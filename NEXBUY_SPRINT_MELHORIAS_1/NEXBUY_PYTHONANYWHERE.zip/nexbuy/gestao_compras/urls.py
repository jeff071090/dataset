from django.urls import path

from . import views

app_name = "gestao_compras"

urlpatterns = [
    path("", views.calendario, name="calendario"),
    path("nova/", views.nova_provisao, name="nova_provisao"),
    path("aprovacao/", views.aprovacao_list, name="aprovacao_list"),
    path("aprovacao/<int:pk>/aprovar/", views.aprovar, name="aprovar"),
    path("aprovacao/<int:pk>/rejeitar/", views.rejeitar, name="rejeitar"),
    path("aprovacao/<int:pk>/solicitar-ajustes/", views.solicitar_ajustes, name="solicitar_ajustes"),
    path("provisao/<int:pk>/timeline/", views.provisao_timeline, name="provisao_timeline"),
    path("provisao/<int:pk>/efetivar/", views.efetivar, name="efetivar_provisao"),
]
