from django.contrib import admin

from .models import EtapaFluxo, FluxoAprovacao, HistoricoProvisao, ItemProvisao, Provisao, SolicitacaoAprovacao


class EtapaFluxoInline(admin.TabularInline):
    model = EtapaFluxo
    extra = 0


@admin.register(FluxoAprovacao)
class FluxoAprovacaoAdmin(admin.ModelAdmin):
    list_display = ("nome", "empresa", "ativo")
    list_filter = ("empresa", "ativo")
    inlines = [EtapaFluxoInline]


class ItemProvisaoInline(admin.TabularInline):
    model = ItemProvisao
    extra = 1
    readonly_fields = ("valor_total",)


class HistoricoProvisaoInline(admin.TabularInline):
    model = HistoricoProvisao
    extra = 0
    readonly_fields = ("usuario", "acao", "detalhe", "criado_em")
    can_delete = False


@admin.register(Provisao)
class ProvisaoAdmin(admin.ModelAdmin):
    list_display = ("fornecedor", "filial", "comprador", "valor_total", "data", "status")
    list_filter = ("status", "filial", "categoria")
    search_fields = ("fornecedor__nome", "observacoes")
    date_hierarchy = "data"
    inlines = [ItemProvisaoInline, HistoricoProvisaoInline]


@admin.register(SolicitacaoAprovacao)
class SolicitacaoAprovacaoAdmin(admin.ModelAdmin):
    list_display = ("provisao", "status", "solicitado_por", "decidido_por", "decidido_em", "valor_excedente")
    list_filter = ("status",)
