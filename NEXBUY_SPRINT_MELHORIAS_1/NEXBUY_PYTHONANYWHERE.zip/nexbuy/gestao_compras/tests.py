"""Testes do módulo de Gestão de Compras (Sprint 4, item 11).

Cobre a criação de provisão dentro e fora do saldo do dia, o Motor de
Aprovação (aprovar/rejeitar) e o cálculo de saldo considerando compras
reais + provisões já lançadas juntas.

Rode com: python manage.py test gestao_compras
"""
import os
import threading
from datetime import date
from decimal import Decimal

from django.db import connections
from django.test import Client, TestCase, TransactionTestCase
from django.test.utils import override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from compras.services import avaliar_e_criar_compra
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, Receita
from usuarios.models import Usuario

from .models import HistoricoProvisao, Provisao, SolicitacaoAprovacao
from .services import (
    ProvisaoNaoEfetivavelError,
    SolicitacaoNaoDecidivelError,
    criar_provisao,
    efetivar_provisao,
    motor_aprovacao_provisao,
    obter_saldo_do_dia,
)

ANO, MES = 2026, 6
DIAS_UTEIS_FIXO = 20


class GestaoComprasTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste GC", cnpj=self._cnpj_unico())
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz", cidade="Cuiabá")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 100000 * 0.5 / 20 = 2500

        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Teste")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Teste")
        self.comprador = Usuario.objects.create_user(
            username=f"comprador_gc_{self.empresa.pk}", password="nexbuy123", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username=f"gerente_gc_{self.empresa.pk}", password="nexbuy123", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )

    _contador_cnpj = [0]

    @classmethod
    def _cnpj_unico(cls):
        cls._contador_cnpj[0] += 1
        return f"11.000.000/000{cls._contador_cnpj[0]}-11"

    def _itens(self, valor_unitario, quantidade=1, produto="Produto Teste"):
        return [{"produto": produto, "quantidade": quantidade, "valor_unitario": valor_unitario}]

    # ------------------------------------------------------------------
    # Criação de provisão
    # ------------------------------------------------------------------

    def test_criar_provisao_dentro_do_limite_fica_provisionada(self):
        provisao, solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=self._itens(1000),
        )
        self.assertFalse(excedeu)
        self.assertIsNone(solicitacao)
        self.assertEqual(provisao.status, Provisao.Status.PROVISIONADA)
        self.assertEqual(provisao.valor_total, Decimal("1000"))
        self.assertEqual(
            HistoricoProvisao.objects.filter(provisao=provisao, acao=HistoricoProvisao.Acao.CRIACAO).count(), 1
        )

    def test_criar_provisao_acima_do_limite_cria_solicitacao(self):
        provisao, solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=self._itens(4000),
        )
        self.assertTrue(excedeu)
        self.assertIsNotNone(solicitacao)
        self.assertEqual(provisao.status, Provisao.Status.AGUARDANDO_APROVACAO)
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)
        self.assertEqual(solicitacao.valor_excedente, Decimal("1500"))  # 4000 - 2500

    def test_valor_total_somado_a_partir_de_varios_itens(self):
        itens = [
            {"produto": "Item 1", "quantidade": 3, "valor_unitario": 100},
            {"produto": "Item 2", "quantidade": 2, "valor_unitario": 50},
        ]
        provisao, _, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=itens,
        )
        self.assertEqual(provisao.valor_total, Decimal("400"))  # 3*100 + 2*50
        self.assertEqual(provisao.itens.count(), 2)

    # ------------------------------------------------------------------
    # Motor de Aprovação
    # ------------------------------------------------------------------

    def test_aprovar_solicitacao_transforma_provisao_em_aprovada(self):
        provisao, solicitacao, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=self._itens(4000),
        )
        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "Aprovado no teste")

        provisao.refresh_from_db()
        solicitacao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.APROVADA)
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.APROVADA)
        self.assertEqual(solicitacao.decidido_por, self.gerente)
        self.assertIsNotNone(solicitacao.decidido_em)
        self.assertTrue(
            HistoricoProvisao.objects.filter(provisao=provisao, acao=HistoricoProvisao.Acao.APROVACAO).exists()
        )

    def test_rejeitar_solicitacao_cancela_provisao(self):
        provisao, solicitacao, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=self._itens(4000),
        )
        motor_aprovacao_provisao.rejeitar(solicitacao, self.gerente, "Sem verba")

        provisao.refresh_from_db()
        solicitacao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.CANCELADA)
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.REJEITADA)
        self.assertTrue(
            HistoricoProvisao.objects.filter(provisao=provisao, acao=HistoricoProvisao.Acao.REJEICAO).exists()
        )

    def test_solicitar_ajustes_cancela_provisao_com_status_proprio(self):
        """Sprint 6, item 5 — "Solicitar Ajustes" é distinto de rejeitar:
        mesmo efeito na Provisão (cancelada, sem edição ainda disponível),
        mas com status e ação de histórico próprios."""
        provisao, solicitacao, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=self._itens(4000),
        )
        motor_aprovacao_provisao.solicitar_ajustes(solicitacao, self.gerente, "Revisar quantidade do item 1")

        provisao.refresh_from_db()
        solicitacao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.CANCELADA)
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.AJUSTES_SOLICITADOS)
        self.assertNotEqual(solicitacao.status, SolicitacaoAprovacao.Status.REJEITADA)
        historico = HistoricoProvisao.objects.get(
            provisao=provisao, acao=HistoricoProvisao.Acao.AJUSTES_SOLICITADOS
        )
        self.assertEqual(historico.detalhe, "Revisar quantidade do item 1")

    def test_provisao_cancelada_nao_conta_no_saldo(self):
        _, solicitacao, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=self._itens(4000),
        )
        motor_aprovacao_provisao.rejeitar(solicitacao, self.gerente, "Sem verba")

        saldo = obter_saldo_do_dia(self.filial, date(ANO, MES, 5))
        self.assertEqual(saldo["provisionado"], Decimal("0"))
        self.assertEqual(saldo["saldo_disponivel"], Decimal("2500"))

    # ------------------------------------------------------------------
    # Saldo considerando Compra (real) + Provisão (planejada) juntas
    # ------------------------------------------------------------------

    def test_saldo_do_dia_considera_compra_e_provisao_juntas(self):
        avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("800"), categoria=self.categoria,
            data_compra=date(ANO, MES, 10), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, usuario=self.comprador,
        )
        criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 10), observacoes="", itens_dados=self._itens(500),
        )

        saldo = obter_saldo_do_dia(self.filial, date(ANO, MES, 10))
        # limite base 2500 - comprado 800 - provisionado 500 = 1200
        self.assertEqual(saldo["comprado"], Decimal("800"))
        self.assertEqual(saldo["provisionado"], Decimal("500"))
        self.assertEqual(saldo["saldo_disponivel"], Decimal("1200"))
        self.assertEqual(saldo["quantidade_provisoes"], 1)


class GestaoComprasViewsTestCase(TestCase):
    """Testa a regra "justificativa obrigatória para rejeitar" na camada de
    view (a `services.rejeitar` em si aceita qualquer justificativa — quem
    exige o preenchimento é a view, por ser uma regra de UX/formulário)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste GC Views", cnpj="22.000.000/0001-22")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Teste Views")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Teste Views")
        self.comprador = Usuario.objects.create_user(
            username="comprador_gc_views", password="nexbuy123", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_gc_views", password="nexbuy123", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        _, self.solicitacao, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 4000}],
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_rejeitar_sem_justificativa_nao_efetiva_e_mostra_erro(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.post(f"/gestao-compras/aprovacao/{self.solicitacao.pk}/rejeitar/", {"justificativa": ""})
        self.assertEqual(response.status_code, 302)

        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_nao_pode_acessar_tela_de_aprovacao(self):
        client = Client()
        client.force_login(self.comprador)
        response = client.get("/gestao-compras/aprovacao/")
        self.assertEqual(response.status_code, 403)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_solicitar_ajustes_sem_justificativa_nao_efetiva_e_mostra_erro(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/solicitar-ajustes/", {"justificativa": ""}
        )
        self.assertEqual(response.status_code, 302)

        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_solicitar_ajustes_com_justificativa_atualiza_solicitacao(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/solicitar-ajustes/",
            {"justificativa": "Confirme o valor unitário"},
        )
        self.assertEqual(response.status_code, 302)

        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.AJUSTES_SOLICITADOS)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_timeline_mostra_historico_para_o_proprio_comprador(self):
        client = Client()
        client.force_login(self.comprador)
        response = client.get(f"/gestao-compras/provisao/{self.solicitacao.provisao.pk}/timeline/")
        self.assertEqual(response.status_code, 200)
        # O template exibe a ação em minúsculas ("comprador criação", como
        # uma frase) — ver `evento.get_acao_display|lower` no template.
        self.assertContains(response, "criação")
        self.assertContains(response, "solicitação de aprovação")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_timeline_de_outra_filial_da_404(self):
        outra_empresa = Empresa.objects.create(nome="Outra Empresa", cnpj="33.000.000/0001-33")
        outra_filial = Filial.objects.create(empresa=outra_empresa, nome="Outra Filial")
        outro_usuario = Usuario.objects.create_user(
            username="comprador_outra_empresa", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=outra_empresa, filial=outra_filial,
        )
        client = Client()
        client.force_login(outro_usuario)
        response = client.get(f"/gestao-compras/provisao/{self.solicitacao.provisao.pk}/timeline/")
        self.assertEqual(response.status_code, 404)


class GateAProprietarioCalendarioEProvisaoTestCase(TestCase):
    """Prompt 2, Gate A: `/gestao-compras/` (Calendário) e
    `/gestao-compras/nova/` (Nova Provisão) eram COMPRADOR-only por engano
    — o Proprietário Operacional (sem `.filial` fixa) também acessa,
    resolvendo a Filial via `filiais_autorizadas_para` (mesmo padrão de
    `financeiro/views_calendario.py`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate A GC", cnpj="66.000.000/0001-66")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz GC", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa)
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Gate A GC")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Gate A GC")
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate_a_gc", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
            empresa=self.empresa, is_staff=False, is_superuser=False,
        )
        self.client = Client()

    def test_proprietario_sem_filial_fixa_acessa_calendario_via_filial_autorizada(self):
        self.assertIsNone(self.proprietario.filial)
        self.client.force_login(self.proprietario)
        response = self.client.get("/gestao-compras/")
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, "sem_filial", status_code=200)

    def test_proprietario_cria_provisao(self):
        self.client.force_login(self.proprietario)
        response = self.client.post(
            "/gestao-compras/nova/",
            {
                "filial": self.filial.pk, "fornecedor": self.fornecedor.pk, "categoria": self.categoria.pk,
                "data": date.today().isoformat(), "observacoes": "",
                "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0", "itens-MIN_NUM_FORMS": "0", "itens-MAX_NUM_FORMS": "1000",
                "itens-0-produto": "Item Gate A", "itens-0-quantidade": "1", "itens-0-valor_unitario": "50,00",
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Provisao.objects.filter(filial=self.filial, comprador=self.proprietario).exists())


class WorkflowAprovacaoTestCase(TestCase):
    """Epico 8 (CORE 1.0): fluxo configuravel com escalonamento por alcada;
    sem fluxo ativo, o comportamento de etapa unica permanece intacto (os
    testes historicos acima continuam cobrindo esse caso)."""

    def setUp(self):
        from empresas.models import Empresa
        from filiais.models import Filial
        from financeiro.models import ConfiguracaoFinanceira, Receita
        from cadastros.models import Categoria
        from compras.models import Fornecedor

        from .models import EtapaFluxo, FluxoAprovacao

        self.EtapaFluxo = EtapaFluxo
        self.FluxoAprovacao = FluxoAprovacao
        self.empresa = Empresa.objects.create(nome="Empresa Workflow", cnpj="81.000.000/0001-81")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa)
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor W")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria W")

        self.comprador = Usuario.objects.create_user("wf_comprador", password="x")
        self.comprador.perfil = Usuario.Perfil.COMPRADOR
        self.comprador.empresa = self.empresa
        self.comprador.filial = self.filial
        self.comprador.save()
        self.gerente = Usuario.objects.create_user("wf_gerente", password="x")
        self.gerente.perfil = Usuario.Perfil.GERENTE
        self.gerente.empresa = self.empresa
        self.gerente.filial = self.filial
        self.gerente.save()
        self.financeiro = Usuario.objects.create_user("wf_financeiro", password="x")
        self.financeiro.perfil = Usuario.Perfil.FINANCEIRO
        self.financeiro.empresa = self.empresa
        self.financeiro.filial = self.filial
        self.financeiro.save()

        self.fluxo = self.FluxoAprovacao.objects.create(
            empresa=self.empresa, nome="Gerente para Financeiro", ativo=True
        )
        self.EtapaFluxo.objects.create(
            fluxo=self.fluxo, ordem=1, perfil_aprovador=Usuario.Perfil.GERENTE, valor_maximo=Decimal("1000.00")
        )
        self.EtapaFluxo.objects.create(fluxo=self.fluxo, ordem=2, perfil_aprovador=Usuario.Perfil.FINANCEIRO)

    def _criar_provisao_acima_do_saldo(self, valor):
        provisao, solicitacao, excedeu = criar_provisao(
            filial=self.filial,
            comprador=self.comprador,
            fornecedor=self.fornecedor,
            categoria=self.categoria,
            data_provisao=date.today(),
            observacoes="",
            itens_dados=[{"produto": "Item W", "quantidade": Decimal("1"), "valor_unitario": valor}],
        )
        self.assertTrue(excedeu)
        return provisao, solicitacao

    def test_solicitacao_nasce_na_primeira_etapa_do_fluxo_ativo(self):
        _, solicitacao = self._criar_provisao_acima_do_saldo(Decimal("999999"))
        self.assertEqual(solicitacao.fluxo, self.fluxo)
        self.assertEqual(solicitacao.etapa_atual.ordem, 1)

    def test_valor_acima_da_alcada_escala_para_a_proxima_etapa(self):
        provisao, solicitacao = self._criar_provisao_acima_do_saldo(Decimal("999999"))
        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "ok da etapa 1")
        solicitacao.refresh_from_db()
        provisao.refresh_from_db()
        self.assertEqual(solicitacao.etapa_atual.ordem, 2)
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)
        self.assertEqual(provisao.status, Provisao.Status.AGUARDANDO_APROVACAO)

        motor_aprovacao_provisao.aprovar(solicitacao, self.financeiro, "ok final")
        provisao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.APROVADA)

    def test_rejeicao_em_qualquer_etapa_encerra_o_fluxo(self):
        provisao, solicitacao = self._criar_provisao_acima_do_saldo(Decimal("999999"))
        motor_aprovacao_provisao.rejeitar(solicitacao, self.gerente, "fora do orcamento")
        provisao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.CANCELADA)

    def test_quem_pode_decidir_a_etapa_atual(self):
        from .services import usuario_pode_decidir_etapa

        _, solicitacao = self._criar_provisao_acima_do_saldo(Decimal("999999"))
        self.assertTrue(usuario_pode_decidir_etapa(self.gerente, solicitacao))
        self.assertFalse(usuario_pode_decidir_etapa(self.financeiro, solicitacao))

        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente)
        solicitacao.refresh_from_db()
        self.assertTrue(usuario_pode_decidir_etapa(self.financeiro, solicitacao))
        self.assertFalse(usuario_pode_decidir_etapa(self.gerente, solicitacao))


class ConcorrenciaAprovacaoProvisaoTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 14): duas decisões sobre a MESMA
    Solicitação de Aprovação (duplo clique, ou dois aprovadores decidindo em
    abas diferentes ao mesmo tempo) — a segunda tentativa encontra o status
    já mudado dentro da transação travada e é rejeitada com um erro de
    domínio, nunca aprova/rejeita a mesma solicitação duas vezes."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Concorrencia GC", cnpj="91.000.000/0001-91")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Concorrencia GC")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Concorrencia GC")
        self.comprador = Usuario.objects.create_user(
            username="comprador_concorrencia_gc", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_concorrencia_gc", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        _, self.solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="",
            itens_dados=[{"produto": "Item Concorrência", "quantidade": 1, "valor_unitario": 4000}],
        )
        self.assertTrue(excedeu)

    def test_segunda_aprovacao_da_mesma_solicitacao_e_rejeitada_com_erro_de_dominio(self):
        motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "primeira decisão")
        with self.assertRaises(SolicitacaoNaoDecidivelError):
            motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "segunda decisão, tarde demais")

    def test_aprovar_e_depois_rejeitar_a_mesma_solicitacao_e_rejeitado(self):
        motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "aprovado")
        with self.assertRaises(SolicitacaoNaoDecidivelError):
            motor_aprovacao_provisao.rejeitar(self.solicitacao, self.gerente, "tarde demais")


class PrecisaoMonetariaCriarProvisaoTestCase(TestCase):
    """Fechamento Final (Seção 8): a decisão "excedeu o saldo do dia?" e o
    `valor_total` persistido da Provisão têm que nascer do MESMO cálculo —
    quantize por item ANTES de somar (`services.criar_provisao` e
    `models.ItemProvisao.save()`). Itens com 2 casas decimais cujo produto
    tem mais de 2 casas (ex.: 0,07 x 0,07 = 0,0049) expõem a divergência que
    existia antes da correção: somar os valores crus e só arredondar uma
    vez no final dá um total diferente de arredondar cada item e depois
    somar."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Precisao GC", cnpj="93.000.000/0001-93")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 100000 * 0.5 / 20 = 2500
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Precisao GC")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Precisao GC")
        self.comprador = Usuario.objects.create_user(
            username="comprador_precisao_gc", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    def test_valor_total_persistido_bate_com_a_soma_por_item_usada_no_gate(self):
        itens = [
            {"produto": f"Item fracionado {i}", "quantidade": Decimal("0.07"), "valor_unitario": Decimal("0.07")}
            for i in range(3)
        ]
        # 0,07 x 0,07 = 0,0049 por item.
        soma_bruta_quantizada_uma_vez_no_final = sum(
            (Decimal(item["quantidade"]) * Decimal(item["valor_unitario"]) for item in itens), Decimal("0")
        ).quantize(Decimal("0.01"))
        soma_correta_quantizando_cada_item_antes = sum(
            (
                (Decimal(item["quantidade"]) * Decimal(item["valor_unitario"])).quantize(Decimal("0.01"))
                for item in itens
            ),
            Decimal("0"),
        )
        # As duas formas de arredondar têm que divergir para estes valores —
        # é essa divergência que o bug original expunha (0,01 vs 0,00).
        self.assertNotEqual(soma_bruta_quantizada_uma_vez_no_final, soma_correta_quantizando_cada_item_antes)
        self.assertEqual(soma_correta_quantizando_cada_item_antes, Decimal("0.00"))

        provisao, _, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="", itens_dados=itens,
        )
        provisao.refresh_from_db()

        self.assertFalse(excedeu)
        self.assertEqual(provisao.status, Provisao.Status.PROVISIONADA)
        self.assertEqual(provisao.valor_total, soma_correta_quantizando_cada_item_antes)
        self.assertEqual(
            sum((item.valor_total for item in provisao.itens.all()), Decimal("0")), provisao.valor_total,
        )


class ConcorrenciaCriarProvisaoTransactionModeTestCase(TransactionTestCase):
    """Fechamento Final (Seção 8): duas criações de Provisão concorrentes na
    MESMA filial/dia, cada uma sozinha dentro do limite, mas juntas
    excedendo — sem `transaction_mode="IMMEDIATE"` (nexbuy/settings.py,
    Seção 14), `select_for_update()` é um no-op no SQLite
    (`has_select_for_update = False`), e as duas threads podiam ler o
    mesmo saldo disponível antes de qualquer uma commitar, reservando
    juntas mais do que o limite diário. Precisa de threads DE VERDADE
    (`TransactionTestCase`, não `TestCase`) para expor a corrida real —
    `TestCase` embrulha o teste inteiro numa única transação externa e as
    outras threads nunca veriam as escritas umas das outras.

    O banco de teste padrão do SQLite (`file:memorydb_default?mode=memory
    &cache=shared`) usa locking em nível de TABELA (SQLITE_LOCKED), que não
    respeita `busy_timeout` — falha na hora em vez de esperar. Isso é
    diferente do `db.sqlite3` real de produção (arquivo), que usa locking
    em nível de BANCO (SQLITE_BUSY) e bloqueia corretamente até o timeout
    configurado — exatamente o que `transaction_mode="IMMEDIATE"` precisa
    para funcionar. Para expor a corrida real (e não um artefato do banco
    de teste em memória), a classe aponta temporariamente o alias
    'default' para um arquivo SQLite de verdade."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        import sqlite3
        import tempfile

        from django.core.management import call_command

        default_settings = connections["default"].settings_dict
        nome_original = default_settings["NAME"]

        # `close()` do backend SQLite é um no-op quando o NAME atual ainda
        # aponta para o banco em memória (proteção contra destruir dados
        # sem querer) — então o `keepalive` abaixo segura pelo menos UMA
        # conexão viva nesse banco compartilhado enquanto trocamos o alias
        # 'default' de arquivo; sem isso, ao fechar a única conexão restante
        # o SQLite destruiria o banco em memória (shared-cache só sobrevive
        # enquanto houver >=1 conexão aberta), quebrando as OUTRAS classes
        # de teste que rodam antes/depois desta no mesmo processo.
        cls._keepalive = sqlite3.connect(nome_original, uri=True)

        fd, cls._db_path = tempfile.mkstemp(suffix=".sqlite3")
        os.close(fd)
        default_settings["NAME"] = cls._db_path
        connections["default"].close()

        def _restaurar_banco_em_memoria():
            connections["default"].close()
            default_settings["NAME"] = nome_original
            connections["default"].close()
            cls._keepalive.close()
            try:
                os.remove(cls._db_path)
            except OSError:
                pass

        cls.addClassCleanup(_restaurar_banco_em_memoria)
        call_command("migrate", run_syncdb=True, verbosity=0, database="default")

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Concorrencia Real GC", cnpj="94.000.000/0001-94")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 100000 * 0.5 / 20 = 2500
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Concorrencia Real GC")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Concorrencia Real GC")
        self.comprador = Usuario.objects.create_user(
            username="comprador_concorrencia_real_gc", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    def test_duas_criacoes_concorrentes_no_mesmo_dia_nunca_ficam_as_duas_provisionadas_acima_do_limite(self):
        resultados = {}
        erros = {}
        barreira = threading.Barrier(2)

        def _criar(chave, valor_item):
            try:
                barreira.wait(timeout=5)
                provisao, _, excedeu = criar_provisao(
                    filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor,
                    categoria=self.categoria, data_provisao=date(ANO, MES, 5), observacoes="",
                    itens_dados=[
                        {"produto": "Item Concorrência Real", "quantidade": 1, "valor_unitario": valor_item}
                    ],
                )
                resultados[chave] = (provisao.pk, excedeu)
            except Exception as exc:  # diagnóstico — não deve acontecer
                erros[chave] = exc
            finally:
                connections.close_all()

        t1 = threading.Thread(target=_criar, args=("a", Decimal("1400")))
        t2 = threading.Thread(target=_criar, args=("b", Decimal("1400")))
        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)

        self.assertFalse(t1.is_alive())
        self.assertFalse(t2.is_alive())
        self.assertEqual(erros, {})
        self.assertEqual(set(resultados.keys()), {"a", "b"})

        provisoes = list(Provisao.objects.filter(pk__in=[resultados["a"][0], resultados["b"][0]]))
        self.assertEqual(len(provisoes), 2)

        provisionadas = [p for p in provisoes if p.status == Provisao.Status.PROVISIONADA]
        aguardando = [p for p in provisoes if p.status == Provisao.Status.AGUARDANDO_APROVACAO]

        # 1400 + 1400 = 2800 > 2500 (limite do dia): as duas NUNCA podem
        # ficar PROVISIONADA ao mesmo tempo — era exatamente isso que
        # acontecia sem `transaction_mode="IMMEDIATE"` (a corrida clássica:
        # as duas leem saldo_disponivel=2500 antes de qualquer commit).
        self.assertEqual(len(provisionadas), 1)
        self.assertEqual(len(aguardando), 1)
        self.assertLessEqual(sum((p.valor_total for p in provisionadas), Decimal("0")), Decimal("2500"))


class EfetivarProvisaoTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 12): Provisão Aprovada -> Compra
    real. Cobre a lacuna crítica que a auditoria funcional apontou (o status
    EFETIVADA existia no enum mas nunca era alcançado) e as garantias
    pedidas — idempotência, parcelas geradas uma única vez, e a Provisão
    efetivada deixando de reservar saldo (Seção 13 — quem passa a valer é a
    Compra vinculada, nunca as duas ao mesmo tempo)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Efetivacao", cnpj="92.000.000/0001-92")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Efetivacao")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Efetivacao")
        self.comprador = Usuario.objects.create_user(
            username="comprador_efetivacao", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_efetivacao", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        provisao, solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="",
            itens_dados=[{"produto": "Item Efetivação", "quantidade": 1, "valor_unitario": 4000}],
        )
        self.assertTrue(excedeu)
        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "Aprovado para efetivação")
        provisao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.APROVADA)
        self.provisao = provisao

    def test_efetivar_provisao_aprovada_cria_compra_vinculada(self):
        compra, ja_efetivada = efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.D30_60_90,
        )
        self.assertFalse(ja_efetivada)
        self.assertEqual(compra.provisao_origem, self.provisao)
        self.assertEqual(compra.valor, Decimal("4000"))
        self.assertEqual(compra.status, Compra.Status.APROVADA)
        self.provisao.refresh_from_db()
        self.assertEqual(self.provisao.status, Provisao.Status.EFETIVADA)
        self.assertTrue(
            HistoricoProvisao.objects.filter(
                provisao=self.provisao, acao=HistoricoProvisao.Acao.EFETIVACAO
            ).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_compra_efetivada_fica_no_nome_do_comprador_da_provisao(self):
        """Rodada 2 dos críticos: quem clica em "Efetivar" (aqui o Financeiro)
        não vira o comprador da Compra. A Compra é de quem planejou a
        Provisão — relatório por comprador, Parcelamentos, Histórico do
        comprador e a dotação individual leem `Compra.usuario`."""
        from compras.services import total_comprado_no_dia_pelo_usuario

        financeiro = Usuario.objects.create_user(
            username="financeiro_efetivacao", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial, first_name="Ana", last_name="Financeira",
        )
        self.comprador.first_name, self.comprador.last_name = "Pedro", "Comprador"
        self.comprador.save(update_fields=["first_name", "last_name"])

        compra, _ = efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=financeiro,
            prazo_pagamento=Compra.PrazoPagamento.D30_60_90,
        )
        self.assertEqual(compra.usuario, self.comprador)
        # Quem efetivou continua na trilha da Compra e da Provisão.
        self.assertEqual(compra.historico.get().usuario, financeiro)
        self.assertEqual(
            HistoricoProvisao.objects.get(provisao=self.provisao, acao=HistoricoProvisao.Acao.EFETIVACAO).usuario,
            financeiro,
        )
        # A dotação individual do comprador desconta a compra efetivada.
        self.assertEqual(
            total_comprado_no_dia_pelo_usuario(self.comprador, self.filial, date(ANO, MES, 5)), Decimal("4000"),
        )
        self.assertEqual(total_comprado_no_dia_pelo_usuario(financeiro, self.filial, date(ANO, MES, 5)), 0)

        client = Client()
        client.force_login(financeiro)
        resposta = client.get("/compras/relatorios/por-comprador/", {"ano": ANO, "mes": MES})
        self.assertEqual(resposta.status_code, 200)
        linhas = {linha["nome"]: linha for linha in resposta.context["agregados"]}
        self.assertEqual(set(linhas), {"Pedro Comprador"})
        self.assertEqual(linhas["Pedro Comprador"]["total"], Decimal("4000"))

    def test_efetivacao_duplicada_devolve_a_mesma_compra_sem_duplicar(self):
        primeira, primeira_ja_efetivada = efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
        )
        self.assertFalse(primeira_ja_efetivada)

        segunda, segunda_ja_efetivada = efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
        )
        self.assertTrue(segunda_ja_efetivada)
        self.assertEqual(primeira.pk, segunda.pk)
        self.assertEqual(Compra.objects.filter(provisao_origem=self.provisao).count(), 1)

    def test_efetivacao_duplicada_nao_gera_parcelas_duas_vezes(self):
        compra, _ = efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.D30_60_90,
        )
        efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.D30_60_90,
        )
        compra.refresh_from_db()
        self.assertEqual(compra.parcelas.count(), 3)
        self.assertEqual(compra.total_parcelas, 3)
        self.assertEqual(sum(p.valor for p in compra.parcelas.all()), Decimal("4000.00"))

    def test_provisao_aguardando_aprovacao_nao_pode_ser_efetivada(self):
        """Fechamento Final (Prompt 1, Seção 7): só Provisionada e Aprovada
        são efetivavéis — uma solicitação ainda PENDENTE de decisão (nem
        aprovada nem dentro do saldo do dia) continua bloqueada."""
        outra_provisao, solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 6), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 999999}],
        )
        self.assertTrue(excedeu)
        self.assertEqual(outra_provisao.status, Provisao.Status.AGUARDANDO_APROVACAO)

        with self.assertRaises(ProvisaoNaoEfetivavelError):
            efetivar_provisao(
                provisao_id=outra_provisao.pk, usuario=self.gerente,
                prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            )

    def test_provisao_cancelada_nao_pode_ser_efetivada(self):
        outra_provisao, _, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 6), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 100}],
        )
        outra_provisao.status = Provisao.Status.CANCELADA
        outra_provisao.save(update_fields=["status"])

        with self.assertRaises(ProvisaoNaoEfetivavelError):
            efetivar_provisao(
                provisao_id=outra_provisao.pk, usuario=self.gerente,
                prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            )

    def test_provisao_provisionada_pode_ser_efetivada(self):
        """Fechamento Final (Prompt 1, Seção 7): a REGRESSÃO que este
        Prompt corrige — antes, uma Provisão que nunca precisou de
        aprovação (nasceu PROVISIONADA, dentro do saldo do dia — o
        caminho mais comum) nunca conseguia virar Compra de verdade."""
        # 08/06/2026 é segunda-feira. Antes era o dia 6 (um SÁBADO): pela
        # regra do Calendário Operacional (rodada 1) fim de semana não tem
        # limite próprio, e a premissa deste teste é "dentro do saldo do dia".
        provisao_dentro_do_saldo, _, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 8), observacoes="",
            itens_dados=[{"produto": "Item Dentro do Saldo", "quantidade": 1, "valor_unitario": 100}],
        )
        self.assertFalse(excedeu)
        self.assertEqual(provisao_dentro_do_saldo.status, Provisao.Status.PROVISIONADA)

        compra, ja_efetivada = efetivar_provisao(
            provisao_id=provisao_dentro_do_saldo.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
        )
        self.assertFalse(ja_efetivada)
        self.assertEqual(compra.provisao_origem, provisao_dentro_do_saldo)
        self.assertEqual(compra.valor, Decimal("100"))
        provisao_dentro_do_saldo.refresh_from_db()
        self.assertEqual(provisao_dentro_do_saldo.status, Provisao.Status.EFETIVADA)
        self.assertTrue(
            HistoricoProvisao.objects.filter(
                provisao=provisao_dentro_do_saldo, acao=HistoricoProvisao.Acao.EFETIVACAO
            ).exists()
        )

    def test_provisao_efetivada_para_de_reservar_saldo_do_dia(self):
        saldo_antes = obter_saldo_do_dia(self.filial, date(ANO, MES, 5))
        self.assertEqual(saldo_antes["provisionado"], Decimal("4000"))

        efetivar_provisao(
            provisao_id=self.provisao.pk, usuario=self.gerente,
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
        )

        saldo_depois = obter_saldo_do_dia(self.filial, date(ANO, MES, 5))
        self.assertEqual(saldo_depois["provisionado"], Decimal("0"))
        # A Compra criada pela efetivação passa a contar como "comprado" —
        # o compromisso não desaparece, só muda de representação.
        self.assertEqual(saldo_depois["comprado"], Decimal("4000"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_tela_de_efetivar_aceita_provisao_provisionada_de_ponta_a_ponta(self):
        """Fechamento Final (Seção 7) — o caminho real do usuário: a tela
        de efetivar (não só o service direto) precisa aceitar uma Provisão
        Provisionada, incluindo `pode_efetivar` liberando o formulário."""
        # 09/06/2026 é terça-feira (antes: dia 7, um DOMINGO — sem limite
        # próprio pela regra do Calendário Operacional, rodada 1).
        provisao_dentro_do_saldo, _, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 9), observacoes="",
            itens_dados=[{"produto": "Item Tela Efetivar", "quantidade": 1, "valor_unitario": 100}],
        )
        self.assertFalse(excedeu)
        self.assertEqual(provisao_dentro_do_saldo.status, Provisao.Status.PROVISIONADA)

        client = Client()
        client.force_login(self.gerente)

        resposta_get = client.get(f"/gestao-compras/provisao/{provisao_dentro_do_saldo.pk}/efetivar/")
        self.assertEqual(resposta_get.status_code, 200)
        self.assertTrue(resposta_get.context["pode_efetivar"])

        resposta_post = client.post(
            f"/gestao-compras/provisao/{provisao_dentro_do_saldo.pk}/efetivar/",
            {"prazo_pagamento": Compra.PrazoPagamento.AVISTA},
        )
        self.assertEqual(resposta_post.status_code, 302)
        provisao_dentro_do_saldo.refresh_from_db()
        self.assertEqual(provisao_dentro_do_saldo.status, Provisao.Status.EFETIVADA)
        self.assertTrue(Compra.objects.filter(provisao_origem=provisao_dentro_do_saldo).exists())


class AcoesProvisaoCrossTenantTestCase(TestCase):
    """Fechamento Final, Seção 4.3: `aprovar`, `rejeitar` e `efetivar` são as
    três ações de decisão do workflow de Provisão e, até aqui, nenhuma tinha
    cobertura cross-tenant — um Gerente de OUTRA empresa (mesmo perfil
    autorizado, mesmo conhecendo o pk) nunca pode decidir nem efetivar uma
    Solicitação/Provisão que não é da própria empresa."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Acoes Cross Tenant", cnpj="40.000.000/0001-40")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Acoes Cross Tenant")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Acoes Cross Tenant")
        self.comprador = Usuario.objects.create_user(
            username="comprador_acoes_cross_tenant", password="nexbuy123", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_acoes_cross_tenant", password="nexbuy123", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        # Item bem acima do saldo do dia (limite base 2500) para gerar uma
        # SolicitacaoAprovacao PENDENTE automaticamente (fluxo legado de
        # etapa única, sem FluxoAprovacao configurado).
        _, self.solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="",
            itens_dados=[{"produto": "Item Acoes Cross Tenant", "quantidade": 1, "valor_unitario": 4000}],
        )
        self.assertTrue(excedeu)
        self.provisao = self.solicitacao.provisao

        # Empresa/filial totalmente separada (sem grupo) com um Gerente
        # próprio — o "intruso".
        self.outra_empresa = Empresa.objects.create(nome="Outra Empresa Acoes", cnpj="41.000.000/0001-41")
        self.outra_filial = Filial.objects.create(empresa=self.outra_empresa, nome="Matriz Intrusa")
        self.gerente_intruso = Usuario.objects.create_user(
            username="gerente_intruso_acoes", password="nexbuy123", perfil=Usuario.Perfil.GERENTE,
            empresa=self.outra_empresa, filial=self.outra_filial,
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_aprovar_solicitacao_de_outra_empresa_e_404(self):
        client = Client()
        client.force_login(self.gerente_intruso)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/aprovar/", {"justificativa": "tentando"}
        )
        self.assertEqual(response.status_code, 404)

        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_rejeitar_solicitacao_de_outra_empresa_e_404(self):
        client = Client()
        client.force_login(self.gerente_intruso)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/rejeitar/", {"justificativa": "tentando"}
        )
        self.assertEqual(response.status_code, 404)

        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_efetivar_provisao_de_outra_empresa_e_404(self):
        # Aprova primeiro com o gerente CORRETO — efetivar só faz sentido de
        # negócio para uma Provisão já APROVADA.
        motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "Aprovado pelo gerente correto")
        self.provisao.refresh_from_db()
        self.assertEqual(self.provisao.status, Provisao.Status.APROVADA)

        client = Client()
        client.force_login(self.gerente_intruso)
        response = client.post(
            f"/gestao-compras/provisao/{self.provisao.pk}/efetivar/",
            {"prazo_pagamento": Compra.PrazoPagamento.AVISTA},
        )
        self.assertEqual(response.status_code, 404)


class AutoaprovacaoControladaProvisaoTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 6: "autoaprovação controlada".
    Por padrão, quem SOLICITOU uma aprovação nunca pode ser quem a decide
    — nem sendo Gerente/Proprietário/superusuário — a menos que a empresa
    ligue `ConfiguracaoPlataforma.permitir_autoaprovacao` explicitamente."""

    def setUp(self):
        from empresas.models import ConfiguracaoPlataforma

        self.ConfiguracaoPlataforma = ConfiguracaoPlataforma
        self.empresa = Empresa.objects.create(nome="Empresa Autoaprovacao Provisao", cnpj="60.000.000/0001-60")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Autoaprovacao")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Autoaprovacao")

        # O Gerente também assina como solicitante (Provisao.comprador) —
        # simula o negócio pequeno onde a mesma pessoa lança e aprovaria.
        self.gerente = Usuario.objects.create_user(
            username="gerente_autoaprovacao", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        self.financeiro = Usuario.objects.create_user(
            username="financeiro_autoaprovacao", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.provisao, self.solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.gerente, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 4000}],
        )
        self.assertTrue(excedeu)
        self.assertEqual(self.solicitacao.solicitado_por_id, self.gerente.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_gerente_nao_pode_aprovar_a_propria_solicitacao_por_padrao(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/aprovar/", {"justificativa": "tentando"}
        )
        self.assertEqual(response.status_code, 302)
        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    def test_service_aprovar_bloqueia_autoaprovacao_mesmo_chamado_diretamente(self):
        """Defesa em profundidade: mesmo pulando a view e chamando o
        service direto, a autoaprovação continua bloqueada."""
        with self.assertRaises(SolicitacaoNaoDecidivelError):
            motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "tentando direto no service")
        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_outra_pessoa_ainda_pode_aprovar(self):
        client = Client()
        client.force_login(self.financeiro)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/aprovar/", {"justificativa": "ok"}
        )
        self.assertEqual(response.status_code, 302)
        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.APROVADA)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_rejeitar_a_propria_solicitacao_continua_permitido(self):
        """A autoaprovação controlada é só sobre APROVAR — rejeitar/pedir
        ajustes na própria solicitação não concede nada a mais a quem
        solicitou, então continua permitido."""
        client = Client()
        client.force_login(self.gerente)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/rejeitar/", {"justificativa": "mudei de ideia"}
        )
        self.assertEqual(response.status_code, 302)
        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.REJEITADA)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_tambem_bloqueado_ao_tentar_autoaprovar(self):
        """O bypass de Proprietário em `usuario_pode_decidir_etapa` é sobre
        HIERARQUIA (destravar fluxo mal configurado) — nunca sobre a
        mesma pessoa aprovar a própria solicitação."""
        proprietario = Usuario.objects.create_user(
            username="prop_autoaprovacao", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        provisao, solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=proprietario, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 6), observacoes="",
            itens_dados=[{"produto": "Item 2", "quantidade": 1, "valor_unitario": 4000}],
        )
        self.assertTrue(excedeu)
        client = Client()
        client.force_login(proprietario)
        response = client.post(f"/gestao-compras/aprovacao/{solicitacao.pk}/aprovar/", {"justificativa": "eu mesmo"})
        self.assertEqual(response.status_code, 302)
        solicitacao.refresh_from_db()
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_superuser_tambem_bloqueado_ao_tentar_autoaprovar(self):
        self.gerente.is_superuser = True
        self.gerente.save(update_fields=["is_superuser"])
        with self.assertRaises(SolicitacaoNaoDecidivelError):
            motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "sou superuser")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_ligar_autoaprovacao_controlada_permite_aprovar_a_propria(self):
        self.ConfiguracaoPlataforma.objects.create(
            empresa=self.empresa, permitir_autoaprovacao=True,
            justificativa_autoaprovacao="Negócio pequeno, sem mais ninguém disponível.",
        )
        client = Client()
        client.force_login(self.gerente)
        response = client.post(
            f"/gestao-compras/aprovacao/{self.solicitacao.pk}/aprovar/", {"justificativa": "agora pode"}
        )
        self.assertEqual(response.status_code, 302)
        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.APROVADA)


class AuditoriaDoCicloDeVidaDaProvisaoTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-3): a Central de Auditoria precisa registrar
    eventos REAIS do ciclo de Provisão (não só login/logout) — cobre
    criação, aprovação (com etapa intermediária), rejeição, ajustes e
    efetivação, sempre com o MESMO `correlation_id` (ligando Provisão →
    Compra → Parcelas) e o flag `autoaprovacao` corretamente aceso/apagado."""

    def setUp(self):
        from auditoria.models import RegistroAuditoria

        self.RegistroAuditoria = RegistroAuditoria
        self.empresa = Empresa.objects.create(nome="Empresa Auditoria Provisao", cnpj="61.000.000/0001-61")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Auditoria Provisao")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Auditoria Provisao")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Auditoria Provisao")
        self.comprador = Usuario.objects.create_user(
            username="comprador_auditoria_provisao", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_auditoria_provisao", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        self.financeiro = Usuario.objects.create_user(
            username="financeiro_auditoria_provisao", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )

    def _criar_provisao_excedente(self, comprador):
        return criar_provisao(
            filial=self.filial, comprador=comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 5), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 4000}],
        )

    def test_criar_provisao_gera_evento_com_correlation_id_proprio(self):
        provisao, solicitacao, excedeu = self._criar_provisao_excedente(self.comprador)
        registro = self.RegistroAuditoria.objects.get(
            categoria=self.RegistroAuditoria.Categoria.PROVISAO_CRIADA, id_objeto=provisao.pk,
        )
        self.assertEqual(registro.correlation_id, f"provisao-{provisao.pk}")
        self.assertEqual(registro.filial, self.filial)
        self.assertEqual(registro.modulo, "provisoes")
        self.assertEqual(registro.resultado, self.RegistroAuditoria.Resultado.SUCESSO)

    def test_aprovar_gera_evento_final_com_mesmo_correlation_id_e_sem_autoaprovacao(self):
        provisao, solicitacao, excedeu = self._criar_provisao_excedente(self.comprador)
        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "Aprovado pela Gerência.")
        solicitacao.refresh_from_db()
        if solicitacao.status == SolicitacaoAprovacao.Status.PENDENTE:
            motor_aprovacao_provisao.aprovar(solicitacao, self.financeiro, "Aprovado pelo Financeiro.")
        eventos_aprovacao = self.RegistroAuditoria.objects.filter(
            categoria=self.RegistroAuditoria.Categoria.PROVISAO_APROVADA, id_objeto=provisao.pk,
        )
        self.assertTrue(eventos_aprovacao.exists())
        for evento in eventos_aprovacao:
            self.assertEqual(evento.correlation_id, f"provisao-{provisao.pk}")
            self.assertFalse(evento.autoaprovacao)
        evento_final = eventos_aprovacao.get(resultado=self.RegistroAuditoria.Resultado.SUCESSO)
        self.assertEqual(evento_final.estado_depois.get("status"), Provisao.Status.APROVADA)

    def test_rejeitar_gera_evento_com_resultado_sucesso(self):
        """Gate D (Prompt 2, Seção 10): rejeitar uma Provisão é uma decisão
        de negócio CONCLUÍDA com sucesso — o evento de auditoria não pode
        aparecer como "falha" (isso ficaria reservado para uma operação
        que não se completou, ex.: erro de concorrência)."""
        provisao, solicitacao, excedeu = self._criar_provisao_excedente(self.comprador)
        motor_aprovacao_provisao.rejeitar(solicitacao, self.financeiro, "Fora do orçamento.")
        registro = self.RegistroAuditoria.objects.get(
            categoria=self.RegistroAuditoria.Categoria.PROVISAO_REJEITADA, id_objeto=provisao.pk,
        )
        self.assertEqual(registro.resultado, self.RegistroAuditoria.Resultado.SUCESSO)
        self.assertEqual(registro.correlation_id, f"provisao-{provisao.pk}")
        self.assertEqual(registro.justificativa, "Fora do orçamento.")

    def test_solicitar_ajustes_gera_evento_proprio(self):
        provisao, solicitacao, excedeu = self._criar_provisao_excedente(self.comprador)
        motor_aprovacao_provisao.solicitar_ajustes(solicitacao, self.gerente, "Confirmar quantidade.")
        self.assertTrue(
            self.RegistroAuditoria.objects.filter(
                categoria=self.RegistroAuditoria.Categoria.PROVISAO_AJUSTES, id_objeto=provisao.pk,
            ).exists()
        )

    def test_efetivar_provisao_reusa_correlation_id_e_registra_compra_e_parcelas(self):
        """Gate pré-Etapa 10 (S1-3, item 6): "correlação Provisão → Compra
        → Parcelas" — o mesmo `correlation_id` da criação aparece no
        evento de efetivação, com a Compra e a contagem de parcelas no
        `estado_depois`."""
        provisao, solicitacao, excedeu = self._criar_provisao_excedente(self.comprador)
        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "Aprovado.")
        solicitacao.refresh_from_db()
        if solicitacao.status == SolicitacaoAprovacao.Status.PENDENTE:
            motor_aprovacao_provisao.aprovar(solicitacao, self.financeiro, "Aprovado pelo Financeiro.")
        compra, _ja_efetivada = efetivar_provisao(
            provisao_id=provisao.pk, usuario=self.financeiro, prazo_pagamento=Compra.PrazoPagamento.D30,
        )
        registro = self.RegistroAuditoria.objects.get(
            categoria=self.RegistroAuditoria.Categoria.PROVISAO_EFETIVADA, id_objeto=provisao.pk,
        )
        self.assertEqual(registro.correlation_id, f"provisao-{provisao.pk}")
        self.assertEqual(registro.estado_depois.get("compra_id"), compra.pk)
        self.assertEqual(registro.estado_depois.get("parcelas"), compra.parcelas.count())

        # Gate H (revisão adversarial, Prompt 2): a Compra nascida da
        # efetivação precisa do PRÓPRIO evento (não só ser citada no
        # `estado_depois` alheio da Provisão) — mesmo `correlation_id`,
        # apontando de volta para a Provisão de origem, com IDs/quantidade/
        # soma das parcelas geradas.
        registro_compra = self.RegistroAuditoria.objects.get(
            categoria=self.RegistroAuditoria.Categoria.COMPRA_LANCADA, id_objeto=compra.pk,
        )
        self.assertEqual(registro_compra.correlation_id, f"provisao-{provisao.pk}")
        self.assertEqual(registro_compra.estado_depois.get("provisao_origem_id"), provisao.pk)
        parcelas_info = registro_compra.estado_depois.get("parcelas")
        self.assertEqual(parcelas_info["quantidade"], compra.parcelas.count())
        self.assertEqual(set(parcelas_info["ids"]), set(compra.parcelas.values_list("pk", flat=True)))
        self.assertEqual(Decimal(parcelas_info["soma"]), compra.valor)

        # As duas categorias compartilham o MESMO correlation_id — um
        # único filtro na Central de Auditoria reconstrói a cadeia inteira.
        cadeia = self.RegistroAuditoria.objects.filter(correlation_id=f"provisao-{provisao.pk}")
        self.assertGreaterEqual(cadeia.count(), 2)
        self.assertTrue(cadeia.filter(tipo_objeto="Provisao").exists())
        self.assertTrue(cadeia.filter(tipo_objeto="Compra").exists())

    def test_autoaprovacao_fica_marcada_quando_solicitante_e_quem_decide(self):
        from empresas.models import ConfiguracaoPlataforma

        ConfiguracaoPlataforma.objects.create(
            empresa=self.empresa, permitir_autoaprovacao=True,
            justificativa_autoaprovacao="Sem outra pessoa disponível.",
        )
        provisao, solicitacao, excedeu = self._criar_provisao_excedente(self.gerente)
        motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "Autoaprovação controlada.")
        solicitacao.refresh_from_db()
        if solicitacao.status == SolicitacaoAprovacao.Status.PENDENTE:
            motor_aprovacao_provisao.aprovar(solicitacao, self.gerente, "2ª etapa, ainda autoaprovação.")
        eventos = self.RegistroAuditoria.objects.filter(
            categoria=self.RegistroAuditoria.Categoria.PROVISAO_APROVADA, id_objeto=provisao.pk,
        )
        self.assertTrue(eventos.exists())
        for evento in eventos:
            self.assertTrue(evento.autoaprovacao)
            self.assertEqual(evento.origem_decisao, self.RegistroAuditoria.OrigemDecisao.AUTOMATICA)


class AuditoriaDeComprasDiretasTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-3): compras lançadas diretamente (sem passar
    por Provisão) também precisam gerar evento — cobre os 3 resultados
    possíveis (aprovada, bloqueada, pendente)."""

    def setUp(self):
        from auditoria.models import RegistroAuditoria

        self.RegistroAuditoria = RegistroAuditoria
        self.empresa = Empresa.objects.create(nome="Empresa Auditoria Compra", cnpj="62.000.000/0001-62")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Auditoria Compra")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
            regra_excesso=ConfiguracaoFinanceira.RegraExcesso.BLOQUEAR,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Auditoria Compra")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Auditoria Compra")
        self.comprador = Usuario.objects.create_user(
            username="comprador_auditoria_compra", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    def test_compra_dentro_do_limite_gera_evento_compra_lancada_sucesso(self):
        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("100"), categoria=self.categoria,
            data_compra=date(ANO, MES, 5), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, usuario=self.comprador,
        )
        registro = self.RegistroAuditoria.objects.get(
            categoria=self.RegistroAuditoria.Categoria.COMPRA_LANCADA, id_objeto=avaliacao.compra.pk,
        )
        self.assertEqual(registro.resultado, self.RegistroAuditoria.Resultado.SUCESSO)
        self.assertEqual(registro.correlation_id, f"compra-{avaliacao.compra.pk}")

    def test_compra_acima_do_limite_com_regra_bloquear_gera_evento_bloqueado(self):
        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("999999"), categoria=self.categoria,
            data_compra=date(ANO, MES, 5), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, usuario=self.comprador,
        )
        registro = self.RegistroAuditoria.objects.get(
            categoria=self.RegistroAuditoria.Categoria.COMPRA_BLOQUEADA, id_objeto=avaliacao.compra.pk,
        )
        self.assertEqual(registro.resultado, self.RegistroAuditoria.Resultado.BLOQUEADO)
