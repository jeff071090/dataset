"""Modelos do módulo de Gestão de Compras (Sprint 4).

Este app cuida exclusivamente do PLANEJAMENTO de compras — a Provisão. Uma
Provisão não é uma compra efetivada (isso continua sendo `compras.Compra`);
é uma intenção de compra que pode ou não vir a se concretizar. Nenhuma regra
financeira (capacidade, limite diário, saldo acumulado) é recalculada aqui —
esse cálculo vem sempre do Motor Financeiro (`finance_engine`), consultado
pelos services deste app (`gestao_compras/services.py`).
"""
from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models

from cadastros.models import Categoria
from compras.models import Fornecedor
from core.models import TimeStampedModel
from empresas.models import Empresa
from filiais.models import Filial
from usuarios.models import Usuario


class Provisao(TimeStampedModel):
    """Cabeçalho de uma intenção de compra (ainda não efetivada)."""

    class Status(models.TextChoices):
        PLANEJADA = "planejada", "Planejada"
        PROVISIONADA = "provisionada", "Provisionada"
        AGUARDANDO_APROVACAO = "aguardando_aprovacao", "Aguardando Aprovação"
        APROVADA = "aprovada", "Aprovada"
        AGUARDANDO_DDA = "aguardando_dda", "Aguardando DDA"
        EFETIVADA = "efetivada", "Efetivada"
        PAGA = "paga", "Paga"
        CANCELADA = "cancelada", "Cancelada"

    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="provisoes", verbose_name="Empresa")
    filial = models.ForeignKey(Filial, on_delete=models.CASCADE, related_name="provisoes", verbose_name="Filial")
    comprador = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="provisoes", verbose_name="Comprador"
    )
    fornecedor = models.ForeignKey(
        Fornecedor, on_delete=models.PROTECT, related_name="provisoes", verbose_name="Fornecedor"
    )
    categoria = models.ForeignKey(
        Categoria, on_delete=models.PROTECT, related_name="provisoes", verbose_name="Categoria"
    )
    data = models.DateField("Data")
    valor_total = models.DecimalField("Valor Total", max_digits=14, decimal_places=2, default=0)
    observacoes = models.TextField("Observações", blank=True)
    status = models.CharField("Status", max_length=25, choices=Status.choices, default=Status.PLANEJADA)

    class Meta:
        verbose_name = "Provisão de Compra"
        verbose_name_plural = "Provisões de Compra"
        ordering = ["-data", "-criado_em"]
        indexes = [
            # Cobre as consultas do Calendário Inteligente e do saldo do dia
            # (`gestao_compras.services`), que sempre filtram por filial+data
            # (Sprint 4.1, auditoria de performance).
            models.Index(fields=["filial", "data"], name="provisao_filial_data_idx"),
            models.Index(fields=["status"], name="provisao_status_idx"),
        ]

    def __str__(self):
        return f"Provisão {self.fornecedor} - R$ {self.valor_total} ({self.data:%d/%m/%Y})"

    def recalcular_valor_total(self, salvar=True):
        """Soma o valor_total de todos os itens já salvos e atualiza o
        cabeçalho — única fonte de verdade para o valor total da provisão."""
        total = sum((item.valor_total for item in self.itens.all()), Decimal("0"))
        self.valor_total = total
        if salvar:
            self.save(update_fields=["valor_total", "atualizado_em"])
        return total


class ItemProvisao(TimeStampedModel):
    """Item (produto) de uma Provisão. Sem cadastro de produtos — o app não
    controla estoque; o campo é apenas descritivo, conforme decidido desde
    o MVP inicial."""

    provisao = models.ForeignKey(Provisao, on_delete=models.CASCADE, related_name="itens", verbose_name="Provisão")
    produto = models.CharField("Produto", max_length=200)
    # RC do Épico 01: quantidade e valor unitário validados em duas camadas
    # (form/model + banco) — antes não havia nenhuma barreira server-side
    # contra valores zero/negativos neste formset.
    quantidade = models.DecimalField(
        "Quantidade", max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))]
    )
    valor_unitario = models.DecimalField(
        "Valor Unitário", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))]
    )
    valor_total = models.DecimalField("Valor Total", max_digits=14, decimal_places=2, editable=False, default=0)

    class Meta:
        verbose_name = "Item da Provisão"
        verbose_name_plural = "Itens da Provisão"
        constraints = [
            models.CheckConstraint(condition=models.Q(quantidade__gt=0), name="item_quantidade_positiva"),
            models.CheckConstraint(condition=models.Q(valor_unitario__gt=0), name="item_valor_unitario_positivo"),
        ]

    def __str__(self):
        return f"{self.produto} ({self.quantidade} x R$ {self.valor_unitario})"

    def save(self, *args, **kwargs):
        # Revisão adversarial (Fechamento Final, Seção 8): quantize explícito
        # a centavos — sem isso, o valor cru (ex.: 3,33 x 3,33 = 11,0889)
        # ficava salvo sem arredondar, e só era arredondado de volta a 2
        # casas quando o BACKEND de banco convertia a leitura (efeito
        # colateral, não garantido em todo backend) — divergindo do total
        # usado por `criar_provisao` para decidir se a Provisão excede o
        # saldo do dia (que soma os valores crus, não os já persistidos).
        # `quantidade`/`valor_unitario` podem chegar aqui como int/str (não
        # só Decimal) — a instância ainda não passou pelo `get_prep_value`
        # do DecimalField, que só roda na escrita no banco. Converter
        # explicitamente antes de multiplicar evita `AttributeError` (int
        # não tem `.quantize`) quando o chamador passa um `int` cru.
        quantidade = Decimal(self.quantidade or 0)
        valor_unitario = Decimal(self.valor_unitario or 0)
        self.valor_total = (quantidade * valor_unitario).quantize(Decimal("0.01"))
        super().save(*args, **kwargs)


class FluxoAprovacao(TimeStampedModel):
    """Fluxo de aprovação configurável por empresa (Épico 8 — CORE 1.0).

    Quando uma empresa tem um fluxo ATIVO, cada Solicitação de Aprovação
    percorre as etapas dele em ordem (escalonamento por alçada); sem fluxo
    configurado, vale o comportamento histórico de decisão em etapa única
    por Proprietário/Gerente/Financeiro — o que preserva todos os testes e
    instalações existentes sem nenhuma mudança.
    """

    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="fluxos_aprovacao", verbose_name="Empresa"
    )
    nome = models.CharField("Nome do fluxo", max_length=100)
    ativo = models.BooleanField("Ativo", default=False)

    class Meta:
        verbose_name = "Fluxo de Aprovação"
        verbose_name_plural = "Fluxos de Aprovação"
        ordering = ["nome"]

    def __str__(self):
        return f"{self.nome} ({self.empresa.nome})"

    def etapas_ordenadas(self):
        return self.etapas.order_by("ordem")


class EtapaFluxo(TimeStampedModel):
    """Uma etapa de um Fluxo de Aprovação: quem decide, até que valor a
    decisão dela é final (alçada), em quanto tempo, e quem substitui."""

    fluxo = models.ForeignKey(FluxoAprovacao, on_delete=models.CASCADE, related_name="etapas", verbose_name="Fluxo")
    ordem = models.PositiveSmallIntegerField("Ordem")
    perfil_aprovador = models.CharField(
        "Perfil aprovador",
        max_length=20,
        choices=Usuario.Perfil.choices,
        help_text="Perfil que decide nesta etapa.",
    )
    aprovador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="etapas_como_aprovador",
        verbose_name="Aprovador específico",
        help_text="Opcional: restringe a etapa a uma pessoa específica (além do perfil).",
    )
    substituto = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="etapas_como_substituto",
        verbose_name="Substituto",
        help_text="Opcional: pessoa que também pode decidir esta etapa (férias/ausências).",
    )
    valor_maximo = models.DecimalField(
        "Alçada (valor máximo)",
        max_digits=14,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Se o valor da provisão for até este teto, a aprovação desta etapa é final; acima dele, sobe para a próxima etapa. Em branco = alçada ilimitada.",
    )
    prazo_dias = models.PositiveSmallIntegerField(
        "Prazo (dias)", null=True, blank=True, help_text="Prazo esperado de decisão desta etapa, em dias."
    )
    observacao = models.CharField("Observação", max_length=200, blank=True)

    class Meta:
        verbose_name = "Etapa do Fluxo"
        verbose_name_plural = "Etapas do Fluxo"
        ordering = ["fluxo", "ordem"]
        constraints = [models.UniqueConstraint(fields=["fluxo", "ordem"], name="etapa_unica_por_ordem")]

    def __str__(self):
        return f"Etapa {self.ordem} — {self.get_perfil_aprovador_display()} ({self.fluxo.nome})"


class SolicitacaoAprovacao(TimeStampedModel):
    """Registro do pedido de aprovação criado quando uma Provisão ultrapassa
    o saldo disponível do dia. Separado do status (mais amplo) da própria
    Provisão porque representa apenas a decisão em si — quem pediu, quem
    decidiu, quando e por quê."""

    class Status(models.TextChoices):
        PENDENTE = "pendente", "Pendente"
        APROVADA = "aprovada", "Aprovada"
        REJEITADA = "rejeitada", "Rejeitada"
        # Valor curto ("ajustes", não "ajustes_solicitados") para caber no
        # max_length=15 já existente, sem precisar alterar o campo
        # (Sprint 6, item 5 — Central de Aprovação).
        AJUSTES_SOLICITADOS = "ajustes", "Ajustes Solicitados"

    provisao = models.ForeignKey(
        Provisao, on_delete=models.CASCADE, related_name="solicitacoes_aprovacao", verbose_name="Provisão"
    )
    status = models.CharField("Status", max_length=15, choices=Status.choices, default=Status.PENDENTE)
    solicitado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="solicitacoes_criadas",
        verbose_name="Solicitado por",
    )
    decidido_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="solicitacoes_decididas", verbose_name="Decidido por",
    )
    decidido_em = models.DateTimeField("Decidido em", null=True, blank=True)
    justificativa = models.TextField("Justificativa", blank=True)
    saldo_disponivel_no_pedido = models.DecimalField("Saldo disponível no pedido", max_digits=14, decimal_places=2)
    valor_excedente = models.DecimalField("Valor excedente", max_digits=14, decimal_places=2)
    # Épico 8 (CORE 1.0) — quando a empresa tem um Fluxo de Aprovação ativo,
    # a solicitação carrega o fluxo e a etapa em que está. Ambos nulos =
    # comportamento histórico de etapa única (nenhuma instalação existente
    # é afetada).
    fluxo = models.ForeignKey(
        FluxoAprovacao,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="solicitacoes",
        verbose_name="Fluxo de aprovação",
    )
    etapa_atual = models.ForeignKey(
        EtapaFluxo,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="solicitacoes_na_etapa",
        verbose_name="Etapa atual",
    )

    class Meta:
        verbose_name = "Solicitação de Aprovação"
        verbose_name_plural = "Solicitações de Aprovação"
        ordering = ["-criado_em"]
        indexes = [
            # `aprovacao_list` filtra sempre por status=PENDENTE — um índice
            # simples acelera essa fila conforme o histórico cresce
            # (Sprint 4.1, auditoria de performance).
            models.Index(fields=["status"], name="solicitacao_status_idx"),
        ]

    def __str__(self):
        return f"Solicitação — {self.provisao} ({self.get_status_display()})"


class HistoricoProvisao(TimeStampedModel):
    """Log de auditoria simples e append-only de uma Provisão: quem criou,
    quem alterou, quem aprovou/rejeitou, quando e o que mudou."""

    class Acao(models.TextChoices):
        CRIACAO = "criacao", "Criação"
        SOLICITACAO_APROVACAO = "solicitacao_aprovacao", "Solicitação de aprovação"
        APROVACAO = "aprovacao", "Aprovação"
        REJEICAO = "rejeicao", "Rejeição"
        AJUSTES_SOLICITADOS = "ajustes_solicitados", "Ajustes solicitados"
        ALTERACAO = "alteracao", "Alteração"
        EFETIVACAO = "efetivacao", "Efetivação em Compra"

    provisao = models.ForeignKey(Provisao, on_delete=models.CASCADE, related_name="historico", verbose_name="Provisão")
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="+", verbose_name="Usuário"
    )
    acao = models.CharField("Ação", max_length=25, choices=Acao.choices)
    detalhe = models.TextField("Detalhe", blank=True)

    class Meta:
        verbose_name = "Histórico da Provisão"
        verbose_name_plural = "Histórico das Provisões"
        ordering = ["criado_em"]

    def __str__(self):
        return f"{self.get_acao_display()} — {self.provisao} ({self.criado_em:%d/%m/%Y %H:%M})"
