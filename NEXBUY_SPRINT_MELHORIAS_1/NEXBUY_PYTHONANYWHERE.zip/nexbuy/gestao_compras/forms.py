from django import forms
from django.forms import inlineformset_factory

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from core.forms import BootstrapFormMixin, MoedaFormMixin

from .models import ItemProvisao, Provisao


class ProvisaoForm(BootstrapFormMixin, forms.ModelForm):
    """Cabeçalho da Provisão (item 6). Fornecedor e Categoria já escopados
    pela empresa do usuário logado — mesmo padrão do `CompraForm`.

    Sprint de Correções Críticas (Seção 11): ganhou o campo `filial`,
    escopado às filiais autorizadas do Comprador na empresa ATIVA — antes a
    filial vinha sempre de `user.filial` (a principal, fixa), então um
    Comprador autorizado em mais de uma filial nunca conseguia provisionar
    fora da primeira."""

    class Meta:
        model = Provisao
        fields = ["filial", "fornecedor", "categoria", "data", "observacoes"]
        widgets = {
            "data": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "observacoes": forms.Textarea(attrs={"rows": 2}),
        }

    def __init__(self, *args, user=None, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["observacoes"].required = False
        self.user = user
        self.filial = None

        if user is None:
            return

        from usuarios.models import filiais_autorizadas_para

        empresa = empresa or user.empresa
        filiais = filiais_autorizadas_para(user, empresa) if empresa is not None else user.filiais_visiveis()
        self.fields["filial"].queryset = filiais
        if filiais.count() == 1:
            self.filial = filiais.first()
            self.fields["filial"].initial = self.filial

        empresa = self.filial.empresa if self.filial else empresa
        if empresa is not None:
            self.fields["fornecedor"].queryset = Fornecedor.objects.filter(empresa=empresa, ativo=True)
            self.fields["categoria"].queryset = Categoria.objects.filter(empresa=empresa, ativo=True)


class ItemProvisaoForm(MoedaFormMixin, BootstrapFormMixin, forms.ModelForm):
    campos_moeda = ("valor_unitario",)

    class Meta:
        model = ItemProvisao
        fields = ["produto", "quantidade", "valor_unitario"]


ItemProvisaoFormSet = inlineformset_factory(
    Provisao,
    ItemProvisao,
    form=ItemProvisaoForm,
    # extra=0 porque min_num já garante 1 linha em branco — min_num e extra
    # se SOMAM (max(min_num, existentes) + extra), então extra=1 aqui
    # renderizaria 2 linhas em vez de 1.
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)


class EfetivarProvisaoForm(BootstrapFormMixin, forms.Form):
    """Prazo de pagamento da Compra gerada ao efetivar uma Provisão (Seção
    12). A Provisão em si não carrega prazo de pagamento — é só uma
    intenção de compra; o prazo real só existe quando o compromisso se
    torna definitivo, então é escolhido aqui, no momento da efetivação
    (mesmos campos e mesma validação de `compras.forms.CompraForm`)."""

    prazo_pagamento = forms.ChoiceField(label="Prazo de pagamento", choices=Compra.PrazoPagamento.choices)
    prazo_personalizado_dias = forms.IntegerField(
        label="Intervalo entre parcelas (dias)", required=False, min_value=1,
    )
    numero_parcelas = forms.IntegerField(label="Número de parcelas", required=False, min_value=1)

    def clean(self):
        cleaned_data = super().clean()
        prazo = cleaned_data.get("prazo_pagamento")
        dias = cleaned_data.get("prazo_personalizado_dias")
        parcelas = cleaned_data.get("numero_parcelas") or 1
        cleaned_data["numero_parcelas"] = parcelas
        if prazo == Compra.PrazoPagamento.PERSONALIZADO:
            if not dias:
                self.add_error("prazo_personalizado_dias", "Informe a quantidade de dias para o prazo personalizado.")
            if parcelas < 1:
                self.add_error("numero_parcelas", "O número de parcelas deve ser 1 ou maior.")
        return cleaned_data


class DecisaoAprovacaoForm(forms.Form):
    """Usado tanto para aprovar quanto para rejeitar — a view decide qual
    ação chamar; aqui só validamos a justificativa."""

    justificativa = forms.CharField(
        label="Justificativa", required=False, widget=forms.Textarea(attrs={"rows": 2, "class": "form-control"})
    )
