"""Views do módulo de Gestão de Compras.

Nenhum cálculo acontece aqui — toda a lógica de saldo, criação de provisão
e decisão de aprovação vive em `gestao_compras/services.py` (que por sua
vez delega ao Motor Financeiro). As views só coletam o contexto, validam o
formulário e escolhem o template.
"""
from datetime import date, timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from core.contexto import empresa_ativa, filiais_do_contexto
from core.permissions import PERFIS_APROVADORES_PROVISAO, perfil_required, permissao_required
from core.utils import formatar_moeda
from financeiro.services import capacidade_configurada
from usuarios.models import Usuario, filiais_autorizadas_para

from .forms import DecisaoAprovacaoForm, EfetivarProvisaoForm, ItemProvisaoFormSet, ProvisaoForm
from .models import Provisao, SolicitacaoAprovacao
from .services import (
    STATUS_EFETIVAVEIS,
    ProvisaoNaoEfetivavelError,
    SolicitacaoNaoDecidivelError,
    autoaprovacao_bloqueada,
    criar_provisao,
    efetivar_provisao,
    marcar_decidiveis,
    motor_aprovacao_provisao,
    obter_calendario_mensal,
    provisoes_aguardando_efetivacao,
    provisoes_visiveis_para,
    usuario_pode_decidir_etapa,
)

PERFIS_APROVACAO_PROVISAO = PERFIS_APROVADORES_PROVISAO


def _filial_do_calendario(request):
    """Resolve a Filial do Calendário Inteligente. O Comprador (perfil com
    uma Filial "de casa") mantém o comportamento original — `request.user
    .filial` direto. Gate A (Prompt 2): o Proprietário Operacional também
    acessa esta tela, mas não tem uma `.filial` fixa — ele opera todas as
    Filiais ativas da Empresa selecionada — então cai no mesmo padrão já
    usado em `financeiro/views_calendario.py::_filial_selecionada`: lista
    as Filiais autorizadas no contexto e aceita `?filial=<pk>` para trocar,
    com a primeira como padrão."""
    if request.user.filial is not None:
        return request.user.filial
    empresa = empresa_ativa(request)
    filiais = list(filiais_autorizadas_para(request.user, empresa)) if empresa is not None else []
    filial_id = request.GET.get("filial")
    if filial_id:
        for filial in filiais:
            if str(filial.pk) == str(filial_id):
                return filial
    return filiais[0] if filiais else None


@permissao_required("calendario.ver")
def calendario(request):
    """Tela principal do Comprador (Sprint 4, item 5); também acessível ao
    Proprietário Operacional (Gate A, Prompt 2) — ver `_filial_do_calendario`."""
    filial = _filial_do_calendario(request)
    if filial is None:
        return render(request, "gestao_compras/calendario.html", {"sem_filial": True})

    hoje = date.today()
    # Defesa contra querystring malformada (mesmo padrão de
    # `compras.views._periodo_do_mes`) — sem isso, qualquer "ano"/"mes" que
    # não seja um inteiro puro (ex.: um favorito antigo, uma edição manual
    # da URL, ou — achado real do QA — o próprio número já formatado com
    # separador de milhar do locale pt-br, "2.026") derruba a tela com
    # HTTP 500 em vez de simplesmente cair no mês atual.
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
    except (TypeError, ValueError):
        ano, mes = hoje.year, hoje.month

    dias = obter_calendario_mensal(filial, ano, mes)

    mes_anterior = date(ano, mes, 1) - timedelta(days=1)
    proximo_mes = (date(ano, mes, 28) + timedelta(days=7)).replace(day=1)

    empresa = empresa_ativa(request)
    filiais_disponiveis = (
        list(filiais_autorizadas_para(request.user, empresa))
        if request.user.filial is None and empresa is not None
        else []
    )
    # Rodada final (crítico funcional): a lista existia, mas nenhum template
    # a usava — o Proprietário com mais de uma filial ficava preso na 1ª em
    # ordem alfabética, e os links de mês descartavam o ?filial=. Com mais
    # de uma filial, o template mostra o seletor e TODO link da tela
    # (mês anterior/próximo, Nova Provisão) carrega a filial escolhida.
    multi_filial = len(filiais_disponiveis) > 1

    return render(
        request,
        "gestao_compras/calendario.html",
        {
            "sem_filial": False,
            "filial": filial,
            "filiais_disponiveis": filiais_disponiveis,
            "multi_filial": multi_filial,
            "hoje": hoje,
            "ano": ano,
            "mes": mes,
            "data_referencia": date(ano, mes, 1),
            "dias": dias,
            "mes_anterior": mes_anterior,
            "proximo_mes": proximo_mes,
            # Etapa 02 (Cliente-Ready): sem isso, um mês sem Receita
            # cadastrada mostra todo dia "verde" como se a capacidade
            # tivesse sido calculada e desse positiva — o template usa este
            # sinal só para pintar os dias de um jeito distinto (neutro),
            # nenhuma fórmula do calendário muda.
            "capacidade_configurada": capacidade_configurada(filial, ano, mes),
        },
    )


@permissao_required("provisoes.criar")
def nova_provisao(request):
    """Formulário de Nova Provisão (Sprint 4, item 6).

    Sprint de Correções Críticas (Seções 11/16): a filial não vem mais fixa
    de `request.user.filial` — o form oferece as filiais AUTORIZADAS do
    Comprador na empresa ATIVA (auto-selecionada se só houver uma, escolha
    obrigatória se houver mais), e a filial submetida é revalidada no
    service antes de gravar."""
    empresa = empresa_ativa(request)
    if not filiais_autorizadas_para(request.user, empresa).exists():
        messages.error(request, "Seu usuário não está vinculado a nenhuma filial autorizada nesta empresa.")
        return redirect("gestao_compras:calendario")

    data_inicial = request.GET.get("data") or date.today().isoformat()
    initial = {"data": data_inicial}
    # Vindo do Calendário de Compras de uma filial específica (?filial=),
    # a filial já chega escolhida — só se for uma das autorizadas.
    filial_get = request.GET.get("filial")
    if filial_get and filiais_autorizadas_para(request.user, empresa).filter(pk=filial_get if filial_get.isdigit() else 0).exists():
        initial["filial"] = int(filial_get)

    if request.method == "POST":
        form = ProvisaoForm(request.POST, user=request.user, empresa=empresa)
        formset = ItemProvisaoFormSet(request.POST, prefix="itens")
        if form.is_valid() and formset.is_valid():
            itens_dados = [
                {
                    "produto": item["produto"],
                    "quantidade": item["quantidade"],
                    "valor_unitario": item["valor_unitario"],
                }
                for item in formset.cleaned_data
                if item and not item.get("DELETE")
            ]
            if not itens_dados:
                messages.error(request, "Inclua ao menos um item na provisão.")
            else:
                provisao, solicitacao, excedeu = criar_provisao(
                    filial=form.cleaned_data["filial"],
                    comprador=request.user,
                    fornecedor=form.cleaned_data["fornecedor"],
                    categoria=form.cleaned_data["categoria"],
                    data_provisao=form.cleaned_data["data"],
                    observacoes=form.cleaned_data.get("observacoes", ""),
                    itens_dados=itens_dados,
                )
                if excedeu:
                    messages.warning(
                        request,
                        "Provisão enviada para aprovação: ultrapassa o saldo disponível do dia em "
                        f"{formatar_moeda(solicitacao.valor_excedente, incluir_prefixo=True)}.",
                    )
                else:
                    messages.success(request, "Provisão criada com sucesso.")
                return redirect("gestao_compras:calendario")
    else:
        form = ProvisaoForm(initial=initial, user=request.user, empresa=empresa)
        formset = ItemProvisaoFormSet(prefix="itens")

    from compras.views import cadastros_de_apoio_faltando

    return render(
        request,
        "gestao_compras/provisao_form.html",
        {
            "form": form,
            "formset": formset,
            "cadastros_faltando": cadastros_de_apoio_faltando(request.user, empresa),
        },
    )


@perfil_required(*PERFIS_APROVACAO_PROVISAO)
def aprovacao_list(request):
    """Lista de Solicitações de Aprovação pendentes (Sprint 4, item 4).
    Traz também o histórico de cada Provisão (Sprint 6, item 6) — exibido
    na linha expandida de decisão, junto com Solicitante/Fornecedor/
    Categoria/Valor/Data/Motivo já mostrados desde a Sprint 4."""
    # Sprint de Correções Críticas (Seção 16): filiais da empresa ATIVA.
    solicitacoes = (
        SolicitacaoAprovacao.objects.filter(
            status=SolicitacaoAprovacao.Status.PENDENTE,
            provisao__filial__in=filiais_do_contexto(request),
        )
        .select_related(
            "provisao", "provisao__fornecedor", "provisao__categoria", "provisao__comprador",
            "provisao__filial", "etapa_atual", "etapa_atual__aprovador",
        )
        .prefetch_related("provisao__itens", "provisao__historico", "provisao__historico__usuario")
    )
    # Crítico funcional (rodada 1): num fluxo de várias etapas, a fila
    # mostrava "Decidir" também para quem NÃO decide a etapa atual — e o
    # clique em Aprovar dava erro. Cada item agora sabe se este usuário pode
    # decidir; quem não pode vê "Aguardando <quem decide> (etapa N)".
    solicitacoes = marcar_decidiveis(solicitacoes, request.user)
    return render(
        request,
        "gestao_compras/aprovacao_list.html",
        {
            "solicitacoes": solicitacoes,
            "total_decidiveis": sum(1 for s in solicitacoes if s.pode_decidir),
            # Rodada final: depois de aprovada, o caminho até o "Efetivar".
            "aguardando_efetivacao": provisoes_aguardando_efetivacao(request.user, filiais_do_contexto(request)),
        },
    )


@perfil_required(*PERFIS_APROVACAO_PROVISAO)
def aprovar(request, pk):
    solicitacao = get_object_or_404(
        SolicitacaoAprovacao,
        pk=pk,
        status=SolicitacaoAprovacao.Status.PENDENTE,
        provisao__filial__in=filiais_do_contexto(request),
    )
    if request.method == "POST":
        if autoaprovacao_bloqueada(request.user, solicitacao):
            messages.error(
                request,
                "Você não pode aprovar a própria solicitação — peça para outra pessoa aprovar, ou "
                "habilite a autoaprovação controlada em Configurações Gerais (com justificativa).",
            )
            return redirect("gestao_compras:aprovacao_list")
        if not usuario_pode_decidir_etapa(request.user, solicitacao):
            messages.error(
                request,
                f"Esta solicitação está na etapa {solicitacao.etapa_atual.ordem} do fluxo de aprovação "
                f"({solicitacao.etapa_atual.get_perfil_aprovador_display()}) — a decisão cabe a essa etapa.",
            )
            return redirect("gestao_compras:aprovacao_list")
        form = DecisaoAprovacaoForm(request.POST)
        justificativa = form.data.get("justificativa", "") if form.is_valid() else ""
        try:
            provisao_decidida = motor_aprovacao_provisao.aprovar(solicitacao, request.user, justificativa)
        except SolicitacaoNaoDecidivelError as exc:
            messages.error(request, str(exc))
        else:
            if provisao_decidida.status == Provisao.Status.APROVADA:
                messages.success(request, f"Provisão de {solicitacao.provisao.fornecedor} aprovada.")
            else:
                messages.success(
                    request,
                    f"Etapa aprovada — a provisão de {solicitacao.provisao.fornecedor} seguiu para a próxima etapa do fluxo.",
                )
    return redirect("gestao_compras:aprovacao_list")


@perfil_required(*PERFIS_APROVACAO_PROVISAO)
def rejeitar(request, pk):
    solicitacao = get_object_or_404(
        SolicitacaoAprovacao,
        pk=pk,
        status=SolicitacaoAprovacao.Status.PENDENTE,
        provisao__filial__in=filiais_do_contexto(request),
    )
    if request.method == "POST":
        if not usuario_pode_decidir_etapa(request.user, solicitacao):
            messages.error(
                request,
                f"Esta solicitação está na etapa {solicitacao.etapa_atual.ordem} do fluxo de aprovação "
                f"({solicitacao.etapa_atual.get_perfil_aprovador_display()}) — a decisão cabe a essa etapa.",
            )
            return redirect("gestao_compras:aprovacao_list")
        justificativa = request.POST.get("justificativa", "").strip()
        if not justificativa:
            messages.error(request, "Informe uma justificativa para rejeitar a provisão.")
            return redirect("gestao_compras:aprovacao_list")
        try:
            motor_aprovacao_provisao.rejeitar(solicitacao, request.user, justificativa)
        except SolicitacaoNaoDecidivelError as exc:
            messages.error(request, str(exc))
        else:
            messages.info(request, f"Provisão de {solicitacao.provisao.fornecedor} rejeitada.")
    return redirect("gestao_compras:aprovacao_list")


@perfil_required(*PERFIS_APROVACAO_PROVISAO)
def solicitar_ajustes(request, pk):
    """Devolve a Solicitação ao comprador pedindo ajustes (Sprint 6, item
    5) — distinto de aprovar/rejeitar. Justificativa obrigatória, mesma
    regra de UX que `rejeitar` já aplica."""
    solicitacao = get_object_or_404(
        SolicitacaoAprovacao,
        pk=pk,
        status=SolicitacaoAprovacao.Status.PENDENTE,
        provisao__filial__in=filiais_do_contexto(request),
    )
    if request.method == "POST":
        if not usuario_pode_decidir_etapa(request.user, solicitacao):
            messages.error(
                request,
                f"Esta solicitação está na etapa {solicitacao.etapa_atual.ordem} do fluxo de aprovação "
                f"({solicitacao.etapa_atual.get_perfil_aprovador_display()}) — a decisão cabe a essa etapa.",
            )
            return redirect("gestao_compras:aprovacao_list")
        justificativa = request.POST.get("justificativa", "").strip()
        if not justificativa:
            messages.error(request, "Informe o que precisa ser ajustado.")
            return redirect("gestao_compras:aprovacao_list")
        try:
            motor_aprovacao_provisao.solicitar_ajustes(solicitacao, request.user, justificativa)
        except SolicitacaoNaoDecidivelError as exc:
            messages.error(request, str(exc))
        else:
            messages.info(request, f"Ajustes solicitados na provisão de {solicitacao.provisao.fornecedor}.")
    return redirect("gestao_compras:aprovacao_list")


@login_required
def provisao_timeline(request, pk):
    """Timeline visual do histórico de uma Provisão (Sprint 6, item 6):
    quem criou, solicitou aprovação, aprovou/rejeitou/pediu ajustes, e
    quando — em ordem cronológica. Reaproveita `HistoricoProvisao`
    (Sprint 4); não inventa nenhum evento que dependeria do DDA (ex.:
    uma etapa de "confirmação financeira" só existiria de verdade com
    essa integração, prevista e ainda não conectada).

    RC do Épico 01 (Correção 01): o escopo vem de
    `provisoes_visiveis_para` — o Comprador acessa SOMENTE as timelines das
    próprias provisões (antes via qualquer uma da filial); os aprovadores
    seguem vendo as da filial que já enxergam em `Aprovação de Provisões`."""
    from compras.models import Compra
    from core.permissions import usuario_tem_permissao

    provisao = get_object_or_404(
        provisoes_visiveis_para(request.user, empresa_ativa(request))
        .select_related("fornecedor", "categoria", "comprador", "filial"),
        pk=pk,
    )
    eventos = provisao.historico.select_related("usuario").all()
    compra_efetivada = Compra.objects.filter(provisao_origem=provisao).first()
    contexto = {
        "provisao": provisao,
        "eventos": eventos,
        "compra_efetivada": compra_efetivada,
        "pode_efetivar": (
            provisao.status in STATUS_EFETIVAVEIS
            and compra_efetivada is None
            and usuario_tem_permissao(request.user, "provisoes.efetivar")
        ),
    }
    return render(request, "gestao_compras/provisao_timeline.html", contexto)


@permissao_required("provisoes.efetivar")
def efetivar(request, pk):
    """Ação explícita "Efetivar Provisão" (Sprint de Correções Críticas —
    Seção 12): transforma a intenção de compra num compromisso real
    (`compras.Compra`). O RBAC já restringe quem chega até aqui
    (Proprietário/Gerente/Financeiro); `efetivar_provisao` ainda revalida
    empresa/filial/status dentro da própria transação — mesmo um acesso
    direto por URL nunca efetiva algo fora do permitido ou fora de ordem."""
    from compras.models import Compra

    provisao = get_object_or_404(
        provisoes_visiveis_para(request.user, empresa_ativa(request)).select_related(
            "fornecedor", "categoria", "comprador", "filial", "empresa"
        ),
        pk=pk,
    )
    compra_existente = Compra.objects.filter(provisao_origem=provisao).first()
    pode_efetivar = provisao.status in STATUS_EFETIVAVEIS and compra_existente is None

    if request.method == "POST":
        form = EfetivarProvisaoForm(request.POST)
        if pode_efetivar and form.is_valid():
            try:
                compra, ja_efetivada = efetivar_provisao(
                    provisao_id=provisao.pk,
                    usuario=request.user,
                    prazo_pagamento=form.cleaned_data["prazo_pagamento"],
                    prazo_personalizado_dias=form.cleaned_data.get("prazo_personalizado_dias"),
                    numero_parcelas=form.cleaned_data.get("numero_parcelas") or 1,
                )
            except ProvisaoNaoEfetivavelError as exc:
                messages.error(request, str(exc))
            else:
                if ja_efetivada:
                    messages.info(request, "Esta provisão já havia sido efetivada anteriormente.")
                else:
                    messages.success(
                        request,
                        f"Provisão efetivada — Compra de {formatar_moeda(compra.valor, incluir_prefixo=True)} "
                        f"criada com {compra.get_prazo_pagamento_display()}.",
                    )
            return redirect("gestao_compras:provisao_timeline", pk=provisao.pk)
        if not pode_efetivar:
            messages.error(request, "Esta provisão não está mais disponível para efetivação.")
            return redirect("gestao_compras:provisao_timeline", pk=provisao.pk)
    else:
        form = EfetivarProvisaoForm()

    contexto = {
        "provisao": provisao,
        "form": form,
        "compra_existente": compra_existente,
        "pode_efetivar": pode_efetivar,
    }
    return render(request, "gestao_compras/provisao_efetivar.html", contexto)
