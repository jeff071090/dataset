"""Regras de negócio do módulo de Gestão de Compras (Sprint 4).

Este módulo cuida apenas do PLANEJAMENTO de compras (Provisão). Ele NÃO
recalcula capacidade financeira nem reimplementa a máquina de estados de
`compras.Compra` — toda regra de cálculo de limite/saldo continua vindo do
Motor Financeiro (`finance_engine`), e a leitura do que já foi efetivamente
comprado vem do app `compras` (somente leitura). Isso preserva a regra da
Sprint 3 de que todo cálculo financeiro passa por um único motor, e evita
duplicar a fórmula de capacidade aqui.

Serviços expostos:

- `obter_saldo_do_dia` / `obter_calendario_mensal` — saldo disponível de um
  dia (ou do mês inteiro) considerando compras reais + provisões já
  lançadas (item 5 — Calendário Inteligente).
- `criar_provisao` — cria a Provisão e, se ultrapassar o saldo do dia,
  cria automaticamente a Solicitação de Aprovação em vez de liberar a
  compra (item 4 — Motor de Aprovação).
- `MotorAprovacaoProvisao` — aprova/rejeita uma Solicitação de Aprovação.
- `registrar_historico` — grava cada alteração relevante da Provisão
  (item 7 — Histórico).
- `efetivar_provisao` — transforma uma Provisão Aprovada num compromisso
  real: cria a `compras.Compra` vinculada, gera as parcelas e move a
  Provisão para Efetivada (Sprint de Correções Críticas, Seção 12).
"""
from datetime import date
from decimal import Decimal
from typing import Optional

from django.db.models import Avg, Count, Sum
from django.utils import timezone

from auditoria.models import RegistroAuditoria
from auditoria.services import registrar_evento
from core.permissions import autoaprovacao_controlada_permitida
from core.utils import formatar_moeda
from finance_engine.calculations import ZERO, classificar_consumo
from finance_engine.services import motor_financeiro
from notificacoes.models import Notificacao
from notificacoes.services import notificar, notificar_perfis
from usuarios.models import Usuario

from .models import EtapaFluxo, FluxoAprovacao, HistoricoProvisao, ItemProvisao, Provisao, SolicitacaoAprovacao

# Status que "reservam" saldo do dia — tudo, exceto o que nunca chegou a
# valer (Planejada, um rascunho ainda não implementado nesta Sprint — ver
# Arquitetura.md) ou o que foi cancelado/rejeitado.
#
# Sprint de Correções Críticas (Seção 13) — EFETIVADA saiu desta lista: uma
# vez efetivada, o compromisso passa a ser representado pela Compra vinculada
# (`Compra.provisao_origem`), não mais pela Provisão — somar as duas contaria
# o mesmo valor duas vezes. PAGA permanece (nenhum fluxo desta Sprint chega
# a esse status; fora do escopo da correção pedida).
STATUS_QUE_RESERVAM_SALDO = (
    Provisao.Status.PROVISIONADA,
    Provisao.Status.AGUARDANDO_APROVACAO,
    Provisao.Status.APROVADA,
    Provisao.Status.AGUARDANDO_DDA,
    Provisao.Status.PAGA,
)

# Fechamento Final (Prompt 1, Seção 7): uma Provisão fica PROVISIONADA (não
# APROVADA) quando NUNCA precisou de aprovação — ela nasceu dentro do saldo
# disponível do dia (`criar_provisao`, `excedeu=False`). Antes desta Seção,
# `efetivar_provisao` só aceitava APROVADA, então o caminho mais comum (a
# maioria das provisões cabe no saldo do dia) nunca conseguia virar Compra
# de verdade — um gap real do ciclo, não intencional. Provisionada e
# Aprovada são igualmente "prontas para efetivar": a diferença entre elas é
# só SE passaram por aprovação explícita, não se têm ou não compromisso
# financeiro válido (ambas já reservam saldo — ver `STATUS_QUE_RESERVAM_SALDO`).
STATUS_EFETIVAVEIS = (Provisao.Status.APROVADA, Provisao.Status.PROVISIONADA)


def total_provisionado_no_dia(filial, data_referencia: date, excluir_pk: Optional[int] = None) -> Decimal:
    """Soma o valor de todas as provisões ativas de um dia."""
    qs = Provisao.objects.filter(filial=filial, data=data_referencia, status__in=STATUS_QUE_RESERVAM_SALDO)
    if excluir_pk:
        qs = qs.exclude(pk=excluir_pk)
    return qs.aggregate(total=Sum("valor_total"))["total"] or ZERO


def contar_provisoes_no_dia(filial, data_referencia: date) -> int:
    return Provisao.objects.filter(filial=filial, data=data_referencia, status__in=STATUS_QUE_RESERVAM_SALDO).count()


def obter_saldo_do_dia(filial, data_referencia: date) -> dict:
    """Saldo disponível de um dia, considerando compras reais (via Motor
    Financeiro) e provisões já lançadas (deste módulo). É a base de tudo
    que a tela de Calendário Inteligente mostra."""
    posicao = motor_financeiro.posicao_do_dia(filial, data_referencia)
    provisionado = total_provisionado_no_dia(filial, data_referencia)
    ja_comprometido = posicao.comprado + provisionado
    saldo_disponivel = posicao.limite_efetivo - ja_comprometido
    cor = classificar_consumo(ja_comprometido, posicao.limite_efetivo)

    return {
        "data": data_referencia,
        "limite_efetivo": posicao.limite_efetivo,
        "comprado": posicao.comprado,
        "provisionado": provisionado,
        "saldo_disponivel": saldo_disponivel,
        "quantidade_provisoes": contar_provisoes_no_dia(filial, data_referencia),
        "cor": cor,
    }


def agrupar_provisoes_do_mes(filial, ano: int, mes: int) -> dict:
    """{dia_do_mes: [Provisao, ...]} em uma única consulta — evita N+1 ao
    montar o calendário do mês inteiro."""
    provisoes = (
        Provisao.objects.filter(
            filial=filial, data__year=ano, data__month=mes, status__in=STATUS_QUE_RESERVAM_SALDO
        )
        .select_related("fornecedor", "categoria", "comprador")
        .prefetch_related("itens")
        .order_by("data", "criado_em")
    )
    agrupado: dict = {}
    for provisao in provisoes:
        agrupado.setdefault(provisao.data.day, []).append(provisao)
    return agrupado


def _somar_provisionado_por_dia(filial, ano: int, mes: int) -> dict:
    """{dia_do_mes: (total_provisionado, quantidade)} em uma única consulta
    agregada — usado pelo calendário do mês inteiro."""
    registros = (
        Provisao.objects.filter(
            filial=filial, data__year=ano, data__month=mes, status__in=STATUS_QUE_RESERVAM_SALDO
        )
        .values("data")
        .annotate(total=Sum("valor_total"), quantidade=Count("id"))
    )
    return {registro["data"].day: (registro["total"] or ZERO, registro["quantidade"]) for registro in registros}


def provisoes_visiveis_para(usuario, empresa=None):
    """Escopo de visualização de Provisões por perfil (RC do Épico 01 —
    Correção 01): o COMPRADOR enxerga somente as próprias provisões (e,
    por consequência, só as timelines delas); os perfis aprovadores seguem
    vendo as provisões das filiais que já enxergavam.

    Sprint de Correções Críticas (Seção 16) — aceita `empresa` (a empresa
    ATIVA do contexto); sem ela, mantém o comportamento antigo por
    compatibilidade com chamadores que ainda não passam o contexto."""
    from usuarios.models import Usuario, filiais_autorizadas_para

    filiais = filiais_autorizadas_para(usuario, empresa) if empresa is not None else usuario.filiais_visiveis()
    qs = Provisao.objects.filter(filial__in=filiais)
    if usuario.perfil == Usuario.Perfil.COMPRADOR:
        qs = qs.filter(comprador=usuario)
    return qs


def provisoes_aguardando_efetivacao(usuario, filiais):
    """Provisões prontas para virar Compra (APROVADA ou PROVISIONADA, sem
    Compra vinculada) nas `filiais` informadas — só para quem tem
    `provisoes.efetivar` (mesmo gate da view `efetivar`).

    Rodada final (crítico funcional): depois da aprovação final, Gerente e
    Financeiro — que podem efetivar — não tinham caminho navegável até a
    timeline onde fica o botão "Efetivar Provisão" (a fila de aprovação só
    mostrava pendentes e o Calendário de Compras não está no menu deles).
    A Central de Aprovações e a fila de provisões passam a listar estas."""
    from compras.models import Compra
    from core.permissions import usuario_tem_permissao

    if not usuario_tem_permissao(usuario, "provisoes.efetivar"):
        return []
    ja_efetivadas = Compra.objects.filter(provisao_origem__isnull=False).values("provisao_origem")
    return list(
        Provisao.objects.filter(filial__in=filiais, status__in=STATUS_EFETIVAVEIS)
        .exclude(pk__in=ja_efetivadas)
        .select_related("fornecedor", "categoria", "comprador", "filial")
        .order_by("data", "pk")
    )


def _notificar_efetivadores(provisao, aprovador) -> None:
    """Aprovação final: avisa quem pode efetivar (Gerente/Financeiro da
    filial, exceto quem aprovou) com o link direto para a timeline, onde
    fica o botão "Efetivar Provisão"."""
    from django.urls import reverse

    from core.permissions import usuario_tem_permissao
    from usuarios.models import filiais_autorizadas_para

    link = reverse("gestao_compras:provisao_timeline", args=[provisao.pk])
    candidatos = Usuario.objects.filter(
        empresa=provisao.empresa, is_active=True,
        perfil__in=(Usuario.Perfil.GERENTE, Usuario.Perfil.FINANCEIRO),
    ).exclude(pk=getattr(aprovador, "pk", None))
    for usuario in candidatos:
        if not usuario_tem_permissao(usuario, "provisoes.efetivar"):
            continue
        if not filiais_autorizadas_para(usuario, provisao.empresa).filter(pk=provisao.filial_id).exists():
            continue
        notificar(
            usuario, Notificacao.Tipo.MUDANCA_STATUS, "Provisão aprovada — aguardando efetivação",
            f"{provisao.fornecedor.nome} — {formatar_moeda(provisao.valor_total, incluir_prefixo=True)} "
            f"({provisao.data:%d/%m/%Y}). Quando o pedido for fechado, efetive-a em Compra.",
            link, provisao.empresa, chave=f"efetivar:{provisao.pk}:{usuario.pk}",
        )


def obter_calendario_mensal(filial, ano: int, mes: int) -> list[dict]:
    """Monta o Calendário Inteligente do mês: saldo, valor provisionado,
    quantidade de provisões e as próprias provisões de cada dia (item 5).

    Reaproveita `MotorFinanceiro.calcular_posicoes_do_mes` (Sprint 3) para
    obter a posição de TODOS os dias em uma única passada, em vez de chamar
    `obter_saldo_do_dia` dia a dia — o mês inteiro sai em ~6 consultas, não
    ~4 por dia (ver Arquitetura.md, seção de performance).
    """
    posicoes = motor_financeiro.calcular_posicoes_do_mes(filial, ano, mes)
    provisionado_por_dia = _somar_provisionado_por_dia(filial, ano, mes)
    provisoes_por_dia = agrupar_provisoes_do_mes(filial, ano, mes)
    hoje = date.today()

    dias = []
    for posicao in posicoes:
        provisionado, quantidade = provisionado_por_dia.get(posicao.data.day, (ZERO, 0))
        ja_comprometido = posicao.comprado + provisionado
        saldo_disponivel = posicao.limite_efetivo - ja_comprometido

        dias.append(
            {
                "dia": posicao.data.day,
                "data": posicao.data,
                "hoje": posicao.data == hoje,
                "limite_efetivo": posicao.limite_efetivo,
                "comprado": posicao.comprado,
                "provisionado": provisionado,
                "saldo_disponivel": saldo_disponivel,
                # Negativo nunca aparece como "saldo de R$ -X" para quem
                # compra: as telas mostram "excedido em R$ X".
                "excedido_em": -saldo_disponivel if saldo_disponivel < ZERO else ZERO,
                "quantidade_provisoes": quantidade,
                "cor": classificar_consumo(ja_comprometido, posicao.limite_efetivo),
                "provisoes": provisoes_por_dia.get(posicao.data.day, []),
                # Showcase (Seção 9): o template do Calendário de Compras
                # sempre leu `dia.tipo_dia` para pintar feriado/bloqueado de
                # cinza, mas a chave nunca era montada aqui (caía no default
                # "util") — o dia bloqueado zerava o limite porém nunca
                # aparecia cinza. O motor já resolve o tipo; só repassar.
                "tipo_dia": posicao.tipo_dia,
                # Crítico funcional (rodada 1): fim de semana (regra padrão),
                # feriado e bloqueio sem saldo herdado e sem nada lançado =
                # dia SEM compra prevista — neutro na tela, nunca "verde =
                # compra liberada" com limite zero.
                "sem_limite_proprio": posicao.sem_limite_proprio and ja_comprometido <= ZERO,
            }
        )
    return dias


def obter_provisoes_do_dia(filial, data_referencia: date):
    return (
        Provisao.objects.filter(filial=filial, data=data_referencia, status__in=STATUS_QUE_RESERVAM_SALDO)
        .select_related("fornecedor", "categoria", "comprador")
        .prefetch_related("itens")
    )


def contar_solicitacoes_pendentes(filiais, usuario=None) -> int:
    """Quantidade de Solicitações de Aprovação pendentes nas filiais dadas —
    usado pela Central de Decisão do Dashboard (Sprint 5).

    Com `usuario` (KPIs de quem DECIDE — Gerente/Financeiro): conta só as
    solicitações cuja etapa ATUAL esse usuário pode decidir
    (`usuario_pode_decidir_etapa`, a mesma regra que a view de aprovar
    aplica). Sem isso, num fluxo Gerente → Financeiro, o Financeiro via
    "1 pendente" de uma solicitação ainda na etapa do Gerente e, ao clicar
    em Aprovar, levava erro. Sem `usuario` (ex.: o Comprador, que só
    acompanha): todas as pendentes."""
    pendentes = SolicitacaoAprovacao.objects.filter(
        status=SolicitacaoAprovacao.Status.PENDENTE, provisao__filial__in=filiais
    )
    if usuario is None:
        return pendentes.count()
    return len(marcar_decidiveis(pendentes.select_related("etapa_atual"), usuario, somente_decidiveis=True))


def marcar_decidiveis(solicitacoes, usuario, *, somente_decidiveis: bool = False) -> list:
    """Marca cada solicitação com `pode_decidir` (o usuário pode decidir a
    etapa atual?) e `aguardando_rotulo` (quem decide agora, para quem não
    pode: "Financeiro (etapa 2)"). Fonte única para a fila de aprovação, a
    Central de Aprovações e os KPIs — o botão "Decidir" só aparece onde a
    decisão de fato é aceita (mesmo princípio de "gate do link = gate da
    view")."""
    marcadas = []
    for solicitacao in solicitacoes:
        solicitacao.pode_decidir = usuario_pode_decidir_etapa(usuario, solicitacao)
        etapa = solicitacao.etapa_atual if solicitacao.etapa_atual_id else None
        if etapa is None:
            solicitacao.aguardando_rotulo = ""
        else:
            quem = etapa.get_perfil_aprovador_display()
            if etapa.aprovador_id:
                aprovador = etapa.aprovador
                quem = aprovador.get_full_name() or aprovador.username
            solicitacao.aguardando_rotulo = f"{quem} (etapa {etapa.ordem})"
        if solicitacao.pode_decidir or not somente_decidiveis:
            marcadas.append(solicitacao)
    return marcadas


def obter_ultimas_provisoes(filial, limite: int = 5):
    """Últimas Provisões lançadas na filial (Sprint 5 — painel lateral)."""
    return (
        Provisao.objects.filter(filial=filial)
        .select_related("fornecedor", "categoria")
        .order_by("-criado_em")[:limite]
    )


DECISOES_JA_TOMADAS = (
    SolicitacaoAprovacao.Status.APROVADA,
    SolicitacaoAprovacao.Status.REJEITADA,
    SolicitacaoAprovacao.Status.AJUSTES_SOLICITADOS,
)


def obter_ultimas_decisoes(filial, limite: int = 5):
    """Últimas Solicitações de Aprovação já decididas (aprovadas, rejeitadas
    ou com ajustes solicitados) na filial (Sprint 5 — painel lateral;
    Sprint 6 incluiu "Ajustes Solicitados" no filtro)."""
    return (
        SolicitacaoAprovacao.objects.filter(provisao__filial=filial, status__in=DECISOES_JA_TOMADAS)
        .exclude(decidido_em__isnull=True)
        .select_related("provisao", "provisao__fornecedor", "decidido_por")
        .order_by("-decidido_em")[:limite]
    )


def obter_fornecedor_provisao_acima_do_historico(filial) -> Optional[str]:
    """Compara a Provisão mais recente da filial com a média histórica do
    mesmo fornecedor (excluindo ela própria) e devolve o nome do
    fornecedor se o valor atual superar 50% da média — insight puramente
    informativo para a Central de Decisão (Demo Experience 1.0, item 12),
    sem nenhum efeito sobre aprovação/bloqueio de nada. Devolve None se não
    houver dado suficiente para comparar."""
    ultima = (
        Provisao.objects.filter(filial=filial, status__in=STATUS_QUE_RESERVAM_SALDO)
        .select_related("fornecedor")
        .order_by("-criado_em")
        .first()
    )
    if ultima is None:
        return None
    media = (
        Provisao.objects.filter(filial=filial, fornecedor=ultima.fornecedor, status__in=STATUS_QUE_RESERVAM_SALDO)
        .exclude(pk=ultima.pk)
        .aggregate(media=Avg("valor_total"))["media"]
    )
    if not media or media <= ZERO:
        return None
    if ultima.valor_total > media * Decimal("1.5"):
        return ultima.fornecedor.nome
    return None


def contar_provisoes_previstas_para(filial, data_referencia: date) -> int:
    """Quantidade de Provisões já lançadas para uma data futura específica
    (ex.: amanhã) — usado pela Central de Decisão para avisar sobre
    compras já previstas (Demo Experience 1.0, item 12)."""
    return Provisao.objects.filter(filial=filial, data=data_referencia, status__in=STATUS_QUE_RESERVAM_SALDO).count()


def _correlation_id_provisao(provisao: Provisao) -> str:
    """Gate pré-Etapa 10 (S1-3): identificador de correlação DERIVADO do
    PK da Provisão (sem coluna nova) — estável e reproduzível em qualquer
    ponto do ciclo de vida dela (criação, aprovação, rejeição, ajustes,
    efetivação em Compra e geração das Parcelas), então filtrar a Central
    de Auditoria por este valor reconstrói a cadeia inteira."""
    return f"provisao-{provisao.pk}"


def registrar_historico(provisao: Provisao, usuario, acao: str, detalhe: str = "") -> HistoricoProvisao:
    return HistoricoProvisao.objects.create(provisao=provisao, usuario=usuario, acao=acao, detalhe=detalhe)


def criar_provisao(
    *, filial, comprador, fornecedor, categoria, data_provisao: date, observacoes: str, itens_dados: list[dict],
):
    """Cria a Provisão e seus itens (item 6). Se o valor total ultrapassar o
    saldo disponível do dia, a Provisão NÃO é liberada automaticamente —
    fica 'Aguardando Aprovação' e uma Solicitação de Aprovação é criada
    (item 4). Devolve (provisao, solicitacao_ou_None, excedeu: bool).

    Sprint de Correções Críticas (Seção 11): revalida no SERVICE que a
    filial pertence ao conjunto de filiais autorizadas do comprador — o
    form já restringe a queryset, mas o service não pode confiar cegamente
    no que foi submetido (defesa em profundidade).

    Sprint de Correções Críticas (Seção 14): a decisão "excede o saldo do
    dia?" e a criação da Provisão rodam dentro de uma transação com a
    Filial bloqueada — sem isso, duas provisões concorrentes na mesma
    filial/dia poderiam ler o mesmo saldo disponível e, juntas, reservar
    mais do que existe (nenhuma delas sozinha excede)."""
    from django.core.exceptions import PermissionDenied
    from django.db import transaction

    from filiais.models import Filial
    from usuarios.models import filiais_autorizadas_para

    if filial not in filiais_autorizadas_para(comprador, filial.empresa):
        raise PermissionDenied("Você não está autorizado a criar provisões nesta filial.")

    with transaction.atomic():
        Filial.objects.select_for_update().get(pk=filial.pk)

        saldo_info = obter_saldo_do_dia(filial, data_provisao)

        # Revisão adversarial (Fechamento Final, Seção 8): quantize por item
        # (mesma regra de `ItemProvisao.save()`) ANTES de somar — sem isso,
        # este total cru podia divergir por frações de centavo do
        # `provisao.valor_total` que de fato fica persistido
        # (`recalcular_valor_total`, abaixo), fazendo o gate "excedeu o
        # saldo do dia?" decidir sobre um número diferente do que a
        # Provisão realmente reserva.
        valor_total_novo = sum(
            (
                (Decimal(item["quantidade"]) * Decimal(item["valor_unitario"])).quantize(Decimal("0.01"))
                for item in itens_dados
            ),
            ZERO,
        )
        excedeu = valor_total_novo > saldo_info["saldo_disponivel"]

        provisao = Provisao.objects.create(
            empresa=filial.empresa,
            filial=filial,
            comprador=comprador,
            fornecedor=fornecedor,
            categoria=categoria,
            data=data_provisao,
            observacoes=observacoes,
            status=Provisao.Status.AGUARDANDO_APROVACAO if excedeu else Provisao.Status.PROVISIONADA,
        )
        for item in itens_dados:
            ItemProvisao.objects.create(
                provisao=provisao,
                produto=item["produto"],
                quantidade=item["quantidade"],
                valor_unitario=item["valor_unitario"],
            )
        provisao.recalcular_valor_total()

        registrar_historico(
            provisao, comprador, HistoricoProvisao.Acao.CRIACAO,
            f"Provisão criada com valor total {formatar_moeda(provisao.valor_total, incluir_prefixo=True)}.",
        )
        # Gate pré-Etapa 10 (S1-3): `correlation_id` derivado do PK da
        # Provisão (nenhuma coluna nova) — todos os eventos do MESMO
        # fluxo (aprovação, rejeição, efetivação, Compra e Parcelas
        # geradas) reusam este mesmo identificador.
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.PROVISAO_CRIADA,
            descricao=f"Provisão criada — {fornecedor.nome} ({formatar_moeda(provisao.valor_total, incluir_prefixo=True)}).",
            empresa=filial.empresa, filial=filial, usuario=comprador,
            modulo="provisoes", acao="criar", resultado=RegistroAuditoria.Resultado.SUCESSO,
            tipo_objeto="Provisao", id_objeto=provisao.pk,
            estado_depois={"status": provisao.status, "valor_total": str(provisao.valor_total)},
            correlation_id=_correlation_id_provisao(provisao),
        )

        solicitacao = None
        if excedeu:
            excedente = provisao.valor_total - saldo_info["saldo_disponivel"]

            # Épico 8 (CORE 1.0): com um Fluxo de Aprovação ativo na empresa, a
            # solicitação nasce na primeira etapa dele; sem fluxo, `fluxo` e
            # `etapa_atual` ficam nulos e vale a decisão em etapa única de
            # sempre (nenhum comportamento existente muda).
            fluxo = FluxoAprovacao.objects.filter(empresa=filial.empresa, ativo=True).first()
            primeira_etapa = fluxo.etapas_ordenadas().first() if fluxo else None

            solicitacao = SolicitacaoAprovacao.objects.create(
                provisao=provisao,
                solicitado_por=comprador,
                saldo_disponivel_no_pedido=saldo_info["saldo_disponivel"],
                valor_excedente=excedente,
                fluxo=fluxo if primeira_etapa else None,
                etapa_atual=primeira_etapa,
            )
            detalhe_solicitacao = f"Ultrapassou o saldo disponível do dia em {formatar_moeda(excedente, incluir_prefixo=True)}."
            if primeira_etapa:
                detalhe_solicitacao += (
                    f' Encaminhada ao fluxo "{fluxo.nome}", etapa {primeira_etapa.ordem} '
                    f"({primeira_etapa.get_perfil_aprovador_display()})."
                )
            registrar_historico(provisao, comprador, HistoricoProvisao.Acao.SOLICITACAO_APROVACAO, detalhe_solicitacao)

    if solicitacao is not None:
        _notificar_aprovadores_da_solicitacao(solicitacao, comprador)

    return provisao, solicitacao, excedeu


def usuario_pode_decidir_etapa(usuario, solicitacao: SolicitacaoAprovacao) -> bool:
    """Épico 8: quem pode decidir a etapa ATUAL de uma solicitação.

    Deliberadamente NÃO trata autoaprovação aqui — esta função é usada
    também por `rejeitar`/`solicitar_ajustes` (view), onde rejeitar/pedir
    ajustes na própria solicitação não concede nada a quem solicitou e
    continua permitido (Fechamento Final, Seção 6). O bloqueio de
    autoaprovação vive só em `_bloquear_autoaprovacao`, chamado
    explicitamente por quem decide APROVAR (view e service).

    Sem fluxo/etapa (o caso histórico), qualquer aprovador liberado pela
    view pode decidir (True). Com etapa: o perfil aprovador dela, o
    aprovador específico, o substituto, o superusuário — e o Proprietário,
    que sempre pode decidir (evita um fluxo mal configurado travar a
    operação da empresa sem ninguém apto a destravar)."""
    if solicitacao.etapa_atual_id is None:
        return True
    if usuario is None:
        return False
    if usuario.is_superuser or usuario.perfil == Usuario.Perfil.PROPRIETARIO:
        return True
    etapa = solicitacao.etapa_atual
    if usuario.perfil == etapa.perfil_aprovador:
        return True
    return usuario.pk in (etapa.aprovador_id, etapa.substituto_id)


def autoaprovacao_bloqueada(usuario, solicitacao: SolicitacaoAprovacao) -> bool:
    """Fechamento Final (Prompt 1, Seção 6) — "autoaprovação controlada":
    True quando `usuario` é quem SOLICITOU esta aprovação e a empresa não
    ligou `ConfiguracaoPlataforma.permitir_autoaprovacao` — nem sendo
    Proprietário ou superusuário (a regra é sobre a mesma pessoa em papéis
    diferentes, não sobre hierarquia). Só se aplica a quem está tentando
    APROVAR — rejeitar/pedir ajustes na própria solicitação não concede
    nada a mais, então não é bloqueado por esta checagem."""
    if usuario is None:
        return False
    return solicitacao.solicitado_por_id == usuario.pk and not autoaprovacao_controlada_permitida(
        solicitacao.provisao.empresa
    )


def _notificar_aprovadores_da_solicitacao(solicitacao: SolicitacaoAprovacao, solicitante) -> None:
    """Avisa quem pode decidir a etapa atual (ou os 3 perfis aprovadores,
    no modo de etapa única) que existe uma solicitação aguardando."""
    provisao = solicitacao.provisao
    empresa = provisao.empresa
    titulo = "Provisão aguardando aprovação"
    mensagem = (
        f"{provisao.fornecedor.nome} — {formatar_moeda(provisao.valor_total, incluir_prefixo=True)} "
        f"({provisao.data:%d/%m/%Y})"
    )
    link = "/gestao-compras/aprovacao/"
    etapa = solicitacao.etapa_atual
    if etapa is not None:
        perfis = (etapa.perfil_aprovador,)
        notificar_perfis(
            empresa, perfis, Notificacao.Tipo.SOLICITACAO_LIMITE, titulo, mensagem, link,
            excluir_usuario=solicitante,
        )
        for extra in (etapa.aprovador, etapa.substituto):
            if extra is not None and extra.perfil not in perfis:
                notificar(extra, Notificacao.Tipo.SOLICITACAO_LIMITE, titulo, mensagem, link, empresa)
    else:
        notificar_perfis(
            empresa,
            (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.GERENTE, Usuario.Perfil.FINANCEIRO),
            Notificacao.Tipo.SOLICITACAO_LIMITE, titulo, mensagem, link,
            excluir_usuario=solicitante,
        )


class SolicitacaoNaoDecidivelError(Exception):
    """A Solicitação de Aprovação não está mais Pendente (já decidida por
    outra requisição) ou o usuário não decide mais a etapa atual dela."""


class MotorAprovacaoProvisao:
    """Decide o destino de uma Solicitação de Aprovação de Provisão (item
    4). A checagem de quem PODE chamar estes métodos (Proprietário, Gerente
    ou Financeiro) é feita na view via `core.permissions` — este serviço
    assume que a permissão já foi validada.

    Épico 8 (CORE 1.0): quando a solicitação pertence a um Fluxo de
    Aprovação, `aprovar` percorre as etapas por alçada — a aprovação de uma
    etapa é FINAL se a alçada dela cobre o valor (ou se não há próxima
    etapa); caso contrário, a solicitação avança para a etapa seguinte e a
    Provisão continua aguardando. Rejeitar/Solicitar Ajustes encerram o
    fluxo em qualquer etapa, com o efeito de sempre.

    Sprint de Correções Críticas (Seção 14): os três métodos de decisão
    recarregam a Solicitação com `select_for_update` e revalidam o status
    DENTRO da transação (`aprovar` também revalida `usuario_pode_decidir_
    etapa`, já que só ele depende de qual etapa está atual — ver nota no
    próprio método) — a view já filtra por `status=PENDENTE` e checa a
    etapa antes de chamar estes métodos, mas entre esse filtro e a
    gravação existe uma janela: duplo clique, duas abas, ou dois
    aprovadores decidindo ao mesmo tempo. Sem a revalidação pós-lock, isso
    podia aprovar E rejeitar a mesma solicitação (dois históricos
    contraditórios) ou aplicar uma aprovação à etapa ERRADA (se ela avançou
    entre o carregamento e a gravação)."""

    def _proxima_etapa(self, solicitacao: SolicitacaoAprovacao):
        """Próxima etapa a percorrer, ou None quando a decisão da etapa
        atual é final (alçada suficiente ou fim do fluxo)."""
        etapa = solicitacao.etapa_atual
        if etapa is None or solicitacao.fluxo_id is None:
            return None
        valor = solicitacao.provisao.valor_total
        if etapa.valor_maximo is None or valor <= etapa.valor_maximo:
            return None  # alçada cobre o valor — decisão final
        return solicitacao.fluxo.etapas_ordenadas().filter(ordem__gt=etapa.ordem).first()

    def _recarregar_e_travar(self, solicitacao: SolicitacaoAprovacao) -> SolicitacaoAprovacao:
        solicitacao = SolicitacaoAprovacao.objects.select_for_update().select_related(
            "provisao", "provisao__fornecedor", "provisao__comprador", "provisao__empresa",
            "fluxo", "etapa_atual",
        ).get(pk=solicitacao.pk)
        if solicitacao.status != SolicitacaoAprovacao.Status.PENDENTE:
            raise SolicitacaoNaoDecidivelError(
                f"Esta solicitação já foi decidida — está \"{solicitacao.get_status_display()}\"."
            )
        return solicitacao

    def aprovar(self, solicitacao: SolicitacaoAprovacao, usuario, justificativa: str = "") -> Provisao:
        """Aprovar respeita a alçada da etapa ATUAL — por isso, diferente
        de rejeitar/solicitar_ajustes (que valem em qualquer etapa, ver
        docstring da classe), revalida `usuario_pode_decidir_etapa` aqui
        DENTRO do lock: se a etapa avançou entre o carregamento na view e a
        gravação, a decisão de quem só era autorizado na etapa ANTERIOR não
        pode ser aplicada à nova.

        Fechamento Final (Seção 6): revalida também `autoaprovacao_bloqueada`
        aqui dentro — defesa em profundidade além da checagem já feita na
        view, para quem chamar este service diretamente nunca conseguir
        aprovar a própria solicitação."""
        from django.db import transaction

        with transaction.atomic():
            solicitacao = self._recarregar_e_travar(solicitacao)
            if autoaprovacao_bloqueada(usuario, solicitacao):
                raise SolicitacaoNaoDecidivelError(
                    "Você não pode aprovar a própria solicitação — peça para outra pessoa aprovar, ou "
                    "habilite a autoaprovação controlada em Configurações Gerais (com justificativa)."
                )
            if not usuario_pode_decidir_etapa(usuario, solicitacao):
                raise SolicitacaoNaoDecidivelError(
                    "A etapa atual desta solicitação mudou e não é mais decidida por este usuário."
                )
            provisao = solicitacao.provisao
            # Gate pré-Etapa 10 (S1-3, item 6): "autoaprovação destacada" —
            # true quando quem decide é a MESMA pessoa que solicitou (só
            # chega até aqui se a config da empresa permite; o bloqueio
            # já aconteceu acima, em `autoaprovacao_bloqueada`).
            eh_autoaprovacao = solicitacao.solicitado_por_id == usuario.pk
            origem = RegistroAuditoria.OrigemDecisao.AUTOMATICA if eh_autoaprovacao else RegistroAuditoria.OrigemDecisao.MANUAL
            proxima = self._proxima_etapa(solicitacao)
            if proxima is not None:
                etapa_atual = solicitacao.etapa_atual
                solicitacao.etapa_atual = proxima
                solicitacao.save(update_fields=["etapa_atual", "atualizado_em"])
                registrar_historico(
                    provisao, usuario, HistoricoProvisao.Acao.APROVACAO,
                    f"Etapa {etapa_atual.ordem} ({etapa_atual.get_perfil_aprovador_display()}) aprovada"
                    f"{' — ' + justificativa if justificativa else ''}. "
                    f"Valor acima da alçada — encaminhada à etapa {proxima.ordem} "
                    f"({proxima.get_perfil_aprovador_display()}).",
                )
                registrar_evento(
                    categoria=RegistroAuditoria.Categoria.PROVISAO_APROVADA,
                    descricao=(
                        f"Etapa {etapa_atual.ordem} ({etapa_atual.get_perfil_aprovador_display()}) aprovada — "
                        f"encaminhada à etapa {proxima.ordem} ({proxima.get_perfil_aprovador_display()})."
                    ),
                    empresa=provisao.empresa, filial=provisao.filial, usuario=usuario,
                    modulo="provisoes", acao="aprovar_etapa", resultado=RegistroAuditoria.Resultado.PENDENTE,
                    tipo_objeto="Provisao", id_objeto=provisao.pk, justificativa=justificativa,
                    origem_decisao=origem, autoaprovacao=eh_autoaprovacao,
                    correlation_id=_correlation_id_provisao(provisao),
                )
                _notificar_aprovadores_da_solicitacao(solicitacao, usuario)
                return provisao

            estado_antes = {"status": provisao.status}
            solicitacao.status = SolicitacaoAprovacao.Status.APROVADA
            solicitacao.decidido_por = usuario
            solicitacao.decidido_em = timezone.now()
            solicitacao.justificativa = justificativa
            solicitacao.save()

            provisao.status = Provisao.Status.APROVADA
            provisao.save(update_fields=["status", "atualizado_em"])

            registrar_historico(
                provisao, usuario, HistoricoProvisao.Acao.APROVACAO,
                justificativa or "Aprovada sem justificativa adicional.",
            )
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.PROVISAO_APROVADA,
                descricao=f"Provisão aprovada — {provisao.fornecedor.nome} ({formatar_moeda(provisao.valor_total, incluir_prefixo=True)}).",
                empresa=provisao.empresa, filial=provisao.filial, usuario=usuario,
                modulo="provisoes", acao="aprovar", resultado=RegistroAuditoria.Resultado.SUCESSO,
                tipo_objeto="Provisao", id_objeto=provisao.pk,
                estado_antes=estado_antes, estado_depois={"status": provisao.status},
                justificativa=justificativa, origem_decisao=origem, autoaprovacao=eh_autoaprovacao,
                correlation_id=_correlation_id_provisao(provisao),
            )
            # Rodada final: a notificação da aprovação final aponta para a
            # timeline da provisão (antes, para o calendário genérico).
            from django.urls import reverse

            notificar(
                provisao.comprador, Notificacao.Tipo.MUDANCA_STATUS, "Provisão aprovada",
                f"{provisao.fornecedor.nome} — {formatar_moeda(provisao.valor_total, incluir_prefixo=True)} foi aprovada.",
                reverse("gestao_compras:provisao_timeline", args=[provisao.pk]), provisao.empresa,
            )
            _notificar_efetivadores(provisao, usuario)
            return provisao

    def rejeitar(self, solicitacao: SolicitacaoAprovacao, usuario, justificativa: str) -> Provisao:
        from django.db import transaction

        with transaction.atomic():
            solicitacao = self._recarregar_e_travar(solicitacao)
            solicitacao.status = SolicitacaoAprovacao.Status.REJEITADA
            solicitacao.decidido_por = usuario
            solicitacao.decidido_em = timezone.now()
            solicitacao.justificativa = justificativa
            solicitacao.save()

            provisao = solicitacao.provisao
            estado_antes = {"status": provisao.status}
            provisao.status = Provisao.Status.CANCELADA
            provisao.save(update_fields=["status", "atualizado_em"])

            registrar_historico(provisao, usuario, HistoricoProvisao.Acao.REJEICAO, justificativa)
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.PROVISAO_REJEITADA,
                descricao=f"Provisão rejeitada — {provisao.fornecedor.nome}: {justificativa}",
                empresa=provisao.empresa, filial=provisao.filial, usuario=usuario,
                # Gate D (Prompt 2, Seção 10): rejeição concluída com
                # sucesso é resultado SUCESSO — "falha" é só para operação
                # que não se completou.
                modulo="provisoes", acao="rejeitar", resultado=RegistroAuditoria.Resultado.SUCESSO,
                tipo_objeto="Provisao", id_objeto=provisao.pk,
                estado_antes=estado_antes, estado_depois={"status": provisao.status},
                justificativa=justificativa, correlation_id=_correlation_id_provisao(provisao),
            )
            notificar(
                provisao.comprador, Notificacao.Tipo.MUDANCA_STATUS, "Provisão rejeitada",
                f"{provisao.fornecedor.nome} — {formatar_moeda(provisao.valor_total, incluir_prefixo=True)}: {justificativa}",
                "/gestao-compras/", provisao.empresa,
            )
            return provisao

    def solicitar_ajustes(self, solicitacao: SolicitacaoAprovacao, usuario, justificativa: str) -> Provisao:
        """Devolve a solicitação ao comprador pedindo ajustes, em vez de
        aprovar ou rejeitar de vez (Sprint 6, item 5). `justificativa` é
        obrigatória (validada na view) — é o que o comprador precisa saber
        para corrigir e lançar uma nova Provisão.

        Hoje isso cancela a Provisão atual (edição de Provisão já criada
        ainda não existe — ver `SPRINT05.md`, "Limitações conhecidas"), mas
        registra uma ação e um status DISTINTOS de "Rejeitada", para que o
        comprador entenda que não foi um "não" definitivo. Não é uma
        gambiarra simulando reedição: é o mesmo efeito de dados de uma
        rejeição, com semântica e histórico próprios — a base certa para
        uma Sprint futura implementar a reedição de verdade sem precisar
        mudar este contrato."""
        from django.db import transaction

        with transaction.atomic():
            solicitacao = self._recarregar_e_travar(solicitacao)
            solicitacao.status = SolicitacaoAprovacao.Status.AJUSTES_SOLICITADOS
            solicitacao.decidido_por = usuario
            solicitacao.decidido_em = timezone.now()
            solicitacao.justificativa = justificativa
            solicitacao.save()

            provisao = solicitacao.provisao
            estado_antes = {"status": provisao.status}
            provisao.status = Provisao.Status.CANCELADA
            provisao.save(update_fields=["status", "atualizado_em"])

            registrar_historico(provisao, usuario, HistoricoProvisao.Acao.AJUSTES_SOLICITADOS, justificativa)
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.PROVISAO_AJUSTES,
                descricao=f"Ajustes solicitados na Provisão — {provisao.fornecedor.nome}: {justificativa}",
                empresa=provisao.empresa, filial=provisao.filial, usuario=usuario,
                # Gate D (Prompt 2, Seção 10): pedir ajustes é uma decisão
                # de negócio válida e concluída — SUCESSO, não FALHA.
                modulo="provisoes", acao="solicitar_ajustes", resultado=RegistroAuditoria.Resultado.SUCESSO,
                tipo_objeto="Provisao", id_objeto=provisao.pk,
                estado_antes=estado_antes, estado_depois={"status": provisao.status},
                justificativa=justificativa, correlation_id=_correlation_id_provisao(provisao),
            )
            notificar(
                provisao.comprador, Notificacao.Tipo.MUDANCA_STATUS, "Ajustes solicitados na provisão",
                f"{provisao.fornecedor.nome} — {formatar_moeda(provisao.valor_total, incluir_prefixo=True)}: {justificativa}",
                "/gestao-compras/", provisao.empresa,
            )
            return provisao


motor_aprovacao_provisao = MotorAprovacaoProvisao()


# ---------------------------------------------------------------------------
# Provisão → Compra (Sprint de Correções Críticas — Seção 12)
#
# Até esta Sprint, `Provisao.Status.EFETIVADA` existia no enum mas nunca era
# alcançado — não havia NENHUMA ligação entre uma Provisão aprovada e uma
# Compra real (achado crítico da auditoria funcional). `efetivar_provisao` é
# o único caminho que cria essa ligação (`Compra.provisao_origem`); a ação
# "Efetivar Provisão" da tela chama exatamente esta função — sem lógica
# própria de criação de Compra na view.
# ---------------------------------------------------------------------------


class ProvisaoNaoEfetivavelError(Exception):
    """A Provisão informada não está num estado que permite efetivação."""


def efetivar_provisao(
    *, provisao_id, usuario, prazo_pagamento, prazo_personalizado_dias=None, numero_parcelas=1,
):
    """Transforma uma Provisão APROVADA num compromisso real: cria a Compra
    vinculada, gera as parcelas do prazo escolhido e move a Provisão para
    EFETIVADA. Devolve (compra, ja_efetivada: bool).

    Pensada para também poder ser chamada, futuramente, pelo matching
    automático do DDA (Seção 12 — "NÃO implementar DDA... mas service
    preparado para ser chamado futuramente") — por isso recebe `usuario`
    explicitamente em vez de assumir uma sessão HTTP, e é IDEMPOTENTE: uma
    segunda chamada para a mesma Provisão já efetivada não cria uma segunda
    Compra nem erra — devolve a Compra existente com `ja_efetivada=True`.

    Transação + lock (Seção 12/14): a Provisão é bloqueada
    (`select_for_update`) e revalidada DENTRO da transação — dois cliques
    simultâneos no botão "Efetivar" (ou o clique concorrendo com uma futura
    chamada automática do DDA) nunca geram duas Compras para a mesma
    Provisão; o segundo sempre enxerga o estado já mudado pelo primeiro."""
    from django.core.exceptions import PermissionDenied
    from django.db import transaction

    from compras.models import Compra, HistoricoCompra
    from compras.services import calcular_numero_parcelas, gerar_parcelas_da_compra, registrar_historico_compra
    from usuarios.models import filiais_autorizadas_para

    with transaction.atomic():
        provisao = Provisao.objects.select_for_update().select_related(
            "empresa", "filial", "fornecedor", "categoria"
        ).get(pk=provisao_id)

        # Idempotência primeiro: uma Provisão já efetivada não tem mais
        # status Aprovada (virou Efetivada), então esta checagem TEM que vir
        # antes da validação de status abaixo — senão uma segunda chamada
        # legítima (retry do DDA, duplo clique que perdeu a corrida) cairia
        # no ramo de erro em vez de devolver a Compra já criada.
        compra_existente = Compra.objects.filter(provisao_origem=provisao).first()
        if compra_existente is not None:
            return compra_existente, True

        if provisao.status not in STATUS_EFETIVAVEIS:
            raise ProvisaoNaoEfetivavelError(
                f"Só é possível efetivar Provisões Provisionadas ou Aprovadas — esta está "
                f"\"{provisao.get_status_display()}\"."
            )

        if provisao.filial not in filiais_autorizadas_para(usuario, provisao.empresa):
            raise PermissionDenied("Você não está autorizado a efetivar provisões desta filial.")

        # A Compra é DO COMPRADOR que planejou a Provisão, não de quem clicou
        # em "Efetivar" (em geral o Financeiro): é `Compra.usuario` que alimenta
        # o relatório "Compras por Comprador", a coluna Comprador de
        # Parcelamentos, o Histórico de Compras do comprador e a dotação
        # individual (`total_comprado_no_dia_pelo_usuario`). Quem efetivou
        # continua registrado no HistoricoCompra/HistoricoProvisao e na
        # auditoria abaixo.
        compra = Compra.objects.create(
            empresa=provisao.empresa,
            filial=provisao.filial,
            fornecedor=provisao.fornecedor,
            usuario=provisao.comprador,
            valor=provisao.valor_total,
            categoria=provisao.categoria,
            data_compra=provisao.data,
            prazo_pagamento=prazo_pagamento,
            prazo_personalizado_dias=prazo_personalizado_dias,
            numero_parcelas=calcular_numero_parcelas(prazo_pagamento, numero_parcelas),
            status=Compra.Status.APROVADA,
            observacao=f"Efetivada a partir da Provisão #{provisao.pk} ({provisao.fornecedor.nome}).",
            provisao_origem=provisao,
        )
        gerar_parcelas_da_compra(compra)
        registrar_historico_compra(
            compra, usuario, HistoricoCompra.Acao.CRIACAO,
            f"Compra criada pela efetivação da Provisão #{provisao.pk}.",
        )

        provisao.status = Provisao.Status.EFETIVADA
        provisao.save(update_fields=["status", "atualizado_em"])
        registrar_historico(
            provisao, usuario, HistoricoProvisao.Acao.EFETIVACAO,
            f"Provisão efetivada — Compra #{compra.pk} criada "
            f"({formatar_moeda(compra.valor, incluir_prefixo=True)}, prazo "
            f"{compra.get_prazo_pagamento_display()}).",
        )
        # Gate pré-Etapa 10 (S1-3, item 6): reusa o MESMO `correlation_id`
        # da Provisão (`_correlation_id_provisao`) — filtrar por ele na
        # Central de Auditoria mostra a cadeia completa Provisão → Compra
        # → Parcelas (a contagem/valor das parcelas já geradas entra no
        # `estado_depois`, sem precisar de um evento por parcela).
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.PROVISAO_EFETIVADA,
            descricao=f"Provisão efetivada em Compra #{compra.pk} — {compra.parcelas.count()} parcela(s).",
            empresa=provisao.empresa, filial=provisao.filial, usuario=usuario,
            modulo="provisoes", acao="efetivar", resultado=RegistroAuditoria.Resultado.SUCESSO,
            tipo_objeto="Provisao", id_objeto=provisao.pk,
            estado_depois={
                "status": provisao.status, "compra_id": compra.pk,
                "compra_valor": str(compra.valor), "parcelas": compra.parcelas.count(),
            },
            correlation_id=_correlation_id_provisao(provisao),
        )
        # Prompt 2 (pré-Etapa 02), Gate D (Seção 10): o evento acima cobre a
        # efetivação DA PROVISÃO; a Compra nascida dela também precisa do
        # PRÓPRIO evento (não só aparecer citada no `estado_depois` alheio),
        # apontando de volta para a Provisão de origem e informando
        # IDs/quantidade/soma das parcelas geradas — mesmo `correlation_id`
        # da Provisão, para a Central de Auditoria reconstruir a cadeia
        # completa Provisão → Compra → Parcelas num único filtro.
        parcelas_geradas = list(compra.parcelas.order_by("numero"))
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.COMPRA_LANCADA,
            descricao=f"Compra criada pela efetivação da Provisão #{provisao.pk}.",
            empresa=provisao.empresa, filial=provisao.filial, usuario=usuario,
            modulo="compras", acao="efetivar_provisao", resultado=RegistroAuditoria.Resultado.SUCESSO,
            tipo_objeto="Compra", id_objeto=compra.pk,
            estado_depois={
                "status": compra.status, "valor": str(compra.valor),
                "provisao_origem_id": provisao.pk,
                "parcelas": {
                    "quantidade": len(parcelas_geradas),
                    "ids": [p.pk for p in parcelas_geradas],
                    "soma": str(sum((p.valor for p in parcelas_geradas), Decimal("0"))),
                },
            },
            correlation_id=_correlation_id_provisao(provisao),
        )
        # Sprint de Correções Críticas (Seção 18): além do histórico próprio
        # da Provisão/Compra (visível na timeline delas), a efetivação
        # também entra no log CENTRALIZADO da empresa (mesmo lugar onde
        # ficam os demais eventos administrativos desta seção).
        from empresas.models import LogConfiguracao

        LogConfiguracao.objects.create(
            empresa=provisao.empresa, usuario=usuario, area="Gestão de Compras",
            descricao=(
                f"Provisão #{provisao.pk} ({provisao.fornecedor.nome}, {provisao.filial.nome}) efetivada — "
                f"Compra #{compra.pk} criada ({formatar_moeda(compra.valor, incluir_prefixo=True)})."
            ),
        )

    notificar_perfis(
        provisao.empresa, (Usuario.Perfil.FINANCEIRO,), Notificacao.Tipo.COMPRA_CRIADA,
        "Provisão efetivada em Compra",
        f"{provisao.fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)} "
        f"({provisao.data:%d/%m/%Y}).",
        "/financeiro/agenda/",
    )
    return compra, False
