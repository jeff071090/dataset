from datetime import date, timedelta
from decimal import Decimal

from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView

from auditoria.models import RegistroAuditoria
from auditoria.services import ip_do_request, registrar_evento
from compras.models import ParcelaCompra
from compras.services import estornar_parcela as estornar_parcela_service
from compras.services import marcar_parcela_paga
from core.contexto import empresa_ativa, filiais_do_contexto
from core.permissions import (
    PERFIS_GESTORES_FINANCEIROS,
    PerfilRequiredMixin,
    perfil_required,
    permissao_required,
    usuario_tem_permissao,
)
from core.relatorios import resposta_csv
from finance_engine.agenda import gerar_agenda
from finance_engine.calendario_operacional import mapa_tipos_do_mes
from usuarios.models import Usuario

from .forms import (
    ConfiguracaoFinanceiraForm,
    CustoFixoForm,
    CustoVariavelForm,
    DiaOperacionalForm,
    ReceitaExtraForm,
    ReceitaForm,
)
from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, DiaOperacional, Receita, ReceitaExtra
from .services import resumo_receitas_do_mes

PERFIS_VISUALIZACAO = PERFIS_GESTORES_FINANCEIROS
# Gate A (Prompt 2, pré-Etapa 02): Proprietário Operacional também cadastra
# Receita/Custo Fixo/Custo Variável — não é exclusivo do Financeiro.
PERFIS_CADASTRO = (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO)


MESES_PT_BR = (
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
)


def _competencia_do_request(request):
    """(ano, mes) pedidos na querystring (`?ano=2026&mes=9`), com defesa
    contra valor malformado (ex.: "2.026" vindo de um link formatado com
    separador de milhar) — cai no mês atual em vez de derrubar a tela."""
    hoje = date.today()
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
        if not 2000 <= ano <= 2100:
            raise ValueError
        date(ano, mes, 1)
    except (TypeError, ValueError, OverflowError):
        ano, mes = hoje.year, hoje.month
    return ano, mes


def _contexto_competencia(ano, mes):
    """Variáveis de navegação entre meses usadas pelas telas de Receitas."""
    hoje = date.today()
    return {
        "ano": ano,
        "mes": mes,
        "mes_referencia": date(ano, mes, 1),
        "mes_nome": f"{MESES_PT_BR[mes - 1]}/{ano}",
        "mes_anterior": (ano, mes - 1) if mes > 1 else (ano - 1, 12),
        "mes_seguinte": (ano, mes + 1) if mes < 12 else (ano + 1, 1),
        "e_mes_atual": (ano, mes) == (hoje.year, hoje.month),
        "meses_opcoes": list(enumerate(MESES_PT_BR, start=1)),
        "anos_opcoes": list(range(hoje.year - 3, hoje.year + 2)),
    }


class ReceitaListView(PerfilRequiredMixin, ListView):
    model = Receita
    template_name = "financeiro/receita_list.html"
    context_object_name = "receitas"
    perfis_permitidos = PERFIS_VISUALIZACAO

    def get_queryset(self):
        return Receita.objects.filter(filial__in=filiais_do_contexto(self.request)).select_related("filial")

    def get_context_data(self, **kwargs):
        """Mudança de escopo (lançamento manual): a tela de Receitas deixa
        explícitas as DUAS partes da receita do mês — receita mensal
        (faturamento) + receitas extras — e o total que alimenta o Motor.
        Os números vêm de `resumo_receitas_do_mes`, a mesma fonte do cálculo
        da capacidade e dos dashboards."""
        contexto = super().get_context_data(**kwargs)
        ano, mes = _competencia_do_request(self.request)
        filiais = list(filiais_do_contexto(self.request))
        contexto.update(_contexto_competencia(ano, mes))
        contexto["resumo_mes"] = resumo_receitas_do_mes(filiais, ano, mes)
        contexto["extras_do_mes"] = (
            ReceitaExtra.objects.filter(filial__in=filiais, data__year=ano, data__month=mes)
            .select_related("filial")
        )
        contexto["pode_cadastrar"] = self.request.user.perfil in PERFIS_CADASTRO
        contexto["mostra_coluna_filial"] = len(filiais) > 1
        return contexto


class ReceitaCreateView(PerfilRequiredMixin, CreateView):
    model = Receita
    form_class = ReceitaForm
    template_name = "financeiro/receita_form.html"
    success_url = reverse_lazy("financeiro:receita_list")
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Nova Receita"}

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def form_valid(self, form):
        # Gate 1 (Sprint de Encerramento Definitivo): objeto de negócio +
        # evento central na MESMA transação — se a auditoria falhar, a
        # Receita não pode ficar gravada sem rastro.
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.RECEITA_ALTERADA, "criar",
                f"Receita de {self.object.filial.nome} ({self.object.mes:%m/%Y}) cadastrada.",
                "Receita", self.object.pk,
                estado_depois={
                    "filial_id": self.object.filial_id, "mes": self.object.mes.isoformat(),
                    "faturamento": str(self.object.faturamento),
                },
            )
        messages.success(self.request, "Receita cadastrada com sucesso.")
        return resposta


class CustoFixoListView(PerfilRequiredMixin, ListView):
    model = CustoFixo
    template_name = "financeiro/custofixo_list.html"
    context_object_name = "custos"
    perfis_permitidos = PERFIS_VISUALIZACAO

    def get_queryset(self):
        return CustoFixo.objects.filter(filial__in=filiais_do_contexto(self.request)).select_related("filial")


class CustoFixoCreateView(PerfilRequiredMixin, CreateView):
    model = CustoFixo
    form_class = CustoFixoForm
    template_name = "financeiro/custofixo_form.html"
    success_url = reverse_lazy("financeiro:custofixo_list")
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Novo Custo Fixo"}

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def form_valid(self, form):
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO, "criar",
                f'Custo fixo "{self.object.descricao}" cadastrado.', "CustoFixo", self.object.pk,
                estado_depois={
                    "filial_id": self.object.filial_id, "descricao": self.object.descricao,
                    "valor": str(self.object.valor), "dia_vencimento": self.object.dia_vencimento,
                    "ativo": self.object.ativo,
                },
            )
        messages.success(self.request, "Custo fixo cadastrado com sucesso.")
        return resposta


class CustoVariavelListView(PerfilRequiredMixin, ListView):
    model = CustoVariavel
    template_name = "financeiro/custovariavel_list.html"
    context_object_name = "custos"
    perfis_permitidos = PERFIS_VISUALIZACAO
    # Sprint de Melhorias 1 (usabilidade): um ano de lançamentos numa página
    # só passava de 7 mil pixels de altura.
    paginate_by = 50

    def get_queryset(self):
        return CustoVariavel.objects.filter(filial__in=filiais_do_contexto(self.request)).select_related("filial")


class CustoVariavelCreateView(PerfilRequiredMixin, CreateView):
    model = CustoVariavel
    form_class = CustoVariavelForm
    template_name = "financeiro/custovariavel_form.html"
    success_url = reverse_lazy("financeiro:custovariavel_list")
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Novo Custo Variável"}

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def form_valid(self, form):
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.CUSTO_VARIAVEL_ALTERADO, "criar",
                f'Custo variável "{self.object.descricao}" cadastrado.', "CustoVariavel", self.object.pk,
                estado_depois={
                    "filial_id": self.object.filial_id, "descricao": self.object.descricao,
                    "valor": str(self.object.valor), "data_prevista": self.object.data_prevista.isoformat(),
                },
            )
        messages.success(self.request, "Custo variável cadastrado com sucesso.")
        return resposta


# --------------------------------------------------------------------------
# Editar/Desativar/Excluir (Sprint de Consolidação — Gate 2A, Parte 6):
# Receita e Custo Variável não têm campo `ativo` (são fatos pontuais — um
# faturamento de um mês, uma despesa avulsa — sem nada mais no sistema
# referenciando a linha), então "excluir com segurança" aqui é uma
# exclusão real, mas só via POST e com confirmação na tela. Custo Fixo já
# tinha `ativo`: soft-delete de verdade, igual Fornecedor/Categoria.
# --------------------------------------------------------------------------


def _registrar_log_financeiro(request, empresa, descricao, area="Contas Financeiras"):
    """Sprint de Correções Críticas (Seção 18): mesmo helper reaproveitado
    para as demais áreas do módulo financeiro que ainda não tinham
    auditoria (Calendário Operacional, Configuração Financeira) — só o
    rótulo da área muda, a estrutura do log é a mesma de sempre."""
    from empresas.models import LogConfiguracao

    LogConfiguracao.objects.create(empresa=empresa, usuario=request.user, area=area, descricao=descricao)


def _registrar_evento_financeiro(
    request, empresa, filial, categoria, acao, descricao, tipo_objeto, id_objeto,
    estado_antes=None, estado_depois=None,
):
    """Prompt 2 (pré-Etapa 02), Gate D (Seção 9): parceiro de
    `_registrar_log_financeiro`, escreve TAMBÉM na Central de Auditoria —
    os dois mecanismos convivem, nenhum substitui o outro."""
    registrar_evento(
        categoria=categoria, descricao=descricao, empresa=empresa, usuario=request.user,
        ip=ip_do_request(request), filial=filial, modulo="financeiro", acao=acao,
        tipo_objeto=tipo_objeto, id_objeto=id_objeto, estado_antes=estado_antes, estado_depois=estado_depois,
    )


class ReceitaUpdateView(PerfilRequiredMixin, UpdateView):
    model = Receita
    form_class = ReceitaForm
    template_name = "financeiro/receita_form.html"
    success_url = reverse_lazy("financeiro:receita_list")
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Editar Receita"}

    def get_queryset(self):
        return Receita.objects.filter(filial__in=filiais_do_contexto(self.request))

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def form_valid(self, form):
        faturamento_antes = Receita.objects.get(pk=self.object.pk).faturamento
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_log_financeiro(
                self.request, self.object.filial.empresa,
                f"Receita de {self.object.filial.nome} ({self.object.mes:%m/%Y}) atualizada para "
                f"R$ {self.object.faturamento}.",
            )
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.RECEITA_ALTERADA, "editar",
                f"Receita de {self.object.filial.nome} ({self.object.mes:%m/%Y}) editada.", "Receita", self.object.pk,
                estado_antes={"faturamento": str(faturamento_antes)},
                estado_depois={"faturamento": str(self.object.faturamento)},
            )
        messages.success(self.request, "Receita atualizada com sucesso.")
        return resposta


@perfil_required(*PERFIS_CADASTRO)
def receita_excluir(request, pk):
    receita = get_object_or_404(Receita, pk=pk, filial__in=filiais_do_contexto(request))
    if request.method == "POST":
        empresa, descricao = receita.filial.empresa, (
            f"Receita de {receita.filial.nome} ({receita.mes:%m/%Y}) excluída."
        )
        receita_pk, receita_filial = receita.pk, receita.filial
        with transaction.atomic():
            receita.delete()
            _registrar_log_financeiro(request, empresa, descricao)
            _registrar_evento_financeiro(
                request, empresa, receita_filial, RegistroAuditoria.Categoria.RECEITA_ALTERADA, "excluir",
                descricao, "Receita", receita_pk,
            )
        messages.success(request, "Receita excluída.")
    return redirect("financeiro:receita_list")


# --------------------------------------------------------------------------
# Receitas extras (mudança de escopo — lançamento 100% manual): serviços
# farmacêuticos, convênios/PBM, rendimentos e outras entradas, que somam à
# receita mensal (faturamento) no Motor Financeiro. Mesma área, mesmo gate
# (PERFIS_VISUALIZACAO para ver, PERFIS_CADASTRO para lançar) e mesma
# categoria de auditoria (RECEITA_ALTERADA) das telas de Receita.
# --------------------------------------------------------------------------


def _estado_receita_extra(receita_extra):
    return {
        "filial_id": receita_extra.filial_id,
        "data": receita_extra.data.isoformat(),
        "descricao": receita_extra.descricao,
        "categoria": receita_extra.categoria,
        "valor": str(receita_extra.valor),
        "observacao": receita_extra.observacao,
    }


def _url_lista_receitas_extras(data_referencia):
    """Lista de receitas extras já no mês da receita salva/excluída — o
    usuário vê o efeito do que acabou de fazer."""
    return f"{reverse('financeiro:receitaextra_list')}?ano={data_referencia.year}&mes={data_referencia.month}"


def _filiais_filtradas(request, filiais):
    """Filtro opcional `?filial=<id>` — só aceita filial visível no
    contexto; qualquer outro id (inclusive de outra empresa) é ignorado."""
    filial_id = (request.GET.get("filial") or "").strip()
    selecionada = next((filial for filial in filiais if str(filial.pk) == filial_id), None)
    return selecionada, ([selecionada] if selecionada is not None else filiais)


class ReceitaExtraListView(PerfilRequiredMixin, ListView):
    model = ReceitaExtra
    template_name = "financeiro/receitaextra_list.html"
    context_object_name = "receitas_extras"
    perfis_permitidos = PERFIS_VISUALIZACAO

    def _filtros(self):
        if not hasattr(self, "_filtros_cache"):
            ano, mes = _competencia_do_request(self.request)
            filiais = list(filiais_do_contexto(self.request))
            filial_selecionada, filiais_alvo = _filiais_filtradas(self.request, filiais)
            categoria = (self.request.GET.get("categoria") or "").strip()
            if categoria not in ReceitaExtra.Categoria.values:
                categoria = ""
            self._filtros_cache = {
                "ano": ano, "mes": mes, "filiais": filiais, "filial_selecionada": filial_selecionada,
                "filiais_alvo": filiais_alvo, "categoria": categoria,
            }
        return self._filtros_cache

    def get_queryset(self):
        filtros = self._filtros()
        queryset = ReceitaExtra.objects.filter(
            filial__in=filtros["filiais_alvo"], data__year=filtros["ano"], data__month=filtros["mes"],
        ).select_related("filial")
        if filtros["categoria"]:
            queryset = queryset.filter(categoria=filtros["categoria"])
        return queryset

    def get(self, request, *args, **kwargs):
        if request.GET.get("formato") == "csv":
            filtros = self._filtros()
            linhas = [
                [
                    item.data.strftime("%d/%m/%Y"), item.filial.nome, item.get_categoria_display(),
                    item.descricao, str(item.valor).replace(".", ","), item.observacao,
                ]
                for item in self.get_queryset()
            ]
            return resposta_csv(
                f"receitas_extras_{filtros['ano']}_{filtros['mes']:02d}.csv",
                ["Data", "Filial", "Categoria", "Descrição", "Valor (R$)", "Observação"], linhas,
            )
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        filtros = self._filtros()
        itens = list(contexto["receitas_extras"])
        total_listado = sum((item.valor for item in itens), Decimal("0"))
        por_categoria = []
        for valor_categoria, rotulo in ReceitaExtra.Categoria.choices:
            do_grupo = [item for item in itens if item.categoria == valor_categoria]
            if do_grupo:
                por_categoria.append(
                    {
                        "rotulo": rotulo,
                        "subtotal": sum((item.valor for item in do_grupo), Decimal("0")),
                        "quantidade": len(do_grupo),
                    }
                )
        contexto.update(_contexto_competencia(filtros["ano"], filtros["mes"]))
        contexto.update(
            {
                "filiais": filtros["filiais"],
                "filial_selecionada": filtros["filial_selecionada"],
                "categoria_selecionada": filtros["categoria"],
                "categorias": ReceitaExtra.Categoria.choices,
                "total_listado": total_listado,
                "quantidade_listada": len(itens),
                "por_categoria": por_categoria,
                # Mesma fonte do Motor: receita mensal + extras do mês (sem o
                # filtro de categoria, que é só de visualização da lista).
                "resumo_mes": resumo_receitas_do_mes(filtros["filiais_alvo"], filtros["ano"], filtros["mes"]),
                "pode_cadastrar": self.request.user.perfil in PERFIS_CADASTRO,
                "mostra_coluna_filial": len(filtros["filiais"]) > 1,
                "filtros_aplicados": bool(filtros["filial_selecionada"] or filtros["categoria"]),
                "querystring_filtros": self._querystring_filtros(filtros),
            }
        )
        return contexto

    @staticmethod
    def _querystring_filtros(filtros):
        partes = []
        if filtros["filial_selecionada"] is not None:
            partes.append(f"filial={filtros['filial_selecionada'].pk}")
        if filtros["categoria"]:
            partes.append(f"categoria={filtros['categoria']}")
        return ("&" + "&".join(partes)) if partes else ""


class ReceitaExtraCreateView(PerfilRequiredMixin, CreateView):
    model = ReceitaExtra
    form_class = ReceitaExtraForm
    template_name = "financeiro/receitaextra_form.html"
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Nova receita extra"}

    def get_initial(self):
        return {"data": date.today()}

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def get_success_url(self):
        return _url_lista_receitas_extras(self.object.data)

    def form_valid(self, form):
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.RECEITA_ALTERADA, "criar",
                f'Receita extra "{self.object.descricao}" de {self.object.filial.nome} '
                f"({self.object.data:%d/%m/%Y}) cadastrada.",
                "ReceitaExtra", self.object.pk,
                estado_depois=_estado_receita_extra(self.object),
            )
        messages.success(
            self.request,
            f'Receita extra "{self.object.descricao}" cadastrada com sucesso — a receita de '
            f"{self.object.data:%m/%Y} e a capacidade de compra já foram recalculadas.",
        )
        return resposta


class ReceitaExtraUpdateView(PerfilRequiredMixin, UpdateView):
    model = ReceitaExtra
    form_class = ReceitaExtraForm
    template_name = "financeiro/receitaextra_form.html"
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Editar receita extra"}

    def get_queryset(self):
        return ReceitaExtra.objects.filter(filial__in=filiais_do_contexto(self.request))

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def get_success_url(self):
        return _url_lista_receitas_extras(self.object.data)

    def form_valid(self, form):
        estado_antes = _estado_receita_extra(ReceitaExtra.objects.get(pk=self.object.pk))
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_log_financeiro(
                self.request, self.object.filial.empresa,
                f'Receita extra "{self.object.descricao}" de {self.object.filial.nome} atualizada '
                f"(R$ {self.object.valor}, {self.object.data:%d/%m/%Y}).",
            )
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.RECEITA_ALTERADA, "editar",
                f'Receita extra "{self.object.descricao}" de {self.object.filial.nome} editada.',
                "ReceitaExtra", self.object.pk,
                estado_antes=estado_antes, estado_depois=_estado_receita_extra(self.object),
            )
        messages.success(
            self.request,
            f'Receita extra "{self.object.descricao}" atualizada com sucesso — '
            "a capacidade de compra já foi recalculada.",
        )
        return resposta


@perfil_required(*PERFIS_CADASTRO)
def receitaextra_excluir(request, pk):
    """GET: tela de confirmação (nada é apagado). POST: exclusão real —
    a receita extra é um fato pontual, nenhum outro registro a referencia."""
    receita_extra = get_object_or_404(
        ReceitaExtra.objects.select_related("filial"), pk=pk, filial__in=filiais_do_contexto(request)
    )
    if request.method == "POST":
        empresa, filial = receita_extra.filial.empresa, receita_extra.filial
        estado_antes = _estado_receita_extra(receita_extra)
        receita_pk, data_referencia, descricao_item = receita_extra.pk, receita_extra.data, receita_extra.descricao
        descricao = f'Receita extra "{descricao_item}" de {filial.nome} ({data_referencia:%d/%m/%Y}) excluída.'
        with transaction.atomic():
            receita_extra.delete()
            _registrar_log_financeiro(request, empresa, descricao)
            _registrar_evento_financeiro(
                request, empresa, filial, RegistroAuditoria.Categoria.RECEITA_ALTERADA, "excluir",
                descricao, "ReceitaExtra", receita_pk, estado_antes=estado_antes,
            )
        messages.success(
            request, f'Receita extra "{descricao_item}" excluída — a capacidade de compra já foi recalculada.'
        )
        return redirect(_url_lista_receitas_extras(data_referencia))
    return render(
        request,
        "financeiro/receitaextra_confirmar_exclusao.html",
        {"receita_extra": receita_extra, "voltar_url": _url_lista_receitas_extras(receita_extra.data)},
    )


class CustoFixoUpdateView(PerfilRequiredMixin, UpdateView):
    model = CustoFixo
    form_class = CustoFixoForm
    template_name = "financeiro/custofixo_form.html"
    success_url = reverse_lazy("financeiro:custofixo_list")
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Editar Custo Fixo"}

    def get_queryset(self):
        return CustoFixo.objects.filter(filial__in=filiais_do_contexto(self.request))

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def form_valid(self, form):
        antes = CustoFixo.objects.get(pk=self.object.pk)
        estado_antes = {"descricao": antes.descricao, "valor": str(antes.valor), "dia_vencimento": antes.dia_vencimento}
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_log_financeiro(
                self.request, self.object.filial.empresa,
                f'Custo fixo "{self.object.descricao}" atualizado (R$ {self.object.valor}, '
                f"vencimento dia {self.object.dia_vencimento}).",
            )
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO, "editar",
                f'Custo fixo "{self.object.descricao}" editado.', "CustoFixo", self.object.pk,
                estado_antes=estado_antes,
                estado_depois={
                    "descricao": self.object.descricao, "valor": str(self.object.valor),
                    "dia_vencimento": self.object.dia_vencimento,
                },
            )
        messages.success(self.request, "Custo fixo atualizado com sucesso.")
        return resposta


@perfil_required(*PERFIS_CADASTRO)
def custofixo_excluir(request, pk):
    """Exclusão lógica: desativa (o campo `ativo` já existe no model),
    mantendo o histórico já calculado com este custo."""
    custo = get_object_or_404(CustoFixo, pk=pk, filial__in=filiais_do_contexto(request))
    if request.method == "POST":
        with transaction.atomic():
            custo.ativo = False
            custo.save(update_fields=["ativo", "atualizado_em"])
            _registrar_log_financeiro(request, custo.filial.empresa, f'Custo fixo "{custo.descricao}" desativado.')
            _registrar_evento_financeiro(
                request, custo.filial.empresa, custo.filial, RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO,
                "desativar", f'Custo fixo "{custo.descricao}" desativado.', "CustoFixo", custo.pk,
                estado_antes={"ativo": True}, estado_depois={"ativo": False},
            )
        messages.success(request, f'Custo fixo "{custo.descricao}" desativado.')
    return redirect("financeiro:custofixo_list")


@perfil_required(*PERFIS_CADASTRO)
def custofixo_reativar(request, pk):
    custo = get_object_or_404(CustoFixo, pk=pk, filial__in=filiais_do_contexto(request))
    if request.method == "POST":
        with transaction.atomic():
            custo.ativo = True
            custo.save(update_fields=["ativo", "atualizado_em"])
            _registrar_log_financeiro(request, custo.filial.empresa, f'Custo fixo "{custo.descricao}" reativado.')
            _registrar_evento_financeiro(
                request, custo.filial.empresa, custo.filial, RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO,
                "reativar", f'Custo fixo "{custo.descricao}" reativado.', "CustoFixo", custo.pk,
                estado_antes={"ativo": False}, estado_depois={"ativo": True},
            )
        messages.success(request, f'Custo fixo "{custo.descricao}" reativado.')
    return redirect("financeiro:custofixo_list")


class CustoVariavelUpdateView(PerfilRequiredMixin, UpdateView):
    model = CustoVariavel
    form_class = CustoVariavelForm
    template_name = "financeiro/custovariavel_form.html"
    success_url = reverse_lazy("financeiro:custovariavel_list")
    perfis_permitidos = PERFIS_CADASTRO
    extra_context = {"titulo": "Editar Custo Variável"}

    def get_queryset(self):
        return CustoVariavel.objects.filter(filial__in=filiais_do_contexto(self.request))

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs

    def form_valid(self, form):
        antes = CustoVariavel.objects.get(pk=self.object.pk)
        estado_antes = {
            "descricao": antes.descricao, "valor": str(antes.valor),
            "data_prevista": antes.data_prevista.isoformat(),
        }
        with transaction.atomic():
            resposta = super().form_valid(form)
            _registrar_log_financeiro(
                self.request, self.object.filial.empresa,
                f'Custo variável "{self.object.descricao}" atualizado (R$ {self.object.valor}, '
                f"previsto para {self.object.data_prevista:%d/%m/%Y}).",
            )
            _registrar_evento_financeiro(
                self.request, self.object.filial.empresa, self.object.filial,
                RegistroAuditoria.Categoria.CUSTO_VARIAVEL_ALTERADO, "editar",
                f'Custo variável "{self.object.descricao}" editado.', "CustoVariavel", self.object.pk,
                estado_antes=estado_antes,
                estado_depois={
                    "descricao": self.object.descricao, "valor": str(self.object.valor),
                    "data_prevista": self.object.data_prevista.isoformat(),
                },
            )
        messages.success(self.request, "Custo variável atualizado com sucesso.")
        return resposta


@perfil_required(*PERFIS_CADASTRO)
def custovariavel_excluir(request, pk):
    custo = get_object_or_404(CustoVariavel, pk=pk, filial__in=filiais_do_contexto(request))
    if request.method == "POST":
        empresa, descricao = custo.filial.empresa, f'Custo variável "{custo.descricao}" excluído.'
        custo_pk, custo_filial = custo.pk, custo.filial
        with transaction.atomic():
            custo.delete()
            _registrar_log_financeiro(request, empresa, descricao)
            _registrar_evento_financeiro(
                request, empresa, custo_filial, RegistroAuditoria.Categoria.CUSTO_VARIAVEL_ALTERADO, "excluir",
                descricao, "CustoVariavel", custo_pk,
            )
        messages.success(request, "Custo variável excluído.")
    return redirect("financeiro:custovariavel_list")


@permissao_required("agenda.ver")
def agenda_financeira(request):
    """Agenda Financeira única (Épico 3 — CORE 1.0): parcelas, contas
    fixas/variáveis e provisões da(s) filial(is) visível(is), numa linha do
    tempo só. Toda a agregação vem de `finance_engine.agenda`."""
    hoje = date.today()
    try:
        dias = max(min(int(request.GET.get("dias", 30)), 90), 7)
    except (TypeError, ValueError):
        dias = 30

    filiais = filiais_do_contexto(request)
    lancamentos = []
    for filial in filiais:
        lancamentos.extend(gerar_agenda(filial, hoje - timedelta(days=7), hoje + timedelta(days=dias), hoje=hoje))
    lancamentos.sort(key=lambda item: (item.data, item.descricao))

    periodo = f"{(hoje - timedelta(days=7)):%d/%m/%Y} a {(hoje + timedelta(days=dias)):%d/%m/%Y}"

    if request.GET.get("formato") == "csv":
        linhas = [
            [
                item.data.strftime("%d/%m/%Y"), item.tipo, item.descricao, item.responsavel or "",
                str(item.valor).replace(".", ","), "Vencida" if item.vencida else item.status.replace("_", " ").capitalize(),
            ]
            for item in lancamentos
        ]
        return resposta_csv(
            "agenda_financeira.csv", ["Data", "Tipo", "Descrição", "Responsável", "Valor (R$)", "Status"], linhas,
        )

    contexto = {
        "hoje": hoje,
        "dias": dias,
        "periodo": periodo,
        "lancamentos": lancamentos,
        "total_pendente": sum((item.valor for item in lancamentos if item.pendente), 0),
        # QA final (Gate 7, Sprint de Encerramento Definitivo): estava fixo em
        # True — mostrava "Baixar"/"Estornar" até para quem não tem
        # `agenda.baixar_parcela` (ex.: Gerente com só `agenda.ver`). O POST
        # já era barrado com 403 no backend, mas a UI não deveria oferecer um
        # botão que sempre falha.
        "pode_baixar": usuario_tem_permissao(request.user, "agenda.baixar_parcela"),
    }
    return render(request, "financeiro/agenda.html", contexto)


@permissao_required("agenda.baixar_parcela")
def baixar_parcela(request, pk):
    """Baixa manual de uma parcela (Agenda Financeira → "marcar como
    paga"). A regra vive em `compras.services.marcar_parcela_paga`."""
    parcela = get_object_or_404(
        ParcelaCompra, pk=pk, compra__filial__in=filiais_do_contexto(request),
        status=ParcelaCompra.Status.PENDENTE,
    )
    if request.method == "POST":
        with transaction.atomic():
            marcar_parcela_paga(parcela, request.user)
            _registrar_evento_financeiro(
                request, parcela.compra.empresa, parcela.compra.filial,
                RegistroAuditoria.Categoria.PARCELA_BAIXADA, "baixar",
                f"Parcela {parcela.numero} de {parcela.compra.fornecedor} marcada como paga.",
                "ParcelaCompra", parcela.pk,
                estado_antes={"status": "pendente"}, estado_depois={"status": "paga", "valor": str(parcela.valor)},
            )
        messages.success(request, f"Parcela {parcela.numero} de {parcela.compra.fornecedor} marcada como paga.")
    return redirect("financeiro:agenda")


@permissao_required("agenda.baixar_parcela")
def estornar_parcela(request, pk):
    """Prompt 2 (pré-Etapa 02), Gates A/D/E/F: reverte uma baixa feita por
    engano (Agenda Financeira → "Estornar"). Mesma permissão de
    `baixar_parcela` — quem pode dar baixa também pode corrigi-la. Exige
    justificativa (é uma reversão financeira, precisa de motivo registrado
    na trilha de auditoria)."""
    parcela = get_object_or_404(
        ParcelaCompra, pk=pk, compra__filial__in=filiais_do_contexto(request),
        status=ParcelaCompra.Status.PAGA,
    )
    if request.method == "POST":
        justificativa = (request.POST.get("justificativa") or "").strip()
        if not justificativa:
            messages.error(request, "Informe a justificativa do estorno.")
            return redirect("financeiro:agenda")
        with transaction.atomic():
            estornar_parcela_service(parcela, request.user, justificativa=justificativa)
            _registrar_evento_financeiro(
                request, parcela.compra.empresa, parcela.compra.filial,
                RegistroAuditoria.Categoria.PARCELA_ESTORNADA, "estornar",
                f"Parcela {parcela.numero} de {parcela.compra.fornecedor} estornada — volta a pendente.",
                "ParcelaCompra", parcela.pk,
                estado_antes={"status": "paga", "valor": str(parcela.valor)}, estado_depois={"status": "pendente"},
            )
        messages.success(request, f"Parcela {parcela.numero} de {parcela.compra.fornecedor} estornada — voltou a pendente.")
    return redirect("financeiro:agenda")


@permissao_required("calendario.configurar")
def calendario_operacional(request):
    """Configuração do Calendário Operacional (Épico 2 — CORE 1.0): grade
    do mês com o tipo resolvido de cada dia + exceções cadastradas da
    empresa ativa, com inclusão/remoção de exceção."""
    empresa = empresa_ativa(request)
    if empresa is None:
        messages.error(request, "Seu usuário não está vinculado a uma empresa.")
        return redirect("dashboard:home")

    hoje = date.today()
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
    except (TypeError, ValueError):
        ano, mes = hoje.year, hoje.month

    if request.method == "POST":
        if request.POST.get("acao") == "remover":
            dia_removido = DiaOperacional.objects.filter(empresa=empresa, pk=request.POST.get("dia_id")).first()
            if dia_removido is not None:
                descricao = f"Exceção de {dia_removido.data:%d/%m/%Y} ({dia_removido.get_tipo_display()}) removida — voltou à regra padrão."
                dia_removido_data, dia_removido_tipo, dia_removido_pk = (
                    dia_removido.data.isoformat(), dia_removido.tipo, dia_removido.pk,
                )
                with transaction.atomic():
                    dia_removido.delete()
                    _registrar_log_financeiro(request, empresa, descricao, area="Calendário Operacional")
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.DIA_OPERACIONAL_ALTERADO, descricao=descricao,
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="financeiro", acao="remover_dia", tipo_objeto="DiaOperacional", id_objeto=dia_removido_pk,
                        estado_antes={"data": dia_removido_data, "tipo": dia_removido_tipo}, estado_depois=None,
                    )
            messages.success(request, "Exceção do calendário removida — o dia voltou à regra padrão.")
            return redirect(f"{request.path}?ano={ano}&mes={mes}")
        if request.POST.get("acao") == "sabado":
            # Sprint de Melhorias 1: liga/desliga "Sábado é dia de compra"
            # para a empresa inteira (ver Empresa.sabado_dia_de_compra).
            ligar = request.POST.get("sabado_dia_de_compra") == "1"
            if ligar != empresa.sabado_dia_de_compra:
                descricao = (
                    "Sábado passou a ser dia de compra (limite próprio, como dia útil)."
                    if ligar else "Sábado deixou de ser dia de compra (volta à regra segunda a sexta)."
                )
                with transaction.atomic():
                    empresa.sabado_dia_de_compra = ligar
                    empresa.save(update_fields=["sabado_dia_de_compra"])
                    _registrar_log_financeiro(request, empresa, descricao, area="Calendário Operacional")
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.DIA_OPERACIONAL_ALTERADO, descricao=descricao,
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="financeiro", acao="sabado_dia_de_compra", tipo_objeto="Empresa", id_objeto=empresa.pk,
                        estado_antes={"sabado_dia_de_compra": not ligar}, estado_depois={"sabado_dia_de_compra": ligar},
                    )
                messages.success(request, descricao)
            return redirect(f"{request.path}?ano={ano}&mes={mes}")
        if request.POST.get("acao") == "confirmar_revisao":
            # Item 10 do Checklist Guiado de Implantação
            # (empresas/services_checklist.py): antes deste botão existir, o
            # item ficava PERMANENTEMENTE pendente para uma Empresa que
            # legitimamente não tem nenhum feriado/exceção para cadastrar —
            # não havia, no banco, como distinguir "revisei e não precisa de
            # nada" de "nunca abri esta tela". Esta confirmação é a
            # correção: um evento auditado real (quem confirmou, quando,
            # Empresa), reservado ao Proprietário — é uma decisão de
            # governança sobre a implantação, diferente da edição
            # operacional do dia a dia (que o Financeiro também faz nesta
            # mesma tela, via `calendario.configurar`).
            if request.user.perfil != Usuario.Perfil.PROPRIETARIO:
                messages.error(
                    request, "Só o Proprietário pode confirmar a revisão do Calendário Operacional.",
                )
                return redirect(f"{request.path}?ano={ano}&mes={mes}")
            with transaction.atomic():
                _registrar_log_financeiro(
                    request, empresa, "Calendário Operacional revisado e confirmado pelo Proprietário.",
                    area="Calendário Operacional",
                )
                registrar_evento(
                    categoria=RegistroAuditoria.Categoria.CALENDARIO_OPERACIONAL_REVISADO,
                    descricao=(
                        "Calendário Operacional revisado e confirmado pelo Proprietário — "
                        "nenhuma exceção adicional necessária."
                    ),
                    empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                    modulo="financeiro", acao="confirmar_calendario",
                    tipo_objeto="Empresa", id_objeto=empresa.pk,
                )
            messages.success(request, "Calendário Operacional marcado como revisado.")
            return redirect(f"{request.path}?ano={ano}&mes={mes}")
        form = DiaOperacionalForm(request.POST)
        if form.is_valid():
            tipo_antes = DiaOperacional.objects.filter(
                empresa=empresa, data=form.cleaned_data["data"]
            ).values_list("tipo", flat=True).first()
            with transaction.atomic():
                dia_salvo, criado = DiaOperacional.objects.update_or_create(
                    empresa=empresa,
                    data=form.cleaned_data["data"],
                    defaults={"tipo": form.cleaned_data["tipo"], "observacao": form.cleaned_data["observacao"]},
                )
                _registrar_log_financeiro(
                    request, empresa,
                    f"Dia {dia_salvo.data:%d/%m/%Y} {'marcado' if criado else 'atualizado'} como "
                    f"{dia_salvo.get_tipo_display()}"
                    + (f" — {dia_salvo.observacao}" if dia_salvo.observacao else "") + ".",
                    area="Calendário Operacional",
                )
                registrar_evento(
                    categoria=RegistroAuditoria.Categoria.DIA_OPERACIONAL_ALTERADO,
                    descricao=f"Dia {dia_salvo.data:%d/%m/%Y} {'marcado' if criado else 'atualizado'} como {dia_salvo.get_tipo_display()}.",
                    empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                    modulo="financeiro", acao="dia_operacional", tipo_objeto="DiaOperacional", id_objeto=dia_salvo.pk,
                    estado_antes={"tipo": tipo_antes} if not criado else None,
                    estado_depois={"data": dia_salvo.data.isoformat(), "tipo": dia_salvo.tipo, "observacao": dia_salvo.observacao},
                )
            messages.success(request, "Dia operacional salvo — a capacidade diária foi recalculada automaticamente.")
            return redirect(f"{request.path}?ano={ano}&mes={mes}")
    else:
        form = DiaOperacionalForm()

    tipos = mapa_tipos_do_mes(empresa, ano, mes)
    excecoes = {dia.data.day: dia for dia in DiaOperacional.objects.filter(empresa=empresa, data__year=ano, data__month=mes)}
    dias = [
        {
            "dia": dia_num,
            "data": date(ano, mes, dia_num),
            "tipo": tipo,
            "excecao": excecoes.get(dia_num),
            "conta_capacidade": tipo in (DiaOperacional.Tipo.UTIL, DiaOperacional.Tipo.ESPECIAL),
        }
        for dia_num, tipo in sorted(tipos.items())
    ]

    mes_anterior = date(ano, mes, 1) - timedelta(days=1)
    proximo_mes = (date(ano, mes, 28) + timedelta(days=7)).replace(day=1)
    # Item 10 do Checklist Guiado de Implantação: mostra ao usuário se
    # alguém já confirmou a revisão (e quem/quando) — o template usa isso
    # para trocar o botão "Confirmar" por um badge de status.
    revisao_confirmada = (
        RegistroAuditoria.objects.filter(
            empresa=empresa, categoria=RegistroAuditoria.Categoria.CALENDARIO_OPERACIONAL_REVISADO,
        )
        .order_by("-criado_em")
        .first()
    )
    contexto = {
        "empresa": empresa,
        "ano": ano,
        "mes": mes,
        "data_referencia": date(ano, mes, 1),
        "dias": dias,
        "form": form,
        "dias_que_contam": sum(1 for d in dias if d["conta_capacidade"]),
        "mes_anterior": mes_anterior,
        "proximo_mes": proximo_mes,
        "tipos_choices": DiaOperacional.Tipo.choices,
        "revisao_confirmada": revisao_confirmada,
        "usuario_e_proprietario": request.user.perfil == Usuario.Perfil.PROPRIETARIO,
    }
    return render(request, "financeiro/calendario_operacional.html", contexto)


@perfil_required(*PERFIS_VISUALIZACAO)
def configuracao_financeira(request):
    empresa = empresa_ativa(request)
    if empresa is None:
        messages.error(request, "Seu usuário não está vinculado a uma empresa.")
        return redirect("dashboard:home")

    # cor_principal="" = "sem cor personalizada" (mesmo padrão do Assistente
    # de Implantação): só ABRIR esta tela não grava o vermelho legado do
    # default do campo.
    config, _ = ConfiguracaoFinanceira.objects.get_or_create(empresa=empresa, defaults={"cor_principal": ""})

    # Sprint de Correções Críticas (Seção 18): campos que alimentam
    # diretamente o Motor Financeiro — mudar qualquer um recalcula a
    # capacidade de TODAS as filiais da empresa a partir de agora, então o
    # log registra valor anterior/posterior de cada um, não só "atualizado".
    _CAMPOS_AUDITADOS = (
        "percentual_compras", "percentual_seguranca", "dias_uteis_manual",
        "permitir_saldo_acumulativo", "redistribuicao_automatica",
        "permitir_ultrapassar_limite", "limite_maximo_acumulado", "regra_excesso",
    )

    if request.method == "POST":
        valores_antes = {campo: getattr(config, campo) for campo in _CAMPOS_AUDITADOS}
        form = ConfiguracaoFinanceiraForm(request.POST, instance=config)
        if form.is_valid():
            with transaction.atomic():
                form.save()
                mudancas = [
                    campo for campo in _CAMPOS_AUDITADOS
                    if campo in form.changed_data and getattr(config, campo) != valores_antes[campo]
                ]
                if mudancas:
                    detalhes = "; ".join(
                        f"{config._meta.get_field(campo).verbose_name}: {valores_antes[campo]} → {getattr(config, campo)}"
                        for campo in mudancas
                    )
                    descricao_log = f"Configuração financeira atualizada — {detalhes}."
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.CONFIGURACAO_FINANCEIRA_ALTERADA,
                        descricao=descricao_log,
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="financeiro", acao="configuracao_financeira",
                        tipo_objeto="ConfiguracaoFinanceira", id_objeto=config.pk,
                        estado_antes={campo: str(valores_antes[campo]) for campo in mudancas},
                        estado_depois={campo: str(getattr(config, campo)) for campo in mudancas},
                    )
                else:
                    descricao_log = "Configuração financeira revisada e salva — nenhum valor mudou."
                # Item 4 do Checklist Guiado de Implantação
                # (empresas/services_checklist.py): o sentinela antigo
                # ("percentual ainda é o padrão de 30%") ficava
                # permanentemente "não configurado" mesmo quando o cliente
                # salvava 30% de propósito. O sinal correto é o FATO de o
                # formulário ter sido salvo, não o valor salvo — por isso
                # este log é gravado em TODO POST válido, mesmo sem
                # `mudancas` (`get_or_create` do GET nunca grava este log,
                # só um POST de verdade grava).
                _registrar_log_financeiro(request, empresa, descricao_log, area="Configuração Financeira")
            messages.success(request, "Configuração financeira atualizada com sucesso.")
            return redirect("financeiro:configuracao")
    else:
        form = ConfiguracaoFinanceiraForm(instance=config)

    return render(request, "financeiro/configuracao_form.html", {"form": form, "empresa": empresa})
