from django import forms

from core.forms import BootstrapFormMixin, MoedaFormMixin
from finance_engine.validators import ConfiguracaoInvalidaError, validar_configuracao_financeira

from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, DiaOperacional, Receita, ReceitaExtra


class DiaOperacionalForm(BootstrapFormMixin, forms.Form):
    """Exceção do Calendário Operacional (Épico 2 — CORE 1.0). Form simples
    (não ModelForm) porque a empresa vem sempre do contexto da view, nunca
    do usuário digitar."""

    data = forms.DateField(label="Data", widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"))
    tipo = forms.ChoiceField(label="Tipo do dia", choices=DiaOperacional.Tipo.choices)
    observacao = forms.CharField(label="Observação", max_length=200, required=False)


class FilialScopedForm(MoedaFormMixin, BootstrapFormMixin, forms.ModelForm):
    """Form base que restringe o campo `filial` às filiais autorizadas do
    usuário logado.

    Sprint de Correções Críticas (Seção 10): passa a aceitar `empresa` (a
    empresa ATIVA do contexto) e delega a `filiais_autorizadas_para` — antes
    usava `user.filiais_visiveis()` sem contexto, que resolve sempre para a
    empresa PRINCIPAL do usuário. Um Financeiro que trocasse de empresa via
    o seletor via a lista de Receitas/Custos da empresa nova corretamente,
    mas o formulário "Nova Receita/Custo" continuava só oferecendo a filial
    de origem — o Financeiro nunca conseguia lançar nada na empresa para a
    qual tinha acabado de trocar de contexto (achado da auditoria de
    filiais e vínculos)."""

    def __init__(self, *args, user=None, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user is not None and "filial" in self.fields:
            from usuarios.models import filiais_autorizadas_para

            empresa = empresa or user.empresa
            filiais = filiais_autorizadas_para(user, empresa) if empresa is not None else user.filiais_visiveis()
            self.fields["filial"].queryset = filiais
            if filiais.count() == 1:
                self.fields["filial"].initial = filiais.first()


class ReceitaForm(FilialScopedForm):
    """Receita mensal: uma por filial e mês.

    Rodada final (crítico funcional): o campo aceita "qualquer dia do mês",
    mas o `save()` do model só normalizava para o dia 1 DEPOIS do
    `validate_unique` — com dia ≠ 01 num mês que já tinha receita a
    gravação estourava em IntegrityError (HTTP 500); com dia 01 o erro de
    unicidade virava um non_field_error que o template não mostrava. Agora
    o mês é normalizado aqui (antes da checagem de unicidade) e a
    duplicidade vira uma mensagem clara, com o atalho para a existente."""

    campos_moeda = ("faturamento",)

    # Preenchido por `validate_unique` quando o mês já tem receita — o
    # template usa para oferecer o link "Editar a receita existente".
    receita_existente = None

    class Meta:
        model = Receita
        fields = ["filial", "mes", "faturamento"]
        widgets = {"mes": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}
        labels = {"mes": "Mês de referência"}

    def clean_mes(self):
        mes = self.cleaned_data.get("mes")
        return mes.replace(day=1) if mes else mes

    def validate_unique(self):
        filial = self.cleaned_data.get("filial")
        mes = self.cleaned_data.get("mes")
        if filial is not None and mes is not None:
            existente = (
                Receita.objects.filter(filial=filial, mes__year=mes.year, mes__month=mes.month)
                .exclude(pk=self.instance.pk)
                .first()
            )
            if existente is not None:
                self.receita_existente = existente
                self.add_error(
                    None,
                    f"Já existe receita de {mes:%m/%Y} para {filial.nome} — edite a existente.",
                )
                return
        super().validate_unique()


class ReceitaExtraForm(FilialScopedForm):
    """Receita extra (serviços farmacêuticos, convênios/PBM, rendimentos,
    outras) — lançamento manual que soma à receita mensal do mês da `data`
    no Motor Financeiro. Filial restrita às autorizadas da empresa ATIVA
    (mesma regra de `ReceitaForm`, herdada de `FilialScopedForm`)."""

    campos_moeda = ("valor",)

    class Meta:
        model = ReceitaExtra
        fields = ["filial", "data", "descricao", "categoria", "valor", "observacao"]
        widgets = {
            "data": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "observacao": forms.Textarea(attrs={"rows": 2}),
        }
        help_texts = {
            "data": "Entra na receita do mês desta data.",
            "valor": "Valor recebido, maior que zero.",
        }

    def clean_valor(self):
        valor = self.cleaned_data.get("valor")
        if valor is not None and valor <= 0:
            raise forms.ValidationError("Informe um valor maior que zero.")
        return valor


class CustoFixoForm(FilialScopedForm):
    campos_moeda = ("valor",)

    class Meta:
        model = CustoFixo
        fields = ["filial", "descricao", "fornecedor", "valor", "dia_vencimento", "ativo"]


class CustoVariavelForm(FilialScopedForm):
    campos_moeda = ("valor",)

    class Meta:
        model = CustoVariavel
        fields = ["filial", "descricao", "valor", "data_prevista"]
        widgets = {"data_prevista": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}


class ConfiguracaoFinanceiraForm(MoedaFormMixin, BootstrapFormMixin, forms.ModelForm):
    campos_moeda = ("limite_maximo_acumulado",)

    class Meta:
        model = ConfiguracaoFinanceira
        fields = [
            "percentual_compras",
            "percentual_seguranca",
            "dias_uteis_manual",
            "permitir_saldo_acumulativo",
            "redistribuicao_automatica",
            "permitir_ultrapassar_limite",
            "limite_maximo_acumulado",
            "regra_excesso",
            "cor_principal",
            "moeda",
            "observacoes",
        ]
        widgets = {
            "cor_principal": forms.TextInput(attrs={"type": "color", "class": "form-control form-control-color"}),
            "observacoes": forms.Textarea(attrs={"rows": 3}),
        }
        help_texts = {
            "cor_principal": (
                "Cor dos botões, do item ativo do menu e dos links em todas as telas. "
                "O padrão é o azul NEXBUY — evite vermelho, que nas telas significa alerta ou prejuízo."
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .models import COR_PRINCIPAL_DEFAULT_LEGADO, COR_PRINCIPAL_PADRAO_NEXBUY

        # Configuração nunca personalizada (vazia ou com o vermelho legado do
        # default do campo): o seletor de cor sugere o azul NEXBUY — salvar
        # "sem mexer" nunca mais pinta o sistema de vermelho (nem de preto,
        # que é o que um <input type="color"> vazio enviaria).
        atual = (self.initial.get("cor_principal") or "").strip().upper()
        if atual in ("", COR_PRINCIPAL_DEFAULT_LEGADO):
            self.initial["cor_principal"] = COR_PRINCIPAL_PADRAO_NEXBUY

    def clean(self):
        cleaned_data = super().clean()
        # Reaproveita a validação central do Motor Financeiro em vez de
        # reescrever as regras aqui (Sprint 3 — regra 8/9).
        try:
            validar_configuracao_financeira(_ConfigPreview(cleaned_data))
        except ConfiguracaoInvalidaError as exc:
            raise forms.ValidationError(str(exc)) from exc
        return cleaned_data


class _ConfigPreview:
    """Adaptador leve: expõe os dados ainda não salvos do formulário com os
    mesmos nomes de atributo que `finance_engine.validators` espera de uma
    instância de `ConfiguracaoFinanceira`."""

    def __init__(self, cleaned_data):
        self.percentual_compras = cleaned_data.get("percentual_compras")
        self.percentual_seguranca = cleaned_data.get("percentual_seguranca")
        self.dias_uteis_manual = cleaned_data.get("dias_uteis_manual")
        self.limite_maximo_acumulado = cleaned_data.get("limite_maximo_acumulado")
