from django.urls import path

from . import views, views_analise, views_calendario, views_capacidade, views_planejamento

app_name = "financeiro"

urlpatterns = [
    path("receitas/", views.ReceitaListView.as_view(), name="receita_list"),
    path("receitas/nova/", views.ReceitaCreateView.as_view(), name="receita_create"),
    path("receitas/<int:pk>/editar/", views.ReceitaUpdateView.as_view(), name="receita_update"),
    path("receitas/<int:pk>/excluir/", views.receita_excluir, name="receita_excluir"),
    # Mudança de escopo (lançamento manual) — receitas extras do mês, que
    # somam à receita mensal (faturamento) no Motor Financeiro.
    path("receitas/extras/", views.ReceitaExtraListView.as_view(), name="receitaextra_list"),
    path("receitas/extras/nova/", views.ReceitaExtraCreateView.as_view(), name="receitaextra_create"),
    path("receitas/extras/<int:pk>/editar/", views.ReceitaExtraUpdateView.as_view(), name="receitaextra_update"),
    path("receitas/extras/<int:pk>/excluir/", views.receitaextra_excluir, name="receitaextra_excluir"),
    path("custos-fixos/", views.CustoFixoListView.as_view(), name="custofixo_list"),
    path("custos-fixos/novo/", views.CustoFixoCreateView.as_view(), name="custofixo_create"),
    path("custos-fixos/<int:pk>/editar/", views.CustoFixoUpdateView.as_view(), name="custofixo_update"),
    path("custos-fixos/<int:pk>/excluir/", views.custofixo_excluir, name="custofixo_excluir"),
    path("custos-fixos/<int:pk>/reativar/", views.custofixo_reativar, name="custofixo_reativar"),
    path("custos-variaveis/", views.CustoVariavelListView.as_view(), name="custovariavel_list"),
    path("custos-variaveis/novo/", views.CustoVariavelCreateView.as_view(), name="custovariavel_create"),
    path("custos-variaveis/<int:pk>/editar/", views.CustoVariavelUpdateView.as_view(), name="custovariavel_update"),
    path("custos-variaveis/<int:pk>/excluir/", views.custovariavel_excluir, name="custovariavel_excluir"),
    path("configuracao/", views.configuracao_financeira, name="configuracao"),
    # CORE 1.0 — Agenda Financeira (Épico 3) e Calendário Operacional (Épico 2)
    path("agenda/", views.agenda_financeira, name="agenda"),
    path("agenda/parcela/<int:pk>/baixar/", views.baixar_parcela, name="baixar_parcela"),
    path("agenda/parcela/<int:pk>/estornar/", views.estornar_parcela, name="estornar_parcela"),
    path("calendario-operacional/", views.calendario_operacional, name="calendario_operacional"),
    # Épico 2A (Etapa 04) — hub Planejamento Financeiro + Parcelamentos
    path("planejamento/", views_planejamento.planejamento_home, name="planejamento"),
    path("parcelamentos/", views_planejamento.parcelamentos, name="parcelamentos"),
    # Sprint de Consolidação (Gate 2A, P1-6) — Central de Relatórios
    path("contas-a-pagar/", views_planejamento.contas_a_pagar, name="contas_a_pagar"),
    # RC do Épico 01 (Correção 02) — Calendário Inteligente do Financeiro
    path("calendario/", views_calendario.calendario_financeiro, name="calendario_financeiro"),
    # RC do Épico 01 (Correção 03) — Motor de Capacidade do Financeiro
    path("capacidade-compradores/", views_capacidade.capacidade_compradores, name="capacidade_compradores"),
    path(
        "capacidade-compradores/<int:usuario_id>/limite/",
        views_capacidade.capacidade_definir_limite,
        name="capacidade_definir_limite",
    ),
    path(
        "capacidade-compradores/<int:usuario_id>/bloquear/",
        views_capacidade.capacidade_bloquear,
        name="capacidade_bloquear",
    ),
    path(
        "capacidade-compradores/<int:usuario_id>/liberar/",
        views_capacidade.capacidade_liberar,
        name="capacidade_liberar",
    ),
    # Análise Financeira (mudança de escopo) — Proprietário, Gerente e
    # Financeiro: DRE Gerencial, Créditos × Débitos e Saúde Financeira.
    path("analise/", views_analise.analise_dre, name="analise_dre"),
    path("analise/creditos-debitos/", views_analise.analise_creditos_debitos, name="analise_creditos_debitos"),
    path("analise/saude/", views_analise.analise_saude, name="analise_saude"),
]
