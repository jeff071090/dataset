"""Calendário Inteligente do Financeiro — views (RC do Épico 01, Correção 02).

Toda a agregação vive em `financeiro/services_calendario.py`; estas views
apenas resolvem o contexto (filial, mês, visão, filtros), delegam ao
service e escolhem o template.
"""
from datetime import date, timedelta

from django.shortcuts import render

from core.contexto import filiais_do_contexto
from core.navegacao import pode_acessar
from core.permissions import permissao_required
from usuarios.models import Usuario

from .services import capacidade_configurada
from .services_calendario import (
    ORIGENS_FILTRO,
    detalhe_do_dia_financeiro,
    dias_da_semana_de,
    montar_calendario_financeiro,
)

VISOES = ("mensal", "semanal", "diaria")


def _filial_selecionada(request, filiais):
    filial_id = request.GET.get("filial")
    if filial_id:
        for filial in filiais:
            if str(filial.pk) == str(filial_id):
                return filial
    return filiais[0] if filiais else None


def _dia_selecionado(request, ano: int, mes: int, hoje: date) -> date:
    bruto = request.GET.get("dia", "")
    try:
        dia = date.fromisoformat(bruto)
        if (dia.year, dia.month) == (ano, mes):
            return dia
    except ValueError:
        pass
    if (hoje.year, hoje.month) == (ano, mes):
        return hoje
    return date(ano, mes, 1)


@permissao_required("financeiro.ver")
def calendario_financeiro(request):
    filiais = list(filiais_do_contexto(request))
    hoje = date.today()

    contexto = {"hoje": hoje, "sem_filial": not filiais, "filiais": filiais}
    if not filiais:
        return render(request, "financeiro/calendario_financeiro.html", contexto)

    filial = _filial_selecionada(request, filiais)
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
        date(ano, mes, 1)
    except ValueError:
        ano, mes = hoje.year, hoje.month

    visao = request.GET.get("visao", "mensal")
    if visao not in VISOES:
        visao = "mensal"
    origem = request.GET.get("origem", "")
    pesquisa = request.GET.get("q", "")
    dia_selecionado = _dia_selecionado(request, ano, mes, hoje)

    payload = montar_calendario_financeiro(filial, ano, mes, origem=origem, pesquisa=pesquisa, hoje=hoje)
    detalhe = detalhe_do_dia_financeiro(filial, dia_selecionado, origem=origem, pesquisa=pesquisa)

    mes_anterior = date(ano, mes, 1) - timedelta(days=1)
    proximo_mes = (date(ano, mes, 28) + timedelta(days=7)).replace(day=1)

    contexto.update(
        {
            "filial": filial,
            "ano": ano,
            "mes": mes,
            "data_referencia": date(ano, mes, 1),
            "visao": visao,
            "origem": origem,
            "pesquisa": pesquisa,
            "origens_filtro": ORIGENS_FILTRO,
            "dias": payload["dias"],
            "total_mes_compromissos": payload["total_mes_compromissos"],
            "qtde_mes_compromissos": payload["qtde_mes_compromissos"],
            "dia_selecionado": dia_selecionado,
            "detalhe": detalhe,
            "dias_semana": dias_da_semana_de(payload["dias"], dia_selecionado),
            "mes_anterior": mes_anterior,
            "proximo_mes": proximo_mes,
            # Etapa 02 (Cliente-Ready): mesmo sinal usado no Calendário
            # Inteligente do Comprador — evita pintar o mês inteiro de verde
            # como se a capacidade tivesse sido calculada, quando na
            # verdade falta o Faturamento do mês.
            "capacidade_configurada": capacidade_configurada(filial, ano, mes),
            # Rodada final: os botões do dia só aparecem para quem passa no
            # gate da tela de destino (a própria tela é aberta por
            # financeiro.ver, que o RBAC pode dar a um Gerente).
            "pode_simular": pode_acessar(request.user, perfis=(
                Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO, Usuario.Perfil.COMPRADOR)),
            "pode_excecoes": pode_acessar(request.user, permissao="calendario.configurar"),
            "pode_lancar_receita": pode_acessar(request.user, perfis=(
                Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO)),
        }
    )
    return render(request, "financeiro/calendario_financeiro.html", contexto)
