"""Testes do app `financeiro` (Sprint 5 — "Próximos Compromissos").

Este app ainda não tinha nenhum teste automatizado. Cobre aqui a nova
função `obter_proximos_compromissos`, sobretudo o cálculo da próxima
ocorrência de um Custo Fixo quando o dia de vencimento já passou no mês
atual (deve rolar para o mês seguinte).

Rode com: python manage.py test financeiro
"""
from datetime import date, timedelta
from decimal import Decimal

from django.test import Client, TestCase
from django.test.utils import override_settings

from empresas.models import Empresa
from usuarios.models import Usuario
from filiais.models import Filial

from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, Receita
from .services import _proxima_ocorrencia_mensal, obter_proximos_compromissos


class ProximosCompromissosTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Financeiro", cnpj="77.000.000/0001-77")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")

    def test_custo_fixo_ainda_nao_vencido_no_mes_aparece_este_mes(self):
        CustoFixo.objects.create(
            filial=self.filial, descricao="Aluguel", valor=Decimal("1000"), dia_vencimento=20,
        )
        compromissos = obter_proximos_compromissos(self.filial, date(2026, 6, 10))
        self.assertEqual(len(compromissos), 1)
        self.assertEqual(compromissos[0]["data"], date(2026, 6, 20))

    def test_custo_fixo_ja_vencido_no_mes_rola_para_o_mes_seguinte(self):
        CustoFixo.objects.create(
            filial=self.filial, descricao="Aluguel", valor=Decimal("1000"), dia_vencimento=5,
        )
        # hoje é dia 10 -> dia 5 deste mês já passou -> deve mostrar 5/julho
        compromissos = obter_proximos_compromissos(self.filial, date(2026, 6, 10), dias_janela=30)
        self.assertEqual(len(compromissos), 1)
        self.assertEqual(compromissos[0]["data"], date(2026, 7, 5))

    def test_custo_fixo_inativo_nao_aparece(self):
        CustoFixo.objects.create(
            filial=self.filial, descricao="Aluguel", valor=Decimal("1000"), dia_vencimento=20, ativo=False,
        )
        compromissos = obter_proximos_compromissos(self.filial, date(2026, 6, 10))
        self.assertEqual(compromissos, [])

    def test_custo_variavel_dentro_da_janela_aparece_ordenado(self):
        CustoVariavel.objects.create(
            filial=self.filial, descricao="Frete extra", valor=Decimal("500"), data_prevista=date(2026, 6, 15),
        )
        CustoVariavel.objects.create(
            filial=self.filial, descricao="Manutenção", valor=Decimal("300"), data_prevista=date(2026, 6, 12),
        )
        compromissos = obter_proximos_compromissos(self.filial, date(2026, 6, 10))
        self.assertEqual([c["descricao"] for c in compromissos], ["Manutenção", "Frete extra"])

    def test_custo_variavel_fora_da_janela_nao_aparece(self):
        CustoVariavel.objects.create(
            filial=self.filial, descricao="Distante", valor=Decimal("500"), data_prevista=date(2026, 8, 1),
        )
        compromissos = obter_proximos_compromissos(self.filial, date(2026, 6, 10), dias_janela=14)
        self.assertEqual(compromissos, [])

    def test_limite_restringe_quantidade_retornada(self):
        for dia in (11, 12, 13, 14):
            CustoVariavel.objects.create(
                filial=self.filial, descricao=f"Custo dia {dia}", valor=Decimal("100"),
                data_prevista=date(2026, 6, dia),
            )
        compromissos = obter_proximos_compromissos(self.filial, date(2026, 6, 10), limite=2)
        self.assertEqual(len(compromissos), 2)


class CalendarioOperacionalTestCase(TestCase):
    """Épico 2 (CORE 1.0): tipos de dia, contagem de dias úteis operacionais
    e o efeito de uma exceção sobre o day-walk do Motor Financeiro."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Calendario", cnpj="78.000.000/0001-78")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")

    def test_sem_excecoes_a_contagem_e_identica_a_seg_sex(self):
        from core.utils import dias_uteis_do_mes
        from finance_engine.calendario_operacional import dias_uteis_operacionais

        # Junho/2026: mesma contagem da regra histórica, byte-idêntica.
        self.assertEqual(dias_uteis_operacionais(self.empresa, 2026, 6), dias_uteis_do_mes(2026, 6))

    def test_feriado_reduz_dias_uteis_e_especial_promove_sabado(self):
        from finance_engine.calendario_operacional import dias_uteis_operacionais

        from .models import DiaOperacional

        base = dias_uteis_operacionais(self.empresa, 2026, 6)
        # 12/06/2026 é sexta-feira -> feriado tira 1 dia útil.
        DiaOperacional.objects.create(empresa=self.empresa, data=date(2026, 6, 12), tipo=DiaOperacional.Tipo.FERIADO)
        self.assertEqual(dias_uteis_operacionais(self.empresa, 2026, 6), base - 1)
        # 13/06/2026 é sábado -> "especial" devolve 1 dia que conta capacidade.
        DiaOperacional.objects.create(empresa=self.empresa, data=date(2026, 6, 13), tipo=DiaOperacional.Tipo.ESPECIAL)
        self.assertEqual(dias_uteis_operacionais(self.empresa, 2026, 6), base)

    def test_dia_bloqueado_tem_limite_zero_no_day_walk(self):
        from finance_engine.services import motor_financeiro

        from .models import ConfiguracaoFinanceira, DiaOperacional, Receita

        ConfiguracaoFinanceira.objects.create(empresa=self.empresa)
        Receita.objects.create(filial=self.filial, mes=date(2026, 6, 1), faturamento=Decimal("100000"))

        posicao_antes = motor_financeiro.posicao_do_dia(self.filial, date(2026, 6, 12))
        self.assertGreater(posicao_antes.limite_base, Decimal("0"))

        DiaOperacional.objects.create(empresa=self.empresa, data=date(2026, 6, 12), tipo=DiaOperacional.Tipo.BLOQUEADO)
        posicao_depois = motor_financeiro.posicao_do_dia(self.filial, date(2026, 6, 12))
        self.assertEqual(posicao_depois.limite_base, Decimal("0"))
        self.assertEqual(posicao_depois.tipo_dia, DiaOperacional.Tipo.BLOQUEADO)


class AgendaFinanceiraTestCase(TestCase):
    """Épico 3 (CORE 1.0): a agenda única agrega parcelas, contas fixas,
    contas variáveis e provisões com o contrato pedido (origem/tipo/data/
    valor/status/responsável)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Agenda", cnpj="79.000.000/0001-79")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")

    def test_agenda_agrega_contas_fixas_e_variaveis_no_periodo(self):
        from finance_engine.agenda import gerar_agenda

        CustoFixo.objects.create(filial=self.filial, descricao="Aluguel", valor=Decimal("1000"), dia_vencimento=15)
        CustoVariavel.objects.create(
            filial=self.filial, descricao="Campanha", valor=Decimal("500"), data_prevista=date(2026, 6, 20)
        )
        agenda = gerar_agenda(self.filial, date(2026, 6, 1), date(2026, 6, 30), hoje=date(2026, 6, 1))
        origens = {(item.origem, item.data) for item in agenda}
        self.assertIn(("conta_fixa", date(2026, 6, 15)), origens)
        self.assertIn(("conta_variavel", date(2026, 6, 20)), origens)
        # Contrato do lançamento: todos os campos pedidos pelo Épico 3.
        item = agenda[0]
        self.assertEqual(item.empresa_id, self.empresa.pk)
        for atributo in ("origem", "tipo", "descricao", "data", "valor", "status", "responsavel"):
            self.assertTrue(hasattr(item, atributo))


class CalendarioFinanceiroPlanejamentoTestCase(TestCase):
    """RC do Epico 01 (Correcao 04) — Planejamento: uma compra de 12.000 em
    30/60/90 vira 3 parcelas de 4.000 e cada uma impacta o dia certo do
    Calendario Inteligente do Financeiro; provisoes idem."""

    def setUp(self):
        from cadastros.models import Categoria
        from usuarios.models import Usuario

        self.empresa = Empresa.objects.create(nome="Empresa C04", cnpj="88.000.000/0001-88")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Insumos")
        self.comprador = Usuario.objects.create_user(
            username="comprador_c04", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        # Capacidade folgada: 12.000 cabe no limite e a compra sai APROVADA
        # (regra padrao ALERTA nao bloqueia) — parcelas geradas na hora.
        from financeiro.models import Receita
        Receita.objects.create(filial=self.filial, mes=date(2026, 3, 1), faturamento=Decimal("900000"))
        from financeiro.models import ConfiguracaoFinanceira
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, percentual_compras=Decimal("30"))

    def test_compra_12000_em_30_60_90_gera_3_parcelas_de_4000_no_calendario(self):
        from compras.models import Compra, Fornecedor
        from compras.services import avaliar_e_criar_compra
        from financeiro.services_calendario import detalhe_do_dia_financeiro, montar_calendario_financeiro

        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Agro Alfa")
        data_compra = date(2026, 3, 2)
        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=fornecedor, valor=Decimal("12000.00"),
            categoria=self.categoria, centro_custo=None, data_compra=data_compra,
            prazo_pagamento=Compra.PrazoPagamento.D30_60_90, prazo_personalizado_dias=None,
            numero_parcelas=3, usuario=self.comprador, observacao="",
        )
        compra = avaliacao.compra
        self.assertEqual(compra.status, Compra.Status.APROVADA)

        parcelas = list(compra.parcelas.order_by("numero"))
        self.assertEqual(len(parcelas), 3)
        self.assertTrue(all(p.valor == Decimal("4000.00") for p in parcelas))
        datas_esperadas = [data_compra + timedelta(days=dias) for dias in (30, 60, 90)]
        self.assertEqual([p.data_vencimento for p in parcelas], datas_esperadas)

        # Cada parcela impacta o dia certo do Calendario do Financeiro.
        for data_parcela in datas_esperadas:
            payload = montar_calendario_financeiro(
                self.filial, data_parcela.year, data_parcela.month, hoje=data_compra
            )
            dia = next(d for d in payload["dias"] if d["data"] == data_parcela)
            self.assertGreaterEqual(dia["qtde_compromissos"], 1)
            self.assertGreaterEqual(dia["total_compromissos"], Decimal("4000.00"))

            detalhe = detalhe_do_dia_financeiro(self.filial, data_parcela)
            valores_parcelas = [item.valor for item in detalhe["parcelas"]]
            self.assertIn(Decimal("4000.00"), valores_parcelas)
            self.assertGreaterEqual(detalhe["total_comprometido"], Decimal("4000.00"))

    def test_provisao_impacta_o_dia_do_calendario_do_financeiro(self):
        from compras.models import Fornecedor
        from financeiro.services_calendario import detalhe_do_dia_financeiro
        from gestao_compras.models import Provisao

        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Agro Beta")
        data_alvo = date(2026, 3, 10)
        Provisao.objects.create(
            empresa=self.empresa, filial=self.filial, comprador=self.comprador,
            fornecedor=fornecedor, categoria=self.categoria, data=data_alvo,
            valor_total=Decimal("2500.00"), status=Provisao.Status.PROVISIONADA,
        )
        detalhe = detalhe_do_dia_financeiro(self.filial, data_alvo)
        valores = [item.valor for item in detalhe["provisoes"]]
        self.assertIn(Decimal("2500.00"), valores)


class ProximoVencimentoJanelaDeterministicaTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, P0-3): trava em teste a fórmula
    usada em dashboard/tests_rc.py para gerar um dia_vencimento cuja
    próxima ocorrência SEMPRE cai dentro da janela de 14 dias do
    dashboard, qualquer que seja o dia do mês em que a suíte rodar —
    elimina o teste date-frágil sem enfraquecer nenhuma asserção."""

    def test_formula_da_proxima_ocorrencia_nunca_escapa_da_janela_de_14_dias(self):
        for offset in range(0, 400):
            hoje = date(2026, 1, 1) + timedelta(days=offset)
            dia_vencimento = min((hoje + timedelta(days=6)).day, 28)
            ocorrencia = _proxima_ocorrencia_mensal(dia_vencimento, hoje)
            gap = (ocorrencia - hoje).days
            self.assertGreaterEqual(gap, 1, f"falhou para hoje={hoje}")
            self.assertLessEqual(gap, 13, f"falhou para hoje={hoje}")


class ContasFinanceirasEditarExcluirTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, Parte 6): Receita e Custo Variável
    ganham edição + exclusão real (nenhum outro model referencia essas
    linhas); Custo Fixo já tinha `ativo` — ganha edição + soft-delete de
    verdade. Tudo auditado em LogConfiguracao e escopado pela empresa
    ATIVA do contexto (não pela empresa "de casa" do usuário)."""

    def setUp(self):
        from empresas.models import LogConfiguracao

        self.LogConfiguracao = LogConfiguracao
        self.empresa = Empresa.objects.create(nome="Empresa Teste Contas", cnpj="90.000.000/0001-90")
        self.empresa_b = Empresa.objects.create(nome="Empresa B Contas", cnpj="91.000.000/0001-91")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B")

        self.financeiro = Usuario.objects.create_user(
            username="fin_contas", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.receita = Receita.objects.create(filial=self.filial, mes=date(2026, 8, 1), faturamento=Decimal("100000"))
        self.receita_b = Receita.objects.create(filial=self.filial_b, mes=date(2026, 8, 1), faturamento=Decimal("50000"))
        self.custo_fixo = CustoFixo.objects.create(
            filial=self.filial, descricao="Aluguel Teste", valor=Decimal("5000"), dia_vencimento=10,
        )
        self.custo_variavel = CustoVariavel.objects.create(
            filial=self.filial, descricao="Campanha Teste", valor=Decimal("2000"), data_prevista=date(2026, 8, 20),
        )

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_receita(self):
        resposta = self.client.post(
            f"/financeiro/receitas/{self.receita.pk}/editar/",
            {"filial": self.filial.pk, "mes": "2026-08-01", "faturamento": "150000.00"},
        )
        self.assertEqual(resposta.status_code, 302)
        self.receita.refresh_from_db()
        self.assertEqual(self.receita.faturamento, Decimal("150000.00"))
        self.assertTrue(
            self.LogConfiguracao.objects.filter(area="Contas Financeiras", descricao__icontains="Receita").exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_receita_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.post(
            f"/financeiro/receitas/{self.receita.pk}/editar/",
            {"filial": self.filial.pk, "mes": "2026-08-01", "faturamento": "150000.00"},
        )
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.RECEITA_ALTERADA, id_objeto=self.receita.pk, acao="editar",
        )
        self.assertEqual(registro.estado_antes["faturamento"], "100000.00")
        self.assertEqual(registro.estado_depois["faturamento"], "150000.00")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_receita_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        receita_pk = self.receita.pk
        self.client.post(f"/financeiro/receitas/{receita_pk}/excluir/")
        self.assertTrue(
            RegistroAuditoria.objects.filter(
                categoria=RegistroAuditoria.Categoria.RECEITA_ALTERADA, id_objeto=receita_pk, acao="excluir",
            ).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_custo_fixo_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.post(
            f"/financeiro/custos-fixos/{self.custo_fixo.pk}/editar/",
            {"filial": self.filial.pk, "descricao": "Aluguel Reajustado", "valor": "5500.00",
             "dia_vencimento": "12", "ativo": "on"},
        )
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO, id_objeto=self.custo_fixo.pk, acao="editar",
        )
        self.assertEqual(registro.estado_depois["descricao"], "Aluguel Reajustado")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_desativar_e_reativar_custo_fixo_gera_eventos_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.post(f"/financeiro/custos-fixos/{self.custo_fixo.pk}/excluir/")
        desativado = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO, id_objeto=self.custo_fixo.pk, acao="desativar",
        )
        self.assertEqual(desativado.estado_depois["ativo"], False)

        self.client.post(f"/financeiro/custos-fixos/{self.custo_fixo.pk}/reativar/")
        reativado = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO, id_objeto=self.custo_fixo.pk, acao="reativar",
        )
        self.assertEqual(reativado.estado_depois["ativo"], True)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_e_excluir_custo_variavel_gera_eventos_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.post(
            f"/financeiro/custos-variaveis/{self.custo_variavel.pk}/editar/",
            {"filial": self.filial.pk, "descricao": "Campanha Ajustada", "valor": "2500.00",
             "data_prevista": "2026-08-25"},
        )
        editado = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.CUSTO_VARIAVEL_ALTERADO,
            id_objeto=self.custo_variavel.pk, acao="editar",
        )
        self.assertEqual(editado.estado_depois["descricao"], "Campanha Ajustada")

        self.client.post(f"/financeiro/custos-variaveis/{self.custo_variavel.pk}/excluir/")
        self.assertTrue(
            RegistroAuditoria.objects.filter(
                categoria=RegistroAuditoria.Categoria.CUSTO_VARIAVEL_ALTERADO,
                id_objeto=self.custo_variavel.pk, acao="excluir",
            ).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_receita_de_outra_empresa_e_404(self):
        """Coerência multiempresa: a Receita da empresa B não pode ser
        editada/excluída pelo Financeiro da empresa A."""
        resposta = self.client.get(f"/financeiro/receitas/{self.receita_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)
        resposta = self.client.post(f"/financeiro/receitas/{self.receita_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)
        self.assertTrue(Receita.objects.filter(pk=self.receita_b.pk).exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_receita_remove_de_verdade(self):
        resposta = self.client.post(f"/financeiro/receitas/{self.receita.pk}/excluir/")
        self.assertEqual(resposta.status_code, 302)
        self.assertFalse(Receita.objects.filter(pk=self.receita.pk).exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_custo_fixo(self):
        resposta = self.client.post(
            f"/financeiro/custos-fixos/{self.custo_fixo.pk}/editar/",
            {"filial": self.filial.pk, "descricao": "Aluguel Reajustado", "valor": "5500.00",
             "dia_vencimento": "12", "ativo": "on"},
        )
        self.assertEqual(resposta.status_code, 302)
        self.custo_fixo.refresh_from_db()
        self.assertEqual(self.custo_fixo.descricao, "Aluguel Reajustado")
        self.assertEqual(self.custo_fixo.valor, Decimal("5500.00"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_desativar_e_reativar_custo_fixo_e_soft_delete(self):
        resposta = self.client.post(f"/financeiro/custos-fixos/{self.custo_fixo.pk}/excluir/")
        self.assertEqual(resposta.status_code, 302)
        self.custo_fixo.refresh_from_db()
        self.assertFalse(self.custo_fixo.ativo)
        self.assertTrue(CustoFixo.objects.filter(pk=self.custo_fixo.pk).exists())  # não apagou, só desativou

        resposta = self.client.post(f"/financeiro/custos-fixos/{self.custo_fixo.pk}/reativar/")
        self.assertEqual(resposta.status_code, 302)
        self.custo_fixo.refresh_from_db()
        self.assertTrue(self.custo_fixo.ativo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_e_excluir_custo_variavel(self):
        resposta = self.client.post(
            f"/financeiro/custos-variaveis/{self.custo_variavel.pk}/editar/",
            {"filial": self.filial.pk, "descricao": "Campanha Ajustada", "valor": "2500.00",
             "data_prevista": "2026-08-25"},
        )
        self.assertEqual(resposta.status_code, 302)
        self.custo_variavel.refresh_from_db()
        self.assertEqual(self.custo_variavel.descricao, "Campanha Ajustada")

        resposta = self.client.post(f"/financeiro/custos-variaveis/{self.custo_variavel.pk}/excluir/")
        self.assertEqual(resposta.status_code, 302)
        self.assertFalse(CustoVariavel.objects.filter(pk=self.custo_variavel.pk).exists())


class GateAProprietarioCadastraContasFinanceirasTestCase(TestCase):
    """Prompt 2, Gate A: o Proprietário Operacional também cadastra Receita/
    Custo Fixo/Custo Variável — `PERFIS_CADASTRO` era `(FINANCEIRO,)` só,
    excluindo o Proprietário por engano."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate A Fin", cnpj="95.000.000/0001-95")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Gate A Fin")
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate_a_fin", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
            empresa=self.empresa, is_staff=False, is_superuser=False,
        )
        self.receita = Receita.objects.create(filial=self.filial, mes=date(2026, 8, 1), faturamento=Decimal("100000"))
        self.client = Client()
        self.client.force_login(self.proprietario)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_acessa_formulario_de_nova_receita(self):
        resposta = self.client.get("/financeiro/receitas/nova/")
        self.assertEqual(resposta.status_code, 200)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_edita_receita(self):
        resposta = self.client.post(
            f"/financeiro/receitas/{self.receita.pk}/editar/",
            {"filial": self.filial.pk, "mes": "2026-08-01", "faturamento": "175000.00"},
        )
        self.assertEqual(resposta.status_code, 302)
        self.receita.refresh_from_db()
        self.assertEqual(self.receita.faturamento, Decimal("175000.00"))


class FinanceiroMultiEmpresaContextoTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 10 e 16): "Nova Receita"/"Novo
    Custo Fixo/Variável" passam a oferecer as filiais da EMPRESA ATIVA do
    contexto — antes ficavam presas à empresa "de casa" do usuário mesmo
    depois de trocar de empresa no seletor, achado da auditoria de filiais
    e vínculos."""

    def setUp(self):
        from usuarios.models import UsuarioEmpresa, UsuarioFilial

        self.empresa_a = Empresa.objects.create(nome="Empresa Financeiro A", cnpj="93.000.000/0001-93")
        self.empresa_b = Empresa.objects.create(nome="Empresa Financeiro B", cnpj="94.000.000/0001-94")
        self.filial_a = Filial.objects.create(empresa=self.empresa_a, nome="Filial A")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B")

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_ctx", password="nexbuy123", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)
        # Vínculo explícito nas duas empresas — ver nota em
        # `RelatoriosCSVTestCase` (compras/tests.py): ganhar qualquer
        # `UsuarioFilial` tira o usuário do modo de compatibilidade que cai
        # sozinho na filial principal.
        UsuarioFilial.objects.create(usuario=self.financeiro, filial=self.filial_a, ativo=True)
        UsuarioFilial.objects.create(usuario=self.financeiro, filial=self.filial_b, ativo=True)

        self.client = Client()
        self.client.login(username="financeiro_ctx", password="nexbuy123")

    @override_settings(ALLOWED_HOSTS=["*"])
    def _trocar_para_empresa_b(self):
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_nova_receita_oferece_filiais_da_empresa_ativa_apos_trocar_contexto(self):
        self._trocar_para_empresa_b()
        resposta = self.client.get("/financeiro/receitas/nova/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(list(resposta.context["form"].fields["filial"].queryset), [self.filial_b])

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_receita_na_empresa_ativa_grava_na_filial_correta(self):
        self._trocar_para_empresa_b()
        resposta = self.client.post(
            "/financeiro/receitas/nova/",
            {"filial": self.filial_b.pk, "mes": "2026-08-01", "faturamento": "200000.00"},
        )
        self.assertEqual(
            resposta.status_code, 302,
            resposta.context["form"].errors if resposta.status_code == 200 else "",
        )
        self.assertTrue(Receita.objects.filter(filial=self.filial_b, faturamento=Decimal("200000.00")).exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_novo_custo_fixo_tambem_respeita_a_empresa_ativa(self):
        self._trocar_para_empresa_b()
        resposta = self.client.get("/financeiro/custos-fixos/novo/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(list(resposta.context["form"].fields["filial"].queryset), [self.filial_b])

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_sem_trocar_contexto_nova_receita_continua_na_empresa_de_casa(self):
        resposta = self.client.get("/financeiro/receitas/nova/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(list(resposta.context["form"].fields["filial"].queryset), [self.filial_a])


class ContasAPagarSegmentadoTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 17): Contas a Pagar segmenta os
    compromissos em 3 naturezas distintas — Obrigações Constituídas
    (parcelas de compra já aprovada), Previsões (custo fixo/variável
    configurado) e Provisões (intenção de compra ainda não efetivada) —
    nunca soma tudo num único número sem explicar a natureza de cada
    parte."""

    def setUp(self):
        from cadastros.models import Categoria
        from compras.models import Compra, Fornecedor
        from compras.services import avaliar_e_criar_compra
        from gestao_compras.services import criar_provisao

        self.empresa = Empresa.objects.create(nome="Empresa Contas a Pagar", cnpj="95.000.000/0001-95")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("80"), dias_uteis_manual=20,
        )
        # limite_diario_base = 500000 * 0.8 / 20 = 20000 — folgado o
        # bastante para todo lançamento abaixo nascer já aprovado/
        # provisionado, sem depender do fluxo de aprovação por excesso.
        Receita.objects.create(filial=self.filial, mes=date(2026, 5, 1), faturamento=Decimal("500000"))

        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor CAP")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria CAP")
        self.financeiro = Usuario.objects.create_user(
            username="financeiro_cap", password="nexbuy123", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.comprador = Usuario.objects.create_user(
            username="comprador_cap", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

        avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("1000.00"), categoria=self.categoria,
            data_compra=date(2026, 5, 10), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, usuario=self.comprador,
        )
        CustoFixo.objects.create(
            filial=self.filial, descricao="Aluguel CAP", valor=Decimal("2000.00"), dia_vencimento=15,
        )
        CustoVariavel.objects.create(
            filial=self.filial, descricao="Manutenção CAP", valor=Decimal("300.00"), data_prevista=date(2026, 5, 20),
        )
        criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(2026, 5, 25), observacoes="",
            itens_dados=[{"produto": "Item CAP", "quantidade": 1, "valor_unitario": 500}],
        )

        self.client = Client()
        self.client.login(username="financeiro_cap", password="nexbuy123")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_tela_segmenta_em_3_grupos_com_subtotais_corretos(self):
        resposta = self.client.get("/financeiro/contas-a-pagar/?ano=2026&mes=5")
        self.assertEqual(resposta.status_code, 200)
        grupos = {g["titulo"]: g for g in resposta.context["grupos"]}
        self.assertEqual(set(grupos), {"Obrigações Constituídas", "Previsões", "Provisões"})

        self.assertEqual(grupos["Obrigações Constituídas"]["subtotal"], Decimal("1000.00"))
        self.assertEqual(grupos["Obrigações Constituídas"]["quantidade"], 1)

        self.assertEqual(grupos["Previsões"]["subtotal"], Decimal("2300.00"))
        self.assertEqual(grupos["Previsões"]["quantidade"], 2)

        self.assertEqual(grupos["Provisões"]["subtotal"], Decimal("500.00"))
        self.assertEqual(grupos["Provisões"]["quantidade"], 1)

        self.assertEqual(resposta.context["total_geral"], Decimal("3800.00"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_csv_mostra_a_origem_de_cada_linha_separadamente(self):
        conteudo = self.client.get(
            "/financeiro/contas-a-pagar/?ano=2026&mes=5&formato=csv"
        ).content.decode("utf-8-sig")
        self.assertIn("Obrigações Constituídas", conteudo)
        self.assertIn("Previsões", conteudo)
        self.assertIn("Provisões", conteudo)

        linhas = [linha for linha in conteudo.splitlines() if "Fornecedor CAP" in linha]
        self.assertEqual(len(linhas), 2)  # a parcela da compra + a provisão
        self.assertTrue(any("Obrigações Constituídas" in linha for linha in linhas))
        self.assertTrue(any("Provisões" in linha for linha in linhas))


class BaixarParcelaTestCase(TestCase):
    """`financeiro.baixar_parcela` (Agenda Financeira → "marcar como paga")
    não tinha nenhum teste automatizado. Cobre a baixa em si e as duas
    fronteiras de isolamento (empresa e, cross-GRUPO de verdade, Fechamento
    Final Seção 4.3) já aplicadas nas demais telas do app."""

    def setUp(self):
        from cadastros.models import Categoria
        from compras.models import Compra, Fornecedor, ParcelaCompra

        self.Compra = Compra
        self.Fornecedor = Fornecedor
        self.Categoria = Categoria
        self.ParcelaCompra = ParcelaCompra

        self.empresa = Empresa.objects.create(nome="Empresa Baixa Parcela", cnpj="96.000.000/0001-96")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Baixa Parcela")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Baixa Parcela")

        self.financeiro = Usuario.objects.create_user(
            username="fin_baixa_parcela", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )

        # Datas RELATIVAS a hoje (nunca fixas): a Agenda Financeira só lista
        # o que vence entre hoje-7 e hoje+30 (`financeiro.views.
        # agenda_financeira`). Com vencimento fixo em 01/09/2026 o teste
        # passava em agosto e quebrava a partir de 09/09/2026 ("bomba-
        # relógio" real encontrada em 25/09/2026). hoje+7 fica sempre no
        # meio da janela — pendente e ainda não vencida, como no cenário
        # original —, inclusive em fim de mês/ano e na virada da meia-noite
        # (a janela é em dias corridos, não em mês). A compra mantém os 31
        # dias de prazo do cenário original.
        self.data_vencimento = date.today() + timedelta(days=7)
        self.compra = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, categoria=self.categoria,
            valor=Decimal("1000.00"), data_compra=self.data_vencimento - timedelta(days=31),
            status=Compra.Status.APROVADA,
        )
        self.parcela = ParcelaCompra.objects.create(
            compra=self.compra, numero=1, data_vencimento=self.data_vencimento, valor=Decimal("1000.00"),
            status=ParcelaCompra.Status.PENDENTE,
        )

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_agenda_pode_baixar_reflete_a_permissao_real_do_usuario(self):
        """QA final (Gate 7, Sprint de Encerramento Definitivo): a Agenda
        Financeira estava com `pode_baixar` fixo em `True` — mostrava os
        botões "Baixar"/"Estornar" até para quem não tem `agenda.
        baixar_parcela` (ex.: Gerente com só `agenda.ver`). O POST em si já
        era barrado com 403 no backend; o bug era só a UI oferecer um botão
        que sempre falhava."""
        resposta = self.client.get("/financeiro/agenda/")
        self.assertTrue(resposta.context["pode_baixar"])
        self.assertContains(resposta, 'title="Marcar parcela como paga"')

        # `agenda.ver` e `agenda.baixar_parcela` são exclusivas do Financeiro/
        # Proprietário por padrão (`PERFIS_GESTORES_FINANCEIROS`) — um Gerente
        # só chega na Agenda com uma permissão INDIVIDUAL extra de
        # `agenda.ver` (exatamente como o seed_demo faz para demo_gerente,
        # "perfil Consulta Financeira"), sem ganhar `agenda.baixar_parcela`
        # junto. É esse o cenário real que expôs o bug.
        from usuarios.models import Permissao

        gerente = Usuario.objects.create_user(
            username="ger_agenda_sem_baixar", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        gerente.permissoes_individuais.add(Permissao.objects.get(codigo="agenda.ver"))

        cliente_gerente = Client()
        cliente_gerente.force_login(gerente)
        resposta_gerente = cliente_gerente.get("/financeiro/agenda/")
        self.assertEqual(resposta_gerente.status_code, 200)
        # A parcela PRECISA estar na Agenda do Gerente — senão o
        # assertNotContains abaixo passaria "de graça" (sem botão porque
        # não há linha, não por falta de permissão), exatamente o que
        # acontecia quando o vencimento fixo saía da janela.
        self.assertIn(
            self.parcela.pk,
            [item.referencia_id for item in resposta_gerente.context["lancamentos"] if item.origem == "parcela"],
        )
        self.assertFalse(resposta_gerente.context["pode_baixar"])
        self.assertNotContains(resposta_gerente, 'title="Marcar parcela como paga"')

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_baixar_parcela_pendente_marca_como_paga(self):
        resposta = self.client.post(f"/financeiro/agenda/parcela/{self.parcela.pk}/baixar/")
        self.assertEqual(resposta.status_code, 302)
        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, self.ParcelaCompra.Status.PAGA)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_baixar_parcela_gera_evento_na_central_de_auditoria(self):
        """Prompt 2, Gate D (Seção 9): categoria própria `PARCELA_BAIXADA`."""
        from auditoria.models import RegistroAuditoria

        self.client.post(f"/financeiro/agenda/parcela/{self.parcela.pk}/baixar/")
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.PARCELA_BAIXADA, id_objeto=self.parcela.pk,
        )
        self.assertEqual(registro.estado_depois["status"], "paga")
        self.assertEqual(registro.usuario_id, self.financeiro.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_estornar_parcela_paga_volta_a_pendente_com_justificativa(self):
        """Prompt 2 (pré-Etapa 02), Gates A/D/E/F: baixar e depois estornar
        devolve a MESMA parcela a pendente (nunca cria uma nova), exige
        justificativa e gera evento próprio (`PARCELA_ESTORNADA`)."""
        from auditoria.models import RegistroAuditoria

        self.client.post(f"/financeiro/agenda/parcela/{self.parcela.pk}/baixar/")
        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, self.ParcelaCompra.Status.PAGA)

        resposta = self.client.post(
            f"/financeiro/agenda/parcela/{self.parcela.pk}/estornar/",
            {"justificativa": "Baixa lançada na parcela errada por engano."},
        )
        self.assertEqual(resposta.status_code, 302)
        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, self.ParcelaCompra.Status.PENDENTE)
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra).count(), 1)

        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.PARCELA_ESTORNADA, id_objeto=self.parcela.pk,
        )
        self.assertEqual(registro.estado_antes["status"], "paga")
        self.assertEqual(registro.estado_depois["status"], "pendente")
        self.assertEqual(registro.usuario_id, self.financeiro.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_estornar_parcela_sem_justificativa_nao_altera_nada(self):
        self.client.post(f"/financeiro/agenda/parcela/{self.parcela.pk}/baixar/")
        resposta = self.client.post(f"/financeiro/agenda/parcela/{self.parcela.pk}/estornar/", {"justificativa": ""})
        self.assertEqual(resposta.status_code, 302)
        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, self.ParcelaCompra.Status.PAGA)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_estornar_parcela_pendente_e_404(self):
        """Só uma parcela PAGA pode ser estornada — a queryset da view já
        filtra por `status=PAGA`, então uma pendente vira 404, não um
        estorno silencioso sem efeito."""
        resposta = self.client.post(
            f"/financeiro/agenda/parcela/{self.parcela.pk}/estornar/", {"justificativa": "x"},
        )
        self.assertEqual(resposta.status_code, 404)
        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, self.ParcelaCompra.Status.PENDENTE)

    def test_service_estornar_parcela_recusa_parcela_pendente(self):
        """Defesa em profundidade: mesmo chamando o service direto (sem
        passar pela queryset filtrada da view), uma parcela PENDENTE não
        pode ser estornada."""
        from django.core.exceptions import ValidationError

        from compras.services import estornar_parcela

        with self.assertRaises(ValidationError):
            estornar_parcela(self.parcela, self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_baixar_parcela_de_outra_empresa_e_404(self):
        """Coerência multiempresa: a parcela de uma Compra de outra empresa
        (sem grupo) não pode ser baixada pelo Financeiro desta empresa."""
        empresa_outra = Empresa.objects.create(nome="Empresa Baixa Parcela Outra", cnpj="97.000.000/0001-97")
        filial_outra = Filial.objects.create(empresa=empresa_outra, nome="Filial Outra")
        fornecedor_outra = self.Fornecedor.objects.create(empresa=empresa_outra, nome="Fornecedor Outra")
        categoria_outra = self.Categoria.objects.create(empresa=empresa_outra, nome="Categoria Outra")
        compra_outra = self.Compra.objects.create(
            empresa=empresa_outra, filial=filial_outra, fornecedor=fornecedor_outra, categoria=categoria_outra,
            valor=Decimal("700.00"), data_compra=date(2026, 8, 1), status=self.Compra.Status.APROVADA,
        )
        parcela_outra = self.ParcelaCompra.objects.create(
            compra=compra_outra, numero=1, data_vencimento=date(2026, 9, 1), valor=Decimal("700.00"),
            status=self.ParcelaCompra.Status.PENDENTE,
        )

        resposta = self.client.get(f"/financeiro/agenda/parcela/{parcela_outra.pk}/baixar/")
        self.assertEqual(resposta.status_code, 404)
        resposta = self.client.post(f"/financeiro/agenda/parcela/{parcela_outra.pk}/baixar/")
        self.assertEqual(resposta.status_code, 404)

        parcela_outra.refresh_from_db()
        self.assertEqual(parcela_outra.status, self.ParcelaCompra.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_baixar_parcela_de_outro_grupo_e_404(self):
        """Fechamento Final, Seção 4.3: variante cross-GRUPO de verdade (não
        só cross-empresa) — duas `GrupoEmpresarial` distintas, uma Empresa
        em cada, e uma autorização `UsuarioEmpresa` ATIVA cruzando os dois
        Grupos (simula dado legado/inconsistente). Mesmo assim a troca de
        contexto não é efetivada e a baixa da parcela do outro grupo
        continua 404 — a autorização sozinha não basta, o Grupo diferente
        bloqueia por cima."""
        from empresas.models import GrupoEmpresarial
        from usuarios.models import UsuarioEmpresa

        grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo Baixa Parcela 1")
        grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo Baixa Parcela 2")
        self.empresa.grupo = grupo_1
        self.empresa.save(update_fields=["grupo"])

        empresa_b = Empresa.objects.create(
            nome="Empresa Baixa Parcela Grupo 2", cnpj="98.000.000/0001-98", grupo=grupo_2,
        )
        filial_b = Filial.objects.create(empresa=empresa_b, nome="Filial Grupo 2")
        fornecedor_b = self.Fornecedor.objects.create(empresa=empresa_b, nome="Fornecedor Grupo 2")
        categoria_b = self.Categoria.objects.create(empresa=empresa_b, nome="Categoria Grupo 2")
        compra_b = self.Compra.objects.create(
            empresa=empresa_b, filial=filial_b, fornecedor=fornecedor_b, categoria=categoria_b,
            valor=Decimal("800.00"), data_compra=date(2026, 8, 1), status=self.Compra.Status.APROVADA,
        )
        parcela_b = self.ParcelaCompra.objects.create(
            compra=compra_b, numero=1, data_vencimento=date(2026, 9, 1), valor=Decimal("800.00"),
            status=self.ParcelaCompra.Status.PENDENTE,
        )

        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=empresa_b, ativo=True)

        resposta = self.client.post("/trocar-empresa/", {"empresa_id": empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)
        self.assertNotEqual(self.client.session.get("empresa_ativa_id"), empresa_b.pk)

        resposta = self.client.post(f"/financeiro/agenda/parcela/{parcela_b.pk}/baixar/")
        self.assertEqual(resposta.status_code, 404)
        parcela_b.refresh_from_db()
        self.assertEqual(parcela_b.status, self.ParcelaCompra.Status.PENDENTE)


class CustosCrossTenantTestCase(TestCase):
    """Revisão adversarial: `ContasFinanceirasEditarExcluirTestCase` já
    prova a coerência multiempresa para Receita — esta classe espelha
    exatamente o mesmo padrão (`test_excluir_receita_de_outra_empresa_e_404`)
    para Custo Fixo e Custo Variável, que ainda não tinham essa cobertura."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Custos Cross Tenant", cnpj="96.200.000/0001-20")
        self.empresa_b = Empresa.objects.create(nome="Empresa B Custos Cross Tenant", cnpj="96.300.000/0001-30")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B")

        self.financeiro = Usuario.objects.create_user(
            username="fin_custos_cross", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.custo_fixo_b = CustoFixo.objects.create(
            filial=self.filial_b, descricao="Aluguel B", valor=Decimal("3000"), dia_vencimento=10,
        )
        self.custo_variavel_b = CustoVariavel.objects.create(
            filial=self.filial_b, descricao="Campanha B", valor=Decimal("1500"), data_prevista=date(2026, 8, 20),
        )

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_e_excluir_custo_fixo_de_outra_empresa_e_404(self):
        resposta = self.client.get(f"/financeiro/custos-fixos/{self.custo_fixo_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)
        resposta = self.client.post(f"/financeiro/custos-fixos/{self.custo_fixo_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)

        self.custo_fixo_b.refresh_from_db()
        self.assertTrue(self.custo_fixo_b.ativo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_e_excluir_custo_variavel_de_outra_empresa_e_404(self):
        resposta = self.client.get(f"/financeiro/custos-variaveis/{self.custo_variavel_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)
        resposta = self.client.post(f"/financeiro/custos-variaveis/{self.custo_variavel_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)

        self.assertTrue(CustoVariavel.objects.filter(pk=self.custo_variavel_b.pk).exists())


class ReceitaCrossGrupoTestCase(TestCase):
    """Fechamento Final, Seção 4.3: variante cross-GRUPO de verdade (não só
    cross-empresa) de `test_excluir_receita_de_outra_empresa_e_404` — duas
    `GrupoEmpresarial` distintas, cada uma com sua Empresa, e uma
    autorização `UsuarioEmpresa` ATIVA cruzando os dois Grupos (simula dado
    legado/inconsistente). A autorização sozinha não basta — o Grupo
    diferente bloqueia por cima, tanto na troca de contexto quanto no
    acesso direto à Receita."""

    def setUp(self):
        from empresas.models import GrupoEmpresarial
        from usuarios.models import UsuarioEmpresa

        self.grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo Receita 1")
        self.grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo Receita 2")

        self.empresa_a = Empresa.objects.create(
            nome="Empresa A Receita Grupo 1", cnpj="96.400.000/0001-40", grupo=self.grupo_1,
        )
        self.empresa_b = Empresa.objects.create(
            nome="Empresa B Receita Grupo 2", cnpj="96.500.000/0001-50", grupo=self.grupo_2,
        )
        self.filial_a = Filial.objects.create(empresa=self.empresa_a, nome="Filial A")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B")

        self.receita_b = Receita.objects.create(
            filial=self.filial_b, mes=date(2026, 8, 1), faturamento=Decimal("60000"),
        )

        self.financeiro = Usuario.objects.create_user(
            username="fin_receita_cross_grupo", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        # Autorização ATIVA cruzando os dois Grupos — simula dado legado/
        # inconsistente: o registro existe e está ativo, mas a Empresa
        # autorizada pertence a um Grupo comprovadamente diferente do Grupo
        # da empresa principal do usuário.
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_trocar_para_empresa_de_outro_grupo_nao_e_efetivado(self):
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)
        self.assertNotEqual(self.client.session.get("empresa_ativa_id"), self.empresa_b.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_receita_de_outro_grupo_continua_404_mesmo_com_autorizacao_ativa(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})

        resposta = self.client.get(f"/financeiro/receitas/{self.receita_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)

        resposta = self.client.post(
            f"/financeiro/receitas/{self.receita_b.pk}/editar/",
            {"filial": self.filial_b.pk, "mes": "2026-08-01", "faturamento": "999999.00"},
        )
        self.assertEqual(resposta.status_code, 404)
        self.receita_b.refresh_from_db()
        self.assertEqual(self.receita_b.faturamento, Decimal("60000"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_receita_de_outro_grupo_continua_404_mesmo_com_autorizacao_ativa(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})

        resposta = self.client.post(f"/financeiro/receitas/{self.receita_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)
        self.assertTrue(Receita.objects.filter(pk=self.receita_b.pk).exists())


class GateDConfiguracaoECalendarioAuditoriaTestCase(TestCase):
    """Prompt 2, Gate D (Seção 9): salvar a Configuração Financeira e criar/
    remover exceções do Calendário Operacional geram eventos próprios na
    Central de Auditoria (`CONFIGURACAO_FINANCEIRA_ALTERADA` e
    `DIA_OPERACIONAL_ALTERADO`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Config Gate D", cnpj="68.000.000/0001-68")
        self.financeiro = Usuario.objects.create_user(
            username="fin_config_gate_d", password="x", perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa,
        )
        self.config = ConfiguracaoFinanceira.objects.create(empresa=self.empresa)
        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_salvar_configuracao_financeira_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.post("/financeiro/configuracao/", {
            "percentual_compras": "40.00", "percentual_seguranca": "0",
            "permitir_saldo_acumulativo": "", "redistribuicao_automatica": "",
            "permitir_ultrapassar_limite": "", "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA,
            "cor_principal": "#E11D2E", "moeda": ConfiguracaoFinanceira.Moeda.BRL,
        })
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.CONFIGURACAO_FINANCEIRA_ALTERADA, id_objeto=self.config.pk,
        )
        self.assertEqual(registro.estado_antes["percentual_compras"], "30.00")
        self.assertEqual(registro.estado_depois["percentual_compras"], "40.00")
        self.assertEqual(registro.usuario_id, self.financeiro.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_e_remover_excecao_de_calendario_gera_eventos_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        from .models import DiaOperacional

        self.client.post("/financeiro/calendario-operacional/", {
            "data": "2026-08-20", "tipo": DiaOperacional.Tipo.FERIADO, "observacao": "Feriado municipal",
        })
        dia = DiaOperacional.objects.get(empresa=self.empresa, data=date(2026, 8, 20))
        criado = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.DIA_OPERACIONAL_ALTERADO, id_objeto=dia.pk, acao="dia_operacional",
        )
        self.assertEqual(criado.estado_depois["tipo"], DiaOperacional.Tipo.FERIADO)

        self.client.post("/financeiro/calendario-operacional/", {"acao": "remover", "dia_id": dia.pk})
        removido = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.DIA_OPERACIONAL_ALTERADO, id_objeto=dia.pk, acao="remover_dia",
        )
        self.assertEqual(removido.estado_antes["tipo"], DiaOperacional.Tipo.FERIADO)
