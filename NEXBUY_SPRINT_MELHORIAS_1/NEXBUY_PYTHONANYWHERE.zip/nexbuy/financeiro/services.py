"""Regras de cálculo da capacidade financeira de compra.

A partir da Sprint 3, toda a matemática foi centralizada no Motor
Financeiro (`finance_engine`) — este módulo passou a ser uma camada de
compatibilidade: mantém a mesma assinatura e o mesmo formato de retorno
(dict) usados pelas Sprints anteriores, delegando o cálculo para
`finance_engine.services.CapacidadeCompraService`. Nenhum código que já
chamava `calcular_capacidade_compra` precisou mudar (ver
`Arquitetura.md`, seção "Migração de responsabilidades").

Fórmula do NEXBUY (detalhada em `finance_engine/calculations.py`):

    Receita do mês = Receita mensal (faturamento) + Receitas extras do mês
    Receita do mês - Custos Fixos - Custos Variáveis = Disponibilidade Financeira
    Disponibilidade Financeira x Percentual de Compras = Capacidade Mensal de Compra
    Capacidade Mensal (- Percentual de Segurança) = Capacidade Mensal Ajustada
    Capacidade Mensal Ajustada / Dias Úteis = Limite Diário de Compra
"""
import calendar as calendar_module
from datetime import date, timedelta

from decimal import Decimal

from finance_engine.services import (
    CapacidadeCompraService,
    obter_configuracao,
    obter_receita_do_mes,
    receita_configurada,
)

from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel

__all__ = [
    "obter_configuracao",
    "calcular_disponibilidade_financeira",
    "calcular_capacidade_compra",
    "capacidade_configurada",
    "obter_proximos_compromissos",
    "obter_receita_do_mes",
    "resumo_receitas_do_mes",
    "receita_da_empresa_no_mes",
]

ZERO = Decimal("0")

_capacidade_service = CapacidadeCompraService()


def capacidade_configurada(filial, ano=None, mes=None) -> bool:
    """Etapa 02 (Cliente-Ready): diz se já existe receita cadastrada da
    filial para o mês informado — usado pelas telas para diferenciar
    "ainda não há dado suficiente para calcular a capacidade" (nenhuma
    receita cadastrada nesse mês, cenário normal logo após o Primeiro
    Acesso) de "capacidade calculada e deu zero/negativa" (há receita, mas
    os custos consomem tudo).

    Receita, aqui, é a receita mensal (faturamento) OU qualquer receita
    extra do mês — as duas alimentam o Motor. A checagem vive no Motor
    (`finance_engine.services.receita_configurada`), fonte única."""
    hoje = date.today()
    ano = ano or hoje.year
    mes = mes or hoje.month
    return receita_configurada(filial, ano, mes)


def resumo_receitas_do_mes(filiais, ano, mes) -> dict:
    """Receita do mês por filial, decomposta em receita mensal
    (faturamento) + receitas extras, com os totais — usado pela tela de
    Receitas. Lê do MESMO `obter_receita_do_mes` que o Motor usa para
    calcular a capacidade, então o total mostrado aqui é sempre o mesmo que
    alimenta o limite diário e os dashboards."""
    linhas = []
    for filial in filiais:
        receita = obter_receita_do_mes(filial, ano, mes)
        linhas.append(
            {
                "filial": filial,
                "receita_mensal": receita.receita_mensal,
                "receitas_extras": receita.receitas_extras,
                "quantidade_extras": receita.quantidade_extras,
                "total": receita.total,
                "tem_receita_mensal": receita.tem_receita_mensal,
                "configurada": receita.configurada,
            }
        )
    return {
        "linhas": linhas,
        "receita_mensal": sum((linha["receita_mensal"] for linha in linhas), ZERO),
        "receitas_extras": sum((linha["receitas_extras"] for linha in linhas), ZERO),
        "total": sum((linha["total"] for linha in linhas), ZERO),
        "configurada": any(linha["configurada"] for linha in linhas),
    }


def receita_da_empresa_no_mes(empresa, ano, mes) -> dict:
    """Receita consolidada da empresa no mês (filiais ATIVAS — o mesmo
    recorte do resumo por filial e do "saldo disponível" do Dashboard do
    Proprietário), decomposta em receita mensal + receitas extras."""
    return resumo_receitas_do_mes(empresa.filiais.filter(ativo=True), ano, mes)


def calcular_disponibilidade_financeira(filial, ano, mes):
    """Mantido por compatibilidade — devolve apenas o bloco de
    disponibilidade (sem capacidade mensal/limite diário). Para o cálculo
    completo, use `calcular_capacidade_compra`."""
    resultado = _capacidade_service.calcular(filial, ano, mes)
    return {
        "faturamento": resultado.faturamento,
        "receita_mensal": resultado.receita_mensal,
        "receitas_extras": resultado.receitas_extras,
        "custos_fixos": resultado.custos_fixos,
        "custos_variaveis": resultado.custos_variaveis,
        "disponibilidade": resultado.disponibilidade,
    }


def calcular_capacidade_compra(filial, ano=None, mes=None):
    """Calcula toda a cadeia: disponibilidade -> capacidade mensal -> limite
    diário. Implementação delegada ao Motor Financeiro (`finance_engine`);
    esta função existe para não quebrar quem já a importava de
    `financeiro.services`."""
    hoje = date.today()
    ano = ano or hoje.year
    mes = mes or hoje.month

    resultado = _capacidade_service.calcular(filial, ano, mes)
    config = obter_configuracao(filial.empresa)

    return {
        # `faturamento` = receita TOTAL do mês (receita mensal + receitas
        # extras); as duas partes vêm logo abaixo, para quem precisar exibir
        # a decomposição.
        "faturamento": resultado.faturamento,
        "receita_mensal": resultado.receita_mensal,
        "receitas_extras": resultado.receitas_extras,
        "custos_fixos": resultado.custos_fixos,
        "custos_variaveis": resultado.custos_variaveis,
        "disponibilidade": resultado.disponibilidade,
        "percentual_compras": resultado.percentual_compra,
        "percentual_seguranca": resultado.percentual_seguranca,
        "capacidade_mensal": resultado.capacidade_mensal,
        "capacidade_mensal_ajustada": resultado.capacidade_mensal_ajustada,
        "dias_uteis": resultado.dias_uteis,
        "limite_diario": resultado.limite_diario_base,
        "regra_excesso": config.regra_excesso if config else ConfiguracaoFinanceira.RegraExcesso.ALERTA,
        "permitir_saldo_acumulativo": config.permitir_saldo_acumulativo if config else False,
        "capacidade_configurada": resultado.receita_configurada,
    }


def _proxima_ocorrencia_mensal(dia_vencimento: int, data_referencia: date) -> date:
    """Próxima data em que um Custo Fixo (dia fixo do mês) vence, a partir
    de `data_referencia` — pode cair neste mês ou rolar para o mês seguinte
    (dias > último dia do mês são ajustados, ex.: dia 31 num mês de 30)."""
    ultimo_dia_mes_atual = calendar_module.monthrange(data_referencia.year, data_referencia.month)[1]
    data_neste_mes = data_referencia.replace(day=min(dia_vencimento, ultimo_dia_mes_atual))
    if data_neste_mes > data_referencia:
        return data_neste_mes

    ano_prox = data_referencia.year + (1 if data_referencia.month == 12 else 0)
    mes_prox = 1 if data_referencia.month == 12 else data_referencia.month + 1
    ultimo_dia_prox_mes = calendar_module.monthrange(ano_prox, mes_prox)[1]
    return date(ano_prox, mes_prox, min(dia_vencimento, ultimo_dia_prox_mes))


def obter_proximos_compromissos(filial, data_referencia: date, limite: int = 5, dias_janela: int = 14) -> list:
    """Lista unificada dos próximos vencimentos financeiros da filial —
    Custos Fixos (recorrentes, por dia do mês) e Custos Variáveis (data
    específica) — usada pelo card "Próximos Compromissos" e pela Central de
    Decisão do Dashboard (Sprint 5). Não recalcula nenhuma regra financeira:
    é apenas uma leitura ordenada de datas já cadastradas."""
    fim_janela = data_referencia + timedelta(days=dias_janela)
    compromissos = []

    for custo in CustoFixo.objects.filter(filial=filial, ativo=True):
        proxima_data = _proxima_ocorrencia_mensal(custo.dia_vencimento, data_referencia)
        if proxima_data <= fim_janela:
            compromissos.append(
                {"descricao": custo.descricao, "valor": custo.valor, "data": proxima_data, "tipo": "Custo Fixo"}
            )

    variaveis = CustoVariavel.objects.filter(
        filial=filial, data_prevista__gt=data_referencia, data_prevista__lte=fim_janela
    )
    for custo in variaveis:
        compromissos.append(
            {"descricao": custo.descricao, "valor": custo.valor, "data": custo.data_prevista, "tipo": "Custo Variável"}
        )

    compromissos.sort(key=lambda c: c["data"])
    return compromissos[:limite]


def contar_compromissos_em(filial, data_alvo: date) -> int:
    """RC do Épico 01 (Correção 01): CONTAGEM de compromissos financeiros de
    uma data — um inteiro agregado, sem descrição nem valor. É a única
    informação derivada de contas que a Central de Decisão do COMPRADOR
    recebe ("amanhã existem muitos compromissos"); a lista detalhada
    (`obter_proximos_compromissos`) é exclusiva dos perfis financeiros."""
    referencia = data_alvo - timedelta(days=1)
    compromissos = obter_proximos_compromissos(filial, referencia, limite=100, dias_janela=1)
    return sum(1 for compromisso in compromissos if compromisso["data"] == data_alvo)
