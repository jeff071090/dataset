"""Testes das Receitas Extras (mudança de escopo — lançamento 100% manual).

A receita do mês que alimenta o Motor Financeiro passa a ser a receita
mensal (`Receita.faturamento`) + a soma das `ReceitaExtra` com data no
mês. Cobre: constraint de valor, motor (valores Decimal exatos),
"capacidade configurada" só com extras, CRUD com RBAC e isolamento entre
empresas, auditoria, contrato do Comprador (nenhum dado de receita) e o
total consistente entre a tela de Receitas e os dashboards.

Rode com: python manage.py test financeiro.tests_receitas_extras
"""
import re
from datetime import date, timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.test import Client, TestCase, TransactionTestCase

from auditoria.models import RegistroAuditoria
from dashboard.viewmodels import CHAVES_PROIBIDAS_COMPRADOR, CHAVES_PROIBIDAS_GERENTE, viewmodel_comprador, viewmodel_gerente
from empresas.models import Empresa
from filiais.models import Filial
from finance_engine.services import motor_financeiro, obter_receita_do_mes
from usuarios.models import Usuario

from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, Receita, ReceitaExtra
from .services import calcular_capacidade_compra, capacidade_configurada, resumo_receitas_do_mes

TERMOS_PROIBIDOS = ("None", "NaN", "Infinity", "Traceback (most recent", "Internal Server Error")


def _mes_atual():
    return date.today().replace(day=1)


def _outro_mes(referencia):
    """Primeiro dia do mês anterior ao de `referencia`."""
    return (referencia - timedelta(days=1)).replace(day=1)


class ReceitaExtraModelTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Extra Model", cnpj="81.000.000/0001-81")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Extra Model")

    def test_empresa_e_preenchida_a_partir_da_filial(self):
        extra = ReceitaExtra.objects.create(
            filial=self.filial, data=date(2026, 8, 12), descricao="Serviço", valor=Decimal("10.00"),
        )
        self.assertEqual(extra.empresa, self.empresa)
        self.assertEqual(extra.categoria, ReceitaExtra.Categoria.OUTRAS)

    def test_banco_recusa_valor_zero(self):
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                ReceitaExtra.objects.create(
                    filial=self.filial, data=date(2026, 8, 12), descricao="Zero", valor=Decimal("0"),
                )

    def test_banco_recusa_valor_negativo(self):
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                ReceitaExtra.objects.create(
                    filial=self.filial, data=date(2026, 8, 12), descricao="Negativo", valor=Decimal("-5.00"),
                )

    def test_validator_do_model_recusa_zero(self):
        extra = ReceitaExtra(filial=self.filial, empresa=self.empresa, data=date(2026, 8, 12),
                             descricao="Zero", valor=Decimal("0"))
        with self.assertRaises(ValidationError) as contexto:
            extra.full_clean()
        self.assertIn("valor", contexto.exception.message_dict)

    def test_centavo_e_o_menor_valor_aceito(self):
        extra = ReceitaExtra(filial=self.filial, empresa=self.empresa, data=date(2026, 8, 12),
                             descricao="Centavo", valor=Decimal("0.01"))
        extra.full_clean()  # não levanta
        extra.save()
        self.assertTrue(ReceitaExtra.objects.filter(pk=extra.pk).exists())


class MotorSomaReceitasExtrasTestCase(TestCase):
    """O Motor soma as receitas extras do mês à receita mensal — valores
    Decimal exatos em toda a cadeia (disponibilidade → capacidade → limite)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Motor Extra", cnpj="82.000.000/0001-82")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Motor Extra")
        self.outra_filial = Filial.objects.create(empresa=self.empresa, nome="Filial 2 Motor Extra")
        # dias úteis manuais: denominador determinístico, independente do mês.
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("30"), dias_uteis_manual=20,
        )
        self.ano, self.mes = 2026, 8
        Receita.objects.create(filial=self.filial, mes=date(2026, 8, 1), faturamento=Decimal("100000.00"))
        CustoFixo.objects.create(filial=self.filial, descricao="Aluguel", valor=Decimal("10000.00"), dia_vencimento=10)
        CustoVariavel.objects.create(
            filial=self.filial, descricao="Campanha", valor=Decimal("2000.00"), data_prevista=date(2026, 8, 20),
        )

    def _extra(self, data, valor, filial=None, categoria=ReceitaExtra.Categoria.OUTRAS):
        return ReceitaExtra.objects.create(
            filial=filial or self.filial, data=data, descricao=f"Extra {valor}", valor=Decimal(valor),
            categoria=categoria,
        )

    def test_sem_extras_o_resultado_e_identico_ao_historico(self):
        resultado = motor_financeiro.capacidade_do_mes(self.filial, self.ano, self.mes)
        self.assertEqual(resultado.faturamento, Decimal("100000.00"))
        self.assertEqual(resultado.receita_mensal, Decimal("100000.00"))
        self.assertEqual(resultado.receitas_extras, Decimal("0"))
        self.assertEqual(resultado.disponibilidade, Decimal("88000.00"))
        self.assertEqual(resultado.limite_diario_base, Decimal("1320"))

    def test_extras_do_mes_somam_a_receita_e_mudam_a_capacidade(self):
        self._extra(date(2026, 8, 3), "1500.50", categoria=ReceitaExtra.Categoria.SERVICOS)
        self._extra(date(2026, 8, 31), "499.50", categoria=ReceitaExtra.Categoria.CONVENIOS)
        # Fora do mês / de outra filial: não entram.
        self._extra(date(2026, 7, 31), "7777.77")
        self._extra(date(2026, 9, 1), "8888.88")
        self._extra(date(2026, 8, 15), "9999.99", filial=self.outra_filial)

        resultado = motor_financeiro.capacidade_do_mes(self.filial, self.ano, self.mes)
        for campo in ("faturamento", "receita_mensal", "receitas_extras", "disponibilidade",
                      "capacidade_mensal", "capacidade_mensal_ajustada", "limite_diario_base"):
            self.assertIsInstance(getattr(resultado, campo), Decimal, campo)
        self.assertEqual(resultado.receita_mensal, Decimal("100000.00"))
        self.assertEqual(resultado.receitas_extras, Decimal("2000.00"))
        self.assertEqual(resultado.faturamento, Decimal("102000.00"))
        # 102000 - 10000 - 2000 = 90000 → × 30% = 27000 → ÷ 20 = 1350
        self.assertEqual(resultado.disponibilidade, Decimal("90000.00"))
        self.assertEqual(resultado.capacidade_mensal, Decimal("27000"))
        self.assertEqual(resultado.capacidade_mensal_ajustada, Decimal("27000"))
        self.assertEqual(resultado.limite_diario_base, Decimal("1350"))
        self.assertTrue(resultado.receita_configurada)

    def test_limite_diario_do_day_walk_reflete_as_extras(self):
        antes = motor_financeiro.posicao_do_dia(self.filial, date(2026, 8, 10)).limite_base
        self._extra(date(2026, 8, 3), "2000.00")
        depois = motor_financeiro.posicao_do_dia(self.filial, date(2026, 8, 10)).limite_base
        # + R$ 2.000 de receita → + R$ 600 de capacidade → + R$ 30/dia (20 dias)
        self.assertEqual(depois - antes, Decimal("30"))

    def test_compatibilidade_calcular_capacidade_compra_expoe_a_decomposicao(self):
        self._extra(date(2026, 8, 3), "2000.00")
        capacidade = calcular_capacidade_compra(self.filial, self.ano, self.mes)
        self.assertEqual(capacidade["faturamento"], Decimal("102000.00"))
        self.assertEqual(capacidade["receita_mensal"], Decimal("100000.00"))
        self.assertEqual(capacidade["receitas_extras"], Decimal("2000.00"))
        self.assertEqual(capacidade["limite_diario"], Decimal("1350"))
        self.assertTrue(capacidade["capacidade_configurada"])

    def test_resumo_da_tela_de_receitas_usa_a_mesma_fonte_do_motor(self):
        self._extra(date(2026, 8, 3), "1500.50")
        self._extra(date(2026, 8, 15), "250.00", filial=self.outra_filial)
        resumo = resumo_receitas_do_mes([self.filial, self.outra_filial], self.ano, self.mes)
        motor_total = sum(
            (motor_financeiro.capacidade_do_mes(f, self.ano, self.mes).faturamento
             for f in (self.filial, self.outra_filial)),
            Decimal("0"),
        )
        self.assertEqual(resumo["total"], motor_total)
        self.assertEqual(resumo["total"], Decimal("101750.50"))
        self.assertEqual(resumo["receita_mensal"], Decimal("100000.00"))
        self.assertEqual(resumo["receitas_extras"], Decimal("1750.50"))


class CapacidadeConfiguradaSoComExtrasTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Config Extra", cnpj="83.000.000/0001-83")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Config Extra")

    def test_sem_nenhuma_receita_nao_esta_configurada(self):
        self.assertFalse(capacidade_configurada(self.filial, 2026, 8))
        self.assertFalse(obter_receita_do_mes(self.filial, 2026, 8).configurada)

    def test_so_com_receita_extra_no_mes_fica_configurada(self):
        ReceitaExtra.objects.create(filial=self.filial, data=date(2026, 8, 5), descricao="PBM", valor=Decimal("300.00"))
        self.assertTrue(capacidade_configurada(self.filial, 2026, 8))
        resultado = motor_financeiro.capacidade_do_mes(self.filial, 2026, 8)
        self.assertTrue(resultado.receita_configurada)
        self.assertEqual(resultado.receita_mensal, Decimal("0"))
        self.assertEqual(resultado.faturamento, Decimal("300.00"))
        self.assertTrue(calcular_capacidade_compra(self.filial, 2026, 8)["capacidade_configurada"])

    def test_extra_de_outro_mes_nao_configura_o_mes(self):
        ReceitaExtra.objects.create(filial=self.filial, data=date(2026, 7, 31), descricao="PBM", valor=Decimal("300.00"))
        self.assertFalse(capacidade_configurada(self.filial, 2026, 8))
        self.assertFalse(calcular_capacidade_compra(self.filial, 2026, 8)["capacidade_configurada"])


class ReceitaExtraCrudBase(TestCase):
    """Empresa A (Proprietário, Financeiro, Gerente, Comprador) + empresa B
    totalmente separada, com uma receita extra própria."""

    @classmethod
    def setUpTestData(cls):
        cls.hoje = date.today()
        cls.empresa = Empresa.objects.create(nome="Empresa CRUD Extra", cnpj="84.000.000/0001-84")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Matriz CRUD Extra")
        ConfiguracaoFinanceira.objects.create(empresa=cls.empresa, percentual_compras=Decimal("30"))
        cls.receita = Receita.objects.create(filial=cls.filial, mes=_mes_atual(), faturamento=Decimal("100000.00"))

        def criar(username, perfil, empresa, filial):
            return Usuario.objects.create_user(
                username=username, password="x", perfil=perfil, empresa=empresa, filial=filial,
            )

        cls.proprietario = criar("prop_extra", Usuario.Perfil.PROPRIETARIO, cls.empresa, None)
        cls.financeiro = criar("fin_extra", Usuario.Perfil.FINANCEIRO, cls.empresa, cls.filial)
        cls.gerente = criar("ger_extra", Usuario.Perfil.GERENTE, cls.empresa, cls.filial)
        cls.comprador = criar("comp_extra", Usuario.Perfil.COMPRADOR, cls.empresa, cls.filial)

        cls.empresa_b = Empresa.objects.create(nome="Empresa B Extra", cnpj="85.000.000/0001-85")
        cls.filial_b = Filial.objects.create(empresa=cls.empresa_b, nome="Filial B Extra")
        cls.extra_b = ReceitaExtra.objects.create(
            filial=cls.filial_b, data=cls.hoje, descricao="Receita sigilosa da empresa B", valor=Decimal("4321.00"),
        )

    def client_de(self, usuario):
        client = Client(SERVER_NAME="127.0.0.1")
        client.force_login(usuario)
        return client

    def dados(self, **extras):
        base = {
            "filial": self.filial.pk, "data": self.hoje.isoformat(), "descricao": "Convênio PBM do mês",
            "categoria": ReceitaExtra.Categoria.CONVENIOS, "valor": "1.500,50", "observacao": "Conferido no extrato.",
        }
        base.update(extras)
        return base

    def criar_extra(self, **campos):
        padrao = {"filial": self.filial, "data": self.hoje, "descricao": "Serviços farmacêuticos",
                  "categoria": ReceitaExtra.Categoria.SERVICOS, "valor": Decimal("800.00")}
        padrao.update(campos)
        return ReceitaExtra.objects.create(**padrao)

    def assert_html_limpo(self, resposta):
        html = resposta.content.decode("utf-8")
        for termo in TERMOS_PROIBIDOS:
            self.assertNotIn(termo, html, f"'{termo}' vazou no HTML")
        return html


class ReceitaExtraRBACTestCase(ReceitaExtraCrudBase):
    def test_comprador_e_gerente_recebem_403_em_todas_as_rotas(self):
        extra = self.criar_extra()
        rotas_get = [
            "/financeiro/receitas/extras/",
            "/financeiro/receitas/extras/nova/",
            f"/financeiro/receitas/extras/{extra.pk}/editar/",
            f"/financeiro/receitas/extras/{extra.pk}/excluir/",
        ]
        for usuario in (self.comprador, self.gerente):
            client = self.client_de(usuario)
            for url in rotas_get:
                self.assertEqual(client.get(url).status_code, 403, f"{usuario.username} GET {url}")
            self.assertEqual(client.post("/financeiro/receitas/extras/nova/", self.dados()).status_code, 403)
            self.assertEqual(
                client.post(f"/financeiro/receitas/extras/{extra.pk}/editar/", self.dados()).status_code, 403
            )
            self.assertEqual(client.post(f"/financeiro/receitas/extras/{extra.pk}/excluir/").status_code, 403)
        self.assertTrue(ReceitaExtra.objects.filter(pk=extra.pk).exists())
        self.assertEqual(ReceitaExtra.objects.filter(filial=self.filial).count(), 1)

    def test_anonimo_e_redirecionado_para_o_login(self):
        resposta = Client(SERVER_NAME="127.0.0.1").get("/financeiro/receitas/extras/")
        self.assertEqual(resposta.status_code, 302)
        self.assertIn("login", resposta["Location"])

    def test_financeiro_e_proprietario_acessam_lista_e_formulario(self):
        for usuario in (self.financeiro, self.proprietario):
            client = self.client_de(usuario)
            for url in ("/financeiro/receitas/extras/", "/financeiro/receitas/extras/nova/", "/financeiro/receitas/"):
                resposta = client.get(url)
                self.assertEqual(resposta.status_code, 200, f"{usuario.username} GET {url}")
                self.assert_html_limpo(resposta)

    def test_proprietario_cadastra_receita_extra(self):
        resposta = self.client_de(self.proprietario).post("/financeiro/receitas/extras/nova/", self.dados())
        self.assertEqual(resposta.status_code, 302, getattr(resposta, "context", None) and resposta.context["form"].errors)
        extra = ReceitaExtra.objects.get(filial=self.filial)
        self.assertEqual(extra.valor, Decimal("1500.50"))
        self.assertEqual(extra.empresa, self.empresa)


class ReceitaExtraCrudTestCase(ReceitaExtraCrudBase):
    def test_criar_grava_audita_e_redireciona_para_o_mes_da_receita(self):
        client = self.client_de(self.financeiro)
        resposta = client.post("/financeiro/receitas/extras/nova/", self.dados())
        self.assertEqual(resposta.status_code, 302)
        extra = ReceitaExtra.objects.get(filial=self.filial)
        self.assertEqual(extra.valor, Decimal("1500.50"))
        self.assertEqual(extra.categoria, ReceitaExtra.Categoria.CONVENIOS)
        self.assertEqual(
            resposta["Location"], f"/financeiro/receitas/extras/?ano={self.hoje.year}&mes={self.hoje.month}"
        )

        evento = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.RECEITA_ALTERADA, tipo_objeto="ReceitaExtra",
            id_objeto=extra.pk, acao="criar",
        )
        self.assertEqual(evento.empresa, self.empresa)
        self.assertEqual(evento.filial, self.filial)
        self.assertEqual(evento.usuario, self.financeiro)
        self.assertIsNone(evento.estado_antes)
        self.assertEqual(evento.estado_depois["valor"], "1500.50")
        self.assertEqual(evento.estado_depois["categoria"], "convenios")

        lista = client.get(resposta["Location"])
        html = self.assert_html_limpo(lista)
        self.assertIn("Convênio PBM do mês", html)
        self.assertIn("cadastrada com sucesso", html)

    def test_valor_zero_ou_negativo_no_formulario_e_recusado(self):
        client = self.client_de(self.financeiro)
        for valor in ("0,00", "-10,00"):
            resposta = client.post("/financeiro/receitas/extras/nova/", self.dados(valor=valor))
            self.assertEqual(resposta.status_code, 200)
            self.assertIn("valor", resposta.context["form"].errors)
            self.assertContains(resposta, "maior que zero")
        self.assertFalse(ReceitaExtra.objects.filter(filial=self.filial).exists())

    def test_editar_altera_e_registra_estado_antes_e_depois(self):
        extra = self.criar_extra(valor=Decimal("800.00"))
        client = self.client_de(self.financeiro)
        resposta = client.post(
            f"/financeiro/receitas/extras/{extra.pk}/editar/",
            self.dados(descricao="Serviços revisados", valor="950,25", categoria="servicos"),
        )
        self.assertEqual(resposta.status_code, 302)
        extra.refresh_from_db()
        self.assertEqual(extra.valor, Decimal("950.25"))
        self.assertEqual(extra.descricao, "Serviços revisados")
        evento = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.RECEITA_ALTERADA, tipo_objeto="ReceitaExtra",
            id_objeto=extra.pk, acao="editar",
        )
        self.assertEqual(evento.estado_antes["valor"], "800.00")
        self.assertEqual(evento.estado_depois["valor"], "950.25")
        self.assertEqual(evento.estado_antes["descricao"], "Serviços farmacêuticos")

    def test_excluir_pede_confirmacao_no_get_e_apaga_no_post(self):
        extra = self.criar_extra()
        client = self.client_de(self.financeiro)
        confirmacao = client.get(f"/financeiro/receitas/extras/{extra.pk}/excluir/")
        self.assertEqual(confirmacao.status_code, 200)
        html = self.assert_html_limpo(confirmacao)
        self.assertIn("Confirmar exclusão", html)
        self.assertTrue(ReceitaExtra.objects.filter(pk=extra.pk).exists())  # GET nunca apaga

        resposta = client.post(f"/financeiro/receitas/extras/{extra.pk}/excluir/")
        self.assertEqual(resposta.status_code, 302)
        self.assertFalse(ReceitaExtra.objects.filter(pk=extra.pk).exists())
        evento = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.RECEITA_ALTERADA, tipo_objeto="ReceitaExtra",
            id_objeto=extra.pk, acao="excluir",
        )
        self.assertEqual(evento.estado_antes["valor"], "800.00")
        self.assertIsNone(evento.estado_depois)

    def test_filtros_por_mes_filial_e_categoria(self):
        self.criar_extra(descricao="Extra deste mês", categoria=ReceitaExtra.Categoria.SERVICOS)
        self.criar_extra(descricao="Rendimento deste mês", categoria=ReceitaExtra.Categoria.RENDIMENTOS)
        anterior = _outro_mes(_mes_atual())
        self.criar_extra(descricao="Extra do mês passado", data=anterior)
        client = self.client_de(self.financeiro)

        html = client.get("/financeiro/receitas/extras/").content.decode("utf-8")
        self.assertIn("Extra deste mês", html)
        self.assertIn("Rendimento deste mês", html)
        self.assertNotIn("Extra do mês passado", html)

        html = client.get(f"/financeiro/receitas/extras/?ano={anterior.year}&mes={anterior.month}").content.decode("utf-8")
        self.assertIn("Extra do mês passado", html)
        self.assertNotIn("Extra deste mês", html)

        html = client.get("/financeiro/receitas/extras/?categoria=rendimentos").content.decode("utf-8")
        self.assertIn("Rendimento deste mês", html)
        self.assertNotIn("Extra deste mês", html)

        html = client.get(f"/financeiro/receitas/extras/?filial={self.filial.pk}").content.decode("utf-8")
        self.assertIn("Extra deste mês", html)

    def test_querystring_malformada_nao_derruba_a_tela(self):
        client = self.client_de(self.financeiro)
        for query in ("?ano=2.026&mes=9", "?ano=abc&mes=13", "?ano=99999999999999999999&mes=1", "?mes=0"):
            for url in ("/financeiro/receitas/extras/", "/financeiro/receitas/"):
                resposta = client.get(url + query)
                self.assertEqual(resposta.status_code, 200, url + query)
                self.assert_html_limpo(resposta)

    def test_links_de_navegacao_de_mes_nao_usam_separador_de_milhar(self):
        html = self.client_de(self.financeiro).get("/financeiro/receitas/extras/").content.decode("utf-8")
        self.assertNotRegex(html, r"ano=\d\.\d{3}")
        html = self.client_de(self.financeiro).get("/financeiro/receitas/").content.decode("utf-8")
        self.assertNotRegex(html, r"ano=\d\.\d{3}")

    def test_csv_exporta_as_receitas_extras_do_filtro(self):
        self.criar_extra(descricao="Serviço no CSV", valor=Decimal("123.45"))
        resposta = self.client_de(self.financeiro).get("/financeiro/receitas/extras/?formato=csv")
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("text/csv", resposta["Content-Type"])
        conteudo = resposta.content.decode("utf-8-sig")
        self.assertIn("Serviço no CSV", conteudo)
        self.assertIn("123,45", conteudo)
        self.assertNotIn("Receita sigilosa da empresa B", conteudo)


class ReceitaExtraIsolamentoEmpresasTestCase(ReceitaExtraCrudBase):
    def test_receita_extra_de_outra_empresa_nunca_aparece_nem_e_editavel(self):
        client = self.client_de(self.financeiro)
        for url in ("/financeiro/receitas/extras/", f"/financeiro/receitas/extras/?filial={self.filial_b.pk}",
                    "/financeiro/receitas/"):
            html = client.get(url).content.decode("utf-8")
            self.assertNotIn("Receita sigilosa da empresa B", html, url)
            self.assertNotIn("4.321,00", html, url)
            self.assertNotIn("Filial B Extra", html, url)

        self.assertEqual(client.get(f"/financeiro/receitas/extras/{self.extra_b.pk}/editar/").status_code, 404)
        self.assertEqual(
            client.post(f"/financeiro/receitas/extras/{self.extra_b.pk}/editar/", self.dados()).status_code, 404
        )
        self.assertEqual(client.get(f"/financeiro/receitas/extras/{self.extra_b.pk}/excluir/").status_code, 404)
        self.assertEqual(client.post(f"/financeiro/receitas/extras/{self.extra_b.pk}/excluir/").status_code, 404)
        self.extra_b.refresh_from_db()
        self.assertEqual(self.extra_b.valor, Decimal("4321.00"))

    def test_nao_cria_receita_extra_em_filial_de_outra_empresa(self):
        resposta = self.client_de(self.financeiro).post(
            "/financeiro/receitas/extras/nova/", self.dados(filial=self.filial_b.pk)
        )
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("filial", resposta.context["form"].errors)
        self.assertEqual(ReceitaExtra.objects.filter(filial=self.filial_b).count(), 1)

    def test_proprietario_nao_ve_filial_de_outra_empresa_no_formulario(self):
        resposta = self.client_de(self.proprietario).get("/financeiro/receitas/extras/nova/")
        self.assertEqual(list(resposta.context["form"].fields["filial"].queryset), [self.filial])


class ReceitaExtraTelasEDashboardsTestCase(ReceitaExtraCrudBase):
    def setUp(self):
        self.criar_extra(descricao="Aplicação de injetáveis", valor=Decimal("1500.50"))
        self.criar_extra(descricao="Repasse PBM", valor=Decimal("499.50"), categoria=ReceitaExtra.Categoria.CONVENIOS)

    def test_tela_de_receitas_mostra_as_duas_partes_e_o_total(self):
        resposta = self.client_de(self.financeiro).get("/financeiro/receitas/")
        html = self.assert_html_limpo(resposta)
        self.assertIn("Receita mensal (faturamento)", html)
        self.assertIn("Receitas extras", html)
        self.assertIn("Total da receita do mês", html)
        self.assertEqual(resposta.context["resumo_mes"]["receita_mensal"], Decimal("100000.00"))
        self.assertEqual(resposta.context["resumo_mes"]["receitas_extras"], Decimal("2000.00"))
        self.assertEqual(resposta.context["resumo_mes"]["total"], Decimal("102000.00"))
        self.assertIn("R$ 102.000,00", html)
        self.assertIn("Aplicação de injetáveis", html)

    def test_dashboard_do_proprietario_mostra_o_total_com_as_extras(self):
        resposta = self.client_de(self.proprietario).get("/")
        self.assertEqual(resposta.status_code, 200)
        html = self.assert_html_limpo(resposta)
        kpis = resposta.context["kpis"]
        self.assertEqual(kpis["faturamento_mes"], Decimal("102000.00"))
        self.assertEqual(kpis["receita_mensal_mes"], Decimal("100000.00"))
        self.assertEqual(kpis["receitas_extras_mes"], Decimal("2000.00"))
        self.assertIn("R$ 102.000", html)
        self.assertIn("extras R$ 2.000,00", html)

    def test_total_fecha_entre_tela_de_receitas_dashboards_e_motor(self):
        total_tela = self.client_de(self.financeiro).get("/financeiro/receitas/").context["resumo_mes"]["total"]
        kpi_proprietario = self.client_de(self.proprietario).get("/").context["kpis"]["faturamento_mes"]
        painel_financeiro = self.client_de(self.financeiro).get("/").context["resumo_filiais"]
        total_financeiro = sum((linha["faturamento"] for linha in painel_financeiro), Decimal("0"))
        motor = motor_financeiro.capacidade_do_mes(self.filial, self.hoje.year, self.hoje.month).faturamento
        self.assertEqual({total_tela, kpi_proprietario, total_financeiro, motor}, {Decimal("102000.00")})

    def test_dashboard_financeiro_mostra_receita_decomposta_por_filial(self):
        html = self.assert_html_limpo(self.client_de(self.financeiro).get("/"))
        self.assertIn("Receita do mês", html)
        self.assertIn("extras R$ 2.000,00", html)

    def test_comprador_nao_recebe_nenhum_dado_de_receita(self):
        payload = viewmodel_comprador(self.comprador)
        self.assertEqual(set(payload) & CHAVES_PROIBIDAS_COMPRADOR, set())
        for chave in ("receita_mensal", "receitas_extras", "receita_total", "faturamento_mes"):
            self.assertIn(chave, CHAVES_PROIBIDAS_COMPRADOR)
            self.assertNotIn(chave, payload)
        # O sinal booleano continua liberado (não é valor financeiro).
        self.assertTrue(payload["capacidade_configurada"])

        resposta = self.client_de(self.comprador).get("/")
        self.assertEqual(resposta.status_code, 200)
        html = self.assert_html_limpo(resposta)
        for termo in ("Faturamento", "Receita mensal", "Receitas extras", "Receita extra",
                      "Aplicação de injetáveis", "Repasse PBM", "1.500,50", "499,50",
                      "102.000", "100.000", "2.000,00", "Capacidade mensal", "Meta Mensal"):
            self.assertNotIn(termo, html, f"'{termo}' vazou para o Comprador")

    def test_gerente_ve_resultado_do_mes_sem_os_lancamentos_de_receita(self):
        """REGRA MUDOU (Correções de Produção — decisão explícita do
        usuário: "a parte analítica fica para o Financeiro, o Gerente e o
        Proprietário"). Antes: nenhum valor de receita no painel do Gerente.
        Agora: o widget "Resultado do mês" do Gerente MOSTRA receita total,
        despesas e resultado em R$ (a mesma DRE que ele já abria na Análise
        Financeira). Continua valendo: o payload do viewmodel do Gerente não
        tem nenhuma chave proibida (o widget vive num contexto separado) e
        os LANÇAMENTOS individuais de receita (descrição/valor de cada
        receita extra) não aparecem no painel."""
        payload = viewmodel_gerente(self.gerente)
        self.assertEqual(set(payload) & CHAVES_PROIBIDAS_GERENTE, set())
        resposta = self.client_de(self.gerente).get("/")
        html = self.assert_html_limpo(resposta)
        self.assertTrue(resposta.context["resultado_mes"]["detalhar_valores"])
        widget = html.split('data-an-widget="resultado-mes"', 1)[1].split("</table>", 1)[0]
        self.assertIn('data-an-widget-valor="receita">R$ 102.000,00', widget)
        self.assertIn('data-an-widget-valor="despesas">', widget)
        self.assertIn('data-an-widget-valor="resultado">', widget)
        for termo in ("Aplicação de injetáveis", "Repasse PBM", "1.500,50"):
            self.assertNotIn(termo, html)

    def test_capacidade_do_comprador_muda_com_a_receita_extra(self):
        """O limite diário que o Comprador enxerga é efeito natural do Motor:
        mais receita extra → limite maior (sem expor o valor da receita)."""
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem
        # limite próprio — a premissa "hoje é dia de compra" fica explícita
        # para a suíte passar em qualquer dia da semana.
        from core.utils_testes import garantir_capacidade_no_dia

        garantir_capacidade_no_dia(self.empresa)
        antes = viewmodel_comprador(self.comprador)["limite_diario"]
        self.criar_extra(descricao="Rendimento", valor=Decimal("10000.00"), categoria=ReceitaExtra.Categoria.RENDIMENTOS)
        depois = viewmodel_comprador(self.comprador)["limite_diario"]
        self.assertGreater(depois, antes)


class ReceitaExtraNavegacaoTestCase(ReceitaExtraCrudBase):
    def test_breadcrumbs_das_novas_rotas(self):
        extra = self.criar_extra()
        client = self.client_de(self.financeiro)
        casos = {
            "/financeiro/receitas/extras/": ("Receitas extras", "/financeiro/receitas/"),
            "/financeiro/receitas/extras/nova/": ("Nova receita extra", "/financeiro/receitas/extras/"),
            f"/financeiro/receitas/extras/{extra.pk}/editar/": ("Editar receita extra", "/financeiro/receitas/extras/"),
            f"/financeiro/receitas/extras/{extra.pk}/excluir/": ("Excluir receita extra", "/financeiro/receitas/extras/"),
        }
        for url, (atual, link_pai) in casos.items():
            html = client.get(url).content.decode("utf-8")
            trecho = html.split('aria-label="Navegação estrutural"', 1)[1].split("</nav>", 1)[0]
            self.assertRegex(trecho, r'aria-current="page">\s*<span>' + re.escape(atual), url)
            self.assertIn(f'href="{link_pai}"', trecho, url)
            self.assertIn('href="/financeiro/planejamento/"', trecho, url)

    def test_item_receitas_fica_ativo_nas_novas_rotas_sem_item_novo_de_menu(self):
        html = self.client_de(self.financeiro).get("/financeiro/receitas/extras/").content.decode("utf-8")
        self.assertRegex(html, r'aria-expanded="true"[^>]*aria-controls="nxGrupo-planejamento"')
        self.assertRegex(html, r'class="nx-nav-sublink active"[^>]*>\s*Receitas')
        aside = html.split('<aside class="nx-sidebar"', 1)[1].split("</aside>", 1)[0]
        self.assertNotIn("/financeiro/receitas/extras/", aside)

        html = self.client_de(self.proprietario).get("/financeiro/receitas/extras/nova/").content.decode("utf-8")
        self.assertRegex(html, r'aria-expanded="true"[^>]*aria-controls="nxGrupo-financeiro"')
        self.assertRegex(html, r'class="nx-nav-sublink active"[^>]*>\s*Planejamento Financeiro')


class ReceitaExtraAtomicidadeTestCase(TransactionTestCase):
    """Mesmo contrato do Gate 1 (core/tests_gate1_atomicidade.py): falha na
    auditoria desfaz a gravação da receita extra — nunca fica um lançamento
    sem rastro. `TransactionTestCase` de propósito (grava de verdade)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Atomic Extra", cnpj="87.000.000/0001-87")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Atomic Extra")
        self.financeiro = Usuario.objects.create_user(
            username="fin_atomic_extra", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.client = Client(SERVER_NAME="127.0.0.1", raise_request_exception=False)
        self.client.force_login(self.financeiro)

    def test_falha_na_auditoria_reverte_criacao_edicao_e_exclusao(self):
        from unittest import mock

        from empresas.models import LogConfiguracao

        falha = RuntimeError("Falha simulada na Auditoria (teste de rollback)")
        # O login já gera evento próprio (auditoria/signals.py) — compara com
        # o que existia antes das escritas, não com zero.
        auditoria_antes = RegistroAuditoria.objects.count()
        dados = {"filial": self.filial.pk, "data": "2026-08-10", "descricao": "PBM", "categoria": "convenios",
                 "valor": "100,00", "observacao": ""}
        with mock.patch("financeiro.views.registrar_evento", side_effect=falha):
            self.client.post("/financeiro/receitas/extras/nova/", dados)
        self.assertFalse(ReceitaExtra.objects.exists())

        extra = ReceitaExtra.objects.create(filial=self.filial, data=date(2026, 8, 10), descricao="PBM",
                                            valor=Decimal("100.00"))
        log_antes = LogConfiguracao.objects.count()
        with mock.patch("financeiro.views.registrar_evento", side_effect=falha):
            self.client.post(f"/financeiro/receitas/extras/{extra.pk}/editar/", {**dados, "valor": "999,99"})
            self.client.post(f"/financeiro/receitas/extras/{extra.pk}/excluir/")
        extra.refresh_from_db()
        self.assertEqual(extra.valor, Decimal("100.00"))
        self.assertEqual(LogConfiguracao.objects.count(), log_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)
