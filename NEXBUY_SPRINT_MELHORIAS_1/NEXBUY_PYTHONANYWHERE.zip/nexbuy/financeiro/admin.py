from django.contrib import admin

from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, DiaOperacional, Receita, ReceitaExtra


@admin.register(DiaOperacional)
class DiaOperacionalAdmin(admin.ModelAdmin):
    list_display = ("data", "tipo", "empresa", "observacao")
    list_filter = ("tipo", "empresa")
    date_hierarchy = "data"


@admin.register(Receita)
class ReceitaAdmin(admin.ModelAdmin):
    list_display = ("filial", "empresa", "mes", "faturamento")
    list_filter = ("empresa", "filial")
    date_hierarchy = "mes"


@admin.register(ReceitaExtra)
class ReceitaExtraAdmin(admin.ModelAdmin):
    list_display = ("descricao", "filial", "empresa", "data", "categoria", "valor")
    list_filter = ("empresa", "filial", "categoria")
    search_fields = ("descricao", "observacao")
    date_hierarchy = "data"
    readonly_fields = ("empresa",)


@admin.register(CustoFixo)
class CustoFixoAdmin(admin.ModelAdmin):
    list_display = ("descricao", "filial", "fornecedor", "valor", "dia_vencimento", "ativo")
    list_filter = ("empresa", "filial", "ativo")
    search_fields = ("descricao", "fornecedor")


@admin.register(CustoVariavel)
class CustoVariavelAdmin(admin.ModelAdmin):
    list_display = ("descricao", "filial", "valor", "data_prevista")
    list_filter = ("empresa", "filial")
    date_hierarchy = "data_prevista"


@admin.register(ConfiguracaoFinanceira)
class ConfiguracaoFinanceiraAdmin(admin.ModelAdmin):
    list_display = ("empresa", "percentual_compras", "regra_excesso")
