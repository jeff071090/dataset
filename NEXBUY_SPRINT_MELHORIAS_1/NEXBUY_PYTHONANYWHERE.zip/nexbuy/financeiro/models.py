from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from core.models import TimeStampedModel
from empresas.models import Empresa
from filiais.models import Filial


class Receita(TimeStampedModel):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="receitas", verbose_name="Empresa")
    filial = models.ForeignKey(Filial, on_delete=models.CASCADE, related_name="receitas", verbose_name="Filial")
    mes = models.DateField("Mês de referência", help_text="Qualquer dia do mês de referência.")
    # RC do Épico 01: valores financeiros validados no model/form (a camada
    # de banco recebe CheckConstraint via Meta, abaixo).
    faturamento = models.DecimalField(
        "Faturamento", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0"))]
    )

    class Meta:
        verbose_name = "Receita"
        verbose_name_plural = "Receitas"
        ordering = ["-mes"]
        unique_together = ("filial", "mes")
        constraints = [
            models.CheckConstraint(condition=models.Q(faturamento__gte=0), name="receita_faturamento_nao_negativo"),
        ]

    def __str__(self):
        return f"{self.filial} - {self.mes:%m/%Y}: R$ {self.faturamento}"

    def save(self, *args, **kwargs):
        # Normaliza sempre para o primeiro dia do mês, garantindo 1 registro por mês/filial.
        self.mes = self.mes.replace(day=1)
        self.empresa = self.filial.empresa
        super().save(*args, **kwargs)


class ReceitaExtra(TimeStampedModel):
    """Receita avulsa lançada manualmente, além da receita mensal
    (faturamento) da filial — serviços farmacêuticos, convênios/PBM,
    rendimentos financeiros e outras entradas.

    A receita do mês que alimenta o Motor Financeiro passa a ser:
    `Receita.faturamento` (receita mensal) + soma das `ReceitaExtra` com
    `data` naquele mês (ver `finance_engine.services.CapacidadeCompraService`).
    Ao contrário da `Receita`, aqui pode haver várias linhas por filial/mês
    (cada entrada é um fato pontual, com data própria)."""

    class Categoria(models.TextChoices):
        SERVICOS = "servicos", "Serviços farmacêuticos"
        CONVENIOS = "convenios", "Convênios / PBM"
        RENDIMENTOS = "rendimentos", "Rendimentos financeiros"
        OUTRAS = "outras", "Outras receitas"

    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="receitas_extras", verbose_name="Empresa"
    )
    filial = models.ForeignKey(
        Filial, on_delete=models.CASCADE, related_name="receitas_extras", verbose_name="Filial"
    )
    data = models.DateField("Data da receita")
    descricao = models.CharField("Descrição", max_length=200)
    categoria = models.CharField(
        "Categoria", max_length=20, choices=Categoria.choices, default=Categoria.OUTRAS
    )
    # Estritamente positivo: uma receita extra de R$ 0,00 não é um fato
    # financeiro (o validator protege o form; o CheckConstraint, o banco).
    valor = models.DecimalField(
        "Valor",
        max_digits=14,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"), message="Informe um valor maior que zero.")],
    )
    observacao = models.TextField("Observação", blank=True)

    class Meta:
        verbose_name = "Receita Extra"
        verbose_name_plural = "Receitas Extras"
        ordering = ["-data", "-id"]
        constraints = [
            models.CheckConstraint(condition=models.Q(valor__gt=0), name="receitaextra_valor_positivo"),
        ]
        indexes = [models.Index(fields=["filial", "data"], name="receitaextra_filial_data_idx")]

    def __str__(self):
        return f"{self.descricao} - R$ {self.valor} ({self.data:%d/%m/%Y})"

    def save(self, *args, **kwargs):
        self.empresa = self.filial.empresa
        super().save(*args, **kwargs)


class CustoFixo(TimeStampedModel):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="custos_fixos", verbose_name="Empresa")
    filial = models.ForeignKey(Filial, on_delete=models.CASCADE, related_name="custos_fixos", verbose_name="Filial")
    descricao = models.CharField("Descrição", max_length=200)
    fornecedor = models.CharField("Fornecedor", max_length=150, blank=True)
    valor = models.DecimalField(
        "Valor mensal", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0"))]
    )
    # RC do Épico 01: dia do mês validado de verdade (antes só o help_text
    # prometia 1-31; nada impedia gravar 99).
    dia_vencimento = models.PositiveSmallIntegerField(
        "Dia do vencimento",
        help_text="Dia do mês, de 1 a 31.",
        validators=[MinValueValidator(1), MaxValueValidator(31)],
    )
    ativo = models.BooleanField("Ativo", default=True)

    class Meta:
        verbose_name = "Custo Fixo"
        verbose_name_plural = "Custos Fixos"
        ordering = ["dia_vencimento"]
        constraints = [
            models.CheckConstraint(condition=models.Q(valor__gte=0), name="custofixo_valor_nao_negativo"),
            models.CheckConstraint(
                condition=models.Q(dia_vencimento__gte=1) & models.Q(dia_vencimento__lte=31),
                name="custofixo_dia_entre_1_e_31",
            ),
        ]

    def __str__(self):
        return f"{self.descricao} - R$ {self.valor} (dia {self.dia_vencimento})"

    def save(self, *args, **kwargs):
        self.empresa = self.filial.empresa
        super().save(*args, **kwargs)


class CustoVariavel(TimeStampedModel):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="custos_variaveis", verbose_name="Empresa")
    filial = models.ForeignKey(Filial, on_delete=models.CASCADE, related_name="custos_variaveis", verbose_name="Filial")
    descricao = models.CharField("Descrição", max_length=200)
    valor = models.DecimalField(
        "Valor", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0"))]
    )
    data_prevista = models.DateField("Data prevista")

    class Meta:
        verbose_name = "Custo Variável"
        verbose_name_plural = "Custos Variáveis"
        ordering = ["-data_prevista"]
        constraints = [
            models.CheckConstraint(condition=models.Q(valor__gte=0), name="custovariavel_valor_nao_negativo"),
        ]

    def __str__(self):
        return f"{self.descricao} - R$ {self.valor}"

    def save(self, *args, **kwargs):
        self.empresa = self.filial.empresa
        super().save(*args, **kwargs)


class DiaOperacional(TimeStampedModel):
    """Exceção do Calendário Operacional de uma empresa (Épico 2 — CORE 1.0).

    O NEXBUY só grava as EXCEÇÕES: na ausência de registro para uma data,
    vale a regra padrão (segunda a sexta = dia útil; sábado = sábado;
    domingo = domingo) — exatamente o comportamento que o sistema sempre
    teve. Um registro sobrescreve o tipo daquela data para a empresa
    inteira (feriado, bloqueio, dia especial que conta capacidade, etc.).

    Quem interpreta este model é o Motor Financeiro
    (`finance_engine/calendario_operacional.py`): dias que "contam
    capacidade" (útil e especial) entram na divisão do limite diário E
    recebem limite base no day-walk; dias que não contam (feriado,
    bloqueado e o fim de semana da regra padrão) têm limite base zero —
    para liberar compras num sábado, cadastre-o como "Especial".
    """

    class Tipo(models.TextChoices):
        UTIL = "util", "Dia útil"
        SABADO = "sabado", "Sábado"
        DOMINGO = "domingo", "Domingo"
        FERIADO = "feriado", "Feriado"
        BLOQUEADO = "bloqueado", "Bloqueado"
        ESPECIAL = "especial", "Especial (conta capacidade)"

    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="dias_operacionais", verbose_name="Empresa"
    )
    data = models.DateField("Data")
    tipo = models.CharField("Tipo do dia", max_length=15, choices=Tipo.choices)
    observacao = models.CharField("Observação", max_length=200, blank=True)

    class Meta:
        verbose_name = "Dia Operacional"
        verbose_name_plural = "Dias Operacionais"
        ordering = ["data"]
        constraints = [
            models.UniqueConstraint(fields=["empresa", "data"], name="dia_operacional_unico_por_empresa")
        ]
        indexes = [models.Index(fields=["empresa", "data"], name="diaoper_empresa_data_idx")]

    def __str__(self):
        return f"{self.data:%d/%m/%Y} — {self.get_tipo_display()} ({self.empresa.nome})"


# Cor principal (Crítico de UX, rodada 1). O default histórico do campo é
# vermelho (#E11D2E) — e a Ajuda manda salvar a Configuração financeira
# "mesmo mantendo os valores sugeridos": salvar sem mexer pintava de
# vermelho botões, menu ativo e links, justo a cor que na Análise significa
# prejuízo/crítico. Trocar o default do campo exigiria uma migração; em vez
# disso o vermelho legado é tratado como "nunca escolhido" (não sobrescreve
# o azul do CSS) e o formulário sugere o azul NEXBUY.
COR_PRINCIPAL_PADRAO_NEXBUY = "#2563EB"
COR_PRINCIPAL_DEFAULT_LEGADO = "#E11D2E"


class ConfiguracaoFinanceira(TimeStampedModel):
    class RegraExcesso(models.TextChoices):
        BLOQUEAR = "bloquear", "Bloquear compra"
        APROVACAO = "aprovacao", "Solicitar Aprovação"
        ALERTA = "alerta", "Permitir compra com alerta"

    class Moeda(models.TextChoices):
        BRL = "BRL", "Real (R$)"
        USD = "USD", "Dólar (US$)"
        EUR = "EUR", "Euro (€)"

    empresa = models.OneToOneField(
        Empresa, on_delete=models.CASCADE, related_name="configuracao_financeira", verbose_name="Empresa"
    )
    percentual_compras = models.DecimalField(
        "Percentual destinado às compras (%)", max_digits=5, decimal_places=2, default=30
    )
    percentual_seguranca = models.DecimalField(
        "Percentual de segurança (%)",
        max_digits=5,
        decimal_places=2,
        default=0,
        help_text="Margem reduzida da capacidade mensal antes de calcular o limite diário.",
    )
    dias_uteis_manual = models.PositiveSmallIntegerField(
        "Dias úteis considerados (manual)",
        null=True,
        blank=True,
        help_text="Deixe em branco para calcular automaticamente os dias úteis do mês.",
    )
    permitir_saldo_acumulativo = models.BooleanField(
        "Permitir saldo acumulativo",
        default=False,
        help_text="Se ativado, o saldo não utilizado em dias anteriores do mês soma ao limite do dia atual.",
    )
    redistribuicao_automatica = models.BooleanField(
        "Redistribuição automática",
        default=False,
        help_text="Se ativado, o excedente de um dia que ultrapassou o limite reduz automaticamente o limite dos dias seguintes.",
    )
    permitir_ultrapassar_limite = models.BooleanField(
        "Permitir ultrapassar o limite diário",
        default=False,
        help_text="Se ativado, uma compra pode ultrapassar o limite efetivo do dia (necessário para a Redistribuição automática atuar). Não altera a Forma de bloqueio abaixo.",
    )
    limite_maximo_acumulado = models.DecimalField(
        "Limite máximo acumulado",
        max_digits=14,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Teto para o saldo acumulado (sobra) que pode se acumular de um dia para o outro. Deixe em branco para não limitar.",
    )
    regra_excesso = models.CharField(
        "Forma de bloqueio ao ultrapassar o limite diário",
        max_length=20,
        choices=RegraExcesso.choices,
        default=RegraExcesso.ALERTA,
    )
    cor_principal = models.CharField("Cor principal da empresa", max_length=7, default="#E11D2E")
    moeda = models.CharField("Moeda", max_length=3, choices=Moeda.choices, default=Moeda.BRL)
    observacoes = models.TextField("Observações", blank=True)

    class Meta:
        verbose_name = "Configuração Financeira"
        verbose_name_plural = "Configurações Financeiras"

    def __str__(self):
        return f"Configuração - {self.empresa.nome}"

    @property
    def cor_principal_personalizada(self) -> str:
        """Cor que de fato sobrescreve `--nx-primary` (templates/base.html),
        ou "" para manter o azul NEXBUY do CSS: vazio, o vermelho legado
        do default do campo (nunca escolhido de verdade) e o próprio azul
        padrão não geram override."""
        cor = (self.cor_principal or "").strip()
        if cor.upper() in ("", COR_PRINCIPAL_DEFAULT_LEGADO, COR_PRINCIPAL_PADRAO_NEXBUY):
            return ""
        return cor
