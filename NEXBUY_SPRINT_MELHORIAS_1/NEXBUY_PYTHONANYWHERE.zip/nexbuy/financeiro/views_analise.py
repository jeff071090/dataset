"""Análise Financeira — DRE Gerencial, Créditos × Débitos e Saúde Financeira.

Acesso: Proprietário, Gerente e Financeiro (`PERFIS_ANALISE_FINANCEIRA`,
o MESMO gate do item de menu em `core/navegacao.py`). O Comprador recebe
403 nas 3 telas.

Escopo de dados: sempre as filiais do CONTEXTO do usuário
(`core.contexto.filiais_do_contexto` — empresa ativa + filiais autorizadas),
exatamente como os relatórios existentes. O filtro `?filial=<id>` só aceita
uma filial desse conjunto; qualquer outro id (inclusive de outra empresa)
é ignorado e a tela volta para "Todas as filiais".

Nenhuma regra de cálculo mora aqui — os números vêm de
`financeiro.services_analise` (que lê do Motor Financeiro) e os gráficos de
`financeiro.graficos_svg`. As URLs de navegação entre meses são montadas em
Python (nunca `{{ ano }}` cru no template: com USE_THOUSAND_SEPARATOR o ano
viraria "2.026").
"""
from datetime import date

from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from django.utils.safestring import mark_safe

from core.contexto import empresa_ativa, filiais_do_contexto
from core.permissions import PERFIS_ANALISE_FINANCEIRA, perfil_required
from core.relatorios import resposta_csv

from . import graficos_svg
from .services_analise import (
    MESES,
    AnaliseFinanceira,
    formatar_pct,
    linhas_csv_creditos_debitos,
    linhas_csv_dre,
    links_de_acao,
    montar_creditos_debitos,
    montar_dre,
    montar_saude,
    periodo_do_request,
    rotulo_mes_curto,
    rotulo_mes_longo,
    somar_meses,
    ultimo_dia,
)

ABAS = (
    ("dre", "DRE Gerencial", "financeiro:analise_dre", "bi-table"),
    ("creditos_debitos", "Créditos × Débitos", "financeiro:analise_creditos_debitos", "bi-arrow-left-right"),
    ("saude", "Saúde Financeira", "financeiro:analise_saude", "bi-heart-pulse"),
)
TITULOS = {chave: rotulo for chave, rotulo, _url, _icone in ABAS}


def _querystring(ano, mes, filial=None, **extras):
    partes = [f"ano={int(ano)}", f"mes={int(mes)}"]
    if filial is not None:
        partes.append(f"filial={int(filial.pk)}")
    partes += [f"{chave}={valor}" for chave, valor in extras.items()]
    return "?" + "&".join(partes)


def _contexto_base(request, aba):
    hoje = timezone.localdate()
    ano, mes = periodo_do_request(request.GET, hoje)
    filiais = list(filiais_do_contexto(request))
    filial_id = (request.GET.get("filial") or "").strip()
    selecionada = next((filial for filial in filiais if str(filial.pk) == filial_id), None)
    escopo = [selecionada] if selecionada is not None else filiais
    analise = AnaliseFinanceira(escopo, hoje)

    url_aba = reverse(dict((c, u) for c, _r, u, _i in ABAS)[aba])
    anterior = somar_meses(ano, mes, -1)
    seguinte = somar_meses(ano, mes, 1)
    filial_texto = selecionada.nome if selecionada is not None else (
        filiais[0].nome if len(filiais) == 1 else "Todas as filiais"
    )
    contexto = {
        "aba": aba,
        "titulo_pagina": TITULOS[aba],
        "abas": [
            {
                "rotulo": rotulo, "icone": icone, "ativa": chave == aba,
                "url": reverse(nome_url) + _querystring(ano, mes, selecionada),
            }
            for chave, rotulo, nome_url, icone in ABAS
        ],
        "hoje": hoje,
        "ano": ano,
        "mes": mes,
        "mes_rotulo": rotulo_mes_longo(ano, mes),
        "mes_curto": rotulo_mes_curto(ano, mes),
        "e_mes_atual": (ano, mes) == (hoje.year, hoje.month),
        "url_mes_anterior": url_aba + _querystring(*anterior, selecionada),
        "url_mes_seguinte": url_aba + _querystring(*seguinte, selecionada),
        "url_mes_atual": url_aba + (_querystring(hoje.year, hoje.month, selecionada)),
        "rotulo_mes_anterior": rotulo_mes_longo(*anterior),
        "rotulo_mes_seguinte": rotulo_mes_longo(*seguinte),
        "url_csv": "",
        "filiais": filiais,
        "filial_selecionada": selecionada,
        "filial_texto": filial_texto,
        "sem_filial": not filiais,
        "tem_dados": bool(filiais) and analise.tem_dados(),
        "primeiro_mes_rotulo": (
            rotulo_mes_longo(*analise.primeiro_mes_com_dados()) if filiais and analise.tem_dados() else ""
        ),
        "periodo": f"{date(ano, mes, 1):%d/%m/%Y} a {ultimo_dia(ano, mes):%d/%m/%Y}",
        "filtros_impressao": [f"Filial: {filial_texto}"],
        "meses_opcoes": [(numero, nome.capitalize()) for numero, nome in enumerate(MESES, start=1)],
        "anos_opcoes": list(range(hoje.year - 3, hoje.year + 2)),
        "links": links_de_acao(request.user),
        "empresa": empresa_ativa(request),
    }
    if ano not in contexto["anos_opcoes"]:
        contexto["anos_opcoes"] = sorted(contexto["anos_opcoes"] + [ano])
    return analise, contexto


def _par_de_graficos(funcao, *args, titulo, **kwargs):
    """Versão larga (tela grande e impressão) + compacta (celular)."""
    largo = funcao(*args, titulo=titulo, largura=720, compacto=False, **kwargs)
    compacto = funcao(*args, titulo=titulo, largura=360, compacto=True, **kwargs)
    return {"largo": mark_safe(largo), "compacto": mark_safe(compacto), "titulo": titulo}


@perfil_required(*PERFIS_ANALISE_FINANCEIRA)
def analise_dre(request):
    """DRE Gerencial (competência) do mês, com mês anterior, variação e
    média, curva de 12 meses e composição do mês."""
    analise, contexto = _contexto_base(request, "dre")
    ano, mes = contexto["ano"], contexto["mes"]
    dados = montar_dre(analise, ano, mes)

    if request.GET.get("formato") == "csv":
        cabecalho, linhas = linhas_csv_dre(dados)
        return resposta_csv(f"dre_gerencial_{ano}_{mes:02d}.csv", cabecalho, linhas)

    contexto["url_csv"] = reverse("financeiro:analise_dre") + _querystring(
        ano, mes, contexto["filial_selecionada"], formato="csv"
    )
    serie = dados["serie"]
    rotulos = [d.rotulo for d in serie]
    # Ajuste final (produto-e-demo): o ponto do mês em andamento avisa que é
    # parcial (receita do mês inteiro × compras só até hoje).
    dicas = [
        rotulo_mes_longo(d.ano, d.mes) + (" (parcial)" if d.em_andamento and d.receita_configurada else "")
        for d in serie
    ]
    series_curva = [
        {"nome": "Receita total", "nome_curto": "Receita", "classe": "s1",
         "valores": [d.receita_total if d.receita_configurada else None for d in serie]},
        {"nome": "Despesas totais", "nome_curto": "Despesas", "classe": "s2",
         "valores": [d.despesas_totais for d in serie]},
        {"nome": "Resultado", "nome_curto": "Resultado", "classe": "s3",
         "valores": [d.resultado if d.receita_configurada else None for d in serie]},
    ]
    atual = dados["atual"]
    cascata_tabela = []
    for etapa in dados["cascata"]:
        # Rodada final: mesma convenção da DRE — o "(−)" já diz que é uma
        # dedução, então o valor sai positivo (antes: "(−) ... R$ -14.723,51",
        # sinal duplo). O gráfico continua desenhando a redução para baixo.
        cascata_tabela.append({
            "rotulo": ("(−) " if etapa["tipo"] == "reducao" else "(=) ") + etapa["rotulo"],
            "valor_fmt": graficos_svg.formatar_brl(etapa["valor"]),
            "pct_fmt": formatar_pct(atual.pct(etapa["valor"])),
        })
    # Críticos (rodada 2): no 1º mês da cliente a "curva" virava 3 pontos
    # soltos (e, só com a receita lançada, o ponto da receita sumia debaixo
    # do resultado). Mesma regra da Saúde (`_curva_das_margens`): com menos
    # de 2 meses com lançamento, nada de curva — a tela explica e a tabela
    # mostra os valores.
    meses_com_dado = sum(1 for d in serie if d.receita_configurada or d.despesas_totais)
    grafico_curva = None
    if meses_com_dado >= 2:
        grafico_curva = _par_de_graficos(
            graficos_svg.grafico_linhas, series_curva, rotulos, rotulos_dica=dicas,
            titulo=f"Receita total, despesas totais e resultado de {rotulos[0]} a {rotulos[-1]}",
            altura=280,
        )
    contexto.update({
        "dre": dados,
        "cascata_tabela": cascata_tabela,
        "legenda_cascata": [
            {"nome": "Receita total", "classe": "s1", "forma": "barra"},
            {"nome": "Compras e custos (deduções)", "classe": "s2", "forma": "barra"},
            {"nome": "Margens e resultado", "classe": "s3", "forma": "barra"},
        ],
        "legenda_curva": series_curva,
        "grafico_curva": grafico_curva,
        # Rodada final: sem receita no mês, a composição "da receita ao
        # resultado" desenharia um resultado negativo que é só ausência de
        # dado — a tela mostra uma nota no lugar do gráfico e da tabela.
        "grafico_cascata": _par_de_graficos(
            graficos_svg.grafico_cascata, dados["cascata"],
            titulo=f"Composição de {contexto['mes_rotulo']}: da receita total ao resultado operacional",
        ) if atual.receita_configurada else None,
    })
    return render(request, "financeiro/analise/dre.html", contexto)


@perfil_required(*PERFIS_ANALISE_FINANCEIRA)
def analise_creditos_debitos(request):
    """Créditos × Débitos (caixa por vencimento): 12 meses + balancete do mês."""
    analise, contexto = _contexto_base(request, "creditos_debitos")
    ano, mes = contexto["ano"], contexto["mes"]
    dados = montar_creditos_debitos(analise, ano, mes)

    if request.GET.get("formato") == "csv":
        cabecalho, linhas = linhas_csv_creditos_debitos(dados)
        return resposta_csv(f"creditos_debitos_{ano}_{mes:02d}.csv", cabecalho, linhas)

    contexto["url_csv"] = reverse("financeiro:analise_creditos_debitos") + _querystring(
        ano, mes, contexto["filial_selecionada"], formato="csv"
    )
    serie = dados["serie"]
    rotulos = [c.rotulo for c in serie]
    dicas = [rotulo_mes_longo(c.ano, c.mes) for c in serie]
    barras = [
        {"nome": "Créditos", "classe": "s1", "valores": [c.creditos for c in serie]},
        {"nome": "Débitos", "classe": "s2", "valores": [c.debitos for c in serie]},
    ]
    # Rodada final: mês sem receita lançada não tem saldo (fica sem ponto).
    linha = {"nome": "Saldo do mês", "classe": "s3",
             "valores": [c.saldo if c.receita_configurada else None for c in serie]}
    # Mesma regra da DRE e da Saúde: com um mês só, o "mês a mês" seria um
    # par de barras e um ponto solto — a tela explica e mostra o balancete e
    # a tabela.
    meses_com_movimento = sum(1 for c in serie if c.creditos or c.debitos)
    grafico_cd = None
    if meses_com_movimento >= 2:
        grafico_cd = _par_de_graficos(
            graficos_svg.grafico_barras_linha, rotulos, barras, linha, rotulos_dica=dicas,
            titulo=f"Créditos e débitos por mês, com o saldo do mês, de {rotulos[0]} a {rotulos[-1]}",
            altura=300,
        )
    contexto.update({
        "cd": dados,
        "legenda_cd": [
            {"nome": "Créditos", "classe": "s1", "forma": "barra"},
            {"nome": "Débitos", "classe": "s2", "forma": "barra"},
            {"nome": "Saldo do mês", "classe": "s3", "forma": "linha"},
        ],
        "grafico_cd": grafico_cd,
    })
    return render(request, "financeiro/analise/creditos_debitos.html", contexto)


@perfil_required(*PERFIS_ANALISE_FINANCEIRA)
def analise_saude(request):
    """Saúde Financeira: indicadores com semáforo, ponto de equilíbrio,
    tendência, comprometimento futuro e recomendações por regras fixas."""
    analise, contexto = _contexto_base(request, "saude")
    ano, mes = contexto["ano"], contexto["mes"]
    dados = montar_saude(analise, ano, mes, usuario=request.user, empresa=contexto["empresa"])
    contexto["saude"] = dados
    if not dados["sem_receita"]:
        serie = dados["serie"]
        contexto.update(_curva_das_margens(serie))
    return render(request, "financeiro/analise/saude.html", contexto)


def _curva_das_margens(serie) -> dict:
    """Curva das margens da Saúde Financeira (crítico de UX, rodada 1).

    - Sem custos variáveis, a margem bruta É a margem de contribuição: as
      duas linhas coincidiam e a azul sumia debaixo da laranja (a legenda
      mostrava 3 séries e o gráfico 2). Quando coincidem em TODOS os meses,
      viram uma série só, com o nome dizendo por quê; quando coincidem só
      em alguns, a de contribuição é tracejada (a de baixo aparece nos vãos).
    - Com um único mês com receita, as três séries seriam um ponto só:
      nada de gráfico — a tela explica e a tabela mostra os valores."""
    rotulos = [d.rotulo for d in serie]
    dicas = [rotulo_mes_longo(d.ano, d.mes) for d in serie]
    bruta = [d.pct(d.margem_bruta) if d.receita_configurada else None for d in serie]
    contribuicao = [d.pct(d.margem_contribuicao) if d.receita_configurada else None for d in serie]
    operacional = [d.pct(d.resultado) if d.receita_configurada else None for d in serie]
    meses_com_dado = sum(1 for valor in bruta if valor is not None)
    if meses_com_dado < 2:
        return {"legenda_margens": [], "grafico_margens": None, "legenda_texto_margens": ""}

    # Iguais NA TELA (mesmo % com 1 casa) → linhas sobrepostas.
    iguais = [b == c for b, c in zip(bruta, contribuicao) if b is not None and c is not None]
    sem_variaveis_em_todos = all(d.custos_variaveis == 0 for d in serie if d.receita_configurada)
    if sem_variaveis_em_todos:
        series_margens = [
            {"nome": "Margem bruta = de contribuição (sem custos variáveis)", "nome_curto": "Bruta = contrib.",
             "classe": "s1", "valores": bruta},
        ]
    else:
        series_margens = [
            {"nome": "Margem bruta", "nome_curto": "Bruta", "classe": "s1", "valores": bruta},
            {"nome": "Margem de contribuição", "nome_curto": "Contribuição", "classe": "s2",
             "valores": contribuicao, "tracejada": any(iguais)},
        ]
    series_margens.append(
        {"nome": "Margem operacional", "nome_curto": "Operacional", "classe": "s3", "valores": operacional}
    )
    texto = "Passe o mouse, toque ou use a tecla Tab nos pontos para ver os valores — eles também estão na tabela logo abaixo."
    if any(serie.get("tracejada") for serie in series_margens):
        texto += " Tracejada: margem de contribuição (nos meses sem custos variáveis ela é igual à margem bruta)."
    return {
        "legenda_margens": series_margens,
        "legenda_texto_margens": texto,
        "grafico_margens": _par_de_graficos(
            graficos_svg.grafico_linhas, series_margens, rotulos, rotulos_dica=dicas, formato="pct",
            titulo=f"Margens em % da receita de {rotulos[0]} a {rotulos[-1]}", altura=260,
        ),
    }
