"""Capacidade dos Compradores — tela do Financeiro (RC do Épico 01, Correção 03).

A capacidade pertence ao FINANCEIRO: ele define a capacidade diária (na
Configuração Financeira), distribui entre os compradores (limite individual),
redistribui durante o dia, bloqueia/libera compradores e bloqueia dias no
Calendário Operacional. Nenhuma regra vive aqui — as ações delegam aos
services do Motor de Capacidade (`compras.services`), que auditam em
LogConfiguracao e notificam o comprador; esta view só coleta o contexto,
valida a entrada e escolhe o template.
"""
from datetime import date
from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from compras.services import (
    bloquear_comprador,
    definir_limite_comprador,
    liberar_comprador,
    obter_situacao_compradores,
)
from core.contexto import empresa_ativa, filiais_do_contexto
from core.permissions import permissao_required
from finance_engine.calendario_operacional import rotulo_do_tipo
from finance_engine.services import motor_financeiro
from financeiro.services import calcular_capacidade_compra
from usuarios.models import Usuario

ZERO = Decimal("0")


def _filial_selecionada(request, filiais):
    filial_id = request.GET.get("filial") or request.POST.get("filial")
    if filial_id:
        for filial in filiais:
            if str(filial.pk) == str(filial_id):
                return filial
    # Críticos (rodada 2): sem escolha explícita, a filial do PRÓPRIO usuário
    # (a mesma do cabeçalho e do card "Capacidade do dia" da barra lateral) —
    # antes abria a 1ª filial do contexto e a tela falava de outra loja.
    for filial in filiais:
        if filial.pk == request.user.filial_id:
            return filial
    return filiais[0] if filiais else None


@permissao_required("capacidade.gerenciar")
def capacidade_compradores(request):
    empresa = empresa_ativa(request)
    filiais = list(filiais_do_contexto(request))
    hoje = date.today()

    contexto = {"hoje": hoje, "sem_filial": not filiais, "filiais": filiais}
    if not filiais or empresa is None:
        return render(request, "financeiro/capacidade_compradores.html", contexto)

    filial = _filial_selecionada(request, filiais)
    situacao = obter_situacao_compradores(empresa, filial, hoje)
    capacidade = calcular_capacidade_compra(filial, hoje.year, hoje.month)
    # Críticos (rodada 2): o KPI mostrava o limite BASE de dia útil como
    # "capacidade a distribuir hoje" e cada dotação como "Disponível/Livre"
    # num sábado/domingo/feriado — mas o limite real do dia (day-walk do
    # Motor, o mesmo dos painéis e de `avaliar_e_criar_compra`) é R$ 0 e
    # qualquer compra vai para aprovação. Agora a tela lê o limite de HOJE.
    posicao_hoje = motor_financeiro.posicao_do_dia(filial, hoje)
    hoje_sem_limite = bool(capacidade["capacidade_configurada"] and posicao_hoje.sem_limite_proprio)

    total_limites = sum((c["limite"] for c in situacao if c["limite"] is not None), ZERO)
    total_utilizado = sum((c["utilizado"] for c in situacao), ZERO)
    total_reservado = sum((c["reservado"] for c in situacao), ZERO)
    total_gasto = total_utilizado + total_reservado

    contexto.update(
        {
            "filial": filial,
            "situacao": situacao,
            # Limite BASE de um dia útil (capacidade do mês ÷ dias úteis):
            # referência para comparar com a soma das dotações individuais.
            "limite_diario": capacidade["limite_diario"],
            # Limite de HOJE (day-walk do Motor: zero em fim de semana/
            # feriado/bloqueio; inclui saldo herdado quando ligado).
            "limite_hoje": posicao_hoje.limite_efetivo,
            "hoje_sem_limite": hoje_sem_limite,
            "rotulo_dia_hoje": rotulo_do_tipo(posicao_hoje.tipo_dia),
            "total_limites": total_limites,
            "total_utilizado": total_utilizado,
            "total_reservado": total_reservado,
            "total_gasto": total_gasto,
            "compradores_bloqueados": sum(1 for c in situacao if c["bloqueado"]),
            "sem_limite_definido": sum(1 for c in situacao if c["limite"] is None),
            # Etapa 02 (Cliente-Ready): "Limite diário da filial" R$ 0,00
            # sem Receita cadastrada parece um cálculo real — este sinal
            # deixa o template distinguir isso de uma capacidade zerada
            # de propósito.
            "capacidade_configurada": capacidade["capacidade_configurada"],
        }
    )
    return render(request, "financeiro/capacidade_compradores.html", contexto)


def _comprador_da_empresa(empresa, usuario_id):
    return get_object_or_404(
        Usuario, pk=usuario_id, empresa=empresa, perfil=Usuario.Perfil.COMPRADOR
    )


def _redirect_capacidade(request):
    filial_id = request.POST.get("filial")
    destino = "financeiro:capacidade_compradores"
    if filial_id:
        return redirect(f"/financeiro/capacidade-compradores/?filial={filial_id}")
    return redirect(destino)


@permissao_required("capacidade.gerenciar")
@require_POST
def capacidade_definir_limite(request, usuario_id):
    empresa = empresa_ativa(request)
    comprador = _comprador_da_empresa(empresa, usuario_id)

    bruto = (request.POST.get("limite") or "").strip().replace(".", "").replace(",", ".")
    if bruto == "":
        limite = None
    else:
        try:
            limite = Decimal(bruto)
        except InvalidOperation:
            messages.error(request, "Informe um valor de limite válido (ex.: 1.500,00) ou deixe em branco para remover.")
            return _redirect_capacidade(request)
        if limite <= 0:
            messages.error(request, "O limite individual deve ser maior que zero — para remover o limite, deixe o campo em branco.")
            return _redirect_capacidade(request)

    definir_limite_comprador(comprador, empresa, limite, request.user)
    nome = comprador.get_full_name() or comprador.username
    if limite is None:
        messages.success(request, f"Limite individual de {nome} removido — vale apenas o limite da filial.")
    else:
        messages.success(request, f"Limite individual de {nome} atualizado.")
    return _redirect_capacidade(request)


@permissao_required("capacidade.gerenciar")
@require_POST
def capacidade_bloquear(request, usuario_id):
    empresa = empresa_ativa(request)
    comprador = _comprador_da_empresa(empresa, usuario_id)
    bloquear_comprador(comprador, empresa, request.user)
    messages.warning(
        request,
        f"{comprador.get_full_name() or comprador.username} bloqueado: novas compras serão barradas na origem até a liberação.",
    )
    return _redirect_capacidade(request)


@permissao_required("capacidade.gerenciar")
@require_POST
def capacidade_liberar(request, usuario_id):
    empresa = empresa_ativa(request)
    comprador = _comprador_da_empresa(empresa, usuario_id)
    liberar_comprador(comprador, empresa, request.user)
    messages.success(request, f"{comprador.get_full_name() or comprador.username} liberado para comprar.")
    return _redirect_capacidade(request)
