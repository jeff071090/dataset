"""Gráficos SVG gerados no servidor — Análise Financeira.

Sem biblioteca externa nem JavaScript: cada função devolve uma string SVG
pronta para ser embutida no HTML (a view marca como segura). Regras que
valem para TODOS os gráficos deste módulo:

- Nunca emitem coordenada inválida: todo número passa por `_f()`, que
  converte Decimal/None/NaN/infinito em um float finito; divisões são
  protegidas e uma série toda zero (ou vazia) ainda gera um gráfico válido.
- Texto dinâmico sempre escapado (`django.utils.html.escape`).
- Acessibilidade: `role="img"` + `aria-label` no <svg>, um <title> geral e
  um <title> em cada ponto/barra (tooltip nativo do navegador). A tabela
  de dados equivalente é renderizada pelo template, sempre visível.
- Cores por PAPEL, via classes CSS (`static/css/analise.css`): série 1
  (receitas/créditos), série 2 (despesas/débitos), série 3 (resultado/
  saldo) — paleta validada pelo validador da skill de dataviz (ordem fixa,
  nunca por ranking). Texto usa tokens de texto, nunca a cor da série.
- Responsivo por `viewBox`; o template oferece uma versão larga (tela
  grande e impressão) e uma compacta (celular), com fontes maiores em
  proporção, para o texto continuar legível em 360px.
- Rótulos em pt-BR: "R$ 1.234,56" e meses "set/26".
"""
import math
from decimal import ROUND_HALF_UP, Decimal

from django.utils.html import escape

ZERO = Decimal("0")

# Espaço reservado para o rótulo direto no fim das linhas (versão larga).
_MARGEM_ROTULO_FIM = 92


# ---------------------------------------------------------------------------
# Números e formatação
# ---------------------------------------------------------------------------

def _f(valor) -> float:
    """Float finito, sempre (Decimal, int, None, NaN ou infinito → número)."""
    if valor is None:
        return 0.0
    try:
        numero = float(valor)
    except (TypeError, ValueError, ArithmeticError):
        return 0.0
    return numero if math.isfinite(numero) else 0.0


def _c(valor) -> str:
    """Coordenada com 1 casa decimal (nunca "nan"/"inf")."""
    texto = f"{_f(valor):.1f}"
    return "0.0" if texto == "-0.0" else texto


def _agrupar_milhar(inteiro: str) -> str:
    partes = []
    while len(inteiro) > 3:
        partes.insert(0, inteiro[-3:])
        inteiro = inteiro[:-3]
    partes.insert(0, inteiro)
    return ".".join(partes)


def formatar_numero(valor, casas: int = 2) -> str:
    """Número no padrão brasileiro ("1.234,56"), determinístico — não
    depende do idioma ativo do request."""
    if valor is None:
        valor = ZERO
    try:
        valor = Decimal(str(valor))
    except (ArithmeticError, ValueError):
        valor = ZERO
    if not valor.is_finite():
        valor = ZERO
    quantum = Decimal(1).scaleb(-casas) if casas else Decimal(1)
    arredondado = valor.quantize(quantum, rounding=ROUND_HALF_UP)
    negativo = arredondado < 0
    inteiro, _, fracao = f"{abs(arredondado):f}".partition(".")
    texto = _agrupar_milhar(inteiro)
    if casas:
        texto = f"{texto},{(fracao + '0' * casas)[:casas]}"
    return f"-{texto}" if negativo else texto


def formatar_brl(valor, casas: int = 2) -> str:
    """ "R$ 1.234,56" / "R$ -1.234,56" (mesmo padrão das telas existentes,
    que escrevem "R$ {{ valor|floatformat:2 }}")."""
    return f"R$ {formatar_numero(valor, casas)}"


def formatar_brl_compacto(valor) -> str:
    """Rótulo curto para eixos e barras estreitas: "R$ 850", "R$ 2,5 mil",
    "R$ 48 mil", "R$ 1,3 mi" (arredondamento comercial, em Decimal)."""
    numero = Decimal(str(_f(valor)))
    absoluto = abs(numero)
    sinal = "-" if numero < 0 else ""
    if absoluto >= 1_000_000:
        base, sufixo = absoluto / Decimal(1_000_000), " mi"
    elif absoluto >= 1_000:
        base, sufixo = absoluto / Decimal(1_000), " mil"
    else:
        return f"R$ {sinal}{formatar_numero(absoluto, 0)}"
    uma_casa = base.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    casas = 1 if base < 10 and uma_casa != uma_casa.to_integral_value() else 0
    return f"R$ {sinal}{formatar_numero(base, casas)}{sufixo}"


def formatar_percentual_eixo(valor) -> str:
    return f"{formatar_numero(Decimal(str(round(_f(valor), 1))), 0)}%"


def _largura_texto(texto: str, fonte: float) -> float:
    return len(texto) * fonte * 0.56


# ---------------------------------------------------------------------------
# Escala
# ---------------------------------------------------------------------------

def escala_bonita(minimo, maximo, alvo: int = 4):
    """Domínio [lo, hi] com marcas "redondas" (1/2/2,5/5 × 10^k), sempre
    incluindo o zero. Série toda zero → domínio [0, 1.000] (um gráfico
    válido, só com a linha de base)."""
    lo = min(0.0, _f(minimo))
    hi = max(0.0, _f(maximo))
    if hi - lo <= 0:
        hi = lo + 1000.0
    bruto = (hi - lo) / max(alvo, 1)
    magnitude = 10 ** math.floor(math.log10(bruto)) if bruto > 0 else 1.0
    passo = magnitude * 10
    for multiplo in (1, 2, 2.5, 5, 10):
        if multiplo * magnitude >= bruto:
            passo = multiplo * magnitude
            break
    lo_t = math.floor(lo / passo + 1e-9) * passo
    hi_t = math.ceil(hi / passo - 1e-9) * passo
    if hi_t <= lo_t:
        hi_t = lo_t + passo
    quantidade = int(round((hi_t - lo_t) / passo))
    marcas = [lo_t + i * passo for i in range(quantidade + 1)]
    return lo_t, hi_t, marcas


def _mapeador(lo, hi, px_inicio, px_fim):
    extensao = (hi - lo) or 1.0

    def mapear(valor):
        return px_inicio + (_f(valor) - lo) / extensao * (px_fim - px_inicio)

    return mapear


# ---------------------------------------------------------------------------
# Peças
# ---------------------------------------------------------------------------

def _abrir_svg(largura, altura, titulo, classe_extra=""):
    titulo = escape(titulo)
    classe = f"an-svg {classe_extra}".strip()
    return (
        f'<svg class="{classe}" viewBox="0 0 {int(largura)} {int(altura)}" role="img" '
        f'aria-label="{titulo}" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">'
        f"<title>{titulo}</title>"
    )


def _barra_vertical(x, y_valor, y_zero, largura, raio=4.0):
    """Coluna com a ponta de dado arredondada (4px) e a base reta."""
    x, y_valor, y_zero, largura = _f(x), _f(y_valor), _f(y_zero), _f(largura)
    altura = abs(y_zero - y_valor)
    if altura < 0.5 or largura <= 0:
        return ""
    r = min(raio, altura, largura / 2)
    if y_valor < y_zero:  # positiva: ponta em cima
        return (
            f"M{_c(x)},{_c(y_zero)} V{_c(y_valor + r)} Q{_c(x)},{_c(y_valor)} {_c(x + r)},{_c(y_valor)} "
            f"H{_c(x + largura - r)} Q{_c(x + largura)},{_c(y_valor)} {_c(x + largura)},{_c(y_valor + r)} "
            f"V{_c(y_zero)} Z"
        )
    return (  # negativa: ponta embaixo
        f"M{_c(x)},{_c(y_zero)} V{_c(y_valor - r)} Q{_c(x)},{_c(y_valor)} {_c(x + r)},{_c(y_valor)} "
        f"H{_c(x + largura - r)} Q{_c(x + largura)},{_c(y_valor)} {_c(x + largura)},{_c(y_valor - r)} "
        f"V{_c(y_zero)} Z"
    )


def _barra_horizontal(x_inicio, x_fim, y, espessura, raio=4.0):
    """Barra horizontal com a ponta de dado (lado de `x_fim`) arredondada."""
    x_inicio, x_fim, y, espessura = _f(x_inicio), _f(x_fim), _f(y), _f(espessura)
    comprimento = abs(x_fim - x_inicio)
    if comprimento < 0.5:
        # valor zero: um traço mínimo para a linha não "sumir"
        return f"M{_c(x_inicio)},{_c(y)} h1 v{_c(espessura)} h-1 Z"
    r = min(raio, comprimento, espessura / 2)
    base = y + espessura
    if x_fim >= x_inicio:
        return (
            f"M{_c(x_inicio)},{_c(y)} H{_c(x_fim - r)} Q{_c(x_fim)},{_c(y)} {_c(x_fim)},{_c(y + r)} "
            f"V{_c(base - r)} Q{_c(x_fim)},{_c(base)} {_c(x_fim - r)},{_c(base)} H{_c(x_inicio)} Z"
        )
    return (
        f"M{_c(x_inicio)},{_c(y)} H{_c(x_fim + r)} Q{_c(x_fim)},{_c(y)} {_c(x_fim)},{_c(y + r)} "
        f"V{_c(base - r)} Q{_c(x_fim)},{_c(base)} {_c(x_fim + r)},{_c(base)} H{_c(x_inicio)} Z"
    )


def _grade_horizontal(partes, marcas, y_de, x0, x1, formatador, fonte):
    for marca in marcas:
        y = y_de(marca)
        classe = "an-eixo" if abs(marca) < 1e-9 else "an-grade"
        partes.append(f'<line class="{classe}" x1="{_c(x0)}" y1="{_c(y)}" x2="{_c(x1)}" y2="{_c(y)}"/>')
        partes.append(
            f'<text class="an-rotulo an-num" x="{_c(x0 - 6)}" y="{_c(y + fonte * 0.35)}" '
            f'text-anchor="end" font-size="{fonte}">{escape(formatador(marca))}</text>'
        )


def _indices_rotulos_x(n, largura_util, fonte, rotulos):
    """Quais meses recebem rótulo no eixo X — todos quando cabem; senão um
    a cada 2 (ou 3), sempre incluindo o último (o mês selecionado)."""
    if n <= 0:
        return set()
    maior = max((_largura_texto(r, fonte) for r in rotulos), default=0) + 6
    passo = 1
    while passo < n and (largura_util / max(n - 1, 1)) * passo < maior:
        passo += 1
    indices = {i for i in range(n - 1, -1, -passo)}
    return indices


# ---------------------------------------------------------------------------
# Gráfico de linhas (curva de 12 meses)
# ---------------------------------------------------------------------------

def grafico_linhas(series, rotulos, *, titulo, rotulos_dica=None, formato="brl",
                   largura=720, altura=280, compacto=False):
    """Linhas com o mesmo eixo Y para todas as séries (nunca eixo duplo).

    `series`: lista de {"nome", "classe" ("s1"/"s2"/"s3"), "valores"} —
    `None` em um valor abre uma lacuna (mês sem dado), nunca um zero falso.
    `rotulos`: rótulo curto de cada mês ("set/26"); `rotulos_dica`: rótulo
    longo usado no tooltip (padrão: o curto)."""
    rotulos = [str(r) for r in rotulos]
    rotulos_dica = [str(r) for r in (rotulos_dica or rotulos)]
    n = len(rotulos)
    fonte = 14 if compacto else 12
    formatador_eixo = formatar_percentual_eixo if formato == "pct" else formatar_brl_compacto

    def formatador_dica(valor):
        if formato == "pct":
            return f"{formatar_numero(valor, 1)}%"
        return formatar_brl(valor)

    valores = [_f(v) for serie in series for v in serie["valores"] if v is not None]
    lo, hi, marcas = escala_bonita(min(valores, default=0.0), max(valores, default=0.0))
    margem_esq = max((_largura_texto(formatador_eixo(m), fonte) for m in marcas), default=30) + 12
    topo, base = 14, fonte + 16
    y_de = _mapeador(lo, hi, altura - base, topo)

    # Rótulo direto no fim de cada linha (≤ 4 séries, versão larga) só
    # quando os finais não colidem; senão ficam a legenda + tooltip.
    finais = []
    for serie in series:
        vals = list(serie["valores"])
        if vals and vals[-1] is not None:
            finais.append((y_de(vals[-1]), serie))
    usar_rotulo_fim = (
        not compacto and n > 1 and len(series) <= 4 and len(finais) == len(series)
        and all(abs(a[0] - b[0]) >= fonte + 3 for i, a in enumerate(finais) for b in finais[i + 1:])
    )
    margem_dir = _MARGEM_ROTULO_FIM if usar_rotulo_fim else 16
    x0, x1 = margem_esq, largura - margem_dir
    respiro = 14

    def x_de(indice):
        if n <= 1:
            return (x0 + x1) / 2
        return x0 + respiro + indice * (x1 - x0 - 2 * respiro) / (n - 1)

    partes = [_abrir_svg(largura, altura, titulo, "an-svg-linhas")]
    _grade_horizontal(partes, marcas, y_de, x0, x1, formatador_eixo, fonte)

    for indice in sorted(_indices_rotulos_x(n, x1 - x0 - 2 * respiro, fonte, rotulos)):
        partes.append(
            f'<text class="an-rotulo" x="{_c(x_de(indice))}" y="{_c(altura - 6)}" '
            f'text-anchor="middle" font-size="{fonte}">{escape(rotulos[indice])}</text>'
        )

    for serie in series:
        classe = escape(serie.get("classe", "s1"))
        vals = list(serie["valores"])
        segmento = []
        segmentos = []
        for indice, valor in enumerate(vals):
            if valor is None:
                if segmento:
                    segmentos.append(segmento)
                segmento = []
                continue
            segmento.append((x_de(indice), y_de(valor)))
        if segmento:
            segmentos.append(segmento)
        # "tracejada": série desenhada por cima de outra que pode coincidir
        # com ela (ex.: margem de contribuição = margem bruta sem custos
        # variáveis) — a de baixo continua visível nos vãos do tracejado.
        tracejada = " an-tracejada" if serie.get("tracejada") else ""
        for trecho in segmentos:
            if len(trecho) >= 2:
                d = "M" + " L".join(f"{_c(x)},{_c(y)}" for x, y in trecho)
                partes.append(f'<path class="an-linha an-{classe}{tracejada}" d="{d}"/>')
        for indice, valor in enumerate(vals):
            if valor is None:
                continue
            x, y = x_de(indice), y_de(valor)
            dica = f"{rotulos_dica[indice] if indice < len(rotulos_dica) else ''} — {serie['nome']}: {formatador_dica(valor)}"
            partes.append(
                f'<g class="an-ponto-grupo"><title>{escape(dica)}</title>'
                f'<circle class="an-alvo" cx="{_c(x)}" cy="{_c(y)}" r="11"/>'
                f'<circle class="an-ponto an-{classe}" cx="{_c(x)}" cy="{_c(y)}" r="4"/></g>'
            )

    if usar_rotulo_fim:
        for y, serie in finais:
            partes.append(
                f'<text class="an-rotulo-serie" x="{_c(x_de(n - 1) + 10)}" y="{_c(y + fonte * 0.35)}" '
                f'font-size="{fonte}">{escape(serie.get("nome_curto") or serie["nome"])}</text>'
            )

    partes.append("</svg>")
    return "".join(partes)


# ---------------------------------------------------------------------------
# Barras agrupadas + linha (créditos × débitos com o saldo)
# ---------------------------------------------------------------------------

def grafico_barras_linha(rotulos, barras, linha, *, titulo, rotulos_dica=None,
                         largura=720, altura=300, compacto=False):
    """Colunas agrupadas por mês (ex.: créditos e débitos) e uma linha no
    MESMO eixo em R$ (ex.: saldo do mês) — um eixo só, a linha pode ficar
    negativa (o zero é sempre a linha de base destacada)."""
    rotulos = [str(r) for r in rotulos]
    rotulos_dica = [str(r) for r in (rotulos_dica or rotulos)]
    n = len(rotulos)
    fonte = 14 if compacto else 12
    todos = [_f(v) for barra in barras for v in barra["valores"] if v is not None]
    if linha:
        todos += [_f(v) for v in linha["valores"] if v is not None]
    lo, hi, marcas = escala_bonita(min(todos, default=0.0), max(todos, default=0.0))
    margem_esq = max((_largura_texto(formatar_brl_compacto(m), fonte) for m in marcas), default=30) + 12
    topo, base = 14, fonte + 16
    x0, x1 = margem_esq, largura - 12
    y_de = _mapeador(lo, hi, altura - base, topo)
    y_zero = y_de(0)

    faixa = (x1 - x0) / max(n, 1)
    quantidade = max(len(barras), 1)
    espaco = 2.0  # "surface gap" entre colunas que se tocam
    largura_barra = max(3.0, min(24.0, (faixa * 0.72 - (quantidade - 1) * espaco) / quantidade))
    largura_grupo = quantidade * largura_barra + (quantidade - 1) * espaco

    partes = [_abrir_svg(largura, altura, titulo, "an-svg-barras")]
    _grade_horizontal(partes, marcas, y_de, x0, x1, formatar_brl_compacto, fonte)

    centros = [x0 + (i + 0.5) * faixa for i in range(n)]
    for indice in sorted(_indices_rotulos_x(n, faixa * max(n - 1, 1), fonte, rotulos)):
        partes.append(
            f'<text class="an-rotulo" x="{_c(centros[indice])}" y="{_c(altura - 6)}" '
            f'text-anchor="middle" font-size="{fonte}">{escape(rotulos[indice])}</text>'
        )

    for indice in range(n):
        inicio_grupo = centros[indice] - largura_grupo / 2
        for posicao, barra in enumerate(barras):
            valores = list(barra["valores"])
            valor = valores[indice] if indice < len(valores) else None
            if valor is None:
                continue
            x = inicio_grupo + posicao * (largura_barra + espaco)
            dica = f"{rotulos_dica[indice]} — {barra['nome']}: {formatar_brl(valor)}"
            caminho = _barra_vertical(x, y_de(valor), y_zero, largura_barra)
            partes.append(
                f'<g class="an-barra-grupo"><title>{escape(dica)}</title>'
                f'<rect class="an-alvo" x="{_c(x - 1)}" y="{_c(topo)}" width="{_c(largura_barra + 2)}" '
                f'height="{_c(altura - base - topo)}"/>'
                + (f'<path class="an-barra an-{escape(barra.get("classe", "s1"))}" d="{caminho}"/>' if caminho else "")
                + "</g>"
            )

    if linha:
        classe = escape(linha.get("classe", "s3"))
        pontos = [(centros[i], y_de(v)) for i, v in enumerate(linha["valores"]) if v is not None and i < n]
        if len(pontos) >= 2:
            d = "M" + " L".join(f"{_c(x)},{_c(y)}" for x, y in pontos)
            partes.append(f'<path class="an-linha an-{classe}" d="{d}"/>')
        for indice, valor in enumerate(linha["valores"]):
            if valor is None or indice >= n:
                continue
            dica = f"{rotulos_dica[indice]} — {linha['nome']}: {formatar_brl(valor)}"
            partes.append(
                f'<g class="an-ponto-grupo"><title>{escape(dica)}</title>'
                f'<circle class="an-alvo" cx="{_c(centros[indice])}" cy="{_c(y_de(valor))}" r="11"/>'
                f'<circle class="an-ponto an-{classe}" cx="{_c(centros[indice])}" cy="{_c(y_de(valor))}" r="4"/></g>'
            )

    partes.append("</svg>")
    return "".join(partes)


# ---------------------------------------------------------------------------
# Cascata horizontal (composição do mês: da receita ao resultado)
# ---------------------------------------------------------------------------

def grafico_cascata(etapas, *, titulo, largura=720, compacto=False):
    """Cascata horizontal: cada linha é uma etapa da DRE.

    `etapas`: lista de {"rotulo", "rotulo_curto", "tipo", "valor"}, com
    `tipo` em "total" (barra do zero até o valor — a receita),
    "reducao" (desconta `valor` do nível atual — compras, custos) ou
    "subtotal" (barra do zero até o nível atual — margens e resultado)."""
    fonte = 14 if compacto else 12
    altura_linha = 38 if compacto else 32
    espessura = 18
    coluna_rotulo = 124 if compacto else 190
    topo = 6

    nivel = 0.0
    barras = []
    for etapa in etapas:
        valor = _f(etapa.get("valor"))
        if etapa["tipo"] == "total":
            inicio, fim = 0.0, valor
            nivel = valor
        elif etapa["tipo"] == "reducao":
            inicio, fim = nivel, nivel - valor
            nivel = fim
        else:  # subtotal
            inicio, fim = 0.0, nivel
        barras.append((etapa, inicio, fim))

    def _texto_do_valor(etapa, fim):
        valor_mostrado = -_f(etapa.get("valor")) if etapa["tipo"] == "reducao" else fim
        texto = formatar_brl_compacto(valor_mostrado) if compacto else formatar_brl(valor_mostrado)
        return valor_mostrado, texto

    extremos = [b[1] for b in barras] + [b[2] for b in barras]
    lo, hi, marcas = escala_bonita(min(extremos, default=0.0), max(extremos, default=0.0), alvo=3 if compacto else 4)
    x0, x1 = coluna_rotulo, largura - 12
    # Críticos (rodada 2): o valor fica FORA da ponta da barra, e a barra que
    # ocupava quase todo o eixo (Receita total, Margem bruta, Margem de
    # contribuição — no celular, todas as principais) ficava sem espaço para
    # ele e o valor simplesmente não era desenhado. A área das barras agora
    # reserva à direita a largura do maior rótulo: todo valor cabe fora da
    # barra, em cor de texto normal (contraste garantido).
    folga_rotulo = max((_largura_texto(_texto_do_valor(e, fim)[1], fonte) for e, _i, fim in barras), default=0.0) + 8
    x1_barras = max(x0 + 40, x1 - folga_rotulo)
    x_de = _mapeador(lo, hi, x0, x1_barras)
    altura = topo + max(len(barras), 1) * altura_linha + fonte + 14

    partes = [_abrir_svg(largura, altura, titulo, "an-svg-cascata")]
    y_eixo = topo + len(barras) * altura_linha
    for marca in marcas:
        x = x_de(marca)
        classe = "an-eixo" if abs(marca) < 1e-9 else "an-grade"
        partes.append(f'<line class="{classe}" x1="{_c(x)}" y1="{_c(topo)}" x2="{_c(x)}" y2="{_c(y_eixo)}"/>')
    # Rótulos do eixo: nas pontas e no zero (evita colisão em tela estreita).
    marcas_rotulo = {marcas[0], marcas[-1]}
    if lo < 0 < hi:
        marcas_rotulo.add(0.0)
    if not compacto:
        marcas_rotulo = set(marcas)
    for marca in sorted(marcas_rotulo):
        ancora = "start" if marca == marcas[0] else ("end" if marca == marcas[-1] else "middle")
        partes.append(
            f'<text class="an-rotulo an-num" x="{_c(x_de(marca))}" y="{_c(y_eixo + fonte + 6)}" '
            f'text-anchor="{ancora}" font-size="{fonte - 1}">{escape(formatar_brl_compacto(marca))}</text>'
        )

    for indice, (etapa, inicio, fim) in enumerate(barras):
        y = topo + indice * altura_linha + (altura_linha - espessura) / 2
        classe = {"total": "s1", "reducao": "s2"}.get(etapa["tipo"], "s3")
        rotulo = etapa.get("rotulo_curto") if compacto else etapa["rotulo"]
        rotulo = rotulo or etapa["rotulo"]
        peso = ' font-weight="600"' if etapa["tipo"] != "reducao" else ""
        partes.append(
            f'<text class="an-rotulo-serie" x="0" y="{_c(y + espessura * 0.72)}" font-size="{fonte}"{peso}>'
            f"{escape(rotulo)}</text>"
        )
        valor_mostrado, texto_valor = _texto_do_valor(etapa, fim)
        dica = f"{etapa['rotulo']}: {formatar_brl(valor_mostrado)}"
        xa, xb = x_de(inicio), x_de(fim)
        caminho = _barra_horizontal(xa, xb, y, espessura)
        partes.append(
            f'<g class="an-barra-grupo"><title>{escape(dica)}</title>'
            f'<rect class="an-alvo" x="{_c(x0)}" y="{_c(y - 6)}" width="{_c(x1 - x0)}" height="{_c(espessura + 12)}"/>'
            f'<path class="an-barra an-{classe}" d="{caminho}"/></g>'
        )
        # Valor fora da ponta da barra (a folga reservada acima garante o
        # espaço); por segurança, sem espaço de nenhum lado ele vai DENTRO
        # da barra, ancorado no fim — nunca some.
        largura_txt = _largura_texto(texto_valor, fonte)
        direita, esquerda = max(xa, xb), min(xa, xb)
        classe_valor = "an-valor"
        if direita + 6 + largura_txt <= x1 + 10:
            x_txt, ancora = direita + 6, "start"
        elif esquerda - 6 - largura_txt >= x0:
            x_txt, ancora = esquerda - 6, "end"
        else:
            x_txt, ancora, classe_valor = direita - 6, "end", "an-valor an-valor-dentro"
        partes.append(
            f'<text class="{classe_valor} an-num" x="{_c(x_txt)}" y="{_c(y + espessura * 0.72)}" '
            f'text-anchor="{ancora}" font-size="{fonte}">{escape(texto_valor)}</text>'
        )

    partes.append("</svg>")
    return "".join(partes)


# ---------------------------------------------------------------------------
# Mini-curva (widget "Resultado do mês" dos dashboards)
# ---------------------------------------------------------------------------

def sparkline(valores, rotulos, *, titulo, largura=180, altura=46, formato="brl"):
    """Linha em tom de apoio, com o mês atual em destaque (cor de acento).
    Mês sem dado (None) abre lacuna. Sem nenhum valor → string vazia.
    `formato="pct"` mostra os valores do tooltip em % (sem R$)."""
    valores = list(valores)
    rotulos = [str(r) for r in rotulos]
    presentes = [_f(v) for v in valores if v is not None]
    if not presentes:
        return ""
    lo, hi = min(0.0, min(presentes)), max(0.0, max(presentes))
    if hi - lo <= 0:
        hi = lo + 1.0
    n = len(valores)
    margem = 6

    def x_de(indice):
        if n <= 1:
            return largura / 2
        return margem + indice * (largura - 2 * margem) / (n - 1)

    y_de = _mapeador(lo, hi, altura - margem, margem)
    partes = [_abrir_svg(largura, altura, titulo, "an-svg-spark")]
    if lo < 0 < hi:
        partes.append(
            f'<line class="an-grade" x1="0" y1="{_c(y_de(0))}" x2="{int(largura)}" y2="{_c(y_de(0))}"/>'
        )
    trecho, trechos = [], []
    for indice, valor in enumerate(valores):
        if valor is None:
            if trecho:
                trechos.append(trecho)
            trecho = []
        else:
            trecho.append((x_de(indice), y_de(valor)))
    if trecho:
        trechos.append(trecho)
    for pedaco in trechos:
        if len(pedaco) >= 2:
            d = "M" + " L".join(f"{_c(x)},{_c(y)}" for x, y in pedaco)
            partes.append(f'<path class="an-linha an-spark-linha" d="{d}"/>')
    for indice, valor in enumerate(valores):
        if valor is None:
            continue
        ultimo = indice == n - 1
        classe = "an-ponto an-s1" if ultimo else "an-ponto an-spark-ponto"
        raio = 4 if ultimo else 2.5
        texto_valor = f"{formatar_numero(valor, 1)}%" if formato == "pct" else formatar_brl(valor)
        dica = f"{rotulos[indice] if indice < len(rotulos) else ''}: {texto_valor}"
        partes.append(
            f'<g class="an-ponto-grupo"><title>{escape(dica)}</title>'
            f'<circle class="an-alvo" cx="{_c(x_de(indice))}" cy="{_c(y_de(valor))}" r="9"/>'
            f'<circle class="{classe}" cx="{_c(x_de(indice))}" cy="{_c(y_de(valor))}" r="{raio}"/></g>'
        )
    partes.append("</svg>")
    return "".join(partes)
