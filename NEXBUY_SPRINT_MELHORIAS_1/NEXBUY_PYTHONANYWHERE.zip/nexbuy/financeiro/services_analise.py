"""Análise Financeira — DRE Gerencial, Créditos × Débitos e Saúde Financeira.

Módulo pedido pela cliente (dona de farmácia): "um DRE e também tipo um
balancete; olhar mensalmente quais foram os créditos e débitos, qual foi a
curva, o que foi maior e o que precisaria fazer para o empreendimento ficar
mais saudável". Acesso: Proprietário, Gerente e Financeiro
(`core.permissions.PERFIS_ANALISE_FINANCEIRA`); o Comprador nunca chega
aqui.

Regra de ouro: NENHUM número de receita ou custo é recalculado por fora.
Receita mensal, receitas extras, receita total, custos fixos e custos
variáveis vêm do Motor Financeiro (`finance_engine.services.
motor_financeiro.capacidade_do_mes`, o mesmo cálculo da Capacidade de
Compra e dos dashboards) — somados filial a filial quando o filtro é
"Todas as filiais". Os detalhamentos (receitas extras por categoria,
custos por descrição) usam exatamente os mesmos filtros do Motor e fecham
com o total dele (garantido pelos testes). Compras entram só quando
APROVADAS (`compras.services.STATUS_REALIZADO`), a mesma regra dos
relatórios de compras existentes.

Premissas que a tela explica ao usuário:
- DRE em regime de competência: receita do mês, compras aprovadas com data
  no mês, custos variáveis com data prevista no mês e os custos fixos
  ATIVOS (o Motor aplica os custos fixos ativos a todo mês — não existe
  histórico de custo fixo).
- Sem controle de estoque, as compras aprovadas do mês são a aproximação
  do custo da mercadoria: um mês de reposição pesada de estoque derruba a
  margem bruta daquele mês.
- Os meses anteriores ao primeiro lançamento da empresa não entram nas
  curvas nem nas médias (um sistema recém-implantado não mostra 11 meses
  de "prejuízo" que nunca aconteceram).
"""
import calendar
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal
from typing import Optional

from django.db.models import Count, Min, Sum
from django.urls import reverse
from django.utils import timezone

from compras.models import Compra, ParcelaCompra
from compras.services import STATUS_REALIZADO
from core.permissions import PERFIS_GESTORES_FINANCEIROS, usuario_tem_permissao
from finance_engine.services import motor_financeiro

from .graficos_svg import formatar_brl, formatar_numero
from .models import CustoFixo, CustoVariavel, Receita, ReceitaExtra

ZERO = Decimal("0")
CEM = Decimal("100")
UM_DECIMO = Decimal("0.1")

MESES = (
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
)
MESES_ABREV = ("jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez")

TAMANHO_JANELA = 12  # meses nas curvas e na média

# ---------------------------------------------------------------------------
# Referências de mercado (fonte ÚNICA — telas, testes e recomendações leem
# daqui). São REFERÊNCIAS APROXIMADAS para orientar a leitura, não metas
# regulatórias: a farmácia independente tem escala de compra menor que uma
# grande rede. O limite "saudável" de cada indicador vem da fonte citada;
# o limite "crítico" é uma margem conservadora definida pelo NEXBUY (sem
# fonte setorial — e a tela diz isso).
#
# Fontes consultadas em 25/09/2026:
# - RD Saúde (Raia Drogasil, maior rede de farmácias do país, associada à
#   Abrafarma) — Release de Resultados 4T24 / ano de 2024, publicado em
#   ri.rdsaude.com.br: margem bruta de 27,7% da receita bruta em 2024;
#   despesas com vendas 17,4% e gerais/administrativas 3,1% da receita
#   bruta; EBITDA ajustado 7,2%; lucro líquido ajustado 3,1%.
# - Sincofarma-SP (sindicato do varejo farmacêutico de SP) — e-book
#   "Gestão e Controle Financeiro em Farmácias" (2022): exemplo de DRE de
#   drogaria com lucro bruto de 40%, despesas variáveis de 12,79%,
#   despesas fixas de 20,34% e lucro de 6,87% das vendas; e a regra de que
#   uma farmácia cujas despesas somam 30% do faturamento "não pode pagar
#   mais do que 70% das suas vendas a fornecedores".
# ---------------------------------------------------------------------------

FONTES_REFERENCIA = {
    "rd": {
        "nome": "RD Saúde (Raia Drogasil) — Release de Resultados 4T24 e ano de 2024",
        "nome_curto": "RD Saúde, resultados de 2024",
        "resumo": (
            "maior rede de farmácias do país: margem bruta de 27,7% da receita bruta, despesas com vendas "
            "de 17,4% e gerais/administrativas de 3,1%, EBITDA ajustado de 7,2% e lucro líquido ajustado "
            "de 3,1% (ano de 2024)"
        ),
        "url": "https://ri.rdsaude.com.br/",
    },
    "sincofarma": {
        "nome": "Sincofarma-SP — e-book “Gestão e Controle Financeiro em Farmácias” (2022)",
        "nome_curto": "Sincofarma-SP (2022)",
        "resumo": (
            "exemplo de DRE de drogaria com lucro bruto de 40%, despesas variáveis de 12,79%, despesas fixas "
            "de 20,34% e lucro de 6,87% das vendas; e a regra de não pagar mais de 70% das vendas a "
            "fornecedores quando as despesas somam 30% do faturamento"
        ),
        "url": "https://sincofarmasp.com.br/wp-content/uploads/2022/05/e-book_gestao_acao.pdf",
    },
    "nexbuy": {
        "nome": "Faixa conservadora definida pelo NEXBUY",
        "nome_curto": "NEXBUY",
        "resumo": "sem fonte setorial específica — faixa genérica de varejo, derivada das demais referências",
        "url": "",
    },
}

# sentido "maior": quanto maior, melhor; "menor": quanto menor, melhor.
REFERENCIAS_MERCADO = {
    "margem_bruta": {
        "sentido": "maior", "saudavel": Decimal("27"), "critico": Decimal("20"),
        "texto": "cerca de 27% ou mais da receita",
        "fontes": ("rd", "sincofarma"),
    },
    "peso_compras": {
        "sentido": "menor", "saudavel": Decimal("73"), "critico": Decimal("80"),
        "texto": "até cerca de 70% a 73% da receita",
        "fontes": ("rd", "sincofarma"),
    },
    "peso_custos_fixos": {
        "sentido": "menor", "saudavel": Decimal("21"), "critico": Decimal("26"),
        "texto": "cerca de 20% da receita",
        "fontes": ("rd", "sincofarma"),
    },
    "margem_contribuicao": {
        "sentido": "maior", "saudavel": Decimal("25"), "critico": Decimal("20"),
        "texto": "25% ou mais — precisa cobrir os custos fixos (cerca de 20%) e ainda deixar resultado",
        "fontes": ("nexbuy",),
    },
    "margem_operacional": {
        "sentido": "maior", "saudavel": Decimal("5"), "critico": Decimal("0"),
        "texto": "5% ou mais da receita (grandes redes: EBITDA de cerca de 7%)",
        "fontes": ("rd", "sincofarma"),
    },
    "margem_seguranca": {
        "sentido": "maior", "saudavel": Decimal("15"), "critico": Decimal("5"),
        "texto": "15% ou mais acima do ponto de equilíbrio",
        "fontes": ("nexbuy",),
    },
    "comprometimento_30d": {
        "sentido": "menor", "saudavel": Decimal("75"), "critico": Decimal("90"),
        "texto": "até cerca de 75% da receita média mensal (o peso normal das compras)",
        "fontes": ("nexbuy",),
    },
}

# Variação mínima (em %) para uma tendência deixar de ser "estável".
LIMIAR_TENDENCIA = Decimal("3")

STATUS_SEMAFORO = {
    "bom": {"rotulo": "Saudável", "icone": "bi-check-circle-fill", "classe": "an-status-bom"},
    "atencao": {"rotulo": "Atenção", "icone": "bi-exclamation-triangle-fill", "classe": "an-status-atencao"},
    "critico": {"rotulo": "Crítico", "icone": "bi-x-octagon-fill", "classe": "an-status-critico"},
    "sem_dado": {"rotulo": "Sem dados", "icone": "bi-dash-circle", "classe": "an-status-sem-dado"},
}


# ---------------------------------------------------------------------------
# Utilitários de período e formatação
# ---------------------------------------------------------------------------

def somar_meses(ano: int, mes: int, delta: int) -> tuple:
    indice = ano * 12 + (mes - 1) + delta
    return indice // 12, indice % 12 + 1


def rotulo_mes_curto(ano: int, mes: int) -> str:
    """ "set/26" """
    return f"{MESES_ABREV[mes - 1]}/{ano % 100:02d}"


def rotulo_mes_longo(ano: int, mes: int) -> str:
    """ "setembro/2026" """
    return f"{MESES[mes - 1]}/{ano}"


def periodo_do_request(params, hoje: date) -> tuple:
    """(ano, mes) de `?ano=&mes=`; valor inválido cai no mês atual. Aceita
    o ano já formatado com separador de milhar ("2.026") — defesa extra
    além do `|stringformat:"d"` nos templates."""
    try:
        ano = int(str(params.get("ano", hoje.year)).replace(".", "").strip())
        mes = int(str(params.get("mes", hoje.month)).strip())
        if not (2000 <= ano <= 2100 and 1 <= mes <= 12):
            raise ValueError
    except (TypeError, ValueError):
        return hoje.year, hoje.month
    return ano, mes


def percentual(parte, total) -> Optional[Decimal]:
    """parte/total em % com 1 casa; None quando o total não é positivo
    (nunca divide por zero, nunca devolve NaN/Infinity)."""
    if total is None or parte is None or total <= ZERO:
        return None
    return (Decimal(parte) / Decimal(total) * CEM).quantize(UM_DECIMO, rounding=ROUND_HALF_UP)


def variacao_percentual(atual, anterior) -> Optional[Decimal]:
    if atual is None or anterior is None or anterior == ZERO:
        return None
    return ((Decimal(atual) - Decimal(anterior)) / abs(Decimal(anterior)) * CEM).quantize(
        UM_DECIMO, rounding=ROUND_HALF_UP
    )


def formatar_valor(valor) -> str:
    """ "R$ 1.234,56" ou "—" quando não há dado."""
    return "—" if valor is None else formatar_brl(valor)


def formatar_pct(valor, sinal: bool = False) -> str:
    """ "12,3%" (ou "+12,3%" com `sinal`) ou "—" quando não há dado."""
    if valor is None:
        return "—"
    texto = formatar_numero(valor, 1)
    if sinal and Decimal(valor) > ZERO:
        texto = f"+{texto}"
    return f"{texto}%"


def classificar(chave: str, valor) -> str:
    """Semáforo de um indicador contra `REFERENCIAS_MERCADO[chave]`."""
    if valor is None:
        return "sem_dado"
    referencia = REFERENCIAS_MERCADO[chave]
    if referencia["sentido"] == "maior":
        if valor >= referencia["saudavel"]:
            return "bom"
        return "atencao" if valor >= referencia["critico"] else "critico"
    if valor <= referencia["saudavel"]:
        return "bom"
    return "atencao" if valor <= referencia["critico"] else "critico"


def fontes_da_referencia(chave: str) -> list:
    return [FONTES_REFERENCIA[codigo] for codigo in REFERENCIAS_MERCADO[chave]["fontes"]]


# ---------------------------------------------------------------------------
# Números por mês
# ---------------------------------------------------------------------------

@dataclass
class DreMes:
    """DRE gerencial (competência) de um mês para um conjunto de filiais."""

    ano: int
    mes: int
    receita_mensal: Decimal = ZERO
    receitas_extras: Decimal = ZERO
    receita_total: Decimal = ZERO
    extras_por_categoria: dict = field(default_factory=dict)  # {codigo: Decimal}
    compras: Decimal = ZERO
    compras_quantidade: int = 0
    compras_por_categoria: list = field(default_factory=list)  # [(nome, Decimal)]
    custos_variaveis: Decimal = ZERO
    custos_variaveis_detalhe: list = field(default_factory=list)  # [(descricao, Decimal)]
    custos_fixos: Decimal = ZERO
    custos_fixos_detalhe: list = field(default_factory=list)  # [(descricao, Decimal)]
    receita_configurada: bool = False
    disponibilidade_motor: Decimal = ZERO  # soma de ResultadoCapacidade.disponibilidade
    # Rodada final: mês anterior ao primeiro lançamento da empresa no
    # NEXBUY — nada foi lançado, então nem os custos fixos se aplicam
    # (antes a tela mostrava um "prejuízo" de custos fixos num mês em que o
    # sistema nem estava em uso).
    antes_da_implantacao: bool = False
    # Ajuste final (produto-e-demo): o mês de HOJE ainda não fechou — a
    # receita lançada é a do mês inteiro, mas as compras e os custos
    # variáveis só chegaram até hoje. Lucro e margem desse mês são
    # parciais (nas primeiras semanas, bem maiores do que o mês vai fechar).
    em_andamento: bool = False
    parcial_ate: Optional[date] = None

    @property
    def rotulo(self) -> str:
        return rotulo_mes_curto(self.ano, self.mes)

    @property
    def margem_bruta(self) -> Decimal:
        return self.receita_total - self.compras

    @property
    def margem_contribuicao(self) -> Decimal:
        return self.margem_bruta - self.custos_variaveis

    @property
    def resultado(self) -> Decimal:
        return self.margem_contribuicao - self.custos_fixos

    @property
    def despesas_totais(self) -> Decimal:
        return self.compras + self.custos_variaveis + self.custos_fixos

    def pct(self, valor) -> Optional[Decimal]:
        return percentual(valor, self.receita_total)


@dataclass
class CaixaMes:
    """Créditos × Débitos (visão de caixa por vencimento) de um mês."""

    ano: int
    mes: int
    receita_mensal: Decimal = ZERO
    receitas_extras: Decimal = ZERO
    extras_por_categoria: dict = field(default_factory=dict)
    parcelas_pagas: Decimal = ZERO
    parcelas_a_pagar: Decimal = ZERO
    parcelas_por_categoria: list = field(default_factory=list)  # [(nome, Decimal)]
    custos_fixos: Decimal = ZERO
    custos_fixos_detalhe: list = field(default_factory=list)
    custos_variaveis: Decimal = ZERO
    custos_variaveis_detalhe: list = field(default_factory=list)
    receita_configurada: bool = False

    @property
    def rotulo(self) -> str:
        return rotulo_mes_curto(self.ano, self.mes)

    @property
    def creditos(self) -> Decimal:
        return self.receita_mensal + self.receitas_extras

    @property
    def parcelas(self) -> Decimal:
        return self.parcelas_pagas + self.parcelas_a_pagar

    @property
    def debitos(self) -> Decimal:
        return self.parcelas + self.custos_fixos + self.custos_variaveis

    @property
    def saldo(self) -> Decimal:
        return self.creditos - self.debitos


_NAO_CALCULADO = object()


class AnaliseFinanceira:
    """Coletor dos números de um conjunto de filiais (sempre as filiais do
    CONTEXTO do usuário, já filtradas pela view). Memoriza por mês para que
    as curvas de 12 meses não repitam consultas."""

    def __init__(self, filiais, hoje: Optional[date] = None):
        self.filiais = list(filiais)
        self.hoje = hoje or timezone.localdate()
        self._dres = {}
        self._caixas = {}
        self._custos_fixos_detalhe = None
        self._primeiro_mes = _NAO_CALCULADO

    # -- Motor -------------------------------------------------------------

    def _capacidades(self, ano, mes):
        return [motor_financeiro.capacidade_do_mes(filial, ano, mes) for filial in self.filiais]

    def _detalhe_custos_fixos(self):
        if self._custos_fixos_detalhe is None:
            self._custos_fixos_detalhe = [
                (linha["descricao"], linha["total"] or ZERO)
                for linha in CustoFixo.objects.filter(filial__in=self.filiais, ativo=True)
                .values("descricao").annotate(total=Sum("valor")).order_by("-total", "descricao")
            ]
        return self._custos_fixos_detalhe

    def dre(self, ano: int, mes: int) -> DreMes:
        chave = (ano, mes)
        if chave in self._dres:
            return self._dres[chave]
        resultado = DreMes(ano=ano, mes=mes, extras_por_categoria={c: ZERO for c in ReceitaExtra.Categoria.values})
        if (ano, mes) == (self.hoje.year, self.hoje.month):
            resultado.em_andamento = True
            resultado.parcial_ate = self.hoje
        if self.filiais:
            capacidades = self._capacidades(ano, mes)
            resultado.receita_mensal = sum((c.receita_mensal for c in capacidades), ZERO)
            resultado.receitas_extras = sum((c.receitas_extras for c in capacidades), ZERO)
            resultado.receita_total = sum((c.faturamento for c in capacidades), ZERO)
            resultado.custos_fixos = sum((c.custos_fixos for c in capacidades), ZERO)
            resultado.custos_variaveis = sum((c.custos_variaveis for c in capacidades), ZERO)
            resultado.disponibilidade_motor = sum((c.disponibilidade for c in capacidades), ZERO)
            resultado.receita_configurada = any(c.receita_configurada for c in capacidades)

            for linha in (
                ReceitaExtra.objects.filter(filial__in=self.filiais, data__year=ano, data__month=mes)
                .values("categoria").annotate(total=Sum("valor"))
            ):
                resultado.extras_por_categoria[linha["categoria"]] = linha["total"] or ZERO

            compras = Compra.objects.filter(
                filial__in=self.filiais, data_compra__year=ano, data_compra__month=mes, status__in=STATUS_REALIZADO
            )
            agregado = compras.aggregate(total=Sum("valor"), quantidade=Count("id"))
            resultado.compras = agregado["total"] or ZERO
            resultado.compras_quantidade = agregado["quantidade"] or 0
            resultado.compras_por_categoria = [
                (linha["categoria__nome"] or "Sem categoria", linha["total"] or ZERO)
                for linha in compras.values("categoria__nome").annotate(total=Sum("valor")).order_by("-total")
            ]
            resultado.custos_variaveis_detalhe = [
                (linha["descricao"], linha["total"] or ZERO)
                for linha in CustoVariavel.objects.filter(
                    filial__in=self.filiais, data_prevista__year=ano, data_prevista__month=mes
                ).values("descricao").annotate(total=Sum("valor")).order_by("-total", "descricao")
            ]
            resultado.custos_fixos_detalhe = list(self._detalhe_custos_fixos())
            if not self.mes_tem_dados(ano, mes):
                resultado.antes_da_implantacao = True
                resultado.custos_fixos = ZERO
                resultado.custos_fixos_detalhe = []
        self._dres[chave] = resultado
        return resultado

    def caixa(self, ano: int, mes: int) -> CaixaMes:
        chave = (ano, mes)
        if chave in self._caixas:
            return self._caixas[chave]
        dre = self.dre(ano, mes)
        resultado = CaixaMes(
            ano=ano, mes=mes,
            receita_mensal=dre.receita_mensal, receitas_extras=dre.receitas_extras,
            extras_por_categoria=dict(dre.extras_por_categoria),
            custos_fixos=dre.custos_fixos, custos_fixos_detalhe=list(dre.custos_fixos_detalhe),
            custos_variaveis=dre.custos_variaveis, custos_variaveis_detalhe=list(dre.custos_variaveis_detalhe),
            receita_configurada=dre.receita_configurada,
        )
        if self.filiais:
            parcelas = self._parcelas().filter(data_vencimento__year=ano, data_vencimento__month=mes)
            for linha in parcelas.values("status").annotate(total=Sum("valor")):
                if linha["status"] == ParcelaCompra.Status.PAGA:
                    resultado.parcelas_pagas += linha["total"] or ZERO
                else:
                    resultado.parcelas_a_pagar += linha["total"] or ZERO
            resultado.parcelas_por_categoria = [
                (linha["compra__categoria__nome"] or "Sem categoria", linha["total"] or ZERO)
                for linha in parcelas.values("compra__categoria__nome").annotate(total=Sum("valor")).order_by("-total")
            ]
        self._caixas[chave] = resultado
        return resultado

    def _parcelas(self):
        """Parcelas de compras APROVADAS das filiais (canceladas nunca contam)."""
        return ParcelaCompra.objects.filter(
            compra__filial__in=self.filiais, compra__status__in=STATUS_REALIZADO
        ).exclude(status=ParcelaCompra.Status.CANCELADA)

    # -- Janela ------------------------------------------------------------

    def primeiro_mes_com_dados(self) -> Optional[tuple]:
        """(ano, mes) do primeiro lançamento da empresa nas filiais — receita,
        receita extra, compra aprovada, custo variável ou cadastro de custo
        fixo. None quando não há lançamento nenhum (sistema recém-implantado)."""
        if self._primeiro_mes is not _NAO_CALCULADO:
            return self._primeiro_mes
        datas = []
        if self.filiais:
            datas.append(Receita.objects.filter(filial__in=self.filiais).aggregate(m=Min("mes"))["m"])
            datas.append(ReceitaExtra.objects.filter(filial__in=self.filiais).aggregate(m=Min("data"))["m"])
            datas.append(
                Compra.objects.filter(filial__in=self.filiais, status__in=STATUS_REALIZADO)
                .aggregate(m=Min("data_compra"))["m"]
            )
            datas.append(CustoVariavel.objects.filter(filial__in=self.filiais).aggregate(m=Min("data_prevista"))["m"])
            criado = CustoFixo.objects.filter(filial__in=self.filiais, ativo=True).aggregate(m=Min("criado_em"))["m"]
            if criado is not None:
                datas.append(timezone.localtime(criado).date() if timezone.is_aware(criado) else criado.date())
        datas = [d for d in datas if d is not None]
        self._primeiro_mes = (min(datas).year, min(datas).month) if datas else None
        return self._primeiro_mes

    def tem_dados(self) -> bool:
        return self.primeiro_mes_com_dados() is not None

    def mes_tem_dados(self, ano: int, mes: int) -> bool:
        primeiro = self.primeiro_mes_com_dados()
        return primeiro is not None and (ano, mes) >= primeiro

    def janela(self, ano: int, mes: int, tamanho: int = TAMANHO_JANELA) -> list:
        """Até `tamanho` meses terminando no mês selecionado, a partir do
        primeiro mês com lançamentos. Nunca vazia: no mínimo o próprio mês."""
        meses = [somar_meses(ano, mes, -i) for i in range(tamanho - 1, -1, -1)]
        primeiro = self.primeiro_mes_com_dados()
        if primeiro is None:
            return [(ano, mes)]
        return [m for m in meses if m >= primeiro] or [(ano, mes)]

    def receita_media(self, ano: int, mes: int) -> tuple:
        """(média da receita total, quantidade de meses) nos meses da janela
        com receita lançada; (None, 0) se nenhum."""
        dres = [self.dre(*m) for m in self.janela(ano, mes)]
        com_receita = [d for d in dres if d.receita_configurada]
        if not com_receita:
            return None, 0
        total = sum((d.receita_total for d in com_receita), ZERO)
        return (total / len(com_receita)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), len(com_receita)

    def parcelas_a_vencer(self, dias: int) -> Decimal:
        """Parcelas PENDENTES com vencimento de hoje até hoje + `dias`."""
        if not self.filiais:
            return ZERO
        return self._parcelas().filter(
            status=ParcelaCompra.Status.PENDENTE,
            data_vencimento__gte=self.hoje,
            data_vencimento__lte=self.hoje + timedelta(days=dias),
        ).aggregate(total=Sum("valor"))["total"] or ZERO

    def parcelas_vencidas(self) -> Decimal:
        if not self.filiais:
            return ZERO
        return self._parcelas().filter(
            status=ParcelaCompra.Status.PENDENTE, data_vencimento__lt=self.hoje
        ).aggregate(total=Sum("valor"))["total"] or ZERO


# ---------------------------------------------------------------------------
# Links de ação — mesmo gate das telas de destino (nunca um link que dê 403)
# ---------------------------------------------------------------------------

def links_de_acao(usuario) -> dict:
    perfil_financeiro = getattr(usuario, "perfil", None) in PERFIS_GESTORES_FINANCEIROS
    links = {}
    if perfil_financeiro:  # PERFIS_VISUALIZACAO / PERFIS_CADASTRO das telas
        links["receitas"] = {"rotulo": "Receitas", "url": reverse("financeiro:receita_list"), "icone": "bi-cash-coin"}
        links["receita_nova"] = {
            "rotulo": "Cadastrar receita", "url": reverse("financeiro:receita_create"), "icone": "bi-plus-circle",
        }
        links["custos_fixos"] = {
            "rotulo": "Custos Fixos", "url": reverse("financeiro:custofixo_list"), "icone": "bi-receipt",
        }
        links["custos_variaveis"] = {
            "rotulo": "Custos Variáveis", "url": reverse("financeiro:custovariavel_list"), "icone": "bi-arrow-left-right",
        }
        links["configuracao"] = {
            "rotulo": "Capacidade Financeira", "url": reverse("financeiro:configuracao"), "icone": "bi-sliders",
        }
    if getattr(usuario, "perfil", None) in PERFIS_GESTORES_FINANCEIROS or usuario_tem_permissao(
        usuario, "compras.lancar"
    ):
        links["compras"] = {"rotulo": "Compras", "url": reverse("compras:lista"), "icone": "bi-cart-check"}
    if usuario_tem_permissao(usuario, "capacidade.gerenciar"):
        links["capacidade"] = {
            "rotulo": "Compradores e Limites", "url": reverse("financeiro:capacidade_compradores"),
            "icone": "bi-people-fill",
        }
    if usuario_tem_permissao(usuario, "agenda.ver"):
        links["agenda"] = {"rotulo": "Agenda Financeira", "url": reverse("financeiro:agenda"), "icone": "bi-calendar2-week"}
    return links


# ---------------------------------------------------------------------------
# Tela 1 — DRE Gerencial
# ---------------------------------------------------------------------------

_SENTIDO_BOM = {  # True: aumento é bom; False: aumento é ruim
    "receita": True, "despesa": False, "resultado": True,
}


def _linha_dre(chave, rotulo, tipo, natureza, extrator, atual, anterior, serie, nivel=0,
               depende_da_receita=False):
    """Uma linha da DRE. `depende_da_receita`: receitas, margens e resultado
    — num mês sem receita lançada o valor é "—" (não um "prejuízo" que é só
    ausência de dado) e não há variação contra ele (rodada final)."""
    sem_atual = depende_da_receita and not atual.receita_configurada
    sem_anterior = depende_da_receita and anterior is not None and not anterior.receita_configurada
    valor_atual = None if sem_atual else extrator(atual)
    valor_anterior = None if (anterior is None or sem_anterior) else extrator(anterior)
    variacao = (valor_atual - valor_anterior) if (valor_anterior is not None and valor_atual is not None) else None
    com_receita = [d for d in serie if d.receita_configurada]
    media = (
        (sum((extrator(d) for d in com_receita), ZERO) / len(com_receita)).quantize(Decimal("0.01"), ROUND_HALF_UP)
        if com_receita else None
    )
    classe_variacao = "an-var-neutra"
    if variacao is not None and variacao != ZERO:
        aumento_bom = _SENTIDO_BOM[natureza]
        melhorou = (variacao > ZERO) == aumento_bom
        classe_variacao = "an-var-boa" if melhorou else "an-var-ruim"
    return {
        "chave": chave,
        "rotulo": rotulo,
        "tipo": tipo,  # "valor" | "detalhe" | "subtotal" | "resultado"
        "nivel": nivel,
        "atual": valor_atual,
        "anterior": valor_anterior,
        "variacao": variacao,
        "variacao_pct": variacao_percentual(valor_atual, valor_anterior),
        "media": media,
        "pct_receita": None if valor_atual is None else atual.pct(valor_atual),
        "atual_fmt": formatar_valor(valor_atual),
        "anterior_fmt": formatar_valor(valor_anterior),
        "variacao_fmt": ("—" if variacao is None else (("+" if variacao > ZERO else "") + formatar_brl(variacao))),
        "variacao_pct_fmt": (
            "novo" if valor_anterior is not None and valor_anterior == ZERO and valor_atual not in (None, ZERO)
            else formatar_pct(variacao_percentual(valor_atual, valor_anterior), sinal=True)
        ),
        "media_fmt": formatar_valor(media),
        "pct_receita_fmt": formatar_pct(None if valor_atual is None else atual.pct(valor_atual)),
        "classe_variacao": classe_variacao,
        "icone_variacao": (
            "" if variacao is None or variacao == ZERO
            else ("bi-arrow-up-right" if variacao > ZERO else "bi-arrow-down-right")
        ),
    }


def linhas_da_dre(atual: DreMes, anterior: Optional[DreMes], serie: list) -> list:
    """Linhas do demonstrativo, na ordem da DRE gerencial."""
    linhas = [
        _linha_dre("receita_mensal", "(+) Receita mensal (faturamento)", "valor", "receita",
                   lambda d: d.receita_mensal, atual, anterior, serie, depende_da_receita=True),
        _linha_dre("receitas_extras", "(+) Receitas extras", "valor", "receita",
                   lambda d: d.receitas_extras, atual, anterior, serie, depende_da_receita=True),
    ]
    for codigo, rotulo in ReceitaExtra.Categoria.choices:
        tem_valor = atual.extras_por_categoria.get(codigo, ZERO) or (
            anterior is not None and anterior.extras_por_categoria.get(codigo, ZERO)
        )
        if tem_valor:
            linhas.append(_linha_dre(
                f"extra_{codigo}", rotulo, "detalhe", "receita",
                lambda d, c=codigo: d.extras_por_categoria.get(c, ZERO), atual, anterior, serie, nivel=1,
            ))
    linhas += [
        _linha_dre("receita_total", "(=) Receita total", "subtotal", "receita",
                   lambda d: d.receita_total, atual, anterior, serie, depende_da_receita=True),
        _linha_dre("compras", "(−) Compras de mercadorias (aprovadas)", "valor", "despesa",
                   lambda d: d.compras, atual, anterior, serie),
        _linha_dre("margem_bruta", "(=) Margem bruta", "subtotal", "resultado",
                   lambda d: d.margem_bruta, atual, anterior, serie, depende_da_receita=True),
        _linha_dre("custos_variaveis", "(−) Custos variáveis", "valor", "despesa",
                   lambda d: d.custos_variaveis, atual, anterior, serie),
        _linha_dre("margem_contribuicao", "(=) Margem de contribuição", "subtotal", "resultado",
                   lambda d: d.margem_contribuicao, atual, anterior, serie, depende_da_receita=True),
        _linha_dre("custos_fixos", "(−) Custos fixos", "valor", "despesa",
                   lambda d: d.custos_fixos, atual, anterior, serie),
    ]
    for descricao, _valor in atual.custos_fixos_detalhe:
        linhas.append(_linha_dre(
            "fixo", descricao, "detalhe", "despesa",
            lambda d, desc=descricao: dict(d.custos_fixos_detalhe).get(desc, ZERO), atual, anterior, serie, nivel=1,
        ))
    linhas.append(_linha_dre("resultado", rotulo_do_resultado(atual), "resultado", "resultado",
                             lambda d: d.resultado, atual, anterior, serie, depende_da_receita=True))
    return linhas


def rotulo_do_resultado(dre: DreMes) -> str:
    """Rodada final: o rótulo da última linha segue o MESMO estado do KPI —
    sem receita, só "(=) Resultado operacional" (o valor é "—"); com a
    análise incompleta (faltam custos fixos ou compras), "provisório";
    completo, lucro ou prejuízo."""
    base = "(=) Resultado operacional"
    if not dre.receita_configurada:
        return base
    if lacunas_do_mes(dre)["provisorio"]:
        return base + " — provisório"
    return base + " — " + ("lucro" if dre.resultado >= ZERO else "prejuízo")


def etapas_cascata(dre: DreMes) -> list:
    return [
        {"rotulo": "Receita total", "rotulo_curto": "Receita", "tipo": "total", "valor": dre.receita_total},
        {"rotulo": "Compras de mercadorias", "rotulo_curto": "Compras", "tipo": "reducao", "valor": dre.compras},
        {"rotulo": "Margem bruta", "rotulo_curto": "Margem bruta", "tipo": "subtotal", "valor": dre.margem_bruta},
        {"rotulo": "Custos variáveis", "rotulo_curto": "Custos variáv.", "tipo": "reducao", "valor": dre.custos_variaveis},
        {"rotulo": "Margem de contribuição", "rotulo_curto": "Margem contrib.", "tipo": "subtotal",
         "valor": dre.margem_contribuicao},
        {"rotulo": "Custos fixos", "rotulo_curto": "Custos fixos", "tipo": "reducao", "valor": dre.custos_fixos},
        {"rotulo": "Resultado operacional", "rotulo_curto": "Resultado", "tipo": "subtotal", "valor": dre.resultado},
    ]


def lacunas_do_mes(dre: DreMes) -> dict:
    """Crítico de UX (rodada 1): com receita lançada mas sem custos e sem
    compras, a DRE mostrava "lucro 100%" e a Saúde declarava tudo saudável —
    falta de dado virando falsa tranquilidade. Diz o que falta no mês (só
    faz sentido com receita lançada): custos fixos, custos variáveis e
    compras aprovadas. Uma farmácia de verdade sempre tem custo fixo e
    compra de mercadoria no mês; zero quase sempre é lançamento pendente."""
    sem_custos_fixos = dre.custos_fixos <= ZERO
    sem_custos_variaveis = dre.custos_variaveis <= ZERO
    sem_compras = dre.compras <= ZERO
    faltando = []
    if sem_custos_fixos:
        faltando.append("os custos fixos")
    if sem_compras:
        faltando.append("as compras aprovadas")
    incompleto = bool(dre.receita_configurada and faltando)
    # Ajuste final (produto-e-demo): "incompleto" só pegava a falta TOTAL de
    # compras — com a receita do mês inteiro já lançada e as compras só até
    # hoje, o mês corrente mostrava lucro de 25% a 50% como resultado firme
    # (os meses fechados ficam em alguns %). O mês em andamento é sempre
    # provisório, mesmo sem nada faltando.
    em_andamento = bool(dre.receita_configurada and dre.em_andamento)
    return {
        "sem_custos_fixos": sem_custos_fixos,
        "sem_custos": sem_custos_fixos and sem_custos_variaveis,
        "sem_compras": sem_compras,
        "incompleto": incompleto,
        "faltando_texto": " e ".join(faltando),
        "em_andamento": em_andamento,
        "parcial_ate_fmt": f"{dre.parcial_ate:%d/%m}" if em_andamento and dre.parcial_ate else "",
        "provisorio": incompleto or em_andamento,
    }


def montar_dre(analise: AnaliseFinanceira, ano: int, mes: int) -> dict:
    atual = analise.dre(ano, mes)
    ano_ant, mes_ant = somar_meses(ano, mes, -1)
    anterior = analise.dre(ano_ant, mes_ant) if analise.mes_tem_dados(ano_ant, mes_ant) else None
    meses = analise.janela(ano, mes)
    serie = [analise.dre(*m) for m in meses]
    meses_com_receita = sum(1 for d in serie if d.receita_configurada)

    tabela_curva = [
        {
            "rotulo": d.rotulo,
            "rotulo_longo": rotulo_mes_longo(d.ano, d.mes),
            "receita_configurada": d.receita_configurada,
            "receita_fmt": formatar_valor(d.receita_total) if d.receita_configurada else "—",
            "despesas_fmt": formatar_valor(d.despesas_totais),
            "resultado_fmt": formatar_valor(d.resultado) if d.receita_configurada else "—",
            "margem_fmt": formatar_pct(d.pct(d.resultado)) if d.receita_configurada else "—",
            "prejuizo": d.receita_configurada and d.resultado < ZERO,
            "selecionado": (d.ano, d.mes) == (ano, mes),
            "parcial": d.receita_configurada and d.em_andamento,
        }
        for d in serie
    ]
    return {
        "atual": atual,
        "anterior": anterior,
        "rotulo_anterior": rotulo_mes_curto(ano_ant, mes_ant),
        "linhas": linhas_da_dre(atual, anterior, serie),
        "serie": serie,
        "meses_com_receita": meses_com_receita,
        "primeiro_mes_janela": rotulo_mes_curto(*meses[0]),
        "tabela_curva": tabela_curva,
        "cascata": etapas_cascata(atual),
        "lacunas": lacunas_do_mes(atual),
        "kpis": {
            "receita_fmt": formatar_brl(atual.receita_total) if atual.receita_configurada else "—",
            "despesas_fmt": formatar_brl(atual.despesas_totais),
            "resultado_fmt": formatar_brl(atual.resultado),
            "margem_fmt": formatar_pct(atual.pct(atual.resultado)),
            "lucro": atual.resultado >= ZERO,
        },
    }


def linhas_csv_dre(dados: dict) -> tuple:
    def numero(valor):
        return "" if valor is None else f"{Decimal(valor):.2f}".replace(".", ",")

    def pct(valor):
        return "" if valor is None else f"{Decimal(valor):.1f}".replace(".", ",")

    cabecalho = [
        "Linha", f"{dados['atual'].rotulo} (R$)", "% da receita", f"{dados['rotulo_anterior']} (R$)",
        "Variação (R$)", "Variação (%)", "Média dos meses com receita (R$)",
    ]
    linhas = [
        [
            ("    " if linha["nivel"] else "") + linha["rotulo"], numero(linha["atual"]), pct(linha["pct_receita"]),
            numero(linha["anterior"]), numero(linha["variacao"]), pct(linha["variacao_pct"]), numero(linha["media"]),
        ]
        for linha in dados["linhas"]
    ]
    return cabecalho, linhas


# ---------------------------------------------------------------------------
# Tela 2 — Créditos × Débitos
# ---------------------------------------------------------------------------

def _balancete(caixa: CaixaMes) -> dict:
    rotulos_categoria = dict(ReceitaExtra.Categoria.choices)
    grupos = [
        {
            "titulo": "Receitas",
            "contas": (
                [{"conta": "Receita de vendas (receita mensal)", "credito": caixa.receita_mensal, "debito": None}]
                if caixa.receita_mensal or caixa.receita_configurada else []
            ) + [
                {"conta": f"Receitas extras — {rotulos_categoria.get(codigo, codigo)}", "credito": valor, "debito": None}
                for codigo, valor in caixa.extras_por_categoria.items() if valor
            ],
        },
        {
            "titulo": "Fornecedores (parcelas de compras com vencimento no mês)",
            "contas": [
                {"conta": f"Fornecedores — {nome}", "credito": None, "debito": valor}
                for nome, valor in caixa.parcelas_por_categoria if valor
            ],
        },
        {
            "titulo": "Custos fixos",
            "contas": [{"conta": descricao, "credito": None, "debito": valor} for descricao, valor in caixa.custos_fixos_detalhe],
        },
        {
            "titulo": "Custos variáveis",
            "contas": [
                {"conta": descricao, "credito": None, "debito": valor} for descricao, valor in caixa.custos_variaveis_detalhe
            ],
        },
    ]
    todas = [conta for grupo in grupos for conta in grupo["contas"]]
    creditos = [c for c in todas if c["credito"]]
    debitos = [c for c in todas if c["debito"]]
    maior_credito = max(creditos, key=lambda c: c["credito"]) if creditos else None
    maior_debito = max(debitos, key=lambda c: c["debito"]) if debitos else None
    total_creditos = sum((c["credito"] or ZERO for c in todas), ZERO)
    total_debitos = sum((c["debito"] or ZERO for c in todas), ZERO)
    for conta in todas:
        conta["credito_fmt"] = formatar_brl(conta["credito"]) if conta["credito"] is not None else ""
        conta["debito_fmt"] = formatar_brl(conta["debito"]) if conta["debito"] is not None else ""
        conta["maior_credito"] = conta is maior_credito
        conta["maior_debito"] = conta is maior_debito
    return {
        "grupos": grupos,
        "total_creditos": total_creditos,
        "total_debitos": total_debitos,
        "total_creditos_fmt": formatar_brl(total_creditos),
        "total_debitos_fmt": formatar_brl(total_debitos),
        "saldo": total_creditos - total_debitos,
        "saldo_fmt": formatar_brl(total_creditos - total_debitos),
        "maior_credito": maior_credito,
        "maior_debito": maior_debito,
        "maior_credito_pct_fmt": formatar_pct(percentual(maior_credito["credito"], total_creditos)) if maior_credito else "—",
        "maior_debito_pct_fmt": formatar_pct(percentual(maior_debito["debito"], total_debitos)) if maior_debito else "—",
        "vazio": not todas,
    }


def montar_creditos_debitos(analise: AnaliseFinanceira, ano: int, mes: int) -> dict:
    """Rodada final: num mês sem receita lançada, o saldo NÃO é calculado
    ("—" e "aguardando a receita do mês", como o KPI da DRE) — antes a tela
    dizia "saíram mais do que entraram" com um saldo que era só a ausência
    da receita. Esses meses também não entram no saldo acumulado nem no
    total do saldo (a coluna de saldo soma só meses com receita)."""
    meses = analise.janela(ano, mes)
    serie = [analise.caixa(*m) for m in meses]
    acumulado = ZERO
    tabela = []
    for caixa in serie:
        if caixa.receita_configurada:
            acumulado += caixa.saldo
        tabela.append({
            "caixa": caixa,
            "rotulo": caixa.rotulo,
            "rotulo_longo": rotulo_mes_longo(caixa.ano, caixa.mes),
            "selecionado": (caixa.ano, caixa.mes) == (ano, mes),
            "receita_configurada": caixa.receita_configurada,
            "saldo_acumulado": acumulado,
            "receita_mensal_fmt": formatar_brl(caixa.receita_mensal),
            "receitas_extras_fmt": formatar_brl(caixa.receitas_extras),
            "creditos_fmt": formatar_brl(caixa.creditos),
            "parcelas_pagas_fmt": formatar_brl(caixa.parcelas_pagas),
            "parcelas_a_pagar_fmt": formatar_brl(caixa.parcelas_a_pagar),
            "custos_fixos_fmt": formatar_brl(caixa.custos_fixos),
            "custos_variaveis_fmt": formatar_brl(caixa.custos_variaveis),
            "debitos_fmt": formatar_brl(caixa.debitos),
            "saldo": caixa.saldo if caixa.receita_configurada else None,
            "saldo_fmt": formatar_brl(caixa.saldo) if caixa.receita_configurada else "—",
            "saldo_acumulado_fmt": formatar_brl(acumulado) if caixa.receita_configurada else "—",
            "saldo_negativo": caixa.receita_configurada and caixa.saldo < ZERO,
            "acumulado_negativo": caixa.receita_configurada and acumulado < ZERO,
        })
    atual = analise.caixa(ano, mes)
    linha_atual = next((linha for linha in tabela if linha["selecionado"]), tabela[-1])
    totais = {
        "creditos_fmt": formatar_brl(sum((c.creditos for c in serie), ZERO)),
        "debitos_fmt": formatar_brl(sum((c.debitos for c in serie), ZERO)),
        "saldo_fmt": formatar_brl(sum((c.saldo for c in serie if c.receita_configurada), ZERO)),
        "saldo_parcial": any(not c.receita_configurada for c in serie),
        "receita_mensal_fmt": formatar_brl(sum((c.receita_mensal for c in serie), ZERO)),
        "receitas_extras_fmt": formatar_brl(sum((c.receitas_extras for c in serie), ZERO)),
        "parcelas_pagas_fmt": formatar_brl(sum((c.parcelas_pagas for c in serie), ZERO)),
        "parcelas_a_pagar_fmt": formatar_brl(sum((c.parcelas_a_pagar for c in serie), ZERO)),
        "custos_fixos_fmt": formatar_brl(sum((c.custos_fixos for c in serie), ZERO)),
        "custos_variaveis_fmt": formatar_brl(sum((c.custos_variaveis for c in serie), ZERO)),
    }
    maior_mes_credito = max(serie, key=lambda c: c.creditos)
    maior_mes_debito = max(serie, key=lambda c: c.debitos)
    return {
        "atual": atual,
        "serie": serie,
        "tabela": tabela,
        "totais": totais,
        "balancete": _balancete(atual),
        "kpis": {
            "creditos_fmt": formatar_brl(atual.creditos),
            "debitos_fmt": formatar_brl(atual.debitos),
            "saldo_fmt": formatar_brl(atual.saldo) if atual.receita_configurada else "—",
            "saldo_negativo": atual.receita_configurada and atual.saldo < ZERO,
            "acumulado_fmt": linha_atual["saldo_acumulado_fmt"],
            "acumulado_negativo": linha_atual["acumulado_negativo"],
            "parcelas_pagas_fmt": formatar_brl(atual.parcelas_pagas),
            "parcelas_a_pagar_fmt": formatar_brl(atual.parcelas_a_pagar),
        },
        "maior_mes_credito": maior_mes_credito.rotulo if maior_mes_credito.creditos > ZERO else "",
        "maior_mes_debito": maior_mes_debito.rotulo if maior_mes_debito.debitos > ZERO else "",
        "primeiro_mes_janela": serie[0].rotulo,
    }


def linhas_csv_creditos_debitos(dados: dict) -> tuple:
    def numero(valor):
        return "" if valor is None else f"{Decimal(valor):.2f}".replace(".", ",")

    cabecalho = [
        "Mês", "Receita mensal (R$)", "Receitas extras (R$)", "Créditos (R$)", "Parcelas pagas (R$)",
        "Parcelas a pagar (R$)", "Custos fixos (R$)", "Custos variáveis (R$)", "Débitos (R$)",
        "Saldo do mês (R$)", "Saldo acumulado (R$)",
    ]
    linhas = []
    for linha in dados["tabela"]:
        caixa = linha["caixa"]
        linhas.append([
            linha["rotulo"], numero(caixa.receita_mensal), numero(caixa.receitas_extras), numero(caixa.creditos),
            numero(caixa.parcelas_pagas), numero(caixa.parcelas_a_pagar), numero(caixa.custos_fixos),
            numero(caixa.custos_variaveis), numero(caixa.debitos), numero(linha["saldo"]),
            numero(linha["saldo_acumulado"] if linha["receita_configurada"] else None),
        ])
    balancete = dados["balancete"]
    linhas.append([])
    linhas.append([f"Balancete de {dados['atual'].rotulo}"])
    linhas.append(["Conta", "Débito (R$)", "Crédito (R$)"])
    for grupo in balancete["grupos"]:
        for conta in grupo["contas"]:
            linhas.append([conta["conta"], numero(conta["debito"]), numero(conta["credito"])])
    linhas.append(["Totais", numero(balancete["total_debitos"]), numero(balancete["total_creditos"])])
    linhas.append([
        "Saldo do mês (créditos − débitos)", "",
        numero(balancete["saldo"]) if dados["atual"].receita_configurada else "aguardando a receita do mês",
    ])
    return cabecalho, linhas


# ---------------------------------------------------------------------------
# Tela 3 — Saúde Financeira
# ---------------------------------------------------------------------------

def _indicador(chave, nome, valor, explicacao, valor_fmt=None, status=None):
    status = status or classificar(chave, valor)
    referencia = REFERENCIAS_MERCADO[chave]
    return {
        "chave": chave,
        "nome": nome,
        "valor": valor,
        "valor_fmt": valor_fmt if valor_fmt is not None else formatar_pct(valor),
        "status": status,
        "status_info": STATUS_SEMAFORO[status],
        "explicacao": explicacao,
        "referencia_texto": referencia["texto"],
        "fontes": fontes_da_referencia(chave),
        "so_nexbuy": referencia["fontes"] == ("nexbuy",),
    }


# Indicador → o que precisa existir no mês para ele significar alguma coisa.
_DEPENDENCIAS_INDICADORES = {
    "margem_bruta": ("sem_compras",),
    "peso_compras": ("sem_compras",),
    "peso_custos_fixos": ("sem_custos_fixos",),
    "margem_contribuicao": ("sem_compras",),
    "margem_operacional": ("sem_compras", "sem_custos_fixos"),
    "margem_seguranca": ("sem_compras", "sem_custos_fixos"),
}
_MOTIVO_LACUNA = {
    "sem_compras": "nenhuma compra aprovada no mês",
    "sem_custos_fixos": "nenhum custo fixo ativo",
}


def _marcar_sem_dados(indicadores, lacunas) -> None:
    """Indicador que depende de um dado ausente no mês vira "Sem dados"
    (com o motivo), nunca "Saudável" — 0% de peso das compras sem nenhuma
    compra lançada não é saúde, é lançamento pendente."""
    for indicador in indicadores:
        motivos = [
            _MOTIVO_LACUNA[chave] for chave in _DEPENDENCIAS_INDICADORES.get(indicador["chave"], ())
            if lacunas[chave]
        ]
        if motivos:
            indicador.update({
                "valor": None,
                "valor_fmt": "Sem dados",
                "status": "sem_dado",
                "status_info": STATUS_SEMAFORO["sem_dado"],
                "motivo_sem_dado": "Falta lançar: " + " e ".join(motivos) + ".",
            })


def _direcao(variacao) -> str:
    if variacao is None:
        return "sem base"
    if variacao > LIMIAR_TENDENCIA:
        return "subindo"
    if variacao < -LIMIAR_TENDENCIA:
        return "caindo"
    return "estável"


def _tendencia(analise: AnaliseFinanceira, ano: int, mes: int) -> dict:
    meses = [somar_meses(ano, mes, -i) for i in (2, 1, 0)]
    dres = [analise.dre(*m) for m in meses if analise.mes_tem_dados(*m)]
    dres = [d for d in dres if d.receita_configurada]
    base = {
        "meses": [
            {"rotulo": d.rotulo, "receita_fmt": formatar_brl(d.receita_total), "despesas_fmt": formatar_brl(d.despesas_totais)}
            for d in dres
        ],
    }
    if len(dres) < 2:
        return {**base, "status": "sem_dado", "status_info": STATUS_SEMAFORO["sem_dado"],
                "texto": "São necessários pelo menos 2 meses com receita lançada para calcular a tendência.",
                "var_receita": None, "var_despesas": None, "direcao_receita": "sem base",
                "direcao_despesas": "sem base", "var_receita_fmt": "—", "var_despesas_fmt": "—",
                "primeiro": "", "ultimo": ""}
    primeiro, ultimo = dres[0], dres[-1]
    var_receita = variacao_percentual(ultimo.receita_total, primeiro.receita_total)
    var_despesas = variacao_percentual(ultimo.despesas_totais, primeiro.despesas_totais)
    dir_receita, dir_despesas = _direcao(var_receita), _direcao(var_despesas)
    if dir_receita == "caindo" and dir_despesas != "caindo":
        status = "critico"
    elif dir_receita == "caindo" or (
        var_despesas is not None and var_receita is not None and var_despesas - var_receita > LIMIAR_TENDENCIA
    ) or (var_receita is None and dir_despesas == "subindo"):
        status = "atencao"
    else:
        status = "bom"
    texto = (
        f"Entre {primeiro.rotulo} e {ultimo.rotulo}: receita {dir_receita} ({formatar_pct(var_receita, sinal=True)}) "
        f"e despesas {dir_despesas} ({formatar_pct(var_despesas, sinal=True)})."
    )
    return {**base, "status": status, "status_info": STATUS_SEMAFORO[status], "texto": texto,
            "var_receita": var_receita, "var_despesas": var_despesas,
            "direcao_receita": dir_receita, "direcao_despesas": dir_despesas,
            "var_receita_fmt": formatar_pct(var_receita, sinal=True),
            "var_despesas_fmt": formatar_pct(var_despesas, sinal=True),
            "primeiro": primeiro.rotulo, "ultimo": ultimo.rotulo}


def _comprometimento(analise: AnaliseFinanceira, ano: int, mes: int) -> dict:
    media, quantidade_meses = analise.receita_media(ano, mes)
    janelas = []
    for dias in (30, 60, 90):
        valor = analise.parcelas_a_vencer(dias)
        pct = percentual(valor, media) if media else None
        janelas.append({"dias": dias, "valor": valor, "valor_fmt": formatar_brl(valor), "pct": pct,
                        "pct_fmt": formatar_pct(pct),
                        "ate": (analise.hoje + timedelta(days=dias)).strftime("%d/%m/%Y")})
    status = classificar("comprometimento_30d", janelas[0]["pct"])
    vencidas = analise.parcelas_vencidas()
    return {
        "janelas": janelas,
        "receita_media": media,
        "receita_media_fmt": formatar_valor(media),
        "meses_media": quantidade_meses,
        "status": status,
        "status_info": STATUS_SEMAFORO[status],
        "referencia_texto": REFERENCIAS_MERCADO["comprometimento_30d"]["texto"],
        "vencidas": vencidas,
        "vencidas_fmt": formatar_brl(vencidas),
        "hoje_fmt": analise.hoje.strftime("%d/%m/%Y"),
    }


def _recomendacao(nivel, texto, links, chaves_links):
    return {
        "nivel": nivel,
        "status_info": STATUS_SEMAFORO[nivel],
        "texto": texto,
        "links": [links[chave] for chave in chaves_links if chave in links],
    }


def gerar_recomendacoes(dre: DreMes, pe, tendencia: dict, comprometimento: dict,
                        percentual_compras_config, links: dict) -> list:
    """Recomendações acionáveis e quantificadas, geradas por REGRAS FIXAS
    (determinísticas) a partir dos números do mês — não é IA."""
    recomendacoes = []
    receita = dre.receita_total
    resultado = dre.resultado
    ref_compras = REFERENCIAS_MERCADO["peso_compras"]["saudavel"]
    ref_fixos = REFERENCIAS_MERCADO["peso_custos_fixos"]["saudavel"]
    texto_config = (
        f" (hoje {formatar_numero(percentual_compras_config, 0)}% da disponibilidade vai para compras)"
        if percentual_compras_config is not None else ""
    )

    if receita <= ZERO:
        return [_recomendacao(
            "critico",
            "A receita lançada para o mês está zerada — sem receita não há margem nem ponto de equilíbrio. "
            "Confira o lançamento da receita mensal e das receitas extras.",
            links, ("receitas",),
        )]

    if resultado < ZERO:
        if pe is not None:
            falta = pe - receita
            recomendacoes.append(_recomendacao(
                "critico",
                f"O mês fechou com prejuízo de {formatar_brl(-resultado)}. Para cobrir os custos fixos faltam "
                f"{formatar_brl(falta)} de receita por mês (ponto de equilíbrio: {formatar_brl(pe)}), "
                f"ou é preciso reduzir {formatar_brl(-resultado)} de custos fixos.",
                links, ("receitas", "custos_fixos"),
            ))
        elif dre.margem_contribuicao <= ZERO:
            # Sprint de Melhorias 1: só quando é verdade. Sem ponto de
            # equilíbrio por FALTA DE DADO (mês sem compras ou sem custos
            # fixos lançados) a frase dizia "as compras já passam da receita"
            # com compras de R$ 0,00 — quem cobre esse caso é o aviso
            # "Análise incompleta" de montar_saude.
            recomendacoes.append(_recomendacao(
                "critico",
                f"As compras e os custos variáveis ({formatar_brl(dre.compras + dre.custos_variaveis)}) já passam "
                f"da receita do mês ({formatar_brl(receita)}): nessa proporção nenhum volume de venda cobre os "
                f"custos fixos. Reduza as compras do mês — revise o percentual destinado a compras em "
                f"Capacidade Financeira{texto_config} e os limites em Compradores e Limites.",
                links, ("configuracao", "capacidade"),
            ))

    peso_compras = dre.pct(dre.compras)
    if peso_compras is not None and peso_compras > ref_compras:
        excesso = dre.compras - (receita * ref_compras / CEM)
        recomendacoes.append(_recomendacao(
            classificar("peso_compras", peso_compras),
            f"As compras consumiram {formatar_pct(peso_compras)} da receita, acima da referência de mercado de "
            f"cerca de 70% a 73% (RD Saúde 2024; Sincofarma-SP). Trazer as compras para "
            f"{formatar_numero(ref_compras, 0)}% da receita significaria {formatar_brl(excesso)} a menos em "
            f"compras no mês: revise o percentual destinado a compras em Capacidade Financeira{texto_config} "
            f"e os limites dos compradores. Se foi um mês de reposição de estoque, acompanhe o mês seguinte.",
            links, ("configuracao", "capacidade"),
        ))

    peso_fixos = dre.pct(dre.custos_fixos)
    if peso_fixos is not None and peso_fixos > ref_fixos:
        reduzir = dre.custos_fixos - (receita * ref_fixos / CEM)
        aumentar = (dre.custos_fixos * CEM / ref_fixos) - receita
        maior = dre.custos_fixos_detalhe[0] if dre.custos_fixos_detalhe else None
        complemento = (
            f" O maior deles é “{maior[0]}” ({formatar_brl(maior[1])}, {formatar_pct(dre.pct(maior[1]))} da receita)."
            if maior else ""
        )
        recomendacoes.append(_recomendacao(
            classificar("peso_custos_fixos", peso_fixos),
            f"Os custos fixos pesam {formatar_pct(peso_fixos)} da receita (referência de mercado: cerca de 20%). "
            f"Para chegar a {formatar_numero(ref_fixos, 0)}% seria preciso reduzir {formatar_brl(reduzir)} de "
            f"custos fixos ou aumentar a receita em {formatar_brl(aumentar)} por mês.{complemento}",
            links, ("custos_fixos", "receitas"),
        ))

    if resultado >= ZERO and pe is not None and receita > ZERO:
        margem_seg = percentual(receita - pe, receita)
        if margem_seg is not None and margem_seg < REFERENCIAS_MERCADO["margem_seguranca"]["saudavel"]:
            recomendacoes.append(_recomendacao(
                classificar("margem_seguranca", margem_seg),
                f"A receita está só {formatar_pct(margem_seg)} acima do ponto de equilíbrio ({formatar_brl(pe)}): "
                f"uma queda de {formatar_brl(receita - pe)} na receita já zera o resultado. Mantenha os custos "
                f"fixos sob controle e acompanhe as vendas semana a semana.",
                links, ("custos_fixos", "receitas"),
            ))

    if tendencia.get("direcao_receita") == "caindo":
        recomendacoes.append(_recomendacao(
            "atencao" if tendencia["status"] != "critico" else "critico",
            f"A receita caiu {formatar_pct(abs(tendencia['var_receita']))} entre {tendencia['primeiro']} e "
            f"{tendencia['ultimo']}. Confira se toda a receita (mensal e extras) foi lançada e, se a queda for "
            f"real, ajuste as compras ao novo patamar de vendas.",
            links, ("receitas", "configuracao"),
        ))
    elif tendencia.get("status") == "atencao" and tendencia.get("var_despesas") is not None:
        recomendacoes.append(_recomendacao(
            "atencao",
            f"As despesas cresceram {tendencia['var_despesas_fmt']} entre {tendencia['primeiro']} e "
            f"{tendencia['ultimo']}, mais que a receita ({tendencia['var_receita_fmt']}). Revise os custos que "
            f"mais subiram.",
            links, ("custos_fixos", "custos_variaveis"),
        ))

    primeira_janela = comprometimento["janelas"][0]
    if comprometimento["status"] in ("atencao", "critico"):
        recomendacoes.append(_recomendacao(
            comprometimento["status"],
            f"As parcelas a vencer nos próximos 30 dias ({primeira_janela['valor_fmt']}) equivalem a "
            f"{primeira_janela['pct_fmt']} da receita média mensal ({comprometimento['receita_media_fmt']}). "
            f"Segure novas compras a prazo e revise os limites dos compradores.",
            links, ("capacidade", "agenda"),
        ))
    if comprometimento["vencidas"] > ZERO:
        recomendacoes.append(_recomendacao(
            "atencao",
            f"Há {comprometimento['vencidas_fmt']} em parcelas vencidas ainda não baixadas. Confira na Agenda "
            f"Financeira se já foram pagas (e dê baixa) ou negocie com o fornecedor.",
            links, ("agenda",),
        ))

    if not recomendacoes:
        recomendacoes.append(_recomendacao(
            "bom",
            "Os indicadores do mês estão dentro das referências de mercado. Continue lançando a receita e os "
            "custos todo mês para acompanhar a tendência.",
            links, ("receitas",),
        ))
    ordem = {"critico": 0, "atencao": 1, "bom": 2, "sem_dado": 3}
    return sorted(recomendacoes, key=lambda r: ordem[r["nivel"]])


def montar_saude(analise: AnaliseFinanceira, ano: int, mes: int, *, usuario=None, empresa=None) -> dict:
    dre = analise.dre(ano, mes)
    links = links_de_acao(usuario) if usuario is not None else {}
    comprometimento = _comprometimento(analise, ano, mes)
    if not dre.receita_configurada:
        return {"sem_receita": True, "dre": dre, "links": links, "comprometimento": comprometimento}

    receita = dre.receita_total
    razao_mc = (dre.margem_contribuicao / receita) if receita > ZERO else None
    pe = (dre.custos_fixos / razao_mc).quantize(Decimal("0.01"), ROUND_HALF_UP) if razao_mc and razao_mc > ZERO else None
    margem_seguranca = percentual(receita - pe, receita) if pe is not None else None
    lacunas = lacunas_do_mes(dre)
    if receita > ZERO and (lacunas["sem_custos_fixos"] or lacunas["sem_compras"]):
        # Sem custo fixo ou sem compra no mês, o ponto de equilíbrio (R$ 0,00)
        # e as margens de 100% seriam falta de dado, não saúde.
        pe, margem_seguranca = None, None

    indicadores = [
        _indicador("margem_bruta", "Margem bruta", dre.pct(dre.margem_bruta),
                   "Quanto sobra da receita depois de pagar as compras de mercadoria."),
        _indicador("peso_compras", "Peso das compras na receita", dre.pct(dre.compras),
                   "Quanto da receita foi para compras aprovadas no mês (sem estoque, é a aproximação do custo da mercadoria)."),
        _indicador("peso_custos_fixos", "Peso dos custos fixos", dre.pct(dre.custos_fixos),
                   "Folha, aluguel e demais contas recorrentes em relação à receita."),
        _indicador("margem_contribuicao", "Margem de contribuição", dre.pct(dre.margem_contribuicao),
                   "O que sobra para pagar os custos fixos depois das compras e dos custos variáveis."),
        _indicador("margem_operacional", "Margem operacional (resultado)", dre.pct(dre.resultado),
                   "Lucro ou prejuízo do mês em relação à receita."),
        _indicador("margem_seguranca", "Margem de segurança", margem_seguranca,
                   "Quanto a receita está acima do ponto de equilíbrio — o “colchão” antes do prejuízo.",
                   valor_fmt=(formatar_pct(margem_seguranca) if pe is not None
                              else ("sem equilíbrio" if razao_mc is not None else "—")),
                   # Margem de contribuição zero/negativa: não existe ponto de
                   # equilíbrio (nenhuma receita cobre os custos fixos) — crítico.
                   # Receita zerada: não há base de cálculo — sem dados.
                   status=None if pe is not None or razao_mc is None else "critico"),
    ]
    if receita > ZERO:
        _marcar_sem_dados(indicadores, lacunas)
    tendencia = _tendencia(analise, ano, mes)
    config = getattr(empresa, "configuracao_financeira", None) if empresa is not None else None
    percentual_config = config.percentual_compras if config is not None else None
    recomendacoes = gerar_recomendacoes(dre, pe, tendencia, comprometimento, percentual_config, links)
    if receita > ZERO and lacunas["incompleto"]:
        chaves = (("custos_fixos",) if lacunas["sem_custos_fixos"] else ()) + (
            ("compras",) if lacunas["sem_compras"] else ()
        )
        recomendacoes = [_recomendacao(
            "atencao",
            f"Análise incompleta: faltam {lacunas['faltando_texto']} de {rotulo_mes_longo(ano, mes)}. Sem eles, as "
            "margens e o ponto de equilíbrio não refletem a farmácia — cadastre os custos fixos e registre as "
            "compras do mês para a análise ficar completa.",
            links, chaves,
        )] + [r for r in recomendacoes if r["nivel"] != "bom"]

    contagem = {"bom": 0, "atencao": 0, "critico": 0, "sem_dado": 0}
    for item in indicadores + [tendencia, comprometimento]:
        contagem[item["status"]] += 1

    meses = analise.janela(ano, mes)
    serie = [analise.dre(*m) for m in meses]
    return {
        "sem_receita": False,
        "dre": dre,
        "links": links,
        "lacunas": lacunas,
        "indicadores": indicadores,
        "ponto_equilibrio": pe,
        "ponto_equilibrio_fmt": formatar_valor(pe),
        "margem_seguranca_fmt": formatar_pct(margem_seguranca),
        "receita_fmt": formatar_brl(receita),
        "custos_fixos_fmt": formatar_brl(dre.custos_fixos),
        "margem_contribuicao_pct_fmt": formatar_pct(dre.pct(dre.margem_contribuicao)),
        # Rodada final: a frase do ponto de equilíbrio manda conferir a conta,
        # mas mostrava a MC arredondada (94,8%) enquanto o cálculo usa a razão
        # exata — refazendo a conta com o que estava na tela, não batia. A
        # frase passa a usar 2 casas e a fórmula sai em reais, com os mesmos
        # números do cálculo (custos fixos × receita ÷ margem de contribuição).
        "margem_contribuicao_pct2_fmt": (
            formatar_numero((dre.margem_contribuicao / receita * Decimal("100")).quantize(Decimal("0.01"), ROUND_HALF_UP), 2) + "%"
            if receita > ZERO else "—"
        ),
        "margem_contribuicao_fmt": formatar_brl(dre.margem_contribuicao),
        "falta_para_equilibrio_fmt": formatar_brl(pe - receita) if pe is not None and pe > receita else "",
        "tendencia": tendencia,
        "comprometimento": comprometimento,
        "recomendacoes": recomendacoes,
        "contagem": contagem,
        "serie": serie,
        "tabela_margens": [
            {
                "rotulo": d.rotulo,
                "receita_configurada": d.receita_configurada,
                "margem_bruta_fmt": formatar_pct(d.pct(d.margem_bruta)),
                "margem_contribuicao_fmt": formatar_pct(d.pct(d.margem_contribuicao)),
                "margem_operacional_fmt": formatar_pct(d.pct(d.resultado)),
                "selecionado": (d.ano, d.mes) == (ano, mes),
            }
            for d in serie
        ],
        "fontes": [FONTES_REFERENCIA[codigo] for codigo in ("rd", "sincofarma", "nexbuy")],
    }


# ---------------------------------------------------------------------------
# Widget "Resultado do mês" (dashboards de Proprietário, Financeiro e Gerente)
# ---------------------------------------------------------------------------

def resumo_resultado_do_mes(filiais, usuario, hoje: Optional[date] = None, meses_curva: int = 6,
                            *, somente_percentuais: bool = False) -> dict:
    """Dados do widget: receita total, despesas, resultado e margem do mês
    atual + mini-curva de 6 meses do resultado. Mesma fonte da DRE (Motor
    Financeiro), então o widget sempre bate com a tela de Análise. Com o
    mês atual em andamento (sempre, enquanto ele não vira), os números do
    mês saem marcados como parciais, a curva cobre os 6 meses FECHADOS e
    `ultimo_fechado` traz o resultado do mês anterior como referência.

    `somente_percentuais=True`: nenhum valor em R$ sai daqui — só
    lucro/prejuízo, a margem do mês e a curva da margem (%). Nenhum
    dashboard usa este modo hoje: o Gerente vê os valores em R$ (decisão
    explícita do usuário nas Correções de Produção)."""
    from .graficos_svg import sparkline

    hoje = hoje or timezone.localdate()
    analise = AnaliseFinanceira(filiais, hoje)
    dre = analise.dre(hoje.year, hoje.month)
    # Críticos (rodada 2): o widget não recebia as lacunas do mês — com
    # receita e custos lançados mas nenhuma compra aprovada, a DRE e a Saúde
    # já diziam "Análise incompleta", e o widget mostrava "Lucro R$ 125.300 ·
    # Margem 77,5%" como resultado firme. Mesma regra da DRE (`lacunas_do_mes`).
    lacunas = lacunas_do_mes(dre)
    # Ajuste final (produto-e-demo): o mês de hoje ainda não fechou (receita
    # do mês inteiro × compras só até hoje) — o widget diz que é parcial e a
    # mini-curva mostra só os meses FECHADOS (antes, o mês corrente virava
    # um pico de 25% a 50% de margem que achatava os meses reais), com o
    # último mês fechado como referência ao lado.
    em_andamento = lacunas["em_andamento"]
    ano_fim, mes_fim = somar_meses(hoje.year, hoje.month, -1) if em_andamento else (hoje.year, hoje.month)
    meses = analise.janela(ano_fim, mes_fim, meses_curva)
    serie = [analise.dre(*m) for m in meses]
    if somente_percentuais:
        valores = [d.pct(d.resultado) if d.receita_configurada else None for d in serie]
        formato, formatar = "pct", formatar_pct
        titulo = f"Margem operacional dos últimos {len(serie)} meses"
    else:
        valores = [d.resultado if d.receita_configurada else None for d in serie]
        formato, formatar = "brl", formatar_valor
        titulo = f"Resultado dos últimos {len(serie)} meses"
    if em_andamento:
        titulo += " fechados"
    rotulos = [rotulo_mes_curto(d.ano, d.mes) for d in serie]
    links = links_de_acao(usuario)
    curva = ""
    if any(v is not None for v in valores):
        curva = sparkline(valores, rotulos, titulo=titulo, formato=formato)
    ultimo_fechado = None
    if em_andamento:
        anterior = analise.dre(*somar_meses(hoje.year, hoje.month, -1))
        if anterior.receita_configurada:
            lacunas_anterior = lacunas_do_mes(anterior)
            ultimo_fechado = {
                "rotulo": rotulo_mes_longo(anterior.ano, anterior.mes),
                "rotulo_curto": rotulo_mes_curto(anterior.ano, anterior.mes),
                "lucro": anterior.resultado >= ZERO,
                "margem_fmt": formatar_pct(anterior.pct(anterior.resultado)),
                "faltando_texto": lacunas_anterior["faltando_texto"] if lacunas_anterior["incompleto"] else "",
            }
            if not somente_percentuais:
                ultimo_fechado["resultado_fmt"] = formatar_brl(anterior.resultado)
    dados = {
        "sem_filial": not analise.filiais,
        "configurada": dre.receita_configurada,
        "lacunas": lacunas,
        "incompleto": lacunas["incompleto"],
        "em_andamento": em_andamento,
        "parcial_ate_fmt": lacunas["parcial_ate_fmt"],
        "ultimo_fechado": ultimo_fechado,
        "detalhar_valores": not somente_percentuais,
        "mes_rotulo": rotulo_mes_longo(hoje.year, hoje.month),
        "margem_fmt": formatar_pct(dre.pct(dre.resultado)),
        "lucro": dre.resultado >= ZERO,
        "curva_svg": curva,
        "curva_titulo": "Margem" if somente_percentuais else "Resultado",
        "curva_meses": len(serie),
        "curva_fechados": em_andamento,
        "curva_tabela": [{"rotulo": r, "valor_fmt": formatar(v)} for r, v in zip(rotulos, valores)],
        "url_analise": reverse("financeiro:analise_dre"),
        "link_receita": links.get("receita_nova"),
    }
    if not somente_percentuais:
        dados.update({
            "receita": dre.receita_total,
            "despesas": dre.despesas_totais,
            "resultado": dre.resultado,
            "receita_fmt": formatar_brl(dre.receita_total),
            "despesas_fmt": formatar_brl(dre.despesas_totais),
            "resultado_fmt": formatar_brl(dre.resultado),
        })
    return dados


def ultimo_dia(ano: int, mes: int) -> date:
    return date(ano, mes, calendar.monthrange(ano, mes)[1])
