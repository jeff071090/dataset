"""Planejamento Financeiro — hub do Financeiro (Épico 2A — Etapa 04).

O Financeiro nunca procura função: tudo o que o perfil usa está aqui,
agrupado por tarefa. Nenhuma regra nova — o hub navega para telas que já
existem; a única tela nova deste módulo é a lista de Parcelamentos em
aberto (leitura pura sobre `ParcelaCompra`).
"""
import calendar
from datetime import date
from decimal import Decimal

from django.db.models import Count, Sum
from django.shortcuts import render

from compras.models import ParcelaCompra
from core.contexto import empresa_ativa, filiais_do_contexto
from core.permissions import permissao_required
from core.relatorios import resposta_csv
from finance_engine.agenda import ORIGEM_CONTA_FIXA, ORIGEM_CONTA_VARIAVEL, ORIGEM_PARCELA, ORIGEM_PROVISAO, gerar_agenda

ZERO = Decimal("0")

# Sprint de Correções Críticas (Seção 17): Contas a Pagar nunca soma tudo
# num único número — cada origem de `LancamentoAgenda` representa uma
# natureza DIFERENTE de compromisso, e o valor de cada uma para uma
# decisão financeira não é o mesmo (uma parcela de compra já aprovada é
# muito mais "real" do que uma provisão ainda aguardando aprovação).
_GRUPOS_CONTAS_A_PAGAR = (
    {
        "chave": "constituidas",
        "titulo": "Obrigações Constituídas",
        "descricao": "Parcelas de compras já aprovadas — o compromisso já existe de fato.",
        "cor": "blue",
        "origens": (ORIGEM_PARCELA,),
    },
    {
        "chave": "previsoes",
        "titulo": "Previsões",
        "descricao": "Custos fixos e variáveis já configurados — recorrência ou estimativa, não nasceram de uma compra real.",
        "cor": "teal",
        "origens": (ORIGEM_CONTA_FIXA, ORIGEM_CONTA_VARIAVEL),
    },
    {
        "chave": "provisoes",
        "titulo": "Provisões",
        "descricao": "Intenções de compra planejadas pelos compradores, ainda não efetivadas — podem nem virar uma compra de verdade.",
        "cor": "purple",
        "origens": (ORIGEM_PROVISAO,),
    },
)


def _agrupar_contas_a_pagar_por_origem(linhas):
    """`linhas` é uma lista de (filial, LancamentoAgenda). Devolve os 3
    grupos da Seção 17, cada um com suas próprias linhas e subtotal."""
    grupos = []
    for definicao in _GRUPOS_CONTAS_A_PAGAR:
        linhas_do_grupo = [par for par in linhas if par[1].origem in definicao["origens"]]
        grupos.append(
            {
                "titulo": definicao["titulo"],
                "descricao": definicao["descricao"],
                "cor": definicao["cor"],
                "linhas": linhas_do_grupo,
                "subtotal": sum((item.valor for _, item in linhas_do_grupo), ZERO),
                "quantidade": len(linhas_do_grupo),
            }
        )
    return grupos


@permissao_required("financeiro.ver")
def planejamento_home(request):
    """Hub com as áreas do Planejamento Financeiro (Etapa 04): Calendário
    Financeiro, Agenda, Capacidade, Compradores e Limites, Calendário
    Operacional, Parcelamentos, Simulador e Relatórios + cadastros-base.

    Rodada final: cada cartão usa o MESMO nome do menu (core/navegacao.py)
    e só aparece para quem passa no MESMO gate da tela de destino — o hub é
    aberto por `financeiro.ver`, que o RBAC aditivo pode conceder a um
    Gerente, mas Receitas/Custos/Capacidade são por perfil."""
    from core.navegacao import pode_acessar
    from core.permissions import PERFIS_GESTORES_FINANCEIROS
    from usuarios.models import Usuario

    perfis_simulacao = (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO, Usuario.Perfil.COMPRADOR)
    hoje = date.today()
    filiais = list(filiais_do_contexto(request))

    pendencias = {"parcelas_abertas": 0, "parcelas_vencidas": 0}
    if filiais:
        abertas = ParcelaCompra.objects.filter(
            compra__filial__in=filiais, status=ParcelaCompra.Status.PENDENTE
        )
        pendencias["parcelas_abertas"] = abertas.count()
        pendencias["parcelas_vencidas"] = abertas.filter(data_vencimento__lt=hoje).count()

    # (título do menu, descrição, url, ícone, permissão da view, perfis da view)
    catalogo = [
        ("Calendário Financeiro", "Visões mensal, semanal e diária do caixa comprometido.",
         "/financeiro/calendario/", "bi-calendar3", "financeiro.ver", None),
        ("Agenda Financeira", "Pagamentos do dia, próximos vencimentos e baixa de parcelas.",
         "/financeiro/agenda/", "bi-calendar2-week", "agenda.ver", None),
        ("Capacidade Financeira", "Percentuais, dias úteis, saldo acumulado e regra de excesso.",
         "/financeiro/configuracao/", "bi-cpu-fill", None, PERFIS_GESTORES_FINANCEIROS),
        ("Compradores e Limites", "Distribuir capacidade, bloquear e liberar compradores.",
         "/financeiro/capacidade-compradores/", "bi-people-fill", "capacidade.gerenciar", None),
        ("Calendário Operacional", "Feriados, bloqueios e exceções (dias sem compra ou dias especiais).",
         "/financeiro/calendario-operacional/", "bi-calendar2-x", "calendario.configurar", None),
        ("Parcelamentos", "Todas as parcelas em aberto, com vencidas em destaque.",
         "/financeiro/parcelamentos/", "bi-credit-card-2-front", "financeiro.ver", None),
        ("Contas a Pagar", "Compromissos do mês fechado, com impressão e exportação.",
         "/financeiro/contas-a-pagar/", "bi-receipt", "financeiro.ver", None),
        ("Simulador", "\"E se eu comprasse X no dia Y?\" — sem gravar nada.",
         "/compras/simulacao/", "bi-calculator-fill", None, perfis_simulacao),
        ("Relatórios", "Timeline, agenda e indicadores num só lugar.",
         "/relatorios/", "bi-file-earmark-bar-graph", "relatorios.ver", None),
        ("Receitas", "Receita mensal (faturamento) e receitas extras — a base da capacidade.",
         "/financeiro/receitas/", "bi-cash-coin", None, PERFIS_GESTORES_FINANCEIROS),
        ("Custos Fixos", "Folha, aluguel, impostos e demais contas recorrentes.",
         "/financeiro/custos-fixos/", "bi-receipt", None, PERFIS_GESTORES_FINANCEIROS),
        ("Custos Variáveis", "Despesas pontuais com data prevista.",
         "/financeiro/custos-variaveis/", "bi-arrow-left-right", None, PERFIS_GESTORES_FINANCEIROS),
    ]
    areas = [
        {"titulo": titulo, "descricao": descricao, "url": url, "icone": icone}
        for titulo, descricao, url, icone, permissao, perfis in catalogo
        if pode_acessar(request.user, permissao=permissao, perfis=perfis)
    ]
    return render(
        request,
        "financeiro/planejamento.html",
        {"areas": areas, "pendencias": pendencias, "hoje": hoje},
    )


@permissao_required("financeiro.ver")
def parcelamentos(request):
    """Parcelamentos em aberto (Etapa 04) — leitura pura sobre as parcelas
    pendentes das filiais do contexto; a baixa continua na Agenda (rota
    existente `financeiro:baixar_parcela`)."""
    hoje = date.today()
    filiais = list(filiais_do_contexto(request))

    parcelas = (
        ParcelaCompra.objects.filter(compra__filial__in=filiais, status=ParcelaCompra.Status.PENDENTE)
        .select_related("compra", "compra__fornecedor", "compra__usuario")
        .order_by("data_vencimento")
    )
    somente_vencidas = request.GET.get("vencidas") == "1"
    if somente_vencidas:
        parcelas = parcelas.filter(data_vencimento__lt=hoje)

    if request.GET.get("formato") == "csv":
        linhas = [
            [
                parcela.data_vencimento.strftime("%d/%m/%Y"),
                parcela.compra.fornecedor.nome,
                f"{parcela.numero}/{parcela.compra.total_parcelas}",
                parcela.compra.usuario.get_full_name() or parcela.compra.usuario.username,
                str(parcela.valor).replace(".", ","),
                "Vencida" if parcela.data_vencimento < hoje else "A vencer",
            ]
            for parcela in parcelas
        ]
        return resposta_csv(
            "parcelamentos.csv", ["Vencimento", "Fornecedor", "Parcela", "Comprador", "Valor (R$)", "Situação"], linhas,
        )

    totais = parcelas.aggregate(total=Sum("valor"), quantidade=Count("id"))
    contexto = {
        "hoje": hoje,
        "parcelas": parcelas,
        "total": totais["total"] or ZERO,
        "quantidade": totais["quantidade"] or 0,
        "vencidas": sum(1 for p in parcelas if p.data_vencimento < hoje),
        "somente_vencidas": somente_vencidas,
        "sem_filial": not filiais,
        "filtros_aplicados": ["Somente vencidas"] if somente_vencidas else [],
    }
    return render(request, "financeiro/parcelamentos.html", contexto)


@permissao_required("financeiro.ver")
def contas_a_pagar(request):
    """Contas a Pagar / Compromissos (Sprint de Consolidação, Gate 2A,
    P1-6): a MESMA base de dados da Agenda Financeira (`gerar_agenda`),
    mas por período FECHADO (mês/ano) em vez de "próximos N dias" — o
    recorte que faz sentido para fechamento financeiro, inclusive de
    meses passados.

    Sprint de Correções Críticas (Seção 17): segmentado por origem em 3
    naturezas de compromisso (Obrigações Constituídas / Previsões /
    Provisões) — nunca um único número somando tudo sem explicar do que
    ele é feito. A tela e o CSV usam exatamente a mesma consulta."""
    hoje = date.today()
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
        inicio = date(ano, mes, 1)
    except (TypeError, ValueError):
        ano, mes, inicio = hoje.year, hoje.month, hoje.replace(day=1)
    fim = date(ano, mes, calendar.monthrange(ano, mes)[1])

    filiais = list(filiais_do_contexto(request))
    # (filial, LancamentoAgenda) — a Agenda não carrega a filial em cada
    # item (é gerada uma filial por vez); mantemos o par aqui só para esta
    # tela poder mostrar a coluna Filial quando o usuário tem mais de uma.
    linhas = [(filial, item) for filial in filiais for item in gerar_agenda(filial, inicio, fim, hoje=hoje)]
    linhas.sort(key=lambda par: (par[1].data, par[1].descricao))

    periodo = f"{inicio:%d/%m/%Y} a {fim:%d/%m/%Y}"

    if request.GET.get("formato") == "csv":
        grupos_por_origem = {origem: g["titulo"] for g in _GRUPOS_CONTAS_A_PAGAR for origem in g["origens"]}
        linhas_csv = [
            [
                item.data.strftime("%d/%m/%Y"), grupos_por_origem.get(item.origem, item.origem), item.tipo,
                item.descricao, filial.nome, item.responsavel or "", str(item.valor).replace(".", ","),
                "Vencida" if item.vencida else item.status.replace("_", " ").capitalize(),
            ]
            for filial, item in linhas
        ]
        return resposta_csv(
            "contas_a_pagar.csv",
            ["Data", "Origem", "Tipo", "Descrição", "Filial", "Responsável", "Valor (R$)", "Status"],
            linhas_csv,
        )

    grupos = _agrupar_contas_a_pagar_por_origem(linhas)
    total_geral = sum((item.valor for _, item in linhas), ZERO)
    contexto = {
        "hoje": hoje,
        "ano": ano,
        "mes": mes,
        "mes_referencia": inicio,
        "periodo": periodo,
        "grupos": grupos,
        "total_geral": total_geral,
        "sem_filial": not filiais,
        "mostra_coluna_filial": len(filiais) > 1,
        "mes_anterior": (ano, mes - 1) if mes > 1 else (ano - 1, 12),
        "mes_seguinte": (ano, mes + 1) if mes < 12 else (ano + 1, 1),
    }
    return render(request, "financeiro/contas_a_pagar.html", contexto)
