"""Calendário Inteligente do Financeiro (RC do Épico 01 — Correção 02).

Módulo próprio do FINANCEIRO: uma visão mensal/semanal/diária de tudo o
que compromete o caixa — compras do dia, parcelamentos, contas fixas
(folha, aluguel, impostos e demais obrigações cadastradas), contas
variáveis e provisões — cruzada com a posição do Motor Financeiro
(capacidade, comprado, saldo, status) e com as exceções do Calendário
Operacional (feriados, bloqueios, observações).

Nada aqui recalcula regra financeira nem persiste nada: o módulo é uma
AGREGAÇÃO de fontes que já existem — `finance_engine.agenda` (compromissos),
`MotorFinanceiro.calcular_posicoes_do_mes` (day-walk canônico, o MESMO dos
dashboards) e `DiaOperacional` (exceções) — a mesma decisão de design da
Agenda Financeira (Épico 3).
"""
from calendar import monthrange
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional

from compras.models import Compra
from finance_engine.agenda import (
    ORIGEM_CONTA_FIXA,
    ORIGEM_CONTA_VARIAVEL,
    ORIGEM_PARCELA,
    ORIGEM_PROVISAO,
    agenda_do_dia,
    gerar_agenda,
)
from finance_engine.services import motor_financeiro

from .models import DiaOperacional

ZERO = Decimal("0")

# Filtro de origem aceito pela tela (valor vazio = todas).
ORIGENS_FILTRO = (
    (ORIGEM_PARCELA, "Parcelamentos"),
    (ORIGEM_CONTA_FIXA, "Contas Fixas"),
    (ORIGEM_CONTA_VARIAVEL, "Contas Variáveis"),
    (ORIGEM_PROVISAO, "Provisões"),
)
_ORIGENS_VALIDAS = {codigo for codigo, _ in ORIGENS_FILTRO}


def _filtrar_lancamentos(lancamentos, origem: str = "", pesquisa: str = ""):
    """Aplica o filtro por origem e a pesquisa textual (descrição, tipo ou
    responsável) sobre lançamentos da Agenda — usado pelas três visões."""
    if origem in _ORIGENS_VALIDAS:
        lancamentos = [item for item in lancamentos if item.origem == origem]
    termo = (pesquisa or "").strip().lower()
    if termo:
        lancamentos = [
            item
            for item in lancamentos
            if termo in item.descricao.lower()
            or termo in item.tipo.lower()
            or termo in (item.responsavel or "").lower()
        ]
    return lancamentos


def montar_calendario_financeiro(
    filial, ano: int, mes: int, origem: str = "", pesquisa: str = "", hoje: Optional[date] = None
) -> dict:
    """Payload do mês para o Calendário do Financeiro: um registro por dia
    com posição do Motor + compromissos da Agenda + exceção operacional."""
    hoje = hoje or date.today()
    ultimo_dia = monthrange(ano, mes)[1]
    inicio, fim = date(ano, mes, 1), date(ano, mes, ultimo_dia)

    posicoes = motor_financeiro.calcular_posicoes_do_mes(filial, ano, mes)
    agenda = _filtrar_lancamentos(gerar_agenda(filial, inicio, fim, hoje=hoje), origem, pesquisa)

    agenda_por_dia = defaultdict(list)
    for lancamento in agenda:
        agenda_por_dia[lancamento.data].append(lancamento)

    excecoes = {
        excecao.data: excecao
        for excecao in DiaOperacional.objects.filter(empresa=filial.empresa, data__range=(inicio, fim))
    }

    dias = []
    for posicao in posicoes:
        do_dia = agenda_por_dia.get(posicao.data, [])
        excecao = excecoes.get(posicao.data)
        dias.append(
            {
                "data": posicao.data,
                "dia": posicao.data.day,
                "hoje": posicao.data == hoje,
                "cor": posicao.cor,
                "tipo_dia": posicao.tipo_dia,
                "sem_limite_proprio": posicao.sem_limite_proprio and posicao.comprado <= ZERO,
                "capacidade": posicao.limite_efetivo,
                "comprado": posicao.comprado,
                "saldo_disponivel": posicao.saldo_do_dia,
                "qtde_compromissos": len(do_dia),
                "total_compromissos": sum((item.valor for item in do_dia), ZERO),
                "observacao": excecao.observacao if excecao else "",
            }
        )

    return {
        "dias": dias,
        "total_mes_compromissos": sum((item.valor for item in agenda), ZERO),
        "qtde_mes_compromissos": len(agenda),
    }


def detalhe_do_dia_financeiro(filial, dia: date, origem: str = "", pesquisa: str = "") -> dict:
    """Detalhe completo de um dia (clique no calendário): compras efetivadas,
    parcelamentos, contas fixas (folha/aluguel/impostos/demais), contas
    variáveis, provisões, total comprometido, saldo, capacidade, status e
    observações do Calendário Operacional."""
    posicao = motor_financeiro.posicao_do_dia(filial, dia)
    lancamentos = _filtrar_lancamentos(agenda_do_dia(filial, dia), origem, pesquisa)

    por_origem = defaultdict(list)
    for lancamento in lancamentos:
        por_origem[lancamento.origem].append(lancamento)

    compras = (
        Compra.objects.filter(filial=filial, data_compra=dia)
        .select_related("fornecedor", "usuario", "categoria")
        .order_by("-valor")
    )
    excecao = DiaOperacional.objects.filter(empresa=filial.empresa, data=dia).first()

    return {
        "data": dia,
        "posicao": posicao,
        "capacidade": posicao.limite_efetivo,
        "comprado": posicao.comprado,
        "saldo": posicao.saldo_do_dia,
        "cor": posicao.cor,
        "tipo_dia": posicao.tipo_dia,
        "sem_limite_proprio": posicao.sem_limite_proprio and posicao.comprado <= ZERO,
        "compras": compras,
        "parcelas": por_origem.get(ORIGEM_PARCELA, []),
        "contas_fixas": por_origem.get(ORIGEM_CONTA_FIXA, []),
        "contas_variaveis": por_origem.get(ORIGEM_CONTA_VARIAVEL, []),
        "provisoes": por_origem.get(ORIGEM_PROVISAO, []),
        "total_comprometido": sum((item.valor for item in lancamentos), ZERO),
        "observacao": excecao.observacao if excecao else "",
        "tipo_excecao": excecao.get_tipo_display() if excecao else "",
    }


def dias_da_semana_de(dias_do_mes: list[dict], dia_focal: date) -> list[dict]:
    """Fatia da semana (segunda a domingo) que contém `dia_focal`, limitada
    ao mês exibido — a visão semanal reaproveita o day-walk já calculado do
    mês em vez de recalcular posições atravessando meses."""
    segunda = dia_focal - timedelta(days=dia_focal.weekday())
    domingo = segunda + timedelta(days=6)
    return [dia for dia in dias_do_mes if segunda <= dia["data"] <= domingo]
