"""Testes da Análise Financeira (DRE Gerencial, Créditos × Débitos e Saúde
Financeira) — mudança de escopo: tudo lançado manualmente, sem ERP.

Cobre: contas da DRE com dados conhecidos (Decimal exato, receitas extras,
só compras aprovadas), números iguais aos do Motor/dashboard, consolidação
multi-filial, isolamento entre empresas, Gerente só nas filiais dele,
Comprador bloqueado (403, sem menu, sem widget, sem card, sem tour),
estado vazio (sistema de produção limpo), CSV, SVG sem NaN/None, HTML das 3
telas sem None/NaN, navegação (menu/breadcrumbs) e as recomendações por
regras fixas.

Rode com: python manage.py test financeiro.tests_analise
"""
import re
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.test import Client, SimpleTestCase, TestCase, override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor, ParcelaCompra
from core.permissions import PERFIS_ANALISE_FINANCEIRA
from dashboard.viewmodels import viewmodel_comprador
from empresas.models import Empresa
from filiais.models import Filial
from finance_engine.services import motor_financeiro
from usuarios.models import Usuario, UsuarioFilial

from . import graficos_svg
from .models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, Receita, ReceitaExtra
from .services import receita_da_empresa_no_mes
from .services_analise import (
    FONTES_REFERENCIA,
    REFERENCIAS_MERCADO,
    AnaliseFinanceira,
    classificar,
    montar_creditos_debitos,
    montar_dre,
    montar_saude,
    periodo_do_request,
    rotulo_mes_curto,
)

TERMOS_PROIBIDOS = ("None", "NaN", "Infinity", "Traceback (most recent", "Internal Server Error")
_CSRF = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')
URLS_ANALISE = ("/financeiro/analise/", "/financeiro/analise/creditos-debitos/", "/financeiro/analise/saude/")
ANO, MES = 2026, 8
Q = f"?ano={ANO}&mes={MES}"


def D(valor):
    return Decimal(valor)


class AnaliseBase(TestCase):
    """Empresa A com 2 filiais e números redondos em jul/ago de 2026 +
    empresa B (outro cliente) para o isolamento."""

    @classmethod
    def setUpTestData(cls):
        cls.empresa = Empresa.objects.create(nome="Farmácia Análise A", cnpj="61.000.000/0001-61")
        cls.f1 = Filial.objects.create(empresa=cls.empresa, nome="Loja Centro Análise")
        cls.f2 = Filial.objects.create(empresa=cls.empresa, nome="Loja Bairro Análise")
        ConfiguracaoFinanceira.objects.create(empresa=cls.empresa, percentual_compras=D("30"), dias_uteis_manual=20)
        cls.outra = Empresa.objects.create(nome="Farmácia Outro Cliente", cnpj="62.000.000/0001-62")
        cls.fb = Filial.objects.create(empresa=cls.outra, nome="Filial Sigilosa B")

        def usuario(username, perfil, empresa, filial):
            return Usuario.objects.create_user(
                username=username, password="Teste!2026Forte", perfil=perfil, empresa=empresa, filial=filial,
            )

        cls.proprietario = usuario("prop_analise", Usuario.Perfil.PROPRIETARIO, cls.empresa, None)
        cls.financeiro = usuario("fin_analise", Usuario.Perfil.FINANCEIRO, cls.empresa, cls.f1)
        UsuarioFilial.objects.create(usuario=cls.financeiro, filial=cls.f1)
        UsuarioFilial.objects.create(usuario=cls.financeiro, filial=cls.f2)
        cls.gerente = usuario("ger_analise", Usuario.Perfil.GERENTE, cls.empresa, cls.f1)
        cls.comprador = usuario("comp_analise", Usuario.Perfil.COMPRADOR, cls.empresa, cls.f1)
        cls.proprietario_b = usuario("prop_analise_b", Usuario.Perfil.PROPRIETARIO, cls.outra, None)

        cls.fornecedor = Fornecedor.objects.create(empresa=cls.empresa, nome="Distribuidora Análise")
        cls.medicamentos = Categoria.objects.create(empresa=cls.empresa, nome="Medicamentos")
        cls.perfumaria = Categoria.objects.create(empresa=cls.empresa, nome="Perfumaria")

        # Receitas: julho só na f1; agosto nas duas.
        Receita.objects.create(filial=cls.f1, mes=date(2026, 7, 1), faturamento=D("80000.00"))
        Receita.objects.create(filial=cls.f1, mes=date(2026, 8, 1), faturamento=D("100000.00"))
        Receita.objects.create(filial=cls.f2, mes=date(2026, 8, 1), faturamento=D("50000.00"))
        ReceitaExtra.objects.create(filial=cls.f1, data=date(2026, 8, 3), descricao="Aplicação de injetáveis",
                                    categoria=ReceitaExtra.Categoria.SERVICOS, valor=D("1500.50"))
        ReceitaExtra.objects.create(filial=cls.f1, data=date(2026, 8, 31), descricao="Repasse PBM",
                                    categoria=ReceitaExtra.Categoria.CONVENIOS, valor=D("499.50"))
        ReceitaExtra.objects.create(filial=cls.f1, data=date(2026, 7, 31), descricao="Rendimento julho",
                                    categoria=ReceitaExtra.Categoria.RENDIMENTOS, valor=D("7777.77"))
        # Custos fixos ativos (o Motor aplica a todo mês) + um inativo que não conta.
        CustoFixo.objects.create(filial=cls.f1, descricao="Aluguel", valor=D("10000.00"), dia_vencimento=10)
        CustoFixo.objects.create(filial=cls.f1, descricao="Folha de Pagamento", valor=D("20000.00"), dia_vencimento=5)
        CustoFixo.objects.create(filial=cls.f2, descricao="Aluguel", valor=D("5000.00"), dia_vencimento=10)
        CustoFixo.objects.create(filial=cls.f1, descricao="Contrato antigo", valor=D("999.99"), dia_vencimento=1,
                                 ativo=False)
        # Custos variáveis: 2 em agosto, 1 em setembro (fora).
        CustoVariavel.objects.create(filial=cls.f1, descricao="Campanha", valor=D("2000.00"), data_prevista=date(2026, 8, 20))
        CustoVariavel.objects.create(filial=cls.f2, descricao="Manutenção", valor=D("1000.00"), data_prevista=date(2026, 8, 10))
        CustoVariavel.objects.create(filial=cls.f1, descricao="Setembro", valor=D("333.33"), data_prevista=date(2026, 9, 1))

        def compra(filial, valor, dia, status, categoria):
            return Compra.objects.create(
                empresa=cls.empresa, filial=filial, fornecedor=cls.fornecedor, usuario=cls.comprador,
                valor=D(valor), categoria=categoria, data_compra=dia, status=status,
            )

        cls.c_ago_f1 = compra(cls.f1, "30000.00", date(2026, 8, 5), Compra.Status.APROVADA, cls.medicamentos)
        cls.c_pendente = compra(cls.f1, "9999.00", date(2026, 8, 6), Compra.Status.PENDENTE, cls.medicamentos)
        compra(cls.f1, "8888.00", date(2026, 8, 7), Compra.Status.REJEITADA, cls.medicamentos)
        cls.c_ago_f2 = compra(cls.f2, "12000.00", date(2026, 8, 8), Compra.Status.APROVADA, cls.perfumaria)
        compra(cls.f1, "20000.00", date(2026, 7, 10), Compra.Status.APROVADA, cls.medicamentos)

        # Parcelas (visão de caixa por vencimento).
        ParcelaCompra.objects.create(compra=cls.c_ago_f1, numero=1, data_vencimento=date(2026, 8, 20),
                                     valor=D("15000.00"), status=ParcelaCompra.Status.PAGA)
        ParcelaCompra.objects.create(compra=cls.c_ago_f1, numero=2, data_vencimento=date(2026, 9, 20),
                                     valor=D("15000.00"))
        ParcelaCompra.objects.create(compra=cls.c_ago_f1, numero=3, data_vencimento=date(2026, 8, 25),
                                     valor=D("500.00"), status=ParcelaCompra.Status.CANCELADA)
        ParcelaCompra.objects.create(compra=cls.c_ago_f2, numero=1, data_vencimento=date(2026, 8, 30),
                                     valor=D("12000.00"))
        # Parcela de compra PENDENTE (não deveria existir; se existir, não conta).
        ParcelaCompra.objects.create(compra=cls.c_pendente, numero=1, data_vencimento=date(2026, 8, 15),
                                     valor=D("9999.00"))

        # Empresa B: valores que NUNCA podem aparecer para a empresa A.
        Receita.objects.create(filial=cls.fb, mes=date(2026, 8, 1), faturamento=D("7777777.00"))
        CustoFixo.objects.create(filial=cls.fb, descricao="Aluguel sigiloso B", valor=D("4321.00"), dia_vencimento=3)

    def client_de(self, usuario):
        client = Client()
        client.force_login(usuario)
        return client

    def html_limpo(self, resposta, esperado=200):
        self.assertEqual(resposta.status_code, esperado)
        html = resposta.content.decode("utf-8")
        varredura = _CSRF.sub(r"\1\2", html)
        for termo in TERMOS_PROIBIDOS:
            self.assertNotIn(termo, varredura, f"termo proibido '{termo}' no HTML")
        return html


# ---------------------------------------------------------------------------
# DRE — contas exatas
# ---------------------------------------------------------------------------

class DreContasTestCase(AnaliseBase):
    def test_dre_consolidada_com_valores_exatos(self):
        dre = AnaliseFinanceira([self.f1, self.f2]).dre(ANO, MES)
        self.assertEqual(dre.receita_mensal, D("150000.00"))
        self.assertEqual(dre.receitas_extras, D("2000.00"))
        self.assertEqual(dre.extras_por_categoria["servicos"], D("1500.50"))
        self.assertEqual(dre.extras_por_categoria["convenios"], D("499.50"))
        self.assertEqual(dre.extras_por_categoria["rendimentos"], D("0"))
        self.assertEqual(dre.receita_total, D("152000.00"))
        # Só a compra APROVADA entra (pendente 9.999 e rejeitada 8.888 fora).
        self.assertEqual(dre.compras, D("42000.00"))
        self.assertEqual(dre.compras_quantidade, 2)
        self.assertEqual(dre.margem_bruta, D("110000.00"))
        self.assertEqual(dre.custos_variaveis, D("3000.00"))
        self.assertEqual(dre.margem_contribuicao, D("107000.00"))
        self.assertEqual(dre.custos_fixos, D("35000.00"))  # inativo 999,99 fora
        self.assertEqual(dre.resultado, D("72000.00"))
        self.assertEqual(dre.pct(dre.resultado), D("47.4"))
        self.assertEqual(dict(dre.custos_fixos_detalhe), {"Folha de Pagamento": D("20000.00"), "Aluguel": D("15000.00")})

    def test_uma_filial_so(self):
        dre = AnaliseFinanceira([self.f1]).dre(ANO, MES)
        self.assertEqual(dre.receita_total, D("102000.00"))
        self.assertEqual(dre.compras, D("30000.00"))
        self.assertEqual(dre.custos_variaveis, D("2000.00"))
        self.assertEqual(dre.custos_fixos, D("30000.00"))
        self.assertEqual(dre.resultado, D("40000.00"))

    def test_numeros_iguais_aos_do_motor(self):
        dre = AnaliseFinanceira([self.f1, self.f2]).dre(ANO, MES)
        capacidades = [motor_financeiro.capacidade_do_mes(f, ANO, MES) for f in (self.f1, self.f2)]
        self.assertEqual(dre.receita_total, sum((c.faturamento for c in capacidades), D("0")))
        self.assertEqual(dre.receita_mensal, sum((c.receita_mensal for c in capacidades), D("0")))
        self.assertEqual(dre.receitas_extras, sum((c.receitas_extras for c in capacidades), D("0")))
        self.assertEqual(dre.custos_fixos, sum((c.custos_fixos for c in capacidades), D("0")))
        self.assertEqual(dre.custos_variaveis, sum((c.custos_variaveis for c in capacidades), D("0")))
        # Resultado = disponibilidade do Motor − compras aprovadas.
        self.assertEqual(dre.resultado, sum((c.disponibilidade for c in capacidades), D("0")) - dre.compras)
        # Detalhes fecham com os totais do Motor.
        self.assertEqual(sum((v for _, v in dre.custos_fixos_detalhe), D("0")), dre.custos_fixos)
        self.assertEqual(sum((v for _, v in dre.custos_variaveis_detalhe), D("0")), dre.custos_variaveis)
        self.assertEqual(sum(dre.extras_por_categoria.values(), D("0")), dre.receitas_extras)

    def test_numeros_iguais_ao_dashboard_do_proprietario_no_mes(self):
        hoje = date.today()
        Receita.objects.create(filial=self.f1, mes=hoje.replace(day=1), faturamento=D("61000.00"))
        ReceitaExtra.objects.create(filial=self.f2, data=hoje, descricao="Extra de hoje", valor=D("250.25"))
        resposta = self.client_de(self.proprietario).get("/")
        widget = resposta.context["resultado_mes"]
        kpis = resposta.context["kpis"]
        dre = AnaliseFinanceira([self.f1, self.f2]).dre(hoje.year, hoje.month)
        self.assertEqual(widget["receita"], kpis["faturamento_mes"])
        self.assertEqual(widget["receita"], receita_da_empresa_no_mes(self.empresa, hoje.year, hoje.month)["total"])
        self.assertEqual(widget["receita"], dre.receita_total)
        self.assertEqual(widget["resultado"], dre.resultado)
        self.assertEqual(widget["despesas"], dre.despesas_totais)

    def test_linhas_mes_anterior_variacao_e_media(self):
        dados = montar_dre(AnaliseFinanceira([self.f1, self.f2]), ANO, MES)
        linhas = {linha["chave"]: linha for linha in dados["linhas"]}
        # Julho: 80.000 + 7.777,77 de receita; 20.000 de compras; 35.000 de fixos.
        self.assertEqual(linhas["receita_total"]["anterior"], D("87777.77"))
        self.assertEqual(linhas["resultado"]["anterior"], D("32777.77"))
        self.assertEqual(linhas["resultado"]["variacao"], D("39222.23"))
        self.assertEqual(linhas["resultado"]["media"], D("52388.89"))  # (72.000 + 32.777,77) / 2
        self.assertEqual(linhas["compras"]["classe_variacao"], "an-var-ruim")  # compras subiram
        self.assertEqual(linhas["resultado"]["classe_variacao"], "an-var-boa")
        self.assertEqual(dados["meses_com_receita"], 2)
        self.assertEqual(linhas["resultado"]["atual_fmt"], "R$ 72.000,00")
        self.assertIn("lucro", linhas["resultado"]["rotulo"])

    def test_meses_antes_do_primeiro_lancamento_nao_entram_na_curva(self):
        analise = AnaliseFinanceira([self.f1, self.f2])
        self.assertEqual(analise.primeiro_mes_com_dados(), (2026, 7))
        self.assertEqual(analise.janela(ANO, MES), [(2026, 7), (2026, 8)])
        dados = montar_dre(analise, 2026, 7)
        self.assertIsNone(dados["anterior"])  # junho: sem lançamentos
        self.assertEqual(dados["linhas"][0]["anterior_fmt"], "—")


# ---------------------------------------------------------------------------
# Escopo: consolidação, Gerente e isolamento entre empresas
# ---------------------------------------------------------------------------

class EscopoTestCase(AnaliseBase):
    def test_proprietario_consolida_e_filtra_por_filial(self):
        client = self.client_de(self.proprietario)
        self.assertEqual(client.get("/financeiro/analise/" + Q).context["dre"]["atual"].receita_total, D("152000.00"))
        uma = client.get(f"/financeiro/analise/{Q}&filial={self.f2.pk}").context["dre"]["atual"]
        self.assertEqual(uma.receita_total, D("50000.00"))
        self.assertEqual(uma.compras, D("12000.00"))

    def test_gerente_so_ve_a_propria_filial(self):
        client = self.client_de(self.gerente)
        dre = client.get("/financeiro/analise/" + Q).context["dre"]["atual"]
        self.assertEqual(dre.receita_total, D("102000.00"))
        # Filial não autorizada na querystring é ignorada (continua só a dele).
        dre = client.get(f"/financeiro/analise/{Q}&filial={self.f2.pk}").context["dre"]["atual"]
        self.assertEqual(dre.receita_total, D("102000.00"))
        html = self.html_limpo(client.get(f"/financeiro/analise/{Q}"))
        self.assertNotIn("Loja Bairro Análise", html)

    def test_isolamento_entre_empresas(self):
        client = self.client_de(self.proprietario)
        for url in URLS_ANALISE:
            resposta = client.get(f"{url}{Q}&filial={self.fb.pk}")
            html = self.html_limpo(resposta)
            for vazamento in ("7.777.777", "Filial Sigilosa B", "Aluguel sigiloso B", "4.321,00"):
                self.assertNotIn(vazamento, html, f"{url}: {vazamento}")
        csv = client.get(f"/financeiro/analise/creditos-debitos/{Q}&filial={self.fb.pk}&formato=csv")
        self.assertNotIn("sigiloso", csv.content.decode("utf-8"))

        dre_b = self.client_de(self.proprietario_b).get("/financeiro/analise/" + Q).context["dre"]["atual"]
        self.assertEqual(dre_b.receita_total, D("7777777.00"))
        self.assertEqual(dre_b.compras, D("0"))

    def test_financeiro_com_duas_filiais_vinculadas(self):
        resposta = self.client_de(self.financeiro).get("/financeiro/analise/" + Q)
        self.assertEqual(resposta.context["dre"]["atual"].receita_total, D("152000.00"))
        self.assertEqual(len(resposta.context["filiais"]), 2)


# ---------------------------------------------------------------------------
# Créditos × Débitos
# ---------------------------------------------------------------------------

class CreditosDebitosTestCase(AnaliseBase):
    def test_caixa_do_mes(self):
        caixa = AnaliseFinanceira([self.f1, self.f2]).caixa(ANO, MES)
        self.assertEqual(caixa.creditos, D("152000.00"))
        self.assertEqual(caixa.parcelas_pagas, D("15000.00"))
        # Cancelada (500) e parcela de compra pendente (9.999) não contam;
        # a parcela de setembro (15.000) é do mês seguinte.
        self.assertEqual(caixa.parcelas_a_pagar, D("12000.00"))
        self.assertEqual(caixa.custos_fixos, D("35000.00"))
        self.assertEqual(caixa.custos_variaveis, D("3000.00"))
        self.assertEqual(caixa.debitos, D("65000.00"))
        self.assertEqual(caixa.saldo, D("87000.00"))

    def test_serie_saldo_acumulado_e_balancete_que_fecha(self):
        dados = montar_creditos_debitos(AnaliseFinanceira([self.f1, self.f2]), ANO, MES)
        self.assertEqual([linha["rotulo"] for linha in dados["tabela"]], ["jul/26", "ago/26"])
        self.assertEqual(dados["tabela"][0]["caixa"].saldo, D("52777.77"))  # 87.777,77 − 35.000
        self.assertEqual(dados["tabela"][1]["saldo_acumulado"], D("139777.77"))
        balancete = dados["balancete"]
        self.assertEqual(balancete["total_creditos"], dados["atual"].creditos)
        self.assertEqual(balancete["total_debitos"], dados["atual"].debitos)
        self.assertEqual(balancete["saldo"], D("87000.00"))
        self.assertEqual(balancete["maior_credito"]["conta"], "Receita de vendas (receita mensal)")
        self.assertEqual(balancete["maior_debito"]["conta"], "Folha de Pagamento")
        contas = {c["conta"]: c for g in balancete["grupos"] for c in g["contas"]}
        self.assertEqual(contas["Fornecedores — Medicamentos"]["debito"], D("15000.00"))
        self.assertEqual(contas["Fornecedores — Perfumaria"]["debito"], D("12000.00"))
        self.assertEqual(contas["Aluguel"]["debito"], D("15000.00"))
        self.assertEqual(contas["Receitas extras — Serviços farmacêuticos"]["credito"], D("1500.50"))

    def test_tela_destaca_maior_credito_e_debito(self):
        html = self.html_limpo(self.client_de(self.financeiro).get("/financeiro/analise/creditos-debitos/" + Q))
        self.assertIn("maior crédito", html)
        self.assertIn("maior débito", html)
        self.assertIn("R$ 65.000,00", html)
        self.assertIn("R$ 139.777,77", html)


# ---------------------------------------------------------------------------
# Saúde Financeira — semáforo e recomendações por regras fixas
# ---------------------------------------------------------------------------

class SaudeFinanceiraTestCase(TestCase):
    """Farmácia em dificuldade: compras 85% da receita, custos fixos 30%."""

    @classmethod
    def setUpTestData(cls):
        cls.empresa = Empresa.objects.create(nome="Farmácia em Alerta", cnpj="63.000.000/0001-63")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Loja Alerta")
        ConfiguracaoFinanceira.objects.create(empresa=cls.empresa, percentual_compras=D("40"), dias_uteis_manual=20)
        cls.financeiro = Usuario.objects.create_user(
            username="fin_alerta", password="x", perfil=Usuario.Perfil.FINANCEIRO, empresa=cls.empresa, filial=cls.filial,
        )
        cls.gerente = Usuario.objects.create_user(
            username="ger_alerta", password="x", perfil=Usuario.Perfil.GERENTE, empresa=cls.empresa, filial=cls.filial,
        )
        Receita.objects.create(filial=cls.filial, mes=date(2026, 8, 1), faturamento=D("100000.00"))
        CustoFixo.objects.create(filial=cls.filial, descricao="Folha de Pagamento", valor=D("20000.00"), dia_vencimento=5)
        CustoFixo.objects.create(filial=cls.filial, descricao="Aluguel", valor=D("10000.00"), dia_vencimento=10)
        fornecedor = Fornecedor.objects.create(empresa=cls.empresa, nome="Distribuidora Alerta")
        categoria = Categoria.objects.create(empresa=cls.empresa, nome="Medicamentos")
        Compra.objects.create(
            empresa=cls.empresa, filial=cls.filial, fornecedor=fornecedor, usuario=cls.financeiro,
            valor=D("85000.00"), categoria=categoria, data_compra=date(2026, 8, 12), status=Compra.Status.APROVADA,
        )

    def test_indicadores_ponto_de_equilibrio_e_semaforo(self):
        dados = montar_saude(AnaliseFinanceira([self.filial]), ANO, MES, usuario=self.financeiro, empresa=self.empresa)
        ind = {i["chave"]: i for i in dados["indicadores"]}
        self.assertEqual(ind["peso_compras"]["valor"], D("85.0"))
        self.assertEqual(ind["peso_compras"]["status"], "critico")
        self.assertEqual(ind["peso_custos_fixos"]["valor"], D("30.0"))
        self.assertEqual(ind["peso_custos_fixos"]["status"], "critico")
        self.assertEqual(ind["margem_bruta"]["valor"], D("15.0"))
        self.assertEqual(ind["margem_bruta"]["status"], "critico")
        self.assertEqual(ind["margem_operacional"]["valor"], D("-15.0"))
        self.assertEqual(ind["margem_operacional"]["status"], "critico")
        # PE = custos fixos ÷ margem de contribuição (15%) = 200.000
        self.assertEqual(dados["ponto_equilibrio"], D("200000.00"))
        self.assertEqual(ind["margem_seguranca"]["valor"], D("-100.0"))

    def test_recomendacoes_quantificadas_com_links(self):
        dados = montar_saude(AnaliseFinanceira([self.filial]), ANO, MES, usuario=self.financeiro, empresa=self.empresa)
        textos = " ".join(r["texto"] for r in dados["recomendacoes"])
        self.assertIn("prejuízo de R$ 15.000,00", textos)
        self.assertIn("faltam R$ 100.000,00 de receita por mês", textos)
        self.assertIn("ponto de equilíbrio: R$ 200.000,00", textos)
        self.assertIn("reduzir R$ 15.000,00 de custos fixos", textos)
        self.assertIn("As compras consumiram 85,0% da receita", textos)
        self.assertIn("R$ 12.000,00 a menos em compras", textos)
        self.assertIn("hoje 40% da disponibilidade vai para compras", textos)
        self.assertIn("reduzir R$ 9.000,00 de custos fixos ou aumentar a receita em R$ 42.857,14", textos)
        self.assertIn("“Folha de Pagamento”", textos)
        self.assertEqual(dados["recomendacoes"][0]["nivel"], "critico")
        urls = {link["url"] for r in dados["recomendacoes"] for link in r["links"]}
        self.assertTrue({"/financeiro/custos-fixos/", "/financeiro/configuracao/", "/financeiro/capacidade-compradores/"} <= urls)

        html = self.client_de(self.financeiro).get("/financeiro/analise/saude/" + Q).content.decode("utf-8")
        self.assertIn("não é inteligência artificial", html)
        self.assertNotIn(">IA<", html)

    def test_gerente_ve_recomendacoes_sem_links_que_dariam_403(self):
        client = Client()
        client.force_login(self.gerente)
        resposta = client.get("/financeiro/analise/saude/" + Q)
        self.assertEqual(resposta.status_code, 200)
        html = resposta.content.decode("utf-8")
        self.assertIn("faltam R$ 100.000,00 de receita por mês", html)
        for proibido in ('href="/financeiro/custos-fixos/"', 'href="/financeiro/configuracao/"',
                         'href="/financeiro/capacidade-compradores/"', 'href="/financeiro/receitas/nova/"'):
            self.assertNotIn(proibido, html)
        for url in ("/financeiro/custos-fixos/", "/financeiro/configuracao/", "/financeiro/capacidade-compradores/"):
            self.assertEqual(client.get(url).status_code, 403)  # por isso nenhum link

    def test_comprometimento_futuro_com_parcelas(self):
        hoje = date.today()
        Receita.objects.create(filial=self.filial, mes=hoje.replace(day=1), faturamento=D("10000.00"))
        compra = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=Fornecedor.objects.get(empresa=self.empresa),
            usuario=self.financeiro, valor=D("60000.00"), categoria=Categoria.objects.get(empresa=self.empresa),
            data_compra=hoje, status=Compra.Status.APROVADA,
        )
        ParcelaCompra.objects.create(compra=compra, numero=1, data_vencimento=hoje + timedelta(days=10), valor=D("60000.00"))
        ParcelaCompra.objects.create(compra=compra, numero=2, data_vencimento=hoje + timedelta(days=45), valor=D("0.01"))
        analise = AnaliseFinanceira([self.filial], hoje)
        self.assertEqual(analise.parcelas_a_vencer(30), D("60000.00"))
        self.assertEqual(analise.parcelas_a_vencer(60), D("60000.01"))
        dados = montar_saude(analise, hoje.year, hoje.month, usuario=self.financeiro, empresa=self.empresa)
        # 60.000 a vencer em 30 dias contra uma receita média de no máximo 55.000.
        self.assertEqual(dados["comprometimento"]["status"], "critico")
        textos = " ".join(r["texto"] for r in dados["recomendacoes"])
        self.assertIn("As parcelas a vencer nos próximos 30 dias (R$ 60.000,00)", textos)

    def client_de(self, usuario):
        client = Client()
        client.force_login(usuario)
        return client


class ReferenciasDeMercadoTestCase(SimpleTestCase):
    def test_referencias_tem_fonte_documentada(self):
        for chave, referencia in REFERENCIAS_MERCADO.items():
            self.assertTrue(referencia["fontes"], chave)
            for fonte in referencia["fontes"]:
                self.assertIn(fonte, FONTES_REFERENCIA)
            self.assertIn(referencia["sentido"], ("maior", "menor"))
        self.assertIn("27,7%", FONTES_REFERENCIA["rd"]["resumo"])
        self.assertIn("sem fonte setorial", FONTES_REFERENCIA["nexbuy"]["resumo"])

    def test_classificacao_nas_bordas(self):
        self.assertEqual(classificar("margem_bruta", D("27")), "bom")
        self.assertEqual(classificar("margem_bruta", D("26.9")), "atencao")
        self.assertEqual(classificar("margem_bruta", D("19.9")), "critico")
        self.assertEqual(classificar("peso_compras", D("73")), "bom")
        self.assertEqual(classificar("peso_compras", D("80")), "atencao")
        self.assertEqual(classificar("peso_compras", D("80.1")), "critico")
        self.assertEqual(classificar("margem_operacional", D("-0.1")), "critico")
        self.assertEqual(classificar("margem_operacional", None), "sem_dado")

    def test_periodo_do_request_resiste_a_ano_com_separador(self):
        hoje = date(2026, 9, 25)
        self.assertEqual(periodo_do_request({"ano": "2.026", "mes": "8"}, hoje), (2026, 8))
        self.assertEqual(periodo_do_request({"ano": "abc", "mes": "8"}, hoje), (2026, 9))
        self.assertEqual(periodo_do_request({"ano": "2026", "mes": "13"}, hoje), (2026, 9))
        self.assertEqual(rotulo_mes_curto(2026, 9), "set/26")


# ---------------------------------------------------------------------------
# Gráficos SVG
# ---------------------------------------------------------------------------

class GraficosSvgTestCase(SimpleTestCase):
    INVALIDOS = ("NaN", "nan", "None", "inf", "Infinity")

    def assert_svg_valido(self, svg):
        self.assertTrue(svg.startswith("<svg"), svg[:40])
        self.assertTrue(svg.endswith("</svg>"))
        self.assertIn('role="img"', svg)
        self.assertIn("aria-label=", svg)
        numeros = " ".join(re.findall(r'(?:[xy][12]?|cx|cy|r|d|width|height)="([^"]*)"', svg))
        for termo in self.INVALIDOS:
            self.assertNotIn(termo, numeros)
            self.assertNotIn(f'"{termo}"', svg)
        self.assertNotIn("None", svg)
        self.assertNotIn("NaN", svg)

    def test_serie_toda_zero_gera_grafico_valido(self):
        svg = graficos_svg.grafico_linhas(
            [{"nome": "Receita", "classe": "s1", "valores": [D("0")] * 12}], [f"m{i}" for i in range(12)], titulo="Zero",
        )
        self.assert_svg_valido(svg)
        self.assertIn("<path", svg)

    def test_valores_ausentes_nan_e_vazio(self):
        series = [
            {"nome": "Receita", "classe": "s1", "valores": [None, D("NaN"), D("100.50"), None]},
            {"nome": "Resultado", "classe": "s3", "valores": [None, None, D("-50"), D("Infinity")]},
        ]
        self.assert_svg_valido(graficos_svg.grafico_linhas(series, ["a", "b", "c", "d"], titulo="Buracos"))
        self.assert_svg_valido(graficos_svg.grafico_linhas([], [], titulo="Vazio"))
        self.assert_svg_valido(graficos_svg.grafico_linhas(
            [{"nome": "Só um", "classe": "s1", "valores": [D("10")]}], ["set/26"], titulo="Um ponto", compacto=True))

    def test_barras_cascata_e_sparkline(self):
        self.assert_svg_valido(graficos_svg.grafico_barras_linha(
            ["jul/26", "ago/26"],
            [{"nome": "Créditos", "classe": "s1", "valores": [D("0"), D("1000")]},
             {"nome": "Débitos", "classe": "s2", "valores": [D("0"), None]}],
            {"nome": "Saldo", "classe": "s3", "valores": [D("0"), D("-500")]}, titulo="CD",
        ))
        self.assert_svg_valido(graficos_svg.grafico_barras_linha(["x"], [], None, titulo="Sem dados", compacto=True))
        etapas = [
            {"rotulo": "Receita", "tipo": "total", "valor": D("0")},
            {"rotulo": "Compras", "tipo": "reducao", "valor": D("0")},
            {"rotulo": "Resultado", "tipo": "subtotal", "valor": D("0")},
        ]
        self.assert_svg_valido(graficos_svg.grafico_cascata(etapas, titulo="Cascata zero"))
        self.assert_svg_valido(graficos_svg.grafico_cascata(etapas, titulo="Cascata zero", compacto=True))
        spark = graficos_svg.sparkline([None, D("10"), D("-5")], ["a", "b", "c"], titulo="Mini")
        self.assert_svg_valido(spark)
        self.assertEqual(graficos_svg.sparkline([None, None], ["a", "b"], titulo="Nada"), "")

    def test_cascata_escreve_o_valor_de_toda_barra_mesmo_ocupando_o_eixo_todo(self):
        """Críticos (rodada 2): a barra que ocupava quase todo o eixo (Receita
        total, margens; no celular, todas as principais) ficava SEM valor —
        o rótulo só ia para fora da barra e, sem espaço, não era desenhado."""
        import re

        etapas = [
            {"rotulo": "Receita total", "rotulo_curto": "Receita", "tipo": "total", "valor": D("287345.12")},
            {"rotulo": "Compras", "rotulo_curto": "Compras", "tipo": "reducao", "valor": D("1500")},
            {"rotulo": "Margem bruta", "rotulo_curto": "M. bruta", "tipo": "subtotal", "valor": None},
            {"rotulo": "Custos variáveis", "rotulo_curto": "C. variáveis", "tipo": "reducao", "valor": D("0")},
            {"rotulo": "Margem de contribuição", "rotulo_curto": "M. contrib.", "tipo": "subtotal", "valor": None},
            {"rotulo": "Custos fixos", "rotulo_curto": "C. fixos", "tipo": "reducao", "valor": D("58000")},
            {"rotulo": "Resultado operacional", "rotulo_curto": "Resultado", "tipo": "subtotal", "valor": None},
        ]
        for largura, compacto, esperados in (
            (720, False, ["R$ 287.345,12", "R$ 285.845,12", "R$ 227.845,12"]),
            (360, True, ["R$ 287 mil", "R$ 286 mil", "R$ 228 mil"]),
        ):
            svg = graficos_svg.grafico_cascata(etapas, titulo="Composição", largura=largura, compacto=compacto)
            self.assert_svg_valido(svg)
            valores = re.findall(r'<text class="an-valor[^"]*an-num"[^>]*>([^<]+)</text>', svg)
            self.assertEqual(len(valores), len(etapas), f"{largura}px: {valores}")
            for esperado in esperados:
                self.assertIn(esperado, valores, f"{largura}px")
            # Todo valor cabe dentro do desenho (nenhum x além da largura).
            for x, texto in re.findall(r'<text class="an-valor an-num" x="([\d.]+)"[^>]*>([^<]+)</text>', svg):
                self.assertLessEqual(float(x) + len(texto) * (14 if compacto else 12) * 0.56, largura, texto)

    def test_rotulos_em_pt_br_e_tooltip(self):
        svg = graficos_svg.grafico_linhas(
            [{"nome": "Receita total", "classe": "s1", "valores": [D("1234.56"), D("250000")]}],
            ["ago/26", "set/26"], rotulos_dica=["agosto/2026", "setembro/2026"], titulo="Curva",
        )
        self.assertIn("<title>agosto/2026 — Receita total: R$ 1.234,56</title>", svg)
        self.assertIn("R$ 250.000,00", svg)
        self.assertIn(">set/26<", svg)
        self.assertEqual(graficos_svg.formatar_brl(D("-1234.5")), "R$ -1.234,50")
        self.assertEqual(graficos_svg.formatar_brl_compacto(D("48000")), "R$ 48 mil")
        self.assertEqual(graficos_svg.formatar_brl_compacto(D("1250000")), "R$ 1,3 mi")

    def test_texto_dinamico_escapado(self):
        svg = graficos_svg.grafico_cascata(
            [{"rotulo": "<script>alert(1)</script>", "tipo": "total", "valor": D("10")}], titulo="A & B",
        )
        self.assertNotIn("<script>", svg)
        self.assertIn("A &amp; B", svg)


# ---------------------------------------------------------------------------
# Telas, CSV, estado vazio e o contrato do Comprador
# ---------------------------------------------------------------------------

class TelasTestCase(AnaliseBase):
    def test_tres_telas_sem_none_nan_para_os_tres_perfis(self):
        for usuario in (self.proprietario, self.financeiro, self.gerente):
            client = self.client_de(usuario)
            for url in URLS_ANALISE:
                for sufixo in (Q, "", "?ano=2026&mes=6", "?ano=2.026&mes=8"):
                    html = self.html_limpo(client.get(url + sufixo))
                    if sufixo == Q:  # mês com receita: as 3 telas têm gráfico
                        self.assertIn("<svg", html, f"{usuario.username} {url}{sufixo}")

    def test_links_de_mes_nunca_levam_ano_formatado(self):
        html = self.html_limpo(self.client_de(self.financeiro).get("/financeiro/analise/" + Q))
        self.assertIn("?ano=2026&amp;mes=7", html)
        self.assertIn("?ano=2026&amp;mes=9", html)
        self.assertNotRegex(html, r'href="[^"]*ano=2\.026')

    def test_dre_mostra_contas_e_percentuais(self):
        html = self.html_limpo(self.client_de(self.proprietario).get("/financeiro/analise/" + Q))
        for trecho in ("(+) Receita mensal (faturamento)", "Serviços farmacêuticos", "R$ 152.000,00",
                       "(−) Compras de mercadorias (aprovadas)", "R$ 42.000,00", "(=) Margem de contribuição",
                       "Folha de Pagamento", "R$ 72.000,00", "47,4%", "Composição do mês"):
            self.assertIn(trecho, html)

    def test_csv_da_dre(self):
        resposta = self.client_de(self.financeiro).get("/financeiro/analise/" + Q + "&formato=csv")
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("text/csv", resposta["Content-Type"])
        self.assertIn('filename="dre_gerencial_2026_08.csv"', resposta["Content-Disposition"])
        conteudo = resposta.content.decode("utf-8-sig")
        self.assertIn("(=) Receita total;152000,00;100,0;87777,77;64222,23;73,2;", conteudo)
        self.assertIn("(−) Compras de mercadorias (aprovadas);42000,00;27,6;20000,00", conteudo)
        self.assertIn("(=) Resultado operacional — lucro;72000,00;47,4;32777,77;39222,23;", conteudo)

    def test_csv_de_creditos_e_debitos(self):
        resposta = self.client_de(self.proprietario).get("/financeiro/analise/creditos-debitos/" + Q + "&formato=csv")
        conteudo = resposta.content.decode("utf-8-sig")
        self.assertIn("ago/26;150000,00;2000,00;152000,00;15000,00;12000,00;35000,00;3000,00;65000,00;87000,00;139777,77",
                      conteudo)
        self.assertIn("Balancete de ago/26", conteudo)
        self.assertIn("Totais;65000,00;152000,00", conteudo)

    def test_card_no_hub_de_relatorios(self):
        for usuario in (self.proprietario, self.financeiro, self.gerente):
            html = self.html_limpo(self.client_de(usuario).get("/relatorios/"))
            self.assertIn("Análise Financeira (DRE)", html)
            self.assertIn('href="/financeiro/analise/?formato=csv"', html)

    def test_widget_nos_dashboards_dos_tres_perfis(self):
        hoje = date.today()
        Receita.objects.create(filial=self.f1, mes=hoje.replace(day=1), faturamento=D("45678.90"))
        for usuario in (self.proprietario, self.financeiro):
            html = self.html_limpo(self.client_de(usuario).get("/"))
            self.assertIn('data-an-widget="resultado-mes"', html)
            self.assertIn("Ver análise completa", html)
            self.assertIn("R$ 45.678,90", html)
        resposta = self.client_de(self.gerente).get("/")
        html = self.html_limpo(resposta)
        self.assertIn('data-an-widget="resultado-mes"', html)
        # REGRA MUDOU (Correções de Produção — decisão explícita do usuário:
        # "a parte analítica fica para o Financeiro, o Gerente e o
        # Proprietário"; o Gerente VÊ os valores em R$ da análise). Antes
        # este teste exigia o widget do Gerente sem nenhum R$; agora o
        # widget dele mostra receita, despesas e resultado em R$, igual ao
        # do Proprietário/Financeiro (mesma fonte da DRE). O Comprador
        # continua sem nada disso — ver CompradorSemAcessoTestCase abaixo.
        widget_gerente = resposta.context["resultado_mes"]
        for chave in ("receita", "despesas", "resultado", "receita_fmt", "despesas_fmt", "resultado_fmt"):
            self.assertIn(chave, widget_gerente)
        self.assertTrue(widget_gerente["detalhar_valores"])
        self.assertEqual(widget_gerente["receita_fmt"], "R$ 45.678,90")
        trecho = html.split('data-an-widget="resultado-mes"', 1)[1].split("</table>", 1)[0]
        self.assertIn("R$ 45.678,90", trecho)
        self.assertIn("Margem", trecho)


class CompradorSemAcessoTestCase(AnaliseBase):
    def test_403_nas_tres_telas_e_no_csv(self):
        client = self.client_de(self.comprador)
        for url in URLS_ANALISE:
            self.assertEqual(client.get(url).status_code, 403, url)
            self.assertEqual(client.get(url + "?formato=csv").status_code, 403, url)

    def test_nada_da_analise_no_dashboard_menu_e_relatorios(self):
        client = self.client_de(self.comprador)
        resposta = client.get("/")
        html = self.html_limpo(resposta)
        for termo in ("Análise Financeira", "/financeiro/analise/", "Resultado do mês", "data-an-widget"):
            self.assertNotIn(termo, html)
        self.assertNotIn("resultado_mes", resposta.context)
        self.assertNotIn("resultado_mes", viewmodel_comprador(self.comprador))
        html = self.html_limpo(client.get("/relatorios/"))
        self.assertNotIn("Análise Financeira", html)
        for termo in ("Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal", "Meta Mensal"):
            self.assertNotIn(termo, self.html_limpo(client.get("/")))

    def test_tour_do_comprador_intacto_e_no_maximo_5_passos_por_perfil(self):
        js = (Path(settings.BASE_DIR) / "static" / "js" / "nexbuy.js").read_text(encoding="utf-8")
        bloco = js.split("var TOUR_STEPS_POR_PERFIL = {", 1)[1].split("};", 1)[0]
        perfis = dict(re.findall(r"(\w+): \[(.*?)\n    \]", bloco, flags=re.S))
        self.assertEqual(set(perfis), {"comprador", "gerente", "financeiro", "proprietario"})
        for perfil, passos in perfis.items():
            self.assertLessEqual(passos.count("{ titulo:"), 5, perfil)
        self.assertNotIn("/financeiro/analise/", perfis["comprador"])
        for perfil in ("gerente", "financeiro", "proprietario"):
            self.assertIn("/financeiro/analise/", perfis[perfil])


class EstadoVazioTestCase(TestCase):
    """Produção começa limpa: nenhum lançamento ainda."""

    @classmethod
    def setUpTestData(cls):
        cls.empresa = Empresa.objects.create(nome="Farmácia Recém-Implantada", cnpj="64.000.000/0001-64")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Matriz Nova")
        cls.financeiro = Usuario.objects.create_user(
            username="fin_vazio", password="x", perfil=Usuario.Perfil.FINANCEIRO, empresa=cls.empresa, filial=cls.filial,
        )
        cls.gerente = Usuario.objects.create_user(
            username="ger_vazio", password="x", perfil=Usuario.Perfil.GERENTE, empresa=cls.empresa, filial=cls.filial,
        )
        cls.sem_filial = Usuario.objects.create_user(
            username="fin_sem_filial", password="x", perfil=Usuario.Perfil.FINANCEIRO, empresa=cls.empresa, filial=None,
        )

    def get(self, usuario, url):
        client = Client()
        client.force_login(usuario)
        resposta = client.get(url)
        self.assertEqual(resposta.status_code, 200, url)
        html = _CSRF.sub(r"\1\2", resposta.content.decode("utf-8"))
        for termo in TERMOS_PROIBIDOS:
            self.assertNotIn(termo, html, f"{url}: {termo}")
        return html

    def test_estado_vazio_amigavel_nas_tres_telas(self):
        for url in URLS_ANALISE:
            html = self.get(self.financeiro, url)
            self.assertIn("Cadastre a receita do mês para ver a análise", html)
            self.assertIn('href="/financeiro/receitas/nova/"', html)
            html = self.get(self.gerente, url)
            self.assertIn("Peça ao Financeiro ou ao Proprietário", html)
            self.assertNotIn('href="/financeiro/receitas/nova/"', html)
        self.assertEqual(Client().get("/financeiro/analise/").status_code, 302)  # anônimo → login

    def test_csv_vazio_e_dashboards(self):
        client = Client()
        client.force_login(self.financeiro)
        self.assertEqual(client.get("/financeiro/analise/?formato=csv").status_code, 200)
        self.assertEqual(client.get("/financeiro/analise/creditos-debitos/?formato=csv").status_code, 200)
        html = self.get(self.financeiro, "/")
        self.assertIn("Cadastre a receita do mês para ver o resultado", html)
        self.get(self.gerente, "/")

    def test_usuario_sem_filial(self):
        for url in URLS_ANALISE:
            html = self.get(self.sem_filial, url)
            self.assertIn("Nenhuma filial vinculada", html)

    def test_mes_sem_receita_com_outros_lancamentos(self):
        CustoFixo.objects.create(filial=self.filial, descricao="Aluguel", valor=D("3000.00"), dia_vencimento=5)
        html = self.get(self.financeiro, "/financeiro/analise/")
        self.assertIn("ainda não foi lançada", html)
        html = self.get(self.financeiro, "/financeiro/analise/saude/")
        self.assertIn("Cadastre a receita do mês para ver a saúde financeira", html)


# ---------------------------------------------------------------------------
# Navegação (menu, estado ativo, breadcrumbs) — mesmo gate da view
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class NavegacaoAnaliseTestCase(AnaliseBase):
    def aside(self, html):
        return html.split('<aside class="nx-sidebar"', 1)[1].split("</aside>", 1)[0]

    def test_gate_do_menu_igual_ao_da_view(self):
        from core.navegacao import _estrutura_por_perfil

        estrutura = _estrutura_por_perfil()
        itens = []
        for entradas in estrutura.values():
            for entrada in entradas:
                if entrada.get("link_unico"):
                    itens.append(entrada)
                else:
                    itens.extend(entrada["itens"])
        analise = [i for i in itens if i["url_name"] == "financeiro:analise_dre"]
        self.assertEqual(len(analise), 3)  # Proprietário (no grupo), Financeiro e Gerente
        for item in analise:
            self.assertEqual(tuple(item["perfis"]), tuple(PERFIS_ANALISE_FINANCEIRA))
            self.assertIsNone(item["permissao"])
            self.assertEqual(item["icone"], "bi-graph-up-arrow")

    def test_proprietario_item_dentro_do_grupo_financeiro_ativo_nas_tres_telas(self):
        client = self.client_de(self.proprietario)
        html = client.get("/").content.decode("utf-8")
        aside = self.aside(html)
        self.assertEqual(aside.count("nx-nav-grupo-btn"), 5)  # continua com 6 entradas de 1º nível
        self.assertIn("Análise Financeira", aside)
        for url in URLS_ANALISE:
            html = client.get(url).content.decode("utf-8")
            self.assertRegex(html, r'aria-expanded="true"[^>]*aria-controls="nxGrupo-financeiro"', url)
            self.assertRegex(html, r'class="nx-nav-sublink active"[^>]*>\s*Análise Financeira', url)

    def test_financeiro_e_gerente_item_de_primeiro_nivel_ativo(self):
        padrao = (r'class="nx-nav-link active"[^>]*>\s*<i[^>]*bi-graph-up-arrow[^>]*></i>'
                  r'<span class="nx-nav-label">Análise Financeira')
        for usuario in (self.financeiro, self.gerente):
            client = self.client_de(usuario)
            for url in URLS_ANALISE:
                self.assertRegex(client.get(url).content.decode("utf-8"), padrao, f"{usuario.username} {url}")
        aside = self.aside(self.client_de(self.financeiro).get("/").content.decode("utf-8"))
        self.assertEqual(aside.count("nx-nav-grupo-btn"), 1)

    def test_breadcrumbs(self):
        client = self.client_de(self.gerente)
        casos = {
            "/financeiro/analise/": "DRE Gerencial",
            "/financeiro/analise/creditos-debitos/": "Créditos × Débitos",
            "/financeiro/analise/saude/": "Saúde Financeira",
        }
        for url, atual in casos.items():
            html = client.get(url).content.decode("utf-8")
            trecho = html.split('aria-label="Navegação estrutural"', 1)[1].split("</nav>", 1)[0]
            self.assertIn('href="/"', trecho)
            self.assertIn('href="/financeiro/analise/"', trecho)
            self.assertIn("Análise Financeira", trecho)
            self.assertRegex(trecho, r'aria-current="page">\s*<span>' + re.escape(atual))

    def test_comprador_sem_item_no_menu_nem_barra_mobile(self):
        html = self.client_de(self.comprador).get("/").content.decode("utf-8")
        self.assertNotIn("Análise Financeira", self.aside(html))
        self.assertNotIn("/financeiro/analise/", html)


class ReceitaZeradaTestCase(TestCase):
    """Receita mensal lançada com R$ 0,00: nada de divisão por zero, nada de
    recomendação absurda — a tela aponta o lançamento zerado."""

    @classmethod
    def setUpTestData(cls):
        cls.empresa = Empresa.objects.create(nome="Farmácia Receita Zero", cnpj="65.000.000/0001-65")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Loja Zero")
        cls.financeiro = Usuario.objects.create_user(
            username="fin_zero", password="x", perfil=Usuario.Perfil.FINANCEIRO, empresa=cls.empresa, filial=cls.filial,
        )
        Receita.objects.create(filial=cls.filial, mes=date(2026, 8, 1), faturamento=D("0"))
        CustoFixo.objects.create(filial=cls.filial, descricao="Aluguel", valor=D("3000.00"), dia_vencimento=5)

    def test_saude_com_receita_zerada(self):
        dados = montar_saude(AnaliseFinanceira([self.filial]), ANO, MES, usuario=self.financeiro, empresa=self.empresa)
        self.assertIsNone(dados["ponto_equilibrio"])
        self.assertEqual({i["status"] for i in dados["indicadores"]}, {"sem_dado"})
        self.assertEqual(len(dados["recomendacoes"]), 1)
        self.assertIn("receita lançada para o mês está zerada", dados["recomendacoes"][0]["texto"])
        client = Client()
        client.force_login(self.financeiro)
        for url in URLS_ANALISE:
            resposta = client.get(url + Q)
            self.assertEqual(resposta.status_code, 200)
            html = _CSRF.sub(r"\1\2", resposta.content.decode("utf-8"))
            for termo in TERMOS_PROIBIDOS:
                self.assertNotIn(termo, html, f"{url}: {termo}")


@override_settings(ALLOWED_HOSTS=["*"])
class CurvaComUmMesTestCase(TestCase):
    """Críticos (rodada 2): no 1º mês da cliente a curva da DRE virava 3
    pontos soltos (e, só com a receita lançada, o ponto da receita sumia
    debaixo do resultado) e Créditos × Débitos ficava com um par de barras e
    um ponto solto. Mesma regra da Saúde: com menos de 2 meses, sem curva,
    com aviso — a tabela continua."""

    def setUp(self):
        self.hoje = date.today()
        empresa = Empresa.objects.create(nome="Farmácia Primeiro Mês", cnpj="63.000.000/0001-63")
        self.filial = Filial.objects.create(empresa=empresa, nome="Matriz Primeiro Mês")
        ConfiguracaoFinanceira.objects.create(empresa=empresa, percentual_compras=D("30"), dias_uteis_manual=20)
        self.financeiro = Usuario.objects.create_user(
            username="fin_primeiro_mes", password="Teste!2026Forte", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=empresa, filial=self.filial,
        )
        Receita.objects.create(filial=self.filial, mes=self.hoje.replace(day=1), faturamento=D("150000.00"))
        CustoFixo.objects.create(filial=self.filial, descricao="Aluguel", valor=D("8000.00"), dia_vencimento=10)
        self.client = Client()
        self.client.force_login(self.financeiro)
        self.q = f"?ano={self.hoje.year}&mes={self.hoje.month}"

    def test_um_mes_sem_curva_com_aviso_e_tabela(self):
        dre = self.client.get("/financeiro/analise/" + self.q).content.decode()
        self.assertIn("data-an-curva-um-mes", dre)
        self.assertNotIn("an-svg-linhas", dre)
        self.assertIn('data-an-tabela="curva"', dre)
        self.assertIn("an-svg-cascata", dre)  # a composição do mês continua
        cd = self.client.get("/financeiro/analise/creditos-debitos/" + self.q).content.decode()
        self.assertIn("data-an-curva-um-mes", cd)
        self.assertNotIn("an-svg-barras", cd)
        self.assertIn('data-an-tabela="creditos-debitos"', cd)

    def test_com_dois_meses_a_curva_volta(self):
        anterior = (self.hoje.replace(day=1) - timedelta(days=1)).replace(day=1)
        Receita.objects.create(filial=self.filial, mes=anterior, faturamento=D("120000.00"))
        dre = self.client.get("/financeiro/analise/" + self.q).content.decode()
        self.assertNotIn("data-an-curva-um-mes", dre)
        self.assertIn("an-svg-linhas", dre)
        cd = self.client.get("/financeiro/analise/creditos-debitos/" + self.q).content.decode()
        self.assertNotIn("data-an-curva-um-mes", cd)
        self.assertIn("an-svg-barras", cd)


# ---------------------------------------------------------------------------
# Ajuste final (produto-e-demo): mês em andamento = resultado PARCIAL
# ---------------------------------------------------------------------------

class MesEmAndamentoTestCase(AnaliseBase):
    """O widget "Resultado do mês" (primeira tela da demo e dos dashboards
    de Proprietário, Gerente e Financeiro) sempre mostra o mês de hoje:
    receita do mês inteiro × compras só até hoje. Nas primeiras semanas o
    lucro saía com 25% a 50% de margem (meses fechados: alguns %) como
    resultado firme — `incompleto` só pegava a falta TOTAL de compras.
    Agora o mês de hoje é sempre parcial: aviso, rótulo "provisório",
    mini-curva só com meses fechados e o último mês fechado ao lado."""

    HOJE_AGOSTO = date(2026, 8, 10)  # agosto "em andamento"; julho fechado

    def test_widget_marca_o_mes_corrente_como_parcial_e_traz_o_mes_fechado(self):
        from django.template.loader import render_to_string

        from .services_analise import resumo_resultado_do_mes

        resumo = resumo_resultado_do_mes([self.f1, self.f2], self.proprietario, self.HOJE_AGOSTO)
        self.assertFalse(resumo["incompleto"])  # nada falta — ainda assim é parcial
        self.assertTrue(resumo["em_andamento"])
        self.assertEqual(resumo["parcial_ate_fmt"], "10/08")
        self.assertEqual(resumo["resultado_fmt"], "R$ 72.000,00")  # o número do mês continua o da DRE
        self.assertEqual(resumo["ultimo_fechado"]["rotulo_curto"], "jul/26")
        self.assertEqual(resumo["ultimo_fechado"]["resultado_fmt"], "R$ 32.777,77")
        self.assertEqual(resumo["ultimo_fechado"]["margem_fmt"], "37,3%")
        # A mini-curva só tem meses FECHADOS — agosto (o pico parcial) fica fora.
        self.assertEqual([p["rotulo"] for p in resumo["curva_tabela"]], ["jul/26"])
        self.assertTrue(resumo["curva_fechados"])

        html = render_to_string("financeiro/analise/_widget_resultado_mes.html", {"resultado": resumo})
        for termo in TERMOS_PROIBIDOS:
            self.assertNotIn(termo, html)
        self.assertIn("data-an-widget-parcial", html)
        self.assertIn("compras lançadas até 10/08; lucro e margem provisórios", html)
        self.assertIn("parcial, até 10/08", html)
        self.assertIn("data-an-widget-ultimo-fechado", html)
        self.assertIn("Mês fechado — jul/26", html)
        self.assertIn("R$ 32.777,77", html)
        self.assertIn("Resultado — mês fechado", html)
        self.assertNotIn("data-an-widget-incompleto", html)

        # Modo sem R$ (sem uso hoje): o mês fechado sai só com a margem.
        so_pct = resumo_resultado_do_mes([self.f1, self.f2], self.proprietario, self.HOJE_AGOSTO,
                                         somente_percentuais=True)
        self.assertNotIn("resultado_fmt", so_pct["ultimo_fechado"])
        html = render_to_string("financeiro/analise/_widget_resultado_mes.html", {"resultado": so_pct})
        self.assertNotIn("R$ 32.777,77", html)
        self.assertIn("37,3%", html)

    def test_sem_mes_fechado_a_curva_espera_o_primeiro_fechamento(self):
        from django.template.loader import render_to_string

        from .services_analise import resumo_resultado_do_mes

        resumo = resumo_resultado_do_mes([self.f1, self.f2], self.proprietario, date(2026, 7, 20))
        self.assertTrue(resumo["em_andamento"])
        self.assertIsNone(resumo["ultimo_fechado"])  # junho não teve lançamento
        self.assertEqual(resumo["curva_svg"], "")
        html = render_to_string("financeiro/analise/_widget_resultado_mes.html", {"resultado": resumo})
        self.assertIn("data-an-widget-curva-aguardando", html)
        self.assertIn("A curva dos meses fechados aparece quando julho/2026 fechar.", html)
        self.assertNotIn("data-an-widget-ultimo-fechado", html)

    def test_dre_do_mes_em_andamento_e_provisoria_e_do_mes_fechado_nao(self):
        analise = AnaliseFinanceira([self.f1, self.f2], self.HOJE_AGOSTO)
        dados = montar_dre(analise, ANO, MES)
        self.assertFalse(dados["lacunas"]["incompleto"])
        self.assertTrue(dados["lacunas"]["em_andamento"])
        self.assertTrue(dados["lacunas"]["provisorio"])
        linhas = {linha["chave"]: linha for linha in dados["linhas"]}
        self.assertEqual(linhas["resultado"]["rotulo"], "(=) Resultado operacional — provisório")
        parciais = [linha["rotulo"] for linha in dados["tabela_curva"] if linha["parcial"]]
        self.assertEqual(parciais, ["ago/26"])

        fechado = montar_dre(AnaliseFinanceira([self.f1, self.f2], date(2026, 9, 27)), ANO, MES)
        self.assertFalse(fechado["lacunas"]["em_andamento"])
        self.assertFalse(fechado["lacunas"]["provisorio"])
        linhas = {linha["chave"]: linha for linha in fechado["linhas"]}
        self.assertEqual(linhas["resultado"]["rotulo"], "(=) Resultado operacional — lucro")
        self.assertFalse(any(linha["parcial"] for linha in fechado["tabela_curva"]))

    def test_telas_do_mes_corrente_avisam_e_levam_ao_mes_fechado(self):
        hoje = date.today()
        Receita.objects.create(filial=self.f1, mes=hoje.replace(day=1), faturamento=D("90000.00"))
        Compra.objects.create(
            empresa=self.empresa, filial=self.f1, fornecedor=self.fornecedor, usuario=self.comprador,
            valor=D("5000.00"), categoria=self.medicamentos, data_compra=hoje, status=Compra.Status.APROVADA,
        )
        ano_ant, mes_ant = (hoje.year - 1, 12) if hoje.month == 1 else (hoje.year, hoje.month - 1)
        for usuario in (self.proprietario, self.financeiro, self.gerente):
            client = self.client_de(usuario)
            dre = self.html_limpo(client.get("/financeiro/analise/"))
            self.assertIn("data-an-aviso-parcial", dre, usuario.username)
            self.assertIn(f"com compras até {hoje:%d/%m}", dre)
            self.assertIn(f'href="/financeiro/analise/?ano={ano_ant}&amp;mes={mes_ant}"', dre)
            self.assertIn("(=) Resultado operacional — provisório", dre)
            self.assertIn(f"parcial: compras até {hoje:%d/%m}", dre)
            self.assertIn("data-an-curva-parcial", dre)
            saude = self.html_limpo(client.get("/financeiro/analise/saude/"))
            self.assertIn("data-an-aviso-parcial", saude, usuario.username)
            inicio = self.html_limpo(client.get("/"))
            widget = inicio.split('data-an-widget="resultado-mes"', 1)[1]
            self.assertIn("data-an-widget-parcial", widget, usuario.username)
            self.assertIn(f"compras lançadas até {hoje:%d/%m}", widget)
        # O mês fechado (agosto, visto de hoje) não tem aviso de parcial.
        fechado = self.html_limpo(self.client_de(self.financeiro).get("/financeiro/analise/" + Q))
        self.assertNotIn("data-an-aviso-parcial", fechado)
        self.assertNotIn("data-an-curva-parcial", fechado)
        # E o Comprador continua sem nada disso.
        html = self.html_limpo(self.client_de(self.comprador).get("/"))
        for termo in ("data-an-widget", "Resultado do mês", "compras lançadas até"):
            self.assertNotIn(termo, html)


class BemVindoSemAnaliseParaCompradorTestCase(AnaliseBase):
    """Ajuste final (produto-e-demo): o cartão do módulo já sumia para o
    Comprador, mas as descrições dos outros perfis em "Perfis disponíveis"
    (que o Comprador também vê) citavam a Análise Financeira."""

    def test_comprador_nao_ve_mencao_a_analise_e_os_demais_veem(self):
        html = self.html_limpo(self.client_de(self.comprador).get("/bem-vindo/"))
        self.assertIn("Perfis disponíveis", html)
        self.assertNotIn("Análise Financeira", html)
        self.assertNotIn("data-nx-modulo-analise", html)
        self.assertIn("efetiva as provisões aprovadas.", html)  # a frase continua inteira
        for usuario in (self.proprietario, self.gerente, self.financeiro):
            html = self.html_limpo(self.client_de(usuario).get("/bem-vindo/"))
            self.assertIn("consulta a Análise Financeira", html, usuario.username)
            self.assertIn("acompanha a Análise Financeira", html, usuario.username)
