"""Testes do app `empresas` (Sprint 6 — módulo Empresa e Identidade Visual).

Este app ainda não tinha nenhum teste automatizado.

Rode com: python manage.py test empresas
"""
import io
from decimal import Decimal

from django.contrib.messages import get_messages
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, TestCase
from django.test.utils import override_settings

from filiais.models import Filial
from usuarios.models import Usuario

from .models import Empresa, GrupoEmpresarial, IdentidadeVisual


class EmpresaFormViewTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste", cnpj="88.000.000/0001-88")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_teste", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.comprador = Usuario.objects.create_user(
            username="comp_teste", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_atualiza_dados_da_empresa(self):
        client = Client()
        client.force_login(self.proprietario)
        response = client.post("/empresas/", {
            "razao_social": "Empresa Teste Ltda",
            "nome": "Empresa Teste",
            "inscricao_estadual": "123.456.789",
            "telefone": "(65) 3333-0000",
            "email": "contato@teste.com.br",
            "endereco": "Rua Teste, 100",
            "cidade": "Cuiabá",
            "estado": "MT",
            "cep": "78000-000",
        })
        self.assertEqual(response.status_code, 302)

        self.empresa.refresh_from_db()
        self.assertEqual(self.empresa.razao_social, "Empresa Teste Ltda")
        self.assertEqual(self.empresa.cidade, "Cuiabá")
        self.assertEqual(self.empresa.estado, "MT")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_atualizar_dados_da_empresa_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        client = Client()
        client.force_login(self.proprietario)
        client.post("/empresas/", {
            "razao_social": "Empresa Teste Ltda Auditada",
            "nome": "Empresa Teste",
            "inscricao_estadual": "123.456.789",
            "telefone": "(65) 3333-0000",
            "email": "contato@teste.com.br",
            "endereco": "Rua Teste, 100",
            "cidade": "Cuiabá",
            "estado": "MT",
            "cep": "78000-000",
        })
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.EMPRESA_EDITADA, id_objeto=self.empresa.pk,
        )
        self.assertEqual(registro.estado_depois["razao_social"], "Empresa Teste Ltda Auditada")
        self.assertEqual(registro.usuario_id, self.proprietario.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_nao_acessa_dados_da_empresa(self):
        client = Client()
        client.force_login(self.comprador)
        response = client.get("/empresas/")
        self.assertEqual(response.status_code, 403)


class IdentidadeVisualTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste IV", cnpj="99.000.000/0001-99")
        self.proprietario = Usuario.objects.create_user(
            username="prop_iv", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def _imagem_teste(self, nome="logo.png"):
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow não instalado")
        buf = io.BytesIO()
        Image.new("RGB", (32, 32), color=(10, 20, 30)).save(buf, format="PNG")
        buf.seek(0)
        return SimpleUploadedFile(nome, buf.read(), content_type="image/png")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_upload_de_logo_cria_identidade_visual(self):
        client = Client()
        client.force_login(self.proprietario)
        response = client.post(
            "/empresas/identidade-visual/",
            {"nome_exibicao": "Nome Fantasia Teste", "cor_secundaria": "#123456", "logo": self._imagem_teste()},
        )
        self.assertEqual(response.status_code, 302)

        identidade = IdentidadeVisual.objects.get(empresa=self.empresa)
        self.assertEqual(identidade.nome_exibicao, "Nome Fantasia Teste")
        self.assertTrue(identidade.logo.name.endswith(".png"))
        identidade.logo.delete(save=False)

    def test_nome_para_exibicao_cai_no_nome_fantasia_quando_vazio(self):
        identidade = IdentidadeVisual.objects.create(empresa=self.empresa)
        self.assertEqual(identidade.nome_para_exibicao, self.empresa.nome)


class ConfiguracoesHomeTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Config", cnpj="77.111.000/0001-77")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_cfg", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.financeiro = Usuario.objects.create_user(
            username="fin_cfg", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="ger_cfg", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )

    # Épico 2A (Etapa 02): a landing /configuracoes/ deixou de existir — o
    # Centro de Configurações (/ncc/) é o hub único e a URL antiga virou
    # redirecionamento por perfil. Os testes abaixo validam o NOVO contrato
    # (atualizados junto com a mudança de especificação do épico).

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_redireciona_para_o_centro_de_configuracoes(self):
        client = Client()
        client.force_login(self.proprietario)
        response = client.get("/configuracoes/")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.headers["Location"], "/ncc/")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_financeiro_redireciona_para_o_planejamento(self):
        client = Client()
        client.force_login(self.financeiro)
        response = client.get("/configuracoes/")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.headers["Location"], "/financeiro/planejamento/")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_gerente_redireciona_para_o_dashboard(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.get("/configuracoes/")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.headers["Location"], "/")


class NccGestaoUsuariosTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, Parte 5): gestão de usuários sem
    depender do /admin — editar dados/perfil, ativar/desativar, gerar
    senha provisória — tudo auditado em LogConfiguracao."""

    def setUp(self):
        from .models import LogConfiguracao

        self.LogConfiguracao = LogConfiguracao
        self.empresa = Empresa.objects.create(nome="Empresa Teste NCC", cnpj="66.000.000/0001-66")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.filial2 = Filial.objects.create(empresa=self.empresa, nome="Filial 2")
        self.proprietario = Usuario.objects.create_user(
            username="prop_ncc", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.alvo = Usuario.objects.create_user(
            username="alvo_ncc", password="senha_antiga_123", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial, first_name="Pedro", email="pedro@antigo.com",
        )
        self.client = Client()
        self.client.force_login(self.proprietario)
        self.url = f"/ncc/usuarios/{self.alvo.pk}/"

    def _payload_dados_base(self, **overrides):
        base = {
            "first_name": "Pedro", "last_name": "Editado", "email": "pedro@novo.com",
            "perfil": Usuario.Perfil.FINANCEIRO, "filial": self.filial.pk, "is_active": "on",
            "salvar_dados": "1",
        }
        base.update(overrides)
        return base

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_nome_email_e_perfil(self):
        resposta = self.client.post(self.url, self._payload_dados_base())
        self.assertEqual(resposta.status_code, 302)
        self.alvo.refresh_from_db()
        self.assertEqual(self.alvo.last_name, "Editado")
        self.assertEqual(self.alvo.email, "pedro@novo.com")
        self.assertEqual(self.alvo.perfil, Usuario.Perfil.FINANCEIRO)
        self.assertTrue(
            self.LogConfiguracao.objects.filter(
                empresa=self.empresa, area="Usuários e Permissões", descricao__icontains="Dados de"
            ).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_perfil_gera_evento_proprio_na_central_de_auditoria(self):
        """Prompt 2, Gate D (Seção 9): mudança de perfil ganha categoria
        própria (`USUARIO_PERFIL_ALTERADO`), com antes/depois."""
        from auditoria.models import RegistroAuditoria

        self.client.post(self.url, self._payload_dados_base(perfil=Usuario.Perfil.FINANCEIRO))
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.USUARIO_PERFIL_ALTERADO, id_objeto=self.alvo.pk,
        )
        self.assertEqual(registro.estado_antes, {"perfil": Usuario.Perfil.COMPRADOR})
        self.assertEqual(registro.estado_depois, {"perfil": Usuario.Perfil.FINANCEIRO})
        self.assertEqual(registro.usuario_id, self.proprietario.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_desativar_usuario_gera_evento_de_status(self):
        from auditoria.models import RegistroAuditoria

        payload_desativado = self._payload_dados_base()
        del payload_desativado["is_active"]
        self.client.post(self.url, payload_desativado)
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.USUARIO_STATUS_ALTERADO, id_objeto=self.alvo.pk,
        )
        self.assertEqual(registro.estado_antes, {"is_active": True})
        self.assertEqual(registro.estado_depois, {"is_active": False})

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_alterar_vinculos_de_filial_gera_evento_de_permissoes(self):
        from auditoria.models import RegistroAuditoria

        self.client.post(
            self.url,
            {"salvar_permissoes": "1", "perfis_acesso": [], "permissoes_individuais": [],
             "empresas_autorizadas": [], "filiais_autorizadas": [self.filial.pk, self.filial2.pk],
             "limite_compra": ""},
        )
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.USUARIO_PERMISSOES_ALTERADAS, id_objeto=self.alvo.pk,
        )
        self.assertIn(self.filial2.nome, registro.estado_depois["filiais_adicionadas"])

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_usuario_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        resposta = self.client.post(
            "/ncc/usuarios/novo/",
            {"first_name": "Novo", "last_name": "Colega", "email": "novo@x.com", "username": "novo_colega_ncc",
             "filial": self.filial.pk, "perfil": Usuario.Perfil.COMPRADOR, "is_active": "on",
             "senha_inicial": "SenhaForte123"},
        )
        self.assertEqual(resposta.status_code, 302, resposta.context["form"].errors if resposta.status_code == 200 else "")
        criado = Usuario.objects.get(username="novo_colega_ncc")
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.USUARIO_CRIADO, id_objeto=criado.pk,
        )
        self.assertEqual(registro.estado_depois["username"], "novo_colega_ncc")
        self.assertEqual(registro.usuario_id, self.proprietario.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_desativar_e_reativar_usuario(self):
        payload_desativado = self._payload_dados_base()
        del payload_desativado["is_active"]  # checkbox desmarcado = ausente no POST
        resposta = self.client.post(self.url, payload_desativado)
        self.assertEqual(resposta.status_code, 302)
        self.alvo.refresh_from_db()
        self.assertFalse(self.alvo.is_active)

        resposta = self.client.post(self.url, self._payload_dados_base())
        self.assertEqual(resposta.status_code, 302)
        self.alvo.refresh_from_db()
        self.assertTrue(self.alvo.is_active)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_usuario_nao_pode_desativar_a_propria_conta(self):
        url_proprio = f"/ncc/usuarios/{self.proprietario.pk}/"
        payload = {
            "first_name": "Roberto", "last_name": "Dono", "email": "dono@x.com",
            "perfil": Usuario.Perfil.PROPRIETARIO, "salvar_dados": "1",
        }  # sem is_active — tentando se autodesativar
        resposta = self.client.post(url_proprio, payload)
        self.assertEqual(resposta.status_code, 200)  # form re-renderizado com erro, sem redirect
        self.proprietario.refresh_from_db()
        self.assertTrue(self.proprietario.is_active)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_gerar_senha_provisoria_troca_a_senha_de_verdade(self):
        resposta = self.client.post(self.url, {"gerar_senha": "1"})
        self.assertEqual(resposta.status_code, 302)

        mensagens = [str(m) for m in get_messages(resposta.wsgi_request)]
        self.assertTrue(any("Nova senha provisória" in m for m in mensagens))

        self.alvo.refresh_from_db()
        self.assertFalse(self.alvo.check_password("senha_antiga_123"))

        self.assertTrue(
            self.LogConfiguracao.objects.filter(
                empresa=self.empresa, area="Usuários e Permissões", descricao__icontains="senha provisória"
            ).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_form_de_permissoes_continua_funcionando_na_tela_com_multiplos_forms(self):
        """A tela agora tem 3 <form> distintos — o de permissões, que já
        existia antes desta Sprint, precisa continuar salvando."""
        from usuarios.models import UsuarioEmpresa

        resposta = self.client.post(
            self.url,
            {"salvar_permissoes": "1", "perfis_acesso": [], "permissoes_individuais": [],
             "empresas_autorizadas": [], "filiais_autorizadas": [self.filial.pk], "limite_compra": "1500.00"},
        )
        self.assertEqual(resposta.status_code, 302, resposta.context["form"].errors if resposta.status_code == 200 else "")
        autorizacao = UsuarioEmpresa.objects.get(usuario=self.alvo, empresa=self.empresa)
        self.assertEqual(autorizacao.limite_compra, Decimal("1500.00"))


class NccConfiguracoesSemEfeitoTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, Parte 9): tema/idioma/fuso horário/
    horário de abertura/horário de fechamento não têm nenhum efeito real
    no sistema hoje (investigado e confirmado por auditoria de código) —
    precisam ficar desabilitados, nunca "salvar" uma mudança que não
    acontece de verdade. `parcelas_maximas` é o único campo real."""

    def setUp(self):
        from empresas.models import ConfiguracaoPlataforma

        self.ConfiguracaoPlataforma = ConfiguracaoPlataforma
        self.empresa = Empresa.objects.create(nome="Empresa Teste NCC Gerais", cnpj="65.000.000/0001-65")
        self.proprietario = Usuario.objects.create_user(
            username="prop_ncc_gerais", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_campos_decorativos_nao_mudam_mesmo_enviados_no_post(self):
        config = self.ConfiguracaoPlataforma.objects.create(empresa=self.empresa)
        self.assertEqual(config.tema, self.ConfiguracaoPlataforma.Tema.PADRAO)
        self.assertEqual(config.fuso_horario, "America/Cuiaba")

        resposta = self.client.post("/ncc/gerais/", {
            "tema": self.ConfiguracaoPlataforma.Tema.CLARO,
            "idioma": self.ConfiguracaoPlataforma.Idioma.PT_BR,
            "fuso_horario": "America/Sao_Paulo",
            "horario_abertura": "08:00",
            "horario_fechamento": "18:00",
            "parcelas_maximas": "6",
        })
        self.assertEqual(resposta.status_code, 302)

        config.refresh_from_db()
        # Os 5 campos "Em breve" continuam exatamente como estavam — o
        # POST tentou mudá-los, mas o form os ignora (disabled=True).
        self.assertEqual(config.tema, self.ConfiguracaoPlataforma.Tema.PADRAO)
        self.assertEqual(config.fuso_horario, "America/Cuiaba")
        self.assertIsNone(config.horario_abertura)
        # O único campo real muda de verdade.
        self.assertEqual(config.parcelas_maximas, 6)


class NccAutoaprovacaoControladaConfigTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 6: ligar a autoaprovação
    controlada precisa de justificativa explícita, e a mudança fica
    registrada em `LogConfiguracao` para auditoria."""

    def setUp(self):
        from empresas.models import ConfiguracaoPlataforma, LogConfiguracao

        self.ConfiguracaoPlataforma = ConfiguracaoPlataforma
        self.LogConfiguracao = LogConfiguracao
        self.empresa = Empresa.objects.create(nome="Empresa Autoaprovacao Config", cnpj="62.000.000/0001-62")
        self.proprietario = Usuario.objects.create_user(
            username="prop_autoaprovacao_config", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)

    def _payload(self, **overrides):
        base = {"fuso_horario": "America/Cuiaba", "parcelas_maximas": "12"}
        base.update(overrides)
        return base

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_ligar_autoaprovacao_gera_evento_na_central_de_auditoria(self):
        """Prompt 2, Gate D (Seção 9): a mudança de autoaprovação chega
        TAMBÉM à Central de Auditoria (RegistroAuditoria), não só ao
        LogConfiguracao legado."""
        from auditoria.models import RegistroAuditoria

        self.client.post("/ncc/gerais/", self._payload(
            permitir_autoaprovacao="on", justificativa_autoaprovacao="Só eu decido aqui.",
        ))
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.AUTOAPROVACAO_ALTERADA, empresa=self.empresa,
        )
        self.assertEqual(registro.estado_antes, {"permitir_autoaprovacao": False})
        self.assertEqual(registro.estado_depois, {"permitir_autoaprovacao": True})
        self.assertEqual(registro.justificativa, "Só eu decido aqui.")
        self.assertEqual(registro.usuario_id, self.proprietario.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_ligar_sem_justificativa_e_erro(self):
        resposta = self.client.post("/ncc/gerais/", self._payload(permitir_autoaprovacao="on"))
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("justificativa_autoaprovacao", resposta.context["form"].errors)
        self.assertFalse(
            self.ConfiguracaoPlataforma.objects.filter(empresa=self.empresa, permitir_autoaprovacao=True).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_ligar_com_justificativa_funciona_e_fica_registrado_no_log(self):
        resposta = self.client.post("/ncc/gerais/", self._payload(
            permitir_autoaprovacao="on",
            justificativa_autoaprovacao="Somos só eu e minha sócia, não tem mais ninguém para aprovar.",
        ))
        self.assertEqual(resposta.status_code, 302)

        config = self.ConfiguracaoPlataforma.objects.get(empresa=self.empresa)
        self.assertTrue(config.permitir_autoaprovacao)
        self.assertEqual(
            config.justificativa_autoaprovacao, "Somos só eu e minha sócia, não tem mais ninguém para aprovar.",
        )

        log = self.LogConfiguracao.objects.filter(empresa=self.empresa, area="Configurações Gerais").latest(
            "criado_em"
        )
        self.assertIn("LIGADA", log.descricao)
        self.assertIn("não tem mais ninguém", log.descricao)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_desligar_nao_exige_justificativa(self):
        self.ConfiguracaoPlataforma.objects.create(
            empresa=self.empresa, permitir_autoaprovacao=True, justificativa_autoaprovacao="Motivo anterior.",
        )
        resposta = self.client.post("/ncc/gerais/", self._payload())  # sem permitir_autoaprovacao = desligando
        self.assertEqual(resposta.status_code, 302)

        config = self.ConfiguracaoPlataforma.objects.get(empresa=self.empresa)
        self.assertFalse(config.permitir_autoaprovacao)

        log = self.LogConfiguracao.objects.filter(empresa=self.empresa, area="Configurações Gerais").latest(
            "criado_em"
        )
        self.assertIn("DESLIGADA", log.descricao)


class PermissaoEmpresaGerenciarDelegavelTestCase(TestCase):
    """Revisão adversarial (Fechamento Final, Seção 4/6): `empresa.gerenciar`
    existia no catálogo de permissões mas as views de Empresa/Identidade
    Visual usavam `@perfil_required(PROPRIETARIO)` hardcoded — a permissão
    nunca tinha efeito real, mesmo concedida individualmente a outro
    perfil. Corrigido para `@permissao_required("empresa.gerenciar")`."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Permissao Delegavel", cnpj="63.000.000/0001-63")
        self.financeiro = Usuario.objects.create_user(
            username="fin_permissao_delegavel", password="x",
            perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_financeiro_sem_a_permissao_recebe_403(self):
        resposta = self.client.get("/empresas/")
        self.assertEqual(resposta.status_code, 403)
        resposta = self.client.get("/empresas/identidade-visual/")
        self.assertEqual(resposta.status_code, 403)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_financeiro_com_a_permissao_individual_acessa(self):
        from usuarios.models import Permissao

        self.financeiro.permissoes_individuais.add(Permissao.objects.get(codigo="empresa.gerenciar"))
        resposta = self.client.get("/empresas/")
        self.assertEqual(resposta.status_code, 200)
        resposta = self.client.get("/empresas/identidade-visual/")
        self.assertEqual(resposta.status_code, 200)


class NccFilialCrudTestCase(TestCase):
    """Sprint de Correções Críticas — Seções 6/19: cadastro de Filial é
    restrito ao Proprietário (`filiais.gerenciar`) e nunca acessível por
    ID de outra Empresa, mesmo por quem tem a permissão."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Filiais", cnpj="55.111.222/0001-55")
        self.empresa_outra = Empresa.objects.create(nome="Outra Empresa", cnpj="55.111.222/0002-55")
        self.filial_matriz = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.filial_da_outra = Filial.objects.create(empresa=self.empresa_outra, nome="Filial Intrusa")

        self.proprietario = Usuario.objects.create_user(
            username="dono_filiais", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.financeiro = Usuario.objects.create_user(
            username="fin_filiais", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial_matriz,
        )
        self.gerente = Usuario.objects.create_user(
            username="ger_filiais", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial_matriz,
        )
        self.comprador = Usuario.objects.create_user(
            username="comp_filiais", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial_matriz,
        )
        self.client = Client()

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_cadastra_filial_nova(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.post("/ncc/filiais/nova/", {"nome": "Filial Nova", "cidade": "Cuiabá", "ativo": "on"})
        self.assertEqual(resposta.status_code, 302, resposta.context["form"].errors if resposta.status_code == 200 else "")
        filial = Filial.objects.get(empresa=self.empresa, nome="Filial Nova")
        self.assertTrue(filial.ativo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_filial_criada_pela_tela_nasce_ativa_sem_o_campo_ativo_no_post(self):
        """Crítico funcional (rodada 1): a tela de criação NÃO renderiza o
        checkbox "Ativo" (só a edição), então o POST real chega sem o
        campo — e a filial nascia inativa, sumindo do cadastro de usuários.
        Agora nasce ativa e já aparece como opção de Filial do usuário."""
        self.client.force_login(self.proprietario)
        tela = self.client.get("/ncc/filiais/nova/")
        self.assertNotIn('name="ativo"', tela.content.decode())
        resposta = self.client.post("/ncc/filiais/nova/", {"nome": "Filial Centro"})
        self.assertEqual(resposta.status_code, 302, resposta.context["form"].errors if resposta.status_code == 200 else "")
        filial = Filial.objects.get(empresa=self.empresa, nome="Filial Centro")
        self.assertTrue(filial.ativo)
        lista = self.client.get("/ncc/filiais/").content.decode()
        linha = lista.split("Filial Centro", 1)[1].split("</tr>", 1)[0]
        self.assertNotIn("Inativa", linha)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_filial_ainda_permite_desativar(self):
        self.client.force_login(self.proprietario)
        filial = Filial.objects.create(empresa=self.empresa, nome="Filial Para Desativar")
        resposta = self.client.post(f"/ncc/filiais/{filial.pk}/", {"nome": "Filial Para Desativar"})
        self.assertEqual(resposta.status_code, 302)
        filial.refresh_from_db()
        self.assertFalse(filial.ativo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_financeiro_gerente_comprador_nao_cadastram_filial(self):
        """`filiais.gerenciar` é Proprietário-only por padrão (Seção 6) —
        os outros 3 perfis recebem 403, mesmo enviando dados válidos."""
        for usuario in (self.financeiro, self.gerente, self.comprador):
            with self.subTest(perfil=usuario.perfil):
                self.client.force_login(usuario)
                resposta = self.client.post(
                    "/ncc/filiais/nova/", {"nome": f"Filial de {usuario.username}", "cidade": "", "ativo": "on"}
                )
                self.assertEqual(resposta.status_code, 403)
        self.assertFalse(Filial.objects.filter(nome__startswith="Filial de").exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_acesso_por_id_a_filial_de_outra_empresa_e_404(self):
        """Mesmo o Proprietário — autorizado a gerenciar filiais — nunca
        alcança por ID a Filial de uma Empresa que não é a ativa dele."""
        self.client.force_login(self.proprietario)
        resposta = self.client.get(f"/ncc/filiais/{self.filial_da_outra.pk}/")
        self.assertEqual(resposta.status_code, 404)

        resposta_post = self.client.post(
            f"/ncc/filiais/{self.filial_da_outra.pk}/", {"nome": "Sequestrada", "cidade": "", "ativo": "on"}
        )
        self.assertEqual(resposta_post.status_code, 404)
        self.filial_da_outra.refresh_from_db()
        self.assertEqual(self.filial_da_outra.nome, "Filial Intrusa")


class NccFilialCadastroFiscalTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 4.4: Filial vira Estabelecimento
    fiscal completo, com busca e badge de "cadastro incompleto" na
    listagem do NCC."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Fiscal Filial", cnpj="56.111.222/0001-56")
        self.filial_incompleta = Filial.objects.create(empresa=self.empresa, nome="Loja Incompleta")
        self.filial_completa = Filial.objects.create(
            empresa=self.empresa, nome="Loja Completa", cnpj="11222333000181",
            razao_social="Loja Completa Comércio Ltda",
            isento_inscricao_estadual=True, endereco="Rua Y", numero="1", bairro="Centro", cidade="Cuiabá",
            estado="MT", cep="78000-000", telefone="(65) 3000-9999",
            responsavel_nome="Fulano de Tal", responsavel_telefone="(65) 99999-0000",
        )
        self.proprietario = Usuario.objects.create_user(
            username="dono_fiscal_filial", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_listagem_mostra_badge_completo_e_incompleto(self):
        resposta = self.client.get("/ncc/filiais/")
        self.assertContains(resposta, "Cadastro incompleto")
        self.assertContains(resposta, "Completo")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_busca_por_nome_filtra_a_listagem(self):
        resposta = self.client.get("/ncc/filiais/", {"q": "Incompleta"})
        self.assertContains(resposta, "Loja Incompleta")
        self.assertNotContains(resposta, "Loja Completa")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_busca_por_cnpj_com_mascara_encontra_a_filial(self):
        resposta = self.client.get("/ncc/filiais/", {"q": "11.222.333/0001-81"})
        self.assertContains(resposta, "Loja Completa")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_filial_com_todos_os_blocos_preenchidos(self):
        resposta = self.client.post("/ncc/filiais/nova/", {
            "nome": "Filial Fiscal Nova", "tipo_estabelecimento": "filial", "codigo_interno": "007",
            # CNPJ deliberadamente diferente do já usado por
            # self.filial_completa ("11.222.333/0001-81") — precisam ser
            # únicos globalmente.
            "cnpj": "98.765.432/0001-98", "inscricao_estadual": "123456789",
            "razao_social": "Filial Fiscal Nova Comércio Ltda",
            "endereco": "Av. Central", "numero": "500", "complemento": "Loja 2", "bairro": "Centro",
            "cidade": "Cuiabá", "estado": "MT", "cep": "78000-100",
            "telefone": "(65) 3000-0000", "email": "filial@nexbuy.com", "responsavel_nome": "Fulano de Tal",
            "responsavel_telefone": "(65) 99999-0000",
            "ativo": "on",
        })
        self.assertEqual(resposta.status_code, 302, resposta.context["form"].errors if resposta.status_code == 200 else "")
        filial = Filial.objects.get(empresa=self.empresa, nome="Filial Fiscal Nova")
        self.assertEqual(filial.cnpj, "98765432000198")
        self.assertEqual(filial.codigo_interno, "007")
        self.assertEqual(filial.responsavel_nome, "Fulano de Tal")
        self.assertTrue(filial.cadastro_completo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_filial_incompleta_completando_cadastro_atualiza_badge(self):
        resposta = self.client.post(f"/ncc/filiais/{self.filial_incompleta.pk}/", {
            "nome": "Loja Incompleta", "tipo_estabelecimento": "filial",
            # CNPJ diferente do já usado por self.filial_completa nesta
            # mesma classe (têm que ser únicos globalmente).
            "cnpj": "98.765.432/0001-98", "isento_inscricao_estadual": "on",
            "razao_social": "Loja Incompleta Comércio Ltda",
            "endereco": "Rua Z", "numero": "10", "bairro": "Centro", "cidade": "Cuiabá", "estado": "MT", "cep": "78000-200",
            "telefone": "(65) 98888-1000",
            "responsavel_nome": "Ciclana de Tal", "responsavel_telefone": "(65) 98888-0000",
            "ativo": "on",
        })
        self.assertEqual(
            resposta.status_code, 302,
            resposta.context["form"].errors if resposta.status_code == 200 else "",
        )
        self.filial_incompleta.refresh_from_db()
        self.assertTrue(self.filial_incompleta.cadastro_completo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_filial_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.post("/ncc/filiais/nova/", {
            "nome": "Filial Auditada Nova", "tipo_estabelecimento": "filial",
            "ativo": "on",
        })
        filial = Filial.objects.get(empresa=self.empresa, nome="Filial Auditada Nova")
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.FILIAL_CRIADA, id_objeto=filial.pk,
        )
        self.assertEqual(registro.filial, filial)
        self.assertEqual(registro.usuario, self.proprietario)
        self.assertEqual(registro.modulo, "filiais")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_filial_gera_evento_com_estado_antes_e_depois(self):
        from auditoria.models import RegistroAuditoria

        self.client.post(f"/ncc/filiais/{self.filial_incompleta.pk}/", {
            "nome": "Loja Incompleta Renomeada", "tipo_estabelecimento": "filial", "ativo": "on",
        })
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.FILIAL_EDITADA, id_objeto=self.filial_incompleta.pk,
        )
        self.assertEqual(registro.estado_antes.get("nome"), "Loja Incompleta")
        self.assertEqual(registro.estado_depois.get("nome"), "Loja Incompleta Renomeada")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_isento_e_ie_juntos_e_rejeitado_pela_view(self):
        resposta = self.client.post(f"/ncc/filiais/{self.filial_incompleta.pk}/", {
            "nome": "Loja Incompleta", "tipo_estabelecimento": "filial",
            "isento_inscricao_estadual": "on", "inscricao_estadual": "123456789",
            "ativo": "on",
        })
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("inscricao_estadual", resposta.context["form"].errors)


class EmpresasAutorizadasMesmoGrupoTestCase(TestCase):
    """Sprint de Correções Críticas — Seções 5/19: um Proprietário só pode
    autorizar usuários seus para Empresas do PRÓPRIO Grupo — nunca para
    uma empresa de outro cliente, mesmo manipulando o ID manualmente."""

    def setUp(self):
        from usuarios.models import UsuarioEmpresa

        from .forms_ncc import UsuarioPermissoesForm

        self.UsuarioPermissoesForm = UsuarioPermissoesForm
        self.UsuarioEmpresa = UsuarioEmpresa

        grupo = GrupoEmpresarial.objects.create(nome="Grupo Mesmo Dono")
        self.empresa_a = Empresa.objects.create(nome="Empresa A Grupo", cnpj="70.000.000/0001-70", grupo=grupo)
        self.empresa_b = Empresa.objects.create(nome="Empresa B Grupo", cnpj="70.000.000/0002-70", grupo=grupo)
        self.empresa_estranha = Empresa.objects.create(nome="Empresa de Outro Cliente", cnpj="80.000.000/0001-80")

        # Perfil PROPRIETARIO de propósito: esta classe testa exclusivamente
        # a fronteira de Grupo em `empresas_autorizadas` — independente do
        # perfil do alvo. Usar Proprietário evita acoplar estes testes à
        # regra, ortogonal, de "ao menos uma filial autorizada" (Fechamento
        # Final, Seção 4.1), que só vale para não-Proprietário.
        self.alvo = Usuario.objects.create_user(
            username="alvo_grupo", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa_a,
        )

    def test_queryset_do_form_nao_lista_empresa_de_outro_grupo(self):
        form = self.UsuarioPermissoesForm(usuario_alvo=self.alvo, empresa=self.empresa_a)
        queryset = form.fields["empresas_autorizadas"].queryset
        self.assertIn(self.empresa_b, queryset)
        self.assertNotIn(self.empresa_estranha, queryset)

    def test_clean_rejeita_id_manual_de_empresa_de_outro_grupo(self):
        """Defesa em profundidade: mesmo que o ID da empresa estranha seja
        submetido manualmente (fora das opções do <select>), o `clean`
        recusa — não confia só no queryset renderizado na tela."""
        form = self.UsuarioPermissoesForm(
            data={
                "empresas_autorizadas": [str(self.empresa_b.pk), str(self.empresa_estranha.pk)],
                "perfis_acesso": [], "permissoes_individuais": [], "limite_compra": "",
            },
            usuario_alvo=self.alvo, empresa=self.empresa_a,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("empresas_autorizadas", form.errors)

    def test_aplicar_nunca_grava_autorizacao_fora_do_grupo(self):
        """3ª camada de defesa: mesmo burlando o form inteiro (chamando
        `aplicar()` com dados já limpos manipulados), o service revalida
        antes de gravar no banco."""
        form = self.UsuarioPermissoesForm(
            data={
                "empresas_autorizadas": [str(self.empresa_b.pk)],
                "perfis_acesso": [], "permissoes_individuais": [], "limite_compra": "",
            },
            usuario_alvo=self.alvo, empresa=self.empresa_a,
        )
        self.assertTrue(form.is_valid())
        form.cleaned_data["empresas_autorizadas"] = Empresa.objects.filter(
            pk__in=[self.empresa_b.pk, self.empresa_estranha.pk]
        )
        form.aplicar()
        autorizadas = set(self.UsuarioEmpresa.objects.filter(usuario=self.alvo).values_list("empresa_id", flat=True))
        self.assertIn(self.empresa_b.pk, autorizadas)
        self.assertNotIn(self.empresa_estranha.pk, autorizadas)


class GestaoVinculosFilialNccTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 4.1: gestão real dos vínculos
    usuário-filial pela interface do NCC (`UsuarioPermissoesForm` +
    `UsuarioDadosForm`/`UsuarioNovoForm`), não mais só em memória via o
    fallback de `filiais_autorizadas_para`."""

    def setUp(self):
        from usuarios.models import UsuarioFilial

        self.UsuarioFilial = UsuarioFilial
        self.empresa = Empresa.objects.create(nome="Empresa Vinculos NCC", cnpj="71.000.000/0001-71")
        self.filial1 = Filial.objects.create(empresa=self.empresa, nome="Filial 1")
        self.filial2 = Filial.objects.create(empresa=self.empresa, nome="Filial 2")
        self.proprietario = Usuario.objects.create_user(
            username="prop_vinculos_ncc", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.alvo = Usuario.objects.create_user(
            username="alvo_vinculos_ncc", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial1,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)
        self.url = f"/ncc/usuarios/{self.alvo.pk}/"

    def _payload_permissoes(self, **overrides):
        base = {
            "salvar_permissoes": "1", "perfis_acesso": [], "permissoes_individuais": [],
            "empresas_autorizadas": [], "filiais_autorizadas": [self.filial1.pk], "limite_compra": "",
        }
        base.update(overrides)
        return base

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_selecionar_uma_segunda_filial_cria_vinculo_ativo(self):
        resposta = self.client.post(
            self.url, self._payload_permissoes(filiais_autorizadas=[self.filial1.pk, self.filial2.pk])
        )
        self.assertEqual(resposta.status_code, 302)
        self.assertTrue(
            self.UsuarioFilial.objects.filter(usuario=self.alvo, filial=self.filial2, ativo=True).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_remover_filial_da_selecao_desativa_sem_apagar(self):
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial1, ativo=True)
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial2, ativo=True)

        resposta = self.client.post(self.url, self._payload_permissoes(filiais_autorizadas=[self.filial1.pk]))
        self.assertEqual(resposta.status_code, 302)
        vinculo2 = self.UsuarioFilial.objects.get(usuario=self.alvo, filial=self.filial2)
        self.assertFalse(vinculo2.ativo)  # desativado, nunca apagado
        self.assertTrue(self.UsuarioFilial.objects.filter(pk=vinculo2.pk).exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_reselecionar_filial_reativa_o_mesmo_registro_sem_duplicar(self):
        vinculo = self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial2, ativo=False)

        resposta = self.client.post(
            self.url, self._payload_permissoes(filiais_autorizadas=[self.filial1.pk, self.filial2.pk])
        )
        self.assertEqual(resposta.status_code, 302)
        vinculo.refresh_from_db()
        self.assertTrue(vinculo.ativo)
        self.assertEqual(self.UsuarioFilial.objects.filter(usuario=self.alvo, filial=self.filial2).count(), 1)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_filial_de_empresa_nao_autorizada_e_rejeitada_no_backend(self):
        """"Uma filial de Empresa não autorizada nunca pode aparecer nem
        ser aceita em POST manipulado" (Seção 4.1)."""
        outra_empresa = Empresa.objects.create(nome="Outra Empresa Vinculos", cnpj="72.000.000/0001-72")
        filial_estranha = Filial.objects.create(empresa=outra_empresa, nome="Filial Estranha")

        resposta = self.client.post(
            self.url, self._payload_permissoes(filiais_autorizadas=[self.filial1.pk, filial_estranha.pk])
        )
        self.assertEqual(resposta.status_code, 200)  # form re-renderizado, nada salvo
        self.assertFalse(self.UsuarioFilial.objects.filter(usuario=self.alvo, filial=filial_estranha).exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_nao_proprietario_ativo_precisa_de_ao_menos_uma_filial(self):
        resposta = self.client.post(self.url, self._payload_permissoes(filiais_autorizadas=[]))
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("filiais_autorizadas", resposta.context["form"].errors)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_nao_proprietario_inativo_pode_ficar_sem_nenhuma_filial(self):
        """Revisão adversarial (Fechamento Final): a regra de "ao menos uma
        filial" só vale "enquanto o usuário estiver ativo" (Seção 4.1) —
        este carve-out nunca tinha sido testado, só o caminho ativo."""
        self.alvo.is_active = False
        self.alvo.save(update_fields=["is_active"])

        resposta = self.client.post(self.url, self._payload_permissoes(filiais_autorizadas=[]))
        self.assertEqual(resposta.status_code, 302)
        self.assertFalse(
            self.UsuarioFilial.objects.filter(usuario=self.alvo, ativo=True).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_nunca_precisa_de_filial_selecionada(self):
        url_proprietario = f"/ncc/usuarios/{self.proprietario.pk}/"
        resposta = self.client.post(url_proprietario, {
            "salvar_permissoes": "1", "perfis_acesso": [], "permissoes_individuais": [],
            "empresas_autorizadas": [], "filiais_autorizadas": [], "limite_compra": "",
        })
        self.assertEqual(resposta.status_code, 302)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_remover_a_filial_principal_promove_outra_automaticamente(self):
        """"Usuario.filial... deve necessariamente pertencer ao conjunto
        autorizado do usuário" (Seção 4.1) — se a principal sai da seleção,
        o service promove outra em vez de deixar `.filial` inconsistente."""
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial1, ativo=True)
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial2, ativo=True)
        self.assertEqual(self.alvo.filial_id, self.filial1.pk)

        resposta = self.client.post(self.url, self._payload_permissoes(filiais_autorizadas=[self.filial2.pk]))
        self.assertEqual(resposta.status_code, 302)
        self.alvo.refresh_from_db()
        self.assertEqual(self.alvo.filial_id, self.filial2.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_log_de_auditoria_lista_filiais_adicionadas_e_removidas(self):
        from .models import LogConfiguracao

        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial1, ativo=True)
        resposta = self.client.post(self.url, self._payload_permissoes(filiais_autorizadas=[self.filial2.pk]))
        self.assertEqual(resposta.status_code, 302)

        log = LogConfiguracao.objects.filter(empresa=self.empresa, area="Usuários e Permissões").latest("criado_em")
        self.assertIn("Filial 2", log.descricao)
        self.assertIn("Filial 1", log.descricao)

    def test_usuario_novo_ganha_vinculo_ativo_automaticamente(self):
        from .forms_ncc import UsuarioNovoForm

        form = UsuarioNovoForm(
            data={
                "first_name": "Novo", "last_name": "Usuario", "email": "novo@x.com",
                "username": "novo_vinculo_ncc", "filial": self.filial1.pk,
                "perfil": Usuario.Perfil.COMPRADOR, "is_active": "on", "senha_inicial": "senha12345",
            },
            empresa=self.empresa,
        )
        self.assertTrue(form.is_valid(), form.errors)
        usuario = form.save()
        self.assertTrue(
            self.UsuarioFilial.objects.filter(usuario=usuario, filial=self.filial1, ativo=True).exists()
        )

    def test_editar_filial_principal_via_dados_cria_vinculo_para_a_nova(self):
        from .forms_ncc import UsuarioDadosForm

        form = UsuarioDadosForm(
            data={
                "first_name": "Alvo", "last_name": "Editado", "email": "alvo@x.com",
                "perfil": Usuario.Perfil.COMPRADOR, "filial": self.filial2.pk, "is_active": "on",
            },
            instance=self.alvo, empresa=self.empresa,
        )
        self.assertTrue(form.is_valid(), form.errors)
        form.save()
        self.assertTrue(
            self.UsuarioFilial.objects.filter(usuario=self.alvo, filial=self.filial2, ativo=True).exists()
        )


class PromocaoFilialPrincipalNuncaCruzaEmpresaTestCase(TestCase):
    """Revisão adversarial (Fechamento Final): regressão para o bug
    confirmado em `UsuarioPermissoesForm.aplicar()` onde a promoção
    automática de `Usuario.filial` podia escolher uma filial de uma
    Empresa DIFERENTE de `Usuario.empresa`, quebrando o invariante
    `Usuario.filial.empresa == Usuario.empresa` que dashboard, context
    processor e gestão de compras assumem sem revalidar."""

    def setUp(self):
        from usuarios.models import UsuarioFilial

        from .forms_ncc import UsuarioPermissoesForm

        self.UsuarioFilial = UsuarioFilial
        self.UsuarioPermissoesForm = UsuarioPermissoesForm

        grupo = GrupoEmpresarial.objects.create(nome="Grupo Promocao Filial")
        self.empresa_a = Empresa.objects.create(nome="Empresa A Promocao", cnpj="73.000.000/0001-73", grupo=grupo)
        self.empresa_b = Empresa.objects.create(nome="Empresa B Promocao", cnpj="73.000.000/0002-73", grupo=grupo)
        self.filial_a1 = Filial.objects.create(empresa=self.empresa_a, nome="Filial A1")
        self.filial_b1 = Filial.objects.create(empresa=self.empresa_b, nome="Filial B1")

        self.alvo = Usuario.objects.create_user(
            username="alvo_promocao", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_a, filial=self.filial_a1,
        )
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial_a1, ativo=True)
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=self.filial_b1, ativo=True)

    def test_deselecionar_filial_principal_sem_candidata_na_mesma_empresa_e_erro_de_validacao(self):
        """Se a única filial que sobra pertence a OUTRA empresa (mesmo que
        autorizada), o form deve recusar — nunca promover silenciosamente
        `Usuario.filial` para fora de `Usuario.empresa`."""
        form = self.UsuarioPermissoesForm(
            data={
                "empresas_autorizadas": [str(self.empresa_b.pk)], "perfis_acesso": [],
                "permissoes_individuais": [], "limite_compra": "",
                "filiais_autorizadas": [str(self.filial_b1.pk)],
            },
            usuario_alvo=self.alvo, empresa=self.empresa_a,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("filiais_autorizadas", form.errors)

        self.alvo.refresh_from_db()
        self.assertEqual(self.alvo.empresa_id, self.empresa_a.pk)
        self.assertEqual(self.alvo.filial_id, self.filial_a1.pk)

    def test_promocao_so_escolhe_candidata_da_empresa_principal(self):
        """Com uma segunda filial válida NA MESMA empresa disponível, a
        promoção deve escolhê-la — nunca a de outra empresa, mesmo que
        seu nome viesse antes em ordem alfabética."""
        filial_a0 = Filial.objects.create(empresa=self.empresa_a, nome="Filial A0 Alfabetica")
        self.UsuarioFilial.objects.create(usuario=self.alvo, filial=filial_a0, ativo=True)

        form = self.UsuarioPermissoesForm(
            data={
                "empresas_autorizadas": [str(self.empresa_b.pk)], "perfis_acesso": [],
                "permissoes_individuais": [], "limite_compra": "",
                "filiais_autorizadas": [str(filial_a0.pk), str(self.filial_b1.pk)],
            },
            usuario_alvo=self.alvo, empresa=self.empresa_a,
        )
        self.assertTrue(form.is_valid(), form.errors)
        form.aplicar()

        self.alvo.refresh_from_db()
        self.assertEqual(self.alvo.filial_id, filial_a0.pk)
        self.assertEqual(self.alvo.empresa_id, self.empresa_a.pk)


class AutorizacaoLegadaForaDoGrupoNuncaEDesativadaPorEdicaoNaoRelacionadaTestCase(TestCase):
    """Revisão adversarial (Fechamento Final): regressão para o bug
    confirmado onde o loop de diferença de `empresas_autorizadas` em
    `aplicar()` usava a regra ESTRITA (`empresas_do_grupo()`) em vez da
    regra permissiva ("provavelmente grupos diferentes") usada em
    `Usuario.empresas_disponiveis()` — desativando, a cada save, uma
    autorização legada legítima (ambos os lados sem Grupo cadastrado)
    que nunca sequer aparece como opção marcável no formulário."""

    def setUp(self):
        from usuarios.models import UsuarioEmpresa

        from .forms_ncc import UsuarioPermissoesForm

        self.UsuarioEmpresa = UsuarioEmpresa
        self.UsuarioPermissoesForm = UsuarioPermissoesForm

        # Nenhuma das duas tem Grupo — replica o padrão legado de
        # autorização direta entre empresas, de antes do conceito de
        # Grupo Empresarial existir.
        self.empresa_x = Empresa.objects.create(nome="Empresa X Legado", cnpj="74.000.000/0001-74")
        self.empresa_y = Empresa.objects.create(nome="Empresa Y Legado", cnpj="74.000.000/0002-74")
        self.filial_x1 = Filial.objects.create(empresa=self.empresa_x, nome="Filial X1")

        self.alvo = Usuario.objects.create_user(
            username="alvo_legado", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_x, filial=self.filial_x1,
        )
        self.autorizacao_legada = self.UsuarioEmpresa.objects.create(
            usuario=self.alvo, empresa=self.empresa_y, ativo=True,
        )

    def test_editar_limite_de_compra_nao_desativa_autorizacao_legada(self):
        form = self.UsuarioPermissoesForm(
            data={
                "empresas_autorizadas": [], "perfis_acesso": [], "permissoes_individuais": [],
                "limite_compra": "1000.00", "filiais_autorizadas": [str(self.filial_x1.pk)],
            },
            usuario_alvo=self.alvo, empresa=self.empresa_x,
        )
        self.assertTrue(form.is_valid(), form.errors)
        form.aplicar()

        self.autorizacao_legada.refresh_from_db()
        self.assertTrue(self.autorizacao_legada.ativo)

    def test_empresa_estranha_nunca_aparece_como_opcao_do_form(self):
        """Confirma a premissa do bug: a empresa legada nunca é oferecida
        como opção — por isso o form nunca pode legitimamente "desmarcá-la"."""
        form = self.UsuarioPermissoesForm(usuario_alvo=self.alvo, empresa=self.empresa_x)
        self.assertNotIn(self.empresa_y, form.fields["empresas_autorizadas"].queryset)


class NccUsuarioEditarCrossEmpresaTestCase(TestCase):
    """Revisão adversarial: `/ncc/usuarios/<pk>/` nunca tinha nenhum teste
    cross-empresa — confirma que o Proprietário de uma Empresa nunca
    alcança, nem por GET nem por POST, o Usuario de outra Empresa
    manipulando o ID diretamente na URL (o `get_object_or_404(Usuario,
    pk=pk, empresa=empresa)` de `ncc_usuario_editar` é a única barreira)."""

    def setUp(self):
        self.empresa_a = Empresa.objects.create(nome="Empresa A Cross Usuario", cnpj="78.000.000/0001-78")
        self.empresa_b = Empresa.objects.create(nome="Empresa B Cross Usuario", cnpj="78.000.000/0002-78")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B Cross Usuario")

        self.proprietario_a = Usuario.objects.create_user(
            username="prop_a_cross_usuario", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa_a,
        )
        self.usuario_b = Usuario.objects.create_user(
            username="user_b_cross_usuario", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_b, filial=self.filial_b, first_name="Beatriz",
        )

        self.client = Client()
        self.client.force_login(self.proprietario_a)
        self.url = f"/ncc/usuarios/{self.usuario_b.pk}/"

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_get_usuario_de_outra_empresa_e_404(self):
        resposta = self.client.get(self.url)
        self.assertEqual(resposta.status_code, 404)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_post_usuario_de_outra_empresa_e_404(self):
        """Mesmo enviando um payload minimo valido de `UsuarioDadosForm`
        tentando editar o usuário da Empresa B, o objeto nunca é
        alcançado — o 404 acontece antes de qualquer form ser processado."""
        payload = {
            "salvar_dados": "1", "first_name": "Invasor", "last_name": "Tentativa",
            "email": "invasor@x.com", "perfil": Usuario.Perfil.COMPRADOR,
            "filial": self.filial_b.pk, "is_active": "on",
        }
        resposta = self.client.post(self.url, payload)
        self.assertEqual(resposta.status_code, 404)
        self.usuario_b.refresh_from_db()
        self.assertEqual(self.usuario_b.first_name, "Beatriz")


class GruposFiliaisMultiEmpresaRenderTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 4.1: prova que
    `_montar_grupos_filiais`/o template realmente AGRUPAM por Empresa
    quando as filiais candidatas do usuário-alvo cruzam duas Empresas do
    MESMO Grupo — nunca tinha sido provado que os dois grupos (não só o
    primeiro) aparecem de fato renderizados na tela."""

    def setUp(self):
        from usuarios.models import UsuarioEmpresa

        grupo = GrupoEmpresarial.objects.create(nome="Grupo Render Multi Empresa")
        self.empresa_a = Empresa.objects.create(nome="Empresa A Render Grupo", cnpj="79.000.000/0001-79", grupo=grupo)
        self.empresa_b = Empresa.objects.create(nome="Empresa B Render Grupo", cnpj="79.000.000/0002-79", grupo=grupo)
        self.filial_a = Filial.objects.create(empresa=self.empresa_a, nome="Filial A Render Grupo")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B Render Grupo")

        self.proprietario = Usuario.objects.create_user(
            username="prop_render_multi_empresa", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa_a,
        )
        # Alvo comprador (não-Proprietário) — o template só renderiza
        # `grupos_filiais` para não-Proprietário; para Proprietário mostra
        # só uma mensagem informativa.
        self.alvo = Usuario.objects.create_user(
            username="alvo_render_multi_empresa", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        # Empresa B autorizada de verdade para o alvo (além de fazer parte
        # do mesmo Grupo, que já bastaria para virar filial candidata).
        UsuarioEmpresa.objects.create(usuario=self.alvo, empresa=self.empresa_b, ativo=True)

        self.client = Client()
        self.client.force_login(self.proprietario)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_grupos_de_filiais_de_ambas_empresas_aparecem_na_tela(self):
        resposta = self.client.get(f"/ncc/usuarios/{self.alvo.pk}/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, self.empresa_a.nome)
        self.assertContains(resposta, self.empresa_b.nome)


class EnvioConjuntoEmpresaEFilialNaMesmaSubmissaoTestCase(TestCase):
    """Caminho positivo end-to-end nunca testado: o Proprietário autoriza
    uma nova Empresa do mesmo Grupo E já marca uma filial dela na MESMA
    submissão POST de `/ncc/usuarios/<pk>/` (Seção 4.1 — `filiais_
    autorizadas` é declarado DEPOIS de `empresas_autorizadas` no form
    justamente para permitir isso numa única submissão)."""

    def setUp(self):
        grupo = GrupoEmpresarial.objects.create(nome="Grupo Envio Conjunto")
        self.empresa_principal = Empresa.objects.create(
            nome="Empresa Principal Envio Conjunto", cnpj="81.000.000/0001-81", grupo=grupo,
        )
        self.empresa_nova = Empresa.objects.create(
            nome="Empresa Nova Envio Conjunto", cnpj="81.000.000/0002-81", grupo=grupo,
        )
        self.filial_principal = Filial.objects.create(empresa=self.empresa_principal, nome="Filial Principal EC")
        self.filial_nova = Filial.objects.create(empresa=self.empresa_nova, nome="Filial Nova EC")

        self.proprietario = Usuario.objects.create_user(
            username="prop_envio_conjunto", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
            empresa=self.empresa_principal,
        )
        self.alvo = Usuario.objects.create_user(
            username="alvo_envio_conjunto", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_principal, filial=self.filial_principal,
        )

        self.client = Client()
        self.client.force_login(self.proprietario)
        self.url = f"/ncc/usuarios/{self.alvo.pk}/"

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_autorizar_empresa_e_filial_nova_na_mesma_submissao(self):
        from usuarios.models import UsuarioEmpresa, UsuarioFilial

        resposta = self.client.post(self.url, {
            "salvar_permissoes": "1", "perfis_acesso": [], "permissoes_individuais": [],
            "empresas_autorizadas": [self.empresa_nova.pk],
            "filiais_autorizadas": [self.filial_principal.pk, self.filial_nova.pk],
            "limite_compra": "",
        })
        self.assertEqual(
            resposta.status_code, 302,
            resposta.context["form"].errors if resposta.status_code == 200 else "",
        )

        self.assertTrue(
            UsuarioEmpresa.objects.filter(usuario=self.alvo, empresa=self.empresa_nova, ativo=True).exists()
        )
        self.assertTrue(
            UsuarioFilial.objects.filter(usuario=self.alvo, filial=self.filial_nova, ativo=True).exists()
        )


class NccCentralAuditoriaTestCase(TestCase):
    """Fechamento Final (Prompt 1, Seção 8): a Central de Auditoria nova é
    protegida por permissão PRÓPRIA (`auditoria.ver`, distinta de
    `ncc.acessar`), une os 4 mecanismos e nunca vaza evento de outra
    empresa — mesmo tema recorrente de isolamento cross-tenant desta
    Sprint."""

    def setUp(self):
        from auditoria.models import RegistroAuditoria
        from auditoria.services import registrar_evento

        self.registrar_evento = registrar_evento
        self.RegistroAuditoria = RegistroAuditoria

        self.empresa = Empresa.objects.create(nome="Empresa Central Auditoria", cnpj="99.100.000/0001-99")
        self.outra_empresa = Empresa.objects.create(nome="Outra Empresa Central Auditoria", cnpj="99.200.000/0001-99")
        self.proprietario = Usuario.objects.create_user(
            username="prop_central_auditoria", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.comprador = Usuario.objects.create_user(
            username="comprador_central_auditoria", password="x", perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa,
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login do Proprietário",
            empresa=self.empresa, usuario=self.proprietario,
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login de outra empresa",
            empresa=self.outra_empresa,
        )
        self.client = Client()

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_sem_permissao_recebe_403(self):
        self.client.force_login(self.comprador)
        resposta = self.client.get("/ncc/central-auditoria/")
        self.assertEqual(resposta.status_code, 403)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_ve_a_tela_com_o_proprio_evento(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.get("/ncc/central-auditoria/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Login do Proprietário")
        self.assertNotContains(resposta, "Login de outra empresa")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_filtro_de_categoria_via_querystring(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.get("/ncc/central-auditoria/?categoria=configuracao")
        self.assertEqual(resposta.status_code, 200)
        self.assertNotContains(resposta, "Login do Proprietário")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_parametros_invalidos_nao_derrubam_a_tela(self):
        """`usuario`/`pagina` fora do formato esperado não podem virar 500
        — a view precisa degradar graciosamente."""
        self.client.force_login(self.proprietario)
        resposta = self.client.get("/ncc/central-auditoria/?usuario=abc&pagina=xyz&data_inicio=nao-e-data")
        self.assertEqual(resposta.status_code, 200)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_filtros_novos_do_gate_d_isolam_o_evento_certo(self):
        """Prompt 2, Gate D (Seção 11): módulo/ação/objeto/origem/
        resultado/autoaprovação/perfil histórico — cada um sozinho já
        isola o evento certo entre dois candidatos. O evento-alvo é do
        Comprador (não do Proprietário do setUp) e com origem AUTOMÁTICA
        (não a MANUAL padrão do login) — só assim `usuario_perfil` e
        `origem_decisao` realmente distinguem os dois eventos, em vez de
        ambos baterem no valor default."""
        self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.COMPRADOR_BLOQUEADO,
            descricao="Comprador bloqueado — evento-alvo dos filtros novos",
            empresa=self.empresa, usuario=self.comprador, modulo="financeiro", acao="bloquear_comprador",
            tipo_objeto="UsuarioEmpresa", id_objeto=999999,
            resultado=self.RegistroAuditoria.Resultado.BLOQUEADO,
            origem_decisao=self.RegistroAuditoria.OrigemDecisao.AUTOMATICA, autoaprovacao=True,
        )
        self.client.force_login(self.proprietario)

        for querystring in (
            "modulo=financeiro", "acao=bloquear_comprador", "tipo_objeto=UsuarioEmpresa",
            "origem_decisao=automatica", "resultado=bloqueado", "autoaprovacao=1",
            f"usuario_perfil={Usuario.Perfil.COMPRADOR}",
        ):
            with self.subTest(querystring=querystring):
                resposta = self.client.get(f"/ncc/central-auditoria/?{querystring}")
                self.assertEqual(resposta.status_code, 200)
                self.assertContains(resposta, "evento-alvo dos filtros novos")
                self.assertNotContains(resposta, "Login do Proprietário")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_filtro_modulo_nao_afeta_os_outros_3_mecanismos_quando_vazio(self):
        """Sem nenhum filtro novo ativo, os eventos de `LogConfiguracao`/
        `HistoricoCompra`/`HistoricoProvisao` continuam aparecendo — a
        combinação `usar_apenas_registro` só liga quando algum filtro do
        Gate D é passado de verdade."""
        self.client.force_login(self.proprietario)
        resposta = self.client.get("/ncc/central-auditoria/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Login do Proprietário")

    def test_origem_do_evento_reflete_o_modulo_real_do_registro(self):
        """Gate 3 (Sprint de Encerramento Definitivo): antes desta correção,
        `listar_eventos_auditoria` hardcodeava `origem="Segurança"` para
        TODO `RegistroAuditoria`, mesmo quando o `modulo` gravado era
        "compras"/"provisoes"/"financeiro"/"usuarios" — um evento de
        Compra aparecia igual a um login na Central de Auditoria (NCC).
        Este teste crava um evento de cada módulo de negócio e confirma que
        `origem` reflete o `modulo` real — e que o evento de Compra NUNCA
        mais aparece rotulado como "Segurança"."""
        from auditoria.services import listar_eventos_auditoria

        evento_compra = self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.COMPRA_LANCADA,
            descricao="Compra lançada — teste de origem", empresa=self.empresa,
            usuario=self.proprietario, modulo="compras", acao="lancar",
        )
        evento_provisao = self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.PROVISAO_CRIADA,
            descricao="Provisão criada — teste de origem", empresa=self.empresa,
            usuario=self.proprietario, modulo="provisoes", acao="criar",
        )
        evento_financeiro = self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.PARCELA_BAIXADA,
            descricao="Parcela baixada — teste de origem", empresa=self.empresa,
            usuario=self.proprietario, modulo="financeiro", acao="baixar",
        )
        evento_usuario = self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.USUARIO_CRIADO,
            descricao="Usuário criado — teste de origem", empresa=self.empresa,
            usuario=self.proprietario, modulo="usuarios", acao="criar",
        )
        evento_empresa = self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.EMPRESA_EDITADA,
            descricao="Empresa editada — teste de origem", empresa=self.empresa,
            usuario=self.proprietario, modulo="empresas", acao="editar",
        )
        evento_login = self.registrar_evento(
            categoria=self.RegistroAuditoria.Categoria.LOGIN_SUCESSO,
            descricao="Login com módulo explícito — teste de origem", empresa=self.empresa,
            usuario=self.proprietario, modulo="seguranca", acao="login",
        )

        pagina = listar_eventos_auditoria(self.empresa, por_pagina=100)
        origem_por_descricao = {e.descricao: e.origem for e in pagina.object_list}

        self.assertEqual(origem_por_descricao["Compra lançada — teste de origem"], "Compras")
        self.assertEqual(origem_por_descricao["Provisão criada — teste de origem"], "Provisões")
        self.assertEqual(origem_por_descricao["Parcela baixada — teste de origem"], "Financeiro")
        self.assertEqual(origem_por_descricao["Usuário criado — teste de origem"], "Usuários e Acesso")
        self.assertEqual(origem_por_descricao["Empresa editada — teste de origem"], "Empresas e Filiais")
        self.assertEqual(origem_por_descricao["Login com módulo explícito — teste de origem"], "Segurança")

        # O evento de Compra é o que estava incorretamente rotulado antes
        # da correção — nunca mais pode voltar a aparecer como "Segurança".
        self.assertNotEqual(origem_por_descricao["Compra lançada — teste de origem"], "Segurança")

        # Confirma também na tela renderizada (view real, não só a função de
        # serviço isolada): o badge de origem do evento de Compra mostra
        # "Compras", e a descrição do evento de Compra aparece perto dela —
        # não mais junto ao badge fixo "Segurança".
        self.client.force_login(self.proprietario)
        resposta = self.client.get("/ncc/central-auditoria/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Compra lançada — teste de origem")
        conteudo = resposta.content.decode()
        indice_evento = conteudo.index("Compra lançada — teste de origem")
        trecho_proximo = conteudo[max(0, indice_evento - 800):indice_evento]
        self.assertIn("Compras", trecho_proximo)
        self.assertNotIn("Segurança", trecho_proximo)


class ProprietarioOperacionalSemSuperuserTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-2): auditoria externa encontrou `proprietario`
    e `demo_proprietario` com `is_staff=1`/`is_superuser=1` no banco de
    demonstração — superusuário ignora `usuario_tem_permissao` por completo
    (`core/permissions.py`), então nenhum teste feito com essas contas
    prova de verdade que o RBAC do perfil Proprietário funciona sozinho.

    Este teste usa uma conta Proprietário deliberadamente SEM
    is_staff/is_superuser e percorre as telas que o catálogo de permissões
    (`core.permissions.CATALOGO_PERMISSOES`) diz que o perfil deve acessar,
    confirmando 200 (nunca 403) — a prova real de que a operação inteira do
    Proprietário passa pelo catálogo, não por um bypass de superusuário."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Prop Operacional", cnpj="93.200.000/0001-93")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_operacional", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        # A prova está aqui: nunca marcado como staff/superuser.
        self.assertFalse(self.proprietario.is_staff)
        self.assertFalse(self.proprietario.is_superuser)
        self.client = Client()
        self.client.force_login(self.proprietario)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_telas_do_catalogo_de_permissoes_respondem_200_sem_superuser(self):
        urls_permitidas = [
            "/",  # dashboard
            "/relatorios/",
            "/ncc/",
            "/ncc/gerais/",
            "/ncc/estrutura/",
            "/ncc/filiais/",
            "/ncc/usuarios/",
            "/ncc/perfis/",
            "/ncc/motor/",
            "/ncc/workflow/",
            "/ncc/compras/",
            "/ncc/dashboard/",
            "/ncc/notificacoes/",
            "/ncc/integracoes/",
            "/ncc/auditoria/",
            "/ncc/central-auditoria/",
            "/gestao-compras/aprovacao/",
            "/financeiro/agenda/",
            "/financeiro/capacidade-compradores/",
            "/financeiro/calendario-operacional/",
            "/timeline/",
            "/notificacoes/",
            "/perfil/",
            # Prompt 2 (pré-Etapa 02), Gate A: o QA anterior registrou como
            # esperado que estas duas rotas dessem 403 para o Proprietário
            # — contradiz a regra oficial do Proprietário Operacional (ele é
            # ator real da operação, não só aprovador). Corrigido em
            # `core.permissions.CATALOGO_PERMISSOES` (compras.lancar,
            # provisoes.criar, calendario.ver agora incluem PROPRIETARIO).
            "/compras/nova/",
            "/gestao-compras/nova/",
            "/gestao-compras/",
        ]
        for url in urls_permitidas:
            with self.subTest(url=url):
                resposta = self.client.get(url)
                self.assertNotEqual(
                    resposta.status_code, 403,
                    f"{url} devolveu 403 para o Proprietário sem superuser — "
                    "falta permissão no catálogo ou vínculo de dados para esta jornada.",
                )
                self.assertNotEqual(resposta.status_code, 500, f"{url} quebrou (500) para o Proprietário.")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_admin_django_continua_negado_ao_proprietario_operacional(self):
        """Confirma o outro lado: o catálogo de permissões não virou
        "acesso total disfarçado" de superusuário — o Proprietário
        Operacional, mesmo com o RBAC amplo do Gate A (Prompt 2), continua
        SEM acesso ao Django Admin, porque nunca ganha `is_staff`/
        `is_superuser` (gate S1-2). Prompt 2, Gate A (Seção 4) corrigiu a
        versão anterior deste teste, que registrava incorretamente como
        esperado que `/gestao-compras/nova/` e `/gestao-compras/`
        dessem 403 — hoje são cobertas como PERMITIDAS em
        `test_telas_do_catalogo_de_permissoes_respondem_200_sem_superuser`."""
        resposta = self.client.get("/admin/", follow=True)
        self.assertContains(
            resposta, "não está autorizado a acessar esta página",
            status_code=200,
        )


class NccWorkflowEditarAuditoriaTestCase(TestCase):
    """Prompt 2, Gate D (Seção 9): salvar um fluxo de aprovação (novo ou
    existente) gera `WORKFLOW_ALTERADO` na Central de Auditoria, com a
    fotografia completa das etapas."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Workflow", cnpj="67.000.000/0001-67")
        self.proprietario = Usuario.objects.create_user(
            username="prop_workflow", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)

    def _payload_fluxo(self, **overrides):
        base = {
            "nome": "Fluxo Padrão", "ativo": "on",
            "etapas-TOTAL_FORMS": "1", "etapas-INITIAL_FORMS": "0",
            "etapas-MIN_NUM_FORMS": "1", "etapas-MAX_NUM_FORMS": "1000",
            "etapas-0-ordem": "1", "etapas-0-perfil_aprovador": Usuario.Perfil.GERENTE,
            "etapas-0-aprovador": "", "etapas-0-substituto": "",
            "etapas-0-valor_maximo": "", "etapas-0-prazo_dias": "",
            "etapas-0-observacao": "",
        }
        base.update(overrides)
        return base

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_fluxo_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria
        from gestao_compras.models import FluxoAprovacao

        resposta = self.client.post("/ncc/workflow/novo/", self._payload_fluxo())
        self.assertEqual(
            resposta.status_code, 302,
            resposta.context["form"].errors if resposta.status_code == 200 else "",
        )
        fluxo = FluxoAprovacao.objects.get(empresa=self.empresa, nome="Fluxo Padrão")
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.WORKFLOW_ALTERADO, id_objeto=fluxo.pk,
        )
        self.assertEqual(registro.estado_depois["nome"], "Fluxo Padrão")
        self.assertEqual(len(registro.estado_depois["etapas"]), 1)
        self.assertEqual(registro.estado_depois["etapas"][0]["perfil_aprovador"], Usuario.Perfil.GERENTE)
        self.assertEqual(registro.usuario_id, self.proprietario.pk)
