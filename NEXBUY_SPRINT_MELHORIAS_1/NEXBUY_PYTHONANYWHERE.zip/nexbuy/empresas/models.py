from django.db import models

from core.choices import UF_CHOICES
from core.models import ModeloAtivavel, TimeStampedModel
from core.utils import formatar_cnpj
from core.validators import normalizar_cnpj, validar_cnpj


class GrupoEmpresarial(TimeStampedModel):
    """Agrupa uma ou mais empresas (CNPJs) sob o mesmo grupo econômico."""

    nome = models.CharField("Nome do grupo", max_length=150)

    class Meta:
        verbose_name = "Grupo Empresarial"
        verbose_name_plural = "Grupos Empresariais"
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class Empresa(TimeStampedModel, ModeloAtivavel):
    grupo = models.ForeignKey(
        GrupoEmpresarial,
        on_delete=models.CASCADE,
        related_name="empresas",
        null=True,
        blank=True,
        verbose_name="Grupo empresarial",
    )
    # Renomeado de "Razão social / Nome fantasia" (Etapa 1) para "Nome
    # Fantasia" na Sprint 6 — só o rótulo mudou (mesma coluna `nome`,
    # nenhum dado é migrado); a Razão Social ganhou campo próprio abaixo.
    nome = models.CharField("Nome Fantasia", max_length=200)
    razao_social = models.CharField("Razão Social", max_length=200, blank=True)
    # Gate pré-Etapa 10 (S1-1): mesmo validador de dígito verificador que já
    # protege `filiais.Filial.cnpj` — antes só existiam CNPJs de exemplo com
    # dígitos inválidos (ex.: "12.345.678/0001-90") na base, sem checagem
    # nenhuma além de unicidade textual.
    cnpj = models.CharField("CNPJ", max_length=18, unique=True, validators=[validar_cnpj])
    inscricao_estadual = models.CharField("Inscrição Estadual", max_length=20, blank=True)
    segmento = models.CharField("Segmento", max_length=100, default="Farmacêutico")
    telefone = models.CharField("Telefone", max_length=20, blank=True)
    email = models.EmailField("E-mail", blank=True)
    endereco = models.CharField("Endereço", max_length=255, blank=True)
    cidade = models.CharField("Cidade", max_length=100, blank=True)
    estado = models.CharField("Estado", max_length=2, choices=UF_CHOICES, blank=True)
    cep = models.CharField("CEP", max_length=9, blank=True)
    # Sprint de Melhorias 1: comércio que abre e compra no sábado liga esta
    # opção no Calendário Operacional e todo sábado passa a ser dia de compra
    # (entra no divisor do limite diário e recebe limite próprio) — antes era
    # preciso marcar sábado por sábado como "Especial". Desligada por padrão:
    # nenhum número muda para quem já usa o sistema.
    sabado_dia_de_compra = models.BooleanField(
        "Sábado é dia de compra", default=False,
        help_text="Ligado: todo sábado tem limite de compra próprio, como um dia útil.",
    )

    class Meta:
        verbose_name = "Empresa"
        verbose_name_plural = "Empresas"
        ordering = ["nome"]

    def save(self, *args, **kwargs):
        # Gate pré-Etapa 10 (S1-1, item 3): representação canônica
        # persistida (só dígitos) independente de como o CNPJ chegou até
        # aqui (form do wizard, admin, seed, shell) — a máscara é só de
        # apresentação (`core.utils.formatar_cnpj`).
        self.cnpj = normalizar_cnpj(self.cnpj)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.nome} ({formatar_cnpj(self.cnpj)})"


class ConfiguracaoPlataforma(TimeStampedModel):
    """Configurações gerais da plataforma por empresa (Épico 12 — NCC).

    Concentra o que NÃO é financeiro (isso continua em
    `financeiro.ConfiguracaoFinanceira`, sem duplicação): tema, idioma,
    fuso horário, horário de funcionamento e a política de parcelamento.
    Criada sob demanda (`get_or_create`) — uma empresa sem registro usa os
    padrões e se comporta exatamente como antes do CORE 1.0.
    """

    class Tema(models.TextChoices):
        PADRAO = "padrao", "Padrão NEXBUY"
        CLARO = "claro", "Claro"

    class Idioma(models.TextChoices):
        PT_BR = "pt-br", "Português (Brasil)"

    empresa = models.OneToOneField(
        Empresa, on_delete=models.CASCADE, related_name="configuracao_plataforma", verbose_name="Empresa"
    )
    tema = models.CharField("Tema", max_length=10, choices=Tema.choices, default=Tema.PADRAO)
    idioma = models.CharField("Idioma", max_length=10, choices=Idioma.choices, default=Idioma.PT_BR)
    fuso_horario = models.CharField(
        "Fuso horário", max_length=50, default="America/Cuiaba",
        help_text="Fuso IANA, ex.: America/Cuiaba, America/Sao_Paulo.",
    )
    horario_abertura = models.TimeField("Horário de abertura", null=True, blank=True)
    horario_fechamento = models.TimeField("Horário de fechamento", null=True, blank=True)
    parcelas_maximas = models.PositiveSmallIntegerField(
        "Máximo de parcelas (personalizado)",
        default=12,
        help_text="Política de parcelamento: limite de parcelas aceito no prazo Personalizado.",
    )
    # Fechamento Final (Prompt 1, Seção 6): "autoaprovação controlada" —
    # por padrão (default=False), quem CRIA uma Provisão/Compra nunca pode
    # APROVAR a própria solicitação, nem sendo Gerente/Proprietário/
    # superusuário (separação de funções). Ligar isso é uma decisão de
    # negócio explícita da empresa (ex.: negócio pequeno, sem ninguém mais
    # disponível para aprovar) — por isso exige justificativa preenchida
    # (validado no form, `ConfiguracaoPlataformaForm.clean()`), fica
    # registrado em `LogConfiguracao` e nunca é ligado sozinho.
    permitir_autoaprovacao = models.BooleanField(
        "Permitir autoaprovação controlada",
        default=False,
        help_text=(
            "Quando desligado (padrão), quem cria uma Provisão ou Compra nunca pode aprovar a "
            "própria solicitação. Só ligue se a empresa realmente não tem outra pessoa disponível "
            "para aprovar — a justificativa abaixo passa a ser obrigatória."
        ),
    )
    justificativa_autoaprovacao = models.TextField(
        "Justificativa da autoaprovação",
        blank=True,
        help_text="Obrigatório preencher ao ligar a autoaprovação controlada — fica registrado para auditoria.",
    )

    class Meta:
        verbose_name = "Configuração da Plataforma"
        verbose_name_plural = "Configurações da Plataforma"

    def __str__(self):
        return f"Plataforma — {self.empresa.nome}"


class LogConfiguracao(TimeStampedModel):
    """Trilha de auditoria das configurações (Épico 12 — NCC): quem alterou
    o quê, em qual área, e quando. Append-only, no mesmo espírito de
    `HistoricoCompra`/`HistoricoProvisao`."""

    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="logs_configuracao", verbose_name="Empresa"
    )
    usuario = models.ForeignKey(
        "usuarios.Usuario", on_delete=models.SET_NULL, null=True, related_name="+", verbose_name="Usuário"
    )
    area = models.CharField("Área", max_length=60)
    descricao = models.CharField("Descrição", max_length=255)

    class Meta:
        verbose_name = "Log de Configuração"
        verbose_name_plural = "Logs de Configuração"
        ordering = ["-criado_em"]

    def __str__(self):
        return f"{self.area}: {self.descricao} ({self.criado_em:%d/%m/%Y %H:%M})"


class IdentidadeVisual(TimeStampedModel):
    """Personalização visual discreta da Empresa (Sprint 6, item 3): logo,
    favicon, cor secundária e nome de exibição.

    Deliberadamente um model separado de `financeiro.ConfiguracaoFinanceira`
    (que já guarda `cor_principal` desde a Etapa 2) — mover `cor_principal`
    para cá exigiria migrar dados e tocar em todo lugar que já lê
    `configuracao_financeira.cor_principal` (inclusive `templates/base.html`),
    sem necessidade real nesta Sprint. Uma consolidação futura é possível,
    mas não obrigatória (ver Arquitetura.md)."""

    empresa = models.OneToOneField(
        Empresa, on_delete=models.CASCADE, related_name="identidade_visual", verbose_name="Empresa"
    )
    nome_exibicao = models.CharField(
        "Nome de exibição", max_length=100, blank=True,
        help_text="Usado no lugar do Nome Fantasia no menu e no login, quando preenchido.",
    )
    logo = models.ImageField("Logo", upload_to="identidade/logos/", blank=True, null=True)
    favicon = models.ImageField("Favicon", upload_to="identidade/favicons/", blank=True, null=True)
    cor_secundaria = models.CharField("Cor secundária", max_length=7, blank=True)

    class Meta:
        verbose_name = "Identidade Visual"
        verbose_name_plural = "Identidades Visuais"

    def __str__(self):
        return f"Identidade Visual — {self.empresa.nome}"

    @property
    def nome_para_exibicao(self) -> str:
        return self.nome_exibicao or self.empresa.nome
