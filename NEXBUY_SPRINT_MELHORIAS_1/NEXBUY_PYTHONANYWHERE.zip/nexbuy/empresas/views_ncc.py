"""NEXBUY Control Center — NCC (Épico 12 — CORE 1.0).

Painel mestre de configuração da plataforma, dividido em módulos. Cada
tela é fina: valida permissão (`ncc.acessar` via RBAC), resolve a empresa
ativa do contexto e delega qualquer efeito a forms/services — nenhuma
regra de negócio vive aqui.
"""
import re

from django.contrib import messages
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from auditoria.models import RegistroAuditoria
from auditoria.services import ip_do_request, registrar_evento
from compras.models import HistoricoCompra
from core.contexto import empresa_ativa
from core.permissions import CATALOGO_PERMISSOES, permissao_required, permissoes_do_usuario
from core.utils import gerar_senha_provisoria
from filiais.forms import FilialForm, filial_possui_movimentacao
from filiais.models import Filial
from gestao_compras.models import FluxoAprovacao, HistoricoProvisao
from usuarios.models import PerfilAcesso, Permissao, Usuario, UsuarioEmpresa

from .forms_ncc import (
    ConfiguracaoPlataformaForm,
    EtapaFluxoFormSet,
    FluxoAprovacaoForm,
    PerfilAcessoForm,
    UsuarioDadosForm,
    UsuarioPermissoesForm,
)
from .models import ConfiguracaoPlataforma, LogConfiguracao
from .services_checklist import calcular_checklist, resumo_checklist


def _registrar_log(request, empresa, area, descricao):
    LogConfiguracao.objects.create(empresa=empresa, usuario=request.user, area=area, descricao=descricao)


# Checklist de Implantação: chave de sessão usada só para "ocultar por
# enquanto" o card na Home do NCC — nunca decide se um item do checklist
# está concluído (isso é sempre uma consulta real ao banco, em
# `services_checklist.calcular_checklist`) e nunca impede o acesso direto à
# tela (`/ncc/checklist/` continua funcionando normalmente).
CHAVE_SESSAO_CHECKLIST_OCULTO = "ncc_checklist_oculto"


@permissao_required("ncc.acessar")
def ncc_home(request):
    """Centro de Configurações (Épico 2A — Etapa 02): o ÚNICO hub de
    parametrização do NEXBUY, organizado nas categorias do produto. Nada de
    configuração espalhada — toda tela de parametrização tem um card aqui
    (inclusive as que moram em outros módulos, como o Calendário
    Operacional e a Capacidade Financeira)."""
    empresa = empresa_ativa(request)
    modulos_organizacao = [
        {"titulo": "Empresas e Filiais", "icone": "bi-building", "url": "/ncc/estrutura/",
         "descricao": "Grupo econômico, empresas (CNPJ), filiais e vínculos."},
        {"titulo": "Filiais", "icone": "bi-shop", "url": "/ncc/filiais/",
         "descricao": "Cadastrar, editar, ativar e desativar filiais da empresa ativa."},
        {"titulo": "Usuários e Permissões", "icone": "bi-people-fill", "url": "/ncc/usuarios/",
         "descricao": "Criar usuários, definir perfil, senha inicial, foto e status."},
        {"titulo": "Perfis de Acesso", "icone": "bi-person-badge-fill", "url": "/ncc/perfis/",
         "descricao": "Perfis de acesso reutilizáveis e permissões por grupo."},
    ]
    # Checklist de Implantação (novo): fica com card próprio no topo da
    # categoria "Organização", exceto quando o Proprietário clicou em
    # "Ocultar por enquanto" nesta MESMA sessão de navegador
    # (`CHAVE_SESSAO_CHECKLIST_OCULTO`) — o checklist continua plenamente
    # acessível pela URL direta (`/ncc/checklist/`) e pelo link fixo no
    # menu lateral do NCC (`templates/base.html`), então ocultar o card
    # aqui nunca torna a tela inalcançável.
    if not request.session.get(CHAVE_SESSAO_CHECKLIST_OCULTO):
        modulos_organizacao.insert(0, {
            "titulo": "Checklist de Implantação", "icone": "bi-list-check", "url": "/ncc/checklist/",
            "descricao": "O que já foi configurado e o que ainda falta, com base em consultas reais ao banco.",
        })
    categorias = [
        {"nome": "Organização", "modulos": modulos_organizacao},
        {"nome": "Motor Financeiro", "modulos": [
            # Rodada final: a descrição era quase igual à do card Capacidade
            # Financeira — este card é o PAINEL do motor (atalhos), não a tela
            # onde os percentuais são editados.
            {"titulo": "Motor Financeiro", "icone": "bi-cpu-fill", "url": "/ncc/motor/",
             "descricao": "Visão geral do motor: atalhos para capacidade, dias operacionais, parcelamento e provisões."},
            # Críticos (rodada 2): o card se chamava "Capacidade Financeira" e
            # abria OUTRA tela (Compradores e Limites). Cada card leva o nome
            # canônico da tela que abre (o mesmo do menu e da Ajuda).
            {"titulo": "Capacidade Financeira", "icone": "bi-sliders", "url": "/financeiro/configuracao/",
             "descricao": "Percentual destinado a compras, dias úteis, saldo acumulado e redistribuição."},
            {"titulo": "Compradores e Limites", "icone": "bi-distribute-horizontal", "url": "/financeiro/capacidade-compradores/",
             "descricao": "Limites individuais, bloqueio e liberação de compradores."},
            {"titulo": "Calendário Operacional", "icone": "bi-calendar2-x", "url": "/financeiro/calendario-operacional/",
             "descricao": "Feriados, dias bloqueados e exceções operacionais."},
            {"titulo": "Parcelamentos e Compras", "icone": "bi-credit-card-2-front", "url": "/ncc/compras/",
             "descricao": "Políticas de compra, parcelas máximas e regras de aprovação."},
            {"titulo": "Workflow de Aprovações", "icone": "bi-signpost-split-fill", "url": "/ncc/workflow/",
             "descricao": "Fluxos configuráveis, alçadas, prazos e substitutos."},
        ]},
        {"nome": "Plataforma", "modulos": [
            {"titulo": "Notificações", "icone": "bi-bell-fill", "url": "/ncc/notificacoes/",
             "descricao": "Avisos dentro do sistema (sino no topo): aprovações, vencimentos e limites."},
            {"titulo": "Integrações", "icone": "bi-plug-fill", "url": "/ncc/integracoes/",
             "descricao": "DDA — integração futura prevista, ainda não conectada. Hoje, tudo é lançado manualmente."},
            {"titulo": "Personalização", "icone": "bi-palette-fill", "url": "/empresas/identidade-visual/",
             "descricao": "Logo, favicon, cores e nome de exibição da empresa."},
            {"titulo": "Dashboard", "icone": "bi-speedometer2", "url": "/ncc/dashboard/",
             "descricao": "Cards, indicadores e widgets exibidos por perfil."},
            {"titulo": "Sistema", "icone": "bi-gear-fill", "url": "/ncc/gerais/",
             "descricao": "Nome, idioma, fuso, moeda e horário de funcionamento."},
        ]},
        {"nome": "Governança", "modulos": [
            {"titulo": "Auditoria do Sistema", "icone": "bi-shield-check", "url": "/ncc/auditoria/",
             "descricao": "Quem alterou o quê, e quando, em toda parametrização."},
            {"titulo": "Central de Auditoria", "icone": "bi-search", "url": "/ncc/central-auditoria/",
             "descricao": "Login, configuração, compras e provisões — tudo num só lugar, com filtro e busca."},
        ]},
    ]
    # Ferramenta do suporte (ver views_wizard.assistente_implantacao).
    if request.user.is_superuser:
        categorias[-1]["modulos"].append(
            {"titulo": "Assistente de Implantação", "icone": "bi-magic", "url": "/ncc/implantacao/",
             "descricao": "Wizard de 9 etapas para colocar um cliente novo de pé (suporte técnico)."}
        )
    return render(request, "empresas/ncc/home.html", {"empresa": empresa, "categorias": categorias})


@permissao_required("ncc.acessar")
def ncc_checklist(request):
    """Checklist Guiado de Configuração Inicial: mostra ao Proprietário o
    que já está pronto e o que falta configurar depois do Primeiro Acesso
    Seguro, sempre a partir de consultas reais ao banco
    (`services_checklist.calcular_checklist`) — nunca uma flag manual.

    Não bloqueia nenhuma outra tela: é só um guia, sempre acessível por
    aqui (`/ncc/checklist/`) mesmo que o card dele tenha sido ocultado da
    Home nesta sessão."""
    empresa = empresa_ativa(request)

    if request.method == "POST" and request.POST.get("acao") == "ocultar":
        # "Ocultar por enquanto" (por sessão de navegador, não por Empresa —
        # nenhum dado é persistido no banco): some o card da Home do NCC até
        # a sessão expirar/o navegador ser fechado. A tela em si continua
        # acessível a qualquer momento por esta mesma URL ou pelo item fixo
        # no menu lateral do NCC.
        request.session[CHAVE_SESSAO_CHECKLIST_OCULTO] = True
        messages.info(
            request,
            "Checklist ocultado da tela inicial do NCC por enquanto — acesse de novo quando quiser pelo menu "
            '"Checklist de Implantação" ou por esta mesma URL.',
        )
        return redirect("ncc:home")

    itens = calcular_checklist(empresa)
    resumo = resumo_checklist(itens)
    # Atalho secundário (ex.: "Abrir o Simulador" nos itens 11/12) só para
    # quem a view do Simulador aceita — gate do link = gate da view.
    from compras.views import PERFIS_SIMULACAO

    contexto = {
        "empresa": empresa, "itens": itens, "resumo": resumo,
        "pode_simular": request.user.perfil in PERFIS_SIMULACAO,
    }
    return render(request, "empresas/ncc/checklist.html", contexto)


@permissao_required("ncc.acessar")
def ncc_gerais(request):
    empresa = empresa_ativa(request)
    config, _ = ConfiguracaoPlataforma.objects.get_or_create(empresa=empresa)
    if request.method == "POST":
        autoaprovacao_estava_ligada = config.permitir_autoaprovacao
        parcelas_maximas_antes = config.parcelas_maximas
        form = ConfiguracaoPlataformaForm(request.POST, instance=config)
        if form.is_valid():
            with transaction.atomic():
                config_salva = form.save()
                descricao = "Configurações gerais da plataforma atualizadas."
                # Fechamento Final (Seção 6): mudança na autoaprovação controlada
                # merece uma linha própria no log — é uma decisão de governança,
                # não só um ajuste de preferência qualquer.
                if config_salva.permitir_autoaprovacao != autoaprovacao_estava_ligada:
                    if config_salva.permitir_autoaprovacao:
                        descricao += (
                            f' Autoaprovação controlada LIGADA — justificativa: '
                            f'"{config_salva.justificativa_autoaprovacao}".'
                        )
                    else:
                        descricao += " Autoaprovação controlada DESLIGADA."
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.AUTOAPROVACAO_ALTERADA,
                        descricao=descricao, empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="empresas", acao="autoaprovacao", tipo_objeto="ConfiguracaoPlataforma",
                        id_objeto=config_salva.pk,
                        estado_antes={"permitir_autoaprovacao": autoaprovacao_estava_ligada},
                        estado_depois={"permitir_autoaprovacao": config_salva.permitir_autoaprovacao},
                        justificativa=config_salva.justificativa_autoaprovacao or "",
                    )
                if config_salva.parcelas_maximas != parcelas_maximas_antes:
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.CONFIGURACAO_PLATAFORMA_ALTERADA,
                        descricao="Parcelas máximas permitidas alteradas.",
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="empresas", acao="configuracao_plataforma", tipo_objeto="ConfiguracaoPlataforma",
                        id_objeto=config_salva.pk,
                        estado_antes={"parcelas_maximas": parcelas_maximas_antes},
                        estado_depois={"parcelas_maximas": config_salva.parcelas_maximas},
                    )
                _registrar_log(request, empresa, "Configurações Gerais", descricao)
            messages.success(request, "Configurações gerais salvas com sucesso.")
            return redirect("ncc:gerais")
    else:
        form = ConfiguracaoPlataformaForm(instance=config)
    return render(request, "empresas/ncc/gerais.html", {"form": form, "empresa": empresa})


@permissao_required("ncc.acessar")
def ncc_estrutura(request):
    empresa = empresa_ativa(request)
    contexto = {
        "empresa": empresa,
        "grupo": empresa.grupo if empresa else None,
        "empresas_do_grupo": empresa.grupo.empresas.filter(ativo=True) if empresa and empresa.grupo else [],
        "filiais": empresa.filiais.all() if empresa else [],
        "usuarios": Usuario.objects.filter(empresa=empresa).order_by("first_name", "username") if empresa else [],
    }
    return render(request, "empresas/ncc/estrutura.html", contexto)


@permissao_required("filiais.gerenciar")
def ncc_filiais(request):
    """CRUD de Filiais (Sprint de Correções Críticas — Seção 6). Restrito à
    permissão `filiais.gerenciar` (Proprietário, por padrão) — Financeiro/
    Gerente/Comprador continuam apenas consultando filiais em outras
    telas, nunca cadastrando/editando por aqui.

    Fechamento Final (Seção 4.4): busca por nome/CNPJ/código interno, e
    cada linha expõe `cadastro_completo` (propriedade do model) para o
    badge de "cadastro incompleto" na listagem."""
    empresa = empresa_ativa(request)
    busca = (request.GET.get("q") or "").strip()
    filiais = (
        empresa.filiais.all().select_related("responsavel_usuario").order_by("nome") if empresa else Filial.objects.none()
    )
    if busca:
        filiais = filiais.filter(
            Q(nome__icontains=busca) | Q(razao_social__icontains=busca)
            | Q(cnpj__icontains=re.sub(r"\D", "", busca) or busca)
            | Q(codigo_interno__icontains=busca)
        )
    return render(request, "empresas/ncc/filiais.html", {"empresa": empresa, "filiais": filiais, "busca": busca})


@permissao_required("filiais.gerenciar")
def ncc_filial_nova(request):
    empresa = empresa_ativa(request)
    if request.method == "POST":
        form = FilialForm(request.POST, empresa=empresa)
        if form.is_valid():
            with transaction.atomic():
                filial = form.save()
                _registrar_log(request, empresa, "Empresas e Filiais", f'Filial "{filial.nome}" criada.')
                registrar_evento(
                    categoria=RegistroAuditoria.Categoria.FILIAL_CRIADA,
                    descricao=f'Filial "{filial.nome}" criada.',
                    empresa=empresa, filial=filial, usuario=request.user, ip=ip_do_request(request),
                    modulo="filiais", acao="criar", resultado=RegistroAuditoria.Resultado.SUCESSO,
                    tipo_objeto="Filial", id_objeto=filial.pk,
                    estado_depois={"nome": filial.nome, "tipo_estabelecimento": filial.tipo_estabelecimento, "ativo": filial.ativo},
                )
            messages.success(request, f'Filial "{filial.nome}" criada com sucesso.')
            return redirect("ncc:filiais")
    else:
        form = FilialForm(empresa=empresa)
    return render(request, "empresas/ncc/filial_form.html", {"empresa": empresa, "form": form, "filial": None})


@permissao_required("filiais.gerenciar")
def ncc_filial_editar(request, pk):
    empresa = empresa_ativa(request)
    # Sprint de Correções Críticas (Seção 6, último item): impede acesso
    # por ID a Filial de outra Empresa — o filtro `empresa=empresa` está na
    # própria consulta, não é uma checagem posterior.
    filial = get_object_or_404(Filial, pk=pk, empresa=empresa)

    if request.method == "POST" and "excluir" in request.POST:
        if filial_possui_movimentacao(filial):
            messages.error(
                request,
                f'A filial "{filial.nome}" tem compras, provisões, receitas, custos ou usuários vinculados — '
                "não pode ser excluída. Desative-a em vez de excluir.",
            )
        else:
            nome = filial.nome
            with transaction.atomic():
                filial.delete()
                _registrar_log(request, empresa, "Empresas e Filiais", f'Filial "{nome}" excluída (sem movimentação).')
            messages.success(request, f'Filial "{nome}" excluída.')
            return redirect("ncc:filiais")
        return redirect("ncc:filial_editar", pk=filial.pk)

    if request.method == "POST":
        estava_ativa = filial.ativo
        estado_antes = {
            "nome": filial.nome, "ativo": filial.ativo, "cnpj": filial.cnpj,
            "razao_social": filial.razao_social, "responsavel_usuario_id": filial.responsavel_usuario_id,
        }
        form = FilialForm(request.POST, instance=filial, empresa=empresa)
        if form.is_valid():
            with transaction.atomic():
                filial = form.save()
                if filial.ativo != estava_ativa:
                    acao = "ativada" if filial.ativo else "desativada"
                    _registrar_log(request, empresa, "Empresas e Filiais", f'Filial "{filial.nome}" {acao}.')
                else:
                    _registrar_log(request, empresa, "Empresas e Filiais", f'Filial "{filial.nome}" atualizada.')
                registrar_evento(
                    categoria=RegistroAuditoria.Categoria.FILIAL_EDITADA,
                    descricao=f'Filial "{filial.nome}" editada.',
                    empresa=empresa, filial=filial, usuario=request.user, ip=ip_do_request(request),
                    modulo="filiais", acao="editar", resultado=RegistroAuditoria.Resultado.SUCESSO,
                    tipo_objeto="Filial", id_objeto=filial.pk,
                    estado_antes=estado_antes,
                    estado_depois={
                        "nome": filial.nome, "ativo": filial.ativo, "cnpj": filial.cnpj,
                        "razao_social": filial.razao_social, "responsavel_usuario_id": filial.responsavel_usuario_id,
                    },
                )
            messages.success(request, f'Filial "{filial.nome}" atualizada com sucesso.')
            return redirect("ncc:filiais")
    else:
        form = FilialForm(instance=filial, empresa=empresa)

    contexto = {
        "empresa": empresa,
        "form": form,
        "filial": filial,
        "pode_excluir": not filial_possui_movimentacao(filial),
    }
    return render(request, "empresas/ncc/filial_form.html", contexto)


@permissao_required("ncc.acessar")
def ncc_usuarios(request):
    empresa = empresa_ativa(request)
    usuarios = (
        Usuario.objects.filter(empresa=empresa)
        .prefetch_related("perfis_acesso", "autorizacoes_empresa__empresa")
        .order_by("first_name", "username")
        if empresa
        else []
    )
    return render(request, "empresas/ncc/usuarios.html", {"empresa": empresa, "usuarios": usuarios})


def _montar_grupos_permissoes(form):
    """Épico 2A (Etapa 03): organiza os checkboxes de permissões do form em
    GRUPOS de negócio, cada item com a descrição do que a permissão faz —
    o painel visual que substitui a lista técnica."""
    from core.permissions import DESCRICOES_PERMISSOES, GRUPOS_PERMISSOES, grupo_da_permissao

    permissoes_por_pk = {str(p.pk): p for p in Permissao.objects.all()}
    grupos = {nome: [] for nome, _ in GRUPOS_PERMISSOES}
    for subwidget in form["permissoes_individuais"]:
        permissao = permissoes_por_pk.get(str(subwidget.data["value"]))
        if permissao is None:
            continue
        grupos[grupo_da_permissao(permissao.codigo)].append(
            {
                "sub": subwidget,
                "codigo": permissao.codigo,
                "nome": permissao.nome,
                "descricao": DESCRICOES_PERMISSOES.get(permissao.codigo, ""),
            }
        )
    return [{"nome": nome, "itens": itens} for nome, itens in grupos.items() if itens]


def _montar_grupos_filiais(form):
    """Fechamento Final (Prompt 1, Seção 4.1): "exiba as filiais agrupadas
    por Empresa/CNPJ autorizada" — mesmo padrão de `_montar_grupos_
    permissoes`, mas agrupando por Empresa em vez de área de negócio."""
    filiais_por_pk = {str(f.pk): f for f in form.filiais_candidatas}
    grupos = {}
    for subwidget in form["filiais_autorizadas"]:
        filial = filiais_por_pk.get(str(subwidget.data["value"]))
        if filial is None:
            continue
        chave = filial.empresa_id
        grupos.setdefault(chave, {"empresa": filial.empresa, "itens": []})
        grupos[chave]["itens"].append({"sub": subwidget, "nome": filial.nome})
    return sorted(grupos.values(), key=lambda g: g["empresa"].nome)


@permissao_required("ncc.acessar")
def ncc_usuario_novo(request):
    """Cadastro de usuário no produto (Épico 2A — Etapa 03). Após criar,
    segue direto para o painel de permissões do novo usuário."""
    from .forms_ncc import UsuarioNovoForm

    empresa = empresa_ativa(request)
    if request.method == "POST":
        form = UsuarioNovoForm(request.POST, request.FILES, empresa=empresa)
        if form.is_valid():
            with transaction.atomic():
                usuario = form.save()
                _registrar_log(
                    request, empresa, "Usuários e Permissões",
                    f"Usuário {usuario.get_full_name() or usuario.username} criado ({usuario.get_perfil_display()}).",
                )
                registrar_evento(
                    categoria=RegistroAuditoria.Categoria.USUARIO_CRIADO,
                    descricao=f"Usuário {usuario.get_full_name() or usuario.username} criado ({usuario.get_perfil_display()}).",
                    empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                    filial=usuario.filial, modulo="usuarios", acao="criar",
                    resultado=RegistroAuditoria.Resultado.SUCESSO,
                    tipo_objeto="Usuario", id_objeto=usuario.pk,
                    estado_depois={
                        "username": usuario.username, "perfil": usuario.perfil,
                        "filial_id": usuario.filial_id, "is_active": usuario.is_active,
                    },
                )
            messages.success(
                request,
                f"Usuário {usuario.get_full_name() or usuario.username} criado. Ajuste as permissões abaixo, se necessário.",
            )
            return redirect("ncc:usuario_editar", pk=usuario.pk)
    else:
        form = UsuarioNovoForm(empresa=empresa)
    return render(request, "empresas/ncc/usuario_novo.html", {"empresa": empresa, "form": form})


@permissao_required("ncc.acessar")
def ncc_usuario_editar(request, pk):
    """Sprint de Consolidação (Gate 2A, Parte 5): a edição de usuário
    reúne agora TRÊS ações independentes na mesma tela — dados/status
    (`UsuarioDadosForm`), permissões/RBAC (`UsuarioPermissoesForm`, já
    existente) e gerar senha provisória — cada uma seu próprio botão de
    submit, para nunca perder o preenchimento de uma ao salvar a outra.
    Sem recuperação por e-mail: a senha nova só aparece UMA VEZ, na
    mensagem de sucesso desta página — não fica salva em texto puro em
    lugar nenhum."""
    from core.permissions import DESCRICOES_PERMISSOES

    empresa = empresa_ativa(request)
    usuarios_editaveis = Usuario.objects.filter(empresa=empresa)
    # Sprint de Melhorias 1 (segurança): a conta do suporte técnico
    # (superusuário/equipe) nunca é editada pelo cliente — sem isto, o
    # Proprietário gerava uma "senha provisória" para ela e entrava no
    # /admin com acesso a todas as empresas do servidor.
    if not request.user.is_superuser:
        usuarios_editaveis = usuarios_editaveis.filter(is_superuser=False, is_staff=False)
    usuario = get_object_or_404(usuarios_editaveis, pk=pk)

    if request.method == "POST" and "salvar_dados" in request.POST:
        estado_antes = {
            "first_name": usuario.first_name, "last_name": usuario.last_name, "email": usuario.email,
            "perfil": usuario.perfil, "is_active": usuario.is_active,
        }
        form_dados = UsuarioDadosForm(request.POST, instance=usuario, empresa=empresa)
        if usuario.pk == request.user.pk and request.POST.get("is_active") is None:
            form_dados.add_error(None, "Você não pode desativar a própria conta por aqui.")
        if form_dados.is_valid():
            with transaction.atomic():
                form_dados.save()
                _registrar_log(
                    request, empresa, "Usuários e Permissões",
                    f"Dados de {usuario.get_full_name() or usuario.username} atualizados"
                    f"{' (desativado)' if not usuario.is_active else ''}.",
                )
                estado_depois = {
                    "first_name": usuario.first_name, "last_name": usuario.last_name, "email": usuario.email,
                    "perfil": usuario.perfil, "is_active": usuario.is_active,
                }
                # Gate D (Prompt 2, Seção 9): status e perfil ganham categoria
                # PRÓPRIA quando mudam — não ficam escondidos num "dados
                # atualizados" genérico, já que são decisões de acesso.
                if estado_antes["is_active"] != estado_depois["is_active"]:
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.USUARIO_STATUS_ALTERADO,
                        descricao=f"{usuario.get_full_name() or usuario.username} — status de acesso alterado.",
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request), filial=usuario.filial,
                        modulo="usuarios", acao="status", tipo_objeto="Usuario", id_objeto=usuario.pk,
                        estado_antes={"is_active": estado_antes["is_active"]},
                        estado_depois={"is_active": estado_depois["is_active"]},
                    )
                if estado_antes["perfil"] != estado_depois["perfil"]:
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.USUARIO_PERFIL_ALTERADO,
                        descricao=f"{usuario.get_full_name() or usuario.username} — perfil alterado.",
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request), filial=usuario.filial,
                        modulo="usuarios", acao="alterar_perfil", tipo_objeto="Usuario", id_objeto=usuario.pk,
                        estado_antes={"perfil": estado_antes["perfil"]}, estado_depois={"perfil": estado_depois["perfil"]},
                    )
                if estado_antes != estado_depois:
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.USUARIO_EDITADO,
                        descricao=f"Dados de {usuario.get_full_name() or usuario.username} atualizados.",
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request), filial=usuario.filial,
                        modulo="usuarios", acao="editar", tipo_objeto="Usuario", id_objeto=usuario.pk,
                        estado_antes=estado_antes, estado_depois=estado_depois,
                    )
            messages.success(request, "Dados do usuário atualizados com sucesso.")
            return redirect("ncc:usuario_editar", pk=usuario.pk)
    else:
        form_dados = UsuarioDadosForm(instance=usuario, empresa=empresa)

    if request.method == "POST" and "gerar_senha" in request.POST:
        senha_gerada = gerar_senha_provisoria()
        with transaction.atomic():
            usuario.set_password(senha_gerada)
            usuario.save(update_fields=["password"])
            _registrar_log(
                request, empresa, "Usuários e Permissões",
                f"Nova senha provisória gerada para {usuario.get_full_name() or usuario.username}.",
            )
        messages.success(
            request,
            f'Nova senha provisória de {usuario.get_full_name() or usuario.username}: "{senha_gerada}" — '
            "informe-a diretamente ao usuário agora; ela não pode ser recuperada depois desta tela.",
        )
        return redirect("ncc:usuario_editar", pk=usuario.pk)

    if request.method == "POST" and "salvar_permissoes" in request.POST:
        form = UsuarioPermissoesForm(request.POST, usuario_alvo=usuario, empresa=empresa)
        if form.is_valid():
            # Gate 1 (Sprint de Encerramento Definitivo): `form.aplicar()` já
            # abre seu PRÓPRIO `transaction.atomic()` (empresas/forms_ncc.py) —
            # mas ele fechava (e commitava) antes de a view chegar aos
            # `registrar_evento()` abaixo, deixando uma janela em que a
            # auditoria podia falhar com a mudança de permissões já
            # irreversível. Abrir um atomic aqui, envolvendo TAMBÉM
            # `form.aplicar()`, resolve isso — atomic aninhado usa savepoint,
            # então o comportamento de `aplicar()` sozinho não muda em nada.
            with transaction.atomic():
                filial_antes_id = usuario.filial_id
                perfis_antes = sorted(usuario.perfis_acesso.values_list("nome", flat=True))
                permissoes_antes = sorted(usuario.permissoes_individuais.values_list("codigo", flat=True))
                empresas_antes = sorted(
                    usuario.autorizacoes_empresa.filter(ativo=True).values_list("empresa__nome", flat=True)
                )
                _, resumo_filiais = form.aplicar()
                usuario.refresh_from_db()
                descricao = f"Permissões/limites de {usuario.get_full_name() or usuario.username} atualizados."
                # Fechamento Final (Seção 4.1): "registre na auditoria quem
                # mudou os vínculos, os valores anteriores e os novos" — o
                # antes/depois completo em JSON vem com a Central de Auditoria
                # (Fase 8); por ora, esta descrição já nomeia especificamente
                # o que mudou nas filiais, não só um "atualizado" genérico.
                if resumo_filiais["filiais_adicionadas"]:
                    descricao += f" Filiais autorizadas: +{', '.join(resumo_filiais['filiais_adicionadas'])}."
                if resumo_filiais["filiais_removidas"]:
                    descricao += f" Filiais revogadas: -{', '.join(resumo_filiais['filiais_removidas'])}."
                _registrar_log(request, empresa, "Usuários e Permissões", descricao)

                perfis_depois = sorted(usuario.perfis_acesso.values_list("nome", flat=True))
                permissoes_depois = sorted(usuario.permissoes_individuais.values_list("codigo", flat=True))
                empresas_depois = sorted(
                    usuario.autorizacoes_empresa.filter(ativo=True).values_list("empresa__nome", flat=True)
                )
                if (
                    perfis_antes != perfis_depois or permissoes_antes != permissoes_depois
                    or empresas_antes != empresas_depois
                    or resumo_filiais["filiais_adicionadas"] or resumo_filiais["filiais_removidas"]
                ):
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.USUARIO_PERMISSOES_ALTERADAS,
                        descricao=descricao,
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request), filial=usuario.filial,
                        modulo="usuarios", acao="permissoes", tipo_objeto="Usuario", id_objeto=usuario.pk,
                        estado_antes={
                            "perfis_acesso": perfis_antes, "permissoes_individuais": permissoes_antes,
                            "empresas_autorizadas": empresas_antes,
                        },
                        estado_depois={
                            "perfis_acesso": perfis_depois, "permissoes_individuais": permissoes_depois,
                            "empresas_autorizadas": empresas_depois,
                            "filiais_adicionadas": resumo_filiais["filiais_adicionadas"],
                            "filiais_removidas": resumo_filiais["filiais_removidas"],
                        },
                    )
                if usuario.filial_id != filial_antes_id:
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.USUARIO_FILIAL_PRINCIPAL_ALTERADA,
                        descricao=f"{usuario.get_full_name() or usuario.username} — Filial principal alterada.",
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request), filial=usuario.filial,
                        modulo="usuarios", acao="filial_principal", tipo_objeto="Usuario", id_objeto=usuario.pk,
                        estado_antes={"filial_id": filial_antes_id}, estado_depois={"filial_id": usuario.filial_id},
                    )
            messages.success(request, "Permissões do usuário atualizadas com sucesso.")
            return redirect("ncc:usuarios")
    else:
        form = UsuarioPermissoesForm(usuario_alvo=usuario, empresa=empresa)

    # Épico 2A (Etapa 03): permissões efetivas em linguagem de negócio.
    nomes_por_codigo = {p.codigo: p.nome for p in Permissao.objects.all()}
    permissoes_efetivas = [
        {"codigo": codigo, "nome": nomes_por_codigo.get(codigo, codigo),
         "descricao": DESCRICOES_PERMISSOES.get(codigo, "")}
        for codigo in sorted(permissoes_do_usuario(usuario))
    ]

    contexto = {
        "empresa": empresa,
        "usuario_alvo": usuario,
        "form_dados": form_dados,
        "form": form,
        "grupos_permissoes": _montar_grupos_permissoes(form),
        "grupos_filiais": _montar_grupos_filiais(form),
        "permissoes_efetivas": permissoes_efetivas,
    }
    return render(request, "empresas/ncc/usuario_form.html", contexto)


@permissao_required("ncc.acessar")
def ncc_perfis(request):
    empresa = empresa_ativa(request)
    perfis = PerfilAcesso.objects.filter(empresa__in=[empresa, None]).prefetch_related("permissoes")
    if request.method == "POST":
        form = PerfilAcessoForm(request.POST, empresa=empresa)
        if form.is_valid():
            with transaction.atomic():
                perfil = form.save()
                _registrar_log(request, empresa, "Usuários e Permissões", f'Perfil de acesso "{perfil.nome}" salvo.')
            messages.success(request, f'Perfil de acesso "{perfil.nome}" salvo com sucesso.')
            return redirect("ncc:perfis")
    else:
        form = PerfilAcessoForm(empresa=empresa)
    return render(request, "empresas/ncc/perfis.html", {"empresa": empresa, "perfis": perfis, "form": form})


@permissao_required("ncc.acessar")
def ncc_perfil_editar(request, pk):
    empresa = empresa_ativa(request)
    # Sprint de Melhorias 1 (segurança): só perfis DA empresa ativa. Antes um
    # perfil global (sem empresa, criado no /admin) podia ser editado — e
    # "adotado" — por qualquer cliente, mudando as permissões dos usuários
    # de OUTRAS empresas que o usavam.
    perfil = PerfilAcesso.objects.filter(pk=pk, empresa=empresa).first()
    if perfil is None:
        return redirect("ncc:perfis")
    if request.method == "POST":
        form = PerfilAcessoForm(request.POST, instance=perfil, empresa=empresa)
        if form.is_valid():
            with transaction.atomic():
                form.save()
                _registrar_log(request, empresa, "Usuários e Permissões", f'Perfil de acesso "{perfil.nome}" atualizado.')
            messages.success(request, "Perfil de acesso atualizado com sucesso.")
            return redirect("ncc:perfis")
    else:
        form = PerfilAcessoForm(instance=perfil, empresa=empresa)
    return render(request, "empresas/ncc/perfil_form.html", {"empresa": empresa, "perfil": perfil, "form": form})


@permissao_required("ncc.acessar")
def ncc_motor(request):
    empresa = empresa_ativa(request)
    config, _ = ConfiguracaoPlataforma.objects.get_or_create(empresa=empresa)
    return render(request, "empresas/ncc/motor.html", {"empresa": empresa, "config_plataforma": config})


@permissao_required("workflow.configurar")
def ncc_workflow(request):
    empresa = empresa_ativa(request)
    fluxos = FluxoAprovacao.objects.filter(empresa=empresa).prefetch_related("etapas")
    return render(request, "empresas/ncc/workflow.html", {"empresa": empresa, "fluxos": fluxos})


@permissao_required("workflow.configurar")
def ncc_workflow_editar(request, pk=None):
    empresa = empresa_ativa(request)
    fluxo = get_object_or_404(FluxoAprovacao, pk=pk, empresa=empresa) if pk else None
    if request.method == "POST":
        form = FluxoAprovacaoForm(request.POST, instance=fluxo)
        formset = EtapaFluxoFormSet(request.POST, instance=fluxo, form_kwargs={"empresa": empresa})
        if form.is_valid():
            with transaction.atomic():
                fluxo_salvo = form.save(commit=False)
                fluxo_salvo.empresa = empresa
                fluxo_salvo.save()
                formset = EtapaFluxoFormSet(request.POST, instance=fluxo_salvo, form_kwargs={"empresa": empresa})
                if formset.is_valid():
                    formset.save()
                    if fluxo_salvo.ativo:
                        # Um único fluxo ativo por empresa — regra simples que
                        # evita ambiguidade sobre qual fluxo governa a próxima
                        # solicitação.
                        FluxoAprovacao.objects.filter(empresa=empresa, ativo=True).exclude(pk=fluxo_salvo.pk).update(ativo=False)
                    _registrar_log(request, empresa, "Workflow", f'Fluxo de aprovação "{fluxo_salvo.nome}" salvo.')
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.WORKFLOW_ALTERADO,
                        descricao=f'Fluxo de aprovação "{fluxo_salvo.nome}" salvo.',
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="empresas", acao="workflow", tipo_objeto="FluxoAprovacao", id_objeto=fluxo_salvo.pk,
                        estado_depois={
                            "nome": fluxo_salvo.nome, "ativo": fluxo_salvo.ativo,
                            "etapas": [
                                {
                                    "ordem": e.ordem, "perfil_aprovador": e.perfil_aprovador,
                                    "valor_maximo": str(e.valor_maximo) if e.valor_maximo is not None else None,
                                    "prazo_dias": e.prazo_dias,
                                }
                                for e in fluxo_salvo.etapas.order_by("ordem")
                            ],
                        },
                    )
                    if fluxo_salvo.ativo:
                        messages.success(request, f'Fluxo "{fluxo_salvo.nome}" salvo e ATIVO — as próximas provisões acima do saldo seguem estas etapas.')
                    else:
                        # Rodada final: salvar sem marcar "Fluxo ativo" gravava o
                        # fluxo inativo em silêncio — as provisões seguiam em
                        # etapa única, ignorando as alçadas configuradas.
                        messages.warning(
                            request,
                            f'Fluxo "{fluxo_salvo.nome}" salvo como INATIVO: ele não é usado nas aprovações. '
                            'Para valer, edite o fluxo e marque "Fluxo ativo".',
                        )
                    return redirect("ncc:workflow")
    else:
        # Rodada final: um fluxo NOVO nasce marcado como ativo quando a
        # empresa ainda não tem nenhum fluxo ativo (o caso comum na
        # implantação) — antes nascia desmarcado e era salvo inativo.
        inicial = None
        if fluxo is None and not FluxoAprovacao.objects.filter(empresa=empresa, ativo=True).exists():
            inicial = {"ativo": True}
        form = FluxoAprovacaoForm(instance=fluxo, initial=inicial)
        formset = EtapaFluxoFormSet(instance=fluxo, form_kwargs={"empresa": empresa})
    return render(
        request, "empresas/ncc/workflow_form.html",
        {"empresa": empresa, "fluxo": fluxo, "form": form, "formset": formset},
    )


@permissao_required("ncc.acessar")
def ncc_compras(request):
    empresa = empresa_ativa(request)
    return render(request, "empresas/ncc/compras.html", {"empresa": empresa})


@permissao_required("ncc.acessar")
def ncc_dashboard(request):
    empresa = empresa_ativa(request)
    return render(request, "empresas/ncc/dashboard.html", {"empresa": empresa})


@permissao_required("ncc.acessar")
def ncc_notificacoes(request):
    empresa = empresa_ativa(request)
    # Crítico de UX/escopo (rodada 1): a tela listava Push, WhatsApp e
    # E-mail como "Preparado — não configurado" e prometia ativá-los "quando
    # o provedor for contratado" — integrações fora do escopo acordado com a
    # cliente (a única integração futura é o DDA). Mostra só o canal que
    # existe de verdade. Os contratos em notificacoes/canais.py continuam no
    # código, sem nenhuma promessa na interface.
    canais = [
        {"nome": "Sistema (sino no topo)", "status": "Ativo", "ativo": True},
    ]
    return render(request, "empresas/ncc/notificacoes.html", {"empresa": empresa, "canais": canais})


@permissao_required("ncc.acessar")
def ncc_integracoes(request):
    """Tela honesta de integrações (mudança de escopo para a nuvem): o
    NEXBUY é 100% web e NÃO se integra a ERP — receitas, receitas extras,
    custos fixos, custos variáveis, compras e provisões são lançados
    manualmente pela interface, e é assim que o sistema funciona hoje.

    A ÚNICA integração prevista é o DDA, ainda não conectada: nenhum botão
    de conectar, nenhum formulário de credencial, nenhum status fictício de
    "sincronizado". `habilitada` segue a flag `FEATURE_DDA` (sempre `False`
    por padrão) e só muda o rótulo — a automação não existe (o contrato
    fica em `finance_engine.interfaces.IntegracaoDDABase`)."""
    from django.conf import settings

    empresa = empresa_ativa(request)
    integracoes = [
        {
            "nome": "DDA", "subtitulo": "Débito Direto Autorizado",
            "rotulo_status": "Não conectado — integração prevista",
            "habilitada": settings.FEATURE_DDA,
            "descricao": (
                "Quando for conectado, o DDA vai trazer para a Agenda Financeira e para "
                "Contas a Pagar os boletos/títulos apresentados ao CNPJ da empresa, para o "
                "Financeiro conferir e vincular à compra ou provisão correspondente."
            ),
            "garantias": (
                "Nunca paga nada sozinho.",
                "Nunca cria custo, compra ou baixa de parcela automaticamente.",
                "Toda confirmação é uma decisão do Financeiro e fica registrada na auditoria.",
            ),
        },
    ]
    return render(request, "empresas/ncc/integracoes.html", {"empresa": empresa, "integracoes": integracoes})


@permissao_required("ncc.acessar")
def ncc_auditoria(request):
    empresa = empresa_ativa(request)
    contexto = {
        "empresa": empresa,
        "logs_configuracao": LogConfiguracao.objects.filter(empresa=empresa).select_related("usuario")[:30],
        "historico_compras": HistoricoCompra.objects.filter(compra__empresa=empresa).select_related("usuario", "compra")[:15],
        "historico_provisoes": HistoricoProvisao.objects.filter(provisao__empresa=empresa)
        .select_related("usuario", "provisao")
        .order_by("-criado_em")[:15],
    }
    return render(request, "empresas/ncc/auditoria.html", contexto)


@permissao_required("auditoria.ver")
def ncc_central_auditoria(request):
    """Central de Auditoria (Fechamento Final, Seção 8): une os 4
    mecanismos de auditoria (`RegistroAuditoria` novo + os 3 já existentes)
    numa única tela com filtro e paginação — aditiva à `ncc_auditoria`
    acima, que continua existindo do jeito que sempre esteve."""
    from datetime import datetime

    from auditoria.services import listar_eventos_auditoria

    empresa = empresa_ativa(request)

    categoria = request.GET.get("categoria", "")
    try:
        usuario_id = int(request.GET.get("usuario", "")) if request.GET.get("usuario") else None
    except ValueError:
        usuario_id = None
    data_inicio_str = request.GET.get("data_inicio", "")
    data_fim_str = request.GET.get("data_fim", "")
    try:
        pagina = int(request.GET.get("pagina", 1))
    except ValueError:
        pagina = 1
    try:
        filial_id = int(request.GET.get("filial", "")) if request.GET.get("filial") else None
    except ValueError:
        filial_id = None
    correlation_id = (request.GET.get("correlation_id") or "").strip()
    # Prompt 2 (pré-Etapa 02), Gate D (Seção 11): filtros novos do contrato
    # completo do Prompt 1 — todos strings cruas do GET, sem tabela de
    # apoio (os `<select>` do template já usam os mesmos `choices` do
    # model, então o valor chega pronto para o `.filter()`).
    modulo = (request.GET.get("modulo") or "").strip()
    acao_filtro = (request.GET.get("acao") or "").strip()
    tipo_objeto = (request.GET.get("tipo_objeto") or "").strip()
    origem_decisao = (request.GET.get("origem_decisao") or "").strip()
    resultado_filtro = (request.GET.get("resultado") or "").strip()
    autoaprovacao_filtro = request.GET.get("autoaprovacao") == "1"
    usuario_perfil_filtro = (request.GET.get("usuario_perfil") or "").strip()

    data_inicio = None
    data_fim = None
    try:
        if data_inicio_str:
            data_inicio = datetime.strptime(data_inicio_str, "%Y-%m-%d").date()
        if data_fim_str:
            data_fim = datetime.strptime(data_fim_str, "%Y-%m-%d").date()
    except ValueError:
        pass

    pagina_eventos = listar_eventos_auditoria(
        empresa, categoria=categoria, usuario_id=usuario_id, filial_id=filial_id, correlation_id=correlation_id,
        data_inicio=data_inicio, data_fim=data_fim, modulo=modulo, acao=acao_filtro, tipo_objeto=tipo_objeto,
        origem_decisao=origem_decisao, resultado=resultado_filtro, autoaprovacao=autoaprovacao_filtro,
        usuario_perfil=usuario_perfil_filtro, pagina=pagina,
    )

    usuarios_da_empresa = Usuario.objects.filter(empresa=empresa).order_by("first_name", "username")
    filiais_da_empresa = empresa.filiais.all().order_by("nome") if empresa else Filial.objects.none()

    contexto = {
        "empresa": empresa,
        "pagina_eventos": pagina_eventos,
        "usuarios_da_empresa": usuarios_da_empresa,
        "filiais_da_empresa": filiais_da_empresa,
        "filtro_categoria": categoria,
        "filtro_usuario": request.GET.get("usuario", ""),
        "filtro_data_inicio": data_inicio_str,
        "filtro_data_fim": data_fim_str,
        "filtro_filial": request.GET.get("filial", ""),
        "filtro_correlation_id": correlation_id,
        "filtro_modulo": modulo,
        "filtro_acao": acao_filtro,
        "filtro_tipo_objeto": tipo_objeto,
        "filtro_origem_decisao": origem_decisao,
        "filtro_resultado": resultado_filtro,
        "filtro_autoaprovacao": request.GET.get("autoaprovacao", ""),
        "filtro_usuario_perfil": usuario_perfil_filtro,
        "opcoes_resultado": RegistroAuditoria.Resultado.choices,
        "opcoes_origem_decisao": RegistroAuditoria.OrigemDecisao.choices,
        "opcoes_perfil": Usuario.Perfil.choices,
        "modulos_distintos": RegistroAuditoria.objects.filter(empresa=empresa).exclude(modulo="")
        .order_by("modulo").values_list("modulo", flat=True).distinct(),
        "acoes_distintas": RegistroAuditoria.objects.filter(empresa=empresa).exclude(acao="")
        .order_by("acao").values_list("acao", flat=True).distinct(),
        "tipos_objeto_distintos": RegistroAuditoria.objects.filter(empresa=empresa).exclude(tipo_objeto="")
        .order_by("tipo_objeto").values_list("tipo_objeto", flat=True).distinct(),
    }
    return render(request, "empresas/ncc/central_auditoria.html", contexto)
