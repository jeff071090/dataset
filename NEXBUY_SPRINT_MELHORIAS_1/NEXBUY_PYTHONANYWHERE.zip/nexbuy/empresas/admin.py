from django.contrib import admin

from core.utils import formatar_cnpj

from .models import ConfiguracaoPlataforma, Empresa, GrupoEmpresarial, IdentidadeVisual, LogConfiguracao


@admin.register(ConfiguracaoPlataforma)
class ConfiguracaoPlataformaAdmin(admin.ModelAdmin):
    list_display = ("empresa", "tema", "idioma", "fuso_horario", "parcelas_maximas")


@admin.register(LogConfiguracao)
class LogConfiguracaoAdmin(admin.ModelAdmin):
    list_display = ("criado_em", "empresa", "usuario", "area", "descricao")
    list_filter = ("empresa", "area")
    readonly_fields = ("empresa", "usuario", "area", "descricao")


@admin.register(GrupoEmpresarial)
class GrupoEmpresarialAdmin(admin.ModelAdmin):
    list_display = ("nome", "criado_em")
    search_fields = ("nome",)


class IdentidadeVisualInline(admin.StackedInline):
    model = IdentidadeVisual
    extra = 0
    max_num = 1


@admin.register(Empresa)
class EmpresaAdmin(admin.ModelAdmin):
    list_display = ("nome", "razao_social", "cnpj_formatado", "segmento", "cidade", "estado", "grupo", "ativo")
    list_filter = ("ativo", "segmento", "grupo", "estado")
    # Gate pré-Etapa 10 (S1-1, item 3): `cnpj` agora é persistido só com
    # dígitos — a busca continua funcionando para quem digita só números;
    # buscar com pontuação/máscara não bate mais (comportamento aceitável,
    # já documentado — ver inventário de migração do CNPJ canônico).
    search_fields = ("nome", "razao_social", "cnpj")
    inlines = [IdentidadeVisualInline]

    @admin.display(description="CNPJ", ordering="cnpj")
    def cnpj_formatado(self, empresa):
        return formatar_cnpj(empresa.cnpj)
