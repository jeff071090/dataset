"""Formulários do Assistente de Implantação (Épico 13 — CORE 1.0).

Cada etapa do wizard tem um form pequeno e explícito. Nenhum form aqui
grava sozinho — quem persiste é a view do wizard, sempre através dos
models/services existentes (nenhuma regra nova de negócio)."""
import re

from django import forms
from django.contrib.auth.password_validation import validate_password

from core.choices import UF_CHOICES
from core.forms import BootstrapFormMixin, MoedaFormMixin
from empresas.models import Empresa
from financeiro.models import ConfiguracaoFinanceira, DiaOperacional
from usuarios.models import Usuario


def _somente_digitos(cnpj: str) -> str:
    return re.sub(r"\D", "", cnpj or "")


def _validar_cnpj_nao_cadastrado(cnpj: str) -> str:
    """Sprint de Correções Críticas (Seção 4) — rejeita explicitamente um
    CNPJ já cadastrado em QUALQUER empresa do banco, em vez de deixar o
    wizard reaproveitar silenciosamente o registro existente
    (`get_or_create`). Compara por dígitos (ignora pontuação) para não
    deixar passar o mesmo CNPJ digitado com formatação diferente.

    Gate pré-Etapa 10 (S1-1): também valida o dígito verificador — antes só
    checava duplicidade, então um CNPJ com dígitos inválidos (mas inédito
    no banco) passava direto. Mesmo validador de `filiais.Filial`."""
    from core.validators import cnpj_e_valido

    cnpj = (cnpj or "").strip()
    if cnpj and not cnpj_e_valido(cnpj):
        raise forms.ValidationError("Este CNPJ não é válido — confira os dígitos.")
    digitos = _somente_digitos(cnpj)
    if digitos and any(_somente_digitos(existente) == digitos for existente in Empresa.objects.values_list("cnpj", flat=True)):
        raise forms.ValidationError(
            "Este CNPJ já está cadastrado no NEXBUY. Se você precisa receber acesso a essa empresa, "
            "utilize a gestão de usuários e autorizações."
        )
    return cnpj


class WizardEmpresaForm(BootstrapFormMixin, forms.Form):
    grupo_nome = forms.CharField(label="Nome do grupo econômico", max_length=150)
    nome = forms.CharField(label="Nome Fantasia", max_length=200)
    razao_social = forms.CharField(label="Razão Social", max_length=200, required=False)
    cnpj = forms.CharField(label="CNPJ", max_length=18)
    cidade = forms.CharField(label="Cidade", max_length=100, required=False)
    estado = forms.ChoiceField(label="Estado", choices=UF_CHOICES, required=False)
    filial_nome = forms.CharField(label="Nome da 1ª filial", max_length=150, initial="Matriz")

    def clean_cnpj(self):
        return _validar_cnpj_nao_cadastrado(self.cleaned_data["cnpj"])


class WizardCnpjForm(BootstrapFormMixin, forms.Form):
    nome = forms.CharField(label="Nome Fantasia", max_length=200)
    cnpj = forms.CharField(label="CNPJ", max_length=18)
    razao_social = forms.CharField(label="Razão Social", max_length=200, required=False)

    def clean_cnpj(self):
        return _validar_cnpj_nao_cadastrado(self.cleaned_data["cnpj"])


class WizardUsuarioForm(BootstrapFormMixin, forms.Form):
    username = forms.CharField(label="Usuário (login)", max_length=150)
    first_name = forms.CharField(label="Nome", max_length=150)
    last_name = forms.CharField(label="Sobrenome", max_length=150, required=False)
    perfil = forms.ChoiceField(label="Perfil", choices=Usuario.Perfil.choices)
    senha = forms.CharField(label="Senha", widget=forms.PasswordInput, min_length=8)

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if Usuario.objects.filter(username=username).exists():
            raise forms.ValidationError("Já existe um usuário com este login.")
        return username

    def clean(self):
        dados = super().clean()
        # Sprint de Melhorias 1 (segurança): mesmas regras de senha do resto
        # do sistema (AUTH_PASSWORD_VALIDATORS, inclusive a da senha pública
        # da demonstração) — antes bastavam 6 caracteres.
        senha = dados.get("senha")
        if senha:
            candidato = Usuario(
                username=dados.get("username") or "", first_name=dados.get("first_name") or "",
                last_name=dados.get("last_name") or "",
            )
            try:
                validate_password(senha, user=candidato)
            except forms.ValidationError as erro:
                self.add_error("senha", erro)
        return dados


class WizardCompradorForm(WizardUsuarioForm):
    """Etapa 4 — igual à de usuários, com o perfil travado em Comprador."""

    perfil = forms.CharField(widget=forms.HiddenInput, initial=Usuario.Perfil.COMPRADOR, required=False)

    def clean_perfil(self):
        return Usuario.Perfil.COMPRADOR


class WizardFinanceiroForm(MoedaFormMixin, BootstrapFormMixin, forms.Form):
    campos_moeda = ("faturamento",)

    faturamento = forms.DecimalField(label="Faturamento previsto do mês", max_digits=14, decimal_places=2)


class WizardCalendarioForm(BootstrapFormMixin, forms.Form):
    data = forms.DateField(label="Data", widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"))
    tipo = forms.ChoiceField(label="Tipo do dia", choices=DiaOperacional.Tipo.choices, initial=DiaOperacional.Tipo.FERIADO)
    observacao = forms.CharField(label="Observação", max_length=200, required=False)


class WizardCapacidadeForm(BootstrapFormMixin, forms.Form):
    percentual_compras = forms.DecimalField(
        label="Percentual destinado às compras (%)", max_digits=5, decimal_places=2, initial=30
    )
    percentual_seguranca = forms.DecimalField(
        label="Percentual de segurança (%)", max_digits=5, decimal_places=2, initial=0
    )
    dias_uteis_manual = forms.IntegerField(
        label="Dias úteis (manual)", required=False, min_value=1,
        help_text="Em branco = calcular automaticamente pelo Calendário Operacional.",
    )


class WizardAprovacoesForm(BootstrapFormMixin, forms.Form):
    regra_excesso = forms.ChoiceField(
        label="Ao ultrapassar o limite diário", choices=ConfiguracaoFinanceira.RegraExcesso.choices,
        initial=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
    )
    criar_fluxo_padrao = forms.BooleanField(
        label="Criar fluxo de aprovação padrão (Gerente → Financeiro)", required=False, initial=False,
        help_text="Provisões acima do saldo passarão pelo Gerente e, acima da alçada dele, pelo Financeiro.",
    )
