"""Checklist Guiado de Configuração Inicial (pós-Primeiro Acesso Seguro).

Depois que o Proprietário conclui o `/primeiro-acesso/`, o banco fica quase
vazio — só existem a Empresa, a Filial Matriz e o próprio usuário
Proprietário. Este módulo calcula, para cada um dos 13 passos recomendados
de implantação, se ele já foi cumprido — SEMPRE por consulta real ao banco
de dados da Empresa ativa, nunca por uma flag "concluído" salva à mão que
poderia ficar desatualizada ou mentir sobre o estado real do sistema.

Cada critério abaixo foi decidido lendo o model real envolvido (nunca
adivinhado) — a justificativa de cada decisão está no comentário do próprio
item. Nenhuma tela do sistema é bloqueada por este checklist estar
incompleto: ele é só um guia, sempre consultável em `/ncc/checklist/`.
"""
from django.urls import reverse

from auditoria.models import RegistroAuditoria
from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from empresas.models import ConfiguracaoPlataforma, LogConfiguracao
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, DiaOperacional, Receita
from gestao_compras.models import Provisao
from usuarios.models import Usuario, UsuarioFilial


def calcular_checklist(empresa) -> list[dict]:
    """Devolve a lista dos 13 itens do checklist de implantação, na ordem
    sugerida, cada um com `concluido` calculado agora mesmo (sem cache) a
    partir do banco. `empresa` deve ser a Empresa ativa do contexto
    (`core.contexto.empresa_ativa`) — todo critério é escopado por ela, o
    que garante que dados de outra Empresa/Grupo nunca marquem um item
    desta Empresa como concluído (isolamento multiempresa)."""
    if empresa is None:
        return []

    itens = []

    # ------------------------------------------------------------------
    # 1) Empresa cadastrada — sempre verdadeiro aqui: `empresa_ativa()` só
    # devolve uma Empresa quando ela já existe (criada no Primeiro Acesso
    # ou depois). Não há como chegar a este checklist sem uma Empresa.
    # ------------------------------------------------------------------
    itens.append({
        "numero": 1,
        "titulo": "Empresa cadastrada",
        "descricao": "Dados básicos da Empresa (nome, CNPJ, endereço) — criados no Primeiro Acesso.",
        "concluido": True,
        "cta_url": reverse("empresas:editar"),
        "cta_label": "Ver/editar Empresa",
    })

    # ------------------------------------------------------------------
    # 2) Filial principal fiscalmente completa — usa a property
    # `Filial.cadastro_completo` (filiais/models.py), que já exige CNPJ,
    # Inscrição Estadual (ou isenção marcada), endereço completo
    # (endereço+número+bairro+cidade+estado+CEP), razão social, telefone e
    # um responsável identificado. A Filial criada pelo Primeiro Acesso só
    # tem `nome` — nasce com `cadastro_completo=False` até o Proprietário
    # completar os dados fiscais.
    # ------------------------------------------------------------------
    filial_matriz = empresa.filiais.filter(tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ).first()
    if filial_matriz is None:
        # Defensivo: não deveria acontecer (Primeiro Acesso sempre cria uma
        # Matriz), mas se acontecer, cai para a lista de Filiais em vez de
        # um link quebrado para um pk inexistente.
        cta_url_filial = reverse("ncc:filiais")
    else:
        cta_url_filial = reverse("ncc:filial_editar", args=[filial_matriz.pk])
    itens.append({
        "numero": 2,
        "titulo": "Filial principal fiscalmente completa",
        "descricao": "CNPJ, Inscrição Estadual, endereço completo, razão social, telefone e responsável da Matriz.",
        "concluido": bool(filial_matriz and filial_matriz.cadastro_completo),
        "cta_url": cta_url_filial,
        "cta_label": "Completar cadastro da Filial",
    })

    # ------------------------------------------------------------------
    # 3) Regras gerais configuradas — `ConfiguracaoPlataforma` já nasce
    # junto da Empresa no Primeiro Acesso (`core/views_primeiro_acesso.py`
    # grava o fuso horário escolhido ali mesmo), então a EXISTÊNCIA do
    # registro já reflete uma decisão real tomada pelo Proprietário (não é
    # um `get_or_create` silencioso de outra tela) — por isso a existência
    # basta como critério, sem exigir nenhum campo extra preenchido.
    # ------------------------------------------------------------------
    config_plataforma = ConfiguracaoPlataforma.objects.filter(empresa=empresa).first()
    itens.append({
        "numero": 3,
        "titulo": "Regras gerais configuradas",
        "descricao": "Fuso horário, idioma, horário de funcionamento e política de parcelamento.",
        "concluido": config_plataforma is not None,
        "cta_url": reverse("ncc:gerais"),
        "cta_label": "Configurar regras gerais",
    })

    # ------------------------------------------------------------------
    # 4) Configuração financeira definida — diferente do item 3,
    # `ConfiguracaoFinanceira` NÃO é criada no Primeiro Acesso (conferido
    # em `core/views_primeiro_acesso.py`), mas a tela
    # `financeiro.views.configuracao_financeira` faz
    # `ConfiguracaoFinanceira.objects.get_or_create(empresa=empresa)` já no
    # GET — ou seja, só VISITAR a página (sem salvar nada) já cria o
    # registro com os valores padrão do model. Por isso a mera existência
    # do registro não é um sinal confiável de que a empresa foi realmente
    # configurada.
    #
    # Correção (Sprint de Correção do Checklist Guiado): a versão anterior
    # comparava `percentual_compras` contra o valor padrão do model (30%)
    # como sentinela de "ainda não configurado" — isso deixava o item
    # PERMANENTEMENTE pendente para um cliente que, de propósito, decidiu
    # manter 30% como o percentual real desejado (coincidência plausível,
    # não um sinal de "nunca configurado"). O sinal correto não é o VALOR
    # salvo, é o FATO de o formulário ter sido submetido:
    # `financeiro.views.configuracao_financeira` agora grava um
    # `LogConfiguracao` (área "Configuração Financeira") em TODO POST
    # válido daquela tela, mesmo quando nenhum valor muda — só a
    # EXISTÊNCIA desse log (nunca um `get_or_create` de GET) distingue "o
    # Proprietário/Financeiro salvou o formulário, seja qual for o valor"
    # de "ninguém nunca salvou nada".
    # ------------------------------------------------------------------
    config_financeira = ConfiguracaoFinanceira.objects.filter(empresa=empresa).first()
    formulario_financeiro_salvo = LogConfiguracao.objects.filter(
        empresa=empresa, area="Configuração Financeira",
    ).exists()
    itens.append({
        "numero": 4,
        "titulo": "Configuração financeira definida",
        "descricao": (
            "Percentual destinado às compras, dias úteis, saldo acumulado e regra de excesso de limite — "
            "salve o formulário ao menos uma vez, mesmo mantendo os valores padrão."
        ),
        "concluido": bool(config_financeira is not None and formulario_financeiro_salvo),
        "cta_url": reverse("financeiro:configuracao"),
        "cta_label": "Abrir Capacidade Financeira",
    })

    # ------------------------------------------------------------------
    # 5) Receita/faturamento inicial cadastrado — existe pelo menos um
    # `financeiro.models.Receita` para alguma Filial desta Empresa.
    # `Receita.empresa` é preenchido automaticamente em `Receita.save()`
    # a partir de `self.filial.empresa` — é a mesma Empresa sempre, então
    # filtrar por `empresa=empresa` já é exatamente "para alguma Filial da
    # empresa ativa".
    # ------------------------------------------------------------------
    itens.append({
        "numero": 5,
        "titulo": "Receita/faturamento inicial cadastrado",
        "descricao": "Pelo menos um mês de faturamento lançado — a base para o Motor Financeiro calcular a capacidade de compra.",
        "concluido": Receita.objects.filter(empresa=empresa).exists(),
        "cta_url": reverse("financeiro:receita_create"),
        "cta_label": "Cadastrar Receita",
    })

    # ------------------------------------------------------------------
    # 6) Categorias cadastradas — pelo menos uma `cadastros.models.
    # Categoria` ATIVA (`ativo=True`, herdado de `ModeloAtivavel`) para a
    # Empresa. Uma categoria desativada não conta: ela não pode ser
    # escolhida em uma Compra nova, então não representa um cadastro
    # utilizável.
    # ------------------------------------------------------------------
    itens.append({
        "numero": 6,
        "titulo": "Categorias cadastradas",
        "descricao": "Pelo menos uma categoria de compra ativa — toda Compra/Provisão exige uma categoria.",
        "concluido": Categoria.objects.filter(empresa=empresa, ativo=True).exists(),
        "cta_url": reverse("cadastros:categoria_list"),
        "cta_label": "Cadastrar Categoria",
    })

    # ------------------------------------------------------------------
    # 7) Fornecedores cadastrados — mesmo raciocínio do item 6, aplicado a
    # `compras.models.Fornecedor` (também `ModeloAtivavel`).
    # ------------------------------------------------------------------
    itens.append({
        "numero": 7,
        "titulo": "Fornecedores cadastrados",
        "descricao": "Pelo menos um fornecedor ativo — toda Compra/Provisão exige um fornecedor.",
        "concluido": Fornecedor.objects.filter(empresa=empresa, ativo=True).exists(),
        "cta_url": reverse("compras:fornecedor_list"),
        "cta_label": "Cadastrar Fornecedor",
    })

    # ------------------------------------------------------------------
    # 8) Usuários e perfis cadastrados — pelo menos 1 usuário ALÉM do
    # Proprietário (Gerente, Financeiro ou Comprador) vinculado a esta
    # Empresa. `Usuario.empresa` é a Empresa principal do usuário
    # (usuarios/models.py) — o mesmo campo usado em todo o resto do NCC
    # (ex.: `ncc_usuarios`).
    # ------------------------------------------------------------------
    itens.append({
        "numero": 8,
        "titulo": "Usuários e perfis cadastrados",
        "descricao": "Pelo menos um usuário além do Proprietário — Gerente, Financeiro ou Comprador.",
        "concluido": Usuario.objects.filter(empresa=empresa).exclude(perfil=Usuario.Perfil.PROPRIETARIO).exists(),
        "cta_url": reverse("ncc:usuario_novo"),
        "cta_label": "Cadastrar Usuário",
    })

    # ------------------------------------------------------------------
    # 9) Compradores com Filiais e limites definidos — pelo menos um
    # usuário Comprador desta Empresa com um `usuarios.models.
    # UsuarioFilial` ATIVO (o vínculo operacional real que autoriza o
    # Comprador a operar naquela Filial — sem ele, `filiais_autorizadas_
    # para()` não devolve nenhuma Filial para esse usuário, e ele não
    # consegue nem lançar Compra).
    # Decisão sobre o limite individual (`usuarios.models.UsuarioEmpresa.
    # limite_compra`, financeiro/models não tem esse campo — ele mora em
    # `usuarios`): o próprio model documenta, no `help_text`, que o campo é
    # OPCIONAL por natureza ("Deixe em branco para não limitar" — o
    # comprador simplesmente usa o limite da capacidade da Filial). Exigir
    # um limite individual preenchido tornaria este item permanentemente
    # pendente em empresas pequenas que nunca vão querer um teto por
    # pessoa, o que não reflete "faltou configurar" de verdade. Por isso o
    # critério fica só na Filial vinculada e ativa — o limite individual é
    # tratado como uma personalização opcional, não como pré-requisito.
    # ------------------------------------------------------------------
    compradores_ids = Usuario.objects.filter(
        empresa=empresa, perfil=Usuario.Perfil.COMPRADOR
    ).values_list("pk", flat=True)
    itens.append({
        "numero": 9,
        "titulo": "Compradores com Filiais e limites definidos",
        "descricao": (
            "Pelo menos um Comprador vinculado a uma Filial (limite individual é opcional — "
            "sem ele, vale o limite da capacidade da própria Filial)."
        ),
        "concluido": UsuarioFilial.objects.filter(usuario_id__in=compradores_ids, ativo=True).exists(),
        "cta_url": reverse("financeiro:capacidade_compradores"),
        "cta_label": "Definir Filiais e limites",
    })

    # ------------------------------------------------------------------
    # 10) Calendário operacional revisado — `financeiro.models.
    # DiaOperacional` só guarda EXCEÇÕES à regra padrão (dia útil = seg-sex,
    # sábado/domingo já tratados automaticamente pelo Motor Financeiro sem
    # precisar de registro nenhum — ver docstring do model). Isso significa
    # que não existe, no banco, NENHUM jeito de distinguir "o Proprietário
    # olhou o calendário e decidiu que não precisa de exceção nenhuma" de
    # "o Proprietário nunca nem abriu essa tela" — as duas situações
    # produzem exatamente zero registros SE só olharmos para
    # `DiaOperacional`.
    #
    # Correção (Sprint de Correção do Checklist Guiado): em vez de
    # inventar um estado "visitado" que o banco não registra, adicionamos
    # uma confirmação EXPLÍCITA do Proprietário — botão "Confirmar
    # calendário revisado" na própria tela do Calendário Operacional
    # (`financeiro.views.calendario_operacional`, ação
    # `confirmar_revisao`) — que grava um `RegistroAuditoria` real
    # (categoria `CALENDARIO_OPERACIONAL_REVISADO`: quem confirmou,
    # quando, Empresa). O item conclui com QUALQUER UM dos dois sinais
    # reais e no banco: uma exceção cadastrada OU essa confirmação
    # explícita registrada.
    # ------------------------------------------------------------------
    calendario_revisado_confirmado = RegistroAuditoria.objects.filter(
        empresa=empresa, categoria=RegistroAuditoria.Categoria.CALENDARIO_OPERACIONAL_REVISADO,
    ).exists()
    itens.append({
        "numero": 10,
        "titulo": "Calendário operacional revisado",
        "descricao": (
            "Cadastre feriados, bloqueios ou dias especiais, se houver — ou, se a empresa realmente não "
            "precisa de nenhuma exceção, o Proprietário pode confirmar a revisão direto na tela do "
            "Calendário Operacional."
        ),
        "concluido": bool(
            DiaOperacional.objects.filter(empresa=empresa).exists() or calendario_revisado_confirmado
        ),
        "cta_url": reverse("financeiro:calendario_operacional"),
        "cta_label": "Revisar Calendário Operacional",
    })

    # ------------------------------------------------------------------
    # 11) Primeira compra registrada — pelo menos 1 `compras.models.Compra`
    # para a Empresa, em QUALQUER status (Aprovada/Pendente/Bloqueada/
    # Rejeitada) — o item confirma que o fluxo de lançar uma Compra já foi
    # usado, não que ela foi aprovada.
    #
    # Crítico de UX (rodada 1): o item se chamava "Primeira Compra
    # simulada" e pedia uma "Compra de teste" — o oposto da Central de
    # Ajuda/MANUAL/PRIMEIROS_PASSOS: toda compra gravada é REAL (entra na
    # DRE, nos limites e nos relatórios) e não pode ser apagada pela tela;
    # para experimentar existe o Simulador. No banco de produção limpo, quem
    # seguisse o checklist criava uma compra fictícia irreversível. O texto
    # agora diz isso e o card traz um atalho secundário para o Simulador.
    # ------------------------------------------------------------------
    itens.append({
        "numero": 11,
        "titulo": "Primeira compra registrada",
        "descricao": (
            "Registre a primeira compra REAL da farmácia — ela não pode ser apagada pela tela e entra na DRE, "
            "nos limites e nos relatórios. Para só experimentar, use o Simulador (não grava nada)."
        ),
        "concluido": Compra.objects.filter(empresa=empresa).exists(),
        "cta_url": reverse("compras:nova"),
        "cta_label": "Lançar Compra",
        "cta_secundario_url": reverse("compras:simulacao"),
        "cta_secundario_label": "Abrir o Simulador",
    })

    # ------------------------------------------------------------------
    # 12) Primeira provisão registrada — mesmo raciocínio do item 11, com
    # `gestao_compras.models.Provisao` (uma provisão gravada também é real:
    # reserva saldo do dia e pode seguir para aprovação).
    # ------------------------------------------------------------------
    itens.append({
        "numero": 12,
        "titulo": "Primeira provisão registrada",
        "descricao": (
            "Planeje a primeira provisão REAL (uma compra futura) — ela reserva o saldo do dia e, se passar do "
            "limite, segue para aprovação; não pode ser apagada pela tela. Para só experimentar, use o Simulador."
        ),
        "concluido": Provisao.objects.filter(empresa=empresa).exists(),
        "cta_url": reverse("gestao_compras:nova_provisao"),
        "cta_label": "Planejar Provisão",
        "cta_secundario_url": reverse("compras:simulacao"),
        "cta_secundario_label": "Abrir o Simulador",
    })

    # ------------------------------------------------------------------
    # 13) Primeiro relatório visualizado — antes, "visualizar uma tela" não
    # deixava nenhum rastro em nenhum model de negócio, então não existia
    # consulta ao banco capaz de confirmar "o Proprietário já olhou um
    # relatório" — o item ficava SEMPRE pendente, mesmo depois de o
    # relatório ser genuinamente aberto.
    #
    # Correção (Sprint de Correção do Checklist Guiado):
    # `compras.views.relatorio_compras_por_filial` agora grava um
    # `RegistroAuditoria` real (categoria `RELATORIO_VISUALIZADO`) na
    # PRIMEIRA visita da Empresa a essa tela — só a primeira (a view
    # confere a existência antes de criar): a auditoria existe para
    # registrar decisões/mudanças de configuração, não tráfego de página,
    # então visitas seguintes não empilham eventos idênticos. Nenhum
    # estado de sessão entra aqui — o sinal mora no banco, escopado pela
    # Empresa, exatamente como todo outro item deste checklist.
    # ------------------------------------------------------------------
    relatorio_visualizado = RegistroAuditoria.objects.filter(
        empresa=empresa, categoria=RegistroAuditoria.Categoria.RELATORIO_VISUALIZADO,
    ).exists()
    itens.append({
        "numero": 13,
        "titulo": "Primeiro relatório visualizado",
        "descricao": (
            "Dê uma olhada no relatório de Compras por Filial — a primeira visita já marca este item "
            "como concluído."
        ),
        "concluido": relatorio_visualizado,
        "cta_url": reverse("compras:relatorio_por_filial"),
        "cta_label": "Ver Relatório por Filial",
    })

    return itens


def resumo_checklist(itens: list[dict]) -> dict:
    """Pequeno resumo agregado (contagem/percentual) usado pela view e pelo
    template — mantém a conta num único lugar, nunca duplicada entre
    `views_ncc.py` e o template."""
    total = len(itens)
    concluidos = sum(1 for item in itens if item["concluido"])
    percentual = round((concluidos / total) * 100) if total else 0
    return {"total": total, "concluidos": concluidos, "percentual": percentual}
