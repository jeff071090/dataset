"""Formulários do NEXBUY Control Center e do RBAC (Épicos 7 e 12)."""
from django import forms
from django.contrib.auth.password_validation import validate_password
from django.forms import inlineformset_factory

from core.forms import BootstrapFormMixin, MoedaFormMixin
from filiais.models import Filial
from gestao_compras.models import EtapaFluxo, FluxoAprovacao
from usuarios.models import PerfilAcesso, Permissao, Usuario, UsuarioEmpresa, UsuarioFilial

from .models import ConfiguracaoPlataforma, Empresa


def _garantir_vinculo_filial_ativo(usuario):
    """Fechamento Final (Prompt 1, Seção 4.1, último item): "o campo
    Usuario.filial permanece como filial principal, mas deve
    necessariamente pertencer ao conjunto autorizado do usuário" — sempre
    que a filial principal é definida ou trocada (cadastro novo ou edição
    de dados), esta função garante que exista um `UsuarioFilial` ATIVO
    correspondente, reativando o registro existente em vez de duplicá-lo.
    Nunca desativa a filial anterior — trocar a principal não revoga por
    si só o acesso a outra filial onde o usuário já estava autorizado; a
    revogação é sempre uma ação explícita na aba "Permissões e acesso"."""
    if usuario.is_proprietario or not usuario.filial_id:
        return
    vinculo, criado = UsuarioFilial.objects.get_or_create(
        usuario=usuario, filial_id=usuario.filial_id, defaults={"ativo": True},
    )
    if not criado and not vinculo.ativo:
        vinculo.ativo = True
        vinculo.save(update_fields=["ativo", "atualizado_em"])


class ConfiguracaoPlataformaForm(BootstrapFormMixin, forms.ModelForm):
    """Sprint de Consolidação (Gate 2A, Parte 9): dos 6 campos deste form,
    só `parcelas_maximas` tem efeito real (`compras.forms.CompraForm`
    valida o prazo Personalizado contra ele). Os outros 5 (tema, idioma,
    fuso horário, horário de abertura/fechamento) não são lidos por
    NENHUMA outra parte do sistema hoje — mantê-los editáveis deixaria o
    usuário "salvar" algo que não faz nada. `disabled=True` é a forma
    correta do Django para isso: o campo aparece (mostra o valor atual/
    default, documentando o que está planejado), mas o navegador não
    permite alterá-lo e o Django ignora qualquer valor de POST para ele,
    usando sempre o valor já salvo — nunca falsifica uma mudança aceita."""

    CAMPOS_SEM_EFEITO_REAL = ("tema", "idioma", "fuso_horario", "horario_abertura", "horario_fechamento")

    class Meta:
        model = ConfiguracaoPlataforma
        fields = [
            "tema", "idioma", "fuso_horario", "horario_abertura", "horario_fechamento", "parcelas_maximas",
            "permitir_autoaprovacao", "justificativa_autoaprovacao",
        ]
        widgets = {
            "horario_abertura": forms.TimeInput(attrs={"type": "time"}, format="%H:%M"),
            "horario_fechamento": forms.TimeInput(attrs={"type": "time"}, format="%H:%M"),
            "justificativa_autoaprovacao": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nome in self.CAMPOS_SEM_EFEITO_REAL:
            self.fields[nome].disabled = True
            self.fields[nome].help_text = "Em breve — ainda sem efeito no sistema."
        self.fields["permitir_autoaprovacao"].required = False
        self.fields["justificativa_autoaprovacao"].required = False

    def clean(self):
        """Fechamento Final (Prompt 1, Seção 6): "autoaprovação controlada"
        precisa ser EXPLICITAMENTE justificada — nunca liga sozinha sem uma
        razão registrada para auditoria."""
        cleaned = super().clean()
        if cleaned.get("permitir_autoaprovacao") and not cleaned.get("justificativa_autoaprovacao", "").strip():
            self.add_error(
                "justificativa_autoaprovacao",
                "Obrigatório explicar o motivo para ligar a autoaprovação controlada.",
            )
        return cleaned


class PerfilAcessoForm(BootstrapFormMixin, forms.ModelForm):
    """Perfil de acesso reutilizável: nome + conjunto de permissões."""

    class Meta:
        model = PerfilAcesso
        fields = ["nome", "descricao", "permissoes"]
        widgets = {"permissoes": forms.CheckboxSelectMultiple}

    def __init__(self, *args, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.empresa = empresa
        self.fields["permissoes"].queryset = Permissao.objects.all()
        self.fields["descricao"].required = False

    def save(self, commit=True):
        perfil = super().save(commit=False)
        if perfil.empresa_id is None and self.empresa is not None:
            perfil.empresa = self.empresa
        if commit:
            perfil.save()
            self.save_m2m()
        return perfil


class UsuarioDadosForm(BootstrapFormMixin, forms.ModelForm):
    """Sprint de Consolidação (Gate 2A, Parte 5): dados básicos e status do
    usuário — nome, e-mail, perfil, filial e ativo/inativo. Separado do
    form de permissões (`UsuarioPermissoesForm`, abaixo): grava campos
    simples do próprio `Usuario`, sem tocar nas 3 relações de RBAC."""

    class Meta:
        model = Usuario
        fields = ["first_name", "last_name", "email", "perfil", "filial", "is_active"]
        labels = {
            "first_name": "Nome", "last_name": "Sobrenome", "email": "E-mail",
            "perfil": "Perfil", "filial": "Filial", "is_active": "Usuário ativo",
        }

    def __init__(self, *args, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["first_name"].required = True
        self.fields["email"].required = True
        if empresa is not None:
            self.fields["filial"].queryset = empresa.filiais.filter(ativo=True)
        self.fields["filial"].help_text = "Obrigatória para Gerente, Financeiro e Comprador."

    def clean(self):
        dados = super().clean()
        perfil = dados.get("perfil")
        if perfil and perfil != Usuario.Perfil.PROPRIETARIO and not dados.get("filial"):
            self.add_error("filial", "Selecione a filial deste usuário.")
        return dados

    def save(self, commit=True):
        usuario = super().save(commit=commit)
        if commit:
            _garantir_vinculo_filial_ativo(usuario)
        return usuario


class UsuarioPermissoesForm(BootstrapFormMixin, forms.Form):
    """Edição RBAC de um usuário: perfis de acesso, permissões individuais,
    empresas autorizadas, filiais autorizadas e limite de compra na
    empresa ativa. Um form dedicado (não ModelForm) porque grava em 4
    relações diferentes — `.aplicar()` é a "função de serviço central"
    pedida pelo Fechamento Final (Seção 4.1), toda dentro de uma única
    `transaction.atomic()`."""

    perfis_acesso = forms.ModelMultipleChoiceField(
        queryset=PerfilAcesso.objects.none(), required=False,
        widget=forms.CheckboxSelectMultiple, label="Perfis de acesso",
    )
    permissoes_individuais = forms.ModelMultipleChoiceField(
        queryset=Permissao.objects.all(), required=False,
        widget=forms.CheckboxSelectMultiple, label="Permissões individuais",
    )
    empresas_autorizadas = forms.ModelMultipleChoiceField(
        queryset=Empresa.objects.none(), required=False,
        widget=forms.CheckboxSelectMultiple, label="Empresas autorizadas (além da principal)",
    )
    # Declarado DEPOIS de `empresas_autorizadas` de propósito: o Django
    # roda `clean_<campo>` na ordem de declaração, então
    # `clean_filiais_autorizadas` (abaixo) já encontra
    # `cleaned_data["empresas_autorizadas"]` pronto — permite autorizar uma
    # Empresa nova e já marcar filiais dela na MESMA submissão.
    filiais_autorizadas = forms.ModelMultipleChoiceField(
        queryset=Filial.objects.none(), required=False,
        widget=forms.CheckboxSelectMultiple, label="Filiais autorizadas",
        help_text=(
            "Em quais filiais este usuário pode lançar Compras, Provisões e ver dados financeiros. "
            "O Proprietário não precisa de seleção — já enxerga todas automaticamente."
        ),
    )
    limite_compra = forms.DecimalField(
        label="Limite de compra individual (empresa ativa)", max_digits=14, decimal_places=2, required=False,
        help_text=(
            "Dotação por dia: quando a soma das compras do dia deste comprador passa deste valor, "
            "a compra vai para aprovação. Em branco = sem limite individual (vale o limite da filial)."
        ),
    )

    def __init__(self, *args, usuario_alvo=None, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.usuario_alvo = usuario_alvo
        self.empresa = empresa
        self.fields["perfis_acesso"].queryset = PerfilAcesso.objects.filter(empresa__in=[empresa, None])
        # Sprint de Correções Críticas (Seção 5): o Proprietário só pode
        # autorizar Empresas do MESMO Grupo Empresarial do usuário-alvo —
        # nunca qualquer empresa do banco (de outro cliente/grupo).
        self.empresas_permitidas = (
            usuario_alvo.empresas_do_grupo().exclude(pk=usuario_alvo.empresa_id)
            if usuario_alvo and usuario_alvo.empresa_id
            else Empresa.objects.none()
        )
        self.fields["empresas_autorizadas"].queryset = self.empresas_permitidas

        # Fechamento Final (Seção 4.1): filiais candidatas = as da empresa
        # principal + as de QUALQUER empresa do mesmo Grupo (não só as já
        # autorizadas agora) — permite marcar, na mesma tela, filiais de uma
        # empresa que está sendo autorizada nesta mesma submissão. A
        # validação de verdade (contra o que foi de fato submetido em
        # `empresas_autorizadas`) acontece em `clean_filiais_autorizadas`.
        empresa_ids_candidatas = set(self.empresas_permitidas.values_list("pk", flat=True))
        if usuario_alvo and usuario_alvo.empresa_id:
            empresa_ids_candidatas.add(usuario_alvo.empresa_id)
        self.filiais_candidatas = Filial.objects.filter(
            empresa_id__in=empresa_ids_candidatas, ativo=True,
        ).select_related("empresa").order_by("empresa__nome", "nome")
        self.fields["filiais_autorizadas"].queryset = self.filiais_candidatas

        if usuario_alvo is not None and not self.is_bound:
            self.fields["perfis_acesso"].initial = usuario_alvo.perfis_acesso.all()
            self.fields["permissoes_individuais"].initial = usuario_alvo.permissoes_individuais.all()
            self.fields["empresas_autorizadas"].initial = Empresa.objects.filter(
                autorizacoes_usuario__usuario=usuario_alvo, autorizacoes_usuario__ativo=True
            )
            self.fields["filiais_autorizadas"].initial = Filial.objects.filter(
                vinculos_usuario__usuario=usuario_alvo, vinculos_usuario__ativo=True,
            )
            if empresa is not None:
                autorizacao = usuario_alvo.autorizacoes_empresa.filter(empresa=empresa).first()
                if autorizacao is not None:
                    self.fields["limite_compra"].initial = autorizacao.limite_compra

    def clean_empresas_autorizadas(self):
        """Sprint de Correções Críticas (Seção 5) — segunda camada,
        explícita: mesmo que o queryset do campo já restrinja as opções
        exibidas, esta validação garante que um ID enviado manualmente de
        fora do Grupo seja rejeitado no backend, não só escondido na UI."""
        empresas = self.cleaned_data.get("empresas_autorizadas") or Empresa.objects.none()
        permitidas_ids = set(self.empresas_permitidas.values_list("pk", flat=True))
        fora_do_grupo = [e for e in empresas if e.pk not in permitidas_ids]
        if fora_do_grupo:
            nomes = ", ".join(e.nome for e in fora_do_grupo)
            raise forms.ValidationError(
                f"Empresa(s) fora do Grupo Empresarial deste usuário: {nomes}. "
                "Só é possível autorizar empresas do mesmo grupo."
            )
        return empresas

    def clean_filiais_autorizadas(self):
        """Fechamento Final (Seção 4.1): "uma filial de Empresa não
        autorizada nunca pode aparecer nem ser aceita em POST manipulado"
        — revalida cada filial submetida contra as empresas REALMENTE
        submetidas em `empresas_autorizadas` (já limpo, por causa da ordem
        de declaração dos campos) + a empresa principal."""
        filiais = self.cleaned_data.get("filiais_autorizadas") or Filial.objects.none()
        empresa_ids_validos = set(
            (self.cleaned_data.get("empresas_autorizadas") or Empresa.objects.none()).values_list("pk", flat=True)
        )
        if self.usuario_alvo and self.usuario_alvo.empresa_id:
            empresa_ids_validos.add(self.usuario_alvo.empresa_id)
        fora_do_escopo = [f for f in filiais if f.empresa_id not in empresa_ids_validos]
        if fora_do_escopo:
            nomes = ", ".join(f"{f.nome} ({f.empresa.nome})" for f in fora_do_escopo)
            raise forms.ValidationError(
                f"Filial(is) fora das empresas autorizadas deste usuário: {nomes}."
            )
        return filiais

    def clean(self):
        cleaned = super().clean()
        # Fechamento Final (Seção 4.1): "para não-Proprietário, exija ao
        # menos uma filial ativa enquanto o usuário estiver ativo" — o
        # Proprietário nunca precisa (já vê tudo automaticamente).
        if (
            self.usuario_alvo and not self.usuario_alvo.is_proprietario and self.usuario_alvo.is_active
            and "filiais_autorizadas" in cleaned and not cleaned["filiais_autorizadas"].exists()
        ):
            self.add_error(
                "filiais_autorizadas",
                "Selecione ao menos uma filial autorizada — obrigatório enquanto o usuário estiver ativo.",
            )
        # Revisão adversarial (Fechamento Final): a filial principal
        # (`Usuario.filial`) só pode ser promovida automaticamente dentro
        # da EMPRESA principal do usuário (`Usuario.empresa`) — nunca para
        # outra empresa, mesmo que autorizada, para nunca quebrar o
        # invariante `Usuario.filial.empresa == Usuario.empresa` que várias
        # telas (dashboard, context processor) assumem sem revalidar. Por
        # isso, exigimos aqui que pelo menos uma filial selecionada
        # pertença à empresa principal — sem isso não há candidata segura
        # para a promoção em `aplicar()`.
        if (
            self.usuario_alvo and not self.usuario_alvo.is_proprietario and self.usuario_alvo.is_active
            and self.usuario_alvo.empresa_id and "filiais_autorizadas" in cleaned
            and cleaned["filiais_autorizadas"].exists()
            and not cleaned["filiais_autorizadas"].filter(empresa_id=self.usuario_alvo.empresa_id).exists()
        ):
            self.add_error(
                "filiais_autorizadas",
                "Pelo menos uma filial da empresa principal do usuário "
                f"({self.usuario_alvo.empresa.nome}) deve continuar selecionada.",
            )
        return cleaned

    def aplicar(self):
        """Grava as 4 relações + o limite na empresa ativa, dentro de uma
        única transação (Fechamento Final, Seção 4.1) — a "função de
        serviço central" pedida pela Seção, para nenhuma relação ficar
        gravada pela metade se algo falhar no meio. Devolve
        `(usuario, resumo)`, onde `resumo` traz o que mudou nas filiais
        (para a view registrar em auditoria com o antes/depois legível)."""
        from django.db import transaction

        usuario = self.usuario_alvo
        resumo = {"filiais_adicionadas": [], "filiais_removidas": []}

        with transaction.atomic():
            usuario.perfis_acesso.set(self.cleaned_data["perfis_acesso"])
            usuario.permissoes_individuais.set(self.cleaned_data["permissoes_individuais"])

            # Terceira camada (Seção 5): revalida no service, imediatamente
            # antes de gravar — não confia só no form ter sido usado como
            # esperado (defesa em profundidade, não apenas UI).
            permitidas_ids = set(usuario.empresas_do_grupo().values_list("pk", flat=True))
            autorizadas = {
                pk for pk in self.cleaned_data["empresas_autorizadas"].values_list("pk", flat=True)
                if pk in permitidas_ids
            }
            existentes = {a.empresa_id: a for a in usuario.autorizacoes_empresa.all()}
            # Revisão adversarial (Fechamento Final): este loop só pode
            # ativar/desativar autorizações para empresas que REALMENTE
            # apareceram como opção marcável no formulário
            # (`permitidas_ids`, mesmo Grupo). Uma autorização legítima e
            # pré-existente para uma empresa fora dessa lista (ex.: vínculo
            # legado direto, de antes do conceito de Grupo existir) nunca é
            # oferecida como checkbox — então ela nunca poderia ser
            # "marcada de novo", e o loop antigo a desativava a cada save,
            # mesmo em uma edição sem nenhuma relação com empresas. A
            # limpeza de autorizações REALMENTE inconsistentes (fora do
            # Grupo) é responsabilidade dedicada do comando
            # `diagnosticar_autorizacoes_fora_do_grupo --corrigir`, não
            # deste formulário.
            for empresa_id, autorizacao in existentes.items():
                if empresa_id == usuario.empresa_id:
                    continue  # a autorização na empresa principal (se houver) só guarda o limite
                if empresa_id not in permitidas_ids:
                    continue  # nunca mexe em autorização que nem foi oferecida como opção
                desejada = empresa_id in autorizadas
                if autorizacao.ativo != desejada:
                    autorizacao.ativo = desejada
                    autorizacao.save(update_fields=["ativo", "atualizado_em"])
            for empresa_id in autorizadas - set(existentes):
                UsuarioEmpresa.objects.create(usuario=usuario, empresa_id=empresa_id, ativo=True)

            # Limite individual vive na autorização da EMPRESA ATIVA (criada
            # sob demanda também para a empresa principal, só como porta-limite).
            if self.empresa is not None:
                limite = self.cleaned_data.get("limite_compra")
                autorizacao, _ = UsuarioEmpresa.objects.get_or_create(
                    usuario=usuario, empresa=self.empresa, defaults={"ativo": True}
                )
                autorizacao.limite_compra = limite
                autorizacao.save(update_fields=["limite_compra", "atualizado_em"])

            # Fechamento Final (Seção 4.1): filiais autorizadas — desativa
            # em vez de apagar; reativa o MESMO registro se selecionada de
            # novo (nunca duplica, graças à constraint única de
            # `UsuarioFilial`). Proprietário nunca precisa de vínculo.
            if not usuario.is_proprietario:
                filiais_desejadas = self.cleaned_data.get("filiais_autorizadas")
                if filiais_desejadas is not None:
                    filial_ids_desejados = set(filiais_desejadas.values_list("pk", flat=True))
                    nomes_por_filial = {f.pk: f.nome for f in filiais_desejadas}
                    empresa_por_filial = {f.pk: f.empresa_id for f in filiais_desejadas}
                    vinculos_existentes = {v.filial_id: v for v in usuario.vinculos_filial.select_related("filial")}

                    for filial_id, vinculo in vinculos_existentes.items():
                        desejado = filial_id in filial_ids_desejados
                        if vinculo.ativo != desejado:
                            vinculo.ativo = desejado
                            vinculo.save(update_fields=["ativo", "atualizado_em"])
                            (resumo["filiais_adicionadas"] if desejado else resumo["filiais_removidas"]).append(
                                vinculo.filial.nome
                            )
                    for filial_id in filial_ids_desejados - set(vinculos_existentes):
                        UsuarioFilial.objects.create(usuario=usuario, filial_id=filial_id, ativo=True)
                        resumo["filiais_adicionadas"].append(nomes_por_filial.get(filial_id, f"#{filial_id}"))

                    # A filial principal precisa continuar dentro do
                    # conjunto autorizado (Seção 4.1, penúltimo item) — se
                    # ela caiu da seleção, promove outra automaticamente
                    # (a primeira por nome) em vez de deixar `Usuario.filial`
                    # apontando para uma filial não autorizada.
                    #
                    # Revisão adversarial (Fechamento Final): a candidata
                    # SÓ pode vir da empresa principal do usuário
                    # (`usuario.empresa_id`) — nunca de outra empresa, ainda
                    # que autorizada, porque várias telas (dashboard,
                    # context processor, gestão de compras) leem
                    # `Usuario.filial` assumindo, sem revalidar, que
                    # `Usuario.filial.empresa == Usuario.empresa`. `clean()`
                    # já garante que sempre existe ao menos uma candidata
                    # assim quando este código roda.
                    if filial_ids_desejados and usuario.filial_id not in filial_ids_desejados:
                        candidatas_mesma_empresa = {
                            pk for pk in filial_ids_desejados
                            if empresa_por_filial.get(pk) == usuario.empresa_id
                        }
                        if candidatas_mesma_empresa:
                            nova_principal_id = min(
                                candidatas_mesma_empresa, key=lambda pk: nomes_por_filial.get(pk, "")
                            )
                            usuario.filial_id = nova_principal_id
                            usuario.save(update_fields=["filial"])

        return usuario, resumo


class FluxoAprovacaoForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = FluxoAprovacao
        fields = ["nome", "ativo"]


class EtapaFluxoForm(MoedaFormMixin, BootstrapFormMixin, forms.ModelForm):
    campos_moeda = ("valor_maximo",)

    class Meta:
        model = EtapaFluxo
        fields = ["ordem", "perfil_aprovador", "aprovador", "substituto", "valor_maximo", "prazo_dias", "observacao"]

    def __init__(self, *args, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        for nome in ("aprovador", "substituto", "valor_maximo", "prazo_dias", "observacao"):
            self.fields[nome].required = False
        usuarios = Usuario.objects.filter(empresa=empresa, is_active=True) if empresa else Usuario.objects.none()
        self.fields["aprovador"].queryset = usuarios
        self.fields["substituto"].queryset = usuarios


EtapaFluxoFormSet = inlineformset_factory(
    FluxoAprovacao,
    EtapaFluxo,
    form=EtapaFluxoForm,
    # `extra=1` (não 0): o template não tem nenhum botão/JS de "adicionar
    # etapa" (diferente do formset de itens de Compra, que usa
    # `static/js/nexbuy.js`) — a única forma de a Proprietária colocar uma
    # linha em branco na tabela é o próprio Django render-la. Com
    # `extra=0`, `total_form_count()` = `max(initial_forms, min_num) +
    # extra` deixava a tela de EDITAR um fluxo já existente (N etapas, N
    # >= min_num) sem NENHUMA linha vazia — não havia como adicionar uma
    # alçada nova a um fluxo já salvo, só recriando tudo do zero em "Novo
    # fluxo". `extra=1` garante sempre uma linha extra em branco, tanto ao
    # criar (fica com a exigida pelo `min_num` + 1 de sobra) quanto ao
    # editar (N + 1) — a linha extra, se deixada vazia, é ignorada
    # normalmente pela validação do formset.
    extra=1,
    can_delete=True,
    min_num=1,
    validate_min=True,
)


class UsuarioNovoForm(BootstrapFormMixin, forms.ModelForm):
    """Cadastro de usuário no PRODUTO (Épico 2A — Etapa 03): dados
    pessoais, empresa (a ativa), filial, perfil, senha inicial, status e
    foto opcional — o fim do desvio ao /admin. As permissões finas são o
    passo seguinte (painel visual, na edição do usuário)."""

    senha_inicial = forms.CharField(
        label="Senha inicial",
        min_length=8,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
        help_text="Mínimo de 8 caracteres, sem ser só números nem uma senha comum. O usuário poderá trocá-la em Meu Perfil.",
    )

    class Meta:
        model = Usuario
        fields = ["first_name", "last_name", "email", "username", "filial", "perfil", "foto", "is_active"]
        labels = {
            "first_name": "Nome", "last_name": "Sobrenome", "email": "E-mail",
            "username": "Usuário (login)", "filial": "Filial", "perfil": "Perfil",
            "foto": "Foto (opcional)", "is_active": "Usuário ativo",
        }

    def __init__(self, *args, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.empresa = empresa
        self.fields["first_name"].required = True
        self.fields["email"].required = True
        if empresa is not None:
            self.fields["filial"].queryset = empresa.filiais.filter(ativo=True)
        self.fields["filial"].help_text = "Obrigatória para Gerente, Financeiro e Comprador."

    def clean_senha_inicial(self):
        """A senha pública da demonstração (e variações) nunca vale como
        senha inicial — na demo publicada na internet a cliente recolocaria
        num usuário ativo a senha que qualquer visitante conhece."""
        from core.senha_demo import SenhaPublicaDemoValidator

        senha = self.cleaned_data["senha_inicial"]
        SenhaPublicaDemoValidator().validate(senha)
        return senha

    def clean(self):
        dados = super().clean()
        # Sprint de Melhorias 1 (segurança): a senha inicial passa por TODAS
        # as regras do AUTH_PASSWORD_VALIDATORS (comum, só números, parecida
        # com o login/nome/e-mail) — antes bastavam 8 caracteres, e
        # "12345678" criava um Financeiro com acesso ao caixa da farmácia.
        senha = dados.get("senha_inicial")
        if senha:
            candidato = Usuario(
                username=dados.get("username") or "", first_name=dados.get("first_name") or "",
                last_name=dados.get("last_name") or "", email=dados.get("email") or "",
            )
            try:
                validate_password(senha, user=candidato)
            except forms.ValidationError as erro:
                self.add_error("senha_inicial", erro)
        perfil = dados.get("perfil")
        if perfil and perfil != Usuario.Perfil.PROPRIETARIO and not dados.get("filial"):
            self.add_error("filial", "Selecione a filial deste usuário.")
        return dados

    def save(self, commit=True):
        usuario = super().save(commit=False)
        usuario.empresa = self.empresa
        usuario.set_password(self.cleaned_data["senha_inicial"])
        if commit:
            usuario.save()
            _garantir_vinculo_filial_ativo(usuario)
        return usuario
