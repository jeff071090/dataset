from django.contrib import messages
from django.db import transaction
from django.shortcuts import redirect, render

from auditoria.models import RegistroAuditoria
from auditoria.services import ip_do_request, registrar_evento
from core.contexto import empresa_ativa
from core.permissions import permissao_required

from .forms import EmpresaForm, IdentidadeVisualForm
from .models import IdentidadeVisual

# Prompt 2 (pré-Etapa 02), Gate D (Seção 9): campos de negócio auditados na
# edição da Empresa — mesmos campos do `EmpresaForm`, nunca o objeto inteiro.
_CAMPOS_AUDITADOS_EMPRESA = (
    "razao_social", "nome", "inscricao_estadual", "telefone", "email",
    "endereco", "cidade", "estado", "cep",
)


# Épico 2A (Etapa 02): a landing "configuracoes_home" (Sprint 6) foi
# eliminada — o Centro de Configurações (/ncc/) é o ÚNICO hub de
# parametrização; /configuracoes/ agora redireciona por perfil
# (ver `core.views.configuracoes_redirect`).


@permissao_required("empresa.gerenciar")
def empresa_editar(request):
    """Dados cadastrais da Empresa (Sprint 6, item 2) — só o Proprietário
    edita. CORE 1.0 (Épico 9): edita a empresa ATIVA do contexto."""
    empresa = empresa_ativa(request)
    if empresa is None:
        messages.error(request, "Seu usuário não está vinculado a uma empresa.")
        return redirect("dashboard:home")

    if request.method == "POST":
        estado_antes = {campo: getattr(empresa, campo) for campo in _CAMPOS_AUDITADOS_EMPRESA}
        form = EmpresaForm(request.POST, instance=empresa)
        if form.is_valid():
            with transaction.atomic():
                form.save()
                estado_depois = {campo: getattr(empresa, campo) for campo in _CAMPOS_AUDITADOS_EMPRESA}
                if estado_antes != estado_depois:
                    registrar_evento(
                        categoria=RegistroAuditoria.Categoria.EMPRESA_EDITADA,
                        descricao=f"Empresa {empresa.nome} — dados cadastrais editados.",
                        empresa=empresa, usuario=request.user, ip=ip_do_request(request),
                        modulo="empresas", acao="editar", tipo_objeto="Empresa", id_objeto=empresa.pk,
                        estado_antes=estado_antes, estado_depois=estado_depois,
                    )
            messages.success(request, "Dados da empresa atualizados com sucesso.")
            return redirect("empresas:editar")
    else:
        form = EmpresaForm(instance=empresa)

    return render(request, "empresas/empresa_form.html", {"form": form, "empresa": empresa})


@permissao_required("empresa.gerenciar")
def identidade_visual_editar(request):
    """Logo, favicon, cor secundária e nome de exibição (Sprint 6, item 3).
    CORE 1.0 (Épico 9): edita a identidade da empresa ATIVA do contexto."""
    empresa = empresa_ativa(request)
    if empresa is None:
        messages.error(request, "Seu usuário não está vinculado a uma empresa.")
        return redirect("dashboard:home")

    identidade, _ = IdentidadeVisual.objects.get_or_create(empresa=empresa)

    if request.method == "POST":
        form = IdentidadeVisualForm(request.POST, request.FILES, instance=identidade)
        if form.is_valid():
            form.save()
            messages.success(request, "Identidade visual atualizada com sucesso.")
            return redirect("empresas:identidade_visual")
    else:
        form = IdentidadeVisualForm(instance=identidade)

    return render(request, "empresas/identidade_visual_form.html", {"form": form, "identidade": identidade})
