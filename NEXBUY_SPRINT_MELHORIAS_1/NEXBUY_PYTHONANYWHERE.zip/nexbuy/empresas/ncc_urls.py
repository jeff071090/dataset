from django.urls import path

from . import views_ncc, views_wizard

app_name = "ncc"

urlpatterns = [
    path("", views_ncc.ncc_home, name="home"),
    path("checklist/", views_ncc.ncc_checklist, name="checklist"),
    path("gerais/", views_ncc.ncc_gerais, name="gerais"),
    path("estrutura/", views_ncc.ncc_estrutura, name="estrutura"),
    path("filiais/", views_ncc.ncc_filiais, name="filiais"),
    path("filiais/nova/", views_ncc.ncc_filial_nova, name="filial_nova"),
    path("filiais/<int:pk>/", views_ncc.ncc_filial_editar, name="filial_editar"),
    path("usuarios/", views_ncc.ncc_usuarios, name="usuarios"),
    path("usuarios/novo/", views_ncc.ncc_usuario_novo, name="usuario_novo"),
    path("usuarios/<int:pk>/", views_ncc.ncc_usuario_editar, name="usuario_editar"),
    path("perfis/", views_ncc.ncc_perfis, name="perfis"),
    path("perfis/<int:pk>/", views_ncc.ncc_perfil_editar, name="perfil_editar"),
    path("motor/", views_ncc.ncc_motor, name="motor"),
    path("workflow/", views_ncc.ncc_workflow, name="workflow"),
    path("workflow/novo/", views_ncc.ncc_workflow_editar, name="workflow_novo"),
    path("workflow/<int:pk>/", views_ncc.ncc_workflow_editar, name="workflow_editar"),
    path("compras/", views_ncc.ncc_compras, name="compras"),
    path("dashboard/", views_ncc.ncc_dashboard, name="dashboard"),
    path("notificacoes/", views_ncc.ncc_notificacoes, name="notificacoes"),
    path("integracoes/", views_ncc.ncc_integracoes, name="integracoes"),
    path("auditoria/", views_ncc.ncc_auditoria, name="auditoria"),
    path("central-auditoria/", views_ncc.ncc_central_auditoria, name="central_auditoria"),
    path("implantacao/", views_wizard.assistente_implantacao, name="implantacao"),
]
