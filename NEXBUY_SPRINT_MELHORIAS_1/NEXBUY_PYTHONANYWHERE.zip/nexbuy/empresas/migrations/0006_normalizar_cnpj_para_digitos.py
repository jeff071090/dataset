"""Gate pré-Etapa 10 (S1-1, item 3): `Empresa.cnpj` passou a ser
persistido de forma canônica (só dígitos) — `Empresa.save()` já garante
isso para qualquer escrita nova; esta migration corrige o que já existia
no banco antes dessa mudança.

Idempotente e segura contra colisão: se duas Empresas diferentes
tivessem CNPJs com a mesma sequência de dígitos mas máscaras diferentes
(dado inconsistente que só era possível porque a unicidade valia sobre a
STRING mascarada, não sobre os dígitos), a normalização pura e simples
geraria uma violação da constraint `unique=True` — por isso cada
colisão detectada é reportada explicitamente em vez de ser aplicada."""
import re

from django.db import migrations


def normalizar(apps, schema_editor):
    Empresa = apps.get_model("empresas", "Empresa")
    vistos = {}
    for empresa in Empresa.objects.all():
        digitos = re.sub(r"\D", "", empresa.cnpj or "")
        if digitos in vistos and vistos[digitos] != empresa.pk:
            raise RuntimeError(
                f"Colisão de CNPJ ao normalizar: Empresa #{empresa.pk} e #{vistos[digitos]} "
                f"têm o mesmo CNPJ em dígitos ({digitos}) com máscaras diferentes — "
                "resolva manualmente antes de aplicar esta migration."
            )
        vistos[digitos] = empresa.pk
        if digitos != empresa.cnpj:
            empresa.cnpj = digitos
            empresa.save(update_fields=["cnpj"])


def reverter(apps, schema_editor):
    # Sem-op de propósito: não há como reconstruir a máscara original
    # (poderia ter sido digitada de formas diferentes) — o dado em dígitos
    # continua válido e utilizável, só perde a formatação original.
    pass


class Migration(migrations.Migration):

    dependencies = [
        ("empresas", "0005_alter_empresa_cnpj"),
    ]

    operations = [
        migrations.RunPython(normalizar, reverter),
    ]
