"""Testes do Checklist Guiado de Configuração Inicial (pós-Primeiro Acesso).

Cobre: (1) o estado logo após o Primeiro Acesso Seguro (só Empresa + Filial
Matriz + Proprietário), (2) cada item virando concluído por uma ação real de
cadastro (nunca uma flag manual), (3) proteção de permissão da view
(`ncc.acessar`) e (4) isolamento multiempresa — dados de uma Empresa nunca
podem marcar um item de OUTRA Empresa como concluído.

Rode com: venv/Scripts/python.exe manage.py test empresas.tests_checklist
"""
from datetime import date
from decimal import Decimal

from django.test import Client, TestCase
from django.test.utils import override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, DiaOperacional, Receita
from gestao_compras.models import Provisao
from usuarios.models import Usuario, UsuarioFilial

from .models import ConfiguracaoPlataforma, Empresa
from .services_checklist import calcular_checklist, resumo_checklist


def _item(itens, numero):
    return next(i for i in itens if i["numero"] == numero)


class ChecklistBaselineTestCase(TestCase):
    """Estado imediatamente após o Primeiro Acesso Seguro: só existem
    Empresa, Filial Matriz (com apenas o nome) e o Proprietário —
    exatamente o que `core/views_primeiro_acesso.py::_criar_estrutura_
    inicial` grava. Confirma, com precisão, quais itens já nascem
    concluídos nesse estado."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Checklist Baseline", cnpj="11.000.000/0001-11")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        # Mesma chamada feita pelo Primeiro Acesso: ConfiguracaoPlataforma
        # já nasce com o fuso horário escolhido no formulário.
        ConfiguracaoPlataforma.objects.create(empresa=self.empresa, fuso_horario="America/Cuiaba")
        self.proprietario = Usuario.objects.create_user(
            username="prop_checklist_baseline", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def test_apenas_empresa_e_regras_gerais_concluidos(self):
        itens = calcular_checklist(self.empresa)
        self.assertEqual(len(itens), 13)

        concluidos = {i["numero"] for i in itens if i["concluido"]}
        # Só o item 1 (Empresa cadastrada) e o item 3 (Regras gerais —
        # ConfiguracaoPlataforma já existe) nascem concluídos; os outros 11
        # ficam pendentes até uma ação real de cadastro.
        self.assertEqual(concluidos, {1, 3})

        resumo = resumo_checklist(itens)
        self.assertEqual(resumo["total"], 13)
        self.assertEqual(resumo["concluidos"], 2)

    def test_item_1_empresa_sempre_concluido(self):
        self.assertTrue(_item(calcular_checklist(self.empresa), 1)["concluido"])

    def test_item_2_filial_matriz_incompleta_fica_pendente(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 2)["concluido"])

    def test_item_2_vira_concluido_quando_filial_matriz_fica_completa(self):
        self.filial.razao_social = "Empresa Checklist Baseline LTDA"
        self.filial.cnpj = "11.000.000/0001-11"
        self.filial.inscricao_estadual = "123456789"
        self.filial.endereco = "Rua Teste"
        self.filial.numero = "100"
        self.filial.bairro = "Centro"
        self.filial.cidade = "Cuiabá"
        self.filial.estado = "MT"
        self.filial.cep = "78000-000"
        self.filial.telefone = "(65) 3000-0000"
        self.filial.responsavel_nome = "Fulano"
        self.filial.responsavel_telefone = "(65) 99999-0000"
        self.filial.save()
        self.assertTrue(self.filial.cadastro_completo)
        self.assertTrue(_item(calcular_checklist(self.empresa), 2)["concluido"])

    def test_item_3_regras_gerais_concluido_pela_existencia_do_registro(self):
        self.assertTrue(_item(calcular_checklist(self.empresa), 3)["concluido"])

    def test_item_4_pendente_sem_configuracao_financeira(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 4)["concluido"])

    def test_item_4_visitar_a_tela_get_or_create_nao_marca_como_configurado(self):
        # `financeiro.views.configuracao_financeira` faz um
        # `get_or_create` já no GET — o registro passa a existir com o
        # valor PADRÃO do model (30%), mas isso não deve contar como
        # "configuração financeira definida" (ninguém decidiu nada ainda).
        ConfiguracaoFinanceira.objects.get_or_create(empresa=self.empresa)
        self.assertFalse(_item(calcular_checklist(self.empresa), 4)["concluido"])

    def test_item_4_alterar_direto_no_banco_sem_passar_pelo_formulario_nao_conclui(self):
        # Correção do Checklist Guiado: o critério deixou de comparar o
        # VALOR do percentual contra o padrão do model (30%) — esse
        # sentinela deixava o item permanentemente pendente para um
        # cliente que decidisse, de propósito, manter 30% como o valor
        # real desejado. Agora o critério exige um sinal real de que o
        # FORMULÁRIO de `/financeiro/configuracao/` foi salvo
        # (`LogConfiguracao`, área "Configuração Financeira") — uma
        # alteração direta no banco via ORM, sem passar pela view, não
        # deixa esse rastro, então não deveria concluir o item mesmo que o
        # percentual não seja mais o padrão. Ver
        # `ChecklistItensCorrigidosTestCase` para a conclusão real via POST.
        config, _ = ConfiguracaoFinanceira.objects.get_or_create(empresa=self.empresa)
        config.percentual_compras = Decimal("45.00")
        config.save(update_fields=["percentual_compras"])
        self.assertFalse(_item(calcular_checklist(self.empresa), 4)["concluido"])

    def test_item_5_pendente_sem_receita(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 5)["concluido"])

    def test_item_6_pendente_sem_categoria(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 6)["concluido"])

    def test_item_6_categoria_inativa_nao_conta(self):
        Categoria.objects.create(empresa=self.empresa, nome="Categoria Inativa", ativo=False)
        self.assertFalse(_item(calcular_checklist(self.empresa), 6)["concluido"])

    def test_item_7_pendente_sem_fornecedor(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 7)["concluido"])

    def test_item_8_pendente_so_com_proprietario(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 8)["concluido"])

    def test_item_9_pendente_sem_comprador_vinculado(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 9)["concluido"])

    def test_item_9_vira_concluido_com_comprador_e_filial_vinculada(self):
        comprador = Usuario.objects.create_user(
            username="comprador_checklist_baseline", password="x",
            perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa, filial=self.filial,
        )
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial, ativo=True)
        self.assertTrue(_item(calcular_checklist(self.empresa), 9)["concluido"])

    def test_item_9_vinculo_inativo_nao_conta(self):
        comprador = Usuario.objects.create_user(
            username="comprador_vinculo_inativo", password="x",
            perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa, filial=self.filial,
        )
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial, ativo=False)
        self.assertFalse(_item(calcular_checklist(self.empresa), 9)["concluido"])

    def test_item_10_pendente_sem_excecao_de_calendario(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 10)["concluido"])

    def test_item_10_vira_concluido_com_uma_excecao(self):
        DiaOperacional.objects.create(empresa=self.empresa, data=date(2026, 12, 25), tipo=DiaOperacional.Tipo.FERIADO)
        self.assertTrue(_item(calcular_checklist(self.empresa), 10)["concluido"])

    def test_item_11_pendente_sem_compra(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 11)["concluido"])

    def test_item_12_pendente_sem_provisao(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 12)["concluido"])

    def test_item_13_pendente_enquanto_ninguem_visitou_o_relatorio(self):
        # Correção do Checklist Guiado: o item deixou de ficar SEMPRE
        # pendente — `compras.views.relatorio_compras_por_filial` agora
        # grava um evento real na primeira visita (ver
        # `ChecklistItensCorrigidosTestCase`). Neste cenário de baseline,
        # ninguém visitou o relatório ainda, então o item continua
        # pendente — exatamente como qualquer outro item deste checklist
        # antes da ação real que o conclui.
        itens = calcular_checklist(self.empresa)
        self.assertFalse(_item(itens, 13)["concluido"])

    def test_calcular_checklist_sem_empresa_devolve_lista_vazia(self):
        self.assertEqual(calcular_checklist(None), [])


class ChecklistProgressaoTestCase(TestCase):
    """Cada cadastro real muda SÓ o item correspondente — os demais itens
    continuam exatamente como estavam antes (nenhum efeito colateral entre
    critérios)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Checklist Progressao", cnpj="12.000.000/0001-12")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoPlataforma.objects.create(empresa=self.empresa, fuso_horario="America/Cuiaba")
        self.proprietario = Usuario.objects.create_user(
            username="prop_checklist_progressao", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.concluidos_base = {1, 3}

    def _concluidos(self):
        return {i["numero"] for i in calcular_checklist(self.empresa) if i["concluido"]}

    def test_cadastrar_receita_conclui_apenas_item_5(self):
        Receita.objects.create(filial=self.filial, mes=date.today(), faturamento=Decimal("50000.00"))
        self.assertEqual(self._concluidos(), self.concluidos_base | {5})

    def test_cadastrar_categoria_conclui_apenas_item_6(self):
        Categoria.objects.create(empresa=self.empresa, nome="Insumos")
        self.assertEqual(self._concluidos(), self.concluidos_base | {6})

    def test_cadastrar_fornecedor_conclui_apenas_item_7(self):
        Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Teste")
        self.assertEqual(self._concluidos(), self.concluidos_base | {7})

    def test_cadastrar_segundo_usuario_conclui_apenas_item_8(self):
        Usuario.objects.create_user(
            username="gerente_checklist_progressao", password="x",
            perfil=Usuario.Perfil.GERENTE, empresa=self.empresa, filial=self.filial,
        )
        self.assertEqual(self._concluidos(), self.concluidos_base | {8})

    def test_cadastrar_compra_conclui_apenas_item_11(self):
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Compra")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Compra")
        Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=fornecedor, usuario=self.proprietario,
            valor=Decimal("100.00"), categoria=categoria,
        )
        # Cadastrar Fornecedor/Categoria para viabilizar a Compra também
        # conclui os itens 6 e 7 — o teste isola exatamente essa
        # consequência esperada, além do item 11.
        self.assertEqual(self._concluidos(), self.concluidos_base | {6, 7, 11})

    def test_cadastrar_provisao_conclui_apenas_item_12(self):
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Provisao")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Provisao")
        Provisao.objects.create(
            empresa=self.empresa, filial=self.filial, comprador=self.proprietario,
            fornecedor=fornecedor, categoria=categoria, data=date.today(), valor_total=Decimal("100.00"),
        )
        self.assertEqual(self._concluidos(), self.concluidos_base | {6, 7, 12})


class ChecklistViewTestCase(TestCase):
    """Permissão da view (`ncc.acessar`, só Proprietário por padrão) e o
    fluxo de "Ocultar por enquanto" (session, não persiste no banco)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Checklist View", cnpj="13.000.000/0001-13")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoPlataforma.objects.create(empresa=self.empresa, fuso_horario="America/Cuiaba")
        self.proprietario = Usuario.objects.create_user(
            username="prop_checklist_view", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.comprador = Usuario.objects.create_user(
            username="comprador_checklist_view", password="x",
            perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa, filial=self.filial,
        )
        self.client = Client()

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_proprietario_acessa_checklist_com_200(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.get("/ncc/checklist/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Checklist de Implantação")
        # Itens 1 (Empresa), 3 (Regras gerais) e 8 (Usuários e perfis — o
        # próprio `self.comprador` criado no setUp já é um segundo usuário
        # além do Proprietário) ficam concluídos neste setUp específico.
        self.assertContains(resposta, "3 de 13 concluídos")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_itens_11_e_12_falam_de_compra_real_e_apontam_o_simulador(self):
        """Crítico de UX (rodada 1): os itens se chamavam "Primeira Compra
        simulada"/"Primeira Provisão simulada" e pediam uma "Compra de
        teste" — mas toda compra/provisão gravada é real (entra na DRE e nos
        limites) e não pode ser apagada pela tela. Quem só quer experimentar
        usa o Simulador, agora com atalho no próprio card."""
        itens = calcular_checklist(self.empresa)
        for numero in (11, 12):
            item = _item(itens, numero)
            texto = f'{item["titulo"]} {item["descricao"]}'.lower()
            self.assertNotIn("simulada", texto)
            self.assertNotIn("de teste", texto)
            self.assertIn("registrad", item["titulo"].lower())
            self.assertIn("simulador", item["descricao"].lower())
            self.assertEqual(item["cta_secundario_url"], "/compras/simulacao/")
        self.client.force_login(self.proprietario)
        html = self.client.get("/ncc/checklist/").content.decode()
        self.assertEqual(html.count("data-nx-cta-secundario"), 2)
        self.assertIn('href="/compras/simulacao/"', html)
        self.assertNotIn("simulada", html)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_sem_permissao_recebe_403(self):
        self.client.force_login(self.comprador)
        resposta = self.client.get("/ncc/checklist/")
        self.assertEqual(resposta.status_code, 403)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_usuario_nao_autenticado_e_redirecionado_ao_login(self):
        resposta = self.client.get("/ncc/checklist/")
        self.assertEqual(resposta.status_code, 302)
        self.assertIn("/accounts/login/", resposta.url)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_ocultar_remove_card_da_home_mas_url_direta_continua_acessivel(self):
        self.client.force_login(self.proprietario)

        home_antes = self.client.get("/ncc/")
        modulos_antes = [m["titulo"] for m in home_antes.context["categorias"][0]["modulos"]]
        self.assertIn("Checklist de Implantação", modulos_antes)

        resposta_ocultar = self.client.post("/ncc/checklist/", {"acao": "ocultar"})
        self.assertRedirects(resposta_ocultar, "/ncc/")

        home_depois = self.client.get("/ncc/")
        modulos_depois = [m["titulo"] for m in home_depois.context["categorias"][0]["modulos"]]
        self.assertNotIn("Checklist de Implantação", modulos_depois)

        # A URL direta e o item de menu continuam funcionando normalmente —
        # "ocultar" nunca bloqueia o acesso à tela em si.
        resposta_direta = self.client.get("/ncc/checklist/")
        self.assertEqual(resposta_direta.status_code, 200)


class ChecklistCrossEmpresaTestCase(TestCase):
    """Isolamento multiempresa: cadastros de OUTRA Empresa nunca podem
    marcar um item desta Empresa como concluído — mesmo tema recorrente de
    isolamento cross-tenant já coberto em `empresas/tests.py` (ver
    `NccUsuarioEditarCrossEmpresaTestCase`, `NccCentralAuditoriaTestCase`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Checklist Cross A", cnpj="14.000.000/0001-14")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz A", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoPlataforma.objects.create(empresa=self.empresa, fuso_horario="America/Cuiaba")
        self.proprietario = Usuario.objects.create_user(
            username="prop_checklist_cross_a", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

        self.outra_empresa = Empresa.objects.create(nome="Empresa Checklist Cross B", cnpj="14.000.000/0002-14")
        self.outra_filial = Filial.objects.create(
            empresa=self.outra_empresa, nome="Matriz B", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        # Dá à Empresa B TUDO que faltava para a Empresa A: Config
        # Financeira alterada, Receita, Categoria, Fornecedor, um segundo
        # usuário (Gerente), Comprador com Filial vinculada, exceção de
        # calendário, Compra e Provisão.
        config_b = ConfiguracaoFinanceira.objects.create(empresa=self.outra_empresa)
        config_b.percentual_compras = Decimal("60.00")
        config_b.save(update_fields=["percentual_compras"])
        Receita.objects.create(filial=self.outra_filial, mes=date.today(), faturamento=Decimal("10000.00"))
        categoria_b = Categoria.objects.create(empresa=self.outra_empresa, nome="Categoria B")
        fornecedor_b = Fornecedor.objects.create(empresa=self.outra_empresa, nome="Fornecedor B")
        Usuario.objects.create_user(
            username="gerente_checklist_cross_b", password="x",
            perfil=Usuario.Perfil.GERENTE, empresa=self.outra_empresa, filial=self.outra_filial,
        )
        comprador_b = Usuario.objects.create_user(
            username="comprador_checklist_cross_b", password="x",
            perfil=Usuario.Perfil.COMPRADOR, empresa=self.outra_empresa, filial=self.outra_filial,
        )
        UsuarioFilial.objects.create(usuario=comprador_b, filial=self.outra_filial, ativo=True)
        DiaOperacional.objects.create(empresa=self.outra_empresa, data=date(2026, 12, 25), tipo=DiaOperacional.Tipo.FERIADO)
        proprietario_b = Usuario.objects.create_user(
            username="prop_checklist_cross_b", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.outra_empresa,
        )
        Compra.objects.create(
            empresa=self.outra_empresa, filial=self.outra_filial, fornecedor=fornecedor_b, usuario=proprietario_b,
            valor=Decimal("100.00"), categoria=categoria_b,
        )
        Provisao.objects.create(
            empresa=self.outra_empresa, filial=self.outra_filial, comprador=comprador_b,
            fornecedor=fornecedor_b, categoria=categoria_b, data=date.today(), valor_total=Decimal("100.00"),
        )
        # Sprint de Correção do Checklist Guiado: os 3 sinais NOVOS
        # (itens 4, 10 e 13) também precisam ficar isolados por Empresa —
        # gravados aqui para a Empresa B do mesmo jeito que os mecanismos
        # antigos acima, para provar que também não vazam para a Empresa A.
        from auditoria.models import RegistroAuditoria
        from auditoria.services import registrar_evento

        from .models import LogConfiguracao

        LogConfiguracao.objects.create(
            empresa=self.outra_empresa, usuario=proprietario_b, area="Configuração Financeira",
            descricao="Configuração financeira revisada e salva — nenhum valor mudou.",
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.CALENDARIO_OPERACIONAL_REVISADO,
            descricao="Calendário Operacional revisado e confirmado pelo Proprietário.",
            empresa=self.outra_empresa, usuario=proprietario_b, modulo="financeiro", acao="confirmar_calendario",
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.RELATORIO_VISUALIZADO,
            descricao="Relatório de Compras por Filial visualizado pela primeira vez.",
            empresa=self.outra_empresa, usuario=proprietario_b, modulo="compras", acao="visualizar_relatorio",
        )

    def test_dados_de_outra_empresa_nao_marcam_itens_da_empresa_ativa(self):
        itens = calcular_checklist(self.empresa)
        concluidos = {i["numero"] for i in itens if i["concluido"]}
        # Só os itens estruturais que nascem prontos para QUALQUER Empresa
        # nova (1: Empresa cadastrada, 3: Regras gerais) — nada que a
        # Empresa B cadastrou vaza para a Empresa A.
        self.assertEqual(concluidos, {1, 3})

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_view_da_empresa_a_nao_mostra_progresso_da_empresa_b(self):
        client = Client()
        client.force_login(self.proprietario)
        resposta = client.get("/ncc/checklist/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "2 de 13 concluídos")


class ChecklistItensCorrigidosTestCase(TestCase):
    """Sprint de Correção do Checklist Guiado: um revisor independente
    encontrou 2 dos 13 itens (10 e 13) que NUNCA conseguiam ficar
    concluídos por desenho, e um terceiro (4) cujo sentinela podia ficar
    permanentemente errado por uma coincidência plausível de valor. Esta
    classe prova, via requisições HTTP reais (não ORM direto simulando o
    formulário), que os três agora completam por uma ação real do
    usuário — sempre uma consulta ao banco, nunca um estado de sessão."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Checklist Correcoes", cnpj="15.000.000/0001-15")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoPlataforma.objects.create(empresa=self.empresa, fuso_horario="America/Cuiaba")
        self.proprietario = Usuario.objects.create_user(
            username="prop_checklist_correcoes", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)

    # -- Item 4: sinal real de "formulário salvo", não o valor salvo -----

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_item_4_conclui_ao_salvar_o_formulario_mesmo_mantendo_o_percentual_padrao(self):
        # Cenário exato do bug relatado: o cliente decide, de propósito,
        # manter 30% (o valor padrão do model) — o critério antigo nunca
        # marcaria isso como "configurado".
        self.assertFalse(_item(calcular_checklist(self.empresa), 4)["concluido"])
        resposta = self.client.post("/financeiro/configuracao/", {
            "percentual_compras": "30.00", "percentual_seguranca": "0",
            "permitir_saldo_acumulativo": "", "redistribuicao_automatica": "",
            "permitir_ultrapassar_limite": "", "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA,
            "cor_principal": "#E11D2E", "moeda": ConfiguracaoFinanceira.Moeda.BRL,
        })
        self.assertEqual(resposta.status_code, 302, resposta.context["form"].errors if resposta.status_code == 200 else "")
        self.assertTrue(_item(calcular_checklist(self.empresa), 4)["concluido"])

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_item_4_visitar_a_tela_sem_submeter_continua_pendente(self):
        resposta = self.client.get("/financeiro/configuracao/")
        self.assertEqual(resposta.status_code, 200)
        self.assertFalse(_item(calcular_checklist(self.empresa), 4)["concluido"])

    # -- Item 10: confirmação explícita do Proprietário -------------------

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_item_10_conclui_com_confirmacao_explicita_do_proprietario_sem_nenhuma_excecao(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 10)["concluido"])
        resposta = self.client.post("/financeiro/calendario-operacional/", {"acao": "confirmar_revisao"})
        self.assertEqual(resposta.status_code, 302)
        # A confirmação NÃO cria nenhuma exceção — o item conclui pelo
        # segundo sinal real (o evento de confirmação), não pelo primeiro.
        self.assertFalse(DiaOperacional.objects.filter(empresa=self.empresa).exists())
        self.assertTrue(_item(calcular_checklist(self.empresa), 10)["concluido"])

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_item_10_confirmacao_e_exclusiva_do_proprietario(self):
        financeiro = Usuario.objects.create_user(
            username="fin_checklist_correcoes", password="x",
            perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa, filial=self.filial,
        )
        client_financeiro = Client()
        client_financeiro.force_login(financeiro)
        # O Financeiro TEM acesso à tela do calendário (`calendario.configurar`
        # é de PERFIS_GESTORES_FINANCEIROS), mas a confirmação do item 10 do
        # Checklist é reservada ao Proprietário — uma decisão de governança
        # sobre a implantação, não uma edição operacional do dia a dia.
        resposta = client_financeiro.post("/financeiro/calendario-operacional/", {"acao": "confirmar_revisao"})
        self.assertEqual(resposta.status_code, 302)
        self.assertFalse(_item(calcular_checklist(self.empresa), 10)["concluido"])

    # -- Item 13: primeira visita real ao relatório ------------------------

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_item_13_conclui_ao_visitar_o_relatorio_de_compras_por_filial(self):
        self.assertFalse(_item(calcular_checklist(self.empresa), 13)["concluido"])
        resposta = self.client.get("/compras/relatorios/por-filial/")
        self.assertEqual(resposta.status_code, 200)
        self.assertTrue(_item(calcular_checklist(self.empresa), 13)["concluido"])

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_item_13_visitas_repetidas_nao_empilham_eventos_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        self.client.get("/compras/relatorios/por-filial/")
        self.client.get("/compras/relatorios/por-filial/")
        self.client.get("/compras/relatorios/por-filial/")
        self.assertEqual(
            RegistroAuditoria.objects.filter(
                empresa=self.empresa, categoria=RegistroAuditoria.Categoria.RELATORIO_VISUALIZADO,
            ).count(),
            1,
        )
        self.assertTrue(_item(calcular_checklist(self.empresa), 13)["concluido"])


class ChecklistJornada13de13TestCase(TestCase):
    """Prova obrigatória (Sprint de Correção do Checklist Guiado): parte de
    um cenário limpo — o mesmo estado que `/primeiro-acesso/` deixa
    (Empresa + Filial Matriz só com nome + `ConfiguracaoPlataforma` +
    Proprietário), replicado via ORM no mesmo padrão já usado pelas
    outras classes deste arquivo (`ChecklistBaselineTestCase` etc.), sem
    depender da tela de Primeiro Acesso — que está sendo reescrita em
    paralelo por outra frente desta sprint — e então completa TODOS os 13
    itens por ações reais de usuário, sempre via requisição HTTP a uma URL
    real (POST em formulários reais, GET na visita ao relatório do item
    13), nunca por ORM direto simulando o preenchimento de um form."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Checklist Jornada 13", cnpj="17.000.000/0001-17")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz", ativo=True,
            tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoPlataforma.objects.create(empresa=self.empresa, fuso_horario="America/Cuiaba")
        self.proprietario = Usuario.objects.create_user(
            username="prop_checklist_jornada13", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()
        self.client.force_login(self.proprietario)

    def _assert_redirect(self, resposta, rotulo):
        if resposta.status_code != 302:
            erros = None
            if resposta.status_code == 200:
                erros = getattr(resposta.context.get("form"), "errors", None) if resposta.context else None
            self.fail(f"{rotulo}: esperava redirect (302), veio {resposta.status_code}. Erros do form: {erros}")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_todos_os_13_itens_concluem_por_acoes_reais_de_usuario_via_ui(self):
        # Itens 1 (Empresa cadastrada) e 3 (Regras gerais) já nascem
        # concluídos neste estado — é o mesmo baseline coberto em
        # `ChecklistBaselineTestCase.test_apenas_empresa_e_regras_gerais_concluidos`.
        itens = calcular_checklist(self.empresa)
        self.assertEqual({i["numero"] for i in itens if i["concluido"]}, {1, 3})

        # Item 2 — completar o cadastro fiscal da Filial Matriz.
        # CNPJ precisa passar no dígito verificador de verdade
        # (`core.validators.validar_cnpj`, aplicado pelo `FilialForm` via
        # `full_clean()`) — mesmo CNPJ estruturalmente válido já usado em
        # `empresas/tests.py::test_criar_filial_com_todos_os_blocos_preenchidos`.
        resposta = self.client.post(f"/ncc/filiais/{self.filial.pk}/", {
            "nome": "Matriz", "tipo_estabelecimento": Filial.TipoEstabelecimento.MATRIZ,
            "cnpj": "98.765.432/0001-98", "inscricao_estadual": "123456789",
            "razao_social": "Empresa Checklist Jornada 13 Comércio Ltda",
            "endereco": "Av. Central", "numero": "100", "bairro": "Centro",
            "cidade": "Cuiabá", "estado": "MT", "cep": "78000-000",
            "telefone": "(65) 3000-0000",
            "responsavel_nome": "Fulano de Tal", "responsavel_telefone": "(65) 99999-0000",
            "ativo": "on",
        })
        self._assert_redirect(resposta, "item 2 — completar filial matriz")

        # Item 4 — salvar a Configuração Financeira (mantendo o percentual
        # padrão de propósito — o cenário exato do bug relatado).
        resposta = self.client.post("/financeiro/configuracao/", {
            "percentual_compras": "30.00", "percentual_seguranca": "0",
            "permitir_saldo_acumulativo": "", "redistribuicao_automatica": "",
            "permitir_ultrapassar_limite": "", "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA,
            "cor_principal": "#E11D2E", "moeda": ConfiguracaoFinanceira.Moeda.BRL,
        })
        self._assert_redirect(resposta, "item 4 — configuração financeira")

        # Item 5 — cadastrar Receita.
        resposta = self.client.post("/financeiro/receitas/nova/", {
            "filial": self.filial.pk, "mes": date.today().replace(day=1).isoformat(), "faturamento": "50000.00",
        })
        self._assert_redirect(resposta, "item 5 — receita")

        # Item 6 — cadastrar Categoria.
        resposta = self.client.post("/cadastros/categorias/nova/", {
            "nome": "Categoria Jornada 13", "categoria_pai": "", "icone": "", "cor": "", "ativo": "on",
        })
        self._assert_redirect(resposta, "item 6 — categoria")
        categoria = Categoria.objects.get(empresa=self.empresa, nome="Categoria Jornada 13")

        # Item 7 — cadastrar Fornecedor.
        resposta = self.client.post("/compras/fornecedores/novo/", {
            "nome": "Fornecedor Jornada 13", "razao_social": "Fornecedor Jornada 13 Ltda",
            "cnpj": "17.111.111/0001-17", "ativo": "on",
        })
        self._assert_redirect(resposta, "item 7 — fornecedor")
        fornecedor = Fornecedor.objects.get(empresa=self.empresa, nome="Fornecedor Jornada 13")

        # Itens 8 e 9 — criar um segundo usuário (Comprador) já vinculado
        # à Filial Matriz: `UsuarioNovoForm.save()` cria automaticamente um
        # `UsuarioFilial` ativo para a filial escolhida, então uma única
        # ação real completa os dois itens de uma vez.
        resposta = self.client.post("/ncc/usuarios/novo/", {
            "first_name": "Comprador", "last_name": "Jornada 13", "email": "comprador.jornada13@x.com",
            "username": "comprador_checklist_jornada13", "filial": self.filial.pk,
            "perfil": Usuario.Perfil.COMPRADOR, "is_active": "on", "senha_inicial": "SenhaForte123",
        })
        self._assert_redirect(resposta, "itens 8/9 — novo usuário Comprador")

        # Item 10 — confirmação explícita do Proprietário, sem cadastrar
        # nenhuma exceção de calendário (o cenário que antes nunca concluía).
        resposta = self.client.post("/financeiro/calendario-operacional/", {"acao": "confirmar_revisao"})
        self._assert_redirect(resposta, "item 10 — confirmar calendário revisado")

        # Item 11 — lançar uma Compra de teste (qualquer status conta).
        resposta = self.client.post("/compras/nova/", {
            "filial": self.filial.pk, "fornecedor": fornecedor.pk, "valor": "50,00",
            "categoria": categoria.pk, "data_compra": date.today().isoformat(),
            "prazo_pagamento": Compra.PrazoPagamento.AVISTA,
        })
        self._assert_redirect(resposta, "item 11 — nova compra")

        # Item 12 — planejar uma Provisão de teste.
        resposta = self.client.post("/gestao-compras/nova/", {
            "filial": self.filial.pk, "fornecedor": fornecedor.pk, "categoria": categoria.pk,
            "data": date.today().isoformat(), "observacoes": "",
            "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0", "itens-MIN_NUM_FORMS": "0", "itens-MAX_NUM_FORMS": "1000",
            "itens-0-produto": "Item Jornada 13", "itens-0-quantidade": "1", "itens-0-valor_unitario": "50,00",
        })
        self._assert_redirect(resposta, "item 12 — nova provisão")

        # Item 13 — visitar o relatório de Compras por Filial pela primeira vez.
        resposta = self.client.get("/compras/relatorios/por-filial/")
        self.assertEqual(resposta.status_code, 200)

        # Prova obrigatória: 13/13, 100% — calculado 100% por consulta real
        # ao banco (`calcular_checklist`), nunca por uma flag manual.
        itens = calcular_checklist(self.empresa)
        concluidos = {i["numero"] for i in itens if i["concluido"]}
        self.assertEqual(concluidos, set(range(1, 14)), f"Itens ainda pendentes: {set(range(1, 14)) - concluidos}")
        resumo = resumo_checklist(itens)
        self.assertEqual(resumo, {"total": 13, "concluidos": 13, "percentual": 100})

        # A mesma prova, agora pela tela real do checklist (não só pela
        # função de cálculo isolada) — "13/13" e "100%" aparecem no HTML.
        resposta_checklist = self.client.get("/ncc/checklist/")
        self.assertEqual(resposta_checklist.status_code, 200)
        self.assertContains(resposta_checklist, "13 de 13 concluídos")
        self.assertContains(resposta_checklist, "100%")
