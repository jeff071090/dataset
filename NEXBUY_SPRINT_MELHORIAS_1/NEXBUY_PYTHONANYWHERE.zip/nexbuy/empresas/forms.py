from django import forms

from core.forms import BootstrapFormMixin

from .models import Empresa, IdentidadeVisual


class EmpresaForm(BootstrapFormMixin, forms.ModelForm):
    """Dados cadastrais da Empresa (Sprint 6, item 2). CNPJ, segmento e
    grupo empresarial não entram aqui de propósito — são dados
    administrativos/legais mais sensíveis, mantidos editáveis só via
    `/admin/` (mesmo padrão de acesso restrito que o resto do sistema já
    usa para configurações estruturais)."""

    class Meta:
        model = Empresa
        fields = [
            "razao_social",
            "nome",
            "inscricao_estadual",
            "telefone",
            "email",
            "endereco",
            "cidade",
            "estado",
            "cep",
        ]
        labels = {"nome": "Nome Fantasia"}


class IdentidadeVisualForm(BootstrapFormMixin, forms.ModelForm):
    """Personalização visual discreta (Sprint 6, item 3): logo, favicon,
    cor secundária e nome de exibição. `cor_principal` continua em
    `financeiro.ConfiguracaoFinanceira` (ver `Arquitetura.md`)."""

    class Meta:
        model = IdentidadeVisual
        fields = ["nome_exibicao", "logo", "favicon", "cor_secundaria"]
        widgets = {
            "cor_secundaria": forms.TextInput(attrs={"type": "color", "class": "form-control form-control-color"}),
        }
