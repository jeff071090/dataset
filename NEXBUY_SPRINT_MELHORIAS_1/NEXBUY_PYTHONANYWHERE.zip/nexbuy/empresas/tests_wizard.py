"""Testes do Assistente de Implantação (Sprint de Correções Críticas —
Seção 19). Este wizard não tinha NENHUM teste automatizado antes desta
Sprint, apesar de ser o único caminho de cadastro de Empresa/Grupo/Filial
matriz + primeiros usuários — exatamente a camada que a Seção 4 corrigiu
(CNPJ nunca reaproveitado, Grupo sempre novo na etapa 1, transação por
etapa, revalidação da Empresa da sessão)."""
from django.test import Client, TestCase
from django.test.utils import override_settings

from filiais.models import Filial
from usuarios.models import Usuario, UsuarioFilial

from .models import Empresa, GrupoEmpresarial


class AssistenteImplantacaoTestCase(TestCase):
    URL = "/ncc/implantacao/"

    def setUp(self):
        # Gravado com máscara de propósito (simula um cadastro real digitado
        # com pontuação) — `Empresa.save()` normaliza para dígitos por
        # baixo dos panos, mas a entrada aqui fica mascarada para que
        # `test_cnpj_com_formatacao_diferente_ainda_e_reconhecido_como_duplicado`
        # realmente exercite a comparação por dígitos, não uma coincidência
        # de string.
        self.empresa_existente = Empresa.objects.create(nome="Já Cadastrada Ltda", cnpj="11.222.333/0001-81")
        self.implantador = Usuario.objects.create_user(
            username="implantador", password="x", perfil=Usuario.Perfil.PROPRIETARIO, is_superuser=True,
        )
        self.client = Client()
        self.client.force_login(self.implantador)

    def _payload_etapa1(self, **overrides):
        base = {
            "grupo_nome": "Grupo Novo Cliente", "nome": "Empresa Nova", "razao_social": "Empresa Nova Ltda",
            "cnpj": "99888777000100", "cidade": "Campo Novo do Parecis", "estado": "MT",
            "filial_nome": "Matriz", "acao": "avancar",
        }
        base.update(overrides)
        return base

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_cnpj_ja_cadastrado_e_rejeitado_com_mensagem_exata(self):
        """Seção 4: CNPJ já existente em QUALQUER empresa nunca é
        reaproveitado silenciosamente — o wizard barra na validação do
        form, com a mensagem exata pedida pela Sprint."""
        resposta = self.client.post(self.URL, self._payload_etapa1(cnpj="11222333000181"))
        self.assertEqual(resposta.status_code, 200)  # form re-renderizado, sem avançar
        self.assertFormError(
            resposta.context["form"], "cnpj",
            "Este CNPJ já está cadastrado no NEXBUY. Se você precisa receber acesso a essa empresa, "
            "utilize a gestão de usuários e autorizações.",
        )
        self.assertEqual(Empresa.objects.filter(cnpj="11222333000181").count(), 1)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_cnpj_com_formatacao_diferente_ainda_e_reconhecido_como_duplicado(self):
        """Mesmo CNPJ, pontuação diferente — a comparação é por dígitos."""
        resposta = self.client.post(self.URL, self._payload_etapa1(cnpj="11222333000181"))
        self.assertEqual(resposta.status_code, 200)
        self.assertTrue(resposta.context["form"].errors.get("cnpj"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_cnpj_novo_cria_empresa_grupo_e_filial_matriz(self):
        resposta = self.client.post(self.URL, self._payload_etapa1())
        self.assertEqual(resposta.status_code, 302)
        empresa = Empresa.objects.get(cnpj="99888777000100")
        self.assertEqual(empresa.nome, "Empresa Nova")
        self.assertIsNotNone(empresa.grupo_id)
        self.assertEqual(empresa.grupo.nome, "Grupo Novo Cliente")
        self.assertTrue(Filial.objects.filter(empresa=empresa, nome="Matriz").exists())

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_duas_implantacoes_separadas_criam_grupos_isolados(self):
        """Isolamento entre grupos: duas implantações de clientes distintos
        (sem relação nenhuma entre si) nunca compartilham Grupo, mesmo se
        rodadas em sequência pelo mesmo implantador."""
        resposta1 = self.client.post(self.URL, self._payload_etapa1(
            grupo_nome="Grupo Cliente A", cnpj="10000000000145",
        ))
        self.assertEqual(resposta1.status_code, 302)
        empresa_a = Empresa.objects.get(cnpj="10000000000145")

        # Reinicia o wizard antes da segunda implantação — mesma sessão,
        # cliente totalmente diferente.
        self.client.post(self.URL, {"acao": "reiniciar"})
        resposta2 = self.client.post(self.URL, self._payload_etapa1(
            grupo_nome="Grupo Cliente B", cnpj="20000000000107",
        ))
        self.assertEqual(resposta2.status_code, 302)
        empresa_b = Empresa.objects.get(cnpj="20000000000107")

        self.assertNotEqual(empresa_a.grupo_id, empresa_b.grupo_id)
        self.assertEqual(GrupoEmpresarial.objects.filter(pk__in=[empresa_a.grupo_id, empresa_b.grupo_id]).count(), 2)

        # Isolamento de verdade: usuário de A não enxerga B como "empresa do grupo".
        usuario_a = Usuario.objects.create_user(username="dono_a_iso", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=empresa_a)
        empresas_do_grupo = list(usuario_a.empresas_do_grupo())
        self.assertIn(empresa_a, empresas_do_grupo)
        self.assertNotIn(empresa_b, empresas_do_grupo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_usuario_criado_na_etapa_3_ganha_vinculo_usuariofilial(self):
        """Seção 7: todo usuário não-Proprietário criado pelo wizard sai
        com `UsuarioFilial` explícito para a filial matriz — sem isso,
        `filiais_autorizadas_para` (Seção 9) não devolveria nada para ele."""
        self.client.post(self.URL, self._payload_etapa1(cnpj="30000000000152"))
        empresa = Empresa.objects.get(cnpj="30000000000152")
        filial = empresa.filiais.first()

        # A sessão só avança de etapa quando o redirect da etapa anterior é
        # SEGUIDO (GET com ?etapa=N) — exatamente como o navegador faria;
        # por isso cada POST abaixo já indica a etapa explicitamente, em
        # vez de confiar que o estado avançou sozinho.
        resposta_pular = self.client.post(f"{self.URL}?etapa=2", {"acao": "pular"})
        self.assertEqual(resposta_pular.status_code, 302)

        resposta = self.client.post(f"{self.URL}?etapa=3", {
            "username": "financeiro_wizard", "first_name": "Ana", "last_name": "Silva",
            "perfil": Usuario.Perfil.FINANCEIRO, "senha": "Farmacia#Forte2026", "acao": "avancar",
        })
        self.assertEqual(
            resposta.status_code, 302,
            resposta.context["form"].errors if resposta.status_code == 200 else "",
        )
        usuario = Usuario.objects.get(username="financeiro_wizard")
        self.assertTrue(
            UsuarioFilial.objects.filter(usuario=usuario, filial=filial, ativo=True).exists()
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_sessao_sem_empresa_valida_volta_para_etapa_1(self):
        """Seção 4, item 9: nenhuma etapa depois da 1 continua operando
        sobre uma referência de Empresa inválida."""
        self.client.post(self.URL, self._payload_etapa1(cnpj="40000000000106"))
        empresa = Empresa.objects.get(cnpj="40000000000106")
        empresa.ativo = False
        empresa.save(update_fields=["ativo"])

        resposta = self.client.get(f"{self.URL}?etapa=3")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.context["etapa_atual"], 1)
