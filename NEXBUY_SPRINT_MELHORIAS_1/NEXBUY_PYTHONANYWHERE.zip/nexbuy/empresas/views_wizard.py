"""Assistente de Implantação (Épico 13 — CORE 1.0).

Wizard de 9 etapas para colocar um cliente novo de pé: Empresa → CNPJs →
Usuários → Compradores → Financeiro → Calendário → Capacidade →
Aprovações → Finalização. A criação é incremental (cada etapa grava de
verdade, via models/forms existentes) e o progresso vive na sessão — o
implantador pode voltar etapas sem perder nada.
"""
from decimal import Decimal

from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.shortcuts import redirect, render

from core.permissions import permissao_required
from core.utils import formatar_cnpj
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, DiaOperacional, Receita
from gestao_compras.models import EtapaFluxo, FluxoAprovacao
from usuarios.models import Usuario, UsuarioFilial

from .forms_wizard import (
    WizardAprovacoesForm,
    WizardCalendarioForm,
    WizardCapacidadeForm,
    WizardCnpjForm,
    WizardCompradorForm,
    WizardEmpresaForm,
    WizardFinanceiroForm,
    WizardUsuarioForm,
)
from .models import Empresa, GrupoEmpresarial, LogConfiguracao

CHAVE_WIZARD = "wizard_implantacao"

ETAPAS = (
    (1, "Empresa"),
    (2, "CNPJs adicionais"),
    (3, "Usuários"),
    (4, "Compradores"),
    (5, "Financeiro"),
    (6, "Calendário"),
    (7, "Capacidade Financeira"),
    (8, "Aprovações"),
    (9, "Finalização"),
)

_FORMS_POR_ETAPA = {
    1: WizardEmpresaForm,
    2: WizardCnpjForm,
    3: WizardUsuarioForm,
    4: WizardCompradorForm,
    5: WizardFinanceiroForm,
    6: WizardCalendarioForm,
    7: WizardCapacidadeForm,
    8: WizardAprovacoesForm,
}

# Etapas em que o implantador pode adicionar vários itens antes de avançar.
_ETAPAS_REPETIVEIS = {2, 3, 4, 6}


def _estado(request):
    return request.session.setdefault(CHAVE_WIZARD, {"etapa": 1, "empresa_id": None, "criados": []})


def _salvar_estado(request, estado):
    request.session[CHAVE_WIZARD] = estado
    request.session.modified = True


def _empresa_do_wizard(estado):
    """Sprint de Correções Críticas (Seção 4, item 8) — revalida a Empresa
    guardada na sessão a cada chamada: se o registro não existir mais ou
    tiver sido desativado (ex.: excluída/desligada entre uma etapa e
    outra), o wizard não deve seguir operando sobre uma referência
    inválida. `None` sinaliza para a view voltar à etapa 1."""
    if not estado.get("empresa_id"):
        return None
    return Empresa.objects.filter(pk=estado["empresa_id"], ativo=True).first()


def _filial_matriz(empresa):
    """Gate pré-Etapa 10 (S1-1): prioriza a Filial explicitamente marcada
    como Matriz — cai para `.first()` só como compatibilidade com dados
    legados de antes desta correção (nenhuma Filial marcada de verdade)."""
    if empresa is None:
        return None
    matriz = empresa.filiais.filter(ativo=True, tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ).first()
    return matriz or empresa.filiais.filter(ativo=True).first()


@permissao_required("ncc.acessar")
def assistente_implantacao(request):
    # Sprint de Melhorias 1 (segurança): o passo 1 cria sempre um Grupo e uma
    # Empresa NOVOS — é ferramenta de implantação de cliente novo pelo
    # suporte, não do dia a dia da farmácia (os guias de uso já diziam "não
    # use"). Aberto a qualquer Proprietário, permitia criar empresas sem
    # contrato e "reservar" o CNPJ de outra empresa. Agora: só superusuário.
    if not request.user.is_superuser:
        raise PermissionDenied("O Assistente de Implantação é exclusivo do suporte técnico do NEXBUY.")
    estado = _estado(request)
    try:
        etapa = int(request.GET.get("etapa", estado.get("etapa", 1)))
    except (TypeError, ValueError):
        etapa = 1
    etapa = min(max(etapa, 1), 9)
    empresa = _empresa_do_wizard(estado)
    if etapa > 1 and empresa is None:
        # Sem empresa criada (ou ela deixou de existir/foi desativada entre
        # uma etapa e outra) — tudo depois da etapa 1 fica inválido.
        estado["empresa_id"] = None
        etapa = 1
        if estado.get("criados"):
            messages.info(request, "A empresa desta implantação não está mais disponível. Reiniciando o assistente.")
    form_class = _FORMS_POR_ETAPA.get(etapa)
    form = None

    if request.method == "POST":
        acao = request.POST.get("acao", "avancar")
        if acao == "reiniciar":
            request.session.pop(CHAVE_WIZARD, None)
            messages.info(request, "Assistente de implantação reiniciado.")
            return redirect("ncc:implantacao")
        if acao == "pular" and etapa in _ETAPAS_REPETIVEIS:
            estado["etapa"] = etapa + 1
            _salvar_estado(request, estado)
            return redirect(f"{request.path}?etapa={etapa + 1}")
        if acao == "concluir" and etapa == 9:
            if empresa is not None:
                LogConfiguracao.objects.create(
                    empresa=empresa, usuario=request.user, area="Implantação",
                    descricao=f'Implantação concluída pelo assistente ({len(estado.get("criados", []))} itens criados).',
                )
            request.session.pop(CHAVE_WIZARD, None)
            messages.success(request, "Implantação concluída com sucesso! A empresa está pronta para uso.")
            return redirect("ncc:home")

        if form_class is not None:
            form = form_class(request.POST)
            if form.is_valid():
                estado, etapa_seguinte = _processar_etapa(request, estado, etapa, form.cleaned_data, acao)
                _salvar_estado(request, estado)
                return redirect(f"{request.path}?etapa={etapa_seguinte}")

    if form is None and form_class is not None:
        form = form_class()

    estado["etapa"] = etapa
    _salvar_estado(request, estado)

    contexto = {
        "etapas": ETAPAS,
        "etapa_atual": etapa,
        "total_etapas": len(ETAPAS),
        "form": form,
        "empresa": empresa,
        "filial": _filial_matriz(empresa),
        "criados": estado.get("criados", []),
        "repetivel": etapa in _ETAPAS_REPETIVEIS,
        "resumo": _resumo_final(empresa) if etapa == 9 else None,
    }
    return render(request, "empresas/ncc/wizard.html", contexto)


def _processar_etapa(request, estado, etapa, dados, acao):
    """Aplica a etapa validada e devolve (estado, próxima etapa). Etapas
    repetíveis com ação "adicionar" permanecem na mesma etapa."""
    empresa = _empresa_do_wizard(estado)
    proxima = etapa if (etapa in _ETAPAS_REPETIVEIS and acao == "adicionar") else etapa + 1

    with transaction.atomic():
        if etapa == 1:
            # Sprint de Correções Críticas (Seção 4): a etapa 1 é sempre
            # implantação de um cliente NOVO — Grupo e Empresa são sempre
            # criados do zero, nunca reaproveitados por coincidência de
            # nome/CNPJ (o form já garante que o CNPJ não existe ainda;
            # `.create()` em vez de `.get_or_create()` remove por completo
            # o caminho que antes podia "adotar" um registro alheio).
            grupo = GrupoEmpresarial.objects.create(nome=dados["grupo_nome"])
            empresa = Empresa.objects.create(
                nome=dados["nome"],
                razao_social=dados["razao_social"],
                cnpj=dados["cnpj"],
                grupo=grupo,
                cidade=dados["cidade"],
                estado=dados["estado"],
            )
            # A cor de marca padrão do NEXBUY (azul) para empresas novas — a
            # ConfiguracaoFinanceira nasce aqui com cor vazia para não herdar
            # o default legado vermelho do model.
            ConfiguracaoFinanceira.objects.create(empresa=empresa, cor_principal="")
            Filial.objects.create(
                empresa=empresa, nome=dados["filial_nome"], ativo=True,
                tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
            )
            estado["empresa_id"] = empresa.pk
            estado["criados"].append(f"Empresa {empresa.nome} ({formatar_cnpj(empresa.cnpj)})")

        elif etapa == 2 and empresa is not None:
            # Mesmo raciocínio: CNPJ adicional é sempre uma Empresa NOVA,
            # sempre no MESMO grupo da implantação em curso (nunca por nome).
            nova = Empresa.objects.create(
                nome=dados["nome"], razao_social=dados["razao_social"], cnpj=dados["cnpj"], grupo=empresa.grupo,
            )
            ConfiguracaoFinanceira.objects.create(empresa=nova, cor_principal="")
            Filial.objects.create(
                empresa=nova, nome="Matriz", ativo=True, tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
            )
            estado["criados"].append(f"CNPJ adicional {nova.nome} ({formatar_cnpj(nova.cnpj)})")

        elif etapa in (3, 4) and empresa is not None:
            filial = _filial_matriz(empresa)
            perfil = dados["perfil"]
            usuario = Usuario.objects.create_user(
                username=dados["username"],
                password=dados["senha"],
                first_name=dados["first_name"],
                last_name=dados["last_name"],
            )
            # Sprint de Correções Críticas (Seção 4, itens 4-6): o usuário
            # criado pelo wizard pertence SOMENTE à empresa desta
            # implantação — nunca a outra empresa/grupo.
            usuario.perfil = perfil
            usuario.empresa = empresa
            usuario.filial = None if perfil == Usuario.Perfil.PROPRIETARIO else filial
            usuario.save()
            if filial is not None and perfil != Usuario.Perfil.PROPRIETARIO:
                _, vinculo_criado = UsuarioFilial.objects.get_or_create(
                    usuario=usuario, filial=filial, defaults={"ativo": True}
                )
                if vinculo_criado:
                    # Sprint de Correções Críticas (Seção 18): vínculo
                    # usuário-Filial não tinha NENHUMA trilha de auditoria
                    # até aqui — nem no log persistente (LogConfiguracao),
                    # nem no resumo do próprio assistente.
                    from .models import LogConfiguracao

                    LogConfiguracao.objects.create(
                        empresa=empresa, usuario=request.user, area="Usuários e Permissões",
                        descricao=f"Usuário {usuario.username} vinculado à filial \"{filial.nome}\" (Assistente de Implantação).",
                    )
            estado["criados"].append(f"Usuário {usuario.username} ({usuario.get_perfil_display()})")

        elif etapa == 5 and empresa is not None:
            filial = _filial_matriz(empresa)
            if filial is not None:
                from datetime import date

                Receita.objects.update_or_create(
                    filial=filial, mes=date.today().replace(day=1), defaults={"faturamento": dados["faturamento"]}
                )
                estado["criados"].append("Faturamento do mês cadastrado")

        elif etapa == 6 and empresa is not None:
            DiaOperacional.objects.update_or_create(
                empresa=empresa, data=dados["data"],
                defaults={"tipo": dados["tipo"], "observacao": dados["observacao"]},
            )
            estado["criados"].append(f'Calendário: {dados["data"]:%d/%m/%Y} ({dados["tipo"]})')

        elif etapa == 7 and empresa is not None:
            config, _ = ConfiguracaoFinanceira.objects.get_or_create(empresa=empresa, defaults={"cor_principal": ""})
            config.percentual_compras = dados["percentual_compras"]
            config.percentual_seguranca = dados["percentual_seguranca"]
            config.dias_uteis_manual = dados["dias_uteis_manual"]
            config.save(update_fields=["percentual_compras", "percentual_seguranca", "dias_uteis_manual", "atualizado_em"])
            estado["criados"].append("Capacidade financeira configurada")

        elif etapa == 8 and empresa is not None:
            config, _ = ConfiguracaoFinanceira.objects.get_or_create(empresa=empresa, defaults={"cor_principal": ""})
            config.regra_excesso = dados["regra_excesso"]
            config.save(update_fields=["regra_excesso", "atualizado_em"])
            if dados["criar_fluxo_padrao"]:
                fluxo, criado = FluxoAprovacao.objects.get_or_create(
                    empresa=empresa, nome="Fluxo padrão de implantação", defaults={"ativo": True}
                )
                if criado:
                    EtapaFluxo.objects.create(
                        fluxo=fluxo, ordem=1, perfil_aprovador=Usuario.Perfil.GERENTE, prazo_dias=2,
                        observacao="Criada pelo Assistente de Implantação.",
                    )
                    EtapaFluxo.objects.create(
                        fluxo=fluxo, ordem=2, perfil_aprovador=Usuario.Perfil.FINANCEIRO, prazo_dias=2,
                        observacao="Criada pelo Assistente de Implantação.",
                    )
                    FluxoAprovacao.objects.filter(empresa=empresa, ativo=True).exclude(pk=fluxo.pk).update(ativo=False)
                    estado["criados"].append("Fluxo de aprovação padrão criado (Gerente → Financeiro)")
            estado["criados"].append("Regra de aprovação configurada")

    return estado, proxima


def _resumo_final(empresa):
    if empresa is None:
        return None
    return {
        "empresa": empresa,
        "filiais": empresa.filiais.filter(ativo=True).count(),
        "usuarios": Usuario.objects.filter(empresa=empresa).count(),
        "compradores": Usuario.objects.filter(empresa=empresa, perfil=Usuario.Perfil.COMPRADOR).count(),
        "config": getattr(empresa, "configuracao_financeira", None),
        "fluxo_ativo": FluxoAprovacao.objects.filter(empresa=empresa, ativo=True).first(),
        "dias_operacionais": DiaOperacional.objects.filter(empresa=empresa).count(),
    }
