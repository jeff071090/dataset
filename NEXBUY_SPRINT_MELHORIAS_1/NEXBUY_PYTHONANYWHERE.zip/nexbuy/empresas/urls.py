from django.urls import path

from . import views

app_name = "empresas"

urlpatterns = [
    path("", views.empresa_editar, name="editar"),
    path("identidade-visual/", views.identidade_visual_editar, name="identidade_visual"),
]
