# NEXBUY — Roteiros de Demonstração Comercial (Etapa 02)

Este documento reúne **dois roteiros separados**, para duas situações
diferentes de demonstração. Os dois usam o **Pacote B** (demo comercial
isolada) — nunca o banco/mídia principal do NEXBUY. Para o "como rodar
tecnicamente" (qual launcher `.bat` usar, como resetar, o que nunca fazer),
ver [NEXBUY_GUIA_DEMO_CLIENTE.md](NEXBUY_GUIA_DEMO_CLIENTE.md). Este
documento é sobre a **apresentação em si** — o que falar e mostrar em cada
minuto.

| | Roteiro A — Cenário vazio | Roteiro B — Cenário pronto |
|---|---|---|
| Duração | 20–30 min | 15–20 min |
| Ponto de partida | Banco de demo **vazio** — cadastro ao vivo | Banco de demo **já povoado** (`seed_demo`) |
| Launcher | `iniciar_demo_cliente_limpa.bat` | `iniciar_demo_cenario_pronto.bat` |
| Melhor para | Provar que o produto é real e o cliente mesmo vai configurá-lo — venda ou piloto novo | Mostrar rápido a plataforma madura, com histórico rico (compras, provisões, auditoria já povoados) |
| Dados | 100% cadastrados na hora, na frente do cliente | Fictícios ("Farmácia Vida Plena") — deixe isso claro na abertura |

Os dois roteiros terminam com o mesmo bloco
["Não prometer ao cliente"](#não-prometer-ao-cliente-vale-para-os-dois-roteiros),
no fim deste documento.

## A nova navegação (V4) — mostre em qualquer um dos roteiros

A navegação foi reorganizada por tarefa e por perfil (Microsprint V4).
Cinco pontos rápidos que valem ouro na apresentação:

1. **Grupos do Proprietário** — o menu lateral tem só 6 destinos de
   primeiro nível: Início, Compras, Financeiro, Gestão, Relatórios e
   Configurações. Abra um grupo e mostre que o sistema inteiro cabe em
   meia dúzia de escolhas — "seu time não precisa decorar 14 telas".
2. **Cada perfil vê a sua casa** — troque de usuário (Comprador →
   Financeiro → Gerente) e mostre o menu mudando: o Comprador tem
   Planejamento de Compras; o Financeiro tem o grupo Planejamento com
   receitas, custos e contas a pagar; o Gerente tem um menu curto focado
   em decisão.
3. **Compra × Provisão** — no painel do Comprador, aponte a linha de
   ajuda: *Compra registra o que já aconteceu; Provisão planeja e reserva
   valor para uma compra futura*. É a dúvida nº 1 de todo cliente novo.
4. **Onde estou? Como volto?** — em qualquer tela interna, mostre o
   breadcrumb no topo (ex.: Início › Planejamento Financeiro › Custos
   Fixos › Novo Custo Fixo) e o grupo do menu aberto e destacado. Volte
   um nível clicando no próprio breadcrumb.
5. **No celular** — estreite a janela (ou abra no celular): a barra
   inferior traz as 3 ações mais usadas do perfil + o botão Menu, que
   abre o mesmo menu lateral completo.

E, como sempre: em Configurações → Integrações aparece só o DDA, marcado
honestamente como "Não conectado — integração prevista" — recurso futuro,
nunca prometido como pronto. Receitas, custos e compras são lançamento
manual: é assim que o sistema funciona hoje.

## Escopo atual (vale para os dois roteiros)

- **Sistema 100% web.** Sem integração com ERP (decisão da cliente) e sem
  controle de estoque.
- **Receitas, custos, compras: lançamento manual.** Receita mensal,
  receitas extras, custos fixos e custos variáveis alimentam a projeção de
  compra e os limites dos compradores.
- **Análise Financeira** (DRE, créditos × débitos, saúde financeira, com
  curvas) para Proprietário, Gerente e Financeiro. O Comprador continua com
  a visão sintética, sem nenhum dado financeiro sensível.
- **DDA: integração futura prevista (não conectada).**

---

## Roteiro A — Cenário vazio/guiado (20–30 min)

Parte do **ambiente de demo totalmente vazio** — o mesmo estado em que o
cliente recebe o produto de verdade — e serve para mostrar ao cliente, ao
vivo, como é o primeiro dia de uso do NEXBUY. Use o launcher
`iniciar_demo_cliente_limpa.bat` (nunca o banco/mídia principal).

### Frase de abertura (use exatamente esta, ou muito próxima)

> "O NEXBUY já está funcional, 100% na web. Você pode cadastrar sua
> estrutura agora mesmo e lançar receitas, custos, compras e provisões,
> com limites, aprovações, agenda, Análise Financeira e relatórios. Tudo
> é lançado manualmente pela tela; a única integração prevista é o DDA,
> ainda não conectada — e o produto não depende dela para funcionar hoje."

### Pré-demo (5 min antes)

1. Rode `iniciar_demo_cliente_limpa.bat` (ver
   [NEXBUY_GUIA_DEMO_CLIENTE.md](NEXBUY_GUIA_DEMO_CLIENTE.md) para os
   detalhes). Ele isola tudo em `db_demo_cliente.sqlite3`/
   `media_demo_cliente\` — nunca `db.sqlite3`/`media\` — e imprime, no
   terminal, um **token de Primeiro Acesso válido só para esta sessão**.
2. Se o banco de demo já tiver sido usado numa apresentação anterior, rode
   antes `resetar_demo_cliente_limpa.bat` para começar de um banco vazio de
   verdade (o launcher pergunta confirmação antes de apagar qualquer coisa).
3. Anote o token impresso no terminal — você vai digitá-lo no formulário,
   ao vivo, no passo 1 abaixo. **Nunca cole o token na URL do navegador.**
4. O launcher já abre `/primeiro-acesso/` numa aba nova.

### Minuto a minuto

**[0:00–0:30] Abertura.** Frase de abertura acima. "Vamos montar a empresa
do zero, na sua frente — nada disso é fictício."

**[0:30–2:30] 1. Primeiro Acesso seguro.**
- A tela `/primeiro-acesso/` abre **sem nenhum token na URL** — ela nunca
  aceita `?token=...`. Mostre isso explicitamente: "repare que não existe
  nada na barra de endereço — o token nunca fica exposto num link".
- Digite o token (impresso no terminal pelo launcher) no formulário
  protegido por CSRF que aparece na tela. Só depois de confirmado, o
  formulário de cadastro da empresa aparece — já numa URL limpa.
- Preencher ao vivo: nome do Proprietário, usuário, senha forte, nome do
  grupo/empresa, CNPJ (pode ser um CNPJ de teste válido), Filial Matriz,
  fuso horário.
- Confirmar e enviar. Mostrar o redirecionamento direto para o login —
  "nenhuma senha padrão, nenhuma conta pré-criada: a senha que ele acabou
  de digitar é a única que existe agora".
- Logar como Proprietário. Mostrar o **Checklist de Implantação**
  (`/ncc/checklist/`) — "o sistema já sabe exatamente o que falta, sem eu
  precisar marcar nada manualmente".

**[2:30–4:30] 2. Configuração rápida.**
- Completar dados fiscais da Filial (`/ncc/filiais/<id>/`) — CNPJ, IE,
  endereço, responsável.
- Regras gerais (`/ncc/gerais/`) e Capacidade Financeira
  (`/financeiro/configuracao/`): "aqui você define que percentual do
  faturamento vira limite diário de compra".

**[4:30–6:30] 3. Faturamento, custos e limites.**
- Cadastrar o faturamento do mês (`/financeiro/receitas/nova/`) — "sem
  isso, o motor não tem base para calcular capacidade; e olha como o
  dashboard já reagiu".
- Se houver tempo, lançar uma receita extra e um custo fixo (Financeiro →
  Planejamento) — "tudo manual, pela tela: é isso que alimenta a projeção
  de compra e os limites dos compradores".
- Voltar ao Dashboard do Proprietário: mostrar a capacidade do dia mudando
  de "sem dado suficiente" para um valor real.

**[6:30–8:30] 4. Cadastro da equipe.**
- Criar Gerente, Financeiro e um Comprador (`/ncc/usuarios/novo/`) —
  mostrar a senha provisória gerada.
- Vincular o Comprador à Filial e definir um limite individual
  (`/financeiro/capacidade-compradores/`).
- Cadastrar uma Categoria e um Fornecedor (`/cadastros/categorias/`,
  `/compras/fornecedores/`).

**[8:30–10:30] 5. Compra pelo Comprador.**
- Logar como o Comprador criado. Mostrar o dashboard "Posso comprar hoje?"
  já com dado real.
- Lançar uma Compra **dentro do limite** (aprovada na hora) e uma **acima
  do limite** (vai para aprovação) — `/compras/nova/`.

**[10:30–12:00] 6. Aprovação pelo Gerente.**
- Logar como Gerente. `/aprovacoes/`: a Compra pendente aparece na fila.
  Aprovar com uma justificativa — "toda decisão fica registrada, com quem
  decidiu e por quê".

**[12:00–13:30] 7. Agenda pelo Financeiro.**
- Logar como Financeiro. Mostrar a parcela gerada pela Compra aprovada na
  Agenda Financeira (`/financeiro/agenda/`).
- Baixar a parcela; em seguida mostrar o estorno com justificativa —
  "controle financeiro de verdade, sem gambiarra".

**[13:30–15:30] 8. Visão do Proprietário.**
- Voltar ao Proprietário. Dashboard Executivo já com dados reais: receita,
  compras, fluxo, ranking de fornecedores.
- Relatórios por Filial e por Comprador (`/compras/relatorios/`) — "os
  totais somam só o que foi realmente aprovado; pendente ou bloqueado nunca
  entra na conta".
- Análise Financeira — DRE, créditos × débitos e saúde financeira, com
  curvas, calculados a partir do que acabou de ser lançado (visível para
  Proprietário, Gerente e Financeiro; nunca para o Comprador).

**[15:30–17:00] 9. Auditoria.**
- `/ncc/central-auditoria/` — mostrar a trilha completa desde o Primeiro
  Acesso até a Compra aprovada, com origem real de cada evento
  (Implantação, Compras, Financeiro).

**[17:00–18:30] 10. Integração futura (DDA).**
- `/ncc/integracoes/` — "Aqui aparece só o DDA, claramente marcado como
  Não conectado — integração prevista. Quando conectado, ele traz os
  boletos apresentados ao CNPJ para a Agenda, para o Financeiro conferir;
  nunca paga nada sozinho. E como você acabou de ver, o produto inteiro
  funciona hoje por lançamento manual, sem depender dele."

**[18:30–20:00] Fecho.** "Foi isso que você acabou de ver: um sistema que
começa vazio, honesto sobre o que ainda não faz, e completamente utilizável
desde o primeiro minuto — sem `/admin`, sem senha padrão, sem dado
fictício." CTA: iniciar o piloto com os dados reais do cliente.

---

## Roteiro B — Cenário pronto (15–20 min)

Parte do banco de demo **já povoado** por `seed_demo` — a empresa fictícia
"Farmácia Vida Plena", com fornecedores, provisões e compras em estados
variados e **12 meses de histórico** nas duas lojas (receitas, custos e
compras de uma farmácia plausível) para a Análise Financeira. Serve para uma demonstração mais rápida, quando o histórico já
maduro (calendário colorido, aprovações pendentes, auditoria com trilha
real) importa mais do que mostrar o cadastro do zero. Use o launcher
`iniciar_demo_cenario_pronto.bat`.

### Frase de abertura (use exatamente esta, ou muito próxima)

> "O que você vai ver agora é uma empresa fictícia — 'Farmácia Vida Plena'
> — já com um ano de operação simulada, para mostrar rápido tudo que o
> NEXBUY faz no dia a dia. Nenhum dado aqui é real; quando entrarmos no seu
> piloto, você vai ver a tela exatamente assim, mas vazia e com os seus
> dados."

### Pré-demo (5 min antes)

1. Rode `iniciar_demo_cenario_pronto.bat` (ver
   [NEXBUY_GUIA_DEMO_CLIENTE.md](NEXBUY_GUIA_DEMO_CLIENTE.md)). Ele aplica
   as migrações e roda `seed_demo` — **só** no banco isolado
   (`db_demo_cliente.sqlite3`/`media_demo_cliente\`) — e imprime no
   terminal as credenciais de demonstração.
2. `seed_demo` é idempotente: pode rodar de novo a qualquer momento (antes
   de cada apresentação, por exemplo) para "resetar a história" do mês sem
   perder nada — não precisa apagar o banco entre uma demo e outra.
3. O launcher já abre `/accounts/login/` numa aba nova.

### Minuto a minuto

**[0:00–1:00] Abertura e badge de demonstração.** Frase de abertura acima.
Aponte o badge **"Modo Demonstração"** visível no topo da tela — o launcher
`iniciar_demo_cenario_pronto.bat` liga `DEMO_MODE=True` porque este cenário
usa dados fictícios (no Roteiro A, de cadastro ao vivo, o badge não aparece:
o launcher limpo define `DEMO_MODE=False`). "Isso fica sempre visível aqui
para nunca confundir dado fictício com dado real; no seu ambiente, esse
badge não existe".

**[1:00–3:00] Login como Comprador (`demo_comprador` — Juliana).**
- Dashboard "Posso comprar hoje?" já com capacidade calculada, Central de
  Decisão com mensagens reais geradas a partir dos dados do seed.
- Calendário Inteligente (`/gestao-compras/`) — mês com dias tranquilos, um
  dia de atenção e um dia crítico.
- **Lançar uma Compra ao vivo** (`/compras/nova/`) — dentro do limite,
  aprovada na hora.
- Login como `demo_comprador2` (Pedro, limite individual de R$ 2.000,00):
  lance uma compra acima do limite para mostrar a dotação diária mandando
  para aprovação.

**[3:00–5:30] Aprovar/rejeitar pelo Gerente (`demo_gerente` — Fernanda).**
- `/aprovacoes/`: fila única (compras + provisões pendentes). Aprove uma
  com justificativa — "toda decisão fica registrada, com quem decidiu e por
  quê".
- Mostre também um desfecho negativo já no histórico: a demo já tem uma
  Compra **Rejeitada** e uma **Bloqueada** (Carla/`demo_comprador3`,
  bloqueada pelo Financeiro — qualquer compra dela sai barrada na origem).
  "Os 4 status existem de verdade: aprovada, pendente, rejeitada e
  bloqueada — nenhum deles é só uma cor na tela."

**[5:30–8:00] Bloquear/liberar e operar a Agenda pelo Financeiro
(`demo_financeiro` — Marcos).**
- `/financeiro/capacidade-compradores/`: os 3 estados lado a lado — Juliana
  com limite de R$ 3.500,00, Pedro com R$ 2.000,00, Carla bloqueada. Ao
  vivo: altere um limite, bloqueie/libere um comprador e mostre a
  notificação chegando para ele.
- Agenda Financeira (`/financeiro/agenda/`) — dê baixa numa parcela e, em
  seguida, mostre o estorno com justificativa.
- Calendário Financeiro (`/financeiro/calendario/`) — visões mensal,
  semanal e diária; filtre por origem, pesquise "folha".

**[8:00–10:30] "A farmácia está saudável?" — Análise Financeira
(`demo_financeiro` — Marcos; o Proprietário vê a mesma tela).**
- Menu **Análise Financeira** → **DRE Gerencial**: receita (mensal +
  convênios/PBM, serviços, rendimentos), compras aprovadas em torno de 60%
  a 65% da receita nos meses fechados, custos variáveis (~8%) e fixos
  (~20% a 22%), margens e resultado. Na curva de 12 meses, aponte o mês que
  fechou no **prejuízo** (compras muito acima do normal) e a receita
  caindo nos últimos meses. A DRE do mês corrente compara as compras até
  hoje com a receita do mês inteiro: antes do dia 25, use « mês anterior »
  para mostrar um mês fechado.
- **Créditos × Débitos**: o "balancete" do mês — entradas e saídas por
  vencimento, a maior entrada e a maior saída — e o mês em que o caixa
  ficou no vermelho (as parcelas do mês ruim vencendo).
- **Saúde Financeira**: semáforo com referência de mercado em cada
  indicador, ponto de equilíbrio e as recomendações em reais ("receita em
  queda", "custos fixos acima da referência"), cada uma com o link da tela
  onde se age.
- **Frase sugerida:** "Com o que vocês já lançam no dia a dia, o NEXBUY
  fecha o mês sozinho: mostra se sobrou dinheiro, para onde ele foi e o
  que ajustar antes que vire problema."
- **Pergunta para a cliente:** "Hoje, no fim do mês, vocês sabem quanto
  sobrou e qual despesa mais pesou? Quanto tempo leva para ter essa
  resposta?"
- O Gerente (`demo_gerente`) vê a mesma análise da própria loja, em R$; o
  Comprador não tem o menu nem acesso à tela.

**[10:30–13:00] Visão consolidada do Proprietário (`demo_proprietario` —
Roberto).**
- Dashboard Executivo — Receita do mês, Ranking de Fornecedores, Alertas
  Estratégicos.
- Troque de empresa no seletor do topo (2ª empresa "Drogaria Vida Plena
  Norte") e volte; clique em "Ver consolidado".
- `/ncc/` — passeie por Workflow (Gerente até R$ 2.000, depois Financeiro),
  Usuários e Permissões (RBAC — perfil "Consulta Financeira" da Fernanda) e
  Calendário Operacional (feriado/bloqueio/sábado especial de exemplo).

**[13:00–15:00] Relatórios e auditoria.**
- Relatórios por Filial e por Comprador (`/compras/relatorios/`) — "os
  totais somam só o que foi realmente aprovado; a Compra rejeitada e a
  bloqueada que você viu não entram na conta".
- `/ncc/central-auditoria/` — mostre a trilha de um evento com
  `correlation_id` (ex.: a Provisão que virou Compra efetivada) — a cadeia
  completa aparece com um clique.

**[15:00–16:00] Integração futura (DDA).**
- `/ncc/integracoes/` — só o DDA aparece, claramente marcado como Não
  conectado — integração prevista. Reforce: receitas, custos e compras são
  lançados manualmente.

**[16:00–18:00] Fecho com limitações honestas.** "Você acabou de ver um ano
de operação — compras, aprovações, bloqueios, agenda, análise financeira,
auditoria —
tudo com as mesmas regras que valem no seu ambiente real. O que você NÃO
viu, porque não faz parte do produto: controle de estoque e integração com
ERP — os lançamentos são manuais, por decisão de escopo. O DDA é a única
integração prevista e ainda não está conectado — prefiro te dizer isso
agora do que você descobrir depois." CTA: agendar o Roteiro A (cenário
vazio) como prova final antes do piloto, ou iniciar o piloto direto.

---

## Não prometer ao cliente (vale para os dois roteiros)

- DDA ativo ou conciliação bancária automática (o DDA é integração futura
  prevista, não conectada).
- Integração com ERP (não haverá, por decisão da cliente — os lançamentos
  são manuais).
- Sugestão automática de compra (a decisão é sempre de uma pessoa).
- Controle de estoque ou cadastro de produtos (o NEXBUY não tem essas
  funcionalidades — nomes de produto são texto livre).
- Sincronização automática de qualquer tipo.
- Pagamento bancário disparado pelo sistema.
- Aplicativo móvel nativo (o NEXBUY é responsivo no navegador, não um app
  nativo).
- Qualquer funcionalidade que você não tenha acabado de mostrar ao vivo
  nesta mesma demonstração.

## Isolamento técnico (os dois roteiros)

Os dois launchers (`iniciar_demo_cliente_limpa.bat` e
`iniciar_demo_cenario_pronto.bat`) usam **sempre** `db_demo_cliente.sqlite3`
e `media_demo_cliente\` — nunca `db.sqlite3` nem `media\`. É seguro rodar
qualquer um dos dois roteiros na mesma máquina onde roda (ou já rodou) o
ambiente cliente-ready real: os dois nunca compartilham banco nem mídia.
Detalhes completos em
[NEXBUY_GUIA_DEMO_CLIENTE.md](NEXBUY_GUIA_DEMO_CLIENTE.md).
