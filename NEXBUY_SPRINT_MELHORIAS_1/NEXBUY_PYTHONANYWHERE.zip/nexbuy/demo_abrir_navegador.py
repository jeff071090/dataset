"""Espera o servidor da demonstracao responder e abre o navegador.

Usado pelo INICIAR_DEMO_NEXBUY.bat: roda em segundo plano no mesmo console
enquanto o `runserver` sobe em primeiro plano. So abre o navegador depois
que a aplicacao responde HTTP 200 na tela de login — nunca abre uma pagina
de erro em branco na frente do cliente.

Nao usa internet nem nenhum servico externo: a unica requisicao e para o
proprio 127.0.0.1.
"""
import sys
import time
import urllib.request
import webbrowser

porta = sys.argv[1] if len(sys.argv) > 1 else "8000"
url = f"http://127.0.0.1:{porta}/accounts/login/"

for _ in range(120):  # ate ~60 segundos
    try:
        with urllib.request.urlopen(url, timeout=2) as resposta:
            if resposta.status == 200:
                webbrowser.open(url)
                print(f"\n[OK] Aplicacao respondendo em {url} — navegador aberto.")
                sys.exit(0)
    except Exception:
        pass
    time.sleep(0.5)

print(
    f"\n[AVISO] A aplicacao nao respondeu em {url} apos 60 segundos.\n"
    "Veja as mensagens de erro acima nesta janela. Proximos passos:\n"
    "  1) Rode PREPARAR_DEMO_NEXBUY.bat e tente de novo;\n"
    "  2) Se a porta estiver em uso por outro programa, feche-o ou\n"
    "     aguarde o INICIAR escolher uma porta alternativa."
)
sys.exit(1)
