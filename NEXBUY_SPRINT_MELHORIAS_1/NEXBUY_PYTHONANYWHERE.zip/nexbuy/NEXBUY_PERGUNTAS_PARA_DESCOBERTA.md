# NEXBUY — Perguntas para Descoberta

Dez perguntas curtas. Use no máximo uma por cena durante a demonstração e
o restante na conversa de fechamento (ou envie por escrito depois). Anote
as respostas — elas viram o desenho da próxima demonstração personalizada.

1. Quantas empresas (CNPJs) e quantas filiais precisam ser acompanhadas?
2. Quantas pessoas compram hoje, e quem são os aprovadores?
3. Hoje, quem define o limite de compra — e onde isso está anotado?
4. Como uma compra acima do limite é aprovada hoje (grupo de WhatsApp,
   telefone, planilha)?
5. Quando o Financeiro descobre os compromissos futuros — antes ou depois
   do boleto chegar?
6. Qual informação mais demora para chegar ao proprietário?
7. Com que frequência acontecem compras "surpresa" que estouram o caixa
   do dia?
8. Se precisarem reconstituir uma decisão de compra de 3 meses atrás,
   quanto tempo leva?
9. Quem vai lançar a receita mensal, as receitas extras e os custos no
   NEXBUY — e com que frequência (diária, semanal, no fechamento do mês)?
10. Se pudessem resolver UM problema da rotina de compras nos próximos 90
    dias, qual seria?
