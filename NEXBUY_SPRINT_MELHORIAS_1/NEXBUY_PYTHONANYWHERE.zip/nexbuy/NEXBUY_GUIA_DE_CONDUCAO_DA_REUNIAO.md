# NEXBUY — Guia de Condução da Reunião

Como conduzir a apresentação para gerar confiança e um próximo passo
concreto — sem espetáculo vazio e sem prometer o que não existe.

## Abertura de 60 segundos

Com `/demo/apresentacao/` na tela, fale (adapte com naturalidade):

> "Antes de mostrar telas, uma frase: o NEXBUY leva a operação de compras
> **da intenção à decisão — com controle, previsibilidade e
> rastreabilidade**. Em vez de eu listar módulos, vou contar a história de
> UMA compra: o comprador planeja, o sistema aplica as regras que VOCÊS
> definem, quem tem alçada decide, o financeiro enxerga o compromisso
> antes do boleto, a análise financeira mostra se a farmácia está
> saudável, e o proprietário acompanha tudo com auditoria. São uns 15
> minutos. Tudo que vou mostrar está rodando de verdade, com dados
> fictícios. Podemos começar?"

Clique **Iniciar demonstração** e siga o Guia da apresentação.

## Como perguntar sem virar interrogatório

- No máximo **uma pergunta por cena**, sempre depois de mostrar algo
  (mostre → pergunte → escute). As perguntas prontas estão no roteiro.
- Prefira perguntas de experiência ("como é hoje?") a perguntas de
  opinião ("gostou?").
- Se o cliente falar, **pare de navegar** e escute. Anote os termos que
  ele usar (loja, matriz, alçada) e repita-os nas cenas seguintes.
- Se o cliente não engajar, siga a história — não force.

## Quando deixar o cliente interagir

Duas vezes, e sempre com você no teclado OU o cliente digitando um único
campo (o valor):

1. **Cena 2** — valor pequeno, dentro do limite (aprova na hora);
2. **Cena 3** — valor grande, acima do limite (vira solicitação).

Não entregue o mouse para navegação livre: a história perde o fio e
aparecem telas fora do roteiro.

## Se perguntarem PREÇO

Nunca invente valor. Responda:

> "O investimento depende do número de empresas, filiais e usuários e do
> pacote de implantação. Prefiro levar essa pergunta com a estrutura real
> de vocês e voltar com uma proposta fechada — posso anotar quantas
> filiais e usuários seriam?"

Isso transforma a pergunta de preço em levantamento de escopo (use
`NEXBUY_PERGUNTAS_PARA_DESCOBERTA.md`).

## Se perguntarem PRAZO

Nunca prometa data. Responda:

> "Depende do que entra na primeira fase. O núcleo que vocês viram já
> está pronto; a implantação é configurar empresas, filiais, perfis e
> limites — não é um projeto de desenvolvimento. O que eu posso fazer é
> mapear a estrutura de vocês e voltar com um plano de implantação por
> etapas, com o que entra em cada uma."

## Como explicar os lançamentos manuais e o DDA

Sempre a mesma estrutura: **o que faz hoje → o que muda no futuro →
status honesto**.

- **Receitas, custos e compras: lançamento manual.** "O NEXBUY é 100%
  web. A receita mensal, as receitas extras, os custos fixos e variáveis e
  as compras são lançados aqui mesmo, pela tela — e é isso que alimenta a
  projeção de compra e os limites de cada comprador. Não depende de nenhum
  outro sistema para funcionar."
- **Análise Financeira (Cena 6 — "A farmácia está saudável?"):** "Para
  Proprietário, Gerente e Financeiro, os mesmos lançamentos viram a DRE
  do mês, um balancete de créditos × débitos e a saúde financeira, com a
  curva de 12 meses e recomendações em reais do que ajustar. O Comprador
  continua vendo só a visão dele, sem dado financeiro sensível." Mostre o
  mês que fechou no prejuízo na curva e as recomendações da Saúde
  Financeira; pergunte se hoje eles sabem, no fim do mês, quanto sobrou.
  Se alguém estranhar um número, lembre que é uma farmácia fictícia —
  mas com proporções de mercado (compras em torno de 60% a 65% da
  receita, custos fixos de ~20% a 22%).
- **DDA:** "Hoje os compromissos entram pelo próprio NEXBUY. O DDA é a
  integração prevista: vai trazer os boletos apresentados ao CNPJ para a
  mesma agenda que vocês viram, para o Financeiro conferir — ele nunca paga
  nada sozinho. Está previsto e **ainda não conectado** — por isso a tela
  diz exatamente isso."

Se perguntarem por integração com o ERP: por decisão de escopo **não
haverá** integração com o ERP — os lançamentos continuam manuais (ver
`NEXBUY_RESPOSTAS_PERGUNTAS_DIFICEIS.md`).

## Encerramento pedindo o próximo passo

Na tela `/demo/encerramento/`:

1. Recapitule em uma frase: "planejou, aplicou limites, aprovou, refletiu
   no financeiro, registrou na auditoria".
2. Faça as duas perguntas de fechamento do roteiro (Cena 8).
3. Proponha UM próximo passo com dono e data:
   > "Proponho o seguinte: vocês me passam a estrutura de empresas,
   > filiais e quem aprova o quê; eu volto com a demonstração montada
   > nesse desenho. Conseguimos agendar para a semana que vem?"
4. Anote o combinado na frente do cliente. Não termine sem próximo passo
   marcado — nem que seja "enviar a lista de perguntas de descoberta".
