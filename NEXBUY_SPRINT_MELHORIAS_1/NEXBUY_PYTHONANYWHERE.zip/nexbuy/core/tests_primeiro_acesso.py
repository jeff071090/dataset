"""Primeiro Acesso Seguro (Etapa 02 — Cliente-Ready; Correção Final).

Fluxo em dois passos: `/primeiro-acesso/` (só o token, por POST) e
`/primeiro-acesso/cadastro/` (o formulário de Empresa/Proprietário, só
acessível com autorização temporária concedida pelo passo 1).

Cobertura obrigatória: rota só disponível em banco realmente vazio; token
nunca aceito por query string nem refletido em resposta/URL/sessão/
cookie/auditoria/log; senha fraca ou similar ao usuário rejeitada; CNPJ
inválido rejeitado; criação atômica de Proprietário+Empresa+Filial; falha
simulada faz rollback total (inclusive a trava de instalação e um
eventual arquivo de logo já salvo); dois Primeiros Acessos concorrentes
não podem os dois ter sucesso; segundo uso sequencial bloqueado;
Proprietário sem is_staff/is_superuser."""
import base64
import logging
import shutil
import tempfile
import threading
from unittest import mock

from django.contrib.auth.password_validation import validate_password
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, TransactionTestCase, override_settings

from auditoria.models import RegistroAuditoria
from core.models import EstadoInstalacao
from empresas.models import ConfiguracaoPlataforma, Empresa, GrupoEmpresarial, IdentidadeVisual
from filiais.models import Filial
from usuarios.models import Usuario

TOKEN = "token-de-teste-primeiro-acesso-2026-nao-usar-em-producao-SENTINELA-UNICA"

PAYLOAD_VALIDO = {
    "first_name": "Ana",
    "last_name": "Proprietária",
    "username": "ana.proprietaria",
    "senha": "S3nhaForteEUnica!2026",
    "senha_confirmacao": "S3nhaForteEUnica!2026",
    "grupo_nome": "Grupo Teste Etapa 02",
    "nome": "Empresa Teste Etapa 02",
    "razao_social": "Empresa Teste Etapa 02 Ltda",
    "cnpj": "11.222.333/0001-81",
    "cidade": "Cuiabá",
    "estado": "MT",
    "filial_nome": "Matriz",
    "identidade_nome_exibicao": "",
    "fuso_horario": "America/Sao_Paulo",
    "confirmo": "on",
}


class _CapturaTodosOsLogs(logging.Handler):
    """Handler simples que só acumula as mensagens formatadas — usado para
    confirmar que o token nunca aparece em NENHUM log, em vez de depender
    de `assertLogs` (que falha se nada for logado no nível pedido, o que
    aconteceria nos caminhos de sucesso desta view)."""

    def __init__(self):
        super().__init__()
        self.mensagens = []

    def emit(self, record):
        self.mensagens.append(self.format(record))


def _autorizar_e_client(token=TOKEN):
    """Helper: faz o passo 1 (POST do token) e devolve o Client já
    autorizado para o passo 2, mais a resposta do passo 1 (para os testes
    que precisam inspecioná-la)."""
    client = Client()
    resposta = client.post("/primeiro-acesso/", {"token": token})
    return client, resposta


def realizar_primeiro_acesso(client=None, payload=None, token=TOKEN):
    """Helper público reaproveitado por outras suítes (`tests_estados_
    vazios.py`, `tests_integracoes_desativadas.py`, `tests_qa_navegador.py`)
    que precisam de um cenário pós-Primeiro-Acesso real, sem repetir o
    fluxo em 2 passos (token → cadastro) em cada arquivo. Devolve a
    resposta final do passo 2 (a mesma que o código antigo, de 1 passo só,
    devolvia) — quem chama continua verificando `status_code == 302`
    exatamente como antes."""
    client = client or Client()
    payload = payload if payload is not None else PAYLOAD_VALIDO
    resposta_token = client.post("/primeiro-acesso/", {"token": token})
    if resposta_token.status_code != 302:
        return resposta_token
    return client.post("/primeiro-acesso/cadastro/", payload)


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class PrimeiroAcessoTokenTestCase(TransactionTestCase):
    """Passo 1 — só o token, nunca por query string, nunca refletido."""

    def setUp(self):
        self.client = Client()
        self.logger_handler = _CapturaTodosOsLogs()
        for nome_logger in ("django.request", "django.security", ""):
            logging.getLogger(nome_logger).addHandler(self.logger_handler)
            logging.getLogger(nome_logger).setLevel(logging.DEBUG)

    def tearDown(self):
        for nome_logger in ("django.request", "django.security", ""):
            logging.getLogger(nome_logger).removeHandler(self.logger_handler)

    def _nenhum_log_contem_o_token(self):
        for mensagem in self.logger_handler.mensagens:
            self.assertNotIn(TOKEN, mensagem, f"Token vazou em log: {mensagem!r}")

    def test_get_mostra_formulario_de_token_sem_pedir_nada_na_url(self):
        resposta = self.client.get("/primeiro-acesso/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Token de configuração")

    def test_query_string_com_token_e_ignorada_e_nunca_refletida(self):
        resposta = self.client.get(f"/primeiro-acesso/?token={TOKEN}")
        self.assertEqual(resposta.status_code, 200)
        conteudo = resposta.content.decode("utf-8")
        self.assertNotIn(TOKEN, conteudo)
        # GET com ?token= não autoriza nada — precisa continuar pedindo o
        # formulário, não pode ter efeito colateral nenhum.
        self.assertFalse(self.client.session.get("primeiro_acesso_autorizado"))

    def test_post_token_correto_autoriza_e_redireciona_para_url_limpa(self):
        resposta = self.client.post("/primeiro-acesso/", {"token": TOKEN})
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(resposta.url, "/primeiro-acesso/cadastro/")
        self.assertNotIn(TOKEN, resposta.url)
        self._nenhum_log_contem_o_token()

    def test_post_token_errado_nao_autoriza_e_nao_reflete_o_valor_enviado(self):
        resposta = self.client.post("/primeiro-acesso/", {"token": "token-completamente-errado"})
        self.assertEqual(resposta.status_code, 200)
        conteudo = resposta.content.decode("utf-8")
        self.assertNotIn("token-completamente-errado", conteudo)
        self.assertNotIn(TOKEN, conteudo)
        self.assertFalse(self.client.session.get("primeiro_acesso_autorizado"))

    def test_post_sem_csrf_e_rejeitado(self):
        cliente_com_csrf = Client(enforce_csrf_checks=True)
        resposta = cliente_com_csrf.post("/primeiro-acesso/", {"token": TOKEN})
        self.assertEqual(resposta.status_code, 403)
        self.assertFalse(cliente_com_csrf.session.get("primeiro_acesso_autorizado"))

    def test_token_correto_nao_aparece_no_conteudo_da_resposta_de_redirecionamento(self):
        resposta = self.client.post("/primeiro-acesso/", {"token": TOKEN}, follow=True)
        self.assertNotIn(TOKEN.encode(), resposta.content)
        for intermediaria, _status in resposta.redirect_chain:
            self.assertNotIn(TOKEN, intermediaria)

    def test_token_correto_nao_e_armazenado_na_sessao_apenas_uma_autorizacao_temporaria(self):
        self.client.post("/primeiro-acesso/", {"token": TOKEN})
        valores_da_sessao = [str(v) for v in self.client.session.items()]
        for valor in valores_da_sessao:
            self.assertNotIn(TOKEN, valor)
        self.assertTrue(self.client.session.get("primeiro_acesso_autorizado"))
        self.assertIn("primeiro_acesso_autorizado_expira_em", self.client.session)

    def test_token_correto_nao_aparece_em_cookies(self):
        resposta = self.client.post("/primeiro-acesso/", {"token": TOKEN})
        for cookie in resposta.cookies.values():
            self.assertNotIn(TOKEN, cookie.value)

    def test_resposta_usa_cache_control_no_store(self):
        resposta = self.client.get("/primeiro-acesso/")
        self.assertEqual(resposta.headers.get("Cache-Control"), "no-store")

    def test_nenhum_log_contem_o_token_em_nenhum_cenario_deste_passo(self):
        self.client.get(f"/primeiro-acesso/?token={TOKEN}")
        self.client.post("/primeiro-acesso/", {"token": "errado"})
        self.client.post("/primeiro-acesso/", {"token": TOKEN})
        self._nenhum_log_contem_o_token()


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class PrimeiroAcessoCadastroTestCase(TransactionTestCase):
    """Passo 2 — formulário de Empresa/Proprietário, só com autorização."""

    def setUp(self):
        self.client = Client()

    def test_get_cadastro_sem_autorizacao_redireciona_para_o_passo_do_token(self):
        resposta = self.client.get("/primeiro-acesso/cadastro/")
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(resposta.url, "/primeiro-acesso/")

    def test_query_string_com_token_direto_no_cadastro_tambem_e_ignorada(self):
        resposta = self.client.get(f"/primeiro-acesso/cadastro/?token={TOKEN}")
        self.assertEqual(resposta.status_code, 302)
        self.assertNotIn(TOKEN, resposta.url)

    def test_get_cadastro_com_autorizacao_mostra_o_formulario(self):
        client, _ = _autorizar_e_client()
        resposta = client.get("/primeiro-acesso/cadastro/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Criar minha conta e minha empresa")

    def test_criacao_atomica_completa_com_sucesso(self):
        client, _ = _autorizar_e_client()
        resposta = client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO, follow=False)
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(resposta.url, "/accounts/login/")

        usuario = Usuario.objects.get(username="ana.proprietaria")
        self.assertEqual(usuario.perfil, Usuario.Perfil.PROPRIETARIO)
        self.assertTrue(usuario.check_password("S3nhaForteEUnica!2026"))

        empresa = Empresa.objects.get(cnpj="11222333000181")
        self.assertEqual(usuario.empresa_id, empresa.pk)
        self.assertEqual(GrupoEmpresarial.objects.filter(nome="Grupo Teste Etapa 02").count(), 1)

        filial = Filial.objects.get(empresa=empresa)
        self.assertEqual(filial.nome, "Matriz")
        self.assertEqual(filial.tipo_estabelecimento, Filial.TipoEstabelecimento.MATRIZ)

        config = ConfiguracaoPlataforma.objects.get(empresa=empresa)
        self.assertEqual(config.fuso_horario, "America/Sao_Paulo")

        evento = RegistroAuditoria.objects.get(categoria=RegistroAuditoria.Categoria.PRIMEIRO_ACESSO_CONCLUIDO)
        self.assertEqual(evento.usuario_id, usuario.pk)
        self.assertEqual(evento.empresa_id, empresa.pk)

        self.assertTrue(EstadoInstalacao.objects.get().concluido)

    def test_conclusao_limpa_a_autorizacao_da_sessao(self):
        client, _ = _autorizar_e_client()
        client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertFalse(client.session.get("primeiro_acesso_autorizado"))

    def test_proprietario_criado_sem_is_staff_nem_is_superuser(self):
        client, _ = _autorizar_e_client()
        client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        usuario = Usuario.objects.get(username="ana.proprietaria")
        self.assertFalse(usuario.is_staff)
        self.assertFalse(usuario.is_superuser)

    def test_token_nunca_aparece_no_evento_de_auditoria(self):
        client, _ = _autorizar_e_client()
        client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        evento = RegistroAuditoria.objects.get(categoria=RegistroAuditoria.Categoria.PRIMEIRO_ACESSO_CONCLUIDO)
        textos = [evento.descricao, str(evento.estado_antes or ""), str(evento.estado_depois or ""), evento.justificativa or ""]
        for texto in textos:
            self.assertNotIn(TOKEN, texto)
            self.assertNotIn("S3nhaForteEUnica!2026", texto)

    def test_senha_fraca_e_rejeitada(self):
        client, _ = _autorizar_e_client()
        payload = dict(PAYLOAD_VALIDO, senha="123456", senha_confirmacao="123456")
        resposta = client.post("/primeiro-acesso/cadastro/", payload)
        self.assertEqual(resposta.status_code, 200)
        self.assertFalse(resposta.context["form"].is_valid())
        self.assertEqual(Usuario.objects.count(), 0)

    def test_senha_semelhante_ao_username_e_rejeitada(self):
        """Bloqueador 3: sem passar `user=` ao `validate_password`, o
        `UserAttributeSimilarityValidator` fica mudo. Prova direta contra
        o form, e também via POST real."""
        client, _ = _autorizar_e_client()
        payload = dict(
            PAYLOAD_VALIDO,
            username="cliente.proprietario",
            senha="cliente.proprietario2026!",
            senha_confirmacao="cliente.proprietario2026!",
        )
        resposta = client.post("/primeiro-acesso/cadastro/", payload)
        self.assertEqual(resposta.status_code, 200)
        self.assertFalse(resposta.context["form"].is_valid())
        self.assertIn("senha", resposta.context["form"].errors)
        self.assertEqual(Usuario.objects.filter(username="cliente.proprietario").count(), 0)

    def test_validate_password_recebe_usuario_candidato_de_verdade(self):
        """Confirma o mecanismo, não só o sintoma: uma senha parecida com
        o PRÓPRIO validate_password (sem user=) não seria rejeitada — aqui
        provamos que ela é."""
        candidato = Usuario(username="joao.silva", first_name="João", last_name="Silva")
        with self.assertRaises(Exception):
            validate_password("joao.silva2026!", user=candidato)

    def test_senhas_diferentes_sao_rejeitadas(self):
        client, _ = _autorizar_e_client()
        payload = dict(PAYLOAD_VALIDO, senha_confirmacao="OutraSenhaForte!2026")
        resposta = client.post("/primeiro-acesso/cadastro/", payload)
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("senha_confirmacao", resposta.context["form"].errors)
        self.assertEqual(Usuario.objects.count(), 0)

    def test_cnpj_invalido_e_rejeitado(self):
        client, _ = _autorizar_e_client()
        payload = dict(PAYLOAD_VALIDO, cnpj="11.111.111/1111-11")
        resposta = client.post("/primeiro-acesso/cadastro/", payload)
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("cnpj", resposta.context["form"].errors)
        self.assertEqual(Empresa.objects.count(), 0)

    def test_cnpj_ja_cadastrado_e_rejeitado(self):
        Empresa.objects.create(nome="Outra", cnpj="11.222.333/0001-81", ativo=False)
        client, _ = _autorizar_e_client()
        resposta = client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("cnpj", resposta.context["form"].errors)
        self.assertEqual(Empresa.objects.filter(ativo=True).count(), 0)

    def test_username_ja_existente_e_rejeitado(self):
        Usuario.objects.create_user(username="ana.proprietaria", password="x", is_active=False)
        client, _ = _autorizar_e_client()
        resposta = client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("username", resposta.context["form"].errors)

    def test_confirmacao_final_obrigatoria(self):
        client, _ = _autorizar_e_client()
        payload = dict(PAYLOAD_VALIDO)
        payload.pop("confirmo")
        resposta = client.post("/primeiro-acesso/cadastro/", payload)
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("confirmo", resposta.context["form"].errors)
        self.assertEqual(Usuario.objects.count(), 0)

    def test_autorizacao_expirada_nao_abre_o_formulario(self):
        client, _ = _autorizar_e_client()
        session = client.session
        session["primeiro_acesso_autorizado_expira_em"] = 1  # timestamp no passado
        session.save()
        resposta = client.get("/primeiro-acesso/cadastro/")
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(resposta.url, "/primeiro-acesso/")

    def test_autorizacao_expirada_nao_permite_criar_via_post(self):
        client, _ = _autorizar_e_client()
        session = client.session
        session["primeiro_acesso_autorizado_expira_em"] = 1
        session.save()
        resposta = client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(Usuario.objects.count(), 0)

    def test_falha_simulada_no_evento_central_faz_rollback_total(self):
        client, _ = _autorizar_e_client()
        with mock.patch(
            "core.views_primeiro_acesso.registrar_evento",
            side_effect=RuntimeError("Falha simulada na Auditoria (teste de rollback)"),
        ):
            cliente_sem_levantar = Client(raise_request_exception=False)
            session = cliente_sem_levantar.session
            session["primeiro_acesso_autorizado"] = True
            from django.utils import timezone
            from datetime import timedelta
            session["primeiro_acesso_autorizado_expira_em"] = (timezone.now() + timedelta(minutes=10)).timestamp()
            session.save()
            resposta = cliente_sem_levantar.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(resposta.status_code, 500)
        self.assertEqual(Usuario.objects.count(), 0)
        self.assertEqual(Empresa.objects.count(), 0)
        self.assertEqual(Filial.objects.count(), 0)
        self.assertEqual(GrupoEmpresarial.objects.count(), 0)
        self.assertEqual(ConfiguracaoPlataforma.objects.count(), 0)
        # A trava de instalação também volta a "pendente" — o rollback é
        # completo, inclusive nesse campo.
        self.assertFalse(EstadoInstalacao.objects.get().concluido)

    def test_apos_rollback_uma_nova_tentativa_pode_funcionar(self):
        client, _ = _autorizar_e_client()
        with mock.patch(
            "core.views_primeiro_acesso.registrar_evento",
            side_effect=RuntimeError("Falha simulada"),
        ):
            Client(raise_request_exception=False).post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(Usuario.objects.count(), 0)

        client2, _ = _autorizar_e_client()
        resposta = client2.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(Usuario.objects.count(), 1)

    def test_segundo_uso_sequencial_fica_bloqueado(self):
        client, _ = _autorizar_e_client()
        primeira = client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(primeira.status_code, 302)

        segunda_tentativa_get = self.client.get("/primeiro-acesso/")
        self.assertEqual(segunda_tentativa_get.status_code, 404)

        client2, resposta_token = _autorizar_e_client()
        self.assertEqual(resposta_token.status_code, 404)

        payload_2 = dict(PAYLOAD_VALIDO, username="outro.usuario", cnpj="11.444.777/0001-61")
        segunda_post = client2.post("/primeiro-acesso/cadastro/", payload_2)
        self.assertEqual(segunda_post.status_code, 404)
        self.assertEqual(Usuario.objects.count(), 1)
        self.assertEqual(Empresa.objects.count(), 1)

    def test_usuario_ou_empresa_inativos_preexistentes_nao_bloqueiam(self):
        """Regra já documentada: só Usuario/Empresa ATIVOS contam. Um
        registro inativo pré-existente (ex.: de uma tentativa cancelada)
        não deixa o sistema num estado ambíguo."""
        Usuario.objects.create_user(username="fantasma", password="x", is_active=False)
        Empresa.objects.create(nome="Fantasma", cnpj="11.444.777/0001-61", ativo=False)
        client, resposta_token = _autorizar_e_client()
        self.assertEqual(resposta_token.status_code, 302)
        resposta = client.post("/primeiro-acesso/cadastro/", PAYLOAD_VALIDO)
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(Usuario.objects.filter(is_active=True).count(), 1)


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class PrimeiroAcessoConcorrenciaTestCase(TransactionTestCase):
    """Bloqueador 2: duas requisições concorrentes, cada uma com dados
    distintos, tentando concluir o Primeiro Acesso ao mesmo tempo.
    `TransactionTestCase` é obrigatório aqui — `TestCase` envolve tudo
    numa transação externa só, o que mascararia qualquer corrida real."""

    def test_apenas_uma_requisicao_concorrente_consegue_concluir(self):
        client_a, resposta_token_a = _autorizar_e_client()
        client_b, resposta_token_b = _autorizar_e_client()
        self.assertEqual(resposta_token_a.status_code, 302)
        self.assertEqual(resposta_token_b.status_code, 302)

        # Ambos os Clients usam `raise_request_exception=False`: numa
        # corrida de verdade contra o SQLite de teste em memória
        # compartilhada, a conexão "perdedora" pode receber `SQLITE_LOCKED`
        # (não `SQLITE_BUSY`) — um caso em que o `busy_timeout`/`timeout`
        # configurado não se aplica, uma particularidade conhecida do modo
        # `cache=shared` usado só pelo banco de TESTE em memória (o banco
        # real de produção é um arquivo SQLite comum ou PostgreSQL, onde
        # essa particularidade não existe). Isso pode surfar como um 500
        # em vez do 404 "limpo" que `_criar_estrutura_inicial` devolve
        # quando consegue adquirir a trava e enxerga o estado já
        # concluído. O que importa de verdade — e é isso que este teste
        # trava com rigor — é que NUNCA os dois conseguem criar uma
        # Empresa: exatamente 1 sucesso (302), zero duplicação de dado.
        # Reaproveita os MESMOS clients já autorizados pelo passo 1 (têm a
        # sessão certa) — só desativa `raise_request_exception` para que
        # uma eventual exceção vire uma resposta 500 de verdade em vez de
        # explodir a thread em silêncio.
        client_a.raise_request_exception = False
        client_b.raise_request_exception = False

        payload_a = dict(PAYLOAD_VALIDO, username="usuario.a", cnpj="11.222.333/0001-81")
        payload_b = dict(PAYLOAD_VALIDO, username="usuario.b", cnpj="11.444.777/0001-61")

        resultados = {}

        def _disparar(nome, client, payload):
            try:
                resposta = client.post("/primeiro-acesso/cadastro/", payload)
                resultados[nome] = resposta.status_code
            except Exception as erro:  # nunca deixar a thread morrer em silêncio
                resultados[nome] = f"EXCECAO: {erro!r}"

        thread_a = threading.Thread(target=_disparar, args=("a", client_a, payload_a))
        thread_b = threading.Thread(target=_disparar, args=("b", client_b, payload_b))
        thread_a.start()
        thread_b.start()
        thread_a.join(timeout=30)
        thread_b.join(timeout=30)

        sucessos = [codigo for codigo in resultados.values() if codigo == 302]
        self.assertEqual(len(sucessos), 1, f"Esperado exatamente 1 sucesso (302), veio {resultados}")

        self.assertEqual(Usuario.objects.filter(is_active=True).count(), 1)
        self.assertEqual(GrupoEmpresarial.objects.count(), 1)
        self.assertEqual(Empresa.objects.count(), 1)
        self.assertEqual(Filial.objects.count(), 1)
        self.assertEqual(ConfiguracaoPlataforma.objects.count(), 1)
        self.assertEqual(
            RegistroAuditoria.objects.filter(categoria=RegistroAuditoria.Categoria.PRIMEIRO_ACESSO_CONCLUIDO).count(),
            1,
        )
        estado = EstadoInstalacao.objects.get()
        self.assertTrue(estado.concluido)


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class PrimeiroAcessoLogoOrfaoTestCase(TransactionTestCase):
    """Bloqueador 4: se a transação falhar depois do logo já ter sido
    salvo no storage, o arquivo não pode sobrar órfão."""

    def setUp(self):
        self.media_temporario = tempfile.mkdtemp(prefix="nexbuy_media_teste_")
        self.override = override_settings(MEDIA_ROOT=self.media_temporario)
        self.override.enable()
        self.client = Client()

    def tearDown(self):
        self.override.disable()
        shutil.rmtree(self.media_temporario, ignore_errors=True)

    def _png_valido(self, nome="logo_cliente.png"):
        # PNG 1x1 transparente válido, conhecido — evita erro de digitação
        # num hex escrito à mão (que quebraria o teste por um motivo
        # completamente alheio ao que ele testa).
        base64_png_1x1 = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk"
            "+A8AAQUBAScY42YAAAAASUVORK5CYII="
        )
        conteudo_png_1x1 = base64.b64decode(base64_png_1x1)
        return SimpleUploadedFile(nome, conteudo_png_1x1, content_type="image/png")

    def test_falha_apos_upload_do_logo_nao_deixa_arquivo_orfao(self):
        client, _ = _autorizar_e_client()
        payload = dict(PAYLOAD_VALIDO, identidade_nome_exibicao="Empresa Teste")
        with mock.patch(
            "core.views_primeiro_acesso.registrar_evento",
            side_effect=RuntimeError("Falha simulada depois do upload do logo"),
        ):
            cliente_sem_levantar = Client(raise_request_exception=False)
            session = cliente_sem_levantar.session
            session["primeiro_acesso_autorizado"] = True
            from django.utils import timezone
            from datetime import timedelta
            session["primeiro_acesso_autorizado_expira_em"] = (timezone.now() + timedelta(minutes=10)).timestamp()
            session.save()
            resposta = cliente_sem_levantar.post(
                "/primeiro-acesso/cadastro/",
                dict(payload, identidade_logo=self._png_valido()),
            )
        self.assertEqual(resposta.status_code, 500)
        self.assertEqual(IdentidadeVisual.objects.count(), 0)
        self.assertEqual(Empresa.objects.count(), 0)

        import os
        arquivos_no_diretorio_de_logos = []
        caminho_logos = os.path.join(self.media_temporario, "identidade", "logos")
        if os.path.isdir(caminho_logos):
            arquivos_no_diretorio_de_logos = os.listdir(caminho_logos)
        self.assertEqual(
            arquivos_no_diretorio_de_logos, [],
            f"Arquivo de logo órfão sobrou no storage após rollback: {arquivos_no_diretorio_de_logos}",
        )

    def test_sucesso_com_logo_mantem_exatamente_um_arquivo_referenciado(self):
        client, _ = _autorizar_e_client()
        payload = dict(
            PAYLOAD_VALIDO,
            identidade_nome_exibicao="Empresa Teste",
            identidade_logo=self._png_valido(),
        )
        resposta = client.post("/primeiro-acesso/cadastro/", payload)
        self.assertEqual(resposta.status_code, 302)

        identidade = IdentidadeVisual.objects.get()
        self.assertTrue(identidade.logo.name)

        import os
        caminho_absoluto = os.path.join(self.media_temporario, identidade.logo.name)
        self.assertTrue(os.path.isfile(caminho_absoluto))

        caminho_logos = os.path.join(self.media_temporario, "identidade", "logos")
        self.assertEqual(len(os.listdir(caminho_logos)), 1)


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class PrimeiroAcessoErrosVisiveisTestCase(TransactionTestCase):
    """Críticos (rodada 2): uma logo inválida (SVG, PDF, HEIC, arquivo
    corrompido) era recusada pelo ImageField SEM nenhuma mensagem na página
    — o template só mostrava os erros de alguns campos. Todo erro precisa
    aparecer no HTML, com um aviso no topo, e nada pode ser criado."""

    def setUp(self):
        self.media_temporario = tempfile.mkdtemp(prefix="nexbuy_media_teste_")
        self.override = override_settings(MEDIA_ROOT=self.media_temporario)
        self.override.enable()

    def tearDown(self):
        self.override.disable()
        shutil.rmtree(self.media_temporario, ignore_errors=True)

    def _enviar(self, **extra):
        client, _ = _autorizar_e_client()
        return client.post("/primeiro-acesso/cadastro/", dict(PAYLOAD_VALIDO, **extra))

    def _assert_recusado_com_mensagem(self, resposta, trecho):
        self.assertEqual(resposta.status_code, 200)
        html = resposta.content.decode()
        self.assertIn("data-nx-form-com-erros", html)
        self.assertIn(trecho, html)
        self.assertEqual(Empresa.objects.count(), 0)
        self.assertEqual(Usuario.objects.count(), 0)

    def test_logo_svg_mostra_mensagem_do_campo(self):
        svg = SimpleUploadedFile(
            "logo.svg", b'<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"></svg>',
            content_type="image/svg+xml",
        )
        resposta = self._enviar(identidade_logo=svg)
        self._assert_recusado_com_mensagem(resposta, "Envie a logo em PNG, JPG ou WEBP")
        self.assertIn("escolha a logo outra vez", resposta.content.decode())

    def test_logo_corrompida_mostra_mensagem_do_campo(self):
        corrompido = SimpleUploadedFile("logo.png", b"isto nao e uma imagem", content_type="image/png")
        self._assert_recusado_com_mensagem(self._enviar(identidade_logo=corrompido), "Envie a logo em PNG, JPG ou WEBP")

    def test_logo_gif_fora_dos_formatos_web_e_recusada_com_mensagem(self):
        gif_1x1 = base64.b64decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")
        gif = SimpleUploadedFile("logo.gif", gif_1x1, content_type="image/gif")
        self._assert_recusado_com_mensagem(self._enviar(identidade_logo=gif), "Envie a logo em PNG, JPG ou WEBP")

    def test_logo_acima_de_5_mb_e_recusada_com_mensagem(self):
        from core import forms_primeiro_acesso

        png_1x1 = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
        )
        with mock.patch.object(forms_primeiro_acesso, "TAMANHO_MAXIMO_LOGO_MB", 0):
            resposta = self._enviar(identidade_logo=SimpleUploadedFile("logo.png", png_1x1, content_type="image/png"))
        self._assert_recusado_com_mensagem(resposta, "A logo tem mais de")

    def test_campo_logo_orienta_formatos_e_restringe_o_seletor(self):
        client, _ = _autorizar_e_client()
        html = client.get("/primeiro-acesso/cadastro/").content.decode()
        self.assertIn('accept="image/png,image/jpeg,image/webp"', html)
        self.assertIn("PNG, JPG ou WEBP, até 5 MB.", html)
        self.assertNotIn("data-nx-form-com-erros", html)

    def test_erros_de_todos_os_campos_obrigatorios_aparecem(self):
        resposta = self._enviar(grupo_nome="", filial_nome="", fuso_horario="Marte/Olympus")
        self.assertEqual(resposta.status_code, 200)
        form = resposta.context["form"]
        html = resposta.content.decode()
        self.assertIn("data-nx-form-com-erros", html)
        for campo in ("grupo_nome", "filial_nome", "fuso_horario"):
            self.assertIn(campo, form.errors)
            for erro in form.errors[campo]:
                self.assertIn(str(erro).replace('"', "&quot;"), html)
