"""Formulário do Primeiro Acesso Seguro (Etapa 02 — Cliente-Ready).

Um único form guiado por seções (Você / Sua empresa / Primeira filial /
Preferências) — não um wizard multi-etapa: evita manter senha em texto
puro na sessão entre requisições. A "confirmação final" pedida pelo prompt
é o campo `confirmo`, a última seção do próprio formulário."""
import re

from django import forms
from django.contrib.auth.password_validation import validate_password

from core.choices import UF_CHOICES
from core.forms import BootstrapFormMixin
from core.senha_demo import PREFIXO_CNPJ_DEMO
from core.validators import cnpj_e_valido
from empresas.models import Empresa
from usuarios.models import Usuario

FUSOS_HORARIOS_BRASIL = (
    ("America/Sao_Paulo", "Brasília (America/Sao_Paulo)"),
    ("America/Cuiaba", "Cuiabá (America/Cuiaba)"),
    ("America/Manaus", "Manaus (America/Manaus)"),
    ("America/Belem", "Belém (America/Belem)"),
    ("America/Fortaleza", "Fortaleza (America/Fortaleza)"),
    ("America/Recife", "Recife (America/Recife)"),
    ("America/Bahia", "Salvador (America/Bahia)"),
    ("America/Noronha", "Fernando de Noronha (America/Noronha)"),
    ("America/Rio_Branco", "Rio Branco (America/Rio_Branco)"),
)


def _somente_digitos(valor: str) -> str:
    return re.sub(r"\D", "", valor or "")


# Críticos (rodada 2): logo em SVG, PDF, HEIC (iPhone) ou arquivo corrompido
# era recusada pelo ImageField SEM nenhuma mensagem na tela (o template não
# mostrava os erros deste campo) — a cliente achava que o botão não
# funcionava. Formatos aceitos e limite de tamanho ficam explícitos no
# campo (texto de ajuda + `accept` do seletor de arquivo) e na validação.
FORMATOS_LOGO = {"PNG": "PNG", "JPEG": "JPG", "WEBP": "WEBP"}
TAMANHO_MAXIMO_LOGO_MB = 5
MENSAGEM_FORMATO_LOGO = (
    "Envie a logo em PNG, JPG ou WEBP (até 5 MB). SVG, PDF e HEIC (foto do iPhone) não são aceitos — "
    "abra a logo e salve/exporte como PNG ou JPG."
)


class PrimeiroAcessoTokenForm(BootstrapFormMixin, forms.Form):
    """Etapa 1 do Primeiro Acesso (Correção Final — Bloqueador 1): só pede
    o token, por POST, nunca por query string. Widget de senha para não
    deixar o segredo visível na tela (mesma cautela de uma credencial),
    embora o valor em si nunca seja armazenado — só uma autorização
    temporária na sessão."""

    token = forms.CharField(label="Token de configuração", widget=forms.PasswordInput, max_length=200)


class PrimeiroAcessoForm(BootstrapFormMixin, forms.Form):
    # Você (Proprietário)
    first_name = forms.CharField(label="Seu nome", max_length=150)
    last_name = forms.CharField(label="Seu sobrenome", max_length=150, required=False)
    username = forms.CharField(label="Usuário (login)", max_length=150)
    senha = forms.CharField(label="Senha", widget=forms.PasswordInput)
    senha_confirmacao = forms.CharField(label="Confirme a senha", widget=forms.PasswordInput)

    # Sua empresa
    grupo_nome = forms.CharField(label="Nome do grupo/negócio", max_length=150)
    nome = forms.CharField(label="Nome Fantasia da Empresa", max_length=200)
    razao_social = forms.CharField(label="Razão Social", max_length=200, required=False)
    cnpj = forms.CharField(label="CNPJ", max_length=18)
    cidade = forms.CharField(label="Cidade", max_length=100, required=False)
    # Rodada final: UF_CHOICES já começa com a opção vazia — somar outra
    # ("", "—") deixava o select com duas opções vazias.
    estado = forms.ChoiceField(
        label="Estado", choices=(("", "—"),) + tuple(uf for uf in UF_CHOICES if uf[0]), required=False,
    )

    # Primeira Filial/Matriz
    filial_nome = forms.CharField(label="Nome da primeira Filial/Matriz", max_length=150, initial="Matriz")

    # Identidade visual (opcional)
    identidade_nome_exibicao = forms.CharField(label="Nome de exibição (opcional)", max_length=100, required=False)
    identidade_logo = forms.ImageField(
        label="Logo (opcional)",
        required=False,
        help_text=f"PNG, JPG ou WEBP, até {TAMANHO_MAXIMO_LOGO_MB} MB.",
        error_messages={"invalid_image": MENSAGEM_FORMATO_LOGO, "invalid_extension": MENSAGEM_FORMATO_LOGO},
        widget=forms.ClearableFileInput(attrs={"accept": "image/png,image/jpeg,image/webp"}),
    )

    # Preferências
    fuso_horario = forms.ChoiceField(
        label="Fuso horário", choices=FUSOS_HORARIOS_BRASIL, initial="America/Sao_Paulo",
    )

    # Confirmação final
    confirmo = forms.BooleanField(
        label="Confirmo que revisei os dados acima e quero criar minha conta e minha empresa no NEXBUY.",
        required=True,
    )

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if not username:
            raise forms.ValidationError("Informe um usuário de login.")
        if Usuario.objects.filter(username=username).exists():
            raise forms.ValidationError("Já existe um usuário com este login.")
        return username

    def clean_senha(self):
        senha = self.cleaned_data["senha"]
        # Correção Final (Bloqueador 3): sem passar `user=`, o
        # `UserAttributeSimilarityValidator` não tem com o que comparar a
        # senha (username/nome/sobrenome) e fica sempre mudo — uma senha
        # como "usuario.login2026!" para o login "usuario.login" passava
        # sem nenhum aviso. Uma instância NÃO salva (nunca persistida,
        # só usada para a comparação) já é suficiente: os validadores só
        # leem os atributos, nunca gravam nada.
        usuario_candidato = Usuario(
            username=self.data.get("username", ""),
            first_name=self.data.get("first_name", ""),
            last_name=self.data.get("last_name", ""),
        )
        validate_password(senha, user=usuario_candidato)
        return senha

    def clean_identidade_logo(self):
        logo = self.cleaned_data.get("identidade_logo")
        if not logo:
            return logo
        if logo.size > TAMANHO_MAXIMO_LOGO_MB * 1024 * 1024:
            raise forms.ValidationError(
                f"A logo tem mais de {TAMANHO_MAXIMO_LOGO_MB} MB. Reduza o arquivo (ou exporte em PNG/JPG menor) "
                "e envie de novo."
            )
        # O Pillow abre outros formatos (GIF, BMP, TIFF, ICO...); a logo
        # aparece no cabeçalho de toda página — só os três formatos web.
        formato = getattr(getattr(logo, "image", None), "format", None)
        if formato is not None and formato not in FORMATOS_LOGO:
            raise forms.ValidationError(MENSAGEM_FORMATO_LOGO)
        return logo

    def clean_cnpj(self):
        cnpj = (self.cleaned_data.get("cnpj") or "").strip()
        if not cnpj_e_valido(cnpj):
            raise forms.ValidationError("Este CNPJ não é válido — confira os dígitos.")
        digitos = _somente_digitos(cnpj)
        # A faixa 98765432... é da empresa fictícia da demonstração: a
        # empresa de verdade nunca a usa (e os scripts de servidor
        # reconhecem a demonstração por ela).
        if digitos.startswith(PREFIXO_CNPJ_DEMO):
            raise forms.ValidationError(
                "Este é o CNPJ fictício da demonstração. Informe o CNPJ verdadeiro da empresa."
            )
        ja_cadastrado = any(
            _somente_digitos(existente) == digitos for existente in Empresa.objects.values_list("cnpj", flat=True)
        )
        if ja_cadastrado:
            raise forms.ValidationError("Este CNPJ já está cadastrado no NEXBUY.")
        return cnpj

    def clean(self):
        cleaned = super().clean()
        senha = cleaned.get("senha")
        confirmacao = cleaned.get("senha_confirmacao")
        if senha and confirmacao and senha != confirmacao:
            self.add_error("senha_confirmacao", "As senhas não coincidem.")
        return cleaned
