"""Senhas dos usuários de demonstração — regra única usada pelo
`seed_demo` (aviso no fim, com DEBUG=False), pelo `definir_senha_demo`
(troca, bloqueio e verificação) e pelo validador de senha do projeto
(`SenhaPublicaDemoValidator`, em AUTH_PASSWORD_VALIDATORS).

Contexto: o `seed_demo` cria os usuários com a senha PÚBLICA de
demonstração (documentada em DEMO_MODE.md). No PC do apresentador isso é
o esperado; numa demonstração publicada na internet (PythonAnywhere — ver
docs/DEPLOY_PYTHONANYWHERE_DEMO.md) qualquer visitante entraria como
Proprietário. Por isso, lá, as senhas são trocadas logo depois do seed.

Escopo de ESCRITA sempre restrito às empresas fictícias do `seed_demo` —
CNPJ que começa com 98765432, o mesmo filtro que o próprio seed usa para
limpar a auditoria (`_limpar_transacoes_anteriores`). Nunca altera usuários
de outra empresa nem superusuários; esses só são CONFERIDOS (leitura) pelo
`definir_senha_demo --verificar`, que manda trocá-los à mão.
"""
from django.contrib.auth.hashers import check_password
from django.core.exceptions import ValidationError

PREFIXO_CNPJ_DEMO = "98765432"
# Até esta distância de edição (inserir, apagar ou trocar 1 caractere
# conta 1) da senha pública normalizada, a senha é "variação" dela:
# Nexbuy123, nexbuy1234, nexbui123, n3xbuy12...
DISTANCIA_MAXIMA_DA_PUBLICA = 3


def usernames_demo():
    """Os 6 usuários de login da demonstração, na ordem do menu de troca
    de perfil (fonte única: `core.views.USUARIOS_DEMO_TROCA`)."""
    from core.views import USUARIOS_DEMO_TROCA

    return [username for username, _rotulo in USUARIOS_DEMO_TROCA]


def senha_publica():
    """A senha pública com que o `seed_demo` cria os usuários (import
    tardio: o seed importa este módulo)."""
    from core.management.commands.seed_demo import SENHA_DEMO

    return SENHA_DEMO


def usuarios_da_empresa_demo():
    """Usuários cuja empresa principal é uma empresa fictícia do seed —
    nunca superusuários (suporte técnico) nem usuários de outra empresa."""
    from usuarios.models import Usuario

    return Usuario.objects.filter(
        empresa__cnpj__startswith=PREFIXO_CNPJ_DEMO, is_superuser=False
    ).order_by("username")


def usa_senha_publica(usuario) -> bool:
    """True se a senha atual do usuário é a senha pública de
    demonstração. Usa o `check_password` do módulo de hashers (e não o
    método do usuário) de propósito: o do usuário regrava o hash quando o
    algoritmo muda — uma simples verificação nunca pode escrever no banco."""
    if not usuario.has_usable_password():
        return False
    return check_password(senha_publica(), usuario.password)


def usuarios_com_senha_publica(apenas_ativos=True):
    """Usuários do escopo da demonstração (os 6 de login + qualquer outro
    da empresa fictícia, como a atendente do histórico de auditoria) que
    ainda entram com a senha pública."""
    usuarios = usuarios_da_empresa_demo()
    if apenas_ativos:
        usuarios = usuarios.filter(is_active=True)
    return [usuario for usuario in usuarios if usa_senha_publica(usuario)]


def usuarios_fora_do_escopo_com_senha_publica():
    """Usuários ATIVOS fora do escopo da demonstração — superusuários
    (mesmo vinculados à empresa fictícia) e usuários de outras empresas —
    que entram com a senha pública (ex.: `createsuperuser` ou `seed_dados`
    rodados à mão no servidor). Só leitura: o `definir_senha_demo` nunca
    troca a senha deles; o `--verificar` manda trocar à mão."""
    from usuarios.models import Usuario

    escopo = usuarios_da_empresa_demo().values("pk")
    candidatos = Usuario.objects.filter(is_active=True).exclude(pk__in=escopo).order_by("username")
    return [usuario for usuario in candidatos if usa_senha_publica(usuario)]


def usuarios_demo_sem_senha():
    """Dos 6 usuários de login, os ATIVOS sem senha utilizável — estado
    deixado pelo `definir_senha_demo --bloquear` (ninguém entra com eles
    até receberem uma senha nova)."""
    return [
        usuario
        for usuario in usuarios_da_empresa_demo().filter(username__in=usernames_demo(), is_active=True)
        if not usuario.has_usable_password()
    ]


# ---------------------------------------------------------------------------
# Variações da senha pública
# ---------------------------------------------------------------------------


def normalizar_senha(texto: str) -> str:
    """Minúsculas (casefold) e só letras/algarismos: "Nexbuy@123!" e
    "NEXBUY 123" viram "nexbuy123"."""
    return "".join(caractere for caractere in texto.casefold() if caractere.isalnum())


def distancia_edicao(a: str, b: str) -> int:
    """Distância de Levenshtein (inserção, remoção ou troca = 1)."""
    if len(a) < len(b):
        a, b = b, a
    anterior = list(range(len(b) + 1))
    for i, caractere_a in enumerate(a, start=1):
        atual = [i]
        for j, caractere_b in enumerate(b, start=1):
            atual.append(min(
                anterior[j] + 1,
                atual[j - 1] + 1,
                anterior[j - 1] + (caractere_a != caractere_b),
            ))
        anterior = atual
    return anterior[-1]


# Nomes que qualquer visitante vê no site publicado (o sistema e a farmácia
# fictícia da tela de login) ou que são o palpite óbvio de uma
# demonstração. Só vale para a senha DIGITADA no `definir_senha_demo` — o
# validador global do projeto não usa esta lista, para não restringir as
# senhas da farmácia de verdade em produção.
PALAVRAS_OBVIAS_DA_DEMO = ("nexbuy", "vidaplena", "farmacia", "demonstracao", "demo")

# Troca comum de letras por números/símbolos ("n3xbuy", "v1dapl3na", "f@rmacia").
_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s", "!": "i"})


def palavras_obvias_na_senha(senha: str) -> list:
    """Palavras de PALAVRAS_OBVIAS_DA_DEMO contidas na senha, ignorando
    maiúsculas, acentos, símbolos e a troca de letras por números."""
    import unicodedata

    sem_acento = unicodedata.normalize("NFKD", (senha or "").casefold())
    sem_acento = "".join(c for c in sem_acento if not unicodedata.combining(c))
    trocada = sem_acento.translate(_LEET)
    candidatos = {normalizar_senha(sem_acento), normalizar_senha(trocada), normalizar_senha(trocada.replace("i", "l"))}
    return [palavra for palavra in PALAVRAS_OBVIAS_DA_DEMO if any(palavra in c for c in candidatos)]


def parece_senha_publica(senha: str) -> bool:
    """True para a senha pública e para variações triviais dela —
    maiúsculas, símbolos, 1 a 3 caracteres a mais/menos/trocados, ou a
    senha pública dentro de outra ("nexbuy123!", "Nexbuy@123",
    "meunexbuy123")."""
    normalizada = normalizar_senha(senha or "")
    publica = normalizar_senha(senha_publica())
    if not normalizada:
        return False
    return publica in normalizada or distancia_edicao(normalizada, publica) <= DISTANCIA_MAXIMA_DA_PUBLICA


class SenhaPublicaDemoValidator:
    """Validador de senha do projeto (AUTH_PASSWORD_VALIDATORS): recusa a
    senha pública de demonstração e as variações dela em QUALQUER troca de
    senha que passe pelas regras do Django (Meu Perfil, Primeiro Acesso,
    `definir_senha_demo`) e no cadastro de usuário do NCC. O `seed_demo`
    grava a senha pública direto (`set_password`), sem validador — a demo
    local continua exatamente igual."""

    MENSAGEM = "Essa senha é (ou lembra demais) a senha pública da demonstração do NEXBUY — escolha outra."

    def validate(self, password, user=None):
        if parece_senha_publica(password):
            raise ValidationError(self.MENSAGEM, code="senha_publica_demo")

    def get_help_text(self):
        return "A senha não pode ser a senha pública de demonstração do NEXBUY nem uma variação dela."
