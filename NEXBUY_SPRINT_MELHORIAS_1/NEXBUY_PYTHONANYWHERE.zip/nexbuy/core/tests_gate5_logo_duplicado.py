"""Gate 5 (Sprint de Encerramento Definitivo): regressão para o bug de
duplicação de arquivos de logo em `media/identidade/logos/`.

Causa raiz (já corrigida em `core/management/commands/seed_demo.py`,
`_criar_identidade_visual`): o PNG gerado por `_gerar_logo_fake` é sempre o
mesmo conteúdo determinístico, mas cada reset de banco (sem limpar a pasta
`media/` junto) fazia `IdentidadeVisual.logo.save(...)` rodar de novo — o
`FileSystemStorage` padrão, ao encontrar um arquivo físico já existente com
esse nome, cunhava um sufixo aleatório novo em vez de reaproveitar. Rodar
`seed_demo` repetidas vezes acumulou 716 arquivos idênticos no projeto real.

Este teste usa um `MEDIA_ROOT` temporário (nunca a pasta `media/` real do
projeto) e confirma que rodar `seed_demo` três vezes seguidas produz sempre
UM único arquivo físico em `identidade/logos/`."""
import shutil
import tempfile
from pathlib import Path

from django.core.files.storage import default_storage
from django.core.management import call_command
from django.test import TestCase, override_settings

from empresas.models import Empresa, IdentidadeVisual


class LogoDemoNaoDuplicaArquivoFisicoTestCase(TestCase):
    def setUp(self):
        self._media_root_temporario = tempfile.mkdtemp(prefix="nexbuy_media_teste_")
        self._override = override_settings(MEDIA_ROOT=self._media_root_temporario)
        self._override.enable()

    def tearDown(self):
        self._override.disable()
        shutil.rmtree(self._media_root_temporario, ignore_errors=True)

    def _contar_arquivos_logo(self):
        pasta_logos = Path(self._media_root_temporario) / "identidade" / "logos"
        if not pasta_logos.exists():
            return 0
        return len([p for p in pasta_logos.iterdir() if p.is_file()])

    def test_tres_execucoes_seguidas_mantem_um_unico_arquivo_fisico(self):
        call_command("seed_demo")
        self.assertEqual(
            self._contar_arquivos_logo(), 1,
            "Após a 1ª execução deveria existir exatamente 1 arquivo de logo.",
        )

        call_command("seed_demo")
        self.assertEqual(
            self._contar_arquivos_logo(), 1,
            "Após a 2ª execução o número de arquivos de logo não pode aumentar "
            "(essa era a causa raiz do bug: um arquivo novo a cada execução).",
        )

        call_command("seed_demo")
        self.assertEqual(
            self._contar_arquivos_logo(), 1,
            "Após a 3ª execução o número de arquivos de logo ainda deve ser 1.",
        )

        empresa = Empresa.objects.get(cnpj="98765432000198")
        identidade = IdentidadeVisual.objects.get(empresa=empresa)
        self.assertTrue(identidade.logo, "A IdentidadeVisual deveria ter um logo salvo.")
        self.assertTrue(
            default_storage.exists(identidade.logo.name),
            f"O caminho salvo em IdentidadeVisual.logo.name ({identidade.logo.name!r}) "
            "deveria apontar para um arquivo que realmente existe em disco.",
        )
        self.assertEqual(identidade.logo.name, "identidade/logos/logo_farmacia_vida_plena.png")
