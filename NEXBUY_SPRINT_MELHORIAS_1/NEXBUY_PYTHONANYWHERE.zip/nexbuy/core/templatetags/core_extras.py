"""Filtros de template reaproveitáveis por qualquer app (Gate pré-Etapa
10, S1-1: exibir CNPJ formatado em templates a partir do valor canônico
só-dígitos armazenado em `Empresa.cnpj`/`Filial.cnpj`)."""
from django import template

from core.utils import formatar_cnpj as _formatar_cnpj

register = template.Library()


@register.filter(name="formatar_cnpj")
def formatar_cnpj(cnpj):
    return _formatar_cnpj(cnpj)


def _valor_legivel(valor):
    if valor is None or valor == "" or valor == [] or valor == {}:
        return "—"
    if valor is True:
        return "sim"
    if valor is False:
        return "não"
    if isinstance(valor, dict):
        return "{" + ", ".join(f"{chave}: {_valor_legivel(item)}" for chave, item in valor.items()) + "}"
    if isinstance(valor, (list, tuple)):
        return "[" + ", ".join(_valor_legivel(item) for item in valor) + "]"
    return str(valor)


@register.filter(name="estado_auditoria")
def estado_auditoria(estado):
    """Ajuste final (produto-e-demo): o "Antes/Depois" da Central de
    Auditoria imprimia o dict Python cru — `{'valor_maximo': None, ...}` —
    e o literal "None" aparecia na tela (Cena 7 da demonstração). Uma
    linha por campo; vazio vira "—" e booleano vira "sim"/"não"."""
    if estado in (None, "", {}, []):
        return "—"
    if isinstance(estado, dict):
        return "\n".join(f"{chave}: {_valor_legivel(valor)}" for chave, valor in estado.items())
    return _valor_legivel(estado)
