"""Correções da rodada 1 dos críticos independentes (véspera da produção).

Cada classe cobre um defeito apontado pelos críticos, contra o HTML e os
números REAIS das views/serviços:

1. Capacidade mensal: a MESMA (ajustada pela margem de segurança) nos
   dashboards do Proprietário, do Financeiro e do Gerente.
2. Motor: sábado/domingo (regra padrão) sem limite base; a soma dos
   limites base do mês é a capacidade mensal ajustada; "Especial" libera.
3. Comprador: cabeçalho, card, % do dia e barra lateral com a MESMA
   resposta (menor entre dotação e filial); negativo vira "excedido".
4. Aprovação por alçada: fila, Central e KPIs só oferecem "Decidir" e só
   contam o que a pessoa pode decidir na etapa atual.
5. Proprietário: "Disponibilidade do mês" + saldo após compras aprovadas =
   resultado da DRE.
6. Cor principal: o vermelho legado do default nunca pinta o sistema.
7. Estados vazios de Nova Compra / Nova Provisão.

Rode com: python manage.py test core.tests_correcoes_rodada1
"""
import re
from calendar import monthrange
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.test import Client, TestCase, override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from compras.services import avaliar_e_criar_compra, definir_limite_comprador
from core.utils import formatar_moeda
from core.utils_testes import garantir_capacidade_no_dia
from empresas.models import Empresa
from filiais.models import Filial
from finance_engine.calendario_operacional import dias_uteis_operacionais
from finance_engine.services import motor_financeiro
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, DiaOperacional, Receita
from gestao_compras.models import EtapaFluxo, FluxoAprovacao, SolicitacaoAprovacao
from gestao_compras.services import criar_provisao, motor_aprovacao_provisao
from usuarios.models import Usuario

CENTAVO = Decimal("0.01")
_CSRF = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')


def _centavos(valor):
    return Decimal(valor).quantize(CENTAVO, rounding=ROUND_HALF_UP)


def _html(testcase, resposta):
    testcase.assertEqual(resposta.status_code, 200)
    html = _CSRF.sub(r"\1\2", resposta.content.decode("utf-8"))
    for termo in ("None", "NaN", "Infinity"):
        testcase.assertNotIn(termo, html, f"'{termo}' vazou no HTML")
    return html


def _cenario_critico(empresa, filial, mes_referencia):
    """Números do relato dos críticos: 40% para compras, 10% de segurança,
    receita 105.000, custos fixos 24.200 e variáveis 2.300 no mês →
    disponibilidade 78.500, capacidade bruta 31.400, ajustada 28.260."""
    ConfiguracaoFinanceira.objects.create(
        empresa=empresa, percentual_compras=Decimal("40"), percentual_seguranca=Decimal("10"), cor_principal="",
    )
    Receita.objects.create(filial=filial, mes=mes_referencia.replace(day=1), faturamento=Decimal("105000"))
    CustoFixo.objects.create(filial=filial, descricao="Aluguel", valor=Decimal("12000"), dia_vencimento=5)
    CustoFixo.objects.create(filial=filial, descricao="Folha de Pagamento", valor=Decimal("12200"), dia_vencimento=5)
    CustoVariavel.objects.create(
        filial=filial, descricao="Frete", valor=Decimal("2300"), data_prevista=mes_referencia.replace(day=15),
    )


class _Base(TestCase):
    def cliente(self, usuario):
        client = Client(SERVER_NAME="127.0.0.1")
        client.force_login(usuario)
        return client


# ---------------------------------------------------------------------------
# 1. Mesma capacidade mensal nos três dashboards
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class CapacidadeMensalEntreDashboardsTestCase(_Base):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Capacidade Única", cnpj="61.000.000/0001-61")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        _cenario_critico(self.empresa, self.filial, date.today())

        def criar(username, perfil, filial=None):
            return Usuario.objects.create_user(
                username=username, password="x", perfil=perfil, empresa=self.empresa, filial=filial,
            )

        self.proprietario = criar("prop_cap_unica", Usuario.Perfil.PROPRIETARIO)
        self.financeiro = criar("fin_cap_unica", Usuario.Perfil.FINANCEIRO, self.filial)
        self.gerente = criar("ger_cap_unica", Usuario.Perfil.GERENTE, self.filial)

    def test_capacidade_mensal_ajustada_igual_nos_tres_perfis(self):
        esperado = Decimal("28260")
        resposta = self.cliente(self.proprietario).get("/")
        html = _html(self, resposta)
        item = resposta.context["resumo_empresas"][0]["filiais"][0]
        self.assertEqual(_centavos(item["capacidade"]["capacidade_mensal_ajustada"]), esperado)
        celula = html.split("data-nx-capacidade-mensal", 1)[1].split("</td>", 1)[0]
        self.assertIn("R$ 28.260,00", celula)
        self.assertNotIn("R$ 31.400,00", html)

        resposta = self.cliente(self.financeiro).get("/")
        html_fin = _html(self, resposta)
        self.assertEqual(_centavos(resposta.context["resumo_filiais"][0]["capacidade_mensal_ajustada"]), esperado)
        self.assertIn("R$ 28.260,00", html_fin)

        resposta = self.cliente(self.gerente).get("/")
        _html(self, resposta)
        self.assertEqual(_centavos(resposta.context["capacidade_mensal"]), esperado)

    def test_limite_diario_fecha_com_a_capacidade_ajustada(self):
        hoje = date.today()
        capacidade = motor_financeiro.capacidade_do_mes(self.filial, hoje.year, hoje.month)
        self.assertEqual(
            _centavos(capacidade.limite_diario_base * capacidade.dias_uteis),
            _centavos(capacidade.capacidade_mensal_ajustada),
        )


# ---------------------------------------------------------------------------
# 2. Motor: uma regra só para o divisor e para o day-walk
# ---------------------------------------------------------------------------

class LimiteDiarioSomaCapacidadeMensalTestCase(TestCase):
    """Setembro/2026: 22 dias úteis; 26/09 é sábado e 27/09 domingo."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Day Walk", cnpj="62.000.000/0001-62")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        _cenario_critico(self.empresa, self.filial, date(2026, 9, 1))

    def _soma_dos_limites_base(self):
        posicoes = motor_financeiro.calcular_posicoes_do_mes(self.filial, 2026, 9)
        self.assertEqual(len(posicoes), 30)
        return posicoes, sum((p.limite_base for p in posicoes), Decimal("0"))

    def test_soma_dos_limites_base_do_mes_e_a_capacidade_mensal_ajustada(self):
        capacidade = motor_financeiro.capacidade_do_mes(self.filial, 2026, 9)
        self.assertEqual(capacidade.dias_uteis, 22)
        self.assertEqual(_centavos(capacidade.capacidade_mensal_ajustada), Decimal("28260.00"))
        self.assertEqual(_centavos(capacidade.limite_diario_base), Decimal("1284.55"))
        posicoes, soma = self._soma_dos_limites_base()
        self.assertEqual(_centavos(soma), Decimal("28260.00"))  # antes: 38.536,36 (+36%)
        por_dia = {p.data.day: p for p in posicoes}
        for dia in (26, 27):
            self.assertEqual(por_dia[dia].limite_base, Decimal("0"))
            self.assertTrue(por_dia[dia].sem_limite_proprio)
        self.assertEqual(por_dia[26].tipo_dia, DiaOperacional.Tipo.SABADO)
        self.assertEqual(_centavos(por_dia[25].limite_base), Decimal("1284.55"))
        self.assertFalse(por_dia[25].sem_limite_proprio)

    def test_sabado_especial_ganha_limite_e_entra_no_divisor(self):
        DiaOperacional.objects.create(empresa=self.empresa, data=date(2026, 9, 26), tipo=DiaOperacional.Tipo.ESPECIAL)
        self.assertEqual(dias_uteis_operacionais(self.empresa, 2026, 9), 23)
        posicoes, soma = self._soma_dos_limites_base()
        self.assertEqual(_centavos(soma), Decimal("28260.00"))
        sabado = posicoes[25]
        self.assertEqual(sabado.data, date(2026, 9, 26))
        self.assertEqual(_centavos(sabado.limite_base), _centavos(Decimal("28260") / 23))
        self.assertEqual(posicoes[26].limite_base, Decimal("0"))  # domingo continua sem limite

    def test_saldo_acumulativo_atravessa_o_fim_de_semana_sem_inventar_limite(self):
        config = self.empresa.configuracao_financeira  # a instância que o Motor lê
        config.permitir_saldo_acumulativo = True
        config.save()
        posicoes, soma = self._soma_dos_limites_base()
        self.assertEqual(_centavos(soma), Decimal("28260.00"))
        sexta, sabado, domingo, segunda = posicoes[24], posicoes[25], posicoes[26], posicoes[27]
        self.assertEqual(sabado.saldo_transferido, sexta.limite_efetivo)
        self.assertEqual(sabado.limite_base, Decimal("0"))
        self.assertEqual(domingo.limite_efetivo, sabado.limite_efetivo)
        self.assertEqual(segunda.limite_efetivo, domingo.limite_efetivo + segunda.limite_base)
        self.assertFalse(sabado.sem_limite_proprio)  # tem saldo herdado para usar

    def test_compra_num_domingo_fica_acima_do_limite(self):
        comprador = Usuario.objects.create_user(
            username="comp_domingo", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Distribuidora Domingo")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos Domingo")
        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=fornecedor, valor=Decimal("100.00"), categoria=categoria,
            centro_custo=None, data_compra=date(2026, 9, 27), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, numero_parcelas=1, usuario=comprador, observacao="",
        )
        self.assertTrue(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.limite_diario, Decimal("0"))


# ---------------------------------------------------------------------------
# 3. Comprador: uma resposta só para "quanto posso comprar hoje"
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class CompradorRespostaUnicaTestCase(_Base):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Resposta Única", cnpj="63.000.000/0001-63")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        _cenario_critico(self.empresa, self.filial, date.today())
        garantir_capacidade_no_dia(self.empresa)
        self.financeiro = Usuario.objects.create_user(
            username="fin_resposta", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.comprador = Usuario.objects.create_user(
            username="comp_resposta", password="x", perfil=Usuario.Perfil.COMPRADOR,
            first_name="Diego", empresa=self.empresa, filial=self.filial,
        )
        # Dotação menor que o limite do dia da filial em QUALQUER mês (28.260 ÷
        # até 24 dias com capacidade = 1.177,50 no mínimo).
        definir_limite_comprador(self.comprador, self.empresa, Decimal("1000.00"), self.financeiro)
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Distribuidora Única")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos Única")

    def _comprar(self, valor):
        return avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal(valor), categoria=self.categoria,
            centro_custo=None, data_compra=date.today(), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, numero_parcelas=1, usuario=self.comprador, observacao="",
        ).compra

    def _painel(self):
        resposta = self.cliente(self.comprador).get("/")
        return resposta, _html(self, resposta)

    def test_sem_compras_cabecalho_card_e_barra_lateral_dizem_o_mesmo_valor(self):
        resposta, html = self._painel()
        self.assertEqual(resposta.context["capacidade_limitada_por"], "dotacao_pessoal")
        self.assertEqual(resposta.context["capacidade_disponivel"], Decimal("1000.00"))
        self.assertIn("Hoje você ainda pode comprar R$ 1.000,00.", resposta.context["cabecalho"]["linhas"])
        card = html.split("data-nx-quanto-posso-comprar", 1)[1].split("</div>", 1)[0]
        self.assertIn("R$ 1.000,00", card)
        self.assertIn('data-nx-sidebar-disponivel>R$ 1.000,00<', html)
        self.assertIn("data-nx-sidebar-percentual>0% utilizado<", html)
        self.assertIn("Minha dotação do dia", html)
        for termo in ("Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal", "Meta Mensal"):
            self.assertNotIn(termo, html)

    def test_excedido_aparece_como_excedido_com_a_mesma_base_da_porcentagem(self):
        self._comprar("800.00")
        self._comprar("900.00")  # passa da dotação: vai para aprovação, mas já conta no dia
        resposta, html = self._painel()
        self.assertEqual(resposta.context["capacidade_disponivel"], Decimal("-700.00"))
        self.assertEqual(resposta.context["capacidade_excedida_em"], Decimal("700.00"))
        self.assertIn(
            "Hoje seu limite de compra foi excedido em R$ 700,00.", resposta.context["cabecalho"]["linhas"]
        )
        card = html.split("data-nx-quanto-posso-comprar", 1)[1].split("</div>", 1)[0]
        self.assertIn("R$ 0,00", card)
        self.assertNotIn("-700", card)
        self.assertIn("limite excedido em R$ 700,00", html)
        # % com base única e explícita: 1.700 ÷ 1.000 (a dotação) = 170%.
        self.assertEqual(round(resposta.context["percentual_utilizado"]), 170)
        self.assertIn("da sua dotação de R$ 1.000,00", html)
        self.assertIn("data-nx-sidebar-percentual>170% utilizado<", html)
        self.assertIn("data-nx-sidebar-excedido>Excedido em R$ 700,00<", html)
        self.assertNotIn("R$ -", html)  # nem no cabeçalho, nem no card, nem no calendário


# ---------------------------------------------------------------------------
# 4. Aprovação por alçada: só "Decidir" para quem decide a etapa atual
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class AprovacaoPorAlcadaTestCase(_Base):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Alçada", cnpj="64.000.000/0001-64")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, cor_principal="")
        Receita.objects.create(filial=self.filial, mes=date(2026, 6, 1), faturamento=Decimal("100000"))
        fluxo = FluxoAprovacao.objects.create(empresa=self.empresa, nome="Gerente e Financeiro", ativo=True)
        EtapaFluxo.objects.create(
            fluxo=fluxo, ordem=1, perfil_aprovador=Usuario.Perfil.GERENTE, valor_maximo=Decimal("3000.00"),
        )
        EtapaFluxo.objects.create(fluxo=fluxo, ordem=2, perfil_aprovador=Usuario.Perfil.FINANCEIRO)

        def criar(username, perfil):
            return Usuario.objects.create_user(
                username=username, password="x", perfil=perfil, empresa=self.empresa, filial=self.filial,
            )

        self.comprador = criar("comp_alcada", Usuario.Perfil.COMPRADOR)
        self.gerente = criar("ger_alcada", Usuario.Perfil.GERENTE)
        self.financeiro = criar("fin_alcada", Usuario.Perfil.FINANCEIRO)
        _, self.solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=self.comprador,
            fornecedor=Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Alçada"),
            categoria=Categoria.objects.create(empresa=self.empresa, nome="Categoria Alçada"),
            data_provisao=date(2026, 6, 10), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": Decimal("999999.00")}],
        )
        self.assertTrue(excedeu)

    def _fila(self, usuario):
        return _html(self, self.cliente(usuario).get("/gestao-compras/aprovacao/"))

    def test_etapa_do_gerente_financeiro_so_acompanha(self):
        html = self._fila(self.financeiro)
        self.assertIn("Fornecedor Alçada", html)
        self.assertNotIn('data-bs-target="#decisao-', html)
        self.assertIn("Aguardando Gerente (etapa 1)", html)
        resposta = self.cliente(self.financeiro).get("/")
        self.assertEqual(resposta.context["provisoes_aguardando_aprovacao"], 0)
        central = self.cliente(self.financeiro).get("/aprovacoes/")
        self.assertEqual(central.context["total_pendente"], 0)
        self.assertIn("Aguardando Gerente (etapa 1)", _html(self, central))

        html = self._fila(self.gerente)
        self.assertIn(f'data-bs-target="#decisao-{self.solicitacao.pk}"', html)
        self.assertEqual(self.cliente(self.gerente).get("/").context["provisoes_aguardando_aprovacao"], 1)

    def test_depois_da_etapa_1_a_vez_e_do_financeiro(self):
        motor_aprovacao_provisao.aprovar(self.solicitacao, self.gerente, "ok da etapa 1")
        self.solicitacao.refresh_from_db()
        self.assertEqual(self.solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

        html = self._fila(self.gerente)
        self.assertNotIn('data-bs-target="#decisao-', html)
        self.assertIn("Aguardando Financeiro (etapa 2)", html)
        self.assertEqual(self.cliente(self.gerente).get("/").context["provisoes_aguardando_aprovacao"], 0)

        html = self._fila(self.financeiro)
        self.assertIn(f'data-bs-target="#decisao-{self.solicitacao.pk}"', html)
        self.assertEqual(self.cliente(self.financeiro).get("/").context["provisoes_aguardando_aprovacao"], 1)
        central = self.cliente(self.financeiro).get("/aprovacoes/")
        self.assertEqual(central.context["total_pendente"], 1)


# ---------------------------------------------------------------------------
# 5. Proprietário: disponibilidade × saldo após compras (= DRE)
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class DisponibilidadeDoMesTestCase(_Base):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Disponibilidade", cnpj="65.000.000/0001-65")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        _cenario_critico(self.empresa, self.filial, date.today())
        self.proprietario = Usuario.objects.create_user(
            username="prop_disp", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Disp")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Disp")
        for valor, status in ((Decimal("6700.00"), Compra.Status.APROVADA), (Decimal("250.00"), Compra.Status.PENDENTE)):
            Compra.objects.create(
                empresa=self.empresa, filial=self.filial, fornecedor=fornecedor, usuario=self.proprietario,
                valor=valor, categoria=categoria, data_compra=date.today(), status=status,
            )

    def test_card_diz_o_que_e_e_mostra_o_saldo_apos_compras_igual_a_dre(self):
        resposta = self.cliente(self.proprietario).get("/")
        html = _html(self, resposta)
        kpis = resposta.context["kpis"]
        self.assertEqual(kpis["saldo_disponivel"], Decimal("78500"))
        self.assertEqual(kpis["saldo_apos_compras"], Decimal("71800"))
        self.assertEqual(kpis["saldo_apos_compras"], resposta.context["resultado_mes"]["resultado"])
        self.assertNotIn("Fluxo — saldo disponível", html)
        self.assertIn("Disponibilidade do mês", html)
        trecho = html.split("data-nx-saldo-apos-compras", 1)[1].split("</span>", 1)[0]
        self.assertIn("R$ 71.800", trecho)


# ---------------------------------------------------------------------------
# 6. Cor principal: o vermelho legado nunca pinta o sistema
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class CorPrincipalPadraoTestCase(_Base):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Cor", cnpj="66.000.000/0001-66")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_cor", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def _override(self, client):
        html = client.get("/").content.decode("utf-8")
        encontrado = re.search(r"--nx-primary:([^;]+);", html)
        return encontrado.group(1) if encontrado else None

    def _dados(self, cor):
        return {
            "percentual_compras": "30", "percentual_seguranca": "0", "dias_uteis_manual": "",
            "limite_maximo_acumulado": "", "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA,
            "cor_principal": cor, "moeda": ConfiguracaoFinanceira.Moeda.BRL, "observacoes": "",
        }

    def test_abrir_e_salvar_sem_mexer_mantem_o_azul_nexbuy(self):
        client = self.cliente(self.proprietario)
        tela = client.get("/financeiro/configuracao/")
        self.assertEqual(tela.status_code, 200)
        self.assertEqual(ConfiguracaoFinanceira.objects.get(empresa=self.empresa).cor_principal, "")
        self.assertEqual(tela.context["form"]["cor_principal"].value(), "#2563EB")
        self.assertIsNone(self._override(client))
        resposta = client.post("/financeiro/configuracao/", self._dados("#2563eb"))
        self.assertEqual(resposta.status_code, 302)
        self.assertIsNone(self._override(client))

    def test_vermelho_legado_do_default_nao_sobrescreve_mas_cor_escolhida_sim(self):
        client = self.cliente(self.proprietario)
        client.post("/financeiro/configuracao/", self._dados("#E11D2E"))
        self.assertIsNone(self._override(client))
        tela = client.get("/financeiro/configuracao/")
        self.assertEqual(tela.context["form"]["cor_principal"].value(), "#2563EB")
        client.post("/financeiro/configuracao/", self._dados("#0C447C"))
        self.assertEqual(self._override(client).lower(), "#0c447c")


# ---------------------------------------------------------------------------
# 7. Estados vazios de Nova Compra / Nova Provisão
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class CadastrosDeApoioFaltandoTestCase(_Base):
    URLS = ("/compras/nova/", "/gestao-compras/nova/")

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Vazia", cnpj="67.000.000/0001-67")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_vazio", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.comprador = Usuario.objects.create_user(
            username="comp_vazio", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    def test_proprietario_recebe_os_atalhos_de_cadastro(self):
        client = self.cliente(self.proprietario)
        for url in self.URLS:
            html = _html(self, client.get(url))
            aviso = html.split("data-nx-cadastros-faltando", 1)[1].split("</div>\n</div>", 1)[0]
            self.assertIn('href="/compras/fornecedores/novo/"', aviso, url)
            self.assertIn('href="/cadastros/categorias/nova/"', aviso, url)
        self.assertEqual(client.get("/compras/fornecedores/novo/").status_code, 200)

    def test_comprador_sabe_a_quem_pedir_e_nao_recebe_link_que_da_403(self):
        client = self.cliente(self.comprador)
        for url in self.URLS:
            html = _html(self, client.get(url))
            aviso = html.split("data-nx-cadastros-faltando", 1)[1].split("</div>\n</div>", 1)[0]
            self.assertIn("Peça ao Proprietário ou ao Financeiro", aviso, url)
            self.assertNotIn("/compras/fornecedores/novo/", aviso)
            self.assertNotIn("/cadastros/categorias/nova/", aviso)
        self.assertEqual(client.get("/compras/fornecedores/novo/").status_code, 403)

    def test_com_cadastros_o_aviso_some(self):
        Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Pronto")
        Categoria.objects.create(empresa=self.empresa, nome="Categoria Pronta")
        client = self.cliente(self.comprador)
        for url in self.URLS:
            self.assertNotIn("data-nx-cadastros-faltando", _html(self, client.get(url)))
