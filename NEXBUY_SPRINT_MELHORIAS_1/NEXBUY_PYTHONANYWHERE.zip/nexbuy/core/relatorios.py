"""Infraestrutura compartilhada da Central de Relatórios (Sprint de
Consolidação — Gate 2A, P1-6): exportação CSV. Nenhuma dependência nova —
só a biblioteca `csv` nativa do Python, como pedido explicitamente.

Cada relatório continua responsável pela própria consulta (respeitando
perfil/permissão/empresa ativa) — este módulo só sabe transformar
cabeçalho + linhas numa resposta HTTP de download.
"""
import csv
import re

from django.http import HttpResponse

# Sprint de Melhorias 1 (segurança): uma célula que começa com = + - @ (ou
# tab/CR) vira FÓRMULA quando o CSV é aberto no Excel — um nome de comprador
# como =HYPERLINK(...) executaria no computador da proprietária. Essas células
# ganham um apóstrofo na frente (o Excel mostra o texto como digitado).
# Números negativos no formato brasileiro (-3.300,00) continuam números.
_INICIO_DE_FORMULA = ("=", "+", "-", "@", "\t", "\r")
_NUMERO_BR = re.compile(r"-?[\d.]+(,\d+)?")


def celula_segura(valor):
    """Neutraliza fórmula numa célula de CSV; números e não-textos passam iguais."""
    if isinstance(valor, str) and valor.startswith(_INICIO_DE_FORMULA) and not _NUMERO_BR.fullmatch(valor):
        return "'" + valor
    return valor


def resposta_csv(nome_arquivo: str, cabecalho, linhas) -> HttpResponse:
    """Gera o download de um CSV pronto para abrir no Excel brasileiro:
    `;` como separador (o `,` é decimal em pt-BR) e BOM UTF-8 (sem ele o
    Excel do Windows interpreta acentos errado)."""
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{nome_arquivo}"'
    response.write("﻿")
    escritor = csv.writer(response, delimiter=";", lineterminator="\r\n")
    escritor.writerow([celula_segura(c) for c in cabecalho])
    escritor.writerows([celula_segura(c) for c in linha] for linha in linhas)
    return response
