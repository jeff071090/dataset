"""Regressão dos bugs REAIS encontrados durante o QA funcional e visual em
navegador real da Etapa 02 (Seção 16 do prompt mestre — ver
NEXBUY_ETAPA_02_QA_FUNCIONAL_VISUAL.md).

Diferente de `core/tests_estados_vazios.py` (cenário pós-Primeiro Acesso já
com Gerente/Financeiro/Comprador criados), este arquivo cobre achados que
não dependiam de nenhum usuário logado — a tela de login é a PRIMEIRA coisa
que qualquer visitante (inclusive um cliente real recém-implantado) vê.
"""
import re
from pathlib import Path

from django.conf import settings
from django.test import Client, TestCase, override_settings

from core.tests_primeiro_acesso import PAYLOAD_VALIDO, TOKEN, realizar_primeiro_acesso


class LoginNuncaExpoeCredencialPadraoTestCase(TestCase):
    """Bug real: `templates/registration/login.html` mostrava, para
    QUALQUER visitante não autenticado (banco vazio ou não), uma dica fixa
    "Usuários de demonstração (senha: nexbuy123) — proprietario · gerente ·
    financeiro · comprador" — incondicional, sem nenhum `{% if demo_mode %}`
    ao redor (diferente do badge "Modo Demonstração" em `templates/base.html`,
    que já segue esse padrão corretamente).

    Isso contraria diretamente a premissa central da Etapa 02
    (Cliente-Ready): o cliente entra num banco ZERADO, sem senha padrão
    nenhuma — expor publicamente, na tela de login, um usuário e senha
    fixos ("nexbuy123") é uma dica de credencial padrão exatamente do tipo
    que o fluxo `/primeiro-acesso/` foi criado para eliminar. Pior: os
    nomes de usuário mostrados (`proprietario`/`gerente`/`financeiro`/
    `comprador`) nem são os do Modo Demonstração real (que usa
    `demo_proprietario` etc., ver DEMO_MODE.md) — são credenciais de
    DESENVOLVIMENTO (`seed_dados`, ver README.md) vazando para qualquer
    visitante de qualquer ambiente.

    Corrigido envolvendo o bloco com `{% if demo_mode %}`, o mesmo sinal já
    usado pelo badge "Modo Demonstração" — nenhuma regra de negócio ou
    dado alterado, só a exibição condicional que já era o padrão do resto
    do projeto."""

    @override_settings(DEMO_MODE=False)
    def test_dica_de_credencial_demo_nao_aparece_com_demo_mode_desligado(self):
        resposta = Client().get("/accounts/login/")
        self.assertEqual(resposta.status_code, 200)
        conteudo = resposta.content.decode("utf-8")
        self.assertNotIn("nexbuy123", conteudo)
        self.assertNotIn("Usuários de demonstração", conteudo)

    @override_settings(DEMO_MODE=True, DEMO_EXIBIR_SENHA=True)
    def test_dica_de_credencial_demo_continua_aparecendo_com_demo_mode_ligado(self):
        """A funcionalidade em si (ajudar quem está numa demonstração ao
        vivo) não pode desaparecer — só deixa de vazar fora desse
        contexto.

        Demo na internet (PythonAnywhere): a dica passou a depender também
        de `DEMO_EXIBIR_SENHA` (padrão = DEBUG, ligado na demo local). O
        override deixa explícito o cenário deste teste — a demonstração
        LOCAL — em vez de depender do DEBUG do ambiente em que a suíte roda.
        O outro lado (servidor, sem a dica) está em
        core/tests_pythonanywhere_demo.py."""
        resposta = Client().get("/accounts/login/")
        self.assertEqual(resposta.status_code, 200)
        conteudo = resposta.content.decode("utf-8")
        self.assertIn("nexbuy123", conteudo)
        self.assertIn("Usuários de demonstração", conteudo)


class BotaoNaoFicaPresoAoCancelarConfirmacaoTestCase(TestCase):
    """Bug real (`static/js/nexbuy.js`): 7 telas usam
    `onsubmit="return confirm('...')"` para pedir confirmação antes de uma
    ação (Bloquear comprador, Rejeitar, excluir Receita/Custo Fixo/Custo
    Variável, Filial, Usuário — ver `grep -rl 'onsubmit="return confirm'
    templates/`). O listener global `document.body.addEventListener(
    "submit", ...)` que trava o botão em estado "carregando" (evita duplo
    envio) roda na fase de BUBBLE, depois do `onsubmit` do próprio
    formulário — então mesmo quando o usuário CANCELA o `confirm()`
    (`onsubmit` retorna `false`, chamando `preventDefault()`), o listener em
    `document.body` disparava do mesmo jeito e desabilitava o botão. Como o
    cancelamento nunca gera POST nem recarrega a página, o botão ficava
    preso (spinner, `disabled`) permanentemente — só um F5 destravava.
    Reproduzido em navegador real durante o QA da Etapa 02 (Seção 16): o
    fluxo automatizado usa a mesma disciplina de "confirm() pode ser
    cancelado" que qualquer usuário real eventualmente aciona.

    Corrigido checando `evento.defaultPrevented` no início do listener —
    sem esse teste (não há test runner de JS neste projeto, só Django),
    este arquivo funciona como trava de regressão textual: garante que o
    guard não seja removido do arquivo estático por engano."""

    def test_listener_global_de_submit_verifica_defaultprevented_antes_de_travar_botao(self):
        caminho = Path(settings.BASE_DIR) / "static" / "js" / "nexbuy.js"
        conteudo = caminho.read_text(encoding="utf-8")

        padrao = re.search(
            r'addEventListener\("submit".*?evento\.defaultPrevented.*?nx-is-loading',
            conteudo,
            re.DOTALL,
        )
        self.assertIsNotNone(
            padrao,
            "O listener global de \"submit\" em nexbuy.js precisa checar "
            "evento.defaultPrevented ANTES de travar o botão em nx-is-loading "
            "— senão cancelar um confirm() deixa o botão preso.",
        )


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class FiltroAutoaprovacaoNaoTransbordaSobreOBotaoTestCase(TestCase):
    """Bug real: `templates/empresas/ncc/central_auditoria.html` — a coluna
    do checkbox "Só autoaprovações" era `col-6 col-md-2 d-flex
    align-items-center` (~110px de largura no viewport de 768px, medido via
    `getBoundingClientRect()` em navegador real). Dois problemas
    combinados, confirmados medindo em navegador real:

    1. O `.form-check` filho é um item flex e, por padrão, um item flex tem
       `min-width: auto` — ele se recusava a encolher abaixo da largura do
       próprio conteúdo, então em vez de quebrar linha dentro da coluna, a
       caixa inteira transbordava para a direita.
    2. Mesmo depois de corrigir isso com `min-width: 0`, a coluna col-md-2
       (~110px) ainda era estreita demais: a palavra "autoaprovações"
       sozinha (sem hífen, não quebra no meio por padrão) não cabe no
       espaço restante depois do padding do checkbox, então transbordava
       mesmo já quebrada para a linha de baixo, sobrepondo o botão
       "Filtrar" vizinho.

    Corrigido com as duas mudanças juntas: `col-md-3` (mais largura) +
    `min-width: 0` no `.form-check` (permite encolher até a largura real da
    coluna) — juntas eliminam a sobreposição sem alterar a centralização
    vertical (`d-flex align-items-center`) usada nos demais viewports.

    Ao corrigir isso, um segundo bug — desta vez introduzido durante a
    própria correção — apareceu: um comentário `{# ... #}` de várias linhas
    não é válido em Django (só `{% comment %}...{% endcomment %}` suporta
    múltiplas linhas) e vazava como texto literal na página. Os dois testes
    abaixo travam essa combinação."""

    def _renderizar_pagina(self):
        client = Client()
        resposta = realizar_primeiro_acesso(client)
        assert resposta.status_code == 302, f"Primeiro Acesso falhou: {resposta.content[:500]}"
        client.login(username="ana.proprietaria", password="S3nhaForteEUnica!2026")

        resposta = client.get("/ncc/central-auditoria/")
        self.assertEqual(resposta.status_code, 200)
        return resposta.content.decode("utf-8")

    def test_coluna_do_checkbox_tem_largura_e_min_width_corrigidos(self):
        conteudo = self._renderizar_pagina()

        padrao = re.search(
            r'class="col-6 col-md-3 d-flex align-items-center">.*?'
            r'form-check mt-4"\s+style="min-width:\s*0;?"[^>]*>\s*'
            r'<input type="checkbox"[^>]*id="filtro-autoaprovacao"',
            conteudo,
            re.DOTALL,
        )
        self.assertIsNotNone(
            padrao,
            "A coluna do filtro \"Só autoaprovações\" precisa ser col-md-3 "
            "(largura suficiente para a palavra inteira) com min-width: 0 "
            "no .form-check (para o item flex poder encolher até a largura "
            "real da coluna) — sem as duas, o texto transborda sobre o "
            "botão \"Filtrar\" em viewports estreitos (ex.: 768px).",
        )

    def test_comentario_de_template_nao_vaza_como_texto_literal(self):
        """Regressão do bug introduzido durante a própria correção acima:
        `{# ... #}` do Django NÃO suporta comentário multi-linha (vira
        texto literal na página) — só `{% comment %}` suporta."""
        conteudo = self._renderizar_pagina()
        self.assertNotIn("QA funcional Etapa 02", conteudo)
        self.assertNotIn("{#", conteudo)
