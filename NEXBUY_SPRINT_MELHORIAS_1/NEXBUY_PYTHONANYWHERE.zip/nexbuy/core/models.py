from django.db import models


class TimeStampedModel(models.Model):
    """Modelo abstrato com datas de criação/atualização, usado por todo o sistema."""

    criado_em = models.DateTimeField("Criado em", auto_now_add=True)
    atualizado_em = models.DateTimeField("Atualizado em", auto_now=True)

    class Meta:
        abstract = True


class ModeloAtivavel(models.Model):
    """Modelo abstrato com o campo `ativo`, usado por todo cadastro que
    suporta exclusão lógica (Empresa, Filial, Fornecedor, Categoria, Centro
    de Custo) — centraliza um campo que antes era redeclarado, idêntico,
    em cada um desses models (Sprint 4.1, auditoria de models)."""

    ativo = models.BooleanField("Ativo", default=True)

    class Meta:
        abstract = True


class EstadoInstalacao(models.Model):
    """Trava técnica singleton do bootstrap (Etapa 02 — Correção Final,
    Bloqueador 2). Existe exatamente 1 linha, criada por migration de
    dados. Nunca guarda o token nem qualquer dado de negócio — só se o
    Primeiro Acesso já foi concluído.

    O motivo de existir: a checagem antiga ("não existe nenhum Usuario
    ativo nem nenhuma Empresa ativa") era feita fora de qualquer
    transação, então duas requisições concorrentes liam "disponível" ao
    mesmo tempo e as duas criavam uma Empresa. Uma linha SEMPRE existente
    pode ser travada com `select_for_update()` dentro de
    `transaction.atomic()` — a segunda requisição concorrente bloqueia
    esperando a primeira commitar (no SQLite isso funciona de verdade
    porque `nexbuy/settings.py` já configura `transaction_mode: "IMMEDIATE"`
    para o banco padrão; no PostgreSQL é o comportamento nativo de
    `select_for_update()`), então relê o estado já atualizado e desiste
    sem criar nada."""

    concluido = models.BooleanField("Setup concluído", default=False)
    concluido_em = models.DateTimeField("Concluído em", null=True, blank=True)

    class Meta:
        verbose_name = "Estado da instalação"
        verbose_name_plural = "Estado da instalação"

    def __str__(self):
        return "Concluído" if self.concluido else "Pendente"
