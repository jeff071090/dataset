"""Funções utilitárias de cálculo compartilhadas pelo sistema NEXBUY."""
import calendar
import os
import secrets
from decimal import ROUND_HALF_UP, Decimal

from django.utils import formats

# Sem caracteres ambíguos (0/O, 1/l/I) — a senha provisória é lida e
# repassada de viva voz/mensagem por quem gerencia usuários (Sprint de
# Consolidação, Gate 2A, Parte 5), então precisa ser fácil de ditar/digitar.
_ALFABETO_SENHA_PROVISORIA = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789"


def gerar_senha_provisoria(tamanho: int = 10) -> str:
    """Senha provisória aleatória e criptograficamente segura (`secrets`,
    nunca `random`) — usada só na hora de gerar, nunca fica salva em texto
    puro em lugar nenhum (só o hash, via `set_password`)."""
    return "".join(secrets.choice(_ALFABETO_SENHA_PROVISORIA) for _ in range(tamanho))


def abortar_seed_em_producao(nome_comando: str) -> None:
    """Sprint de Consolidação (Gate 2A, Parte 10): `seed_demo` e
    `seed_dados` criam usuários com senha pública e conhecida
    ("nexbuy123", documentada em DEMO_MODE.md/README) — nunca podem rodar
    em produção (DEBUG=False) sem um pedido explícito e documentado.
    Levanta CommandError, que o `manage.py` trata como saída limpa (sem
    stack trace) e código de saída diferente de zero.

    Uso real (`settings.USO_REAL`, NEXBUY_USO_REAL=True no .env): recusa
    SEMPRE — com qualquer DEBUG, dentro ou fora dos testes e mesmo com
    ALLOW_SEED_IN_PRODUCTION na linha do comando. O banco guarda os dados
    de verdade da farmácia; nenhum seed mistura dados fictícios e usuários
    com senha pública a eles."""
    from django.conf import settings
    from django.core.management.base import CommandError

    if getattr(settings, "USO_REAL", False):
        raise CommandError(
            f"'{nome_comando}' recusado: este servidor está em USO REAL (NEXBUY_USO_REAL=True no .env) — "
            "o banco guarda os dados de verdade da farmácia. O comando criaria uma empresa fictícia e "
            "usuários com senha pública e conhecida no meio desses dados, por isso nunca roda aqui, nem com "
            "ALLOW_SEED_IN_PRODUCTION. Nada foi gravado. A demonstração com dados fictícios continua no "
            "computador do apresentador (demonstração local)."
        )
    if settings.DEBUG or getattr(settings, "TESTING", False):
        return
    permitido = (os.environ.get("ALLOW_SEED_IN_PRODUCTION") or "").strip().lower() in ("1", "true", "sim", "yes")
    if permitido:
        return
    # A autorização vai SÓ na linha do comando — nunca no .env, que vale
    # também para o site (docs/DEPLOY_PYTHONANYWHERE_DEMO.md, parte 13).
    manter = " --manter-senhas" if nome_comando == "seed_demo" else ""
    raise CommandError(
        f"'{nome_comando}' cria usuários com senha pública e conhecida — bloqueado com DEBUG=False "
        "(servidor). Na demonstração do PythonAnywhere, use o script, que faz backup e mantém as senhas: "
        "bash deploy/pythonanywhere/atualizar_demo.sh --renovar-cenario. "
        "Se você tem certeza do que está fazendo, passe a autorização SÓ nesta linha de comando "
        f"(NUNCA no .env, que vale para o site inteiro): ALLOW_SEED_IN_PRODUCTION=True python manage.py "
        f"{nome_comando}{manter} — e depois confira: python manage.py definir_senha_demo --verificar."
    )


def formatar_moeda(valor, incluir_prefixo: bool = False) -> str:
    """Formata um número no padrão monetário brasileiro: separador de
    milhar "." e duas casas decimais com ",": "1.234,56".

    Usada por mensagens (`django.contrib.messages`) e qualquer outro texto
    montado em Python puro (fora de templates) — o motor de templates já
    formata sozinho via `USE_THOUSAND_SEPARATOR` (Sprint 6, item 1). Reaproveita
    `django.utils.formats.number_format` (mesmo mecanismo do filtro
    `floatformat`) em vez de reimplementar separadores na mão, para nunca
    divergir do que os templates mostram.

    Arredonda (ROUND_HALF_UP, o mesmo de `floatformat`) ANTES de formatar:
    `number_format(decimal_pos=2)` sozinho TRUNCA as casas — 28.260 ÷ 22 =
    1.284,5454… saía "1.284,54" nas mensagens e insights enquanto as
    tabelas (floatformat) mostravam "1.284,55".
    """
    arredondado = Decimal(str(valor) if isinstance(valor, float) else valor).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    texto = formats.number_format(arredondado, decimal_pos=2)
    return f"R$ {texto}" if incluir_prefixo else texto


def formatar_cnpj(cnpj) -> str:
    """Aplica a máscara "XX.XXX.XXX/XXXX-XX" a um CNPJ armazenado de forma
    canônica (só dígitos — ver `core.validators.normalizar_cnpj`), para
    exibição em templates, relatórios/impressão e mensagens.

    Devolve o valor original sem alteração se não tiver exatamente 14
    dígitos (dado legado incompleto, nunca quebra a tela por causa disso)."""
    import re

    digitos = re.sub(r"\D", "", cnpj or "")
    if len(digitos) != 14:
        return cnpj or ""
    return f"{digitos[0:2]}.{digitos[2:5]}.{digitos[5:8]}/{digitos[8:12]}-{digitos[12:14]}"


def dias_uteis_do_mes(ano, mes):
    """Conta os dias úteis (segunda a sexta) de um mês/ano.

    Implementação simples sem calendário de feriados — suficiente para o MVP.
    """
    cal = calendar.Calendar()
    total = 0
    for semana in cal.monthdayscalendar(ano, mes):
        for indice_dia_semana, dia in enumerate(semana):
            if dia != 0 and indice_dia_semana < 5:  # 0=segunda ... 4=sexta
                total += 1
    return total
