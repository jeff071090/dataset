"""Micro-sprint Gate Final V2 — Bloqueador P0.

`core.0001_initial` sempre cria `EstadoInstalacao(concluido=False)` — correto
para um banco novo, mas PERIGOSO para um banco que já tinha Usuario/Empresa
antes desta migration existir: nesse caso, a trava nascia "pendente" mesmo
a instalação já tendo sido concluída há muito tempo por outro mecanismo
(o antigo, sem `EstadoInstalacao`, que só olhava para Usuario/Empresa
ativos). Isso reabria `/primeiro-acesso/` de forma perigosa assim que todos
os usuários/empresas fossem desativados (uma operação legítima, não um
ataque) — a rota voltava a responder 200 com o formulário do token, num
banco que já tem histórico real.

Esta migration, forward-only e posterior a `core.0001_initial`, regulariza
isso uma única vez: se QUALQUER Usuario ou Empresa já existir no banco
neste momento (ativo ou inativo — a mera existência já prova que o
Primeiro Acesso, ou o cadastro manual equivalente de uma versão anterior,
já aconteceu), marca `EstadoInstalacao.concluido=True` e grava
`concluido_em` com o horário desta migração. Se o banco for realmente novo
(nenhum Usuario, nenhuma Empresa), não faz nada — `concluido` continua
`False` como `core.0001_initial` já deixou.

Não edita nenhuma migration existente. Usa exclusivamente modelos
históricos (`apps.get_model`), nunca os models atuais."""
from django.db import migrations
from django.utils import timezone


def regularizar_estado_instalacao(apps, schema_editor):
    EstadoInstalacao = apps.get_model("core", "EstadoInstalacao")
    Usuario = apps.get_model("usuarios", "Usuario")
    Empresa = apps.get_model("empresas", "Empresa")

    ja_existe_algum_registro_de_negocio = Usuario.objects.exists() or Empresa.objects.exists()
    if not ja_existe_algum_registro_de_negocio:
        # Banco realmente novo — nada a regularizar, core.0001_initial já
        # deixou a linha correta (`concluido=False`).
        return

    # `get_or_create` (em vez de `.get()`) por segurança: mesmo que, por
    # algum motivo excepcional, a linha de `core.0001_initial` não exista
    # ainda neste banco específico, a regularização não pode falhar —
    # ela garante a linha e já a marca concluída.
    estado, _criado = EstadoInstalacao.objects.get_or_create()
    if not estado.concluido:
        estado.concluido = True
        estado.concluido_em = timezone.now()
        estado.save(update_fields=["concluido", "concluido_em"])


def reverter_regularizacao(apps, schema_editor):
    """Migration reversa NÃO reabre o Primeiro Acesso — reverter esta
    regularização de forma ingênua (voltar `concluido` para `False`) seria
    exatamente o mesmo risco de segurança que esta migration existe para
    fechar. `reverse` é, de propósito, um no-op seguro."""
    return


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0001_initial"),
        ("usuarios", "0012_sync_catalogo_permissoes_prompt2_gate_a_b"),
        ("empresas", "0006_normalizar_cnpj_para_digitos"),
    ]

    operations = [
        migrations.RunPython(regularizar_estado_instalacao, reverter_regularizacao),
    ]
