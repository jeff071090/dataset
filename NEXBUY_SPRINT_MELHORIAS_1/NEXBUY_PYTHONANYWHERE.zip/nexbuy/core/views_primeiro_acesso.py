"""Primeiro Acesso Seguro (Etapa 02 — Cliente-Ready; Correção Final).

Único jeito de colocar o NEXBUY de pé num banco cliente-ready sem usar
`/admin`, shell manual ou senha publicada em documentação.

Fluxo em DOIS passos, cada um em sua própria URL:

1. `/primeiro-acesso/` — só pede o token, por POST. Nunca aceita o token
   por query string, nunca devolve o valor recebido em lugar nenhum da
   resposta (HTML, header, mensagem, log, auditoria). Em caso de sucesso,
   grava só uma AUTORIZAÇÃO TEMPORÁRIA (nunca o token em si) na sessão,
   com expiração curta, e redireciona para uma URL limpa.
2. `/primeiro-acesso/cadastro/` — o formulário de Empresa/Proprietário de
   verdade. Só responde enquanto a sessão tiver a autorização temporária
   válida (não expirada) E o banco continuar realmente vazio. A criação
   inteira roda dentro de uma única transação que também adquire (via
   `select_for_update()`) a trava técnica `core.models.EstadoInstalacao`
   — isso serializa duas requisições concorrentes: a segunda só enxerga o
   estado já atualizado da primeira depois que ela commitar, e desiste
   sem criar nada (Correção Final, Bloqueador 2).
"""
import hmac
from datetime import timedelta

from django.conf import settings
from django.contrib import messages
from django.core.files.storage import default_storage
from django.db import transaction
from django.http import Http404
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils import timezone

from auditoria.models import RegistroAuditoria
from auditoria.services import ip_do_request, registrar_evento
from core.models import EstadoInstalacao
from empresas.models import ConfiguracaoPlataforma, Empresa, GrupoEmpresarial, IdentidadeVisual
from filiais.models import Filial
from usuarios.models import Usuario

from .forms_primeiro_acesso import PrimeiroAcessoForm, PrimeiroAcessoTokenForm

CHAVE_SESSAO_AUTORIZADO = "primeiro_acesso_autorizado"
CHAVE_SESSAO_AUTORIZADO_EXPIRA = "primeiro_acesso_autorizado_expira_em"
DURACAO_AUTORIZACAO_SEGUNDOS = 15 * 60  # 15 minutos — tempo curto de propósito.


def _sem_cache(resposta):
    """Nenhuma resposta deste fluxo pode ser guardada por proxy/navegador
    — mesmo sem o token no corpo, um cache intermediário nunca deveria
    reter nada desta jornada. `Referrer-Policy` evita que o navegador
    propague a URL desta página (mesmo já limpa, sem segredo) para um
    link/imagem de terceiro eventualmente presente na página seguinte."""
    resposta["Cache-Control"] = "no-store"
    resposta["Referrer-Policy"] = "same-origin"
    return resposta


def _setup_concluido() -> bool:
    # `get_or_create()` (em vez de `.get()`) torna a leitura autossuficiente
    # — a linha normalmente já existe (criada pela migration de dados
    # `core.0001_initial`), mas se por qualquer motivo não existir (ex.:
    # `flush` de um `TransactionTestCase`, que trunca tabelas sem re-rodar
    # migrations de dados), a própria leitura garante a linha em vez de
    # levantar `DoesNotExist`.
    estado, _criado = EstadoInstalacao.objects.get_or_create()
    return estado.concluido


def _primeiro_acesso_disponivel() -> bool:
    """Checagem leve, fora de transação — só decide se a TELA aparece.
    Quem realmente impede a dupla criação é a trava dentro de
    `_criar_estrutura_inicial` (Bloqueador 2); esta função pode ter falso
    positivo sob concorrência sem problema nenhum, porque a criação em si
    está protegida por outro mecanismo."""
    if _setup_concluido():
        return False
    if Usuario.objects.filter(is_active=True).exists():
        return False
    if Empresa.objects.filter(ativo=True).exists():
        return False
    token_configurado = (getattr(settings, "INITIAL_SETUP_TOKEN", "") or "").strip()
    return bool(token_configurado)


def _autorizar_sessao(request):
    request.session[CHAVE_SESSAO_AUTORIZADO] = True
    request.session[CHAVE_SESSAO_AUTORIZADO_EXPIRA] = (
        timezone.now() + timedelta(seconds=DURACAO_AUTORIZACAO_SEGUNDOS)
    ).timestamp()


def _limpar_autorizacao(request):
    request.session.pop(CHAVE_SESSAO_AUTORIZADO, None)
    request.session.pop(CHAVE_SESSAO_AUTORIZADO_EXPIRA, None)


def _sessao_autorizada(request) -> bool:
    if not request.session.get(CHAVE_SESSAO_AUTORIZADO):
        return False
    expira_em = request.session.get(CHAVE_SESSAO_AUTORIZADO_EXPIRA)
    if not expira_em or timezone.now().timestamp() > expira_em:
        _limpar_autorizacao(request)
        return False
    return True


def _criar_estrutura_inicial(dados, ip):
    """Toda a criação em uma única unidade atômica — se qualquer parte
    falhar (inclusive o evento central da Auditoria), nada permanece:
    nenhum usuário parcial, nenhuma Empresa parcial, nenhuma Filial
    parcial, nenhuma configuração parcial, nenhum arquivo de logo órfão
    no storage (Correção Final, Bloqueador 4), e a trava de instalação
    (`EstadoInstalacao`) também volta a `concluido=False` — uma nova
    tentativa depois do rollback pode funcionar."""
    logo_arquivo_salvo = None
    try:
        with transaction.atomic():
            # Correção Final (Bloqueador 2): trava exclusiva na ÚNICA linha
            # de `EstadoInstalacao`. `select_for_update()` bloqueia uma
            # segunda transação concorrente até esta terminar (commit ou
            # rollback) — no SQLite isso é reforçado pelo
            # `transaction_mode: "IMMEDIATE"` já configurado em
            # `nexbuy/settings.py`; no PostgreSQL é o comportamento nativo
            # do lock de linha. Só depois de adquirir a trava é que
            # revalidamos as condições — a checagem feita antes de entrar
            # aqui (`_primeiro_acesso_disponivel`) não vale como garantia.
            estado, _criado = EstadoInstalacao.objects.select_for_update().get_or_create()
            if estado.concluido:
                raise Http404()
            if Usuario.objects.filter(is_active=True).exists():
                raise Http404()
            if Empresa.objects.filter(ativo=True).exists():
                raise Http404()

            grupo = GrupoEmpresarial.objects.create(nome=dados["grupo_nome"])
            empresa = Empresa.objects.create(
                nome=dados["nome"],
                razao_social=dados["razao_social"],
                cnpj=dados["cnpj"],
                grupo=grupo,
                cidade=dados["cidade"],
                estado=dados["estado"],
            )
            filial = Filial.objects.create(
                empresa=empresa, nome=dados["filial_nome"], ativo=True,
                tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
            )
            ConfiguracaoPlataforma.objects.create(empresa=empresa, fuso_horario=dados["fuso_horario"])
            if dados.get("identidade_nome_exibicao") or dados.get("identidade_logo"):
                identidade = IdentidadeVisual.objects.create(
                    empresa=empresa,
                    nome_exibicao=dados.get("identidade_nome_exibicao") or "",
                    logo=dados.get("identidade_logo") or None,
                )
                # Guardamos o nome do arquivo JÁ GRAVADO no storage (o
                # `FileField.save()` grava fisicamente assim que o model é
                # salvo, independente da transação de banco) — se algo
                # depois falhar e esta transação sofrer rollback, o
                # `except` abaixo apaga esse arquivo. Isso evita o arquivo
                # órfão que sobrevivia no `media/` mesmo com o banco
                # revertido.
                if identidade.logo:
                    logo_arquivo_salvo = identidade.logo.name

            # Proprietário Operacional: `create_user` (nunca
            # `create_superuser`) garante `is_staff=False`/
            # `is_superuser=False` — o mesmo Django que protege qualquer
            # conta comum, sem atalho de administrador.
            usuario = Usuario.objects.create_user(
                username=dados["username"],
                password=dados["senha"],
                first_name=dados["first_name"],
                last_name=dados.get("last_name") or "",
            )
            usuario.perfil = Usuario.Perfil.PROPRIETARIO
            usuario.empresa = empresa
            usuario.filial = None
            usuario.save()

            registrar_evento(
                categoria=RegistroAuditoria.Categoria.PRIMEIRO_ACESSO_CONCLUIDO,
                descricao=f'Primeiro acesso concluído — Empresa "{empresa.nome}" e Proprietário "{usuario.username}" criados.',
                empresa=empresa, usuario=usuario, ip=ip, filial=filial,
                modulo="implantacao", acao="primeiro_acesso",
                resultado=RegistroAuditoria.Resultado.SUCESSO,
                tipo_objeto="Empresa", id_objeto=empresa.pk,
                estado_depois={
                    "empresa": empresa.nome, "cnpj": empresa.cnpj,
                    "usuario": usuario.username, "filial": filial.nome,
                },
                # Nunca a senha, nunca o token — só o que já está acima.
            )

            estado.concluido = True
            estado.concluido_em = timezone.now()
            estado.save(update_fields=["concluido", "concluido_em"])
    except Exception:
        if logo_arquivo_salvo:
            default_storage.delete(logo_arquivo_salvo)
        raise
    return usuario, empresa, filial


def primeiro_acesso(request):
    """Passo 1: só o token, só por POST. Nunca lê `request.GET` — um
    `?token=...` legado na URL é simplesmente ignorado, nunca processado
    e nunca refletido em lugar nenhum (Correção Final, Bloqueador 1)."""
    if not _primeiro_acesso_disponivel():
        raise Http404()

    if request.method == "POST":
        form = PrimeiroAcessoTokenForm(request.POST)
        if form.is_valid():
            token_configurado = (getattr(settings, "INITIAL_SETUP_TOKEN", "") or "").strip()
            token_recebido = form.cleaned_data["token"]
            if hmac.compare_digest(token_recebido, token_configurado):
                _autorizar_sessao(request)
                return _sem_cache(redirect("primeiro_acesso_cadastro"))
        # Token ausente/incorreto: mensagem genérica, o valor recebido
        # NUNCA é reaproveitado no contexto do template nem seria exibido
        # de volta mesmo que estivesse (o form não devolve o valor de
        # PasswordInput). Sempre 200 — não é 403 para não sinalizar
        # comportamentos diferentes exploráveis por scanner automatizado.
        return _sem_cache(render(
            request, "core/primeiro_acesso_token.html",
            {"form": PrimeiroAcessoTokenForm(), "erro": "Token inválido ou não informado."},
        ))

    return _sem_cache(render(request, "core/primeiro_acesso_token.html", {"form": PrimeiroAcessoTokenForm()}))


def primeiro_acesso_cadastro(request):
    """Passo 2: exige a autorização temporária concedida no passo 1 —
    nunca aceita nem processa um token aqui. Se a autorização não existe
    ou expirou, volta para o passo 1 (sem revelar mais detalhes)."""
    if not _primeiro_acesso_disponivel():
        raise Http404()
    if not _sessao_autorizada(request):
        return _sem_cache(redirect("primeiro_acesso"))

    if request.method == "POST":
        form = PrimeiroAcessoForm(request.POST, request.FILES)
        if form.is_valid():
            _criar_estrutura_inicial(form.cleaned_data, ip_do_request(request))
            _limpar_autorizacao(request)
            messages.success(request, "Conta criada com sucesso! Faça login para continuar.")
            return _sem_cache(redirect("login"))
    else:
        form = PrimeiroAcessoForm()

    return _sem_cache(render(request, "core/primeiro_acesso.html", {"form": form}))
