"""Apoio compartilhado dos testes (não é um módulo de testes em si — o nome
não casa com o padrão "test*.py" da descoberta do Django).

Regra do Calendário Operacional (crítico funcional, rodada 1): só os dias
que contam capacidade (útil e especial) recebem limite base no day-walk do
Motor Financeiro — sábado e domingo, pela regra padrão, ficam sem limite
próprio (antes recebiam o limite cheio, e a soma do mês passava da
capacidade mensal). Muitos testes lançam compras/provisões "hoje" com a
premissa de que hoje é um dia de compra; como a suíte roda em qualquer dia
da semana (inclusive no GitHub Actions de um sábado), essa premissa agora
precisa ser explícita.
"""
from datetime import date


def garantir_capacidade_no_dia(empresa, data=None):
    """Garante que `data` (padrão: hoje) seja um dia com capacidade para a
    `empresa`: em dia útil não faz nada; em fim de semana/feriado cadastra
    a exceção "Especial (conta capacidade)" — exatamente o que o
    Proprietário faria no Calendário Operacional para liberar compras
    naquele dia. Devolve a data."""
    from finance_engine.calendario_operacional import dia_conta_capacidade, tipo_do_dia
    from financeiro.models import DiaOperacional

    data = data or date.today()
    if not dia_conta_capacidade(tipo_do_dia(empresa, data)):
        DiaOperacional.objects.update_or_create(
            empresa=empresa, data=data,
            defaults={"tipo": DiaOperacional.Tipo.ESPECIAL, "observacao": "Dia de compra (teste)."},
        )
    return data
