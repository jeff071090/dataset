"""Validadores reaproveitáveis por mais de um app (Fechamento Final —
Prompt 1, Seção 4.4).

`validar_cnpj` implementa o algoritmo público e nacional de dígito
verificador de CNPJ (módulo 11 sobre os 12 dígitos base, duas vezes) — um
cálculo matemático único e válido no Brasil inteiro, não uma tabela de
regras por Estado. Cobertura de teste própria em `core/tests.py` prova a
consistência do cálculo (gera uma base válida e confere que o próprio
validador aceita), sem depender de nenhum CNPJ real "decorado".

NÃO existe aqui nenhuma validação de dígito verificador de Inscrição
Estadual por Unidade Federativa: cada um dos 27 Estados usa um formato e
um algoritmo de checksum PRÓPRIO, e reproduzir as 27 regras de memória
seria arriscado — errar uma regra rejeitaria um cadastro de cliente real
por um bug nosso, o que é pior do que não validar o dígito verificador.
Por isso `filiais.Filial` valida IE apenas estruturalmente (só dígitos,
tamanho plausível) e conta com `isento_inscricao_estadual` como escape
explícito. Validação completa por UF, se um dia for necessária, deveria
vir de uma biblioteca mantida (ex.: um pacote dedicado) ou de consulta à
SINTEGRA/Receita — não de uma tabela escrita aqui."""
import re

from django.core.exceptions import ValidationError

PESOS_CNPJ_PRIMEIRO_DIGITO = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
PESOS_CNPJ_SEGUNDO_DIGITO = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]


def _calcular_digito_verificador_cnpj(numeros, pesos):
    soma = sum(int(digito) * peso for digito, peso in zip(numeros, pesos))
    resto = soma % 11
    return "0" if resto < 2 else str(11 - resto)


def cnpj_e_valido(cnpj) -> bool:
    """True se `cnpj` (com ou sem máscara) tem 14 dígitos e os dois
    dígitos verificadores batem com o cálculo oficial. Não é o validador
    de formulário/model (esse é `validar_cnpj`, abaixo) — é a função pura,
    reutilizável também fora do contexto de um Model/Form."""
    if not cnpj:
        return False
    numeros = re.sub(r"\D", "", cnpj)
    if len(numeros) != 14:
        return False
    # Sequências com todos os dígitos iguais (ex.: "11111111111111") batem
    # matematicamente com QUALQUER checksum simples por coincidência do
    # algoritmo — mesma armadilha conhecida do CPF — e nunca são um CNPJ
    # real emitido, então são rejeitadas explicitamente.
    if numeros == numeros[0] * 14:
        return False
    primeiro_digito = _calcular_digito_verificador_cnpj(numeros[:12], PESOS_CNPJ_PRIMEIRO_DIGITO)
    if primeiro_digito != numeros[12]:
        return False
    segundo_digito = _calcular_digito_verificador_cnpj(numeros[:13], PESOS_CNPJ_SEGUNDO_DIGITO)
    return segundo_digito == numeros[13]


def normalizar_cnpj(cnpj) -> str:
    """Representação canônica persistida de um CNPJ (Gate pré-Etapa 10,
    S1-1, item 3): só dígitos, sem máscara. `Empresa` e `Filial` chamam
    isto no próprio `save()` — nunca confiam só no formulário — para que
    QUALQUER caminho de escrita (form, admin, wizard, seed, shell) grave
    sempre a mesma representação, independente de como o CNPJ foi digitado.
    A máscara só existe na apresentação (`core.utils.formatar_cnpj`)."""
    return re.sub(r"\D", "", cnpj or "")


def validar_cnpj(value):
    """Validador de Model/Form (Django chama automaticamente em
    `full_clean()`/`ModelForm.is_valid()`; nunca roda para valor vazio —
    `Field.run_validators` pula validadores quando o valor está em
    `empty_values`, então campos opcionais em branco não disparam isto)."""
    if not cnpj_e_valido(value):
        raise ValidationError(
            "%(value)s não é um CNPJ válido — confira os dígitos.",
            params={"value": value},
        )


def inscricao_estadual_estruturalmente_plausivel(inscricao_estadual) -> bool:
    """Checagem estrutural MÍNIMA (só dígitos, 2 a 14 caracteres) — de
    propósito, não valida o dígito verificador por UF (ver docstring do
    módulo). Usada só para pegar erros grosseiros de digitação (letras,
    campo vazio de espaços, etc.), nunca para reprovar uma IE real."""
    numeros = re.sub(r"\D", "", inscricao_estadual or "")
    return 2 <= len(numeros) <= 14
