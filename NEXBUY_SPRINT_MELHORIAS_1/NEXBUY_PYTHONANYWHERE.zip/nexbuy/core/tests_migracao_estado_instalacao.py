"""Micro-sprint Gate Final V2 — Bloqueador P0: migração segura do
`EstadoInstalacao` para bancos anteriores.

Cenário do bug: um banco que JÁ tinha Usuario/Empresa antes de
`core.0001_initial` existir recebia `EstadoInstalacao(concluido=False)` —
e, se todos os usuários/empresas fossem depois desativados (operação
legítima), `/primeiro-acesso/` voltava a responder 200 num banco com
histórico real. `core.0002_regularizar_estado_instalacao_banco_anterior`
fecha isso: qualquer Usuario/Empresa pré-existente (ativo OU inativo)
marca `concluido=True` de forma permanente.

Estes testes exercitam a REGRA da migration (via a mesma função que a
migration executa, com modelos históricos de verdade obtidos pelo
executor de migrations do Django) e o comportamento fim-a-fim da rota."""
import importlib

from django.db import connection
from django.db.migrations.executor import MigrationExecutor
from django.test import Client, TransactionTestCase, override_settings

from core.models import EstadoInstalacao
from core.tests_primeiro_acesso import TOKEN
from empresas.models import Empresa
from usuarios.models import Usuario

_MODULO_MIGRATION = "core.migrations.0002_regularizar_estado_instalacao_banco_anterior"


def _rodar_regularizacao_com_modelos_historicos():
    """Executa a MESMA função da migration, com o mesmo tipo de argumento
    que o Django passa (o registro de apps do estado histórico do grafo de
    migrations) — não uma simulação com models atuais."""
    modulo = importlib.import_module(_MODULO_MIGRATION)
    executor = MigrationExecutor(connection)
    estado_do_grafo = executor.loader.project_state(
        ("core", "0002_regularizar_estado_instalacao_banco_anterior")
    )
    modulo.regularizar_estado_instalacao(estado_do_grafo.apps, connection.schema_editor())


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class RegularizacaoEstadoInstalacaoTestCase(TransactionTestCase):
    def setUp(self):
        # `TransactionTestCase` trunca as tabelas entre testes (sem
        # re-rodar migrations de dados) — recria o estado que
        # `core.0001_initial` deixa num banco novo.
        EstadoInstalacao.objects.get_or_create(defaults={"concluido": False})

    def test_banco_novo_sem_usuarios_nem_empresas_continua_pendente(self):
        _rodar_regularizacao_com_modelos_historicos()
        estado = EstadoInstalacao.objects.get()
        self.assertFalse(estado.concluido)
        self.assertIsNone(estado.concluido_em)

        resposta = Client().get("/primeiro-acesso/")
        self.assertEqual(resposta.status_code, 200)

    def test_banco_anterior_com_usuario_inativo_marca_concluido(self):
        """A mera EXISTÊNCIA (mesmo inativo) prova instalação anterior."""
        Usuario.objects.create_user(username="antigo", password="x", is_active=False)
        _rodar_regularizacao_com_modelos_historicos()
        estado = EstadoInstalacao.objects.get()
        self.assertTrue(estado.concluido)
        self.assertIsNotNone(estado.concluido_em)

    def test_banco_anterior_com_empresa_inativa_marca_concluido(self):
        Empresa.objects.create(nome="Antiga", cnpj="11.444.777/0001-61", ativo=False)
        _rodar_regularizacao_com_modelos_historicos()
        self.assertTrue(EstadoInstalacao.objects.get().concluido)

    def test_apos_regularizacao_desativar_tudo_nao_reabre_primeiro_acesso(self):
        """O cenário exato da auditoria: banco anterior migrado, depois
        todos os usuários/empresas desativados — a rota tem que continuar
        404, nunca voltar a 200."""
        usuario = Usuario.objects.create_user(username="dono.antigo", password="x", is_active=True)
        empresa = Empresa.objects.create(nome="Empresa Antiga", cnpj="11.444.777/0001-61", ativo=True)
        _rodar_regularizacao_com_modelos_historicos()
        self.assertTrue(EstadoInstalacao.objects.get().concluido)

        usuario.is_active = False
        usuario.save(update_fields=["is_active"])
        empresa.ativo = False
        empresa.save(update_fields=["ativo"])

        resposta = Client().get("/primeiro-acesso/")
        self.assertEqual(resposta.status_code, 404)
        resposta_cadastro = Client().get("/primeiro-acesso/cadastro/")
        self.assertEqual(resposta_cadastro.status_code, 404)

    def test_regularizacao_e_idempotente_e_nunca_duplica_a_linha(self):
        Usuario.objects.create_user(username="antigo", password="x", is_active=False)
        _rodar_regularizacao_com_modelos_historicos()
        primeira_marca = EstadoInstalacao.objects.get().concluido_em
        _rodar_regularizacao_com_modelos_historicos()
        self.assertEqual(EstadoInstalacao.objects.count(), 1)
        # Rodar de novo não sobrescreve o timestamp original.
        self.assertEqual(EstadoInstalacao.objects.get().concluido_em, primeira_marca)

    def test_reversa_da_migration_nao_reabre_instalacao(self):
        """A função reversa é um no-op de propósito — nunca volta
        `concluido` para False."""
        modulo = importlib.import_module(_MODULO_MIGRATION)
        Usuario.objects.create_user(username="antigo", password="x", is_active=False)
        _rodar_regularizacao_com_modelos_historicos()
        self.assertTrue(EstadoInstalacao.objects.get().concluido)

        executor = MigrationExecutor(connection)
        estado_do_grafo = executor.loader.project_state(
            ("core", "0002_regularizar_estado_instalacao_banco_anterior")
        )
        modulo.reverter_regularizacao(estado_do_grafo.apps, connection.schema_editor())
        self.assertTrue(EstadoInstalacao.objects.get().concluido)
