"""Central de Ajuda (/ajuda/) e manuais do repositório.

Cenário REAL de produção: banco limpo, empresa criada pelo Primeiro Acesso
(o administrador é o Proprietário) e um usuário de cada outro perfil —
nenhum dado de negócio, nenhum seed.

Garantias:
1. /ajuda/ exige login e abre (200) para os 4 perfis, sem None/NaN/
   Infinity/Traceback no HTML.
2. O conteúdo se adapta ao perfil; o Comprador NUNCA recebe as seções de
   planejamento financeiro, agenda ou Análise Financeira, nem termos
   financeiros sensíveis (nem com permissão RBAC extra).
3. Todo atalho da ajuda abre sem 403 — o gate de cada destino é o MESMO
   da view (link presente ⇔ tela liberada).
4. Breadcrumb "Início › Ajuda" e link "Manual do sistema" no menu Ajuda.
5. Manuais em docs/ e README coerentes com a Central de Ajuda.
"""
import re
from pathlib import Path

from django.conf import settings
from django.test import Client, SimpleTestCase, TestCase, override_settings
from django.urls import reverse

from core.tests_primeiro_acesso import TOKEN, realizar_primeiro_acesso
from core.views_ajuda import DESTINOS, links_da_ajuda
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.services_analise import REFERENCIAS_MERCADO
from usuarios.models import Permissao, Usuario

BASE_DIR = Path(settings.BASE_DIR)

TERMOS_PROIBIDOS = ("None", "NaN", "Infinity", "Traceback (most recent", "Internal Server Error")
# Contrato do Comprador em todo o sistema (core/tests_demo_showcase.py,
# financeiro/tests_analise.py) — vale para a página inteira.
TERMOS_PROIBIDOS_COMPRADOR_PAGINA = (
    "Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal", "Meta Mensal",
    "Análise Financeira", "/financeiro/analise/",
)
# Mais estrito dentro do manual: nada de receita, custos, margens ou DRE.
TERMOS_PROIBIDOS_COMPRADOR_MANUAL = (
    "faturamento", "receita", "custos fixos", "custo fixo", "custos variáveis", "custo variável",
    "margem", "dre gerencial", "equilíbrio", "análise financeira", "créditos × débitos", "saúde financeira",
    "folha de pagamento", "aluguel", "capacidade mensal", "meta mensal", "contas a pagar",
    "/financeiro/",
)
SECOES_ESPERADAS = {
    Usuario.Perfil.PROPRIETARIO: ["comece", "primeiros-passos", "planejamento", "compras", "aprovacoes",
                                  "agenda", "analise", "relatorios", "faq"],
    Usuario.Perfil.FINANCEIRO: ["comece", "primeiros-passos", "planejamento", "compras", "aprovacoes",
                                "agenda", "analise", "relatorios", "faq"],
    Usuario.Perfil.GERENTE: ["comece", "compras", "aprovacoes", "analise", "relatorios", "faq"],
    Usuario.Perfil.COMPRADOR: ["comece", "compras", "aprovacoes", "relatorios", "faq"],
}
# Destinos em que a ajuda segue o MENU, um subconjunto do gate da view
# (a view também aceita o Financeiro, mas o menu dele não tem o item).
DESTINOS_SUBCONJUNTO_DO_MENU = {"aprovacoes", "indicadores"}

_CSRF = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')


def _manual(html):
    """Só o conteúdo do manual (sem sidebar/topbar)."""
    inicio = html.index('id="aj-manual"')
    fim = html.index("<!-- /aj-manual -->", inicio)
    return html[inicio:fim]


def _secoes(html):
    return re.findall(r'<section class="aj-secao nx-card" id="([^"]+)"', html)


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class CentralAjudaBase(TestCase):
    @classmethod
    def setUpTestData(cls):
        resposta = realizar_primeiro_acesso(Client())
        assert resposta.status_code == 302, resposta.content[:300]
        cls.empresa = Empresa.objects.get(cnpj="11222333000181")
        cls.filial = Filial.objects.get(empresa=cls.empresa)
        cls.proprietario = Usuario.objects.get(username="ana.proprietaria")
        cls.usuarios = {Usuario.Perfil.PROPRIETARIO: cls.proprietario}
        for perfil in (Usuario.Perfil.GERENTE, Usuario.Perfil.FINANCEIRO, Usuario.Perfil.COMPRADOR):
            cls.usuarios[perfil] = Usuario.objects.create_user(
                username=f"{perfil}.ajuda", password="Ajuda!2026Forte", perfil=perfil,
                empresa=cls.empresa, filial=cls.filial, first_name=perfil.capitalize(),
            )

    def cliente(self, perfil):
        client = Client()
        client.force_login(self.usuarios[perfil])
        return client

    def html_ajuda(self, perfil, client=None):
        client = client or self.cliente(perfil)
        resposta = client.get("/ajuda/")
        self.assertEqual(resposta.status_code, 200, perfil)
        return _CSRF.sub(r"\1\2", resposta.content.decode("utf-8"))


class AcessoTestCase(CentralAjudaBase):
    def test_exige_login(self):
        resposta = Client().get("/ajuda/")
        self.assertEqual(resposta.status_code, 302)
        self.assertTrue(resposta["Location"].startswith(reverse("login")))
        self.assertIn("next=/ajuda/", resposta["Location"])

    def test_200_para_os_4_perfis_sem_none_nan(self):
        for perfil in SECOES_ESPERADAS:
            with self.subTest(perfil=perfil):
                html = self.html_ajuda(perfil)
                for termo in TERMOS_PROIBIDOS:
                    self.assertNotIn(termo, html, f"{perfil}: {termo}")
                self.assertIn("Como usar o NEXBUY", html)

    def test_rota_e_nome(self):
        self.assertEqual(reverse("ajuda"), "/ajuda/")


class NavegacaoTestCase(CentralAjudaBase):
    def test_breadcrumb_inicio_ajuda(self):
        html = self.html_ajuda(Usuario.Perfil.COMPRADOR)
        trilha = html.split('class="nx-breadcrumbs"', 1)[1].split("</nav>", 1)[0]
        self.assertIn('<a href="/">Início</a>', trilha)
        self.assertRegex(trilha, r'aria-current="page">\s*<span>Ajuda</span>')

    def test_link_manual_do_sistema_no_menu_ajuda_para_todos(self):
        for perfil in SECOES_ESPERADAS:
            with self.subTest(perfil=perfil):
                html = self.cliente(perfil).get("/").content.decode("utf-8")
                self.assertIn('href="/ajuda/"', html)
                self.assertIn("Manual do sistema", html)

    def test_sumario_aponta_para_secoes_existentes(self):
        for perfil in SECOES_ESPERADAS:
            with self.subTest(perfil=perfil):
                html = self.html_ajuda(perfil)
                sumario = html.split('class="aj-sumario', 1)[1].split("</nav>", 1)[0]
                ancoras = re.findall(r'href="#([^"]+)"', sumario)
                self.assertEqual(ancoras, SECOES_ESPERADAS[perfil])
                for ancora in re.findall(r'href="#([^"]+)"', html):
                    self.assertIn(f'id="{ancora}"', html, f"âncora quebrada: #{ancora}")


class ConteudoPorPerfilTestCase(CentralAjudaBase):
    def test_secoes_por_perfil(self):
        for perfil, esperadas in SECOES_ESPERADAS.items():
            with self.subTest(perfil=perfil):
                self.assertEqual(_secoes(self.html_ajuda(perfil)), esperadas)

    def test_comprador_nunca_recebe_secoes_nem_termos_financeiros(self):
        html = self.html_ajuda(Usuario.Perfil.COMPRADOR)
        for termo in TERMOS_PROIBIDOS_COMPRADOR_PAGINA:
            self.assertNotIn(termo, html, f"termo sensível na página do Comprador: {termo}")
        manual = _manual(html).lower()
        for termo in TERMOS_PROIBIDOS_COMPRADOR_MANUAL:
            self.assertNotIn(termo, manual, f"termo financeiro no manual do Comprador: {termo}")
        for secao in ("primeiros-passos", "planejamento", "agenda", "analise"):
            self.assertNotIn(f'id="{secao}"', html)

    def test_comprador_com_permissao_extra_continua_sem_secoes_financeiras(self):
        comprador = self.usuarios[Usuario.Perfil.COMPRADOR]
        comprador.permissoes_individuais.add(
            *Permissao.objects.filter(codigo__in=("financeiro.ver", "agenda.ver", "timeline.ver"))
        )
        html = self.html_ajuda(Usuario.Perfil.COMPRADOR)
        self.assertEqual(_secoes(html), SECOES_ESPERADAS[Usuario.Perfil.COMPRADOR])
        manual = _manual(html).lower()
        for termo in TERMOS_PROIBIDOS_COMPRADOR_MANUAL:
            self.assertNotIn(termo, manual, termo)

    def test_gerente_so_ve_a_agenda_quando_recebe_a_permissao(self):
        gerente = self.usuarios[Usuario.Perfil.GERENTE]
        self.assertNotIn('id="agenda"', self.html_ajuda(Usuario.Perfil.GERENTE))
        gerente.permissoes_individuais.add(Permissao.objects.get(codigo="agenda.ver"))
        html = self.html_ajuda(Usuario.Perfil.GERENTE)
        self.assertIn('id="agenda"', html)
        self.assertIn('href="/financeiro/agenda/"', _manual(html))
        self.assertIn("A baixa é feita pelo Financeiro ou pelo Proprietário", html)

    def test_administrador_ve_roteiro_de_implantacao_completo(self):
        html = self.html_ajuda(Usuario.Perfil.PROPRIETARIO)
        manual = _manual(html)
        for trecho in ("Primeiro Acesso", "Dados da empresa", "Filiais", "Usuários e perfis de acesso",
                       "Configuração financeira", "percentual destinado às compras", "Receita mensal",
                       "Receitas extras", "Custos fixos", "Custos variáveis", "Limites dos compradores",
                       "Fluxo de aprovação", "Checklist de implantação"):
            self.assertIn(trecho, manual, trecho)
        for url in ("/ncc/usuarios/novo/", "/ncc/filiais/", "/financeiro/configuracao/",
                    "/financeiro/receitas/nova/", "/financeiro/receitas/extras/", "/ncc/checklist/",
                    "/ncc/workflow/", "/financeiro/capacidade-compradores/"):
            self.assertIn(f'href="{url}"', manual, url)

    def test_financeiro_ve_passos_do_administrador_como_texto_sem_link(self):
        manual = _manual(self.html_ajuda(Usuario.Perfil.FINANCEIRO))
        self.assertIn("Feito pelo administrador", manual)
        for url in ("/ncc/usuarios/novo/", "/ncc/filiais/", "/ncc/checklist/", "/ncc/workflow/", "/empresas/"):
            self.assertNotIn(f'href="{url}"', manual, url)
        self.assertIn('href="/financeiro/receitas/nova/"', manual)

    def test_faq_responde_senha_aprovacao_e_dda(self):
        for perfil in SECOES_ESPERADAS:
            with self.subTest(perfil=perfil):
                manual = _manual(self.html_ajuda(perfil))
                self.assertIn("Esqueci a minha senha", manual)
                self.assertIn("Gerar nova senha provisória", manual)
                self.assertIn("para aprovação?", manual)
                self.assertIn("O que é o DDA e quando ele vem?", manual)
                self.assertIn("ainda não está conectada", manual)

    def test_analise_explica_glossario_e_usa_as_faixas_do_calculo(self):
        for perfil in (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.GERENTE, Usuario.Perfil.FINANCEIRO):
            with self.subTest(perfil=perfil):
                manual = _manual(self.html_ajuda(perfil))
                for termo in ("Margem bruta", "Margem de contribuição", "Ponto de equilíbrio", "Margem de segurança"):
                    self.assertIn(f"<dt>{termo}</dt>", manual, termo)
                faixa = REFERENCIAS_MERCADO["margem_bruta"]["saudavel"]
                self.assertIn(f"a partir de {int(faixa)}%", manual)


class LinksSemBloqueioTestCase(CentralAjudaBase):
    def test_nenhum_link_da_ajuda_leva_a_403(self):
        for perfil in SECOES_ESPERADAS:
            client = self.cliente(perfil)
            manual = _manual(self.html_ajuda(perfil, client))
            hrefs = sorted(set(re.findall(r'href="(/[^"#?]*)', manual)))
            self.assertTrue(hrefs, perfil)
            for href in hrefs:
                with self.subTest(perfil=perfil, href=href):
                    status = client.get(href).status_code
                    self.assertNotIn(status, (403, 404, 500), f"{perfil} {href} -> {status}")

    def test_gate_de_cada_atalho_e_o_mesmo_da_view(self):
        """Link presente ⇔ a tela abre para o perfil (e ausente ⇔ 403)."""
        for perfil in SECOES_ESPERADAS:
            client = self.cliente(perfil)
            request = client.get("/ajuda/").wsgi_request
            links = links_da_ajuda(self.usuarios[perfil], request)
            for chave, _rotulo, url_name, _icone, _permissao, _perfis in DESTINOS:
                with self.subTest(perfil=perfil, destino=chave):
                    status = client.get(reverse(url_name)).status_code
                    if chave in links:
                        self.assertNotEqual(status, 403, f"{perfil}: atalho {chave} daria 403")
                    elif chave not in DESTINOS_SUBCONJUNTO_DO_MENU:
                        self.assertEqual(status, 403, f"{perfil}: {chave} abre ({status}) mas a ajuda esconde")

    def test_rbac_aditivo_libera_o_atalho_junto_com_a_tela(self):
        gerente = self.usuarios[Usuario.Perfil.GERENTE]
        client = self.cliente(Usuario.Perfil.GERENTE)
        self.assertEqual(client.get("/financeiro/agenda/").status_code, 403)
        gerente.permissoes_individuais.add(Permissao.objects.get(codigo="agenda.ver"))
        manual = _manual(self.html_ajuda(Usuario.Perfil.GERENTE, client))
        self.assertIn('href="/financeiro/agenda/"', manual)
        self.assertEqual(client.get("/financeiro/agenda/").status_code, 200)


class ImpressaoTestCase(CentralAjudaBase):
    def test_pagina_imprimivel(self):
        html = self.html_ajuda(Usuario.Perfil.FINANCEIRO)
        self.assertIn("css/ajuda.css", html)
        self.assertIn('class="nx-print-header"', html)
        self.assertIn("Manual do sistema — perfil Financeiro", html)
        self.assertIn('onclick="window.print()"', html)
        self.assertRegex(html, r'class="aj-sumario nx-no-print"')
        css = (BASE_DIR / "static" / "css" / "ajuda.css").read_text(encoding="utf-8")
        self.assertIn("@media print", css)
        self.assertNotIn("http://", css)
        self.assertNotIn("https://", css)

    def test_templates_da_ajuda_sem_comentario_multilinha_vazando(self):
        for arquivo in sorted((BASE_DIR / "templates" / "core" / "ajuda").glob("*.html")):
            with self.subTest(arquivo=arquivo.name):
                texto = arquivo.read_text(encoding="utf-8")
                self.assertIsNone(re.search(r"\{#[^#]*\n", texto), "comentário {# #} em várias linhas vaza na página")
                self.assertNotIn("{{ ano }}", texto)


class DocumentosTestCase(SimpleTestCase):
    DOCS = ("MANUAL_DO_USUARIO.md", "PRIMEIROS_PASSOS_ADMINISTRADOR.md",
            "DEPLOY_HOSTINGER_GITHUB.md", "OPERACAO_BACKUP_E_ATUALIZACAO.md")

    def _ler(self, *partes):
        return (BASE_DIR.joinpath(*partes)).read_text(encoding="utf-8")

    def test_readme_aponta_para_os_4_documentos_existentes(self):
        readme = self._ler("README.md")
        for nome in self.DOCS:
            with self.subTest(doc=nome):
                self.assertIn(f"docs/{nome}", readme)
                self.assertTrue((BASE_DIR / "docs" / nome).exists(), nome)

    def test_readme_reflete_o_escopo_atual(self):
        readme = self._ler("README.md")
        self.assertNotIn("Inovafarma", readme)
        for trecho in ("DDA", "Análise Financeira", "estoque", "/ajuda/", "manual"):
            self.assertIn(trecho, readme, trecho)

    def test_manual_do_usuario_cobre_os_4_perfis_e_a_central_de_ajuda(self):
        manual = self._ler("docs", "MANUAL_DO_USUARIO.md")
        for trecho in ("Proprietário", "Gerente", "Financeiro", "Comprador", "/ajuda/", "Provisão",
                       "Margem de contribuição", "Ponto de equilíbrio", "Margem de segurança",
                       "Esqueci", "DDA"):
            self.assertIn(trecho, manual, trecho)
        self.assertNotIn("Inovafarma", manual)

    def test_primeiros_passos_tem_roteiro_em_ordem_e_checklist(self):
        guia = self._ler("docs", "PRIMEIROS_PASSOS_ADMINISTRADOR.md")
        ordem = ["Primeiro Acesso", "Dados da empresa", "Filiais", "Usuários", "Configuração financeira",
                 "Receita mensal", "Receitas extras", "Custos fixos", "Custos variáveis",
                 "Limites dos compradores", "Fluxo de aprovação", "Checklist de Implantação"]
        ultimo = -1
        for trecho in ordem:
            posicao = guia.find(trecho, ultimo + 1)
            self.assertGreater(posicao, ultimo, f"fora de ordem ou ausente: {trecho}")
            ultimo = posicao
        self.assertGreaterEqual(guia.count("- [ ]"), 12, "o checklist imprimível precisa das caixas")
        self.assertIn("INITIAL_SETUP_TOKEN", guia)
