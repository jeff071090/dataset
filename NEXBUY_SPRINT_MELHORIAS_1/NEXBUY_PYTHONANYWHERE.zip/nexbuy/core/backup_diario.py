"""Backup diário automático do banco SQLite, feito pelo próprio site.

Por quê: a conta grátis do PythonAnywhere criada depois de 15/01/2026 não
tem "scheduled tasks" — sem agendador, quem garante uma cópia por dia é o
próprio NEXBUY, aproveitando o primeiro acesso do dia. (Na VPS o backup é
do cron, com deploy/backup.sh; lá BACKUP_DIARIO fica desligado.)

Configuração (nexbuy/settings.py, tudo desligado por padrão):

    BACKUP_DIARIO=True
    BACKUP_DIARIO_DIR=/home/<usuario>/nexbuy_backups
    BACKUP_DIARIO_MANTER=14

O que acontece:

1. `BackupDiarioMiddleware` só entra na cadeia com BACKUP_DIARIO=True e a
   configuração válida (banco SQLite + pasta com caminho completo). Fora
   disso sai na subida do processo (MiddlewareNotUsed): custo zero; com a
   configuração errada, deixa um aviso no log e o site segue normal.
2. Em cada requisição o custo é uma comparação de números: o processo
   guarda em memória o horário da próxima verificação (a meia-noite de
   Cuiabá seguinte, depois que o backup do dia está garantido). Só a
   primeira requisição do dia de cada processo agenda a verificação.
3. A verificação roda DEPOIS de a resposta ser entregue (no fechamento da
   resposta, como o Django faz com arquivos abertos) — quem abriu a página
   não espera a cópia. Ela olha se <pasta>/diario_AAAA-MM-DD.sqlite3 de
   hoje já existe (um `os.path.exists` por dia por processo); se não
   existe, copia o banco pela API de backup do SQLite
   (`sqlite3.Connection.backup`, abrindo o ARQUIVO do banco direto, só para
   leitura — nunca a conexão do Django) para um arquivo
   "<nome>.<pid>.parcial", confere `PRAGMA integrity_check` == "ok",
   renomeia para o nome final, aplica permissão 600 e apaga as cópias
   "diario_AAAA-MM-DD.sqlite3" mais antigas que as BACKUP_DIARIO_MANTER
   mais recentes. Nenhum outro arquivo da pasta é tocado — em especial os
   backups feitos à mão (nexbuy_*.sqlite3), que têm a retenção deles.

Trava entre processos: arquivo "<pasta>/.diario_backup.trava" criado com
O_CREAT|O_EXCL (atômico também no disco de rede do PythonAnywhere). Se
existe e foi criado há menos de 15 minutos, outro processo está copiando:
este desiste e confere de novo em 2 minutos (aí o arquivo do dia já existe).
Com mais de 15 minutos é sobra de um processo que morreu no meio: é
apagado e a cópia segue. Mesmo no pior caso (dois processos copiando ao
mesmo tempo), cada um usa o próprio ".parcial" e a troca pelo nome final é
atômica — o resultado é sempre uma cópia íntegra.

Política de nova tentativa: qualquer erro (disco cheio, pasta sem
permissão, banco travado, cópia que não passou no integrity_check) vira
`logger.exception` e uma nova tentativa 30 minutos depois, no mesmo
processo — nunca derruba nem atrasa a página. Um problema permanente gera
no máximo ~2 linhas de log por hora por processo. Configuração inválida
não melhora sozinha: avisa uma vez e só confere de novo no dia seguinte.

À mão: `python manage.py backup_diario` (a mesma função, com a mesma
trava).
"""
import logging
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from django.conf import settings
from django.core.exceptions import MiddlewareNotUsed
from django.utils import timezone

logger = logging.getLogger(__name__)

# Só arquivos com exatamente este nome são do backup diário — a retenção
# nunca olha para mais nada.
PADRAO_COPIA = re.compile(r"^diario_(\d{4}-\d{2}-\d{2})\.sqlite3$")
# O ".parcial" e os arquivos que o SQLite cria ao lado dele enquanto grava
# (-journal; -wal/-shm se um dia o modo WAL for usado): se o processo morre
# no meio da cópia (Reload do site, kill), eles ficam para trás juntos.
SUFIXOS_DO_SQLITE = ("-journal", "-wal", "-shm")
PADRAO_PARCIAL = re.compile(r"^diario_\d{4}-\d{2}-\d{2}\.sqlite3\.\d+\.parcial(-journal|-wal|-shm)?$")
NOME_TRAVA = ".diario_backup.trava"

ESPERA_APOS_FALHA = 30 * 60  # segundos
ESPERA_COM_TRAVA_OCUPADA = 2 * 60
VALIDADE_DA_TRAVA = 15 * 60
TEMPO_ESPERA_BANCO = 10  # segundos esperando o banco ficar livre para leitura

ENGINE_SQLITE = "django.db.backends.sqlite3"

# Alias local: os testes contam quantas vezes o backup olha o disco.
_existe = os.path.exists


class BackupDiarioErro(Exception):
    """Falha da cópia (mensagem em português, sem segredo nenhum)."""


@dataclass
class Resultado:
    # "criado", "ja_existia", "ocupado" (outro processo copiando) ou
    # "configuracao" (BACKUP_DIARIO_DIR/banco inválidos — `mensagem` diz o quê).
    situacao: str
    caminho: str = ""
    mensagem: str = ""
    removidos: list = field(default_factory=list)


# --------------------------------------------------------------------------
# Configuração (lida a cada chamada: override_settings funciona nos testes)
# --------------------------------------------------------------------------


def _config_banco():
    return settings.DATABASES["default"]


def caminho_do_banco():
    """Arquivo do banco SQLite do site (SQLITE_PATH, ou db.sqlite3 na raiz)."""
    return str(_config_banco().get("NAME") or "")


def pasta_de_backup():
    return (getattr(settings, "BACKUP_DIARIO_DIR", "") or "").strip()


def copias_a_manter():
    try:
        return max(2, int(getattr(settings, "BACKUP_DIARIO_MANTER", 14)))
    except (TypeError, ValueError):
        return 14


def problema_de_configuracao():
    """Texto do problema (para log/console) ou "" se dá para copiar."""
    engine = _config_banco().get("ENGINE", "")
    if engine != ENGINE_SQLITE:
        return (
            f"o banco não é SQLite ({engine or 'sem ENGINE'}) — o backup diário automático só copia "
            "banco SQLite. Desligue BACKUP_DIARIO no .env."
        )
    pasta = pasta_de_backup()
    if not pasta:
        return "BACKUP_DIARIO_DIR está vazio no .env (ex.: BACKUP_DIARIO_DIR=/home/<usuario>/nexbuy_backups)."
    if not os.path.isabs(pasta):
        return (
            f"BACKUP_DIARIO_DIR precisa ser um caminho completo, começando na raiz (está \"{pasta}\"; "
            "ex.: /home/<usuario>/nexbuy_backups)."
        )
    return ""


# --------------------------------------------------------------------------
# Datas (sempre no fuso do projeto, America/Cuiaba)
# --------------------------------------------------------------------------


def _agora():
    return timezone.now()


def dia_local(agora=None):
    return timezone.localtime(agora or _agora(), timezone.get_default_timezone()).date()


def _inicio_do_dia_seguinte(agora):
    fuso = timezone.get_default_timezone()
    amanha = dia_local(agora) + timedelta(days=1)
    return datetime(amanha.year, amanha.month, amanha.day, tzinfo=fuso).timestamp()


def caminho_da_copia(dia, pasta=None):
    return os.path.join(pasta or pasta_de_backup(), f"diario_{dia.isoformat()}.sqlite3")


def copias_existentes(pasta=None):
    """Nomes das cópias diárias da pasta, da mais antiga para a mais nova
    (o nome tem a data, então a ordem alfabética é a cronológica)."""
    pasta = pasta or pasta_de_backup()
    try:
        with os.scandir(pasta) as itens:
            return sorted(item.name for item in itens if PADRAO_COPIA.match(item.name) and item.is_file())
    except FileNotFoundError:
        return []


# --------------------------------------------------------------------------
# A cópia
# --------------------------------------------------------------------------


def _apagar_sem_erro(caminho):
    try:
        os.remove(caminho)
    except FileNotFoundError:
        pass
    except OSError:
        logger.warning("Backup diário: não consegui apagar %s.", caminho)


def _criar_arquivo_privado(caminho):
    """Cria o arquivo vazio já com permissão 600 — a cópia nunca fica
    legível por outros nem por um instante."""
    descritor = os.open(caminho, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(descritor)


def _integridade(caminho):
    """Resultado do PRAGMA integrity_check ("ok" quando a cópia está boa)."""
    conexao = sqlite3.connect(caminho)
    try:
        linhas = conexao.execute("PRAGMA integrity_check").fetchall()
    finally:
        conexao.close()
    return "\n".join(str(linha[0]) for linha in linhas)


_INTERVALO = 0.25  # segundos entre tentativas com o banco ocupado


def _desistir_se_ocupado_demais():
    """Sozinho, `Connection.backup` tenta de novo PARA SEMPRE enquanto o
    banco estiver ocupado — e prenderia o processo do site. Mesma solução de
    core/management/commands/limpar_movimentacoes.py::copiar_banco_sqlite:
    o callback de progresso conta as tentativas seguidas com o banco
    ocupado e desiste (TimeoutError) depois de ~TEMPO_ESPERA_BANCO."""
    limite = max(1, int(TEMPO_ESPERA_BANCO / _INTERVALO))
    ocupado = {"vezes": 0}

    def progresso(status, _restantes, _total):
        if status in (sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED):
            ocupado["vezes"] += 1
            if ocupado["vezes"] > limite:
                raise TimeoutError(f"o banco ficou ocupado por mais de {TEMPO_ESPERA_BANCO:g} segundos.")
        else:
            ocupado["vezes"] = 0

    return progresso


def _apagar_parcial(parcial):
    """O ".parcial" e o que o SQLite deixou ao lado dele."""
    _apagar_sem_erro(parcial)
    for sufixo in SUFIXOS_DO_SQLITE:
        _apagar_sem_erro(parcial + sufixo)


def _copiar(origem, destino):
    """Cópia íntegra do arquivo `origem` para `destino`, via ".parcial"."""
    if not os.path.isfile(origem):
        raise BackupDiarioErro(f"banco não encontrado em {origem}.")
    parcial = f"{destino}.{os.getpid()}.parcial"
    _apagar_parcial(parcial)  # sobra deste mesmo processo numa tentativa anterior
    _criar_arquivo_privado(parcial)
    try:
        # Só leitura e pelo arquivo: nunca cria um banco vazio no lugar de um
        # que sumiu, nunca grava no banco do site e nunca usa a conexão do
        # Django (que pode estar no meio de uma transação do request).
        fonte = sqlite3.connect(Path(origem).resolve().as_uri() + "?mode=ro", uri=True, timeout=_INTERVALO)
        try:
            copia = sqlite3.connect(parcial)
            try:
                fonte.backup(copia, pages=-1, progress=_desistir_se_ocupado_demais(), sleep=_INTERVALO)
            finally:
                copia.close()
        finally:
            fonte.close()
        resultado = _integridade(parcial)
        if resultado != "ok":
            raise BackupDiarioErro(f"a cópia não passou no PRAGMA integrity_check: {resultado[:200]}")
        os.replace(parcial, destino)
    except BaseException:
        _apagar_parcial(parcial)
        raise
    try:
        os.chmod(destino, 0o600)
    except OSError:
        logger.warning("Backup diário: não consegui aplicar a permissão 600 em %s.", destino)


def _aplicar_retencao(pasta, manter, preservar=""):
    """Apaga as cópias diárias além das `manter` mais recentes. Devolve os
    nomes apagados. Só arquivos "diario_AAAA-MM-DD.sqlite3" — e nunca a
    cópia que acabou de ser feita (`preservar`), nem com o relógio do
    servidor atrasado em relação às cópias que já estão na pasta."""
    nomes = copias_existentes(pasta)
    excedentes = nomes[:-manter] if len(nomes) > manter else []
    excedentes = [nome for nome in excedentes if nome != preservar]
    for nome in excedentes:
        _apagar_sem_erro(os.path.join(pasta, nome))
    return excedentes


def _limpar_parciais_antigas(pasta):
    """".parcial" (e o "-journal" que o SQLite deixa ao lado) de um processo
    que morreu no meio da cópia — só os nossos, e só os velhos: um recente
    pode ser de outro processo copiando agora."""
    limite = time.time() - VALIDADE_DA_TRAVA
    with os.scandir(pasta) as itens:
        for item in itens:
            if PADRAO_PARCIAL.match(item.name) and item.is_file():
                try:
                    if item.stat().st_mtime < limite:
                        _apagar_sem_erro(item.path)
                except FileNotFoundError:
                    pass


# --------------------------------------------------------------------------
# Trava entre processos
# --------------------------------------------------------------------------


def _trava_vencida(caminho):
    try:
        return time.time() - os.path.getmtime(caminho) > VALIDADE_DA_TRAVA
    except FileNotFoundError:
        return True


def _pegar_trava(pasta):
    """Caminho da trava se conseguiu; None se outro processo está copiando."""
    caminho = os.path.join(pasta, NOME_TRAVA)
    for _tentativa in range(2):
        try:
            descritor = os.open(caminho, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            if not _trava_vencida(caminho):
                return None
            logger.warning("Backup diário: trava antiga (mais de %d min) removida: %s", VALIDADE_DA_TRAVA // 60, caminho)
            _apagar_sem_erro(caminho)
            continue
        with os.fdopen(descritor, "w", encoding="ascii") as arquivo:
            arquivo.write(f"{os.getpid()} {int(time.time())}\n")
        return caminho
    return None


def _soltar_trava(caminho):
    _apagar_sem_erro(caminho)


# --------------------------------------------------------------------------
# Entrada principal (middleware e comando manage.py backup_diario)
# --------------------------------------------------------------------------


def fazer_backup_diario(agora=None):
    """Garante a cópia de hoje. Devolve um `Resultado`; levanta exceção se
    a cópia falhar (quem chama decide: o middleware loga e segue, o comando
    mostra o erro). Não olha BACKUP_DIARIO — o comando manual funciona com
    o automático desligado."""
    problema = problema_de_configuracao()
    if problema:
        return Resultado("configuracao", mensagem=problema)
    pasta = pasta_de_backup()
    destino = caminho_da_copia(dia_local(agora), pasta)
    if _existe(destino):
        return Resultado("ja_existia", destino)

    os.makedirs(pasta, mode=0o700, exist_ok=True)
    trava = _pegar_trava(pasta)
    if trava is None:
        return Resultado("ocupado", destino, mensagem="outro processo está fazendo a cópia agora.")
    try:
        # Outro processo pode ter terminado a cópia entre a conferência
        # acima e a trava.
        if os.path.exists(destino):
            return Resultado("ja_existia", destino)
        _limpar_parciais_antigas(pasta)
        inicio = time.monotonic()
        _copiar(caminho_do_banco(), destino)
        duracao = time.monotonic() - inicio
        removidos = _aplicar_retencao(pasta, copias_a_manter(), preservar=os.path.basename(destino))
    finally:
        _soltar_trava(trava)
    logger.info(
        "Backup diário criado: %s (%.1f s; cópias antigas removidas: %d).", destino, duracao, len(removidos),
    )
    return Resultado("criado", destino, removidos=removidos)


# Estado do processo: horário (epoch) a partir do qual vale conferir de novo.
_proxima_verificacao = 0.0
_trava_do_processo = threading.Lock()


def reiniciar_estado():
    """Volta o processo ao estado "nunca conferiu" (testes / processo novo)."""
    global _proxima_verificacao
    _proxima_verificacao = 0.0


def backup_pendente(agora=None):
    """O teste barato de cada requisição: uma comparação de números."""
    return (agora or _agora()).timestamp() >= _proxima_verificacao


def verificar_backup_diario():
    """Faz o backup do dia se ainda não foi feito. NUNCA levanta exceção."""
    global _proxima_verificacao
    if not _trava_do_processo.acquire(blocking=False):
        return  # outra thread deste processo já está cuidando disso
    try:
        agora = _agora()
        if not backup_pendente(agora):
            return
        try:
            resultado = fazer_backup_diario(agora)
        except Exception:
            _proxima_verificacao = agora.timestamp() + ESPERA_APOS_FALHA
            logger.exception(
                "Backup diário FALHOU (o site segue normal; nova tentativa em %d minutos).",
                ESPERA_APOS_FALHA // 60,
            )
            return
        if resultado.situacao == "ocupado":
            _proxima_verificacao = agora.timestamp() + ESPERA_COM_TRAVA_OCUPADA
            return
        if resultado.situacao == "configuracao":
            logger.warning("Backup diário desligado: %s", resultado.mensagem)
        _proxima_verificacao = _inicio_do_dia_seguinte(agora)
    except Exception:  # pragma: no cover — rede de segurança final
        _proxima_verificacao = time.time() + ESPERA_APOS_FALHA
        logger.exception("Backup diário: erro inesperado (o site segue normal).")
    finally:
        _trava_do_processo.release()


def _depois_da_resposta(resposta, funcao):
    """Roda `funcao` quando o servidor fecha a resposta (já entregue ao
    navegador) — o mesmo gancho que o Django usa para fechar arquivos de
    um FileResponse. Sem o gancho (outra classe de resposta), roda já."""
    ganchos = getattr(resposta, "_resource_closers", None)
    if isinstance(ganchos, list):
        ganchos.append(funcao)
    else:
        funcao()


class BackupDiarioMiddleware:
    def __init__(self, get_response):
        if not getattr(settings, "BACKUP_DIARIO", False):
            raise MiddlewareNotUsed
        problema = problema_de_configuracao()
        if problema:
            logger.warning("Backup diário (BACKUP_DIARIO=True) não vai rodar: %s", problema)
            raise MiddlewareNotUsed
        self.get_response = get_response

    def __call__(self, request):
        resposta = self.get_response(request)
        try:
            if backup_pendente():
                _depois_da_resposta(resposta, verificar_backup_diario)
        except Exception:  # pragma: no cover — nunca deixa o backup afetar a página
            logger.exception("Backup diário: erro ao agendar (o site segue normal).")
        return resposta
