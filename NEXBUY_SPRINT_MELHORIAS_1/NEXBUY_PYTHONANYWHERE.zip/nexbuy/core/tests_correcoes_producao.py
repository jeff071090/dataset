"""Correções de Produção (véspera da implantação na VPS) — UX, cadastros e
visão do Gerente.

Cobre, contra o HTML REAL renderizado pelas views:

1. Gerente vê os valores da análise no widget "Resultado do mês" (decisão
   explícita do usuário) — o payload do viewmodel do Gerente continua sem
   nenhuma chave proibida e o Comprador continua sem NADA disso.
2. Menu de Cadastros (Fornecedores, Categorias, Centros de Custo) para os
   perfis que abrem essas views, com o MESMO gate delas; estado ativo e
   breadcrumbs; nenhum link do menu dá 403, nem com RBAC aditivo.
3. Busca global: Análise Financeira, Manual do sistema e Receitas extras;
   cada atalho com o gate da view (nenhum resultado que dê 403).
4. Login exibe as mensagens do Django (ex.: "Conta criada com sucesso!" do
   Primeiro Acesso) e a linha "Esqueceu a senha?".
5. Filial com receitas extras (ou vínculo de usuário) não pode ser excluída.
6. NCC › Notificações: conteúdo do card dentro de `.nx-card-body`.
7. Dashboard do Proprietário: o KPI "Compras do mês" explica que soma
   aprovadas + aguardando aprovação (regra inalterada).
8. Dados de exemplo sem "estoque".

Rode com: python manage.py test core.tests_correcoes_producao
"""
import re
from datetime import date
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.test import Client, TestCase, override_settings
from django.urls import resolve, reverse

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from core.navegacao import _estrutura_por_perfil
from core.permissions import PERFIS_ANALISE_FINANCEIRA, PERFIS_GESTORES_FINANCEIROS
from core.tests_primeiro_acesso import TOKEN, realizar_primeiro_acesso
from core.views import _telas_pesquisaveis
from dashboard.viewmodels import CHAVES_PROIBIDAS_GERENTE, viewmodel_comprador, viewmodel_gerente
from empresas.models import Empresa
from filiais.forms import filial_possui_movimentacao
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, Receita, ReceitaExtra
from usuarios.models import Permissao, Usuario, UsuarioFilial

TERMOS_PROIBIDOS = ("None", "NaN", "Infinity", "Traceback (most recent", "Internal Server Error")
SENHA = "Teste!2026Forte"
_HREF = re.compile(r'href="(/[^"#?]*)')
_CSRF = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')


def _aside(html):
    return html.split('<aside class="nx-sidebar"', 1)[1].split("</aside>", 1)[0]


def _mobile(html):
    if 'class="nx-mobile-nav"' not in html:
        return ""
    return html.split('class="nx-mobile-nav"', 1)[1].split("</nav>", 1)[0]


def _limpo(testcase, resposta):
    html = _CSRF.sub(r"\1\2", resposta.content.decode("utf-8"))
    for termo in TERMOS_PROIBIDOS:
        testcase.assertNotIn(termo, html, f"'{termo}' vazou no HTML")
    return html


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class CenarioPrimeiroAcessoBase(TestCase):
    """Cenário real de produção: banco limpo + Primeiro Acesso + 1 usuário
    por perfil criado pelo administrador."""

    @classmethod
    def setUpTestData(cls):
        resposta = realizar_primeiro_acesso(Client())
        assert resposta.status_code == 302, f"Primeiro Acesso falhou: {resposta.content[:300]}"
        cls.empresa = Empresa.objects.get(cnpj="11222333000181")
        cls.filial = Filial.objects.get(empresa=cls.empresa)
        cls.proprietario = Usuario.objects.get(username="ana.proprietaria")

        def criar(username, perfil):
            return Usuario.objects.create_user(
                username=username, password=SENHA, perfil=perfil, empresa=cls.empresa, filial=cls.filial,
            )

        cls.gerente = criar("gerente.prod", Usuario.Perfil.GERENTE)
        cls.financeiro = criar("financeiro.prod", Usuario.Perfil.FINANCEIRO)
        cls.comprador = criar("comprador.prod", Usuario.Perfil.COMPRADOR)
        cls.todos = (cls.proprietario, cls.gerente, cls.financeiro, cls.comprador)

    def cliente(self, usuario):
        client = Client()
        client.force_login(usuario)
        return client

    def html(self, usuario, url, status=200):
        resposta = self.cliente(usuario).get(url)
        self.assertEqual(resposta.status_code, status, f"{usuario.username} GET {url}")
        return _limpo(self, resposta)

    def conceder(self, usuario, *codigos):
        for codigo in codigos:
            usuario.permissoes_individuais.add(Permissao.objects.get(codigo=codigo))


# ---------------------------------------------------------------------------
# 1. Gerente vê os valores da análise; Comprador continua sem nada
# ---------------------------------------------------------------------------

@override_settings(ALLOWED_HOSTS=["*"])
class GerenteVeValoresDaAnaliseTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        hoje = date.today()
        cls.empresa = Empresa.objects.create(nome="Farmácia Resultado", cnpj="71.000.000/0001-71")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Matriz Resultado")
        ConfiguracaoFinanceira.objects.create(empresa=cls.empresa, percentual_compras=Decimal("30"))
        Receita.objects.create(filial=cls.filial, mes=hoje.replace(day=1), faturamento=Decimal("80000.50"))
        ReceitaExtra.objects.create(
            filial=cls.filial, data=hoje, descricao="Convênio PBM sigiloso", valor=Decimal("1234.00"),
            categoria=ReceitaExtra.Categoria.CONVENIOS,
        )
        CustoFixo.objects.create(filial=cls.filial, descricao="Aluguel da loja", valor=Decimal("5000.00"),
                                 dia_vencimento=5)

        def criar(username, perfil):
            return Usuario.objects.create_user(
                username=username, password="x", perfil=perfil, empresa=cls.empresa, filial=cls.filial,
            )

        cls.gerente = criar("ger_resultado", Usuario.Perfil.GERENTE)
        cls.comprador = criar("comp_resultado", Usuario.Perfil.COMPRADOR)
        cls.financeiro = criar("fin_resultado", Usuario.Perfil.FINANCEIRO)

    def get(self, usuario, url="/"):
        client = Client()
        client.force_login(usuario)
        resposta = client.get(url)
        self.assertEqual(resposta.status_code, 200, url)
        return resposta, _limpo(self, resposta)

    def test_widget_do_gerente_mostra_receita_despesas_e_resultado_em_reais(self):
        resposta, html = self.get(self.gerente)
        widget = resposta.context["resultado_mes"]
        self.assertTrue(widget["detalhar_valores"])
        self.assertEqual(widget["receita"], Decimal("81234.50"))
        trecho = html.split('data-an-widget="resultado-mes"', 1)[1].split("</table>", 1)[0]
        self.assertIn('data-an-widget-valor="receita">R$ 81.234,50', trecho)
        self.assertIn(f'data-an-widget-valor="despesas">{widget["despesas_fmt"]}', trecho)
        self.assertIn(f'data-an-widget-valor="resultado">{widget["resultado_fmt"]}', trecho)
        self.assertIn("Margem", trecho)
        self.assertIn("Ver análise completa", trecho)
        # Mesmo número do widget do Financeiro (mesma fonte da DRE).
        resposta_fin, _ = self.get(self.financeiro)
        self.assertEqual(resposta_fin.context["resultado_mes"]["resultado"], widget["resultado"])

    def test_contrato_de_chaves_do_viewmodel_do_gerente_continua_intacto(self):
        self.assertEqual(set(viewmodel_gerente(self.gerente)) & CHAVES_PROIBIDAS_GERENTE, set())
        resposta, html = self.get(self.gerente)
        # O widget vive numa chave de contexto SEPARADA do viewmodel.
        self.assertNotIn("resultado_mes", viewmodel_gerente(self.gerente))
        self.assertIn("resultado_mes", resposta.context)
        # Lançamentos individuais de receita nunca chegam ao painel.
        self.assertNotIn("Convênio PBM sigiloso", html)
        self.assertNotIn("1.234,00", html)

    def test_comprador_continua_sem_nada_da_analise(self):
        resposta, html = self.get(self.comprador)
        self.assertNotIn("resultado_mes", resposta.context)
        self.assertNotIn("resultado_mes", viewmodel_comprador(self.comprador))
        for termo in ("data-an-widget", "Resultado do mês", "Análise Financeira", "/financeiro/analise/",
                      "81.234", "80.000", "Faturamento", "Folha de Pagamento", "Aluguel",
                      "Capacidade mensal", "Meta Mensal", "Convênio PBM sigiloso"):
            self.assertNotIn(termo, html, f"'{termo}' vazou para o Comprador")


# ---------------------------------------------------------------------------
# 2. Menu de Cadastros com o gate idêntico ao das views
# ---------------------------------------------------------------------------

URLS_CADASTROS = {
    "compras:fornecedor_list": ("Fornecedores", "/compras/fornecedores/"),
    "cadastros:categoria_list": ("Categorias", "/cadastros/categorias/"),
    "cadastros:centrocusto_list": ("Centros de Custo", "/cadastros/centros-custo/"),
}
PAGINAS_CADASTROS = {
    "/compras/fornecedores/": "Fornecedores",
    "/compras/fornecedores/novo/": "Fornecedores",
    "/cadastros/categorias/": "Categorias",
    "/cadastros/categorias/nova/": "Categorias",
    "/cadastros/centros-custo/": "Centros de Custo",
    "/cadastros/centros-custo/novo/": "Centros de Custo",
}


class MenuCadastrosTestCase(CenarioPrimeiroAcessoBase):
    def _sublink_ativo(self, html, rotulo):
        self.assertRegex(html, r'class="nx-nav-sublink active"[^>]*>\s*' + re.escape(rotulo))

    def _grupo(self, html, grupo_id, aberto):
        self.assertRegex(html, r'aria-expanded="%s"[^>]*aria-controls="nxGrupo-%s"'
                         % ("true" if aberto else "false", grupo_id))

    def test_gate_dos_itens_e_identico_ao_perfis_permitidos_das_views(self):
        encontrados = {}
        for perfil, entradas in _estrutura_por_perfil().items():
            for entrada in entradas:
                itens = [entrada] if entrada.get("link_unico") else entrada["itens"]
                for item in itens:
                    if item["url_name"] in URLS_CADASTROS:
                        encontrados.setdefault(item["url_name"], []).append(perfil)
                        view = resolve(reverse(item["url_name"])).func.view_class
                        self.assertEqual(set(item["perfis"]), set(view.perfis_permitidos), item["url_name"])
                        self.assertEqual(set(item["perfis"]), set(PERFIS_GESTORES_FINANCEIROS))
                        self.assertIsNone(item["permissao"])
        for url_name in URLS_CADASTROS:
            self.assertEqual(sorted(encontrados[url_name]), ["financeiro", "proprietario"], url_name)

    def test_proprietario_ve_cadastros_no_grupo_compras_com_6_entradas_de_1o_nivel(self):
        aside = _aside(self.html(self.proprietario, "/"))
        self.assertEqual(aside.count("nx-nav-grupo-btn"), 5)
        for rotulo in ("Início", "Compras", "Financeiro", "Gestão", "Relatórios", "Configurações"):
            self.assertIn(f'<span class="nx-nav-label">{rotulo}</span>', aside)
        grupo_compras = aside.split('id="nxGrupo-compras"', 1)[1].split("</ul>", 1)[0]
        for rotulo, href in URLS_CADASTROS.values():
            self.assertIn(f'href="{href}"', grupo_compras)
            self.assertIn(rotulo, grupo_compras)
            self.assertEqual(aside.count(f'href="{href}"'), 1)

    def test_financeiro_ve_cadastros_dentro_do_unico_grupo(self):
        aside = _aside(self.html(self.financeiro, "/"))
        self.assertEqual(aside.count("nx-nav-grupo-btn"), 1)
        grupo = aside.split('id="nxGrupo-planejamento"', 1)[1].split("</ul>", 1)[0]
        for rotulo, href in URLS_CADASTROS.values():
            self.assertIn(f'href="{href}"', grupo)
            self.assertEqual(aside.count(f'href="{href}"'), 1)

    def test_gerente_e_comprador_nao_recebem_links_de_cadastro(self):
        for usuario in (self.gerente, self.comprador):
            html = self.html(usuario, "/")
            for _rotulo, href in URLS_CADASTROS.values():
                self.assertNotIn(f'href="{href}"', _aside(html) + _mobile(html), usuario.username)
                self.assertEqual(self.cliente(usuario).get(href).status_code, 403)

    def test_rbac_cadastros_gerenciar_nao_abre_item_nem_view_por_perfil(self):
        for usuario in (self.gerente, self.comprador):
            self.conceder(usuario, "cadastros.gerenciar")
            aside = _aside(self.html(usuario, "/"))
            for _rotulo, href in URLS_CADASTROS.values():
                self.assertNotIn(f'href="{href}"', aside)
                self.assertEqual(self.cliente(usuario).get(href).status_code, 403)

    def test_estado_ativo_e_grupo_aberto_nas_paginas_de_cadastro(self):
        for url, rotulo in PAGINAS_CADASTROS.items():
            html = self.html(self.proprietario, url)
            self._grupo(html, "compras", aberto=True)
            self._grupo(html, "configuracoes", aberto=False)
            self._sublink_ativo(html, rotulo)
            self.assertEqual(len(re.findall(r'class="nx-nav-sublink active"', html)), 1, url)

            html = self.html(self.financeiro, url)
            self._grupo(html, "planejamento", aberto=True)
            self._sublink_ativo(html, rotulo)
            self.assertEqual(len(re.findall(r'class="nx-nav-sublink active"', html)), 1, url)

    def test_breadcrumbs_dos_formularios_de_cadastro(self):
        casos = {
            "/compras/fornecedores/novo/": ("Novo Fornecedor", "/compras/fornecedores/"),
            "/cadastros/categorias/nova/": ("Nova Categoria", "/cadastros/categorias/"),
            "/cadastros/centros-custo/novo/": ("Novo Centro de Custo", "/cadastros/centros-custo/"),
        }
        for url, (atual, pai) in casos.items():
            html = self.html(self.financeiro, url)
            trecho = html.split('aria-label="Navegação estrutural"', 1)[1].split("</nav>", 1)[0]
            self.assertIn('href="/"', trecho)
            self.assertIn(f'href="{pai}"', trecho)
            self.assertRegex(trecho, r'aria-current="page">\s*<span>' + re.escape(atual))

    def test_nenhum_link_do_menu_da_403_para_nenhum_perfil(self):
        for usuario in self.todos:
            html = self.html(usuario, "/")
            hrefs = set(_HREF.findall(_aside(html) + _mobile(html)))
            self.assertTrue(hrefs, usuario.username)
            client = self.cliente(usuario)
            for href in sorted(hrefs):
                status = client.get(href).status_code
                self.assertIn(status, (200, 302), f"{usuario.username}: menu leva a {href} ({status})")

    def test_nenhum_link_do_menu_da_403_com_rbac_aditivo(self):
        extras = ("financeiro.ver", "cadastros.gerenciar", "agenda.ver", "timeline.ver", "relatorios.ver")
        for usuario in (self.gerente, self.comprador):
            self.conceder(usuario, *extras)
            html = self.html(usuario, "/")
            client = self.cliente(usuario)
            for href in sorted(set(_HREF.findall(_aside(html) + _mobile(html)))):
                status = client.get(href).status_code
                self.assertIn(status, (200, 302), f"{usuario.username} (RBAC): menu leva a {href} ({status})")


# ---------------------------------------------------------------------------
# 3. Busca global
# ---------------------------------------------------------------------------

class BuscaGlobalTestCase(CenarioPrimeiroAcessoBase):
    def titulos(self, usuario, termo):
        resposta = self.cliente(usuario).get("/buscar/", {"q": termo})
        self.assertEqual(resposta.status_code, 200)
        _limpo(self, resposta)
        return [t["titulo"] for t in resposta.context["resultados"]["telas"]]

    def test_analise_financeira_para_os_perfis_da_analise(self):
        for usuario in self.todos:
            achou = "Análise Financeira" in self.titulos(usuario, "análise")
            self.assertEqual(achou, usuario.perfil in PERFIS_ANALISE_FINANCEIRA, usuario.username)
            self.assertEqual("Análise Financeira" in self.titulos(usuario, "dre"),
                             usuario.perfil in PERFIS_ANALISE_FINANCEIRA)

    def test_manual_do_sistema_para_todos(self):
        for usuario in self.todos:
            self.assertIn("Manual do sistema", self.titulos(usuario, "manual"), usuario.username)
            self.assertEqual(self.cliente(usuario).get("/ajuda/").status_code, 200)

    def test_receitas_extras_com_o_gate_da_view(self):
        for usuario in self.todos:
            achou = "Receitas extras" in self.titulos(usuario, "extras")
            self.assertEqual(achou, usuario.perfil in PERFIS_GESTORES_FINANCEIROS, usuario.username)

    def test_gerente_com_rbac_financeiro_nao_ve_atalhos_de_views_por_perfil(self):
        """Receitas/Custos/Cadastros são por PERFIL: o RBAC aditivo
        (financeiro.ver, cadastros.gerenciar) não abre as views — então o
        atalho também não pode aparecer (antes aparecia e dava 403)."""
        self.conceder(self.gerente, "financeiro.ver", "cadastros.gerenciar")
        titulos = [t[0] for t in _telas_pesquisaveis(self.gerente)]
        for proibido in ("Receitas", "Receitas extras", "Custos Fixos", "Custos Variáveis",
                         "Fornecedores", "Categorias", "Centros de Custo"):
            self.assertNotIn(proibido, titulos)
        # O que é por permissão continua abrindo junto com a view.
        self.assertIn("Planejamento Financeiro", titulos)
        self.assertEqual(self.cliente(self.gerente).get("/financeiro/planejamento/").status_code, 200)

    def test_nenhum_atalho_da_busca_da_403(self):
        cenarios = [(u, ()) for u in self.todos] + [
            (self.gerente, ("financeiro.ver", "cadastros.gerenciar", "agenda.ver", "compras.lancar")),
            (self.comprador, ("financeiro.ver", "cadastros.gerenciar", "agenda.ver", "timeline.ver")),
        ]
        for usuario, codigos in cenarios:
            self.conceder(usuario, *codigos)
            client = self.cliente(usuario)
            for titulo, url, _icone, _chaves, _ok in _telas_pesquisaveis(usuario):
                status = client.get(url).status_code
                self.assertIn(status, (200, 302), f"{usuario.username} {codigos}: '{titulo}' {url} ({status})")


# ---------------------------------------------------------------------------
# 4. Login: mensagens do Django + "Esqueceu a senha?"
# ---------------------------------------------------------------------------

@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"], DEMO_MODE=False)
class LoginMensagensTestCase(TestCase):
    def test_conta_criada_aparece_no_login_e_nao_depois_no_dashboard(self):
        client = Client()
        resposta = realizar_primeiro_acesso(client)
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(resposta["Location"], reverse("login"))
        html = _limpo(self, client.get(resposta["Location"]))
        self.assertIn("Conta criada com sucesso! Faça login para continuar.", html)
        self.assertRegex(html, r'class="alert alert-success[^"]*"[^>]*data-nx-login-mensagem')
        # A mensagem é consumida no login: não reaparece depois de entrar.
        self.assertTrue(client.login(username="ana.proprietaria", password="S3nhaForteEUnica!2026"))
        self.assertNotIn("Conta criada com sucesso", client.get("/").content.decode("utf-8"))

    def test_esqueceu_a_senha_e_sem_credencial_demo(self):
        html = _limpo(self, Client().get("/accounts/login/"))
        self.assertIn("Esqueceu a senha? Fale com o administrador da sua empresa.", html)
        self.assertNotIn("nexbuy123", html)
        self.assertNotIn("Usuários de demonstração", html)
        self.assertNotIn("data-nx-login-mensagem", html)  # sem mensagem pendente, nada de alerta vazio

    def test_senha_errada_continua_com_o_aviso_de_sempre(self):
        resposta = Client().post("/accounts/login/", {"username": "ninguem", "password": "errada"})
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("Usuário ou senha inválidos.", _limpo(self, resposta))


# ---------------------------------------------------------------------------
# 5. Filial com receitas extras não pode ser excluída
# ---------------------------------------------------------------------------

class FilialMovimentacaoTestCase(CenarioPrimeiroAcessoBase):
    def nova_filial(self, nome):
        return Filial.objects.create(empresa=self.empresa, nome=nome)

    def excluir(self, filial):
        return self.cliente(self.proprietario).post(f"/ncc/filiais/{filial.pk}/", {"excluir": "1"})

    def test_filial_so_com_receita_extra_nao_e_excluida_e_a_receita_sobrevive(self):
        filial = self.nova_filial("Filial Só Extras")
        extra = ReceitaExtra.objects.create(
            filial=filial, data=date.today(), descricao="Serviço farmacêutico", valor=Decimal("150.00"),
            categoria=ReceitaExtra.Categoria.SERVICOS,
        )
        self.assertTrue(filial_possui_movimentacao(filial))
        resposta = self.excluir(filial)
        self.assertEqual(resposta.status_code, 302)
        self.assertTrue(Filial.objects.filter(pk=filial.pk).exists())
        self.assertTrue(ReceitaExtra.objects.filter(pk=extra.pk).exists())
        html = _limpo(self, self.cliente(self.proprietario).get(f"/ncc/filiais/{filial.pk}/"))
        self.assertFalse(self.cliente(self.proprietario).get(f"/ncc/filiais/{filial.pk}/").context["pode_excluir"])
        self.assertNotIn("Excluir permanentemente", html)
        self.assertIn("não pode ser excluída", html)

    def test_filial_com_vinculo_de_usuario_nao_e_excluida(self):
        filial = self.nova_filial("Filial Vinculada")
        UsuarioFilial.objects.create(usuario=self.comprador, filial=filial)
        self.assertTrue(filial_possui_movimentacao(filial))
        self.excluir(filial)
        self.assertTrue(Filial.objects.filter(pk=filial.pk).exists())
        self.assertTrue(UsuarioFilial.objects.filter(filial=filial, usuario=self.comprador).exists())

    def test_filial_sem_nada_continua_podendo_ser_excluida(self):
        filial = self.nova_filial("Filial Vazia")
        self.assertFalse(filial_possui_movimentacao(filial))
        resposta = self.excluir(filial)
        self.assertRedirects(resposta, "/ncc/filiais/", fetch_redirect_response=False)
        self.assertFalse(Filial.objects.filter(pk=filial.pk).exists())

    def test_todas_as_relacoes_cascade_da_filial_estao_cobertas(self):
        """Trava de regressão: toda relação nova com CASCADE para a Filial
        precisa entrar em `filial_possui_movimentacao` (senão a exclusão
        apaga registros em silêncio)."""
        cobertas = {"usuarios", "vinculos_usuario", "compras", "provisoes", "receitas",
                    "receitas_extras", "custos_fixos", "custos_variaveis"}
        cascade = {
            rel.get_accessor_name() for rel in Filial._meta.related_objects
            if rel.on_delete.__name__ == "CASCADE"
        }
        self.assertEqual(cascade - cobertas, set(), "relação CASCADE nova sem bloqueio de exclusão")


# ---------------------------------------------------------------------------
# 6. NCC › Notificações com .nx-card-body
# ---------------------------------------------------------------------------

class NotificacoesNccTestCase(CenarioPrimeiroAcessoBase):
    def test_conteudo_do_card_fica_dentro_do_card_body(self):
        html = self.html(self.proprietario, "/ncc/notificacoes/")
        self.assertRegex(
            html, r'<div class="nx-card nx-card-w-md">\s*<div class="nx-card-body">\s*<h2 class="nx-card-title'
        )

    def test_so_o_canal_que_existe_sem_prometer_integracoes_fora_do_escopo(self):
        """Crítico de UX/escopo (rodada 1): escopo acordado = só o DDA como
        integração futura. A tela e o card do Centro de Configurações não
        prometem mais Push/WhatsApp/E-mail nem mostram caminho de código."""
        html = self.html(self.proprietario, "/ncc/notificacoes/")
        self.assertIn("Sistema (sino no topo)", html)
        for termo in ("WhatsApp", "Push", "Preparado", "canais.py", "quando o provedor for contratado"):
            self.assertNotIn(termo, html)
        home = self.html(self.proprietario, "/ncc/")
        card = home.split('href="/ncc/notificacoes/" class="nx-card', 1)[1].split("</a>", 1)[0]
        for termo in ("WhatsApp", "Push", "E-mail"):
            self.assertNotIn(termo, card)


# ---------------------------------------------------------------------------
# 7. KPI "Compras do mês" explica a regra (aprovadas + aguardando)
# ---------------------------------------------------------------------------

class KpiComprasDoMesTestCase(CenarioPrimeiroAcessoBase):
    def test_rotulo_explicita_aprovadas_mais_pendentes_sem_mudar_a_regra(self):
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Distribuidora KPI")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos KPI")
        for valor, status in ((Decimal("1000.00"), Compra.Status.APROVADA), (Decimal("500.00"), Compra.Status.PENDENTE)):
            Compra.objects.create(
                empresa=self.empresa, filial=self.filial, fornecedor=fornecedor, usuario=self.comprador,
                valor=valor, categoria=categoria, data_compra=date.today(), status=status,
            )
        resposta = self.cliente(self.proprietario).get("/")
        html = _limpo(self, resposta)
        self.assertEqual(resposta.context["kpis"]["compras_mes"], Decimal("1500.00"))  # regra intacta
        self.assertRegex(html, r'data-nx-compras-mes-regra[^>]*>aprovadas \+ aguardando aprovação<')


# ---------------------------------------------------------------------------
# 8. Dados de exemplo sem "estoque"
# ---------------------------------------------------------------------------

class SeedsSemEstoqueTestCase(TestCase):
    def test_textos_dos_seeds(self):
        pasta = Path(settings.BASE_DIR) / "core" / "management" / "commands"
        seed_demo = (pasta / "seed_demo.py").read_text(encoding="utf-8")
        seed_dados = (pasta / "seed_dados.py").read_text(encoding="utf-8")
        self.assertNotIn("Reforço de estoque", seed_demo)
        self.assertIn("Reforço de compra para campanha de inverno", seed_demo)
        self.assertNotIn("Reposição de Estoque", seed_dados)
        self.assertIn("Reposição Extra de Mercadorias", seed_dados)
