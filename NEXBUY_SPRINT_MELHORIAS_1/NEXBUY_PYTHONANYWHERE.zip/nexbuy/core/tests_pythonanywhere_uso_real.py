"""Uso real no PythonAnywhere — scripts de deploy/pythonanywhere/ e o guia
docs/PYTHONANYWHERE_USO_REAL.md.

A cliente pediu para testar com dados reais no mesmo site grátis: sai a
demonstração (empresa fictícia de CNPJ 98765432..., os 6 usuários demo_*),
entra um banco vazio com o Primeiro Acesso da proprietária. Aqui:

1. Estáticos: arquivos novos, LF, shebang, `bash -n`, nenhum segredo, os
   nomes combinados com o settings (NEXBUY_USO_REAL, BACKUP_DIARIO*), o
   gerador do zip levando tudo, o guia e os apontamentos da documentação.
2. Execução REAL no Git Bash, num HOME simulado (pasta temporária com o
   código descompactado do próprio zip, o virtualenv do projeto e
   --sem-wsgi; NEXBUY_PULAR_PIP=1 pula só o "pip install"):
   demonstração -> ativar_uso_real.sh --sim -> banco vazio, .env certo,
   token mostrado uma vez e em nenhum arquivo além do .env, cópia
   demonstracao_final_*; repetir não apaga nada; --novo-token; Primeiro
   Acesso de verdade (test Client); depois disso ativar/preparar/atualizar
   nunca apagam nem rodam o seed e o token sai do .env; opções da
   demonstração recusadas; backup e restauração.

O banco "de demonstração" daqui é montado direto (empresa 98765432000198 e
os 6 usuários, sem o seed_demo, que leva minutos): os scripts reconhecem a
demonstração pelo prefixo do CNPJ — e um teste estático garante que o
seed_demo só cria empresas com esse prefixo. O caminho com o seed completo
(preparar.sh --gerar-senha -> ativar_uso_real.sh) foi conferido à mão.

Sem o Git Bash (Windows) ou o bash (Linux), os testes de execução são
pulados.
"""
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import zipfile
from contextlib import closing
from pathlib import Path, PurePosixPath

from django.test import SimpleTestCase

from core.tests_pythonanywhere_demo import (
    BASE_DIR, PA_DIR, SEIS, SENHA_PUBLICA, _bash, _modulo_gerar_pacote, _parece_segredo,
)

GUIA = BASE_DIR / "docs" / "PYTHONANYWHERE_USO_REAL.md"
GUIA_DEMO = BASE_DIR / "docs" / "DEPLOY_PYTHONANYWHERE_DEMO.md"
SCRIPTS_NOVOS = ("ativar_uso_real.sh", "atualizar.sh", "backup.sh", "restaurar.sh", "voltar_demonstracao.sh")
TOCADOS = (
    *(PA_DIR / nome for nome in (
        *SCRIPTS_NOVOS, "_comum_pa.sh", "preparar.sh", "atualizar_demo.sh", "backup_demo.sh",
        "gerar_pacote.py", "nexbuy.env.pythonanywhere.exemplo",
    )),
    GUIA, GUIA_DEMO, BASE_DIR / "README.md", Path(__file__),
)
DOMINIO = "nexbuy-teste.invalid"  # .invalid nunca resolve: nenhuma rede, nem por engano
CNPJ_REAL = "11222333000181"
SEM_BASH = "bash não encontrado (no Windows: Git Bash em C:\\Program Files\\Git\\bin\\bash.exe)"


def _ler(caminho):
    return Path(caminho).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# 1. Estáticos
# ---------------------------------------------------------------------------


class ArquivosUsoRealTestCase(SimpleTestCase):
    def test_arquivos_novos_lf_sem_bom_shebang_e_modo_estrito(self):
        for nome in SCRIPTS_NOVOS:
            with self.subTest(script=nome):
                bruto = (PA_DIR / nome).read_bytes()
                self.assertNotIn(b"\r", bruto)
                self.assertFalse(bruto.startswith(b"\xef\xbb\xbf"))
                texto = bruto.decode("utf-8")
                self.assertTrue(texto.startswith("#!/usr/bin/env bash\n"))
                self.assertIn("set -euo pipefail", texto)
                self.assertIn('. "$SCRIPT_DIR/_comum_pa.sh"', texto)
        for caminho in (GUIA, GUIA_DEMO):
            self.assertNotIn(b"\r", caminho.read_bytes())

    def test_bash_n(self):
        bash = _bash()
        if bash is None:
            self.skipTest(SEM_BASH)
        for script in sorted(PA_DIR.glob("*.sh")):
            with self.subTest(script=script.name):
                resultado = subprocess.run([bash, "-n", script.as_posix()], capture_output=True, text=True, timeout=60)
                self.assertEqual(resultado.returncode, 0, resultado.stderr)

    def test_nada_de_segredo_senha_publica_nem_marca_de_terceiro(self):
        for caminho in TOCADOS:
            texto = _ler(caminho)
            with self.subTest(arquivo=caminho.name):
                self.assertNotIn("pris" + "ma", texto.lower())
                # README: a senha pública da demo local já era citada (seção de
                # desenvolvimento) antes desta entrega; aqui só a linha nova.
                if caminho.name == "README.md":
                    texto = "\n".join(linha for linha in texto.splitlines() if "PYTHONANYWHERE_USO_REAL" in linha)
                if caminho != Path(__file__):
                    self.assertNotIn(SENHA_PUBLICA, texto)
                    self.assertEqual(_parece_segredo(texto), [])
                    self.assertNotRegex(texto, r"(?m)^\s*(export\s+)?ALLOW_SEED_IN_PRODUCTION=")
                    for nome, valor in re.findall(r"(?m)^\s*(SECRET_KEY|INITIAL_SETUP_TOKEN)=(.*)$", texto):
                        self.assertTrue(valor == "" or valor.startswith("$") or valor.startswith(".*/"), f"{nome}={valor!r}")

    def test_cache_do_env_le_igual_ao_python_dotenv_e_nunca_fica_velho(self):
        """carregar_env lê o .env inteiro numa chamada (CPU do console); o
        valor_env só usa o cache enquanto o arquivo não mudar."""
        bash = _bash()
        if bash is None:
            self.skipTest(SEM_BASH)
        pasta = Path(tempfile.mkdtemp(prefix="nexbuy_cache_"))
        self.addCleanup(shutil.rmtree, pasta, True)
        (pasta / "um.env").write_bytes(
            b'DEBUG=False\nexport DEBUG=True\nA = "valor com espaco" # c\nB=x\\y\\tz\nC=\n'
        )
        corpo = (
            'ENV_FILE="$PASTA/um.env"\n'
            "carregar_env\n"
            'env_em_cache && echo "CACHE sim" || echo "CACHE nao"\n'
            'echo "COM [$(valor_env DEBUG)] [$(valor_env A)] [$(valor_env B)] [$(valor_env C pc)] [$(valor_env Z pz)]"\n'
            '_ENV_CACHE_ARQUIVO=""\n'
            'echo "SEM [$(valor_env DEBUG)] [$(valor_env A)] [$(valor_env B)] [$(valor_env C pc)] [$(valor_env Z pz)]"\n'
            "carregar_env\n"
            "printf 'DEBUG=False\\n' >> \"$ENV_FILE\"\n"
            'env_em_cache && echo "MUDOU sim" || echo "MUDOU nao"\n'
            'echo "DEPOIS [$(valor_env DEBUG)]"\n'
            "gravar_no_env NOVO=1\n"
            'env_em_cache && echo "GRAVOU sim" || echo "GRAVOU nao"\n'
            'echo "NOVO [$(valor_env NOVO)]"\n'
        )
        script = "set -euo pipefail\n" f"SCRIPT_DIR='{PA_DIR.as_posix()}'\n" '. "$SCRIPT_DIR/_comum_pa.sh"\n' + corpo
        venv = Path(sys.executable).resolve().parent.parent
        ambiente = {**os.environ, "NEXBUY_HOME": pasta.as_posix(), "NEXBUY_VENV": venv.as_posix(),
                    "PASTA": pasta.as_posix(), "PYTHONIOENCODING": "utf-8"}
        resultado = subprocess.run([bash, "-c", script], capture_output=True, text=True, encoding="utf-8",
                                   timeout=120, env=ambiente)
        self.assertEqual(resultado.returncode, 0, resultado.stderr)
        linhas = resultado.stdout.splitlines()
        esperado = "[True] [valor com espaco] [x\\y\\tz] [pc] [pz]"
        self.assertEqual(linhas[:3], ["CACHE sim", f"COM {esperado}", f"SEM {esperado}"])
        self.assertEqual(linhas[3:], ["MUDOU nao", "DEPOIS [False]", "GRAVOU sim", "NOVO [1]"])

    def test_nomes_combinados_com_o_settings_e_o_backup_diario(self):
        ativar = _ler(PA_DIR / "ativar_uso_real.sh")
        bloco = ativar.split("gravar_no_env DEMO_MODE=False", 1)[1].split("\nok ", 1)[0]
        for trecho in ("DEMO_EXIBIR_SENHA=False", "NEXBUY_USO_REAL=True", '"INITIAL_SETUP_TOKEN=$TOKEN_NOVO"',
                       "BACKUP_DIARIO=True", '"BACKUP_DIARIO_DIR=$BACKUP_DIR"', "BACKUP_DIARIO_MANTER=14"):
            self.assertIn(trecho, bloco)
        comum = _ler(PA_DIR / "_comum_pa.sh")
        self.assertIn('BACKUP_DIR="$HOME_BASE/nexbuy_backups"', comum)
        self.assertIn("env_ligado NEXBUY_USO_REAL", comum)
        self.assertIn("secrets.token_urlsafe(32)", comum)
        for variavel in ("NEXBUY_USO_REAL", "BACKUP_DIARIO", "BACKUP_DIARIO_DIR", "BACKUP_DIARIO_MANTER"):
            self.assertRegex(comum, rf"(?s)\nunset .*\b{variavel}\b")
        # Contrato com o settings.py (o outro lado do combinado).
        settings_py = _ler(BASE_DIR / "nexbuy" / "settings.py")
        self.assertIn('env_bool("NEXBUY_USO_REAL", False)', settings_py)
        for variavel in ('"BACKUP_DIARIO"', '"BACKUP_DIARIO_DIR"', '"BACKUP_DIARIO_MANTER"'):
            self.assertIn(variavel, settings_py)

    def test_backup_manual_nunca_apaga_diario_nem_demonstracao_final(self):
        backup = _ler(PA_DIR / "backup.sh")
        self.assertIn("MANTER=5", backup)
        self.assertIn("MANTER=10", backup)
        self.assertIn('COPIAS=("$BACKUP_DIR"/nexbuy_*.sqlite3)', backup)
        linhas_rm = [linha for linha in backup.splitlines() if re.search(r"\brm\b", linha) and not linha.strip().startswith("#")]
        self.assertTrue(linhas_rm)
        for linha in linhas_rm:
            self.assertNotIn("diario", linha)
            self.assertNotIn("demonstracao_final", linha)
        for nome in ("backup_demo.sh", "atualizar_demo.sh"):
            self.assertIn('exec bash "$SCRIPT_DIR/', _ler(PA_DIR / nome))

    def test_ativar_na_ordem_certa_e_token_so_no_env_e_na_tela(self):
        ativar = _ler(PA_DIR / "ativar_uso_real.sh")
        conversao = ativar.split('etapa "3/8" "Dependências (antes de qualquer mudança)"', 1)[1]
        ordem = ["instalar_dependencias", 'digite APAGAR', "backup.sh\" --destino", "export SQLITE_PATH=\"$NOVO\"",
                 "copiar_banco_por_cima \"$NOVO\" \"$BANCO\"", "mv \"$MIDIA\" \"$ARQUIVO/media\"",
                 "gerar_token", "gravar_no_env DEMO_MODE=False", "collectstatic", "recarregar_e_conferir",
                 "mostrar_token_primeiro_acesso \"$TOKEN_NOVO\""]
        posicoes = [conversao.index(trecho) for trecho in ordem]
        self.assertEqual(posicoes, sorted(posicoes))
        self.assertIn('[[ "$RESPOSTA" == "APAGAR" ]]', ativar)
        # O token só passa por variável do bash: nunca por echo/tee/log/argumento.
        for linha in ativar.splitlines():
            if "TOKEN_NOVO" in linha and not linha.strip().startswith("#"):
                self.assertRegex(linha.strip(), r'^(TOKEN_NOVO="\$\(gerar_token\)"|TOKEN_NOVO=""|"INITIAL_SETUP_TOKEN=\$TOKEN_NOVO"|'
                                 r'gravar_no_env "INITIAL_SETUP_TOKEN=\$TOKEN_NOVO"|mostrar_token_primeiro_acesso "\$TOKEN_NOVO"|'
                                 r'# Gera.*)', linha)
        for proibido in ("tee ", "logger ", "set -x"):
            self.assertNotIn(proibido, ativar)
        # Nunca apaga banco com empresa real; nunca roda seed nem senha de demonstração.
        self.assertIn("QTD_EMPRESAS_REAIS > 0", ativar)
        self.assertNotIn("seed_demo", ativar.replace("seed_demo)", ""))
        self.assertNotIn("definir_senha_demo", ativar)

    def test_seed_demo_so_cria_empresas_com_o_prefixo_ficticio(self):
        """Os scripts reconhecem a demonstração pelo CNPJ 98765432...: se o
        seed passar a criar outra empresa, o ativar_uso_real.sh a trataria
        como real e (com razão) se recusaria a apagar."""
        seed = _ler(BASE_DIR / "core" / "management" / "commands" / "seed_demo.py")
        cnpjs = re.findall(r'Empresa\.objects\.(?:update_or_create|get_or_create|create)\(\s*cnpj="([\d./-]+)"', seed)
        self.assertGreaterEqual(len(cnpjs), 2)
        for cnpj in cnpjs:
            self.assertTrue(re.sub(r"\D", "", cnpj).startswith("98765432"), cnpj)
        self.assertIn('PREFIXO_DEMO = "98765432"', _ler(PA_DIR / "_comum_pa.sh"))

    def test_preparar_e_atualizar_pulam_a_demonstracao_no_uso_real(self):
        preparar = _ler(PA_DIR / "preparar.sh")
        atualizar = _ler(PA_DIR / "atualizar.sh")
        for texto, nome in ((preparar, "preparar.sh"), (atualizar, "atualizar.sh")):
            with self.subTest(script=nome):
                self.assertIn("uso_real_no_env", texto)
                self.assertIn("QTD_EMPRESAS_REAIS > 0", texto)
                self.assertIn("recusar_opcao_de_demonstracao", texto)
                self.assertIn("conferir_token_primeiro_acesso", texto)
                self.assertIn("conferir_backup_diario", texto)
        for opcao in ("--gerar-senha", "--senha-individual", "--trocar-senha", "--recriar-cenario"):
            self.assertIn(f'"{opcao.upper().lstrip("-").replace("-", "_")}:{opcao}"', preparar)
        self.assertIn('recusar_opcao_de_demonstracao "--renovar-cenario" "atualizar.sh"', atualizar)
        self.assertIn('recusar_opcao_de_demonstracao "--gerar-senha" "atualizar.sh"', atualizar)
        # Resumo sem a abertura da apresentação no uso real.
        resumo = preparar.split("# RESUMO", 1)[1]
        self.assertLess(resumo.index('if [[ "$USO_REAL" == "1" ]]; then'), resumo.index("Abertura da apresentação"))
        # Última barreira do seed.
        comum = _ler(PA_DIR / "_comum_pa.sh")
        barreira = comum.split("manage_seed() {", 1)[1].split("\n}", 1)[0]
        self.assertLess(barreira.index("uso_real_no_env"), barreira.index("ALLOW_SEED_IN_PRODUCTION=True"))
        self.assertLess(barreira.index("QTD_EMPRESAS_REAIS > 0"), barreira.index("ALLOW_SEED_IN_PRODUCTION=True"))

    def test_gerar_pacote_leva_os_arquivos_novos(self):
        modulo = _modulo_gerar_pacote()
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as pasta:
            destino = Path(pasta) / "NEXBUY_PYTHONANYWHERE.zip"
            modulo.gerar(BASE_DIR, destino, usar_git=False)
            with zipfile.ZipFile(destino) as pacote:
                nomes = set(pacote.namelist())
                for nome in (*SCRIPTS_NOVOS, "atualizar_demo.sh", "backup_demo.sh"):
                    info = pacote.getinfo(f"nexbuy/deploy/pythonanywhere/{nome}")
                    self.assertEqual((info.external_attr >> 16) & 0o777, 0o755, nome)
                self.assertIn("nexbuy/docs/PYTHONANYWHERE_USO_REAL.md", nomes)
        # Com git, um script novo esquecido fora do "git add" recusa o pacote.
        arquivos = modulo.listar_pela_arvore(BASE_DIR)
        sem_ativar = [a for a in arquivos if str(a) != "deploy/pythonanywhere/ativar_uso_real.sh"]
        with self.assertRaisesRegex(modulo.PacoteRecusado, "ativar_uso_real.sh"):
            modulo.verificar_essenciais(BASE_DIR, sem_ativar)
        modulo.verificar_essenciais(BASE_DIR, arquivos)
        self.assertIn(PurePosixPath("docs/PYTHONANYWHERE_USO_REAL.md"), arquivos)

    def test_gitattributes_mantem_sh_em_lf(self):
        atributos = _ler(BASE_DIR / ".gitattributes")
        self.assertRegex(atributos, r"(?m)^\*\.sh\s+text eol=lf$")
        self.assertRegex(atributos, r"(?m)^deploy/\*\*\s+text eol=lf$")

    def test_voltar_demonstracao_confere_tudo_antes_de_mexer(self):
        """A volta para a demonstração era uma receita no guia que mexia no
        .env e apagava os uploads ANTES de qualquer conferência. Agora é um
        script: recusa banco com dado real antes de tocar em qualquer coisa
        e MOVE os uploads (nunca rm -rf)."""
        voltar = _ler(PA_DIR / "voltar_demonstracao.sh")
        corpo = voltar.split('etapa "1/6"', 1)[1]
        ordem = ["exigir_instalacao", "if banco_tem_dados_reais; then", "conferir_banco_do_nexbuy",
                 '[[ "$RESPOSTA" == "VOLTAR" ]]', 'bash "$SCRIPT_DIR/backup.sh"',
                 'copiar_banco_por_cima "$COPIA_ORIGEM" "$BANCO"', 'mv "$MIDIA" "$GUARDA_MIDIA"',
                 'cp -R "$PASTA/media" "$MIDIA"', "gravar_no_env NEXBUY_USO_REAL=False", 'atualizar.sh"']
        posicoes = [corpo.index(trecho) for trecho in ordem]
        self.assertEqual(posicoes, sorted(posicoes))
        self.assertNotRegex(voltar, r"(?m)^[^#]*\brm -r")
        self.assertNotIn("sed -i", voltar)
        # Nada de seed nem de senha aqui: as senhas da demonstração guardada voltam com ela.
        self.assertNotIn("seed_demo", voltar)
        self.assertNotIn("definir_senha_demo", voltar)

    def test_trava_do_token_e_explicacao_do_w008_no_ativar(self):
        ativar = _ler(PA_DIR / "ativar_uso_real.sh")
        # O quadro do token aparece mesmo se o script parar depois de gravá-lo.
        self.assertIn("trap mostrar_token_se_parou EXIT", ativar)
        self.assertLess(ativar.index("trap mostrar_token_se_parou EXIT"), ativar.index('etapa "1/8"'))
        etapa7 = ativar.split('etapa "7/8"', 1)[1].split('etapa "8/8"', 1)[0]
        self.assertLess(etapa7.index("gravar_no_env DEMO_MODE=False"), etapa7.index("TOKEN_GRAVADO=1"))
        final = ativar.split('etapa "8/8"', 1)[1]
        self.assertLess(final.index("TOKEN_GRAVADO=0"), final.index('mostrar_token_primeiro_acesso "$TOKEN_NOVO"'))
        self.assertLess(final.index("check --deploy"), final.index("explicar_aviso_w008"))
        self.assertIn("explicar_aviso_w008", _ler(PA_DIR / "preparar.sh"))
        self.assertIn("security.W008", _ler(PA_DIR / "_comum_pa.sh"))


class GuiaUsoRealTestCase(SimpleTestCase):
    def test_guia_cobre_o_caminho_inteiro(self):
        texto = _ler(GUIA)
        for trecho in (
            "gerar_pacote.py", "Upload a file", "mv nexbuy nexbuy_antigo", "unzip -o NEXBUY_PYTHONANYWHERE.zip",
            "cp ../nexbuy_antigo/.env .", "chmod 600 .env", "bash deploy/pythonanywhere/ativar_uso_real.sh",
            "APAGAR", "--novo-token", "clear", "/primeiro-acesso/", "/demo/apresentacao/",
            "demonstracao_final_AAAA-MM-DD_HHMM", "NEXBUY_USO_REAL=True", "BACKUP_DIARIO=True",
            "diario_AAAA-MM-DD.sqlite3", "Run until 1 month from today", "3 semanas",
            "bash deploy/pythonanywhere/atualizar.sh", "bash deploy/pythonanywhere/backup.sh",
            "bash deploy/pythonanywhere/restaurar.sh", "RESTAURAR", "Checklist de Implantação",
            "Empresas e Filiais", "Usuários e Permissões", "Gerar nova senha provisória", "Meu Perfil",
            "Receitas", "Custos fixos", "Capacidade Financeira", "Calendário Operacional",
            "Compradores e Limites", "Assistente de Implantação", "Simulador", "FEATURE_DDA=False",
            "Desktop", "EUA", "LGPD", "6 meses", "512 MB", "Nenhum dado de cliente ou paciente",
            "nomes, e-mails e logins da equipe", "valores financeiros", "servidor definitivo",
            "docs/OPERACAO_BACKUP_E_ATUALIZACAO.md", "restaurar_backup.sh", "docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md",
            "docs/DEPLOY_HOSTINGER_GITHUB.md", "changepassword", "manage.py backup_diario", "aba **Files**",
        ):
            with self.subTest(trecho=trecho):
                self.assertIn(trecho, texto)
        for username in SEIS:
            self.assertIn(f"`{username}`", texto)
        partes = re.findall(r"(?m)^## (\d+)\. ", texto)
        self.assertEqual([int(p) for p in partes], list(range(16)))

    def test_guia_sem_segredo_nem_caminho_desta_maquina(self):
        texto = _ler(GUIA)
        self.assertNotIn(SENHA_PUBLICA, texto)
        self.assertNotRegex(texto, r"(?m)SECRET_KEY=\S")
        self.assertNotRegex(texto, r"INITIAL_SETUP_TOKEN=[A-Za-z0-9_-]")
        self.assertNotRegex(texto, r"[A-Z]:\\Users")
        self.assertEqual(_parece_segredo(texto), [])
        self.assertNotIn("ALLOW_SEED_IN_PRODUCTION", texto)
        for linha in texto.splitlines():
            comando = linha.strip().lstrip("-").strip().lstrip("`")
            if comando.startswith(("tail ", "curl ")):
                self.assertNotIn("<", linha, linha)

    def test_guia_volta_para_a_demonstracao_pelo_script_e_para_se_recusar(self):
        texto = _ler(GUIA)
        parte14 = texto.split("## 14. ", 1)[1].split("## 15. ", 1)[0]
        self.assertIn("bash deploy/pythonanywhere/voltar_demonstracao.sh", parte14)
        self.assertIn("PARE", parte14)
        self.assertIn("VOLTAR", parte14)
        self.assertIn("media_antes_da_volta_", parte14)
        # Nenhum comando que mexe no .env ou apaga uploads antes da conferência.
        for proibido in ("sed -i", "rm -rf", "restaurar.sh", "cp -r"):
            self.assertNotIn(proibido, parte14)

    def test_guia_cobre_empresa_na_demonstracao_token_perdido_e_mensagens(self):
        texto = _ler(GUIA)
        parte1 = texto.split("## 1. ", 1)[1].split("## 2. ", 1)[0]
        self.assertIn("--descartar-empresas-da-demonstracao", parte1)
        self.assertIn("Assistente de Implantação", parte1)
        self.assertIn("vp_atendente_beatriz", parte1)
        parte4 = texto.split("## 4. ", 1)[1].split("## 5. ", 1)[0]
        self.assertIn("O quadro com o token não apareceu", parte4)
        self.assertIn("--novo-token", parte4)
        self.assertNotIn("ele continua de\n  onde parou", parte4)
        parte12 = texto.split("## 12. ", 1)[1].split("## 13. ", 1)[0]
        for mensagem in ("O banco é a DEMONSTRAÇÃO com empresa cadastrada DENTRO dela", "O banco já é de USO REAL",
                         "faltou trazer o .env da pasta antiga", "Corrigido no .env: NEXBUY_USO_REAL=True",
                         "não é um caminho completo"):
            with self.subTest(mensagem=mensagem):
                self.assertIn(mensagem, parte12)
                # A mensagem citada no guia é a que os scripts mostram.
                scripts = "".join(_ler(PA_DIR / nome) for nome in ("_comum_pa.sh", "ativar_uso_real.sh"))
                self.assertIn(mensagem.split(": NEXBUY")[0], scripts)

    def test_documentos_apontam_para_o_guia(self):
        self.assertIn("docs/PYTHONANYWHERE_USO_REAL.md", _ler(BASE_DIR / "README.md"))
        demo = _ler(GUIA_DEMO)
        self.assertIn("docs/PYTHONANYWHERE_USO_REAL.md", demo[:1500])
        self.assertIn("docs/PYTHONANYWHERE_USO_REAL.md", _ler(PA_DIR / "ativar_uso_real.sh"))
        exemplo = _ler(PA_DIR / "nexbuy.env.pythonanywhere.exemplo")
        for variavel in ("NEXBUY_USO_REAL", "BACKUP_DIARIO", "BACKUP_DIARIO_DIR", "BACKUP_DIARIO_MANTER"):
            self.assertRegex(exemplo, rf"(?m)^#\s*{variavel}=")


# ---------------------------------------------------------------------------
# 2. Execução real no Git Bash, num HOME simulado
# ---------------------------------------------------------------------------

CURL_FALSO = r"""#!/usr/bin/env bash
# curl FALSO dos testes: nenhuma rede. Responde como um site em uso real.
url=""; formato=""; cabecalho=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        -I) cabecalho=1 ;;
        -w) formato="$2"; shift ;;
        -o|--max-time) shift ;;
        http://*|https://*) url="$1" ;;
    esac
    shift
done
printf '%s\n' "$url" >> "$CURL_LOG"
destino=""
case "$url" in
    http://*) codigo=301; destino="https://${url#http://}" ;;
    */demo/apresentacao/) codigo=404 ;;
    *) codigo=200 ;;
esac
if [[ "$cabecalho" == "1" ]]; then
    printf 'HTTP/1.1 %s OK\r\n\r\n' "$codigo"
fi
if [[ -n "$formato" ]]; then
    printf '%s' "$formato" | sed -e "s|%{http_code}|$codigo|" -e "s|%{redirect_url}|$destino|"
fi
"""

CRIAR_DEMONSTRACAO = """
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from empresas.models import Empresa, GrupoEmpresarial
from usuarios.models import Usuario
grupo = GrupoEmpresarial.objects.create(nome="Grupo Vida Plena Farmácias")
empresa = Empresa.objects.create(nome="Farmácia Vida Plena", razao_social="Vida Plena Farmácias Ltda",
                                 cnpj="98765432000198", grupo=grupo)
for nome in SEIS:
    usuario = Usuario(username=nome, empresa=empresa)
    usuario.set_unusable_password()
    usuario.save()
default_storage.save("identidade/logos/logo_teste.png", ContentFile(b"logo"))
print("DEMO_OK", Empresa.objects.count(), Usuario.objects.count())
"""

PRIMEIRO_ACESSO = """
from django.conf import settings
from django.test import Client
cliente = Client(HTTP_HOST=DOMINIO)
print("GET", cliente.get("/primeiro-acesso/", secure=True).status_code)
r = cliente.post("/primeiro-acesso/", {"token": settings.INITIAL_SETUP_TOKEN}, secure=True)
print("TOKEN", r.status_code, r.get("Location"))
r = cliente.post("/primeiro-acesso/cadastro/", {
    "first_name": "Ana", "last_name": "Teste", "username": "ana.proprietaria",
    "senha": SENHA, "senha_confirmacao": SENHA, "grupo_nome": "Grupo Teste Real",
    "nome": "Drogaria Teste Real", "razao_social": "Drogaria Teste Real Ltda", "cnpj": CNPJ,
    "cidade": "Cuiabá", "estado": "MT", "filial_nome": "Matriz", "fuso_horario": "America/Cuiaba",
    "confirmo": "on",
}, secure=True)
print("CADASTRO", r.status_code, r.get("Location"))
"""

PAGINAS = """
from django.conf import settings
from django.test import Client
cliente = Client(HTTP_HOST=DOMINIO)
for caminho in ("/accounts/login/", "/primeiro-acesso/", "/demo/apresentacao/"):
    print("PAGINA", caminho, cliente.get(caminho, secure=True).status_code)
print("DEMO_MODE", settings.DEMO_MODE, "USO_REAL", settings.USO_REAL, "DDA", settings.FEATURE_DDA)
"""


def _sha(caminho):
    import hashlib

    return hashlib.sha256(Path(caminho).read_bytes()).hexdigest()


class ExecucaoUsoRealTestCase(SimpleTestCase):
    """Roda os scripts de verdade no Git Bash. O HOME simulado é montado uma
    vez (código do zip + banco de demonstração + .env) e copiado para cada
    teste."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.bash = _bash()
        if cls.bash is None:
            return
        cls.base = Path(tempfile.mkdtemp(prefix="nexbuy_uso_real_"))
        # Sem .resolve(): no Linux o python do venv é um link simbólico para
        # o do sistema, e resolvê-lo "saía" do venv (Django não encontrado).
        cls.python = Path(sys.executable).absolute()
        cls.venv = cls.python.parent.parent
        modelo = cls.base / "modelo"
        (modelo / "nexbuy_dados" / "media").mkdir(parents=True)
        pacote = cls.base / "NEXBUY_PYTHONANYWHERE.zip"
        _modulo_gerar_pacote().gerar(BASE_DIR, pacote, usar_git=False)
        with zipfile.ZipFile(pacote) as arquivo_zip:
            arquivo_zip.extractall(modelo)
        app = modelo / "nexbuy"
        dados = modelo / "nexbuy_dados"
        # Mesmo .env que o preparar.sh gera para a demonstração.
        (app / ".env").write_bytes((
            "# NEXBUY — demonstração (HOME simulado dos testes)\n"
            f"SECRET_KEY={secrets.token_urlsafe(50)}\n"
            "DEBUG=False\nDEMO_MODE=True\nDEMO_EXIBIR_SENHA=False\n"
            f"ALLOWED_HOSTS={DOMINIO}\nCSRF_TRUSTED_ORIGINS=https://{DOMINIO}\n"
            "SECURE_SSL_REDIRECT=False\nUSA_PROXY_HTTPS=True\nSQLITE_WAL=False\n"
            f"SQLITE_PATH={(dados / 'db.sqlite3').as_posix()}\nMEDIA_ROOT={(dados / 'media').as_posix()}\n"
            f"STATIC_ROOT={(modelo / 'nexbuy_static').as_posix()}\n"
            "ADMIN_URL=suporte-teste/\nINITIAL_SETUP_TOKEN=\nFEATURE_DDA=False\nLOG_LEVEL=WARNING\nDB_ENGINE=sqlite3\n"
        ).encode("utf-8"))
        cls.modelo = modelo
        resultado = cls._manage(modelo, "migrate", "--noinput")
        assert resultado.returncode == 0, resultado.stdout + resultado.stderr
        resultado = cls._shell(modelo, f"SEIS = {SEIS!r}\n" + CRIAR_DEMONSTRACAO)
        assert "DEMO_OK 1 6" in resultado.stdout, resultado.stdout + resultado.stderr
        # Programas falsos: curl (sem rede) e sleep (sem espera).
        falsos = cls.base / "falsos"
        falsos.mkdir()
        (falsos / "curl").write_bytes(CURL_FALSO.encode("utf-8"))
        (falsos / "sleep").write_bytes(b"#!/usr/bin/env bash\nexit 0\n")
        for programa in ("curl", "sleep"):
            os.chmod(falsos / programa, 0o755)
        cls.falsos = falsos

    @classmethod
    def tearDownClass(cls):
        try:
            if getattr(cls, "base", None):
                shutil.rmtree(cls.base, ignore_errors=True)
        finally:
            super().tearDownClass()

    def setUp(self):
        if self.bash is None:
            self.skipTest(SEM_BASH)

    # -- ambiente ---------------------------------------------------------

    @classmethod
    def _ambiente(cls, home=None):
        ambiente = {chave: valor for chave, valor in os.environ.items() if chave not in {
            "SQLITE_PATH", "MEDIA_ROOT", "STATIC_ROOT", "DEBUG", "DEMO_MODE", "DEMO_EXIBIR_SENHA", "SECRET_KEY",
            "ALLOWED_HOSTS", "INITIAL_SETUP_TOKEN", "NEXBUY_USO_REAL", "BACKUP_DIARIO", "BACKUP_DIARIO_DIR",
            "BACKUP_DIARIO_MANTER", "ALLOW_SEED_IN_PRODUCTION",
        }}
        ambiente.update({"DJANGO_SETTINGS_MODULE": "nexbuy.settings", "PYTHONIOENCODING": "utf-8"})
        if home is not None:
            ambiente.update({
                "NEXBUY_HOME": home.as_posix(), "NEXBUY_VENV": cls.venv.as_posix(),
                "NEXBUY_PYTHON": cls.python.as_posix(), "PA_USUARIO": "nexbuyteste", "PA_DOMINIO": DOMINIO,
                "NEXBUY_PULAR_PIP": "1", "NEXBUY_WSGI_DIR": (home / "var_www").as_posix(),
            })
        return ambiente

    @classmethod
    def _manage(cls, home, *argumentos):
        return subprocess.run(
            [str(cls.python), "manage.py", *argumentos], cwd=home / "nexbuy", capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=600, env=cls._ambiente(),
        )

    @classmethod
    def _shell(cls, home, codigo):
        return cls._manage(home, "shell", "-c", codigo)

    def _novo_home(self, nome):
        home = self.base / nome
        shutil.copytree(self.modelo, home)
        env = home / "nexbuy" / ".env"
        env.write_bytes(env.read_bytes().replace(self.modelo.as_posix().encode(), home.as_posix().encode()))
        (home / "var_www").mkdir()
        return home

    def _rodar(self, home, script, *argumentos, falsos=False):
        ambiente = self._ambiente(home)
        comando = [self.bash, (home / "nexbuy" / "deploy" / "pythonanywhere" / script).as_posix(), *argumentos]
        if falsos:
            # O bash.exe do Git põe /mingw64/bin e /usr/bin na frente do PATH:
            # os programas falsos entram na frente já dentro do bash.
            ambiente["FALSOS_DIR"] = self.falsos.as_posix()
            ambiente["CURL_LOG"] = (home / "curl.log").as_posix()
            comando = [self.bash, "-c",
                       'PATH="$(cygpath -u "$FALSOS_DIR" 2>/dev/null || printf %s "$FALSOS_DIR"):$PATH"; '
                       'export PATH; exec bash "$@"', "_", *comando[1:]]
        resultado = subprocess.run(
            comando,
            cwd=home / "nexbuy", input="", capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=900, env=ambiente,
        )
        resultado.saida = resultado.stdout + resultado.stderr
        return resultado

    def _env(self, home):
        from dotenv import dotenv_values

        return dotenv_values(home / "nexbuy" / ".env")

    def _contagem(self, home):
        """(empresas, usuários, CNPJs) lidos direto do arquivo do banco, só
        leitura — sem subir o Django a cada conferência."""
        banco = home / "nexbuy_dados" / "db.sqlite3"
        conexao = sqlite3.connect(banco.resolve().as_uri() + "?mode=ro", uri=True)
        try:
            cnpjs = sorted(cnpj for (cnpj,) in conexao.execute("SELECT cnpj FROM empresas_empresa"))
            usuarios = conexao.execute("SELECT COUNT(*) FROM usuarios_usuario").fetchone()[0]
        finally:
            conexao.close()
        return len(cnpjs), usuarios, ",".join(cnpjs) or "-"

    def _estado(self, home):
        """Impressão digital do que nunca pode mudar numa recusa."""
        backups = home / "nexbuy_backups"
        return (
            _sha(home / "nexbuy_dados" / "db.sqlite3"), _sha(home / "nexbuy" / ".env"),
            sorted(p.name for p in backups.iterdir()) if backups.exists() else [],
        )

    # -- testes -----------------------------------------------------------

    def test_sem_sim_e_sem_terminal_nada_e_apagado(self):
        home = self._novo_home("sem_sim")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Sem terminal para confirmar. Nada foi apagado.", resultado.saida)
        self.assertIn("DEIXAM DE EXISTIR", resultado.saida)
        self.assertEqual(self._estado(home), antes)
        self.assertEqual(self._contagem(home)[:2], (1, 6))

    def test_demonstracao_para_uso_real_ponta_a_ponta(self):
        home = self._novo_home("ponta_a_ponta")
        app = home / "nexbuy"
        backups = home / "nexbuy_backups"
        env_antes = self._env(home)

        # (1) Banco de demonstração -> ativar_uso_real.sh --sim
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        # O WARNINGS do check --deploy (W008) vem explicado, como no preparar.sh.
        self.assertIn("O aviso security.W008 (SECURE_SSL_REDIRECT) é esperado aqui", resultado.saida)
        env = self._env(home)
        token = env["INITIAL_SETUP_TOKEN"]
        self.assertRegex(token, r"^[A-Za-z0-9_-]{43}$")
        esperado = {
            "DEMO_MODE": "False", "DEMO_EXIBIR_SENHA": "False", "NEXBUY_USO_REAL": "True", "BACKUP_DIARIO": "True",
            "BACKUP_DIARIO_DIR": backups.as_posix(), "BACKUP_DIARIO_MANTER": "14",
        }
        for chave, valor in esperado.items():
            self.assertEqual(env.get(chave), valor, chave)
        for chave in ("SECRET_KEY", "ADMIN_URL", "ALLOWED_HOSTS", "CSRF_TRUSTED_ORIGINS", "SQLITE_PATH", "MEDIA_ROOT",
                      "FEATURE_DDA", "DEBUG"):
            self.assertEqual(env.get(chave), env_antes.get(chave), chave)
        linhas_env = (app / ".env").read_text(encoding="utf-8").splitlines()
        for chave in (*esperado, "INITIAL_SETUP_TOKEN", "SECRET_KEY"):
            self.assertEqual(sum(1 for l in linhas_env if l.startswith(f"{chave}=")), 1, chave)
        # Token: uma vez na tela, e em nenhum arquivo além do .env.
        self.assertEqual(resultado.saida.count(token), 1)
        self.assertIn(f"https://{DOMINIO}/primeiro-acesso/", resultado.saida)
        com_token = [p for p in home.rglob("*") if p.is_file() and token.encode() in p.read_bytes()]
        self.assertEqual(com_token, [app / ".env"])
        # Banco vazio no mesmo lugar, uploads vazios, demonstração guardada.
        self.assertEqual(self._contagem(home), (0, 0, "-"))
        self.assertEqual(list((home / "nexbuy_dados" / "media").iterdir()), [])
        guardadas = sorted(backups.glob("demonstracao_final_*"))
        self.assertEqual(len(guardadas), 1)
        guardada = guardadas[0]
        self.assertRegex(guardada.name, r"^demonstracao_final_\d{4}-\d{2}-\d{2}_\d{4}$")
        self.assertTrue((guardada / "media" / "identidade" / "logos" / "logo_teste.png").is_file())
        self.assertTrue((guardada / "LEIA-ME.txt").is_file())
        with closing(sqlite3.connect(guardada / "db.sqlite3")) as conexao:
            self.assertEqual(conexao.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(conexao.execute("SELECT cnpj FROM empresas_empresa").fetchall(), [("98765432000198",)])
            self.assertEqual(conexao.execute("SELECT COUNT(*) FROM usuarios_usuario").fetchone()[0], 6)
        if os.name != "nt":
            self.assertEqual(guardada.stat().st_mode & 0o777, 0o700)
            self.assertEqual((guardada / "db.sqlite3").stat().st_mode & 0o777, 0o600)
            self.assertEqual((app / ".env").stat().st_mode & 0o777, 0o600)
        # O site de verdade (settings + .env novos): login 200, Primeiro Acesso 200, apresentação 404.
        paginas = self._shell(home, f"DOMINIO = {DOMINIO!r}\n" + PAGINAS).stdout
        self.assertIn("PAGINA /accounts/login/ 200", paginas)
        self.assertIn("PAGINA /primeiro-acesso/ 200", paginas)
        self.assertIn("PAGINA /demo/apresentacao/ 404", paginas)
        self.assertIn("DEMO_MODE False USO_REAL True DDA False", paginas)
        # O backup diário do próprio site (core/backup_diario.py) grava na pasta combinada.
        self.assertTrue(list(backups.glob("diario_*.sqlite3")), sorted(p.name for p in backups.iterdir()))

        # (2) Rodar de novo: nada é apagado, o token continua o mesmo — e a
        # troca é terminada (estáticos e recarga), caso tenha parado no meio.
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("nada foi apagado", resultado.saida)
        self.assertIn("Arquivos estáticos atualizados", resultado.saida)
        self.assertIn("--novo-token", resultado.saida)
        self.assertNotIn(token, resultado.saida)
        self.assertEqual(self._estado(home), antes)

        # (2b) --novo-token (com recarga e conferência por um curl falso, sem rede).
        wsgi = home / "var_www" / f"{DOMINIO.replace('.', '_')}_wsgi.py"
        wsgi.write_text("# wsgi simulado\n", encoding="utf-8")
        resultado = self._rodar(home, "ativar_uso_real.sh", "--novo-token", falsos=True)
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        novo_token = self._env(home)["INITIAL_SETUP_TOKEN"]
        self.assertRegex(novo_token, r"^[A-Za-z0-9_-]{43}$")
        self.assertNotEqual(novo_token, token)
        self.assertEqual(resultado.saida.count(novo_token), 1)
        self.assertIn(f"https://{DOMINIO}/primeiro-acesso/ respondeu 200, como esperado.", resultado.saida)
        self.assertIn(f"https://{DOMINIO}/demo/apresentacao/ respondeu 404, como esperado.", resultado.saida)
        self.assertIn("Site recarregado", resultado.saida)
        self.assertNotIn(novo_token, (home / "curl.log").read_text(encoding="utf-8"))
        self.assertEqual(self._contagem(home), (0, 0, "-"))

        # (3) A proprietária faz o Primeiro Acesso de verdade.
        senha = secrets.token_urlsafe(12) + "-Aa9"
        feito = self._shell(home, f"DOMINIO = {DOMINIO!r}\nSENHA = {senha!r}\nCNPJ = {CNPJ_REAL!r}\n" + PRIMEIRO_ACESSO).stdout
        self.assertIn("CADASTRO 302 /accounts/login/", feito)
        self.assertEqual(self._contagem(home), (1, 1, CNPJ_REAL))

        # ativar de novo: recusa sem apagar nada; --novo-token também.
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("JÁ ESTÁ em USO REAL — nada foi apagado", resultado.saida)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--novo-token", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("O Primeiro Acesso já foi feito", resultado.saida)
        self.assertEqual(self._estado(home), antes)

        # atualizar.sh (e o nome antigo): nada apagado, seed nunca roda, token sai do .env.
        resultado = self._rodar(home, "atualizar_demo.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        for trecho in ("Modo: USO REAL", "o token foi APAGADO do .env", "Backup diário automático LIGADO",
                       "Backup diário mais recente:", "Nada a fazer no uso real"):
            self.assertIn(trecho, resultado.saida)
        for proibido in ("Cenário fictício", "seed_demo", "Senha pública", "definir_senha_demo"):
            self.assertNotIn(proibido, resultado.saida)
        self.assertEqual(self._env(home)["INITIAL_SETUP_TOKEN"], "")
        self.assertEqual(self._contagem(home), (1, 1, CNPJ_REAL))
        self.assertTrue(list(backups.glob("nexbuy_*.sqlite3")))

        # preparar.sh com um token esquecido no .env: mesmo comportamento.
        conteudo = (app / ".env").read_text(encoding="utf-8")
        (app / ".env").write_bytes(conteudo.replace("INITIAL_SETUP_TOKEN=\n", f"INITIAL_SETUP_TOKEN={secrets.token_urlsafe(32)}\n").encode())
        resultado = self._rodar(home, "preparar.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        for trecho in ("Modo: USO REAL", "o token foi APAGADO do .env", "Nada a fazer no uso real"):
            self.assertIn(trecho, resultado.saida)
        for proibido in ("Cenário fictício", "Criando o cenário", "Senha pública", "Abertura da apresentação"):
            self.assertNotIn(proibido, resultado.saida)
        self.assertEqual(self._env(home)["INITIAL_SETUP_TOKEN"], "")
        self.assertEqual(self._contagem(home), (1, 1, CNPJ_REAL))

        # (4) Opções da demonstração no uso real: recusadas sem mudar nada.
        antes = self._estado(home)
        for script, argumentos in (
            ("atualizar.sh", ("--renovar-cenario", "--sim", "--sem-wsgi")),
            ("atualizar_demo.sh", ("--gerar-senha", "--sem-wsgi")),
            ("preparar.sh", ("--gerar-senha", "--sem-wsgi")),
            ("preparar.sh", ("--recriar-cenario", "--sim", "--sem-wsgi")),
        ):
            with self.subTest(script=script, argumentos=argumentos):
                resultado = self._rodar(home, script, *argumentos)
                self.assertEqual(resultado.returncode, 1, resultado.saida)
                self.assertIn("é da DEMONSTRAÇÃO, e este site está em USO REAL — nada foi alterado.", resultado.saida)
        self.assertEqual(self._estado(home), antes)

        # (5) Restauração: backup da demonstração recusado; backup real aceito.
        resultado = self._rodar(home, "restaurar.sh", "--sim", "--sem-wsgi", (guardada / "db.sqlite3").as_posix())
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Restaurar apagaria os dados reais", resultado.saida)
        self.assertEqual(self._estado(home), antes)
        copia = sorted(backups.glob("nexbuy_*.sqlite3"))[-1]
        self._shell(home, "from usuarios.models import Usuario\nfrom empresas.models import Empresa\n"
                          "Usuario.objects.create_user('joao.comprador', password=None, empresa=Empresa.objects.get())")
        self.assertEqual(self._contagem(home)[:2], (1, 2))
        resultado = self._rodar(home, "restaurar.sh", "--sim", "--sem-wsgi", copia.as_posix())
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("Banco restaurado", resultado.saida)
        self.assertEqual(self._contagem(home), (1, 1, CNPJ_REAL))

    def test_empresa_real_sem_o_marcador_nunca_e_apagada_nem_recebe_o_seed(self):
        home = self._novo_home("sem_marcador")
        self._shell(home, "from empresas.models import Empresa, GrupoEmpresarial\n"
                          f"Empresa.objects.create(nome='Farmacia Real', razao_social='X', cnpj={CNPJ_REAL!r}, "
                          "grupo=GrupoEmpresarial.objects.create(nome='G'))")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("nunca apaga um banco com dados reais. Nada foi alterado.", resultado.saida)
        # Demonstração + empresa cadastrada nela: a saída é a opção explícita,
        # nunca o marcador à mão (que deixaria o fictício no uso real).
        self.assertIn("--descartar-empresas-da-demonstracao", resultado.saida)
        self.assertNotIn("falta só o marcador", resultado.saida.lower())
        resultado = self._rodar(home, "atualizar.sh", "--renovar-cenario", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("age como USO REAL", resultado.saida)
        self.assertEqual(self._estado(home), antes)
        # Última barreira: o próprio manage_seed recusa.
        ambiente = self._ambiente(home)
        resultado = subprocess.run(
            [self.bash, "-c", 'set -euo pipefail; SCRIPT_DIR="$1"; . "$SCRIPT_DIR/_comum_pa.sh"; '
                              'exigir_instalacao; manage_seed seed_demo',
             "_", (home / "nexbuy" / "deploy" / "pythonanywhere").as_posix()],
            cwd=home / "nexbuy", input="", capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=300, env=ambiente,
        )
        self.assertEqual(resultado.returncode, 1, resultado.stdout + resultado.stderr)
        self.assertIn("Recusado: o banco tem empresa de verdade", resultado.stderr)
        self.assertEqual(self._estado(home), antes)
        self.assertEqual(self._contagem(home)[:2], (2, 6))

    def test_backup_retencao_nunca_apaga_diario_nem_demonstracao_final(self):
        home = self._novo_home("retencao")
        backups = home / "nexbuy_backups"
        (backups / "demonstracao_final_AAAA").mkdir(parents=True)
        (backups / "demonstracao_final_AAAA" / "db.sqlite3").write_bytes(b"x")
        for dia in range(1, 13):
            (backups / f"nexbuy_2000-01-{dia:02d}_1200.sqlite3").write_bytes(b"x")
        for dia in range(1, 4):
            (backups / f"diario_2000-01-{dia:02d}.sqlite3").write_bytes(b"x")
        resultado = self._rodar(home, "backup_demo.sh")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertEqual(len(list(backups.glob("nexbuy_*.sqlite3"))), 5)  # demonstração: 5
        with (home / "nexbuy" / ".env").open("a", encoding="utf-8", newline="\n") as env:
            env.write("NEXBUY_USO_REAL=True\n")
        for dia in range(13, 20):
            (backups / f"nexbuy_2000-01-{dia:02d}_1200.sqlite3").write_bytes(b"x")
        resultado = self._rodar(home, "backup.sh")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("(uso real)", resultado.saida)
        self.assertEqual(len(list(backups.glob("nexbuy_*.sqlite3"))), 10)  # uso real: 10
        self.assertEqual(len(list(backups.glob("diario_*.sqlite3"))), 3)
        self.assertTrue((backups / "demonstracao_final_AAAA" / "db.sqlite3").is_file())
        mais_nova = sorted(backups.glob("nexbuy_*.sqlite3"))[-1]
        with closing(sqlite3.connect(mais_nova)) as conexao:
            self.assertEqual(conexao.execute("PRAGMA integrity_check").fetchone()[0], "ok")

    # -- correções da revisão --------------------------------------------

    def _ativar(self, home):
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        return resultado

    def _primeiro_acesso(self, home, cnpj=CNPJ_REAL):
        senha = secrets.token_urlsafe(12) + "-Aa9"
        feito = self._shell(home, f"DOMINIO = {DOMINIO!r}\nSENHA = {senha!r}\nCNPJ = {cnpj!r}\n" + PRIMEIRO_ACESSO)
        self.assertIn("CADASTRO 302 /accounts/login/", feito.stdout, feito.stdout + feito.stderr)

    def _midia(self, home):
        pasta = home / "nexbuy_dados" / "media"
        return sorted(p.relative_to(pasta).as_posix() for p in pasta.rglob("*") if p.is_file())

    def _trocar_no_env(self, home, **valores):
        env = home / "nexbuy" / ".env"
        linhas = [l for l in env.read_text(encoding="utf-8").splitlines() if l.split("=", 1)[0] not in valores]
        linhas += [f"{chave}={valor}" for chave, valor in valores.items()]
        env.write_bytes(("\n".join(linhas) + "\n").encode("utf-8"))

    def _sql(self, home, comando):
        with closing(sqlite3.connect(home / "nexbuy_dados" / "db.sqlite3")) as conexao:
            conexao.execute(comando)
            conexao.commit()

    def _bash_comum(self, home, corpo, cwd):
        """Funções do _comum_pa.sh, carregadas como os scripts carregam."""
        resultado = subprocess.run(
            [self.bash, "-c", 'set -euo pipefail; SCRIPT_DIR="$1"; . "$SCRIPT_DIR/_comum_pa.sh"; ' + corpo,
             "_", (home / "nexbuy" / "deploy" / "pythonanywhere").as_posix()],
            cwd=cwd, input="", capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=300, env=self._ambiente(home),
        )
        resultado.saida = resultado.stdout + resultado.stderr
        return resultado

    def test_confirmacao_conta_todos_os_usuarios_da_demonstracao(self):
        """A etapa 2 contava 7 (o seed tem outros usuários fictícios além dos
        6 demo_*) e a confirmação falava em 6."""
        home = self._novo_home("sete_usuarios")
        self._shell(home, "from empresas.models import Empresa\nfrom usuarios.models import Usuario\n"
                          "u = Usuario(username='vp_atendente_beatriz', empresa=Empresa.objects.get())\n"
                          "u.set_unusable_password(); u.save()")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Usuários ativos: 7 (de demonstração: 7; outros: 0)", resultado.saida)
        self.assertIn("os 7 usuários ativos da demonstração, entre eles os 6 acessos", resultado.saida)
        self.assertIn("demo_comprador3): DEIXAM DE EXISTIR", resultado.saida)
        self.assertNotIn("os 6 usuários de demonstração", resultado.saida)
        self.assertIn("Sem terminal para confirmar. Nada foi apagado.", resultado.saida)
        self.assertEqual(self._estado(home), antes)

    def test_token_aparece_mesmo_se_a_troca_parar_depois_de_grava_lo(self):
        """O collectstatic (etapa 8) falha depois do APAGAR e do token
        gravado: o quadro do token sai mesmo assim, uma vez; rodar de novo
        termina a troca (estáticos) sem apagar nada e sem mostrar o token."""
        home = self._novo_home("token_parou")
        (home / "arquivo_comum").write_bytes(b"x")
        estaticos_ruins = (home / "arquivo_comum" / "static").as_posix()
        conteudo = (home / "nexbuy" / ".env").read_text(encoding="utf-8")
        estaticos = re.search(r"(?m)^STATIC_ROOT=(.*)$", conteudo).group(1)
        self._trocar_no_env(home, STATIC_ROOT=estaticos_ruins)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("O collectstatic falhou", resultado.saida)
        token = self._env(home)["INITIAL_SETUP_TOKEN"]
        self.assertRegex(token, r"^[A-Za-z0-9_-]{43}$")
        self.assertEqual(resultado.saida.count(token), 1)
        self.assertIn("O script PAROU antes do fim", resultado.saida)
        self.assertIn("PRIMEIRO ACESSO — copie AGORA", resultado.saida)
        self.assertEqual(self._env(home)["NEXBUY_USO_REAL"], "True")
        self.assertEqual(self._contagem(home), (0, 0, "-"))

        # Corrigido o problema, o MESMO comando (sem --sim, sem terminal) termina a troca.
        self._trocar_no_env(home, STATIC_ROOT=estaticos)
        banco = _sha(home / "nexbuy_dados" / "db.sqlite3")
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("esperando o Primeiro Acesso — nada foi apagado", resultado.saida)
        self.assertIn("Arquivos estáticos atualizados", resultado.saida)
        self.assertIn("--novo-token", resultado.saida)
        self.assertNotIn(token, resultado.saida)
        self.assertEqual(self._env(home)["INITIAL_SETUP_TOKEN"], token)
        self.assertEqual(_sha(home / "nexbuy_dados" / "db.sqlite3"), banco)
        self.assertTrue(any(Path(estaticos).rglob("*.css")))

    def test_empresa_cadastrada_na_demonstracao_so_sai_com_ordem_explicita(self):
        home = self._novo_home("misto")
        self._shell(home, "from empresas.models import Empresa, GrupoEmpresarial\n"
                          f"Empresa.objects.create(nome='Farmacia da Cliente', razao_social='X', cnpj={CNPJ_REAL!r}, "
                          "grupo=GrupoEmpresarial.objects.create(nome='G'))")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("O banco é a DEMONSTRAÇÃO com empresa cadastrada DENTRO dela: Farmacia da Cliente", resultado.saida)
        self.assertIn("--descartar-empresas-da-demonstracao", resultado.saida)
        self.assertNotIn("falta só o marcador", resultado.saida.lower())
        self.assertEqual(self._estado(home), antes)

        # Quem pôs o marcador à mão (a dica antiga) continua sem "JÁ ESTÁ em USO REAL".
        self._trocar_no_env(home, NEXBUY_USO_REAL="True")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertNotIn("JÁ ESTÁ em USO REAL", resultado.saida)
        self.assertIn("--descartar-empresas-da-demonstracao", resultado.saida)
        self.assertEqual(self._estado(home), antes)

        # Com a ordem explícita: tudo sai do site e fica guardado na mesma cópia.
        resultado = self._rodar(home, "ativar_uso_real.sh", "--descartar-empresas-da-demonstracao", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("as empresas cadastradas DENTRO da demonstração: Farmacia da Cliente", resultado.saida)
        self.assertEqual(self._contagem(home), (0, 0, "-"))
        guardada = sorted((home / "nexbuy_backups").glob("demonstracao_final_*"))[-1]
        with closing(sqlite3.connect(guardada / "db.sqlite3")) as conexao:
            cnpjs = sorted(c for (c,) in conexao.execute("SELECT cnpj FROM empresas_empresa"))
        self.assertEqual(cnpjs, sorted([CNPJ_REAL, "98765432000198"]))
        self.assertRegex(self._env(home)["INITIAL_SETUP_TOKEN"], r"^[A-Za-z0-9_-]{43}$")

    def test_depois_do_primeiro_acesso_nada_desfaz_o_uso_real(self):
        home = self._novo_home("pos_pa")
        self._ativar(home)
        self._primeiro_acesso(home)
        midia = home / "nexbuy_dados" / "media"
        for relativo in ("identidade/logos/logo_real.png", "usuarios/fotos/ana.png"):
            (midia / relativo).parent.mkdir(parents=True, exist_ok=True)
            (midia / relativo).write_bytes(b"upload real")
        uploads = self._midia(home)

        # (a) Voltar para a demonstração: recusa ANTES de tocar em qualquer coisa.
        antes = self._estado(home)
        resultado = self._rodar(home, "voltar_demonstracao.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Recusado: o site tem dados REAIS", resultado.saida)
        self.assertIn("PARE aqui", resultado.saida)
        self.assertEqual(self._estado(home), antes)
        self.assertEqual(self._midia(home), uploads)
        self.assertEqual(self._env(home)["BACKUP_DIARIO"], "True")

        # (b) Primeiro Acesso feito com um CNPJ do prefixo fictício (o
        # formulário antigo aceitava): continua sendo uso real.
        self._sql(home, "UPDATE empresas_empresa SET cnpj = '98765432000198'")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("JÁ ESTÁ em USO REAL — nada foi apagado", resultado.saida)
        self.assertEqual(self._estado(home), antes)
        self.assertEqual(self._contagem(home), (1, 1, "98765432000198"))

        # (c) .env de demonstração por engano (o que a receita antiga da
        # parte 14 deixava): nada apaga, nada semeia, e o marcador volta.
        self._trocar_no_env(home, NEXBUY_USO_REAL="False", DEMO_MODE="True", BACKUP_DIARIO="False")
        antes = self._estado(home)
        resultado = self._rodar(home, "ativar_uso_real.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("O banco já é de USO REAL (Primeiro Acesso já feito)", resultado.saida)
        resultado = self._rodar(home, "atualizar.sh", "--renovar-cenario", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("age como USO REAL", resultado.saida)
        guardada = sorted((home / "nexbuy_backups").glob("demonstracao_final_*"))[-1]
        resultado = self._rodar(home, "restaurar.sh", "--sim", "--sem-wsgi", (guardada / "db.sqlite3").as_posix())
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Restaurar apagaria os dados reais", resultado.saida)
        resultado = self._bash_comum(home, "exigir_instalacao; manage_seed seed_demo", home / "nexbuy")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Recusado: o Primeiro Acesso já foi feito", resultado.saida)
        self.assertEqual(self._estado(home), antes)

        resultado = self._rodar(home, "backup.sh")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("uso real: o banco tem dados reais", resultado.saida)
        self.assertIn("(máximo 10)", resultado.saida)

        resultado = self._rodar(home, "atualizar.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("Corrigido no .env: NEXBUY_USO_REAL=True", resultado.saida)
        env = self._env(home)
        for chave, valor in (("NEXBUY_USO_REAL", "True"), ("DEMO_MODE", "False"), ("DEMO_EXIBIR_SENHA", "False"),
                             ("BACKUP_DIARIO", "True")):
            self.assertEqual(env.get(chave), valor, chave)
        self.assertEqual(self._contagem(home), (1, 1, "98765432000198"))
        self.assertEqual(self._midia(home), uploads)
        paginas = self._shell(home, f"DOMINIO = {DOMINIO!r}\n" + PAGINAS).stdout
        self.assertIn("PAGINA /demo/apresentacao/ 404", paginas)
        self.assertIn("DEMO_MODE False USO_REAL True", paginas)

    def test_voltar_para_a_demonstracao_antes_do_primeiro_acesso(self):
        home = self._novo_home("voltar")
        # Senhas próprias (não a pública) nos 6: a demonstração publicada é assim.
        self._shell(home, "import secrets\nfrom usuarios.models import Usuario\n"
                          "for u in Usuario.objects.all():\n"
                          "    u.set_password(secrets.token_urlsafe(16) + '-Aa9'); u.save()")
        env_antes = self._env(home)
        self._ativar(home)
        estranho = home / "nexbuy_dados" / "media" / "identidade" / "logos" / "enviado_depois.png"
        estranho.parent.mkdir(parents=True, exist_ok=True)
        estranho.write_bytes(b"depois")

        antes = self._estado(home)
        resultado = self._rodar(home, "voltar_demonstracao.sh", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 1, resultado.saida)
        self.assertIn("Sem terminal para confirmar. Nada foi alterado.", resultado.saida)
        self.assertEqual(self._estado(home), antes)

        resultado = self._rodar(home, "voltar_demonstracao.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("A DEMONSTRAÇÃO voltou", resultado.saida)
        self.assertIn("Modo: DEMONSTRAÇÃO", resultado.saida)
        env = self._env(home)
        for chave, valor in (("NEXBUY_USO_REAL", "False"), ("DEMO_MODE", "True"), ("INITIAL_SETUP_TOKEN", ""),
                             ("BACKUP_DIARIO", "False")):
            self.assertEqual(env.get(chave), valor, chave)
        for chave in ("SECRET_KEY", "ALLOWED_HOSTS", "SQLITE_PATH", "MEDIA_ROOT", "ADMIN_URL"):
            self.assertEqual(env.get(chave), env_antes.get(chave), chave)
        self.assertEqual(self._contagem(home), (1, 6, "98765432000198"))
        self.assertEqual(self._midia(home), ["identidade/logos/logo_teste.png"])
        # O que estava no site foi MOVIDO, nunca apagado; a cópia guardada continua lá.
        movidos = sorted((home / "nexbuy_backups").glob("media_antes_da_volta_*/identidade/logos/enviado_depois.png"))
        self.assertEqual(len(movidos), 1)
        guardada = sorted((home / "nexbuy_backups").glob("demonstracao_final_*"))[-1]
        self.assertTrue((guardada / "db.sqlite3").is_file())
        self.assertTrue((guardada / "media" / "identidade" / "logos" / "logo_teste.png").is_file())
        paginas = self._shell(home, f"DOMINIO = {DOMINIO!r}\n" + PAGINAS).stdout
        self.assertIn("PAGINA /primeiro-acesso/ 404", paginas)
        self.assertIn("DEMO_MODE True USO_REAL False", paginas)

        # De novo: já é demonstração, nada muda.
        antes = self._estado(home)
        resultado = self._rodar(home, "voltar_demonstracao.sh", "--sim", "--sem-wsgi")
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertIn("já está na DEMONSTRAÇÃO", resultado.saida)
        self.assertEqual(self._estado(home), antes)

    def test_sem_env_na_atualizacao_mostra_o_cp_da_pasta_antiga(self):
        home = self._novo_home("sem_env")
        (home / "nexbuy_antigo").mkdir()
        shutil.move(home / "nexbuy" / ".env", home / "nexbuy_antigo" / ".env")
        for script in ("atualizar.sh", "ativar_uso_real.sh", "restaurar.sh"):
            with self.subTest(script=script):
                resultado = self._rodar(home, script, "--sem-wsgi")
                self.assertEqual(resultado.returncode, 1, resultado.saida)
                self.assertIn("faltou trazer o .env da pasta antiga", resultado.saida)
                self.assertIn("cp ~/nexbuy_antigo/.env ~/nexbuy/.env", resultado.saida)
                self.assertIn("chmod 600 ~/nexbuy/.env", resultado.saida)
                self.assertNotIn("Rode primeiro: bash deploy/pythonanywhere/preparar.sh", resultado.saida)
                self.assertFalse((home / "nexbuy" / ".env").exists())

    def test_backup_diario_dir_sem_caminho_completo_e_corrigido(self):
        """BACKUP_DIARIO_DIR=~/nexbuy_backups (escrito à mão): o site recusa
        esse valor; o script dizia LIGADO e criava uma pasta "~"."""
        pasta = Path(tempfile.mkdtemp(prefix="nexbuy_til_"))
        self.addCleanup(shutil.rmtree, pasta, True)
        home = pasta / "home"
        trabalho = pasta / "trabalho"
        trabalho.mkdir()
        (home / "nexbuy" / "deploy").mkdir(parents=True)
        shutil.copytree(PA_DIR, home / "nexbuy" / "deploy" / "pythonanywhere")
        for valor, esperado in (("~/nexbuy_backups", home / "nexbuy_backups"),
                                ("backups_relativos", home / "nexbuy_backups"),
                                ("~/outra_pasta/", home / "outra_pasta")):
            with self.subTest(valor=valor):
                env = home / "nexbuy" / ".env"
                env.write_bytes((f"NEXBUY_USO_REAL=True\nBACKUP_DIARIO=True\nBACKUP_DIARIO_DIR={valor}\n"
                                 "BACKUP_DIARIO_MANTER=14\n").encode("utf-8"))
                resultado = self._bash_comum(home, "carregar_env; conferir_backup_diario", trabalho)
                self.assertEqual(resultado.returncode, 0, resultado.saida)
                self.assertIn("não é um caminho completo", resultado.saida)
                self.assertIn("NÃO estava fazendo o backup diário", resultado.saida)
                self.assertEqual(self._env(home)["BACKUP_DIARIO_DIR"], esperado.as_posix())
                self.assertTrue(esperado.is_dir())
                self.assertEqual(list(trabalho.iterdir()), [])  # nenhuma pasta "~" nem relativa
                # O valor gravado é um que o site aceita.
                from django.test import override_settings

                from core import backup_diario
                with override_settings(BACKUP_DIARIO_DIR=self._env(home)["BACKUP_DIARIO_DIR"]):
                    self.assertEqual(backup_diario.problema_de_configuracao(), "")
        # Caminho completo: nada muda.
        env.write_bytes(f"BACKUP_DIARIO=True\nBACKUP_DIARIO_DIR={(home / 'ok').as_posix()}\nBACKUP_DIARIO_MANTER=14\n"
                        .encode("utf-8"))
        resultado = self._bash_comum(home, "carregar_env; conferir_backup_diario", trabalho)
        self.assertEqual(resultado.returncode, 0, resultado.saida)
        self.assertNotIn("não é um caminho completo", resultado.saida)
        self.assertIn("Backup diário automático LIGADO", resultado.saida)
