"""Rotas de infraestrutura para produção (Pronto para a Nuvem).

- `/healthz/` — verificação de saúde usada pelo instalador, pelo
  `deploy/atualizar.sh` e por qualquer monitor externo (UptimeRobot etc.).
  Sem login. Responde `{"status": "ok"}` (200) quando o banco responde e
  `{"status": "indisponivel"}` (503) quando não — nunca devolve versão,
  caminho de arquivo, nome de banco, mensagem de exceção ou qualquer outro
  detalhe interno (esses vão só para o log do servidor).
- Páginas de erro 400/403/404/500 (`handler400`... em `nexbuy/urls.py`) e a
  página de falha de CSRF (`CSRF_FAILURE_VIEW` em `nexbuy/settings.py`).

Por que as páginas de erro não usam o `render()` normal: com `request`, o
Django roda TODOS os context processors — e os do NEXBUY consultam o banco
(identidade visual, empresa ativa, notificações, menu). Uma página de erro
não pode depender justamente do que talvez esteja quebrado: o 500 precisa
aparecer com o banco fora do ar, e um 404/400 de um robô não deveria custar
consultas. Por isso os templates são renderizados SEM request (só `{% static
%}`, que não toca no banco), com um HTML mínimo embutido como última rede
se até o template falhar.
"""
import logging

from django.conf import settings
from django.db import connection
from django.http import HttpResponse, HttpResponseNotAllowed, JsonResponse
from django.template import loader
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.cache import never_cache

logger = logging.getLogger("nexbuy.infra")

# Última rede de segurança: sem template, sem arquivo estático, sem banco.
_HTML_MINIMO = (
    '<!DOCTYPE html><html lang="pt-br"><head><meta charset="UTF-8">'
    '<meta name="viewport" content="width=device-width, initial-scale=1">'
    "<title>{titulo} · NEXBUY</title></head>"
    '<body style="font-family:Segoe UI,Arial,sans-serif;background:#F1F5F9;'
    'color:#0F172A;display:flex;min-height:100vh;align-items:center;'
    'justify-content:center;margin:0;padding:16px;">'
    '<div style="background:#fff;border-radius:14px;padding:32px;max-width:420px;'
    'text-align:center;box-shadow:0 10px 30px rgba(15,23,42,.08);">'
    '<p style="font-weight:800;letter-spacing:.5px;margin:0 0 12px;">NEXBUY</p>'
    '<h1 style="font-size:1.3rem;margin:0 0 8px;">{titulo}</h1>'
    '<p style="color:#64748B;margin:0 0 20px;">{mensagem}</p>'
    '<a href="/" style="display:inline-block;background:#2563EB;color:#fff;'
    'padding:10px 18px;border-radius:10px;text-decoration:none;">Voltar ao início</a>'
    "</div></body></html>"
)


@never_cache
def healthz(request):
    if request.method not in ("GET", "HEAD"):
        return HttpResponseNotAllowed(["GET", "HEAD"])
    try:
        with connection.cursor() as cursor:
            # Uma tabela real (não só "SELECT 1"): no SQLite, abrir um
            # caminho errado CRIA um arquivo vazio e "SELECT 1" passaria —
            # exigir a tabela de migrações pega banco errado/não migrado.
            cursor.execute("SELECT 1 FROM django_migrations LIMIT 1")
            cursor.fetchone()
    except Exception:  # noqa: BLE001 — qualquer falha do banco vira 503, com o detalhe só no log
        logger.exception("Healthcheck: o banco de dados não respondeu.")
        return JsonResponse({"status": "indisponivel"}, status=503)
    return JsonResponse({"status": "ok"})


# Sistema interno (e, na demonstração publicada no PythonAnywhere, um
# ambiente só para a cliente): nada para buscadores indexarem. É o MESMO
# conteúdo que o nginx da VPS já devolve sozinho (deploy/nginx_nexbuy.conf,
# `location = /robots.txt`) — lá a requisição nem chega ao Django; aqui
# cobre as hospedagens sem nginx próprio.
ROBOTS_TXT = "User-agent: *\nDisallow: /\n"


def robots_txt(request):
    """`/robots.txt` — sem login, sem banco, sem context processor."""
    if request.method not in ("GET", "HEAD"):
        return HttpResponseNotAllowed(["GET", "HEAD"])
    return HttpResponse(ROBOTS_TXT, content_type="text/plain; charset=utf-8")


def _pagina_de_erro(template_name, status, titulo, mensagem, contexto=None):
    try:
        corpo = loader.get_template(template_name).render(contexto or {})
    except Exception:  # noqa: BLE001 — a página de erro nunca pode gerar outro erro
        logger.exception("Falha ao renderizar %s; usando a página de erro mínima.", template_name)
        corpo = _HTML_MINIMO.format(titulo=titulo, mensagem=mensagem)
    resposta = HttpResponse(corpo, status=status, content_type="text/html; charset=utf-8")
    resposta["Cache-Control"] = "no-store"
    return resposta


def erro_400(request, exception=None):
    return _pagina_de_erro(
        "400.html", 400, "Requisição inválida",
        "Não conseguimos entender o pedido enviado pelo navegador.",
    )


def erro_403(request, exception=None):
    return _pagina_de_erro(
        "403.html", 403, "Acesso negado",
        "Seu perfil de usuário não tem permissão para acessar esta página.",
    )


def erro_404(request, exception=None):
    return _pagina_de_erro(
        "404.html", 404, "Página não encontrada",
        "O endereço acessado não existe ou foi movido.",
    )


def erro_500(request):
    return _pagina_de_erro(
        "500.html", 500, "Algo deu errado",
        "Tivemos um erro inesperado ao processar sua solicitação.",
    )


def falha_csrf(request, reason=""):
    """`CSRF_FAILURE_VIEW`: formulário enviado com token vencido/ausente
    (página aberta há muito tempo, login/logout feito em outra aba, cookies
    bloqueados). O botão "Recarregar" faz um GET limpo do MESMO endereço —
    nunca repete o POST — e só aceita caminho relativo do próprio site (um
    caminho como "//outro-site" vira "/")."""
    caminho = request.path or "/"
    if not caminho.startswith("/") or not url_has_allowed_host_and_scheme(caminho, allowed_hosts=None):
        caminho = "/"
    contexto = {
        "caminho": caminho,
        # O motivo técnico ("CSRF token missing" etc.) só aparece em
        # desenvolvimento; em produção ele fica no log (django.security.csrf).
        "motivo": reason if settings.DEBUG else "",
    }
    return _pagina_de_erro(
        "403_csrf.html", 403, "Sua sessão expirou",
        "Recarregue a página e tente de novo.",
        contexto,
    )
