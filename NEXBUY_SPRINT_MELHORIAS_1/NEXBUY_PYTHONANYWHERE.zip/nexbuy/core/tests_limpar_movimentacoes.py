"""Testes do comando `manage.py limpar_movimentacoes` (saída da fase de
teste) e dos scripts da VPS que o usam (`deploy/limpar_dados_de_teste.sh`
e `deploy/zerar_banco.sh`).

Cenário: DUAS empresas completas (cadastros + movimentações +
planejamento). A limpeza roda sempre na empresa "alvo"; a "outra" precisa
ficar intacta em todos os testes.
"""
import os
import re
import sqlite3
import tempfile
import threading
from datetime import date, timedelta
from decimal import Decimal
from io import StringIO
from pathlib import Path
from unittest import mock

from django.conf import settings
from django.core.management import CommandError, call_command
from django.test import SimpleTestCase, TestCase

from auditoria.models import RegistroAuditoria
from auditoria.services import registrar_evento
from cadastros.models import Categoria, CentroCusto
from compras.models import Compra, Fornecedor, HistoricoCompra, ParcelaCompra
from core.management.commands.limpar_movimentacoes import copiar_banco_sqlite, pasta_do_backup
from empresas.models import ConfiguracaoPlataforma, Empresa, IdentidadeVisual, LogConfiguracao
from filiais.models import Filial
from financeiro.models import (
    ConfiguracaoFinanceira,
    CustoFixo,
    CustoVariavel,
    DiaOperacional,
    Receita,
    ReceitaExtra,
)
from gestao_compras.models import (
    EtapaFluxo,
    FluxoAprovacao,
    HistoricoProvisao,
    ItemProvisao,
    Provisao,
    SolicitacaoAprovacao,
)
from notificacoes.models import Notificacao
from usuarios.models import PerfilAcesso, Usuario, UsuarioEmpresa

BASE_DIR = Path(settings.BASE_DIR)
DEPLOY_DIR = BASE_DIR / "deploy"

CNPJ_ALVO = "11.222.333/0001-81"
CNPJ_OUTRA = "44.555.666/0001-99"


def _popular_empresa(sufixo, cnpj):
    """Uma empresa como ela fica depois de uma "análise fictícia": todos
    os cadastros, compras (inclusive uma nascida de provisão efetivada, que
    é PROTECT), provisões com aprovação, notificações e o planejamento."""
    hoje = date.today()
    empresa = Empresa.objects.create(nome=f"Farmácia {sufixo}", cnpj=cnpj)
    filial = Filial.objects.create(empresa=empresa, nome=f"Matriz {sufixo}", ativo=True)
    proprietario = Usuario.objects.create_user(
        username=f"prop_{sufixo}", password=None, perfil=Usuario.Perfil.PROPRIETARIO, empresa=empresa, filial=filial,
    )
    comprador = Usuario.objects.create_user(
        username=f"comp_{sufixo}", password=None, perfil=Usuario.Perfil.COMPRADOR, empresa=empresa, filial=filial,
    )
    UsuarioEmpresa.objects.create(usuario=comprador, empresa=empresa, limite_compra=Decimal("1500.00"), bloqueado=True)
    PerfilAcesso.objects.create(empresa=empresa, nome=f"Consulta {sufixo}")
    fornecedor = Fornecedor.objects.create(empresa=empresa, nome=f"Distribuidora {sufixo}")
    categoria = Categoria.objects.create(empresa=empresa, nome="Medicamentos")
    centro = CentroCusto.objects.create(empresa=empresa, nome="Loja")
    ConfiguracaoFinanceira.objects.create(empresa=empresa, percentual_compras=Decimal("35"))
    ConfiguracaoPlataforma.objects.create(empresa=empresa)
    IdentidadeVisual.objects.create(empresa=empresa, nome_exibicao=f"Vida {sufixo}")
    fluxo = FluxoAprovacao.objects.create(empresa=empresa, nome="Padrão", ativo=True)
    etapa = EtapaFluxo.objects.create(fluxo=fluxo, ordem=1, perfil_aprovador=Usuario.Perfil.GERENTE)
    LogConfiguracao.objects.create(empresa=empresa, usuario=proprietario, area="Sistema", descricao="Configuração inicial")
    registrar_evento(
        categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login realizado",
        empresa=empresa, usuario=proprietario, modulo="seguranca",
    )

    # --- Movimentações -------------------------------------------------
    compra = Compra.objects.create(
        empresa=empresa, filial=filial, fornecedor=fornecedor, usuario=comprador, valor=Decimal("300.00"),
        categoria=categoria, centro_custo=centro, data_compra=hoje, prazo_pagamento=Compra.PrazoPagamento.D30_60,
    )
    ParcelaCompra.objects.create(compra=compra, numero=1, data_vencimento=hoje + timedelta(days=30), valor=Decimal("150.00"))
    ParcelaCompra.objects.create(compra=compra, numero=2, data_vencimento=hoje + timedelta(days=60), valor=Decimal("150.00"))
    HistoricoCompra.objects.create(compra=compra, usuario=comprador, acao=HistoricoCompra.Acao.CRIACAO)

    provisao = Provisao.objects.create(
        empresa=empresa, filial=filial, comprador=comprador, fornecedor=fornecedor, categoria=categoria,
        data=hoje, valor_total=Decimal("200.00"), status=Provisao.Status.AGUARDANDO_APROVACAO,
    )
    ItemProvisao.objects.create(provisao=provisao, produto="Dipirona", quantidade=Decimal("10"), valor_unitario=Decimal("20"))
    SolicitacaoAprovacao.objects.create(
        provisao=provisao, solicitado_por=comprador, saldo_disponivel_no_pedido=Decimal("100.00"),
        valor_excedente=Decimal("100.00"), fluxo=fluxo, etapa_atual=etapa,
    )
    HistoricoProvisao.objects.create(provisao=provisao, usuario=comprador, acao=HistoricoProvisao.Acao.CRIACAO)

    efetivada = Provisao.objects.create(
        empresa=empresa, filial=filial, comprador=comprador, fornecedor=fornecedor, categoria=categoria,
        data=hoje, valor_total=Decimal("50.00"), status=Provisao.Status.EFETIVADA,
    )
    ItemProvisao.objects.create(provisao=efetivada, produto="Soro", quantidade=Decimal("5"), valor_unitario=Decimal("10"))
    Compra.objects.create(
        empresa=empresa, filial=filial, fornecedor=fornecedor, usuario=comprador, valor=Decimal("50.00"),
        categoria=categoria, data_compra=hoje, provisao_origem=efetivada,
    )
    Notificacao.objects.create(
        usuario=comprador, empresa=empresa, tipo=Notificacao.Tipo.COMPRA_CRIADA, titulo="Compra criada",
    )
    Notificacao.objects.create(
        usuario=proprietario, empresa=empresa, tipo=Notificacao.Tipo.SOLICITACAO_LIMITE, titulo="Aprovação pendente",
    )

    # --- Planejamento --------------------------------------------------
    Receita.objects.create(filial=filial, mes=hoje, faturamento=Decimal("100000.00"))
    ReceitaExtra.objects.create(filial=filial, data=hoje, descricao="Convênio", valor=Decimal("500.00"))
    CustoFixo.objects.create(filial=filial, descricao="Aluguel", valor=Decimal("5000.00"), dia_vencimento=10)
    CustoVariavel.objects.create(filial=filial, descricao="Campanha", valor=Decimal("800.00"), data_prevista=hoje)
    DiaOperacional.objects.create(empresa=empresa, data=hoje, tipo=DiaOperacional.Tipo.FERIADO)
    return empresa


def _movimentacoes(empresa):
    return {
        "compras": Compra.objects.filter(empresa=empresa).count(),
        "parcelas": ParcelaCompra.objects.filter(compra__empresa=empresa).count(),
        "historicos_compra": HistoricoCompra.objects.filter(compra__empresa=empresa).count(),
        "provisoes": Provisao.objects.filter(empresa=empresa).count(),
        "itens_provisao": ItemProvisao.objects.filter(provisao__empresa=empresa).count(),
        "solicitacoes": SolicitacaoAprovacao.objects.filter(provisao__empresa=empresa).count(),
        "historicos_provisao": HistoricoProvisao.objects.filter(provisao__empresa=empresa).count(),
        "notificacoes": Notificacao.objects.filter(empresa=empresa).count(),
    }


def _planejamento(empresa):
    return {
        "receitas": Receita.objects.filter(empresa=empresa).count(),
        "receitas_extras": ReceitaExtra.objects.filter(empresa=empresa).count(),
        "custos_fixos": CustoFixo.objects.filter(empresa=empresa).count(),
        "custos_variaveis": CustoVariavel.objects.filter(empresa=empresa).count(),
        "dias_operacionais": DiaOperacional.objects.filter(empresa=empresa).count(),
    }


def _cadastros(empresa):
    return {
        "empresa": Empresa.objects.filter(pk=empresa.pk, ativo=True).count(),
        "filiais": Filial.objects.filter(empresa=empresa).count(),
        "usuarios": Usuario.objects.filter(empresa=empresa, is_active=True).count(),
        "limite_e_bloqueio_do_comprador": UsuarioEmpresa.objects.filter(
            empresa=empresa, limite_compra=Decimal("1500.00"), bloqueado=True,
        ).count(),
        "perfis_acesso": PerfilAcesso.objects.filter(empresa=empresa).count(),
        "fornecedores": Fornecedor.objects.filter(empresa=empresa).count(),
        "categorias": Categoria.objects.filter(empresa=empresa).count(),
        "centros_custo": CentroCusto.objects.filter(empresa=empresa).count(),
        "configuracao_financeira": ConfiguracaoFinanceira.objects.filter(
            empresa=empresa, percentual_compras=Decimal("35"),
        ).count(),
        "configuracao_plataforma": ConfiguracaoPlataforma.objects.filter(empresa=empresa).count(),
        "identidade_visual": IdentidadeVisual.objects.filter(empresa=empresa).count(),
        "fluxos": FluxoAprovacao.objects.filter(empresa=empresa, ativo=True).count(),
        "etapas": EtapaFluxo.objects.filter(fluxo__empresa=empresa).count(),
        "logs_configuracao": LogConfiguracao.objects.filter(empresa=empresa).count(),
    }


MOVIMENTACOES_POPULADAS = {
    "compras": 2, "parcelas": 2, "historicos_compra": 1, "provisoes": 2, "itens_provisao": 2,
    "solicitacoes": 1, "historicos_provisao": 1, "notificacoes": 2,
}
PLANEJAMENTO_POPULADO = {
    "receitas": 1, "receitas_extras": 1, "custos_fixos": 1, "custos_variaveis": 1, "dias_operacionais": 1,
}
ZERADO_MOV = dict.fromkeys(MOVIMENTACOES_POPULADAS, 0)
ZERADO_PLAN = dict.fromkeys(PLANEJAMENTO_POPULADO, 0)


class LimparMovimentacoesTestCase(TestCase):
    def setUp(self):
        self.alvo = _popular_empresa("Alvo", CNPJ_ALVO)
        self.outra = _popular_empresa("Outra", CNPJ_OUTRA)
        pasta = tempfile.TemporaryDirectory()
        self.addCleanup(pasta.cleanup)
        self.pasta_backup = Path(pasta.name)
        patcher = mock.patch.dict(os.environ, {"BACKUP_DIR": pasta.name})
        patcher.start()
        self.addCleanup(patcher.stop)
        self.cadastros_alvo = _cadastros(self.alvo)
        self.cadastros_outra = _cadastros(self.outra)
        self.auditoria_antes = RegistroAuditoria.objects.count()

    def _rodar(self, *argumentos):
        saida = StringIO()
        call_command("limpar_movimentacoes", *argumentos, stdout=saida)
        return saida.getvalue()

    def _backups(self):
        return sorted(self.pasta_backup.glob("nexbuy_antes_da_limpeza_*.sqlite3"))

    def _outra_intacta(self):
        self.assertEqual(_movimentacoes(self.outra), MOVIMENTACOES_POPULADAS)
        self.assertEqual(_planejamento(self.outra), PLANEJAMENTO_POPULADO)
        self.assertEqual(_cadastros(self.outra), self.cadastros_outra)
        self.assertEqual(RegistroAuditoria.objects.filter(empresa=self.outra).count(), 1)

    # --- Simulação -------------------------------------------------------

    def test_cenario_de_partida(self):
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)
        self.assertEqual(_planejamento(self.alvo), PLANEJAMENTO_POPULADO)

    def test_simulacao_e_o_padrao_e_nao_apaga_nada(self):
        saida = self._rodar("--empresa", CNPJ_ALVO)
        self.assertIn("SIMULAÇÃO", saida)
        self.assertIn("nada foi apagado", saida)
        self.assertIn("--confirmar", saida)
        self.assertRegex(saida, r"Compras\s+2")
        self.assertRegex(saida, r"Notificações\s+2")
        self.assertIn("(mantido)", saida)
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)
        self.assertEqual(_planejamento(self.alvo), PLANEJAMENTO_POPULADO)
        self.assertEqual(RegistroAuditoria.objects.count(), self.auditoria_antes)
        self.assertEqual(self._backups(), [])
        self._outra_intacta()

    def test_simulacao_com_planejamento_tambem_nao_apaga_nada(self):
        saida = self._rodar("--empresa", CNPJ_ALVO, "--incluir-planejamento")
        self.assertIn("SIMULAÇÃO", saida)
        self.assertRegex(saida, r"Receitas mensais\s+1")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)
        self.assertEqual(_planejamento(self.alvo), PLANEJAMENTO_POPULADO)
        self.assertEqual(self._backups(), [])

    # --- Confirmar ---------------------------------------------------------

    def test_confirmar_apaga_so_as_movimentacoes_da_empresa_alvo(self):
        saida = self._rodar("--empresa", CNPJ_ALVO, "--confirmar")
        self.assertIn("Limpeza concluída", saida)
        self.assertEqual(_movimentacoes(self.alvo), ZERADO_MOV)
        # Sem --incluir-planejamento, receitas/custos/calendário ficam.
        self.assertEqual(_planejamento(self.alvo), PLANEJAMENTO_POPULADO)
        self._outra_intacta()

    def test_cadastros_e_configuracoes_sao_mantidos(self):
        self._rodar("--empresa", CNPJ_ALVO, "--confirmar", "--incluir-planejamento")
        self.assertEqual(_cadastros(self.alvo), self.cadastros_alvo)
        self.assertTrue(all(valor >= 1 for valor in _cadastros(self.alvo).values()))
        self._outra_intacta()

    def test_incluir_planejamento_apaga_receitas_custos_e_calendario(self):
        self._rodar("--empresa", CNPJ_ALVO, "--confirmar", "--incluir-planejamento")
        self.assertEqual(_movimentacoes(self.alvo), ZERADO_MOV)
        self.assertEqual(_planejamento(self.alvo), ZERADO_PLAN)
        self._outra_intacta()

    def test_cnpj_sem_mascara_tambem_funciona(self):
        self._rodar("--empresa", re.sub(r"\D", "", CNPJ_ALVO), "--confirmar")
        self.assertEqual(_movimentacoes(self.alvo), ZERADO_MOV)
        self._outra_intacta()

    # --- Backup ------------------------------------------------------------

    def test_backup_consistente_e_criado_antes_de_apagar_e_o_caminho_e_impresso(self):
        saida = self._rodar("--empresa", CNPJ_ALVO, "--confirmar")
        backups = self._backups()
        self.assertEqual(len(backups), 1)
        self.assertRegex(backups[0].name, r"^nexbuy_antes_da_limpeza_\d{4}-\d{2}-\d{2}_\d{6}\.sqlite3$")
        self.assertIn(str(backups[0]), saida)
        conexao = sqlite3.connect(str(backups[0]))
        try:
            self.assertEqual(conexao.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            # A cópia tem o estado de ANTES da limpeza (as compras das duas empresas).
            self.assertEqual(conexao.execute("SELECT COUNT(*) FROM compras_compra").fetchone()[0], 4)
            self.assertEqual(
                conexao.execute(
                    "SELECT COUNT(*) FROM compras_compra WHERE empresa_id = ?", (self.alvo.pk,)
                ).fetchone()[0],
                2,
            )
        finally:
            conexao.close()

    def test_banco_em_memoria_sem_backup_dir_recusa_e_nao_apaga_nada(self):
        """Sem BACKUP_DIR, a cópia vai para a pasta do arquivo do banco
        (`pasta_do_backup`, testada abaixo). O banco de teste é em memória,
        sem pasta: o comando recusa em vez de apagar sem cópia."""
        with mock.patch.dict(os.environ, {"BACKUP_DIR": ""}):
            with self.assertRaisesMessage(CommandError, "BACKUP_DIR"):
                self._rodar("--empresa", CNPJ_ALVO, "--confirmar")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)

    # --- Auditoria -----------------------------------------------------------

    def test_registra_a_limpeza_na_central_de_auditoria_sem_apagar_a_trilha(self):
        self._rodar("--empresa", CNPJ_ALVO, "--confirmar", "--responsavel", "Ana Proprietária")
        self.assertEqual(RegistroAuditoria.objects.count(), self.auditoria_antes + 1)
        # O login registrado antes continua lá (a trilha nunca é apagada).
        self.assertTrue(RegistroAuditoria.objects.filter(
            empresa=self.alvo, categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO,
        ).exists())
        evento = RegistroAuditoria.objects.get(empresa=self.alvo, acao="limpar_movimentacoes")
        self.assertIn(evento.categoria, RegistroAuditoria.Categoria.values)
        self.assertEqual(evento.categoria, RegistroAuditoria.Categoria.CONFIGURACAO_PLATAFORMA_ALTERADA)
        self.assertEqual(evento.modulo, "implantacao")
        self.assertEqual(evento.origem_decisao, RegistroAuditoria.OrigemDecisao.SISTEMA)
        self.assertIn("Ana Proprietária", evento.descricao)
        self.assertIn("Ana Proprietária", evento.justificativa)
        self.assertIn("nexbuy_antes_da_limpeza_", evento.justificativa)
        self.assertEqual(evento.estado_antes["compras"], 2)
        self.assertEqual(evento.estado_antes["provisoes"], 2)
        self.assertEqual(evento.estado_antes["notificacoes"], 2)
        self.assertEqual(set(evento.estado_depois.values()), {0})
        self.assertFalse(RegistroAuditoria.objects.filter(empresa=self.outra, acao="limpar_movimentacoes").exists())

    def test_evento_aparece_na_central_de_auditoria_como_implantacao(self):
        from auditoria.services import listar_eventos_auditoria

        self._rodar("--empresa", CNPJ_ALVO, "--confirmar", "--responsavel", "Suporte")
        pagina = listar_eventos_auditoria(self.alvo)
        eventos = [e for e in pagina if "Limpeza dos dados de teste" in e.descricao]
        self.assertEqual(len(eventos), 1)
        self.assertEqual(eventos[0].origem, "Implantação")

    # --- Erros e segurança ------------------------------------------------------

    def test_cnpj_inexistente_da_erro_claro_e_nao_apaga_nada(self):
        with self.assertRaisesMessage(CommandError, "Nenhuma empresa com o CNPJ 99.888.777/0001-66"):
            self._rodar("--empresa", "99.888.777/0001-66", "--confirmar")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)
        self._outra_intacta()
        self.assertEqual(self._backups(), [])

    def test_cnpj_incompleto_da_erro_claro(self):
        with self.assertRaisesMessage(CommandError, "CNPJ inválido"):
            self._rodar("--empresa", "123", "--confirmar")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)

    def test_empresa_e_obrigatoria(self):
        with self.assertRaises(CommandError):
            self._rodar("--confirmar")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)

    def test_falha_no_meio_desfaz_tudo(self):
        with mock.patch(
            "core.management.commands.limpar_movimentacoes.registrar_evento",
            side_effect=RuntimeError("falha simulada na auditoria"),
        ):
            with self.assertRaises(RuntimeError):
                self._rodar("--empresa", CNPJ_ALVO, "--confirmar", "--incluir-planejamento")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)
        self.assertEqual(_planejamento(self.alvo), PLANEJAMENTO_POPULADO)
        self.assertEqual(RegistroAuditoria.objects.count(), self.auditoria_antes)

    def test_registro_de_outra_empresa_ligado_a_esta_bloqueia_a_limpeza_inteira(self):
        """Dado inconsistente (compra da OUTRA empresa efetivada a partir de
        uma provisão da empresa alvo): apagar a provisão apagaria/quebraria
        um registro alheio — o PROTECT barra e a transação desfaz tudo."""
        provisao_alvo = Provisao.objects.filter(empresa=self.alvo, status=Provisao.Status.AGUARDANDO_APROVACAO).get()
        compra_outra = Compra.objects.filter(empresa=self.outra, provisao_origem__isnull=True).get()
        compra_outra.provisao_origem = provisao_alvo
        compra_outra.save(update_fields=["provisao_origem"])

        with self.assertRaisesMessage(CommandError, "Nada foi apagado"):
            self._rodar("--empresa", CNPJ_ALVO, "--confirmar")
        self.assertEqual(_movimentacoes(self.alvo), MOVIMENTACOES_POPULADAS)
        self.assertEqual(_movimentacoes(self.outra), MOVIMENTACOES_POPULADAS)
        self.assertEqual(RegistroAuditoria.objects.count(), self.auditoria_antes)

    def test_empresa_sem_movimentacoes_nao_gera_backup_nem_evento(self):
        self._rodar("--empresa", CNPJ_ALVO, "--confirmar")
        backups_antes = self._backups()
        auditoria = RegistroAuditoria.objects.count()
        saida = self._rodar("--empresa", CNPJ_ALVO, "--confirmar")
        self.assertIn("Nada para apagar", saida)
        self.assertEqual(self._backups(), backups_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria)

    def test_depois_da_limpeza_as_telas_da_empresa_continuam_abrindo(self):
        self._rodar("--empresa", CNPJ_ALVO, "--confirmar", "--incluir-planejamento")
        proprietario = Usuario.objects.get(username="prop_Alvo")
        self.client.force_login(proprietario)
        with self.settings(ALLOWED_HOSTS=["*"]):
            for url in ("/", "/compras/lista/", "/gestao-compras/", "/financeiro/receitas/", "/ncc/checklist/"):
                with self.subTest(url=url):
                    self.assertEqual(self.client.get(url).status_code, 200)


class CopiaDeSegurancaSqliteTestCase(SimpleTestCase):
    """O caminho da PRODUÇÃO (banco em arquivo): cópia pela API de backup do
    SQLite, por uma conexão separada, com a trava de escrita da limpeza já
    aberta — e nunca presa quando o banco está ocupado."""

    def setUp(self):
        pasta = tempfile.TemporaryDirectory()
        self.addCleanup(pasta.cleanup)
        self.pasta = Path(pasta.name)

    def _banco(self, nome, wal):
        caminho = self.pasta / nome
        conexao = sqlite3.connect(str(caminho), isolation_level=None, check_same_thread=False)
        self.addCleanup(conexao.close)
        if wal:
            conexao.execute("PRAGMA journal_mode=WAL")
        conexao.execute("CREATE TABLE t (x INTEGER)")
        conexao.executemany("INSERT INTO t VALUES (?)", [(1,), (2,), (3,)])
        return conexao, caminho

    def _sem_travar(self, funcao, segundos=30):
        resultado = {}

        def rodar():
            try:
                resultado["valor"] = funcao()
            except BaseException as erro:  # noqa: BLE001 — o teste confere o tipo
                resultado["erro"] = erro

        linha = threading.Thread(target=rodar, daemon=True)
        linha.start()
        linha.join(segundos)
        self.assertFalse(linha.is_alive(), "a cópia de segurança ficou presa")
        return resultado

    def _contar(self, caminho):
        conexao = sqlite3.connect(str(caminho))
        try:
            return (
                conexao.execute("PRAGMA integrity_check").fetchone()[0],
                conexao.execute("SELECT COUNT(*) FROM t").fetchone()[0],
            )
        finally:
            conexao.close()

    def test_copia_com_a_trava_de_escrita_da_limpeza_ja_aberta(self):
        for wal in (True, False):
            with self.subTest(wal=wal):
                dono, caminho = self._banco(f"db_{wal}.sqlite3", wal)
                dono.execute("BEGIN IMMEDIATE")  # a transação do comando
                destino = self.pasta / f"copia_{wal}.sqlite3"
                resultado = self._sem_travar(lambda: copiar_banco_sqlite(str(caminho), str(destino)))
                self.assertNotIn("erro", resultado)
                self.assertEqual(self._contar(destino), ("ok", 3))
                # A transação de quem segura a trava continua valendo.
                dono.execute("DELETE FROM t")
                dono.execute("COMMIT")
                self.assertEqual(dono.execute("SELECT COUNT(*) FROM t").fetchone()[0], 0)
                self.assertEqual(self._contar(destino), ("ok", 3))

    def test_nunca_fica_presa_com_o_banco_ocupado(self):
        dono, caminho = self._banco("ocupado.sqlite3", wal=False)
        dono.execute("BEGIN EXCLUSIVE")
        dono.execute("INSERT INTO t VALUES (4)")
        destino = self.pasta / "copia_ocupado.sqlite3"
        resultado = self._sem_travar(
            lambda: copiar_banco_sqlite(str(caminho), str(destino), espera_maxima=1.0)
        )
        self.assertIsInstance(resultado.get("erro"), TimeoutError)
        dono.execute("ROLLBACK")

    def test_pasta_do_backup(self):
        banco = self.pasta / "db.sqlite3"
        self.assertEqual(pasta_do_backup(str(banco), False, None), self.pasta.resolve())
        self.assertEqual(pasta_do_backup(str(banco), False, "  "), self.pasta.resolve())
        self.assertEqual(pasta_do_backup(str(banco), False, str(self.pasta / "bk")), self.pasta / "bk")
        self.assertEqual(pasta_do_backup(":memory:", True, str(self.pasta)), self.pasta)
        with self.assertRaisesMessage(CommandError, "BACKUP_DIR"):
            pasta_do_backup(":memory:", True, "")


class ScriptsDeLimpezaTestCase(SimpleTestCase):
    """Os dois scripts novos da VPS: fim de linha LF (bytes), cobertos pelo
    .gitattributes e com a ordem de segurança certa."""

    SCRIPTS = ("limpar_dados_de_teste.sh", "zerar_banco.sh")

    def _ler(self, nome):
        return (DEPLOY_DIR / nome).read_bytes()

    def test_scripts_existem_com_lf_shebang_e_modo_estrito(self):
        for nome in self.SCRIPTS:
            with self.subTest(script=nome):
                conteudo = self._ler(nome)
                self.assertNotIn(b"\r", conteudo)
                self.assertFalse(conteudo.startswith(b"\xef\xbb\xbf"))
                self.assertTrue(conteudo.startswith(b"#!/usr/bin/env bash\n"))
                texto = conteudo.decode("utf-8")
                self.assertIn("set -Eeuo pipefail", texto)
                self.assertIn('. "$SCRIPT_DIR/_comum.sh"', texto)
                self.assertIn("exigir_root", texto)

    def test_gitattributes_forca_lf_nos_scripts(self):
        texto = (BASE_DIR / ".gitattributes").read_text(encoding="utf-8")
        self.assertRegex(texto, r"(?m)^\*\.sh\s+text eol=lf\s*$")
        self.assertRegex(texto, r"(?m)^deploy/\*\*\s+text eol=lf\s*$")

    def test_limpar_dados_simula_antes_pede_o_cnpj_de_novo_e_faz_backup(self):
        texto = self._ler("limpar_dados_de_teste.sh").decode("utf-8")
        simulacao = texto.index("nexbuy_manage limpar_movimentacoes")
        confirmacao = texto.index("digite de novo o CNPJ")
        backup = texto.index('bash "$SCRIPT_DIR/backup.sh"')
        limpeza = texto.index("--confirmar", backup)
        self.assertLess(simulacao, confirmacao)
        self.assertLess(confirmacao, backup)
        self.assertLess(backup, limpeza)
        self.assertIn("--incluir-planejamento", texto)
        self.assertIn("--responsavel", texto)

    def test_zerar_banco_para_faz_backup_recria_com_migrate_e_religa(self):
        texto = self._ler("zerar_banco.sh").decode("utf-8")
        parar = texto.index('systemctl stop "$SERVICO"')
        backup = texto.index('bash "$SCRIPT_DIR/backup.sh"')
        migrate = texto.index("nexbuy_manage migrate --noinput")
        religar = texto.index('systemctl start "$SERVICO"', migrate)
        self.assertLess(parar, backup)
        self.assertLess(backup, migrate)
        self.assertLess(migrate, religar)
        self.assertIn("ZERAR", texto)
        self.assertIn("INITIAL_SETUP_TOKEN", texto)
        self.assertIn("/primeiro-acesso/", texto)
        # O banco antigo nunca é apagado: fica guardado ao lado.
        self.assertIn("antes-de-zerar", texto)
        self.assertNotRegex(texto, r'rm -f "\$ZB_BANCO"(\s|$)')
        # Falha no meio (antes do banco novo ficar pronto) devolve o anterior.
        self.assertIn("trap desfazer_se_preciso EXIT", texto)

    def test_nexbuy_manage_continua_aceitando_o_comando_de_limpeza(self):
        texto = self._ler("nexbuy-manage.sh").decode("utf-8")
        self.assertNotIn("limpar_movimentacoes", texto.split("case", 1)[1].split("esac", 1)[0])
