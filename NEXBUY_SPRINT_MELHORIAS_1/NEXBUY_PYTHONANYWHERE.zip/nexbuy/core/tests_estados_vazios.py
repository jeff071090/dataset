"""Estados vazios pós-Primeiro Acesso (Etapa 02 — Cliente-Ready).

Cobre o cenário "o cliente acabou de se cadastrar sozinho": existe Empresa +
Filial + Proprietário (criados pelo fluxo REAL de `/primeiro-acesso/`, não
recriados manualmente) + um usuário de cada outro perfil (Gerente,
Financeiro, Comprador) vinculado à mesma Filial — o suficiente para logar
como cada perfil. Nenhum dado de negócio existe ainda (sem Receita, Custo,
Fornecedor, Categoria, Compra, Provisão etc.) e nenhum destes testes roda
`seed_demo`.

Diferente de um banco 100% vazio de qualquer usuário (só existe antes do
Primeiro Acesso): aqui já existe login, e cada tela precisa se comportar
bem com "quase nada cadastrado ainda" — sem traceback, sem `None`/`NaN`
visível, sem número financeiro enganoso.
"""
import re
from datetime import date, timedelta
from decimal import Decimal

from django.test import Client, TestCase, override_settings

from cadastros.models import CentroCusto, Categoria
from compras.models import Compra, Fornecedor, ParcelaCompra
from core.tests_primeiro_acesso import PAYLOAD_VALIDO, TOKEN, realizar_primeiro_acesso
from empresas.models import Empresa, IdentidadeVisual
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, DiaOperacional, Receita
from gestao_compras.models import Provisao, SolicitacaoAprovacao
from usuarios.models import Usuario, UsuarioEmpresa
from core.utils_testes import garantir_capacidade_no_dia

TERMOS_PROIBIDOS = ("None", "NaN", "Infinity", "Traceback (most recent", "Internal Server Error")

# O valor do csrfmiddlewaretoken é uma string aleatória de 64 caracteres —
# em algumas renderizações ela vai coincidentemente conter "NaN" (ou
# qualquer outro termo proibido de 3 letras) como substring, sem que isso
# tenha qualquer relação com um bug real de estado vazio. Removemos o VALOR
# do token (nunca o campo em si) antes de varrer por termos proibidos, para
# a checagem não ficar refém de um token opaco e aleatório.
_CSRF_TOKEN_VALUE_RE = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class CenarioQuaseVazioTestCase(TestCase):
    """Base reaproveitada por todos os testes deste arquivo."""

    @classmethod
    def setUpTestData(cls):
        client = Client()
        resposta = realizar_primeiro_acesso(client)
        assert resposta.status_code == 302, f"Primeiro Acesso falhou: {resposta.content[:500]}"

        cls.empresa = Empresa.objects.get(cnpj="11222333000181")
        cls.filial = Filial.objects.get(empresa=cls.empresa)
        cls.proprietario = Usuario.objects.get(username="ana.proprietaria")

        cls.gerente = Usuario.objects.create_user(
            username="gerente.teste", password="Teste!2026Forte", perfil=Usuario.Perfil.GERENTE,
            empresa=cls.empresa, filial=cls.filial, first_name="Gerente", last_name="Teste",
        )
        cls.financeiro = Usuario.objects.create_user(
            username="financeiro.teste", password="Teste!2026Forte", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=cls.empresa, filial=cls.filial, first_name="Financeiro", last_name="Teste",
        )
        cls.comprador = Usuario.objects.create_user(
            username="comprador.teste", password="Teste!2026Forte", perfil=Usuario.Perfil.COMPRADOR,
            empresa=cls.empresa, filial=cls.filial, first_name="Comprador", last_name="Teste",
        )

    def get_ok(self, url, usuario=None, msg=None):
        if usuario is not None:
            self.client.force_login(usuario)
        resposta = self.client.get(url)
        self.assertEqual(resposta.status_code, 200, msg or f"{url} -> {resposta.status_code}")
        conteudo = resposta.content.decode("utf-8", errors="replace")
        conteudo_para_varredura = _CSRF_TOKEN_VALUE_RE.sub(r"\1\2", conteudo)
        for termo in TERMOS_PROIBIDOS:
            self.assertNotIn(termo, conteudo_para_varredura, f"{url}: termo proibido '{termo}' encontrado")
        return resposta


class ExploracaoTelas(CenarioQuaseVazioTestCase):
    """Percurso exploratório — cada método visita uma tela/perfil. Falhas
    aqui apontam exatamente qual tela/perfil quebra no cenário quase vazio."""

    def test_dashboard_proprietario(self):
        self.get_ok("/", self.proprietario)

    def test_dashboard_gerente(self):
        self.get_ok("/", self.gerente)

    def test_dashboard_financeiro(self):
        self.get_ok("/", self.financeiro)

    def test_dashboard_comprador(self):
        self.get_ok("/", self.comprador)

    def test_calendario_operacional(self):
        self.get_ok("/financeiro/calendario-operacional/", self.financeiro)
        self.get_ok("/financeiro/calendario-operacional/", self.proprietario)

    def test_calendario_financeiro(self):
        self.get_ok("/financeiro/calendario/", self.financeiro)

    def test_calendario_inteligente_comprador(self):
        self.get_ok("/gestao-compras/", self.comprador)
        self.get_ok("/gestao-compras/", self.proprietario)

    def test_relatorio_por_filial(self):
        self.get_ok("/compras/relatorios/por-filial/", self.proprietario)
        self.get_ok("/compras/relatorios/por-filial/?formato=csv", self.proprietario)

    def test_relatorio_por_comprador(self):
        self.get_ok("/compras/relatorios/por-comprador/", self.proprietario)
        self.get_ok("/compras/relatorios/por-comprador/?formato=csv", self.proprietario)

    def test_lista_compras(self):
        self.get_ok("/compras/lista/", self.proprietario)
        self.get_ok("/compras/lista/", self.comprador)
        self.get_ok("/compras/lista/?formato=csv", self.proprietario)

    def test_central_auditoria(self):
        self.get_ok("/ncc/central-auditoria/", self.proprietario)

    def test_busca_global(self):
        self.get_ok("/buscar/", self.proprietario)
        self.get_ok("/buscar/?q=fornecedor", self.proprietario)
        self.get_ok("/buscar/?q=fornecedor", self.comprador)

    def test_trocar_empresa_dropdown_ausente_com_1_empresa(self):
        resposta = self.get_ok("/", self.proprietario)
        self.assertNotContains(resposta, "Trocar de empresa")

    def test_agenda_financeira(self):
        self.get_ok("/financeiro/agenda/", self.financeiro)
        self.get_ok("/financeiro/agenda/?formato=csv", self.financeiro)

    def test_capacidade_compradores(self):
        self.get_ok("/financeiro/capacidade-compradores/", self.financeiro)

    def test_indicadores(self):
        self.get_ok("/indicadores/", self.proprietario)
        self.get_ok("/indicadores/", self.gerente)
        self.get_ok("/indicadores/", self.financeiro)

    def test_aprovacoes(self):
        self.get_ok("/aprovacoes/", self.gerente)
        self.get_ok("/aprovacoes/", self.proprietario)
        self.get_ok("/aprovacoes/", self.financeiro)

    def test_timeline(self):
        self.get_ok("/timeline/", self.proprietario)

    def test_relatorios_home(self):
        self.get_ok("/relatorios/", self.proprietario)
        self.get_ok("/relatorios/", self.comprador)

    def test_simulacao(self):
        self.get_ok("/compras/simulacao/", self.comprador)

    def test_notificacoes(self):
        self.get_ok("/notificacoes/", self.comprador)

    def test_planejamento(self):
        self.get_ok("/financeiro/planejamento/", self.financeiro)

    def test_parcelamentos(self):
        self.get_ok("/financeiro/parcelamentos/", self.financeiro)

    def test_contas_a_pagar(self):
        self.get_ok("/financeiro/contas-a-pagar/", self.financeiro)

    def test_receitas_custos_list(self):
        self.get_ok("/financeiro/receitas/", self.financeiro)
        self.get_ok("/financeiro/custos-fixos/", self.financeiro)
        self.get_ok("/financeiro/custos-variaveis/", self.financeiro)

    def test_fornecedores_list(self):
        self.get_ok("/compras/fornecedores/", self.financeiro)

    def test_aprovacao_compras_list(self):
        self.get_ok("/compras/aprovacao/", self.gerente)

    def test_aprovacao_provisao_list(self):
        self.get_ok("/gestao-compras/aprovacao/", self.gerente)

    def test_nova_compra_form(self):
        self.get_ok("/compras/nova/", self.comprador)

    def test_nova_provisao_form(self):
        self.get_ok("/gestao-compras/nova/", self.comprador)

    def test_ncc_home_e_usuarios(self):
        self.get_ok("/ncc/", self.proprietario)
        self.get_ok("/ncc/usuarios/", self.proprietario)

    def test_empresa_editar(self):
        self.get_ok("/empresas/", self.proprietario)


class CorrecoesEstadoVazioTestCase(CenarioQuaseVazioTestCase):
    """Regressão dos bugs REAIS encontrados e corrigidos nesta auditoria —
    cada teste aqui falhava (ou teria falhado) antes da correção."""

    def test_hero_do_comprador_nao_mostra_limite_atingido_sem_configuracao(self):
        """Bug: `dashboard/viewmodels.py::viewmodel_comprador` calculava
        `pode_comprar_hoje = (limite_restante > 0)` — sem Receita
        cadastrada, limite e comprado são ambos zero, então a conta dava
        False e o hero mostrava "Limite atingido" em vermelho, uma alarme
        falso logo no primeiro login. Corrigido com o sinal
        `capacidade_configurada` (financeiro/services.py) que troca a
        mensagem por um estado neutro."""
        resposta = self.get_ok("/", self.comprador)
        self.assertContains(resposta, "Sem dado suficiente")
        self.assertNotContains(resposta, "Limite atingido")
        self.assertFalse(resposta.context["capacidade_configurada"])

    def test_central_de_decisao_nao_contradiz_o_hero_sem_configuracao(self):
        """Bug irmão do anterior: a Central de Decisão (`dashboard/insights.py`)
        dizia "Hoje você pode comprar normalmente" (verde) na MESMA tela em
        que o hero dizia "Limite atingido" (vermelho) — duas respostas
        contraditórias para a mesma pergunta. Agora as duas concordam."""
        resposta = self.get_ok("/", self.comprador)
        conteudo = resposta.content.decode()
        self.assertIn("Capacidade financeira ainda não configurada", conteudo)
        self.assertNotIn("Hoje você pode comprar normalmente.", conteudo)
        self.assertNotIn("O saldo disponível está confortável.", conteudo)

    def test_saudacao_do_comprador_nao_afirma_limite_saudavel_sem_configuracao(self):
        # Críticos (rodada 2) — a REGRA do texto mudou: o cabeçalho é do
        # Comprador, que não pode lançar receita; antes mandava ele
        # "cadastrar o faturamento". Agora diz quem precisa agir.
        resposta = self.get_ok("/", self.comprador)
        conteudo = resposta.content.decode()
        self.assertIn("O Financeiro ainda não lançou a receita do mês", conteudo)
        self.assertNotIn("Cadastre o faturamento", conteudo)
        self.assertNotIn("cadastre o faturamento", conteudo)
        self.assertNotIn("Seu limite diário está saudável.", conteudo)

    def test_calendario_inteligente_do_comprador_avisa_capacidade_nao_configurada(self):
        resposta = self.get_ok("/gestao-compras/", self.comprador)
        self.assertContains(resposta, "Capacidade financeira ainda não configurada")
        self.assertFalse(resposta.context["capacidade_configurada"])

    def test_calendario_financeiro_avisa_capacidade_nao_configurada(self):
        resposta = self.get_ok("/financeiro/calendario/", self.financeiro)
        self.assertContains(resposta, "Capacidade financeira ainda não configurada")
        self.assertFalse(resposta.context["capacidade_configurada"])

    def test_capacidade_compradores_nao_mostra_limite_zero_enganoso(self):
        resposta = self.get_ok("/financeiro/capacidade-compradores/", self.financeiro)
        self.assertFalse(resposta.context["capacidade_configurada"])
        conteudo = resposta.content.decode()
        self.assertIn("cadastre o faturamento", conteudo)

    def test_central_auditoria_mostra_evento_de_implantacao_com_origem_correta(self):
        """O evento do Primeiro Acesso (`modulo="implantacao"`) precisa
        aparecer com o rótulo "Implantação" — nunca "Compra" ou
        "Financeiro" por engano (mapeamento em `auditoria/services.py::
        _ORIGEM_POR_MODULO`, já correto; este teste é a trava de
        regressão)."""
        resposta = self.get_ok("/ncc/central-auditoria/", self.proprietario)
        conteudo = resposta.content.decode()
        self.assertIn("Implantação", conteudo)
        eventos = list(resposta.context["pagina_eventos"])
        implantacao = [e for e in eventos if "Primeiro acesso" in e.descricao]
        self.assertEqual(len(implantacao), 1)
        self.assertEqual(implantacao[0].origem, "Implantação")

    def test_capacidade_configurada_fica_verdadeira_depois_de_cadastrar_receita(self):
        """Confere que o sinal muda para True assim que existe Receita — e
        que a mensagem de estado vazio desaparece, sem alterar nenhuma
        fórmula (o valor calculado continua o mesmo de sempre)."""
        from datetime import date

        from financeiro.models import Receita

        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("50000.00"))

        resposta = self.get_ok("/", self.comprador)
        self.assertTrue(resposta.context["capacidade_configurada"])
        self.assertNotContains(resposta, "Sem dado suficiente")
        self.assertNotContains(resposta, "Capacidade financeira ainda não configurada")


class CadastroCompletoTestCase(CenarioQuaseVazioTestCase):
    """Passo 4 — auditoria de completude: cada fluxo de cadastro abaixo é
    exercido de ponta a ponta SÓ pela interface (Django test Client em
    URLs reais, nunca ORM direto simulando o formulário), a partir do
    cenário pós-Primeiro Acesso — sem `seed_demo`, sem `/admin`, sem shell.
    Prova que nenhuma tela depende de uma Categoria/Fornecedor/Filial
    específica do seed: tudo aqui é criado do zero pelo próprio teste."""

    def test_categoria_e_centro_de_custo_cadastrados_via_interface(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.post(
            "/cadastros/categorias/nova/",
            {"nome": "Insumos Agrícolas", "icone": "bi-tags", "cor": "#042C53", "ativo": "on"},
        )
        self.assertRedirects(resposta, "/cadastros/categorias/")
        self.assertTrue(Categoria.objects.filter(empresa=self.empresa, nome="Insumos Agrícolas").exists())

        resposta = self.client.post(
            "/cadastros/centros-custo/novo/", {"nome": "Administrativo", "ativo": "on"}
        )
        self.assertRedirects(resposta, "/cadastros/centros-custo/")
        self.assertTrue(CentroCusto.objects.filter(empresa=self.empresa, nome="Administrativo").exists())

    def test_fornecedor_cadastrado_via_interface(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.post(
            "/compras/fornecedores/novo/",
            {
                "nome": "Fornecedor Teste Ltda", "razao_social": "Fornecedor Teste Ltda ME",
                "cnpj": "12.345.678/0001-95", "cidade": "Cuiabá", "estado": "MT", "ativo": "on",
            },
        )
        self.assertRedirects(resposta, "/compras/fornecedores/")
        self.assertTrue(Fornecedor.objects.filter(empresa=self.empresa, nome="Fornecedor Teste Ltda").exists())

    def test_receita_custo_fixo_custo_variavel_cadastrados_via_interface(self):
        self.client.force_login(self.financeiro)
        hoje = date.today()
        resposta = self.client.post(
            "/financeiro/receitas/nova/",
            {"filial": self.filial.pk, "mes": hoje.replace(day=1).isoformat(), "faturamento": "100000,00"},
        )
        self.assertRedirects(resposta, "/financeiro/receitas/")
        self.assertTrue(Receita.objects.filter(filial=self.filial).exists())

        resposta = self.client.post(
            "/financeiro/custos-fixos/novo/",
            {
                "filial": self.filial.pk, "descricao": "Aluguel do galpão", "valor": "3500,00",
                "dia_vencimento": "10", "ativo": "on",
            },
        )
        self.assertRedirects(resposta, "/financeiro/custos-fixos/")
        self.assertTrue(CustoFixo.objects.filter(filial=self.filial, descricao="Aluguel do galpão").exists())

        resposta = self.client.post(
            "/financeiro/custos-variaveis/novo/",
            {
                "filial": self.filial.pk, "descricao": "Frete extra", "valor": "800,00",
                "data_prevista": (hoje + timedelta(days=5)).isoformat(),
            },
        )
        self.assertRedirects(resposta, "/financeiro/custos-variaveis/")
        self.assertTrue(CustoVariavel.objects.filter(filial=self.filial, descricao="Frete extra").exists())

    def test_configuracao_financeira_editada_via_interface(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.post(
            "/financeiro/configuracao/",
            {
                "percentual_compras": "35", "percentual_seguranca": "5",
                "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
                "moeda": ConfiguracaoFinanceira.Moeda.BRL, "cor_principal": "#042C53",
            },
        )
        self.assertRedirects(resposta, "/financeiro/configuracao/")
        config = ConfiguracaoFinanceira.objects.get(empresa=self.empresa)
        self.assertEqual(config.percentual_compras, Decimal("35"))
        self.assertEqual(config.regra_excesso, ConfiguracaoFinanceira.RegraExcesso.APROVACAO)

    def test_calendario_operacional_excecao_cadastrada_via_interface(self):
        self.client.force_login(self.proprietario)
        hoje = date.today()
        dia_excecao = date(hoje.year, hoje.month, min(hoje.day + 2, 28))
        resposta = self.client.post(
            "/financeiro/calendario-operacional/",
            {"data": dia_excecao.isoformat(), "tipo": DiaOperacional.Tipo.FERIADO, "observacao": "Feriado municipal"},
        )
        self.assertEqual(resposta.status_code, 302)
        self.assertTrue(DiaOperacional.objects.filter(empresa=self.empresa, data=dia_excecao).exists())

    def test_novo_usuario_perfis_permissoes_senha_provisoria_e_desativacao_via_interface(self):
        """Cadastro completo de um Comprador novo: criação, vínculo de
        filial autorizada (RBAC), geração de senha provisória e
        ativar/desativar — tudo por `/ncc/usuarios/`."""
        self.client.force_login(self.proprietario)
        resposta = self.client.post(
            "/ncc/usuarios/novo/",
            {
                "first_name": "Novo", "last_name": "Comprador", "email": "novo.comprador@example.com",
                "username": "novo.comprador", "filial": self.filial.pk, "perfil": Usuario.Perfil.COMPRADOR,
                "is_active": "on", "senha_inicial": "SenhaForteTeste123",
            },
        )
        self.assertEqual(resposta.status_code, 302)
        novo = Usuario.objects.get(username="novo.comprador")
        self.assertEqual(novo.perfil, Usuario.Perfil.COMPRADOR)
        self.assertTrue(novo.check_password("SenhaForteTeste123"))

        # Permissões/RBAC — vincula a filial autorizada (obrigatório para não-Proprietário ativo).
        resposta = self.client.post(
            f"/ncc/usuarios/{novo.pk}/",
            {
                "salvar_permissoes": "1",
                "filiais_autorizadas": [self.filial.pk],
                "limite_compra": "",
            },
        )
        self.assertRedirects(resposta, "/ncc/usuarios/")
        self.assertTrue(novo.vinculos_filial.filter(filial=self.filial, ativo=True).exists())

        # Senha provisória.
        resposta = self.client.post(f"/ncc/usuarios/{novo.pk}/", {"gerar_senha": "1"})
        self.assertEqual(resposta.status_code, 302)

        # Desativar.
        resposta = self.client.post(
            f"/ncc/usuarios/{novo.pk}/",
            {
                "salvar_dados": "1", "first_name": "Novo", "last_name": "Comprador",
                "email": "novo.comprador@example.com", "perfil": Usuario.Perfil.COMPRADOR,
                "filial": self.filial.pk,
                # is_active OMITIDO de propósito = desmarcado (checkbox).
            },
        )
        self.assertEqual(resposta.status_code, 302)
        novo.refresh_from_db()
        self.assertFalse(novo.is_active)

    def test_nova_filial_com_dados_fiscais_e_ativar_desativar_via_interface(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.post(
            "/ncc/filiais/nova/",
            {
                "nome": "Filial Norte", "razao_social": "Empresa Teste Etapa 02 Ltda",
                "cnpj": "11.222.333/0002-62", "tipo_estabelecimento": "filial",
                "cidade": "Sinop", "estado": "MT", "ativo": "on",
            },
        )
        self.assertEqual(resposta.status_code, 302)
        filial_nova = Filial.objects.get(empresa=self.empresa, nome="Filial Norte")
        self.assertTrue(filial_nova.ativo)

        # Desativar a filial recém-criada.
        resposta = self.client.post(
            f"/ncc/filiais/{filial_nova.pk}/",
            {
                "nome": "Filial Norte", "razao_social": "Empresa Teste Etapa 02 Ltda",
                "cnpj": "11.222.333/0002-62", "tipo_estabelecimento": "filial",
                "cidade": "Sinop", "estado": "MT",
                # ativo OMITIDO = desativa.
            },
        )
        self.assertEqual(resposta.status_code, 302)
        filial_nova.refresh_from_db()
        self.assertFalse(filial_nova.ativo)

    def test_identidade_visual_editada_via_interface(self):
        self.client.force_login(self.proprietario)
        resposta = self.client.post(
            "/empresas/identidade-visual/",
            {"nome_exibicao": "Empresa Teste — Nome de Exibição", "cor_secundaria": "#EF9F27"},
        )
        self.assertRedirects(resposta, "/empresas/identidade-visual/")
        identidade = IdentidadeVisual.objects.get(empresa=self.empresa)
        self.assertEqual(identidade.nome_exibicao, "Empresa Teste — Nome de Exibição")

    def test_fluxo_completo_de_compra_dentro_e_acima_do_limite_com_aprovacao(self):
        """Confirma que o ciclo de Compra funciona com Categoria/Fornecedor
        criados NESTE teste (nunca IDs fixos de um seed): faturamento alto
        o bastante para dar folga no dia, uma compra dentro do limite
        (aprovada direto) e uma acima (vai para aprovação do Gerente)."""
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("300000.00"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(self.empresa)
        # Regra padrão sem configuração explícita é "alerta" (aprova e avisa)
        # — para exercitar de verdade o caminho "acima do limite vai para
        # aprovação do Gerente", a empresa precisa ter ligado essa regra.
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
        )
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Insumos")
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor XPTO", cnpj="00000000000191")

        self.client.force_login(self.comprador)
        resposta = self.client.post(
            "/compras/nova/",
            {
                "filial": self.filial.pk, "fornecedor": fornecedor.pk, "valor": "100,00",
                "categoria": categoria.pk, "data_compra": date.today().isoformat(),
                "prazo_pagamento": Compra.PrazoPagamento.AVISTA, "numero_parcelas": 1,
            },
        )
        self.assertRedirects(resposta, "/compras/lista/")
        compra_pequena = Compra.objects.get(fornecedor=fornecedor, valor=Decimal("100.00"))
        self.assertEqual(compra_pequena.status, Compra.Status.APROVADA)

        resposta = self.client.post(
            "/compras/nova/",
            {
                "filial": self.filial.pk, "fornecedor": fornecedor.pk, "valor": "999999,00",
                "categoria": categoria.pk, "data_compra": date.today().isoformat(),
                "prazo_pagamento": Compra.PrazoPagamento.AVISTA, "numero_parcelas": 1,
            },
        )
        self.assertRedirects(resposta, "/compras/lista/")
        compra_grande = Compra.objects.get(fornecedor=fornecedor, valor=Decimal("999999.00"))
        self.assertIn(compra_grande.status, (Compra.Status.PENDENTE, Compra.Status.BLOQUEADA))

        if compra_grande.status == Compra.Status.PENDENTE:
            self.client.force_login(self.gerente)
            resposta = self.client.post(f"/compras/aprovacao/{compra_grande.pk}/aprovar/")
            self.assertEqual(resposta.status_code, 302)
            compra_grande.refresh_from_db()
            self.assertEqual(compra_grande.status, Compra.Status.APROVADA)

    def test_fluxo_completo_de_provisao_criacao_aprovacao_e_efetivacao(self):
        """Provisão acima do saldo do dia -> Solicitação de Aprovação ->
        Gerente aprova -> Financeiro efetiva em Compra real."""
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("50000.00"))
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Manutenção")
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Oficina Central", cnpj="00000000000272")

        self.client.force_login(self.comprador)
        payload = {
            "filial": self.filial.pk, "fornecedor": fornecedor.pk, "categoria": categoria.pk,
            "data": date.today().isoformat(), "observacoes": "",
            "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0",
            "itens-MIN_NUM_FORMS": "1", "itens-MAX_NUM_FORMS": "1000",
            "itens-0-produto": "Peça de reposição", "itens-0-quantidade": "1",
            "itens-0-valor_unitario": "999999,00",
        }
        resposta = self.client.post("/gestao-compras/nova/", payload)
        self.assertRedirects(resposta, "/gestao-compras/")
        provisao = Provisao.objects.get(fornecedor=fornecedor)
        self.assertEqual(provisao.status, Provisao.Status.AGUARDANDO_APROVACAO)
        solicitacao = SolicitacaoAprovacao.objects.get(provisao=provisao)

        self.client.force_login(self.gerente)
        resposta = self.client.post(f"/gestao-compras/aprovacao/{solicitacao.pk}/aprovar/")
        self.assertEqual(resposta.status_code, 302)
        provisao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.APROVADA)

        self.client.force_login(self.financeiro)
        resposta = self.client.post(
            f"/gestao-compras/provisao/{provisao.pk}/efetivar/",
            {"prazo_pagamento": Compra.PrazoPagamento.AVISTA, "numero_parcelas": 1},
        )
        self.assertEqual(resposta.status_code, 302)
        provisao.refresh_from_db()
        self.assertEqual(provisao.status, Provisao.Status.EFETIVADA)
        self.assertTrue(Compra.objects.filter(provisao_origem=provisao).exists())

    def test_capacidade_do_comprador_limite_bloqueio_e_liberacao_via_interface(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.post(
            f"/financeiro/capacidade-compradores/{self.comprador.pk}/limite/",
            {"filial": self.filial.pk, "limite": "1.500,00"},
        )
        self.assertEqual(resposta.status_code, 302)
        autorizacao = UsuarioEmpresa.objects.get(usuario=self.comprador, empresa=self.empresa)
        self.assertEqual(autorizacao.limite_compra, Decimal("1500.00"))

        resposta = self.client.post(
            f"/financeiro/capacidade-compradores/{self.comprador.pk}/bloquear/", {"filial": self.filial.pk}
        )
        self.assertEqual(resposta.status_code, 302)
        autorizacao.refresh_from_db()
        self.assertTrue(autorizacao.bloqueado)

        resposta = self.client.post(
            f"/financeiro/capacidade-compradores/{self.comprador.pk}/liberar/", {"filial": self.filial.pk}
        )
        self.assertEqual(resposta.status_code, 302)
        autorizacao.refresh_from_db()
        self.assertFalse(autorizacao.bloqueado)

    def test_baixa_e_estorno_de_parcela_com_justificativa_via_interface(self):
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("300000.00"))
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Diversos")
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Parcelado", cnpj="00000000000353")
        compra = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=fornecedor, usuario=self.comprador,
            valor=Decimal("300.00"), categoria=categoria, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, status=Compra.Status.APROVADA,
        )
        parcela = ParcelaCompra.objects.create(
            compra=compra, numero=1, valor=Decimal("300.00"),
            data_vencimento=date.today(), status=ParcelaCompra.Status.PENDENTE,
        )

        self.client.force_login(self.financeiro)
        resposta = self.client.post(f"/financeiro/agenda/parcela/{parcela.pk}/baixar/")
        self.assertRedirects(resposta, "/financeiro/agenda/")
        parcela.refresh_from_db()
        self.assertEqual(parcela.status, ParcelaCompra.Status.PAGA)

        resposta = self.client.post(
            f"/financeiro/agenda/parcela/{parcela.pk}/estornar/",
            {"justificativa": "Baixa lançada por engano."},
        )
        self.assertRedirects(resposta, "/financeiro/agenda/")
        parcela.refresh_from_db()
        self.assertEqual(parcela.status, ParcelaCompra.Status.PENDENTE)
