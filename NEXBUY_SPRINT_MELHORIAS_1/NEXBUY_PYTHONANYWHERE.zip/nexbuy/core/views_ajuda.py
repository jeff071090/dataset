"""Central de Ajuda (/ajuda/) — o manual do sistema dentro do próprio NEXBUY.

Escrita para o usuário final (não técnico): a farmácia vai começar a usar
o sistema do zero, sozinha, e cada pessoa precisa entender o que é seu.

Regras desta tela:

1. Login obrigatório; os 4 perfis entram. O conteúdo se adapta ao perfil
   logado — cada seção só é renderizada para quem a usa.
2. O Comprador vê SÓ o que é dele (compras, provisões, calendário de
   compras, simulador, aprovações do ponto de vista de quem pede, relatórios
   e perguntas frequentes). As seções de planejamento financeiro, agenda e
   Análise Financeira nunca chegam ao HTML do Comprador — nem escondidas.
3. Todo link para uma tela do sistema passa pelo MESMO gate da view de
   destino (`permissao=` para `@permissao_required`, `perfis=` para
   `@perfil_required`/`PerfilRequiredMixin`) — a regra de ouro de
   `core/navegacao.py`. Um destino negado vira texto ("fale com o
   administrador"), nunca um link que dê 403.

Nenhum dado de negócio é lido ou gravado aqui: a tela só explica.
"""
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.urls import reverse

from core.navegacao import montar_navegacao
from core.permissions import (
    PERFIS_ANALISE_FINANCEIRA,
    PERFIS_APROVADORES_PROVISAO,
    PERFIS_GESTORES_FINANCEIROS,
    TODOS_OS_PERFIS,
    permissoes_do_usuario,
)
from usuarios.models import Usuario

PROPRIETARIO = Usuario.Perfil.PROPRIETARIO
GERENTE = Usuario.Perfil.GERENTE
FINANCEIRO = Usuario.Perfil.FINANCEIRO
COMPRADOR = Usuario.Perfil.COMPRADOR

# Gates por perfil copiados das views de destino (fonte: o decorator/mixin
# de cada uma — conferido em financeiro/views.py, compras/views.py,
# cadastros/views.py, gestao_compras/views.py e dashboard/views.py).
_PROP_FIN = PERFIS_GESTORES_FINANCEIROS                  # financeiro PERFIS_VISUALIZACAO/CADASTRO
_GESTORES = (PROPRIETARIO, GERENTE, FINANCEIRO)          # compras PERFIS_GESTORES (relatórios)
_SIMULACAO = (PROPRIETARIO, FINANCEIRO, COMPRADOR)       # compras PERFIS_SIMULACAO
# Aprovações e Indicadores: a view aceita Proprietário, Gerente e
# Financeiro, mas o MENU só mostra para Proprietário e Gerente — a ajuda
# segue o menu (subconjunto do gate da view: nunca 403 e nunca um link que
# o menu do perfil não tem).
_APROVACOES_MENU = (PROPRIETARIO, GERENTE)

# (chave, rótulo, url_name, ícone, permissao, perfis)
DESTINOS = (
    ("inicio", "Início (seu painel)", "dashboard:home", "bi-speedometer2", None, None),
    ("meu_perfil", "Meu Perfil", "meu_perfil", "bi-person-circle", None, None),
    ("notificacoes", "Notificações", "notificacoes:lista", "bi-bell", None, None),
    ("busca", "Pesquisar no sistema", "busca_global", "bi-search", None, None),
    ("bem_vindo", "Bem-vindo ao NEXBUY", "bem_vindo", "bi-info-circle", None, None),
    # Gestão / Configurações (NEXBUY Control Center)
    ("empresa", "Dados da Empresa", "empresas:editar", "bi-building", "empresa.gerenciar", None),
    ("identidade", "Identidade Visual", "empresas:identidade_visual", "bi-palette", "empresa.gerenciar", None),
    ("estrutura", "Empresas e Filiais", "ncc:estrutura", "bi-diagram-3", "ncc.acessar", None),
    ("filiais", "Filiais", "ncc:filiais", "bi-shop", "filiais.gerenciar", None),
    ("usuarios", "Usuários e Permissões", "ncc:usuarios", "bi-people", "ncc.acessar", None),
    ("usuario_novo", "Novo Usuário", "ncc:usuario_novo", "bi-person-plus", "ncc.acessar", None),
    ("perfis_acesso", "Perfis de Acesso", "ncc:perfis", "bi-shield-lock", "ncc.acessar", None),
    ("ncc", "Centro de Configurações", "ncc:home", "bi-sliders", "ncc.acessar", None),
    ("gerais", "Configurações Gerais", "ncc:gerais", "bi-gear", "ncc.acessar", None),
    ("checklist", "Checklist de Implantação", "ncc:checklist", "bi-list-check", "ncc.acessar", None),
    ("workflow", "Workflow de Aprovações", "ncc:workflow", "bi-diagram-2", "workflow.configurar", None),
    ("integracoes", "Integrações", "ncc:integracoes", "bi-plug", "ncc.acessar", None),
    ("auditoria", "Auditoria do Sistema", "ncc:auditoria", "bi-journal-check", "ncc.acessar", None),
    # Cadastros de apoio
    ("categorias", "Categorias", "cadastros:categoria_list", "bi-tags", None, _PROP_FIN),
    ("centros_custo", "Centros de Custo", "cadastros:centrocusto_list", "bi-bullseye", None, _PROP_FIN),
    ("fornecedores", "Fornecedores", "compras:fornecedor_list", "bi-truck", None, _PROP_FIN),
    # Planejamento financeiro
    ("planejamento", "Planejamento Financeiro", "financeiro:planejamento", "bi-compass", "financeiro.ver", None),
    ("configuracao", "Capacidade Financeira", "financeiro:configuracao", "bi-cpu", None, _PROP_FIN),
    ("receitas", "Receitas", "financeiro:receita_list", "bi-cash-coin", None, _PROP_FIN),
    ("receita_nova", "Nova receita mensal", "financeiro:receita_create", "bi-plus-circle", None, _PROP_FIN),
    ("receitas_extras", "Receitas extras", "financeiro:receitaextra_list", "bi-cash-stack", None, _PROP_FIN),
    ("custos_fixos", "Custos Fixos", "financeiro:custofixo_list", "bi-receipt", None, _PROP_FIN),
    ("custos_variaveis", "Custos Variáveis", "financeiro:custovariavel_list", "bi-arrow-left-right", None, _PROP_FIN),
    ("calendario_operacional", "Calendário Operacional", "financeiro:calendario_operacional",
     "bi-calendar2-x", "calendario.configurar", None),
    ("compradores", "Compradores e Limites", "financeiro:capacidade_compradores", "bi-people-fill",
     "capacidade.gerenciar", None),
    ("calendario_financeiro", "Calendário Financeiro", "financeiro:calendario_financeiro", "bi-calendar3",
     "financeiro.ver", None),
    ("agenda", "Agenda Financeira", "financeiro:agenda", "bi-calendar2-week", "agenda.ver", None),
    ("contas_a_pagar", "Contas a Pagar", "financeiro:contas_a_pagar", "bi-receipt-cutoff", "financeiro.ver", None),
    ("parcelamentos", "Parcelamentos", "financeiro:parcelamentos", "bi-credit-card-2-front", "financeiro.ver", None),
    ("timeline", "Timeline Financeira", "dashboard:timeline", "bi-graph-up", "timeline.ver", None),
    # Análise Financeira
    ("analise_dre", "DRE Gerencial", "financeiro:analise_dre", "bi-table", None, PERFIS_ANALISE_FINANCEIRA),
    ("analise_creditos", "Créditos × Débitos", "financeiro:analise_creditos_debitos", "bi-arrow-left-right",
     None, PERFIS_ANALISE_FINANCEIRA),
    ("analise_saude", "Saúde Financeira", "financeiro:analise_saude", "bi-heart-pulse",
     None, PERFIS_ANALISE_FINANCEIRA),
    # Compras e provisões
    ("nova_compra", "Nova Compra", "compras:nova", "bi-plus-circle-fill", "compras.lancar", None),
    ("historico", "Histórico de Compras", "compras:lista", "bi-clock-history", None, TODOS_OS_PERFIS),
    ("simulador", "Simulador", "compras:simulacao", "bi-calculator", None, _SIMULACAO),
    ("calendario_compras", "Calendário de Compras", "gestao_compras:calendario", "bi-calendar3",
     "calendario.ver", None),
    ("nova_provisao", "Nova Provisão", "gestao_compras:nova_provisao", "bi-calendar-plus", "provisoes.criar", None),
    # Aprovações
    ("aprovacoes", "Aprovações", "dashboard:aprovacoes", "bi-check2-square", None, _APROVACOES_MENU),
    ("aprovacao_compras", "Compras acima do limite", "compras:aprovacao", "bi-cart-x", "compras.aprovar", None),
    ("aprovacao_provisoes", "Provisões para decidir", "gestao_compras:aprovacao_list", "bi-hourglass-split",
     None, PERFIS_APROVADORES_PROVISAO),
    # Relatórios
    ("indicadores", "Indicadores", "dashboard:indicadores", "bi-graph-up-arrow", None, _APROVACOES_MENU),
    ("relatorios", "Central de Relatórios", "relatorios", "bi-file-earmark-bar-graph", "relatorios.ver", None),
    ("rel_filial", "Compras por Filial", "compras:relatorio_por_filial", "bi-shop", None, _GESTORES),
    ("rel_comprador", "Compras por Comprador", "compras:relatorio_por_comprador", "bi-person-lines-fill",
     None, _GESTORES),
)

# Seções do manual: (id, título, ícone, perfis que a recebem). O Comprador
# fica de fora de toda seção com dado financeiro da empresa.
SECOES = (
    ("comece", "Comece por aqui", "bi-flag", TODOS_OS_PERFIS),
    ("primeiros-passos", "Primeiros passos da implantação", "bi-rocket-takeoff", _PROP_FIN),
    ("planejamento", "Planejamento financeiro", "bi-compass", _PROP_FIN),
    ("compras", "Compras e provisões", "bi-cart-check", TODOS_OS_PERFIS),
    ("aprovacoes", "Aprovações", "bi-check2-square", TODOS_OS_PERFIS),
    ("agenda", "Agenda financeira e contas a pagar", "bi-calendar2-week", _GESTORES),
    ("analise", "Análise Financeira", "bi-graph-up-arrow", PERFIS_ANALISE_FINANCEIRA),
    ("relatorios", "Relatórios e impressão", "bi-printer", TODOS_OS_PERFIS),
    ("faq", "Perguntas frequentes", "bi-question-circle", TODOS_OS_PERFIS),
)


def _permitido(user, perms, permissao, perfis):
    """O MESMO teste da view de destino.

    - `perfis` (views com `perfil_required`/`PerfilRequiredMixin`): só o
      perfil conta — esses decorators não abrem exceção nem para
      superusuário, então a ajuda também não abre.
    - `permissao` (views com `permissao_required`): RBAC aditivo, igual a
      `usuario_tem_permissao` (superusuário passa).
    """
    if perfis is not None:
        return user.perfil in perfis
    if permissao:
        return user.is_superuser or permissao in perms
    return True


def _caminhos_no_menu(user, request):
    """{url: "Grupo › Item"} a partir do menu REAL do usuário — a ajuda
    ensina o caminho exato que a pessoa vai ver na barra lateral."""
    caminhos = {}
    for entrada in montar_navegacao(user, request):
        if entrada.get("link_unico"):
            caminhos.setdefault(entrada["url"], entrada["rotulo"])
            continue
        for item in entrada["itens"]:
            caminhos.setdefault(item["url"], f'{entrada["rotulo"]} › {item["rotulo"]}')
    return caminhos


def links_da_ajuda(user, request):
    """Só os destinos que este usuário pode abrir — os demais nem entram no
    dicionário (o template mostra texto no lugar do link)."""
    perms = permissoes_do_usuario(user)
    caminhos = _caminhos_no_menu(user, request)
    links = {}
    for chave, rotulo, url_name, icone, permissao, perfis in DESTINOS:
        if not _permitido(user, perms, permissao, perfis):
            continue
        url = reverse(url_name)
        links[chave] = {"rotulo": rotulo, "url": url, "icone": icone, "menu": caminhos.get(url, "")}
    return links


# A seção da Agenda só aparece para quem abre ao menos uma das telas dela
# (o Gerente só tem Agenda quando o administrador concede a permissão).
_TELAS_DA_AGENDA = ("agenda", "contas_a_pagar", "parcelamentos")


def secoes_do_perfil(perfil, links):
    secoes = []
    for id_secao, titulo, icone, perfis in SECOES:
        if perfil not in perfis:
            continue
        if id_secao == "agenda" and not any(chave in links for chave in _TELAS_DA_AGENDA):
            continue
        secoes.append({"id": id_secao, "titulo": titulo, "icone": icone})
    return secoes


_NOMES_REFERENCIAS = (
    ("margem_bruta", "Margem bruta"),
    ("peso_compras", "Peso das compras na receita"),
    ("peso_custos_fixos", "Peso dos custos fixos"),
    ("margem_contribuicao", "Margem de contribuição"),
    ("margem_operacional", "Margem operacional (resultado)"),
    ("margem_seguranca", "Margem de segurança"),
    ("comprometimento_30d", "Comprometimento dos próximos 30 dias"),
)


def _pct(valor):
    texto = f"{valor:.1f}".replace(".", ",")
    return (texto[:-2] if texto.endswith(",0") else texto) + "%"


def referencias_de_mercado():
    """Faixas do semáforo da Saúde Financeira lidas da MESMA fonte da tela
    (`financeiro.services_analise.REFERENCIAS_MERCADO`) — a ajuda nunca
    fica desatualizada em relação ao cálculo."""
    from financeiro.services_analise import FONTES_REFERENCIA, REFERENCIAS_MERCADO

    linhas = []
    for chave, nome in _NOMES_REFERENCIAS:
        ref = REFERENCIAS_MERCADO.get(chave)
        if ref is None:
            continue
        maior = ref["sentido"] == "maior"
        linhas.append({
            "nome": nome,
            "saudavel": f'{"a partir de" if maior else "até"} {_pct(ref["saudavel"])}',
            "critico": f'{"abaixo de" if maior else "acima de"} {_pct(ref["critico"])}',
            "fontes": ", ".join(FONTES_REFERENCIA[codigo]["nome_curto"] for codigo in ref["fontes"]),
        })
    return linhas


@login_required
def central_ajuda(request):
    user = request.user
    perfil = user.perfil
    links = links_da_ajuda(user, request)
    secoes = secoes_do_perfil(perfil, links)
    mostrar = {secao["id"].replace("-", "_"): True for secao in secoes}
    contexto = {
        "secoes": secoes,
        "mostrar": mostrar,
        "links": links,
        "referencias": referencias_de_mercado() if mostrar.get("analise") else [],
        "titulo_impressao": f"Manual do sistema — perfil {user.get_perfil_display()}",
        "perfil": perfil,
        "perfil_rotulo": user.get_perfil_display(),
        "eh_proprietario": perfil == PROPRIETARIO,
        "eh_gerente": perfil == GERENTE,
        "eh_financeiro": perfil == FINANCEIRO,
        "eh_comprador": perfil == COMPRADOR,
    }
    return render(request, "core/ajuda/central.html", contexto)
