"""Backup diário automático feito pelo próprio site (core/backup_diario.py).

A conta grátis do PythonAnywhere (criada depois de 15/01/2026) não tem
"scheduled tasks"; com os dados reais da farmácia no servidor, o NEXBUY faz
sozinho uma cópia por dia, no primeiro acesso do dia. Aqui tudo roda com
bancos SQLite DE VERDADE numa pasta temporária — nunca o banco do projeto.

O banco copiado nos testes é um arquivo próprio do teste (a função
`caminho_do_banco` é trocada), porque o banco de testes do Django é em
memória. O dia é controlado trocando `core.backup_diario._agora`.
"""
import io
import logging
import os
import sqlite3
import stat
import tempfile
import time
from datetime import datetime, timedelta
from datetime import timezone as dt_timezone
from unittest import mock

from django.core.exceptions import MiddlewareNotUsed
from django.core.management import call_command
from django.core.management.base import CommandError
from django.http import HttpResponse
from django.test import Client, RequestFactory, SimpleTestCase, TestCase, override_settings
from django.utils import timezone

from core import backup_diario
from core.tests_producao import carregar_settings

FUSO = timezone.get_default_timezone()  # America/Cuiaba


def _momento(dia, hora=9, minuto=0):
    """Instante (aware) num dia/hora de Cuiabá."""
    return datetime(dia.year, dia.month, dia.day, hora, minuto, tzinfo=FUSO)


DIA = datetime(2026, 10, 6).date()
OUTRO_DIA = DIA + timedelta(days=1)


def _criar_banco(caminho, linhas=200):
    conexao = sqlite3.connect(caminho)
    try:
        conexao.execute("CREATE TABLE compra (id INTEGER PRIMARY KEY, fornecedor TEXT, valor REAL)")
        conexao.executemany(
            "INSERT INTO compra (fornecedor, valor) VALUES (?, ?)",
            [(f"Fornecedor {i}", i * 10.5) for i in range(linhas)],
        )
        conexao.commit()
    finally:
        conexao.close()


def _contar_linhas(caminho):
    conexao = sqlite3.connect(caminho)
    try:
        return conexao.execute("SELECT COUNT(*) FROM compra").fetchone()[0]
    finally:
        conexao.close()


def _integridade(caminho):
    conexao = sqlite3.connect(caminho)
    try:
        return conexao.execute("PRAGMA integrity_check").fetchone()[0]
    finally:
        conexao.close()


def _tocar(caminho, conteudo=b"x"):
    with open(caminho, "wb") as arquivo:
        arquivo.write(conteudo)


class AmbienteDeBackupMixin:
    """Pasta temporária com um banco SQLite real e a pasta de backup;
    BACKUP_DIARIO ligado e o estado do processo zerado a cada teste."""

    manter = 14

    def setUp(self):
        super().setUp()
        self._tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self._tmp.cleanup)
        self.banco = os.path.join(self._tmp.name, "db.sqlite3")
        self.pasta = os.path.join(self._tmp.name, "nexbuy_backups")
        _criar_banco(self.banco)

        configuracao = override_settings(
            BACKUP_DIARIO=True, BACKUP_DIARIO_DIR=self.pasta, BACKUP_DIARIO_MANTER=self.manter,
        )
        configuracao.enable()
        self.addCleanup(configuracao.disable)

        for alvo, valor in (
            ("core.backup_diario.caminho_do_banco", lambda: self.banco),
            ("core.backup_diario._agora", lambda: self.agora),
        ):
            patch = mock.patch(alvo, side_effect=valor)
            patch.start()
            self.addCleanup(patch.stop)

        self.agora = _momento(DIA)
        backup_diario.reiniciar_estado()
        self.addCleanup(backup_diario.reiniciar_estado)

        # Sem a linha "Backup diário criado" (INFO) a cada teste na saída da
        # suíte; avisos e erros continuam visíveis (e capturáveis).
        registro = logging.getLogger("core.backup_diario")
        self.addCleanup(registro.setLevel, registro.level)
        registro.setLevel(logging.WARNING)

    def copia(self, dia=DIA):
        return os.path.join(self.pasta, f"diario_{dia.isoformat()}.sqlite3")

    def arquivos(self):
        return sorted(os.listdir(self.pasta)) if os.path.isdir(self.pasta) else []


def _middleware(resposta=None):
    return backup_diario.BackupDiarioMiddleware(lambda request: resposta or HttpResponse("ok"))


def _requisicao(middleware):
    """Uma requisição completa: resposta montada e depois fechada pelo
    servidor (é no fechamento que a cópia roda)."""
    resposta = middleware(RequestFactory().get("/"))
    resposta.close()
    return resposta


# ---------------------------------------------------------------------------
# 1. settings.py
# ---------------------------------------------------------------------------


class BackupDiarioSettingsTestCase(SimpleTestCase):
    def test_padrao_desligado(self):
        with mock.patch.dict(os.environ, {}):
            for nome in ("BACKUP_DIARIO", "BACKUP_DIARIO_DIR", "BACKUP_DIARIO_MANTER"):
                os.environ.pop(nome, None)
            s = carregar_settings()
        self.assertFalse(s["BACKUP_DIARIO"])
        self.assertEqual(s["BACKUP_DIARIO_DIR"], "")
        self.assertEqual(s["BACKUP_DIARIO_MANTER"], 14)

    def test_ligado_pelo_env(self):
        s = carregar_settings(
            BACKUP_DIARIO="True", BACKUP_DIARIO_DIR=" /home/usuario/nexbuy_backups ", BACKUP_DIARIO_MANTER="30",
        )
        self.assertTrue(s["BACKUP_DIARIO"])
        self.assertEqual(s["BACKUP_DIARIO_DIR"], "/home/usuario/nexbuy_backups")
        self.assertEqual(s["BACKUP_DIARIO_MANTER"], 30)

    def test_manter_tem_minimo_2_e_valor_invalido_nao_derruba_o_site(self):
        self.assertEqual(carregar_settings(BACKUP_DIARIO_MANTER="1")["BACKUP_DIARIO_MANTER"], 2)
        self.assertEqual(carregar_settings(BACKUP_DIARIO_MANTER="0")["BACKUP_DIARIO_MANTER"], 2)
        self.assertEqual(carregar_settings(BACKUP_DIARIO_MANTER="abc")["BACKUP_DIARIO_MANTER"], 14)
        self.assertEqual(carregar_settings(BACKUP_DIARIO_MANTER="")["BACKUP_DIARIO_MANTER"], 14)

    def test_middleware_depois_de_security_e_whitenoise_antes_de_sessao(self):
        cadeia = carregar_settings()["MIDDLEWARE"]
        posicao = cadeia.index("core.backup_diario.BackupDiarioMiddleware")
        self.assertGreater(posicao, cadeia.index("django.middleware.security.SecurityMiddleware"))
        self.assertGreater(posicao, cadeia.index("whitenoise.middleware.WhiteNoiseMiddleware"))
        self.assertLess(posicao, cadeia.index("django.contrib.sessions.middleware.SessionMiddleware"))
        self.assertLess(posicao, cadeia.index("django.middleware.csrf.CsrfViewMiddleware"))
        self.assertLess(posicao, cadeia.index("django.contrib.auth.middleware.AuthenticationMiddleware"))


# ---------------------------------------------------------------------------
# 2. Liga / desliga e configuração inválida
# ---------------------------------------------------------------------------


class PadraoDaSuiteTestCase(TestCase):
    def test_nos_testes_o_backup_nunca_roda_sozinho(self):
        """Sem override nenhum (o ambiente normal da suíte), o middleware
        sai da cadeia e nenhum request agenda cópia."""
        from django.conf import settings

        self.assertFalse(settings.BACKUP_DIARIO)
        with self.assertRaises(MiddlewareNotUsed):
            _middleware()
        with mock.patch("core.backup_diario.verificar_backup_diario") as verificar:
            self.assertEqual(Client().get("/accounts/login/").status_code, 200)
        verificar.assert_not_called()


class LigaDesligaTestCase(AmbienteDeBackupMixin, SimpleTestCase):
    def test_desligado_o_middleware_sai_da_cadeia(self):
        with override_settings(BACKUP_DIARIO=False):
            with self.assertRaises(MiddlewareNotUsed):
                _middleware()
        self.assertEqual(self.arquivos(), [])

    def test_sem_pasta_avisa_e_nao_faz_nada(self):
        with override_settings(BACKUP_DIARIO_DIR=""), self.assertLogs("core.backup_diario", "WARNING") as logs:
            with self.assertRaises(MiddlewareNotUsed):
                _middleware()
        self.assertIn("BACKUP_DIARIO_DIR está vazio", "\n".join(logs.output))
        self.assertEqual(self.arquivos(), [])

    def test_pasta_relativa_avisa_e_nao_faz_nada(self):
        with override_settings(BACKUP_DIARIO_DIR="nexbuy_backups"), \
                self.assertLogs("core.backup_diario", "WARNING") as logs:
            with self.assertRaises(MiddlewareNotUsed):
                _middleware()
        self.assertIn("caminho completo", "\n".join(logs.output))

    def test_banco_que_nao_e_sqlite_avisa_e_nao_faz_nada(self):
        config_postgres = {"ENGINE": "django.db.backends.postgresql", "NAME": "nexbuy"}
        with mock.patch("core.backup_diario._config_banco", return_value=config_postgres), \
                self.assertLogs("core.backup_diario", "WARNING") as logs:
            with self.assertRaises(MiddlewareNotUsed):
                _middleware()
            self.assertEqual(backup_diario.fazer_backup_diario().situacao, "configuracao")
        self.assertIn("não é SQLite", "\n".join(logs.output))
        self.assertEqual(self.arquivos(), [])

    def test_configuracao_que_fica_invalida_depois_avisa_uma_vez_e_espera_o_dia_seguinte(self):
        middleware = _middleware()
        with override_settings(BACKUP_DIARIO_DIR=""), self.assertLogs("core.backup_diario", "WARNING") as logs:
            _requisicao(middleware)
            _requisicao(middleware)
        self.assertEqual(len(logs.output), 1)
        self.assertFalse(backup_diario.backup_pendente(self.agora))
        self.assertTrue(backup_diario.backup_pendente(_momento(OUTRO_DIA, 0, 1)))


# ---------------------------------------------------------------------------
# 3. Cópia do dia, uma vez só
# ---------------------------------------------------------------------------


class CopiaDoDiaTestCase(AmbienteDeBackupMixin, SimpleTestCase):
    def test_primeiro_request_do_dia_cria_copia_integra(self):
        with self.assertLogs("core.backup_diario", "INFO") as logs:
            _requisicao(_middleware())
        self.assertIn("Backup diário criado", "\n".join(logs.output))
        self.assertEqual(self.arquivos(), [f"diario_{DIA.isoformat()}.sqlite3"])
        self.assertEqual(_integridade(self.copia()), "ok")
        self.assertEqual(_contar_linhas(self.copia()), _contar_linhas(self.banco))
        if os.name != "nt":
            self.assertEqual(stat.S_IMODE(os.stat(self.copia()).st_mode), 0o600)

    def test_a_copia_roda_depois_da_resposta_entregue(self):
        resposta = _middleware()(RequestFactory().get("/"))
        self.assertEqual(self.arquivos(), [])  # a página saiu sem esperar a cópia
        resposta.close()  # o servidor fecha a resposta depois de entregá-la
        self.assertTrue(os.path.exists(self.copia()))

    def test_segundo_request_nao_refaz_nem_olha_o_disco(self):
        middleware = _middleware()
        _requisicao(middleware)
        modificado = os.path.getmtime(self.copia())
        with mock.patch("core.backup_diario._copiar") as copiar, \
                mock.patch("core.backup_diario._existe", wraps=os.path.exists) as existe:
            for _ in range(5):
                self.agora += timedelta(hours=2)  # até 19h do mesmo dia
                resposta = _requisicao(middleware)
                self.assertEqual(resposta.status_code, 200)
        copiar.assert_not_called()
        existe.assert_not_called()
        self.assertEqual(os.path.getmtime(self.copia()), modificado)

    def test_processo_novo_no_mesmo_dia_so_confere_o_arquivo(self):
        _requisicao(_middleware())
        backup_diario.reiniciar_estado()  # outro processo / site recarregado
        with mock.patch("core.backup_diario._copiar") as copiar, \
                mock.patch("core.backup_diario._existe", wraps=os.path.exists) as existe:
            _requisicao(_middleware())
            _requisicao(_middleware())
        copiar.assert_not_called()
        self.assertEqual(existe.call_count, 1)

    def test_troca_de_dia_faz_outra_copia(self):
        middleware = _middleware()
        _requisicao(middleware)
        self.agora = _momento(DIA, 23, 59)
        _requisicao(middleware)
        self.assertFalse(os.path.exists(self.copia(OUTRO_DIA)))
        self.agora = _momento(OUTRO_DIA, 0, 5)
        _requisicao(middleware)
        self.assertEqual(
            self.arquivos(), [f"diario_{DIA.isoformat()}.sqlite3", f"diario_{OUTRO_DIA.isoformat()}.sqlite3"],
        )

    def test_dia_e_o_de_cuiaba_e_nao_o_utc(self):
        # 02:30 UTC de 07/10 ainda é 06/10, 22:30, em Cuiabá (UTC-4).
        self.agora = datetime(2026, 10, 7, 2, 30, tzinfo=dt_timezone.utc)
        _requisicao(_middleware())
        self.assertEqual(self.arquivos(), [f"diario_{DIA.isoformat()}.sqlite3"])
        # E a próxima conferência é à meia-noite de Cuiabá (04:00 UTC).
        self.assertFalse(backup_diario.backup_pendente(datetime(2026, 10, 7, 3, 59, tzinfo=dt_timezone.utc)))
        self.assertTrue(backup_diario.backup_pendente(datetime(2026, 10, 7, 4, 0, tzinfo=dt_timezone.utc)))

    def test_copia_reflete_o_banco_no_momento(self):
        _requisicao(_middleware())
        conexao = sqlite3.connect(self.banco)
        conexao.execute("INSERT INTO compra (fornecedor, valor) VALUES ('Novo', 1)")
        conexao.commit()
        conexao.close()
        self.agora = _momento(OUTRO_DIA)
        _requisicao(_middleware())
        self.assertEqual(_contar_linhas(self.copia(OUTRO_DIA)), _contar_linhas(self.copia(DIA)) + 1)

    def test_nao_cria_nem_altera_o_banco_de_origem(self):
        antes = os.path.getmtime(self.banco), os.path.getsize(self.banco)
        _requisicao(_middleware())
        self.assertEqual((os.path.getmtime(self.banco), os.path.getsize(self.banco)), antes)

    def test_banco_inexistente_nao_e_criado(self):
        os.remove(self.banco)
        with self.assertLogs("core.backup_diario", "ERROR"):
            _requisicao(_middleware())
        self.assertFalse(os.path.exists(self.banco))
        self.assertFalse(os.path.exists(self.copia()))


# ---------------------------------------------------------------------------
# 4. Retenção
# ---------------------------------------------------------------------------


class RetencaoTestCase(AmbienteDeBackupMixin, SimpleTestCase):
    manter = 3

    def test_mantem_as_n_mais_recentes_e_nao_toca_em_mais_nada(self):
        os.makedirs(self.pasta)
        antigos = [DIA - timedelta(days=n) for n in range(1, 21)]
        for dia in antigos:
            _tocar(self.copia(dia))
        outros = [
            "nexbuy_2026-10-01_0930.sqlite3",       # backup manual (backup_demo.sh)
            "nexbuy_2026-01-01_0000.sqlite3",
            "diario_2020-01-01.sqlite3.bak",         # nome parecido, mas não é da retenção
            "diario_antigo.sqlite3",
            "diario_2020-01-01.sqlite3.gz",
            "anotacoes.txt",
        ]
        for nome in outros:
            _tocar(os.path.join(self.pasta, nome))

        _requisicao(_middleware())

        esperados = sorted(
            [f"diario_{dia.isoformat()}.sqlite3" for dia in (DIA, DIA - timedelta(days=1), DIA - timedelta(days=2))]
            + outros
        )
        self.assertEqual(self.arquivos(), esperados)

    def test_manter_abaixo_de_2_vira_2(self):
        os.makedirs(self.pasta)
        for n in range(1, 5):
            _tocar(self.copia(DIA - timedelta(days=n)))
        with override_settings(BACKUP_DIARIO_MANTER=0):
            _requisicao(_middleware())
        self.assertEqual(
            self.arquivos(),
            [f"diario_{(DIA - timedelta(days=1)).isoformat()}.sqlite3", f"diario_{DIA.isoformat()}.sqlite3"],
        )

    def test_relogio_atrasado_nunca_apaga_a_copia_recem_feita(self):
        os.makedirs(self.pasta)
        futuros = [DIA + timedelta(days=n) for n in range(1, 4)]
        for dia in futuros:
            _tocar(self.copia(dia))
        _requisicao(_middleware())
        self.assertTrue(os.path.exists(self.copia(DIA)))
        self.assertEqual(_integridade(self.copia(DIA)), "ok")

    def test_retencao_so_roda_quando_cria_copia_nova(self):
        os.makedirs(self.pasta)
        for n in range(0, 6):  # inclusive a de hoje: nada a copiar
            _tocar(self.copia(DIA - timedelta(days=n)))
        _requisicao(_middleware())
        self.assertEqual(len(self.arquivos()), 6)


# ---------------------------------------------------------------------------
# 5. Erros nunca derrubam o site
# ---------------------------------------------------------------------------


class ErroNoBackupTestCase(AmbienteDeBackupMixin, SimpleTestCase):
    def test_erro_na_copia_loga_e_tenta_de_novo_em_30_minutos(self):
        middleware = _middleware()
        with mock.patch("core.backup_diario._copiar", side_effect=OSError("disco cheio")) as copiar, \
                self.assertLogs("core.backup_diario", "ERROR") as logs:
            resposta = _requisicao(middleware)
            self.assertEqual(resposta.status_code, 200)
            self.agora += timedelta(minutes=29)
            _requisicao(middleware)
        self.assertEqual(copiar.call_count, 1)
        self.assertIn("FALHOU", "\n".join(logs.output))
        self.assertIn("disco cheio", "\n".join(logs.output))
        self.assertIn("30 minutos", "\n".join(logs.output))
        self.assertFalse(os.path.exists(self.copia()))
        self.assertFalse(os.path.exists(os.path.join(self.pasta, backup_diario.NOME_TRAVA)))

        self.agora += timedelta(minutes=2)
        _requisicao(middleware)
        self.assertEqual(_integridade(self.copia()), "ok")

    def test_banco_ocupado_desiste_em_vez_de_prender_o_processo(self):
        """Sozinho, Connection.backup tentaria para sempre com o banco
        travado por outra conexão."""
        trava = sqlite3.connect(self.banco, isolation_level=None)
        trava.execute("BEGIN EXCLUSIVE")
        try:
            inicio = time.monotonic()
            with mock.patch("core.backup_diario.TEMPO_ESPERA_BANCO", 0.5), \
                    self.assertLogs("core.backup_diario", "ERROR") as logs:
                resposta = _requisicao(_middleware())
            self.assertLess(time.monotonic() - inicio, 10)
        finally:
            trava.execute("ROLLBACK")
            trava.close()
        self.assertEqual(resposta.status_code, 200)
        self.assertIn("ocupado", "\n".join(logs.output))
        self.assertEqual([n for n in self.arquivos() if n.startswith("diario_")], [])

        # Liberado o banco, a nova tentativa (30 min depois) copia normalmente.
        self.agora += timedelta(minutes=31)
        _requisicao(_middleware())
        self.assertEqual(_integridade(self.copia()), "ok")

    def test_qualquer_excecao_do_backup_e_engolida(self):
        with mock.patch("core.backup_diario.fazer_backup_diario", side_effect=RuntimeError("inesperado")), \
                self.assertLogs("core.backup_diario", "ERROR"):
            resposta = _requisicao(_middleware())
        self.assertEqual(resposta.status_code, 200)

    def test_integrity_check_ruim_nao_vira_copia(self):
        with mock.patch("core.backup_diario._integridade", return_value="*** in database main ***\nPage 3: erro"), \
                self.assertLogs("core.backup_diario", "ERROR") as logs:
            _requisicao(_middleware())
        self.assertIn("integrity_check", "\n".join(logs.output))
        self.assertEqual([n for n in self.arquivos() if n.startswith("diario_")], [])  # nem .parcial

    def test_resposta_de_verdade_continua_normal_mesmo_com_erro(self):
        resposta_redirect = HttpResponse(status=302)
        with mock.patch("core.backup_diario._copiar", side_effect=PermissionError("sem permissão")), \
                self.assertLogs("core.backup_diario", "ERROR"):
            resposta = _requisicao(_middleware(resposta_redirect))
        self.assertEqual(resposta.status_code, 302)


class ErroNoBackupComRequestDeVerdadeTestCase(AmbienteDeBackupMixin, TestCase):
    """A cadeia inteira de middlewares do projeto, pelo cliente de testes
    do Django (que fecha a resposta como um servidor WSGI)."""

    def test_login_responde_200_e_cria_a_copia(self):
        resposta = Client().get("/accounts/login/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(_integridade(self.copia()), "ok")

    def test_erro_no_backup_nao_muda_200_nem_302(self):
        with mock.patch("core.backup_diario._copiar", side_effect=OSError("falha de rede no disco")), \
                self.assertLogs("core.backup_diario", "ERROR"):
            self.assertEqual(Client().get("/accounts/login/").status_code, 200)
            backup_diario.reiniciar_estado()
            resposta = Client().get("/")
            self.assertEqual(resposta.status_code, 302)
        self.assertFalse(os.path.exists(self.copia()))


# ---------------------------------------------------------------------------
# 6. Trava entre processos
# ---------------------------------------------------------------------------


class TravaTestCase(AmbienteDeBackupMixin, SimpleTestCase):
    def _trava(self):
        return os.path.join(self.pasta, backup_diario.NOME_TRAVA)

    def test_trava_recente_de_outro_processo_impede_a_copia(self):
        os.makedirs(self.pasta)
        _tocar(self._trava(), b"99999 0\n")
        middleware = _middleware()
        with mock.patch("core.backup_diario._copiar") as copiar:
            _requisicao(middleware)
            self.assertEqual(backup_diario.fazer_backup_diario(self.agora).situacao, "ocupado")
            copiar.assert_not_called()
        self.assertTrue(os.path.exists(self._trava()))  # a trava alheia não é apagada

        # O outro processo termina (cria a cópia e solta a trava): 2 minutos
        # depois este confere e encontra a cópia pronta.
        os.remove(self._trava())
        _tocar(self.copia())
        self.agora += timedelta(minutes=3)
        with mock.patch("core.backup_diario._copiar") as copiar:
            _requisicao(middleware)
        copiar.assert_not_called()
        self.assertFalse(backup_diario.backup_pendente(self.agora))

    def test_trava_vencida_e_removida_e_a_copia_segue(self):
        os.makedirs(self.pasta)
        _tocar(self._trava(), b"99999 0\n")
        velho = time.time() - backup_diario.VALIDADE_DA_TRAVA - 60
        os.utime(self._trava(), (velho, velho))
        with self.assertLogs("core.backup_diario", "WARNING"):
            _requisicao(_middleware())
        self.assertEqual(_integridade(self.copia()), "ok")
        self.assertFalse(os.path.exists(self._trava()))

    def test_trava_e_solta_depois_da_copia(self):
        _requisicao(_middleware())
        self.assertTrue(os.path.exists(self.copia()))
        self.assertNotIn(backup_diario.NOME_TRAVA, self.arquivos())

    def test_parcial_velho_de_processo_morto_e_limpo_e_recente_nao(self):
        os.makedirs(self.pasta)
        velho = os.path.join(self.pasta, f"diario_{DIA.isoformat()}.sqlite3.4242.parcial")
        recente = os.path.join(self.pasta, f"diario_{DIA.isoformat()}.sqlite3.4343.parcial")
        _tocar(velho)
        _tocar(recente)
        # Processo morto no meio da cópia (Reload, kill): o SQLite deixa o
        # "-journal" ao lado do ".parcial" — ele também é sobra e sai.
        sobras_velhas = [velho + "-journal", velho + "-wal", velho + "-shm"]
        for caminho in sobras_velhas:
            _tocar(caminho)
        _tocar(recente + "-journal")
        antigo = time.time() - backup_diario.VALIDADE_DA_TRAVA - 60
        for caminho in (velho, *sobras_velhas):
            os.utime(caminho, (antigo, antigo))
        _requisicao(_middleware())
        self.assertFalse(os.path.exists(velho))
        for caminho in sobras_velhas:
            self.assertFalse(os.path.exists(caminho), caminho)
        self.assertTrue(os.path.exists(recente))
        self.assertTrue(os.path.exists(recente + "-journal"))  # pode ser de outro processo copiando agora
        self.assertTrue(os.path.exists(self.copia()))

    def test_journal_orfao_velho_tambem_e_limpo(self):
        """O caso real: a limpeza antiga apagava o ".parcial" e deixava o
        "-journal" para sempre na pasta de backup."""
        os.makedirs(self.pasta)
        orfao = os.path.join(self.pasta, f"diario_{DIA.isoformat()}.sqlite3.38876.parcial-journal")
        _tocar(orfao)
        antigo = time.time() - backup_diario.VALIDADE_DA_TRAVA - 60
        os.utime(orfao, (antigo, antigo))
        _requisicao(_middleware())
        self.assertEqual(self.arquivos(), [f"diario_{DIA.isoformat()}.sqlite3"])

    def test_falha_no_meio_da_copia_nao_deixa_journal(self):
        def integridade_com_journal(caminho):
            _tocar(caminho + "-journal")  # o que o SQLite deixa quando a cópia é interrompida
            return "*** in database main ***\nPage 3: erro"

        with mock.patch("core.backup_diario._integridade", side_effect=integridade_com_journal), \
                self.assertLogs("core.backup_diario", "ERROR"):
            _requisicao(_middleware())
        self.assertEqual([n for n in self.arquivos() if n.startswith("diario_")], [])

    def test_duas_threads_do_mesmo_processo_copiam_uma_vez(self):
        import threading

        middleware = _middleware()
        chamadas = []
        copiar_original = backup_diario._copiar

        def copiar_devagar(origem, destino):
            chamadas.append(destino)
            time.sleep(0.2)
            copiar_original(origem, destino)

        with mock.patch("core.backup_diario._copiar", side_effect=copiar_devagar):
            threads = [threading.Thread(target=_requisicao, args=(middleware,)) for _ in range(4)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
        self.assertEqual(len(chamadas), 1)
        self.assertEqual(_integridade(self.copia()), "ok")


# ---------------------------------------------------------------------------
# 7. manage.py backup_diario
# ---------------------------------------------------------------------------


class ComandoBackupDiarioTestCase(AmbienteDeBackupMixin, SimpleTestCase):
    def _rodar(self, *args):
        saida = io.StringIO()
        call_command("backup_diario", *args, stdout=saida)
        return saida.getvalue()

    def test_cria_a_copia_e_depois_avisa_que_ja_existe(self):
        saida = self._rodar()
        self.assertIn("[ok] Backup de hoje criado", saida)
        self.assertIn(f"diario_{DIA.isoformat()}.sqlite3", saida)
        self.assertEqual(_integridade(self.copia()), "ok")
        self.assertIn("já existe", self._rodar())

    def test_funciona_com_o_automatico_desligado_e_avisa(self):
        with override_settings(BACKUP_DIARIO=False):
            saida = self._rodar()
        self.assertTrue(os.path.exists(self.copia()))
        self.assertIn("AUTOMÁTICO está desligado", saida)

    def test_listar_nao_copia(self):
        saida = self._rodar("--listar")
        self.assertFalse(os.path.exists(self.copia()))
        self.assertIn("Cópias diárias", saida)

    def test_sem_pasta_e_erro_claro(self):
        with override_settings(BACKUP_DIARIO_DIR=""):
            with self.assertRaises(CommandError) as contexto:
                self._rodar()
        self.assertIn("BACKUP_DIARIO_DIR", str(contexto.exception))

    def test_falha_vira_erro_claro(self):
        with mock.patch("core.backup_diario._copiar", side_effect=OSError("disco cheio")):
            with self.assertRaises(CommandError) as contexto:
                self._rodar()
        self.assertIn("disco cheio", str(contexto.exception))
        self.assertIn("não foi alterado", str(contexto.exception))

    def test_ocupado_por_outro_processo(self):
        os.makedirs(self.pasta)
        _tocar(os.path.join(self.pasta, backup_diario.NOME_TRAVA))
        with self.assertRaises(CommandError) as contexto:
            self._rodar()
        self.assertIn("Outro processo", str(contexto.exception))
