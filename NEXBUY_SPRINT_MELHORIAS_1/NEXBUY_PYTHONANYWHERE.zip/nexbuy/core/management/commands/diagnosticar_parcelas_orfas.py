"""Sprint de Correções Críticas — Seção 15.

Comando de DIAGNÓSTICO (somente leitura — nunca grava nada no banco): lista
toda Compra Aprovada sem nenhuma parcela (`ParcelaCompra`) associada — o
compromisso financeiro dela não aparece em nenhum lugar do sistema (Agenda
Financeira, Contas a Pagar, Parcelamentos), porque toda essa exibição
depende das parcelas existirem de verdade.

Rode antes de `backfill_parcelas_orfas` para conferir exatamente o que será
corrigido. Este comando nunca cria, altera nem apaga nada — é seguro rodar
em qualquer ambiente, inclusive produção.

Uso:
    python manage.py diagnosticar_parcelas_orfas
"""
from django.core.management.base import BaseCommand
from django.db.models import Count

from compras.models import Compra
from compras.services import calcular_vencimentos_da_compra, dividir_valor_em_parcelas
from core.utils import formatar_moeda


class Command(BaseCommand):
    help = "Lista Compras Aprovadas sem nenhuma parcela — diagnóstico somente leitura (Sprint de Correções Críticas, Seção 15)."

    def handle(self, *args, **options):
        orfas = (
            Compra.objects.annotate(total_parcelas_reais=Count("parcelas"))
            .filter(total_parcelas_reais=0, status=Compra.Status.APROVADA)
            .select_related("fornecedor", "filial", "filial__empresa")
            .order_by("filial__empresa__nome", "data_compra", "pk")
        )

        total = orfas.count()
        if total == 0:
            self.stdout.write(self.style.SUCCESS("Nenhuma Compra Aprovada sem parcelas encontrada. Nada a corrigir."))
            return

        self.stdout.write(
            self.style.WARNING(
                f"{total} Compra(s) Aprovada(s) sem nenhuma parcela — o compromisso delas não aparece "
                "na Agenda Financeira, em Contas a Pagar nem em Parcelamentos:"
            )
        )
        self.stdout.write("")

        soma_valor = 0
        soma_parcelas_previstas = 0
        for compra in orfas:
            vencimentos = calcular_vencimentos_da_compra(compra)
            valores = dividir_valor_em_parcelas(compra.valor, len(vencimentos))
            soma_valor += compra.valor
            soma_parcelas_previstas += len(vencimentos)

            self.stdout.write(
                f"Compra #{compra.pk} — {compra.filial.empresa.nome} / {compra.filial.nome}\n"
                f"  Fornecedor: {compra.fornecedor.nome}\n"
                f"  Data da compra: {compra.data_compra:%d/%m/%Y}\n"
                f"  Valor: {formatar_moeda(compra.valor, incluir_prefixo=True)}\n"
                f"  Prazo: {compra.get_prazo_pagamento_display()}"
                + (f" ({compra.prazo_personalizado_dias} dias)" if compra.prazo_personalizado_dias else "")
                + f"\n  Parcelas que SERIAM geradas pelo backfill ({len(vencimentos)}):"
            )
            for numero, (vencimento, valor) in enumerate(zip(vencimentos, valores), start=1):
                self.stdout.write(f"    {numero}/{len(vencimentos)} — vence {vencimento:%d/%m/%Y} — {formatar_moeda(valor, incluir_prefixo=True)}")
            self.stdout.write("")

        self.stdout.write(
            self.style.WARNING(
                f"Total: {total} compra(s), {soma_parcelas_previstas} parcela(s) prevista(s), "
                f"soma de {formatar_moeda(soma_valor, incluir_prefixo=True)}."
            )
        )
        self.stdout.write("")
        self.stdout.write(
            "Para corrigir, rode primeiro em modo simulação:\n"
            "  python manage.py backfill_parcelas_orfas --dry-run\n"
            "e, conferido o resultado, sem --dry-run para gravar de verdade."
        )
