"""Sprint de Correções Críticas — Seção 15.

Comando de BACKFILL (grava no banco): gera as parcelas que faltam nas
Compras Aprovadas antigas que nunca as tiveram (compras lançadas antes do
Épico 4 — Compras Parceladas — existir). Reaproveita `gerar_parcelas_da_
compra`, o MESMO service usado para gerar parcelas de uma Compra nova ou
recém-aprovada — nenhuma fórmula nova, nenhum caminho de cálculo paralelo.

Comando SEPARADO do diagnóstico (`diagnosticar_parcelas_orfas`) de
propósito: um só lê, o outro só grava — rode o diagnóstico primeiro para
saber exatamente o que vai acontecer antes de aplicar de verdade.

Uso:
    python manage.py backfill_parcelas_orfas --dry-run   # simula, não grava nada
    python manage.py backfill_parcelas_orfas             # grava de verdade

Idempotente: rodar de novo depois de uma execução bem-sucedida não
encontra mais nenhuma Compra órfã e não faz nada. Transacional: todas as
Compras da execução são corrigidas juntas — se qualquer uma falhar a
validação (soma das parcelas ≠ valor da compra), NADA é gravado.

Este comando NÃO deve ser rodado em produção sem revisão — é uma correção
de dados históricos pensada para a base fictícia de demonstração, sempre
depois de um backup do banco (Seção 15/22 do Sprint de Correções
Críticas)."""
import os
from decimal import Decimal

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import Count

from compras.models import Compra
from compras.services import gerar_parcelas_da_compra
from core.utils import formatar_moeda


class _DryRunRollback(Exception):
    """Exceção de controle interna: força o rollback da transação quando
    `--dry-run` está ativo, depois de já ter validado tudo dentro dela."""


def _abortar_backfill_em_producao():
    """Mesmo espírito de `core.utils.abortar_seed_em_producao`, mas para um
    risco diferente: aqui não é criar usuário com senha pública — é
    reescrever dados financeiros históricos. Bloqueado com DEBUG=False
    (produção) a menos que explicitamente liberado."""
    from django.conf import settings

    if settings.DEBUG or getattr(settings, "TESTING", False):
        return
    permitido = (os.environ.get("ALLOW_BACKFILL_IN_PRODUCTION") or "").strip().lower() in ("1", "true", "sim", "yes")
    if permitido:
        return
    raise CommandError(
        "'backfill_parcelas_orfas' reescreve dados financeiros históricos — bloqueado com DEBUG=False "
        "(ambiente de produção). Esta correção foi pensada para a base fictícia de demonstração, sempre "
        "depois de um backup. Se você tem certeza do que está fazendo, defina "
        "ALLOW_BACKFILL_IN_PRODUCTION=True no .env e rode de novo."
    )


class Command(BaseCommand):
    help = "Gera as parcelas que faltam em Compras Aprovadas antigas sem nenhuma (Sprint de Correções Críticas, Seção 15)."

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Mostra exatamente o que seria gravado, sem gravar nada de verdade.",
        )

    def handle(self, *args, **options):
        _abortar_backfill_em_producao()
        dry_run = options["dry_run"]

        orfas = list(
            Compra.objects.annotate(total_parcelas_reais=Count("parcelas"))
            .filter(total_parcelas_reais=0, status=Compra.Status.APROVADA)
            .select_related("fornecedor", "filial", "filial__empresa")
            .order_by("filial__empresa__nome", "data_compra", "pk")
        )

        if not orfas:
            self.stdout.write(self.style.SUCCESS("Nenhuma Compra Aprovada sem parcelas encontrada. Nada a fazer."))
            return

        modo = "SIMULAÇÃO (--dry-run, nada será gravado)" if dry_run else "GRAVAÇÃO REAL"
        self.stdout.write(self.style.WARNING(f"Modo: {modo}. {len(orfas)} compra(s) serão processadas.\n"))

        soma_geral = Decimal("0")
        corrigidas = []

        try:
            with transaction.atomic():
                for compra in orfas:
                    parcelas = gerar_parcelas_da_compra(compra)
                    soma_parcelas = sum((p.valor for p in parcelas), Decimal("0"))

                    # Validação da soma (Seção 15): a correção só é aceita se as
                    # parcelas geradas somarem EXATAMENTE o valor da compra —
                    # qualquer divergência aborta a transação inteira, nada fica
                    # parcialmente corrigido.
                    if soma_parcelas != compra.valor:
                        raise CommandError(
                            f"Compra #{compra.pk}: soma das parcelas geradas ({formatar_moeda(soma_parcelas, incluir_prefixo=True)}) "
                            f"não bate com o valor da compra ({formatar_moeda(compra.valor, incluir_prefixo=True)}) — "
                            "abortando toda a execução, nada foi gravado."
                        )

                    soma_geral += compra.valor
                    corrigidas.append((compra, parcelas))
                    self.stdout.write(
                        f"Compra #{compra.pk} — {compra.filial.empresa.nome} / {compra.filial.nome} — "
                        f"{compra.fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)}"
                    )
                    for parcela in parcelas:
                        self.stdout.write(
                            f"    {parcela.numero}/{len(parcelas)} — vence {parcela.data_vencimento:%d/%m/%Y} — "
                            f"{formatar_moeda(parcela.valor, incluir_prefixo=True)}"
                        )

                if dry_run:
                    # Mesmo em modo simulação, as parcelas foram fisicamente
                    # inseridas para validar a soma — o rollback do dry-run
                    # desfaz tudo antes do commit (nenhum dado real é gravado).
                    raise _DryRunRollback()
        except _DryRunRollback:
            pass

        self.stdout.write("")
        if dry_run:
            self.stdout.write(
                self.style.WARNING(
                    f"[SIMULAÇÃO] {len(corrigidas)} compra(s) SERIAM corrigidas, somando "
                    f"{formatar_moeda(soma_geral, incluir_prefixo=True)}. Nada foi gravado — rode sem "
                    "--dry-run para aplicar de verdade."
                )
            )
        else:
            self.stdout.write(
                self.style.SUCCESS(
                    f"{len(corrigidas)} compra(s) corrigida(s) com sucesso, somando "
                    f"{formatar_moeda(soma_geral, incluir_prefixo=True)} em parcelas geradas."
                )
            )
