"""Fechamento Final (Prompt 1) — Seção 5.

Sincroniza `Permissao` (banco) com `core.permissions.CATALOGO_PERMISSOES`
(fonte única, em memória) — sem precisar escrever uma migration de dados
nova a cada permissão acrescentada ao catálogo. Idempotente
(`update_or_create`) e seguro em qualquer ambiente, inclusive produção:
nunca remove uma `Permissao` existente (mesmo que tenha saído do catálogo
em memória) nem toca em nenhuma atribuição (`PerfilAcesso.permissoes`,
`Usuario.permissoes_individuais`) — só garante que todo código do catálogo
exista no banco com o nome atualizado.

A migration `usuarios.0008_sync_catalogo_permissoes_fechamento_final` já
fecha a divergência conhecida até este ponto (`filiais.gerenciar` e
`provisoes.efetivar`); este comando é para o dia a dia — depois de
acrescentar uma permissão nova a `CATALOGO_PERMISSOES`, rode-o (ou escreva
uma migration de dados equivalente) para ela aparecer no banco.

Uso:
    python manage.py sincronizar_permissoes
"""
from django.core.management.base import BaseCommand

from core.permissions import CATALOGO_PERMISSOES
from usuarios.models import Permissao


class Command(BaseCommand):
    help = (
        "Sincroniza usuarios.Permissao com core.permissions.CATALOGO_PERMISSOES — "
        "idempotente, nunca remove permissão nem atribuição existente (Fechamento Final, Seção 5)."
    )

    def handle(self, *args, **options):
        criadas = []
        atualizadas = []
        for codigo, nome, _perfis in CATALOGO_PERMISSOES:
            permissao, criada = Permissao.objects.update_or_create(codigo=codigo, defaults={"nome": nome})
            (criadas if criada else atualizadas).append(permissao)

        if criadas:
            self.stdout.write(self.style.SUCCESS(f"{len(criadas)} permissão(ões) nova(s) criada(s):"))
            for permissao in criadas:
                self.stdout.write(f"  + {permissao.codigo} — {permissao.nome}")
        else:
            self.stdout.write("Nenhuma permissão nova — todo o catálogo já estava persistido.")

        self.stdout.write(f"{len(atualizadas)} permissão(ões) já existente(s) confirmada(s)/atualizada(s).")

        codigos_memoria = {codigo for codigo, _, _ in CATALOGO_PERMISSOES}
        sobrando_no_banco = Permissao.objects.exclude(codigo__in=codigos_memoria)
        if sobrando_no_banco.exists():
            self.stdout.write(
                self.style.WARNING(
                    f"{sobrando_no_banco.count()} permissão(ões) no banco não existem mais no catálogo em "
                    "memória (não removidas automaticamente — revise manualmente se ainda fazem sentido):"
                )
            )
            for permissao in sobrando_no_banco:
                self.stdout.write(f"  ? {permissao.codigo} — {permissao.nome}")

        self.stdout.write(self.style.SUCCESS("Catálogo de permissões sincronizado."))
