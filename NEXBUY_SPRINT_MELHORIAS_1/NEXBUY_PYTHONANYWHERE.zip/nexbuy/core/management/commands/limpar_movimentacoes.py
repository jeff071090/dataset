"""Limpa as MOVIMENTAÇÕES de UMA empresa — a saída da "fase de teste".

Para que serve: antes do uso real, a equipe pode fazer uma "análise
fictícia" no próprio sistema de produção (lançar compras, provisões,
receitas e custos de mentira para aprender). Compras e provisões gravadas
não podem ser editadas nem apagadas pela interface (isso protege o
histórico), então este comando é o caminho para começar o uso real do zero
SEM perder os cadastros.

Uso:
    python manage.py limpar_movimentacoes --empresa 12.345.678/0001-90
        SIMULAÇÃO (padrão): só lista quantos registros de cada tipo seriam
        apagados. Nada é alterado.
    python manage.py limpar_movimentacoes --empresa 12345678000190 --confirmar
        Apaga as movimentações da empresa (tudo numa transação só).
    ... --confirmar --incluir-planejamento
        Apaga também receitas mensais, receitas extras, custos fixos,
        custos variáveis e os dias cadastrados do calendário operacional.

Na VPS, use o script guiado (simula primeiro e pede o CNPJ de novo):
    sudo bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh

O que é APAGADO (só da empresa do CNPJ informado):
    compras, parcelas, históricos de compra, provisões, itens de provisão,
    solicitações de aprovação, históricos de provisão e notificações;
    com --incluir-planejamento, também o planejamento financeiro acima.

O que é SEMPRE MANTIDO:
    empresa, filiais, usuários (inclusive limites e bloqueios dos
    compradores), perfis de acesso e permissões, fornecedores, categorias,
    centros de custo, configuração financeira, configuração da plataforma,
    fluxos de aprovação, identidade visual e a Central de Auditoria (trilha
    que nunca é apagada — a própria limpeza fica registrada nela).

Segurança:
    - nunca toca em outra empresa (todo filtro é pela empresa do CNPJ);
    - com --confirmar e banco SQLite, faz ANTES uma cópia de segurança
      consistente (API de backup do SQLite, conferida com integrity_check)
      num arquivo com data e hora ao lado do banco — ou em BACKUP_DIR, se a
      variável de ambiente estiver definida — e imprime o caminho;
    - cópia, exclusões e o registro na auditoria acontecem dentro de UMA
      transação: qualquer erro desfaz tudo.
"""
import getpass
import os
import sqlite3
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import connection, transaction
from django.db.models import ProtectedError
from django.utils import timezone

from auditoria.models import RegistroAuditoria
from auditoria.services import registrar_evento
from compras.models import Compra, HistoricoCompra, ParcelaCompra
from core.utils import formatar_cnpj
from core.validators import normalizar_cnpj
from empresas.models import Empresa
from financeiro.models import CustoFixo, CustoVariavel, DiaOperacional, Receita, ReceitaExtra
from gestao_compras.models import HistoricoProvisao, ItemProvisao, Provisao, SolicitacaoAprovacao
from notificacoes.models import Notificacao

# (chave, rótulo, consulta). A ORDEM é a de exclusão: filhos antes dos pais,
# e Compras antes de Provisões — `Compra.provisao_origem` é PROTECT, então
# uma provisão efetivada só pode sair depois da compra que ela gerou.
MOVIMENTACOES = (
    ("notificacoes", "Notificações", lambda empresa: Notificacao.objects.filter(empresa=empresa)),
    ("historicos_compra", "Históricos de compra", lambda empresa: HistoricoCompra.objects.filter(compra__empresa=empresa)),
    ("parcelas", "Parcelas de compra", lambda empresa: ParcelaCompra.objects.filter(compra__empresa=empresa)),
    ("compras", "Compras", lambda empresa: Compra.objects.filter(empresa=empresa)),
    ("historicos_provisao", "Históricos de provisão", lambda empresa: HistoricoProvisao.objects.filter(provisao__empresa=empresa)),
    ("solicitacoes_aprovacao", "Solicitações de aprovação", lambda empresa: SolicitacaoAprovacao.objects.filter(provisao__empresa=empresa)),
    ("itens_provisao", "Itens de provisão", lambda empresa: ItemProvisao.objects.filter(provisao__empresa=empresa)),
    ("provisoes", "Provisões", lambda empresa: Provisao.objects.filter(empresa=empresa)),
)

PLANEJAMENTO = (
    ("receitas_mensais", "Receitas mensais", lambda empresa: Receita.objects.filter(empresa=empresa)),
    ("receitas_extras", "Receitas extras", lambda empresa: ReceitaExtra.objects.filter(empresa=empresa)),
    ("custos_fixos", "Custos fixos", lambda empresa: CustoFixo.objects.filter(empresa=empresa)),
    ("custos_variaveis", "Custos variáveis", lambda empresa: CustoVariavel.objects.filter(empresa=empresa)),
    ("dias_calendario", "Dias do calendário operacional", lambda empresa: DiaOperacional.objects.filter(empresa=empresa)),
)

# Ordem de EXIBIÇÃO no relatório (a de exclusão, acima, é outra).
ORDEM_EXIBICAO = (
    "compras", "parcelas", "historicos_compra", "provisoes", "itens_provisao",
    "solicitacoes_aprovacao", "historicos_provisao", "notificacoes",
)

MANTIDOS = (
    "empresa, filiais, usuários (com limites e bloqueios), perfis de acesso e permissões, "
    "fornecedores, categorias, centros de custo, configuração financeira e da plataforma, "
    "fluxos de aprovação, identidade visual e a Central de Auditoria"
)


def pasta_do_backup(nome_banco, em_memoria, backup_dir=None) -> Path:
    """BACKUP_DIR (se definido) ou a pasta do próprio arquivo do banco."""
    if backup_dir and str(backup_dir).strip():
        return Path(str(backup_dir).strip())
    if em_memoria:
        raise CommandError("Banco em memória: defina BACKUP_DIR para indicar onde gravar a cópia de segurança.")
    return Path(str(nome_banco)).resolve().parent


def copiar_banco_sqlite(origem, destino, espera_maxima=30.0):
    """Cópia consistente pela API de backup do SQLite (`Connection.backup`),
    feita por uma conexão SEPARADA, só de leitura.

    Por que separada: a API de backup não lê a partir da conexão que segura
    a trava de escrita — o SQLite devolve LOCKED e o Python tentaria de novo
    para sempre. Chamada com a transação IMMEDIATE do Django já aberta
    (settings.py), esta segunda conexão lê exatamente o último estado
    confirmado e ninguém consegue gravar entre a cópia e as exclusões.

    Nunca fica presa: se o banco continuar ocupado por mais de
    `espera_maxima` segundos, desiste com TimeoutError."""
    intervalo = 0.25
    limite = max(1, int(espera_maxima / intervalo))
    ocupado = {"vezes": 0}

    def progresso(status, _restantes, _total):
        if status in (sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED):
            ocupado["vezes"] += 1
            if ocupado["vezes"] > limite:
                raise TimeoutError(f"o banco ficou ocupado por mais de {espera_maxima:g} segundos.")
        else:
            ocupado["vezes"] = 0

    # Espera curta por passo; quem limita o tempo TOTAL é o `progresso`.
    fonte = sqlite3.connect(origem, timeout=min(1.0, espera_maxima))
    try:
        alvo = sqlite3.connect(destino)
        try:
            fonte.backup(alvo, pages=-1, progress=progresso, sleep=intervalo)
        finally:
            alvo.close()
    finally:
        fonte.close()


def _remover(caminho):
    try:
        Path(caminho).unlink(missing_ok=True)
    except OSError:
        pass


class Command(BaseCommand):
    help = (
        "Apaga as movimentações (compras, parcelas, provisões, aprovações, históricos e "
        "notificações) de UMA empresa, para sair da fase de teste. Padrão: simulação."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--empresa", required=True, metavar="CNPJ",
            help="CNPJ da empresa (com ou sem máscara). Obrigatório.",
        )
        parser.add_argument(
            "--confirmar", action="store_true",
            help="Apaga de verdade. Sem esta opção, é só uma simulação (nada é alterado).",
        )
        parser.add_argument(
            "--incluir-planejamento", action="store_true",
            help="Apaga também receitas mensais, receitas extras, custos fixos, custos variáveis "
                 "e os dias do calendário operacional.",
        )
        parser.add_argument(
            "--responsavel", default="", metavar="NOME",
            help="Quem pediu/executou a limpeza (fica na Central de Auditoria). "
                 "Padrão: o usuário do sistema operacional.",
        )

    # ------------------------------------------------------------------

    def handle(self, *args, **options):
        empresa = self._empresa(options["empresa"])
        incluir_planejamento = options["incluir_planejamento"]
        confirmar = options["confirmar"]

        grupos = list(MOVIMENTACOES) + (list(PLANEJAMENTO) if incluir_planejamento else [])
        contagens = {chave: consulta(empresa).count() for chave, _rotulo, consulta in grupos}
        total = sum(contagens.values())

        self._relatorio(empresa, contagens, incluir_planejamento, confirmar)

        if not confirmar:
            self.stdout.write("")
            self.stdout.write(self.style.WARNING(
                f"SIMULAÇÃO — nada foi apagado. {total} registro(s) seriam apagados."
            ))
            self.stdout.write(
                "Para apagar de verdade, rode de novo com --confirmar "
                "(na VPS: sudo bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh)."
            )
            return

        if total == 0:
            self.stdout.write(self.style.SUCCESS("Nada para apagar: esta empresa não tem registros desses tipos."))
            return

        responsavel = (options["responsavel"] or "").strip() or self._usuario_do_sistema()
        agora = timezone.localtime()

        try:
            with transaction.atomic():
                # A cópia é feita DENTRO da transação: no SQLite (modo
                # IMMEDIATE, ver settings.py) ela já segura a trava de
                # escrita, então a cópia é exatamente o estado de antes da
                # limpeza — ninguém grava nada entre a cópia e as exclusões.
                caminho_backup = self._backup(agora)
                # Recontagem já com a trava: é o número exato que vai para a auditoria.
                contagens = {chave: consulta(empresa).count() for chave, _rotulo, consulta in grupos}
                total_apagado = 0
                for _chave, _rotulo, consulta in grupos:
                    quantidade, _por_modelo = consulta(empresa).delete()
                    total_apagado += quantidade
                restantes = {chave: consulta(empresa).count() for chave, _rotulo, consulta in grupos}
                self._registrar_auditoria(
                    empresa, contagens, restantes, total_apagado, incluir_planejamento, responsavel, agora,
                    caminho_backup,
                )
        except ProtectedError as erro:
            raise CommandError(
                "Nada foi apagado: há registro de OUTRA empresa ligado a uma movimentação desta "
                f"(ex.: compra efetivada a partir de uma provisão desta empresa). Detalhe: {erro}"
            ) from erro

        self.stdout.write("")
        if caminho_backup:
            self.stdout.write(f"Cópia de segurança (antes da limpeza): {caminho_backup}")
        self.stdout.write(self.style.SUCCESS(
            f"Limpeza concluída: {total_apagado} registro(s) apagados de "
            f"{empresa.nome} ({formatar_cnpj(empresa.cnpj)}). Evento registrado na Central de Auditoria."
        ))

    # ------------------------------------------------------------------

    def _empresa(self, valor):
        digitos = normalizar_cnpj(valor)
        if len(digitos) != 14:
            raise CommandError(
                f'CNPJ inválido: "{valor}". Informe os 14 dígitos (com ou sem máscara), '
                "ex.: --empresa 12.345.678/0001-90"
            )
        empresa = Empresa.objects.filter(cnpj__in=(digitos, formatar_cnpj(digitos))).first()
        if empresa is None:
            existentes = [
                f"{e.nome} ({formatar_cnpj(e.cnpj)})" for e in Empresa.objects.order_by("nome")[:10]
            ]
            lista = "; ".join(existentes) if existentes else "nenhuma empresa cadastrada"
            raise CommandError(
                f"Nenhuma empresa com o CNPJ {formatar_cnpj(digitos)}. Nada foi apagado. "
                f"Empresas cadastradas: {lista}."
            )
        return empresa

    def _relatorio(self, empresa, contagens, incluir_planejamento, confirmar):
        titulo = "LIMPEZA" if confirmar else "SIMULAÇÃO (nada será apagado)"
        self.stdout.write(f"Empresa: {empresa.nome} ({formatar_cnpj(empresa.cnpj)})")
        self.stdout.write(f"Modo: {titulo}")
        self.stdout.write("")
        self.stdout.write("Movimentações que serão apagadas:" if confirmar else "Movimentações que seriam apagadas:")
        rotulos = {chave: rotulo for chave, rotulo, _consulta in MOVIMENTACOES}
        for chave in ORDEM_EXIBICAO:
            self.stdout.write(f"  {rotulos[chave]:<34} {contagens[chave]:>7}")
        self.stdout.write("")
        if incluir_planejamento:
            self.stdout.write("Planejamento (--incluir-planejamento):")
            for chave, rotulo, _consulta in PLANEJAMENTO:
                self.stdout.write(f"  {rotulo:<34} {contagens[chave]:>7}")
        else:
            self.stdout.write("Planejamento MANTIDO (para apagar também, use --incluir-planejamento):")
            for _chave, rotulo, consulta in PLANEJAMENTO:
                self.stdout.write(f"  {rotulo:<34} {consulta(empresa).count():>7}  (mantido)")
        self.stdout.write("")
        self.stdout.write(f"Sempre mantidos: {MANTIDOS}.")

    def _usuario_do_sistema(self):
        try:
            usuario = getpass.getuser()
        except Exception:  # noqa: BLE001 — sem usuário identificável no ambiente
            usuario = ""
        sudo = os.environ.get("SUDO_USER", "")
        if sudo and sudo != usuario:
            return f"{sudo} (via {usuario or 'sudo'})"
        return usuario or "usuário não identificado"

    def _backup(self, agora):
        """Cópia consistente do banco SQLite ANTES de apagar (chamada já
        dentro da transação). Devolve o caminho, ou None quando o banco não
        é SQLite (aí o backup é de quem opera — `deploy/limpar_dados_de_
        teste.sh` roda `deploy/backup.sh` antes)."""
        if connection.vendor != "sqlite":
            self.stdout.write(self.style.WARNING(
                "Banco não é SQLite: nenhuma cópia automática foi feita por este comando "
                "(faça o backup do banco antes, ex.: pg_dump)."
            ))
            return None

        em_memoria = connection.is_in_memory_db()
        pasta = pasta_do_backup(connection.settings_dict["NAME"], em_memoria, os.environ.get("BACKUP_DIR"))
        pasta.mkdir(parents=True, exist_ok=True)
        carimbo = agora.strftime("%Y-%m-%d_%H%M%S")
        caminho = pasta / f"nexbuy_antes_da_limpeza_{carimbo}.sqlite3"
        sequencia = 1
        while caminho.exists():
            sequencia += 1
            caminho = pasta / f"nexbuy_antes_da_limpeza_{carimbo}_{sequencia}.sqlite3"

        try:
            if em_memoria:
                # Só nos testes automatizados (banco de teste em memória): não
                # há arquivo para uma segunda conexão ler, então a imagem do
                # banco sai da própria conexão (serialize), já na transação.
                connection.ensure_connection()
                caminho.write_bytes(connection.connection.serialize())
            else:
                copiar_banco_sqlite(str(connection.settings_dict["NAME"]), str(caminho))
            destino = sqlite3.connect(str(caminho))
            try:
                integridade = destino.execute("PRAGMA integrity_check").fetchone()[0]
            finally:
                destino.close()
            if integridade != "ok":
                raise CommandError(
                    f"A cópia de segurança não passou no integrity_check ({integridade}). Nada foi apagado."
                )
        except TimeoutError as erro:
            _remover(caminho)
            raise CommandError(
                f"Não foi possível copiar o banco (ocupado por outra gravação): {erro} Nada foi apagado — "
                "tente de novo em alguns minutos, com ninguém lançando no sistema."
            ) from erro
        except BaseException:
            _remover(caminho)
            raise
        try:
            os.chmod(caminho, 0o600)  # dados financeiros: só o dono lê
        except OSError:
            pass
        return str(caminho)

    def _registrar_auditoria(self, empresa, contagens, restantes, total, incluir_planejamento, responsavel, agora,
                             caminho_backup):
        resumo = (
            f"{contagens['compras']} compra(s), {contagens['provisoes']} provisão(ões), "
            f"{contagens['notificacoes']} notificação(ões)"
        )
        if incluir_planejamento:
            resumo += ", receitas, custos e calendário"
        descricao = f"Limpeza dos dados de teste por {responsavel}: {total} registro(s) apagados ({resumo})."
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.CONFIGURACAO_PLATAFORMA_ALTERADA,
            descricao=descricao[:255],
            empresa=empresa,
            modulo="implantacao",
            acao="limpar_movimentacoes",
            tipo_objeto="Empresa",
            id_objeto=empresa.pk,
            estado_antes=contagens,
            estado_depois=restantes,
            justificativa=(
                f"manage.py limpar_movimentacoes executado por {responsavel} em "
                f"{agora:%d/%m/%Y %H:%M:%S}. Planejamento incluído: {'sim' if incluir_planejamento else 'não'}. "
                f"Cópia de segurança: {caminho_backup or 'não gerada por este comando (banco não é SQLite)'}."
            ),
            origem_decisao=RegistroAuditoria.OrigemDecisao.SISTEMA,
        )
