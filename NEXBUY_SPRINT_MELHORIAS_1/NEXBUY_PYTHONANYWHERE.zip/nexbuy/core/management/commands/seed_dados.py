"""Cria os dados de demonstração do NEXBUY: empresa, filial, financeiro,
categorias, centros de custo, fornecedores, usuários de teste e algumas
compras de exemplo (para o calendário visual).

Idempotente: pode ser executado novamente a qualquer momento sem duplicar
registros nem alterar a empresa/filial/usuários já existentes.

Uso:
    python manage.py seed_dados
"""
import calendar
from datetime import date
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from cadastros.models import CentroCusto, Categoria
from compras.models import Compra, Fornecedor
from compras.services import avaliar_e_criar_compra
from core.utils import abortar_seed_em_producao, formatar_cnpj, formatar_moeda
from empresas.models import Empresa, GrupoEmpresarial
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, Receita
from financeiro.services import calcular_capacidade_compra
from usuarios.models import Usuario

SENHA_DEMO = "nexbuy123"

CATEGORIAS_PADRAO = [
    "Medicamentos",
    "Perfumaria",
    "Cosméticos",
    "Higiene",
    "Serviços",
    "Marketing",
    "Tecnologia",
    "Despesas Gerais",
    "Outros",
]

CENTROS_CUSTO_PADRAO = [
    "Compras",
    "Financeiro",
    "Administrativo",
    "Marketing",
    "RH",
    "TI",
    "Operacional",
    "Outros",
]


class Command(BaseCommand):
    help = "Cria os dados de demonstração do NEXBUY (empresa, filial, financeiro, cadastros, usuários e compras)."

    @transaction.atomic
    def handle(self, *args, **options):
        abortar_seed_em_producao("seed_dados")
        grupo, _ = GrupoEmpresarial.objects.get_or_create(nome="Grupo Farmácia Modelo")

        # Gate pré-Etapa 10 (S1-1): "12.345.678/0001-90" nunca teve dígito
        # verificador válido — trocado por um CNPJ com o mesmo prefixo mas
        # matematicamente válido (`core.validators.cnpj_e_valido`).
        empresa, _ = Empresa.objects.update_or_create(
            cnpj="12345678000195",
            defaults={"nome": "Farmácia Modelo", "grupo": grupo, "segmento": "Farmacêutico"},
        )

        filial, _ = Filial.objects.update_or_create(
            empresa=empresa, nome="Centro",
            defaults={
                "tipo_estabelecimento": Filial.TipoEstabelecimento.MATRIZ,
                "cidade": "Campo Novo do Parecis", "ativo": True,
            },
        )

        ConfiguracaoFinanceira.objects.update_or_create(
            empresa=empresa,
            defaults={
                "percentual_compras": Decimal("35"),
                "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA,
                # Vazio = empresa de demonstração sem cor customizada, para
                # que a paleta oficial do Design System (Sprint UX 1.0)
                # apareça por padrão; uma empresa real que já tenha
                # escolhido sua própria cor em Configurações não é afetada
                # por este seed (só roda sobre a empresa de demonstração).
                "cor_principal": "",
            },
        )

        hoje = date.today()
        mes_referencia = hoje.replace(day=1)

        Receita.objects.update_or_create(
            filial=filial, mes=mes_referencia, defaults={"faturamento": Decimal("270000")}
        )

        custos_fixos = [
            ("Folha de Pagamento", "", Decimal("70000"), 5),
            ("Aluguel", "Imobiliária Parecis", Decimal("8000"), 10),
            ("Energia e Água", "Concessionária Local", Decimal("7000"), 15),
            ("Sistema de Gestão", "Fornecedor de Software", Decimal("5000"), 20),
        ]
        for descricao, fornecedor_nome, valor, dia in custos_fixos:
            CustoFixo.objects.update_or_create(
                filial=filial,
                descricao=descricao,
                defaults={"fornecedor": fornecedor_nome, "valor": valor, "dia_vencimento": dia, "ativo": True},
            )

        custos_variaveis = [
            ("Reposição Extra de Mercadorias", Decimal("25000"), mes_referencia.replace(day=12)),
            ("Fretes e Logística", Decimal("5000"), mes_referencia.replace(day=18)),
        ]
        for descricao, valor, data_prevista in custos_variaveis:
            CustoVariavel.objects.update_or_create(
                filial=filial, descricao=descricao, data_prevista=data_prevista, defaults={"valor": valor}
            )

        # Categorias e centros de custo padrão (Módulos 2 e 3 — Etapa 2)
        categorias = {}
        for nome in CATEGORIAS_PADRAO:
            categoria, _ = Categoria.objects.get_or_create(empresa=empresa, nome=nome)
            categorias[nome] = categoria

        centros_custo = {}
        for nome in CENTROS_CUSTO_PADRAO:
            centro, _ = CentroCusto.objects.get_or_create(empresa=empresa, nome=nome)
            centros_custo[nome] = centro

        # Fornecedores com cadastro completo (Módulo 1 — Etapa 2)
        fornecedores_dados = [
            (
                "Distribuidora ABC Farma",
                {
                    "razao_social": "ABC Distribuidora de Medicamentos Ltda",
                    "cnpj": "12.111.222/0001-33",
                    "inscricao_estadual": "131.234.567",
                    "telefone": "(65) 3311-2233",
                    "whatsapp": "(65) 99911-2233",
                    "email": "contato@abcfarma.com.br",
                    "cidade": "Cuiabá",
                    "estado": "MT",
                },
            ),
            (
                "Distribuidora XYZ Higiene e Perfumaria",
                {
                    "razao_social": "XYZ Higiene e Perfumaria Ltda",
                    "cnpj": "12.333.444/0001-55",
                    "inscricao_estadual": "133.456.789",
                    "telefone": "(65) 3322-4455",
                    "whatsapp": "(65) 99922-4455",
                    "email": "vendas@xyzhigiene.com.br",
                    "cidade": "Cuiabá",
                    "estado": "MT",
                },
            ),
            (
                "Serviços Gerais Ltda",
                {
                    "razao_social": "Serviços Gerais e Manutenção Ltda",
                    "cnpj": "12.555.666/0001-77",
                    "telefone": "(65) 3333-5566",
                    "email": "financeiro@servicosgerais.com.br",
                    "cidade": "Campo Novo do Parecis",
                    "estado": "MT",
                },
            ),
        ]
        fornecedores = {}
        for nome, dados in fornecedores_dados:
            fornecedor, _ = Fornecedor.objects.update_or_create(empresa=empresa, nome=nome, defaults=dados)
            fornecedores[nome] = fornecedor

        usuarios_demo = [
            # Gate pré-Etapa 10 (S1-2): nunca is_staff/is_superuser aqui —
            # ver comentário equivalente em seed_demo.py.
            ("proprietario", Usuario.Perfil.PROPRIETARIO, "Ana", "Proprietária", filial, False),
            ("gerente", Usuario.Perfil.GERENTE, "Bruno", "Gerente", filial, False),
            ("financeiro", Usuario.Perfil.FINANCEIRO, "Carla", "Financeiro", filial, False),
            ("comprador", Usuario.Perfil.COMPRADOR, "Diego", "Comprador", filial, False),
        ]
        for username, perfil, first_name, last_name, fil, acesso_total in usuarios_demo:
            usuario, criado = Usuario.objects.get_or_create(username=username)
            usuario.first_name = first_name
            usuario.last_name = last_name
            usuario.perfil = perfil
            usuario.empresa = empresa
            usuario.filial = None if perfil == Usuario.Perfil.PROPRIETARIO else fil
            usuario.is_staff = acesso_total
            usuario.is_superuser = acesso_total
            usuario.set_password(SENHA_DEMO)
            usuario.save()

        # Remove compras de demonstração de execuções anteriores, para permitir reexecução segura.
        Compra.objects.filter(filial=filial, observacao__startswith="[DEMO]").delete()

        capacidade = calcular_capacidade_compra(filial, hoje.year, hoje.month)
        limite_diario = capacidade["limite_diario"]
        ultimo_dia_mes = calendar.monthrange(hoje.year, hoje.month)[1]

        def dia_seguro(dia):
            return min(dia, ultimo_dia_mes)

        comprador = Usuario.objects.get(username="comprador")

        demo_compras = [
            (
                dia_seguro(3), Decimal("0.30"), fornecedores["Distribuidora ABC Farma"],
                categorias["Medicamentos"], centros_custo["Compras"],
            ),
            (
                dia_seguro(6), Decimal("0.85"), fornecedores["Distribuidora XYZ Higiene e Perfumaria"],
                categorias["Higiene"], centros_custo["Compras"],
            ),
            (
                dia_seguro(9), Decimal("1.30"), fornecedores["Serviços Gerais Ltda"],
                categorias["Serviços"], centros_custo["Administrativo"],
            ),
            (
                hoje.day, Decimal("0.45"), fornecedores["Distribuidora ABC Farma"],
                categorias["Medicamentos"], centros_custo["Compras"],
            ),
        ]

        for dia, proporcao, fornecedor, categoria, centro_custo in demo_compras:
            data_compra = date(hoje.year, hoje.month, dia)
            if limite_diario > 0:
                valor = (limite_diario * proporcao).quantize(Decimal("0.01"))
            else:
                valor = Decimal("100.00")
            avaliar_e_criar_compra(
                filial=filial,
                fornecedor=fornecedor,
                valor=valor,
                categoria=categoria,
                centro_custo=centro_custo,
                data_compra=data_compra,
                prazo_pagamento=Compra.PrazoPagamento.D30,
                prazo_personalizado_dias=None,
                usuario=comprador,
                observacao="[DEMO] Compra de demonstração gerada automaticamente.",
            )

        self.stdout.write(self.style.SUCCESS("Dados de demonstração do NEXBUY criados com sucesso!"))
        self.stdout.write("")
        self.stdout.write(f"Empresa: {empresa.nome} ({formatar_cnpj(empresa.cnpj)}) — Filial: {filial.nome}")
        self.stdout.write(f"Categorias: {len(categorias)} · Centros de custo: {len(centros_custo)} · Fornecedores: {len(fornecedores)}")
        self.stdout.write(f"Limite diário calculado hoje: {formatar_moeda(limite_diario, incluir_prefixo=True)}")
        self.stdout.write("")
        self.stdout.write("Usuários de teste (senha para todos: nexbuy123):")
        for username, perfil, *_ in usuarios_demo:
            self.stdout.write(f"  - {username} ({perfil.label})")
