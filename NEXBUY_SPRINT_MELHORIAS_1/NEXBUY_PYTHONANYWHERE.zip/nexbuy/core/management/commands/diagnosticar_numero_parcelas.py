"""Gate pré-Etapa 10 (S1-4): diagnóstico somente leitura — falha (código
de saída != 0) se QUALQUER Compra tiver `numero_parcelas` diferente da
contagem real de `ParcelaCompra` associada. Nunca grava nada no banco.

Só compara Compras que JÁ têm pelo menos uma parcela materializada — uma
Compra Pendente/Bloqueada (nunca aprovada) legitimamente tem zero parcelas
reais e `numero_parcelas` correto refletindo o que SERIA gerado; comparar
contra zero geraria falso positivo em toda Compra ainda não aprovada.

Uso:
    python manage.py diagnosticar_numero_parcelas
"""
from django.core.management.base import BaseCommand, CommandError
from django.db.models import Count, F

from compras.models import Compra


class Command(BaseCommand):
    help = "Lista Compras com numero_parcelas divergente da contagem real de parcelas (Gate pré-Etapa 10, S1-4)."

    def handle(self, *args, **options):
        divergentes = (
            Compra.objects.annotate(total_parcelas_reais=Count("parcelas"))
            .exclude(total_parcelas_reais=0)
            .exclude(numero_parcelas=F("total_parcelas_reais"))
            .select_related("fornecedor", "filial", "filial__empresa")
            .order_by("filial__empresa__nome", "data_compra", "pk")
        )

        total = divergentes.count()
        if total == 0:
            self.stdout.write(self.style.SUCCESS("Nenhuma divergência — numero_parcelas bate com a contagem real em todas as Compras."))
            return

        self.stdout.write(self.style.ERROR(f"{total} Compra(s) com numero_parcelas divergente da contagem real de parcelas:\n"))
        for compra in divergentes:
            self.stdout.write(
                f"Compra #{compra.pk} — {compra.filial.empresa.nome} / {compra.filial.nome} — "
                f"{compra.fornecedor.nome} — prazo {compra.get_prazo_pagamento_display()}\n"
                f"  numero_parcelas={compra.numero_parcelas} vs. parcelas reais={compra.total_parcelas_reais}"
            )
        raise CommandError(f"{total} Compra(s) com numero_parcelas divergente — corrija antes de prosseguir.")
