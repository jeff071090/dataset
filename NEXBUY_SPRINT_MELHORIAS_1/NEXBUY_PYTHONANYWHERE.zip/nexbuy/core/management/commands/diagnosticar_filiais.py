"""Fechamento Final (Prompt 1) — Seção 4.4/4.5.

Lista Filiais com cadastro fiscal incompleto (`Filial.cadastro_completo`
== False — falta CNPJ, Inscrição Estadual/isenção, ou algum campo do
endereço) e, separadamente, qualquer inconsistência de integridade que a
constraint do banco por si só não deixa MOSTRAR de forma legível (a
constraint em si já impede o dado errado de ser gravado; este comando é
só para inspeção/relatório, nunca corrige nada).

Puramente somente-leitura: não existe `--corrigir` aqui, de propósito —
dado fiscal faltante (CNPJ, IE, endereço) não tem um valor "correto"
óbvio para preencher sozinho; quem completa o cadastro é o Proprietário,
pela tela de Filiais do NCC.

Uso:
    python manage.py diagnosticar_filiais             # lista (padrão)
    python manage.py diagnosticar_filiais --dry-run    # mesma coisa, explícito
"""
from django.core.management.base import BaseCommand

from filiais.models import Filial


class Command(BaseCommand):
    help = (
        "Lista Filiais com cadastro fiscal incompleto (Fechamento Final, Seção 4.4) — "
        "somente leitura, nunca corrige (não há valor certo para preencher sozinho)."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Só lista — comportamento padrão mesmo sem esta flag (não existe modo de correção).",
        )

    def handle(self, *args, **options):
        incompletas = [
            filial for filial in Filial.objects.filter(ativo=True).select_related("empresa").order_by(
                "empresa__nome", "nome"
            )
            if not filial.cadastro_completo
        ]

        if not incompletas:
            self.stdout.write(self.style.SUCCESS(
                "Nenhuma Filial ativa com cadastro fiscal incompleto. Nada a reportar."
            ))
            return

        self.stdout.write(self.style.WARNING(
            f"{len(incompletas)} Filial(is) ativa(s) com cadastro incompleto:\n"
        ))
        for filial in incompletas:
            faltando = []
            if not filial.cnpj:
                faltando.append("CNPJ")
            if not filial.isento_inscricao_estadual and not filial.inscricao_estadual:
                faltando.append("Inscrição Estadual (ou marcar Isento)")
            if not (filial.endereco and filial.numero and filial.bairro and filial.cidade and filial.estado and filial.cep):
                faltando.append("endereço completo (logradouro/número/bairro/cidade/UF/CEP)")
            if not filial.razao_social:
                faltando.append("razão social")
            if not filial.telefone:
                faltando.append("telefone")
            if not (
                filial.responsavel_usuario_id
                or (filial.responsavel_nome and (filial.responsavel_telefone or filial.responsavel_email))
            ):
                faltando.append("responsável (usuário ou nome + telefone/e-mail)")
            self.stdout.write(
                f'  "{filial.nome}" (empresa "{filial.empresa.nome}") — falta: {", ".join(faltando)}'
            )

        self.stdout.write("")
        self.stdout.write(
            "Nenhuma alteração é feita por este comando — complete o cadastro pela tela "
            "Filiais do NEXBUY Control Center (NCC)."
        )
