"""Troca a senha dos usuários de demonstração — obrigatório na
demonstração publicada na internet (PythonAnywhere — ver
docs/DEPLOY_PYTHONANYWHERE_DEMO.md).

O `seed_demo` cria os 6 usuários de login com a senha PÚBLICA de
demonstração (a do PC do apresentador, documentada em DEMO_MODE.md). Num
site aberto na internet isso deixaria qualquer visitante entrar como
Proprietário e trancar a cliente do lado de fora. Este comando troca essas
senhas e, de quebra, inutiliza a senha pública de qualquer OUTRO usuário da
empresa fictícia que ainda a use (ex.: a atendente criada só para o
histórico da Central de Auditoria).

Uso (no console do servidor, dentro da pasta do projeto):

    python manage.py definir_senha_demo                        # 1 senha para os 6 (digitada 2x, escondida)
    python manage.py definir_senha_demo --gerar                # gera 1 senha forte e mostra UMA vez
    python manage.py definir_senha_demo --individual           # 1 senha por usuário (pergunta um a um)
    python manage.py definir_senha_demo --individual --gerar   # gera 1 por usuário e mostra a tabela
    python manage.py definir_senha_demo --usuarios demo_gerente,demo_comprador --gerar
    python manage.py definir_senha_demo --verificar            # só confere (código de saída != 0 se algo falta)
    python manage.py definir_senha_demo --bloquear             # desativa a senha pública (ninguém entra) — falha fechada

Regras de segurança:

- Escopo fechado: só os 6 usuários `demo_*` da empresa fictícia do seed
  (CNPJ 98765432...) e, para inutilizar a senha pública, os demais
  usuários dessa mesma empresa. Nunca troca a senha de usuário de outra
  empresa nem de superusuário (`core.senha_demo`) — esses o `--verificar`
  só confere e manda trocar à mão.
- A senha NUNCA entra por argumento de linha de comando nem por variável de
  ambiente (ficaria no histórico do terminal/processos): ou é digitada
  escondida (getpass) ou é gerada aqui (`secrets`). Sem terminal
  interativo, só `--gerar`, `--bloquear` e `--verificar` funcionam.
- Senha digitada: pelo menos 12 caracteres, sem "nexbuy" e sem lembrar a
  senha pública (Nexbuy123, nexbuy123!, nexbuy2026... são recusadas), além
  das regras de senha do projeto (`AUTH_PASSWORD_VALIDATORS`).
- A senha nunca vai para log nem auditoria: o registro no Log de
  Configuração diz só QUANTOS usuários tiveram a senha redefinida.
- Funciona com DEBUG=False (é uma medida de segurança do servidor).

Códigos de saída do `--verificar` (os scripts do PythonAnywhere usam):
0 = tudo certo; 3 = algum usuário ATIVO entra com a senha pública;
4 = algum dos 6 usuários de login está sem senha (depois do `--bloquear`).
"""
import getpass
import os
import sys

from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from core import senha_demo
from core.utils import gerar_senha_provisoria

# Senha gerada: 16 caracteres do alfabeto sem ambíguos de
# `core.utils.gerar_senha_provisoria` (sem 0/O/o, 1/l/I/i) — fácil de ditar
# ou digitar a partir de uma mensagem, e muito além do mínimo de 14 pedido.
TAMANHO_SENHA_GERADA = 16
# Senha digitada: mais longa que o mínimo geral do projeto (8) — é a senha
# de um site aberto na internet, cujos usuários aparecem na apresentação.
TAMANHO_MINIMO_DIGITADA = 12
TENTATIVAS_POR_SENHA = 3
# Códigos de saída do --verificar (o manage.py devolve este número ao
# shell; os scripts do PythonAnywhere o conferem).
CODIGO_SAIDA_SENHA_PUBLICA = 3
CODIGO_SAIDA_SEM_SENHA = 4


def _nome(usuario):
    return usuario.get_full_name() or usuario.username


class Command(BaseCommand):
    help = (
        "Troca a senha dos 6 usuários de demonstração (e inutiliza a senha pública de qualquer outro "
        "usuário da empresa fictícia). Obrigatório na demonstração publicada na internet."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--gerar",
            action="store_true",
            help="Gera uma senha forte aleatória (mostrada UMA vez no console) em vez de pedir a digitação.",
        )
        parser.add_argument(
            "--individual",
            action="store_true",
            help="Uma senha diferente para cada usuário (com --gerar, mostra a tabela usuário/senha).",
        )
        parser.add_argument(
            "--usuarios",
            default="",
            help="Só estes usuários de demonstração, separados por vírgula (ex.: demo_gerente,demo_comprador).",
        )
        parser.add_argument(
            "--verificar",
            action="store_true",
            help=(
                "Só confere: termina com código de saída diferente de zero se algum usuário ATIVO ainda "
                "entra com a senha pública (3) ou se algum dos 6 usuários de login está sem senha (4)."
            ),
        )
        parser.add_argument(
            "--bloquear",
            action="store_true",
            help=(
                "Desativa a senha pública de quem ainda a usa na empresa fictícia (senha inutilizável: "
                "ninguém entra com esses usuários até receberem senha nova). Usado pelos scripts quando a "
                "troca de senha não termina — o site nunca fica aceitando a senha pública."
            ),
        )

    # ------------------------------------------------------------------
    # Pontos de entrada
    # ------------------------------------------------------------------

    def handle(self, *args, **opcoes):
        if opcoes["verificar"] or opcoes["bloquear"]:
            if opcoes["verificar"] and opcoes["bloquear"]:
                raise CommandError("Use --verificar OU --bloquear, não os dois juntos.")
            if opcoes["gerar"] or opcoes["individual"] or opcoes["usuarios"]:
                modo = "--verificar só confere" if opcoes["verificar"] else "--bloquear só desativa a senha pública"
                raise CommandError(f"{modo} — não combine com --gerar, --individual ou --usuarios.")
            if opcoes["verificar"]:
                self._verificar()
            else:
                self._bloquear()
            return

        alvos = self._usuarios_alvo(opcoes["usuarios"])
        if not opcoes["gerar"] and not self._terminal_interativo():
            raise CommandError(
                "Este comando pede a senha pelo teclado (sem mostrar na tela), mas não há um terminal "
                "interativo aqui. Rode num console de verdade ou use --gerar para criar uma senha forte "
                "automaticamente. Por segurança a senha nunca é aceita por argumento nem por variável de ambiente."
            )

        senhas = self._obter_senhas(alvos, gerar=opcoes["gerar"], individual=opcoes["individual"])

        with transaction.atomic():
            for usuario in alvos:
                usuario.set_password(senhas[usuario.username])
                usuario.save(update_fields=["password"])
            desativados = self._inutilizar_senha_publica_dos_demais()
            self._registrar_no_log(alvos, desativados)

        self._mostrar_resultado(alvos, senhas, desativados, gerar=opcoes["gerar"], individual=opcoes["individual"])

    def _terminal_interativo(self):
        """Há alguém digitando? (Isolado num método para os testes.)"""
        entrada = sys.stdin
        try:
            if entrada is None or not entrada.isatty():
                return False
        except (AttributeError, ValueError):
            return False
        if os.name == "nt":
            # No Windows o dispositivo NUL (entrada "vazia" de tarefas
            # automáticas) também responde isatty() = True — e o getpass
            # ficaria esperando para sempre. Só um console de verdade conta.
            try:
                import ctypes
                import msvcrt

                modo = ctypes.c_uint32()
                identificador = msvcrt.get_osfhandle(entrada.fileno())
                return bool(ctypes.windll.kernel32.GetConsoleMode(identificador, ctypes.byref(modo)))
            except Exception:  # noqa: BLE001 — na dúvida, não há terminal
                return False
        return True

    # ------------------------------------------------------------------
    # Quem
    # ------------------------------------------------------------------

    def _usuarios_alvo(self, texto_usuarios):
        todos = senha_demo.usernames_demo()
        if texto_usuarios.strip():
            pedidos = []
            for nome in texto_usuarios.split(","):
                nome = nome.strip()
                if nome and nome not in pedidos:
                    pedidos.append(nome)
            invalidos = [nome for nome in pedidos if nome not in todos]
            if invalidos:
                raise CommandError(
                    f"Usuário(s) fora da lista de demonstração: {', '.join(invalidos)}. "
                    f"Válidos: {', '.join(todos)}."
                )
            nomes = pedidos
        else:
            nomes = todos

        encontrados = {u.username: u for u in senha_demo.usuarios_da_empresa_demo().filter(username__in=nomes)}
        for nome in nomes:
            if nome not in encontrados:
                self.stderr.write(self.style.WARNING(
                    f"Aviso: {nome} não existe na empresa de demonstração (CNPJ {senha_demo.PREFIXO_CNPJ_DEMO}...) "
                    "ou é superusuário — ignorado."
                ))
        alvos = [encontrados[nome] for nome in nomes if nome in encontrados]
        if not alvos:
            raise CommandError(
                "Nenhum usuário de demonstração encontrado. Crie o cenário antes "
                "(no PythonAnywhere: bash deploy/pythonanywhere/preparar.sh)."
            )
        return alvos

    # ------------------------------------------------------------------
    # Senhas
    # ------------------------------------------------------------------

    def _obter_senhas(self, alvos, *, gerar, individual):
        if gerar:
            if individual:
                return {u.username: self._gerar_senha(u) for u in alvos}
            senha = self._gerar_senha(*alvos)
            return {u.username: senha for u in alvos}

        self.stdout.write("")
        self.stdout.write("A senha NÃO aparece enquanto você digita (nem asteriscos). Digite e tecle Enter.")
        self.stdout.write(
            f"Use pelo menos {TAMANHO_MINIMO_DIGITADA} caracteres (ex.: três palavras e um número), "
            "sem 'nexbuy' e sem lembrar a senha da demonstração local."
        )
        if individual:
            senhas = {}
            for usuario in alvos:
                senhas[usuario.username] = self._pedir_senha(
                    [usuario], f"Nova senha de {usuario.username} ({_nome(usuario)}): "
                )
            return senhas
        senha = self._pedir_senha(
            alvos, f"Nova senha (a mesma para os {len(alvos)} usuários de demonstração): "
        )
        return {u.username: senha for u in alvos}

    def _pedir_senha(self, usuarios, pergunta):
        for tentativa in range(1, TENTATIVAS_POR_SENHA + 1):
            senha = getpass.getpass(pergunta)
            confirmacao = getpass.getpass("Digite a mesma senha de novo: ")
            if senha != confirmacao:
                self.stderr.write(self.style.ERROR("As duas senhas digitadas são diferentes."))
            else:
                problemas = self._problemas_da_senha(senha, usuarios)
                if not problemas:
                    return senha
                self.stderr.write(self.style.ERROR("Senha recusada:"))
                for problema in problemas:
                    self.stderr.write(self.style.ERROR(f"  - {problema}"))
            if tentativa < TENTATIVAS_POR_SENHA:
                self.stderr.write(f"Tente de novo ({tentativa + 1}/{TENTATIVAS_POR_SENHA}).")
        raise CommandError(
            f"Nenhuma senha foi alterada: {TENTATIVAS_POR_SENHA} tentativas sem uma senha válida. "
            f"Dica: use pelo menos {TAMANHO_MINIMO_DIGITADA} caracteres misturando letras e números "
            "(ex.: três palavras e um número), sem 'nexbuy', fuja de senhas comuns ou parecidas com o "
            "nome do usuário — ou rode com --gerar."
        )

    @staticmethod
    def _problemas_da_senha(senha, usuarios):
        """Regras da senha de um site aberto na internet: pelo menos
        TAMANHO_MINIMO_DIGITADA caracteres, nada de "nexbuy" nem de variação
        da senha pública (maiúsculas, símbolos, 1 a 3 caracteres de
        diferença — `core.senha_demo.parece_senha_publica`), mais as regras
        do projeto (AUTH_PASSWORD_VALIDATORS: não só números, não comum, não
        parecida com o usuário) conferidas contra CADA usuário que vai
        recebê-la."""
        problemas = []
        if not senha.strip():
            problemas.append("A senha não pode ficar em branco.")
        if len(senha) < TAMANHO_MINIMO_DIGITADA:
            problemas.append(
                f"A senha precisa ter pelo menos {TAMANHO_MINIMO_DIGITADA} caracteres "
                f"(esta tem {len(senha)})."
            )
        if "nexbuy" in senha_demo.normalizar_senha(senha):
            problemas.append("Não use o nome do sistema (nexbuy) na senha — é o primeiro palpite de qualquer um.")
        palavras = senha_demo.palavras_obvias_na_senha(senha)
        if palavras:
            problemas.append(
                "Não use nomes que aparecem no próprio site ou na demonstração ("
                + ", ".join(palavras)
                + "), nem trocando letras por números (ex.: n3xbuy) — são os primeiros palpites de qualquer um."
            )
        if senha_demo.parece_senha_publica(senha):
            problemas.append(senha_demo.SenhaPublicaDemoValidator.MENSAGEM)
        validadores = [
            *password_validation.get_default_password_validators(),
            senha_demo.SenhaPublicaDemoValidator(),
        ]
        for usuario in usuarios:
            try:
                password_validation.validate_password(senha, user=usuario, password_validators=validadores)
            except ValidationError as erro:
                for mensagem in erro.messages:
                    if mensagem not in problemas:
                        problemas.append(mensagem)
        return problemas

    def _gerar_senha(self, *usuarios):
        """Senha aleatória (`secrets`, via `gerar_senha_provisoria`) com pelo
        menos uma minúscula, uma maiúscula e um algarismo, aprovada pelas
        mesmas regras da senha digitada."""
        while True:
            senha = gerar_senha_provisoria(TAMANHO_SENHA_GERADA)
            if (
                any(c.islower() for c in senha)
                and any(c.isupper() for c in senha)
                and any(c.isdigit() for c in senha)
                and not self._problemas_da_senha(senha, usuarios)
            ):
                return senha

    # ------------------------------------------------------------------
    # Os demais usuários da empresa fictícia
    # ------------------------------------------------------------------

    def _inutilizar_senha_publica_dos_demais(self):
        """Qualquer usuário da empresa fictícia que NÃO é um dos 6 de login e
        ainda entra com a senha pública (ex.: vp_atendente_beatriz, criada
        pelo seed só para o histórico de auditoria) fica com a senha
        inutilizável — ninguém entra com ela, nem com a senha pública."""
        seis = set(senha_demo.usernames_demo())
        desativados = []
        for usuario in senha_demo.usuarios_da_empresa_demo().exclude(username__in=seis):
            if senha_demo.usa_senha_publica(usuario):
                usuario.set_unusable_password()
                usuario.save(update_fields=["password"])
                desativados.append(usuario)
        return desativados

    def _registrar_no_log(self, alvos, desativados):
        """Mesmo registro que a tela Usuários e Permissões faz ao gerar uma
        senha provisória (`LogConfiguracao`, área "Usuários e Permissões") —
        sem migração nova e, claro, sem a senha. Sem usuário (`usuario=None`,
        a tela mostra "—"): quem roda o comando é o suporte, no console."""
        from empresas.models import LogConfiguracao

        por_empresa = {}
        for usuario in alvos:
            por_empresa.setdefault(usuario.empresa_id, [0, 0])[0] += 1
        for usuario in desativados:
            por_empresa.setdefault(usuario.empresa_id, [0, 0])[1] += 1
        for empresa_id, (redefinidas, inutilizadas) in por_empresa.items():
            partes = []
            if redefinidas:
                partes.append(f"senha redefinida para {redefinidas} usuário(s) de demonstração")
            if inutilizadas:
                partes.append(f"senha pública desativada para {inutilizadas} usuário(s)")
            LogConfiguracao.objects.create(
                empresa_id=empresa_id,
                usuario=None,
                area="Usuários e Permissões",
                descricao=f"Suporte (comando definir_senha_demo): {'; '.join(partes)}."[:255],
            )

    # ------------------------------------------------------------------
    # Saída
    # ------------------------------------------------------------------

    def _mostrar_resultado(self, alvos, senhas, desativados, *, gerar, individual):
        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS(f"Senha alterada para {len(alvos)} usuário(s) de demonstração:"))
        for usuario in alvos:
            self.stdout.write(f"  - {usuario.username} ({_nome(usuario)} — {usuario.get_perfil_display()})")
        if desativados:
            self.stdout.write(
                "Senha pública desativada (ninguém entra mais com ela) para: "
                + ", ".join(u.username for u in desativados)
            )

        # Só quem NÃO acabou de receber senha nova precisa ser conferido
        # (cada conferência custa um hash).
        fora = sorted(
            u.username
            for u in senha_demo.usuarios_da_empresa_demo().filter(is_active=True).exclude(username__in=list(senhas))
            if senha_demo.usa_senha_publica(u)
        )
        if fora:
            self.stderr.write(self.style.WARNING(
                "Atenção: ainda com a senha pública (não estavam em --usuarios): " + ", ".join(fora)
            ))

        if gerar:
            faixa = "-" * 64
            self.stdout.write("")
            self.stdout.write(faixa)
            if individual:
                self.stdout.write("SENHAS GERADAS (uma por usuário):")
                for usuario in alvos:
                    self.stdout.write(
                        f"  Usuário: {usuario.username:<18} Senha: {senhas[usuario.username]}"
                        f"   ({_nome(usuario)})"
                    )
            else:
                if len(alvos) == 1:
                    self.stdout.write(f"SENHA GERADA (para {alvos[0].username}):")
                else:
                    self.stdout.write(f"SENHA GERADA (a mesma para os {len(alvos)} usuários):")
                self.stdout.write(f"  Senha: {senhas[alvos[0].username]}")
            self.stdout.write(faixa)
            self.stdout.write("Copie AGORA: ela não aparece de novo e não fica gravada em lugar nenhum")
            self.stdout.write("(no banco fica só o código embaralhado). Depois, limpe a tela do console.")
        self.stdout.write("")
        self.stdout.write("Envie a senha à cliente por um canal DIFERENTE do link do site (ex.: link por")
        self.stdout.write("e-mail, senha por mensagem ou ligação). Quem já estava logado com estes")
        self.stdout.write("usuários precisa entrar de novo.")

    # ------------------------------------------------------------------
    # --bloquear
    # ------------------------------------------------------------------

    def _bloquear(self):
        """Falha FECHADA: todo usuário da empresa fictícia que ainda entra
        com a senha pública (os 6 de login e os demais) fica com a senha
        inutilizável. Os scripts do PythonAnywhere rodam isto logo depois do
        seed e quando a troca de senha não termina (sem terminal, 3
        digitações recusadas, Ctrl+C) — o site nunca fica aceitando a senha
        pública. Os 6 voltam a entrar quando receberem senha nova."""
        with transaction.atomic():
            bloqueados = senha_demo.usuarios_com_senha_publica(apenas_ativos=False)
            for usuario in bloqueados:
                usuario.set_unusable_password()
                usuario.save(update_fields=["password"])
            if bloqueados:
                self._registrar_no_log([], bloqueados)
        if not bloqueados:
            self.stdout.write(self.style.SUCCESS(
                "Nenhum usuário da demonstração usa a senha pública — nada a desativar."
            ))
            return
        self.stdout.write(self.style.WARNING(
            "Senha pública DESATIVADA (ninguém entra com estes usuários até receberem senha nova): "
            + ", ".join(u.username for u in bloqueados)
        ))
        self.stdout.write("Para definir as senhas: python manage.py definir_senha_demo (ou --gerar).")

    # ------------------------------------------------------------------
    # --verificar
    # ------------------------------------------------------------------

    def _verificar(self):
        """Só leitura. Falha (código 3) se QUALQUER usuário ativo entra com a
        senha pública — os da demonstração e também superusuários e usuários
        de outra empresa, que este comando não troca (manda trocar à mão).
        Falha (código 4) se algum dos 6 de login está sem senha (depois do
        `--bloquear`). Avisa, sem falhar, de usuário dos 6 que não existe ou
        foi desativado (renovar o cenário reativa)."""
        seis = senha_demo.usernames_demo()
        dos_seis = {u.username: u for u in senha_demo.usuarios_da_empresa_demo().filter(username__in=seis)}
        faltando = [nome for nome in seis if nome not in dos_seis]
        if len(faltando) == len(seis):
            self.stdout.write(self.style.WARNING(
                "Nenhum usuário de demonstração existe ainda (crie o cenário com o seed_demo)."
            ))
        elif faltando:
            self.stdout.write(self.style.WARNING("Usuários de demonstração que não existem: " + ", ".join(faltando)))

        desativados = [nome for nome in seis if nome in dos_seis and not dos_seis[nome].is_active]
        if desativados:
            self.stdout.write(self.style.WARNING(
                "Usuários de demonstração DESATIVADOS (não conseguem entrar): " + ", ".join(desativados)
                + ". Para reativar: renove o cenário (atualizar_demo.sh --renovar-cenario) ou reative em "
                "Usuários e Permissões, logado como demo_proprietario."
            ))

        inativos = [
            u.username
            for u in senha_demo.usuarios_da_empresa_demo().filter(is_active=False)
            if senha_demo.usa_senha_publica(u)
        ]
        if inativos:
            self.stdout.write(self.style.WARNING(
                "Inativos, mas ainda com a senha pública (rode definir_senha_demo para desativá-la): "
                + ", ".join(inativos)
            ))

        com_senha_publica = senha_demo.usuarios_com_senha_publica(apenas_ativos=True)
        fora_do_escopo = senha_demo.usuarios_fora_do_escopo_com_senha_publica()
        if com_senha_publica:
            self.stdout.write(self.style.ERROR("Usuários ATIVOS que ainda entram com a senha pública de demonstração:"))
            for usuario in com_senha_publica:
                self.stdout.write(self.style.ERROR(f"  - {usuario.username} ({_nome(usuario)})"))
        if fora_do_escopo:
            self.stdout.write(self.style.ERROR(
                "Fora da demonstração (superusuário ou outra empresa), ATIVOS e com a senha pública — "
                "este comando NÃO troca a senha deles; troque à mão (python manage.py changepassword "
                "<usuario>) ou desative o usuário:"
            ))
            for usuario in fora_do_escopo:
                self.stdout.write(self.style.ERROR(f"  - {usuario.username} ({_nome(usuario)})"))
        if com_senha_publica or fora_do_escopo:
            total = len(com_senha_publica) + len(fora_do_escopo)
            instrucao = "Troque agora: python manage.py definir_senha_demo" if com_senha_publica else (
                "Troque a senha deles à mão (python manage.py changepassword <usuario>)."
            )
            raise CommandError(
                f"{total} usuário(s) ativo(s) ainda com a senha pública. {instrucao}",
                returncode=CODIGO_SAIDA_SENHA_PUBLICA,
            )

        sem_senha = senha_demo.usuarios_demo_sem_senha()
        if sem_senha:
            self.stdout.write(self.style.ERROR(
                "Usuários de demonstração SEM SENHA (ninguém entra com eles): "
                + ", ".join(u.username for u in sem_senha)
            ))
            raise CommandError(
                f"{len(sem_senha)} usuário(s) de demonstração sem senha. "
                "Defina agora: python manage.py definir_senha_demo (ou --gerar).",
                returncode=CODIGO_SAIDA_SEM_SENHA,
            )
        self.stdout.write(self.style.SUCCESS(
            "OK: nenhum usuário ativo usa a senha pública e os usuários de demonstração têm senha definida."
        ))
