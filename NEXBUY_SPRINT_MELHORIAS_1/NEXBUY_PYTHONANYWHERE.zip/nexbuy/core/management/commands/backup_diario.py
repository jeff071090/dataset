"""Faz agora o backup diário do banco — o mesmo que o site faz sozinho no
primeiro acesso do dia quando BACKUP_DIARIO=True (ver core/backup_diario.py).

Uso (no console do servidor, dentro da pasta do projeto):

    python manage.py backup_diario            # garante a cópia de hoje e lista as guardadas
    python manage.py backup_diario --listar   # só lista as cópias diárias guardadas

Usa BACKUP_DIARIO_DIR e BACKUP_DIARIO_MANTER do .env. Funciona mesmo com o
backup automático desligado (BACKUP_DIARIO=False). Se a cópia de hoje já
existe, não faz outra. Nunca apaga nada além das cópias
"diario_AAAA-MM-DD.sqlite3" mais antigas que as BACKUP_DIARIO_MANTER mais
recentes — os backups feitos à mão (nexbuy_*.sqlite3) não são tocados.
"""
import os

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from core import backup_diario


class Command(BaseCommand):
    help = (
        "Faz agora o backup diário do banco SQLite (o mesmo do primeiro acesso do dia com "
        "BACKUP_DIARIO=True) e lista as cópias diárias guardadas."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--listar", action="store_true", help="Só lista as cópias diárias guardadas, sem copiar nada.",
        )

    def handle(self, *args, **options):
        problema = backup_diario.problema_de_configuracao()
        if problema:
            raise CommandError(f"Backup diário não pode rodar: {problema}")
        pasta = backup_diario.pasta_de_backup()

        if not options["listar"]:
            try:
                resultado = backup_diario.fazer_backup_diario()
            except Exception as erro:
                raise CommandError(
                    f"O backup diário falhou: {erro} — o banco do site não foi alterado. "
                    "Confira o espaço em disco e a pasta de backup e tente de novo."
                ) from erro
            if resultado.situacao == "criado":
                self.stdout.write(self.style.SUCCESS(f"[ok] Backup de hoje criado: {resultado.caminho}"))
                for nome in resultado.removidos:
                    self.stdout.write(f"[info] Removida (mais antiga que as últimas guardadas): {nome}")
            elif resultado.situacao == "ja_existia":
                self.stdout.write(self.style.SUCCESS(f"[ok] O backup de hoje já existe: {resultado.caminho}"))
            elif resultado.situacao == "ocupado":
                raise CommandError(
                    "Outro processo está fazendo o backup de hoje agora. Espere 1 minuto e rode de novo."
                )
            else:  # pragma: no cover — configuração já conferida acima
                raise CommandError(f"Backup diário não pode rodar: {resultado.mensagem}")

        copias = backup_diario.copias_existentes(pasta)
        manter = backup_diario.copias_a_manter()
        self.stdout.write(f"[info] Cópias diárias em {pasta}: {len(copias)} (guarda as {manter} mais recentes)")
        for nome in reversed(copias):
            tamanho = os.path.getsize(os.path.join(pasta, nome)) / (1024 * 1024)
            self.stdout.write(f"         {nome}  ({tamanho:.1f} MB)")
        if not getattr(settings, "BACKUP_DIARIO", False):
            self.stdout.write(
                "[aviso] O backup AUTOMÁTICO está desligado (BACKUP_DIARIO=False no .env): "
                "só há cópia quando alguém roda este comando."
            )
