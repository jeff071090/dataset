"""Fechamento Final (Prompt 1) — Seção 4.3.

Diagnostica `UsuarioEmpresa` e `UsuarioFilial` ativos cujo Grupo diverge do
Grupo da Empresa principal do usuário — dado historicamente possível (a
criação já é restrita ao mesmo Grupo desde a Sprint de Correções Críticas,
Seção 5, mas essa restrição não existia antes dela, e nada impede um
registro criado diretamente por fora do formulário, ex.: shell/admin). A
resolução efetiva de acesso (`Usuario.empresas_disponiveis()` e
`filiais_autorizadas_para`) já ignora essas autorizações — este comando
serve para ENCONTRAR e, se pedido explicitamente, LIMPAR o dado
inconsistente em si, para a auditoria e os painéis de "Empresas
Autorizadas"/"Filiais Autorizadas" pararem de mostrar uma autorização que
nunca funciona de verdade.

Verifica os dois níveis, com a mesma semântica "provavelmente diferente"
(só considera inconsistente quando dá pra PROVAR que os grupos divergem —
os dois lados têm `grupo_id` não-nulo e ele diverge):
  - `UsuarioEmpresa`: Grupo da empresa autorizada x Grupo da empresa
    principal do usuário.
  - `UsuarioFilial`: Grupo da empresa DONA da filial vinculada x Grupo da
    empresa principal do usuário — pega inclusive o caso de uma filial
    vinculada diretamente, sem nenhum `UsuarioEmpresa` correspondente (ou
    deixada para trás depois de um `--corrigir` anterior desativar só a
    autorização de empresa).

Nunca corrige silenciosamente: sem nenhuma flag, só lista (equivalente a
--dry-run). A correção real (`--corrigir`) DESATIVA o registro
(`ativo=False`) — nunca apaga — preservando o histórico, e é idempotente:
rodar de novo depois de corrigido não encontra mais nada (os registros já
desativados não entram no filtro `ativo=True`).

Uso:
    python manage.py diagnosticar_autorizacoes_fora_do_grupo             # só lista (padrão)
    python manage.py diagnosticar_autorizacoes_fora_do_grupo --dry-run   # mesma coisa, explícito
    python manage.py diagnosticar_autorizacoes_fora_do_grupo --corrigir  # desativa as encontradas
"""
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from usuarios.models import UsuarioEmpresa, UsuarioFilial


class Command(BaseCommand):
    help = (
        "Lista (e, com --corrigir, desativa) UsuarioEmpresa ativos fora do Grupo da "
        "empresa principal do usuário (Fechamento Final, Seção 4.3)."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Só lista o que seria corrigido — comportamento padrão mesmo sem esta flag.",
        )
        parser.add_argument(
            "--corrigir", action="store_true",
            help="Desativa (ativo=False) as autorizações inconsistentes encontradas. Nunca apaga.",
        )

    def handle(self, *args, **options):
        if options["dry_run"] and options["corrigir"]:
            raise CommandError("Use --dry-run OU --corrigir, nunca os dois juntos.")
        corrigir = options["corrigir"]

        empresas_inconsistentes = []
        for autorizacao in (
            UsuarioEmpresa.objects.filter(ativo=True)
            .select_related("usuario", "usuario__empresa", "empresa")
            .order_by("usuario__username", "empresa__nome")
        ):
            usuario = autorizacao.usuario
            if not usuario.empresa_id:
                continue  # sem empresa principal, não há Grupo para comparar
            if autorizacao.empresa_id == usuario.empresa_id:
                continue  # autorização pra própria empresa principal (redundante, mas não inconsistente)
            # Só é "fora do Grupo" quando dá pra PROVAR que são grupos
            # diferentes — os dois lados têm `grupo_id` não-nulo e ele
            # diverge. Mesma semântica de `Usuario.empresas_disponiveis()`:
            # quando qualquer lado não tem Grupo cadastrado (`None`), o
            # dado NÃO é inconsistente — é uma autorização direta legítima,
            # de antes do conceito de Grupo existir.
            grupo_principal = usuario.empresa.grupo_id
            grupo_autorizada = autorizacao.empresa.grupo_id
            if grupo_principal is not None and grupo_autorizada is not None and grupo_autorizada != grupo_principal:
                empresas_inconsistentes.append(autorizacao)

        vinculos_inconsistentes = []
        for vinculo in (
            UsuarioFilial.objects.filter(ativo=True)
            .select_related("usuario", "usuario__empresa", "filial", "filial__empresa")
            .order_by("usuario__username", "filial__nome")
        ):
            usuario = vinculo.usuario
            if not usuario.empresa_id:
                continue
            # Mesma prova exigida em `Usuario.empresas_disponiveis()`, mas
            # comparando o Grupo da empresa DONA da filial vinculada — pega
            # o vínculo mesmo quando não existe (mais) nenhum `UsuarioEmpresa`
            # correspondente (vínculo direto, ou órfão após uma correção
            # anterior que só desativou a autorização de empresa).
            grupo_principal = usuario.empresa.grupo_id
            grupo_da_filial = vinculo.filial.empresa.grupo_id
            if grupo_principal is not None and grupo_da_filial is not None and grupo_da_filial != grupo_principal:
                vinculos_inconsistentes.append(vinculo)

        if not empresas_inconsistentes and not vinculos_inconsistentes:
            self.stdout.write(self.style.SUCCESS(
                "Nenhuma autorização (UsuarioEmpresa) ou vínculo (UsuarioFilial) fora do Grupo encontrado. "
                "Nada a corrigir."
            ))
            return

        modo = "CORRIGINDO (desativando)" if corrigir else "SIMULAÇÃO (--dry-run, nada será alterado)"
        total = len(empresas_inconsistentes) + len(vinculos_inconsistentes)
        self.stdout.write(self.style.WARNING(f"Modo: {modo}. {total} registro(s) fora do Grupo encontrado(s):\n"))

        if empresas_inconsistentes:
            self.stdout.write(f"Autorizações de Empresa (UsuarioEmpresa) — {len(empresas_inconsistentes)}:")
            for autorizacao in empresas_inconsistentes:
                usuario = autorizacao.usuario
                self.stdout.write(
                    f"  Usuário #{usuario.pk} ({usuario.username}) — empresa principal "
                    f"\"{usuario.empresa.nome}\" (grupo {usuario.empresa.grupo_id or 'nenhum'}) — "
                    f"autorizado em \"{autorizacao.empresa.nome}\" (grupo {autorizacao.empresa.grupo_id or 'nenhum'})"
                )

        if vinculos_inconsistentes:
            self.stdout.write(f"Vínculos de Filial (UsuarioFilial) — {len(vinculos_inconsistentes)}:")
            for vinculo in vinculos_inconsistentes:
                usuario = vinculo.usuario
                self.stdout.write(
                    f"  Usuário #{usuario.pk} ({usuario.username}) — empresa principal "
                    f"\"{usuario.empresa.nome}\" (grupo {usuario.empresa.grupo_id or 'nenhum'}) — "
                    f"vinculado à filial \"{vinculo.filial.nome}\" da empresa \"{vinculo.filial.empresa.nome}\" "
                    f"(grupo {vinculo.filial.empresa.grupo_id or 'nenhum'})"
                )

        if not corrigir:
            self.stdout.write("")
            self.stdout.write(
                "Nada foi alterado. Para desativar estes registros (preserva o histórico, "
                "nunca apaga), rode:\n  python manage.py diagnosticar_autorizacoes_fora_do_grupo --corrigir"
            )
            return

        with transaction.atomic():
            if empresas_inconsistentes:
                UsuarioEmpresa.objects.filter(pk__in=[a.pk for a in empresas_inconsistentes]).update(ativo=False)
            if vinculos_inconsistentes:
                UsuarioFilial.objects.filter(pk__in=[v.pk for v in vinculos_inconsistentes]).update(ativo=False)

        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS(f"{total} registro(s) desativado(s) com sucesso."))
