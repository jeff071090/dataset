"""Popula o NEXBUY com uma experiência de demonstração completa (Demo
Experience 1.0) — uma empresa fictícia própria ("Farmácia Vida Plena"),
inteiramente separada da empresa de desenvolvimento criada por
`seed_dados` (CNPJ, filial e usuários diferentes, sem nenhuma colisão),
com fornecedores, categorias, provisões e compras em estados variados,
pensada para uma apresentação comercial.

Toda a "regra de negócio" usada aqui é a mesma já existente no sistema —
este comando só chama os services reais (`avaliar_e_criar_compra`,
`criar_provisao`, `motor_aprovacao_provisao.aprovar/rejeitar/
solicitar_ajustes`), na mesma sequência que um uso real do NEXBUY faria.
Nenhuma regra nova, nenhuma tabela nova.

Idempotente: pode ser executado novamente a qualquer momento. As
Provisões e Compras de demonstração são recriadas do zero a cada
execução (apagadas e regeradas), para que a "história" do mês sempre
faça sentido em relação à data atual; Empresa/Filial/usuários/
fornecedores/categorias são atualizados no lugar (nunca duplicados).

Histórico de 12 meses (Análise Financeira): as duas lojas ganham receita
mensal, receitas extras, custos variáveis e compras APROVADAS de 13 meses
completos antes do mês corrente (12 na janela da Análise + 1 de
"aquecimento", para as parcelas do 1º mês da janela já existirem) e do mês
corrente até ontem. É o histórico de uma farmácia de verdade — compras de
~62–66% da receita, custos fixos de ~21% e custos variáveis de ~8% —, com
um mês ruim (compras muito acima do normal, fechado em prejuízo) e uma
receita em queda nos últimos meses, para a DRE, Créditos × Débitos e a
Saúde Financeira mostrarem números críveis e alertas reais. As compras do
histórico são gravadas direto pelo ORM (status Aprovada + parcelas geradas
pelas MESMAS funções de parcelamento do sistema), sem passar pelo motor de
aprovação — é passado já decidido; tudo é datado em relação a hoje.

Uso:
    python manage.py seed_demo
    python manage.py seed_demo --manter-senhas   # demo publicada na internet

`--manter-senhas` (demonstração publicada no PythonAnywhere — ver
docs/DEPLOY_PYTHONANYWHERE_DEMO.md): quem JÁ existe continua com a senha
atual (a que foi definida com `manage.py definir_senha_demo`); só usuários
criados agora recebem a senha pública de demonstração. Todo o resto do
cenário é renovado igual.

Recusa (CommandError, código de saída != 0, nada gravado):
- sempre que o servidor está em uso real (NEXBUY_USO_REAL=True no .env);
- num servidor (DEBUG=False) sem ALLOW_SEED_IN_PRODUCTION=True na linha do
  comando (`core.utils.abortar_seed_em_producao`);
- num servidor com qualquer empresa de dados reais (CNPJ fora da faixa
  fictícia 98765432...) ou com o Primeiro Acesso já concluído, mesmo com a
  autorização acima (`recusar_se_houver_dados_reais`).
"""
import calendar
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal
from io import BytesIO

from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.management.base import BaseCommand
from django.db import transaction
from django.db.models import Sum

from auditoria.models import RegistroAuditoria
from auditoria.services import registrar_evento
from cadastros.models import Categoria
from compras.models import Compra, Fornecedor, ParcelaCompra
from compras.services import (
    avaliar_e_criar_compra,
    bloquear_comprador,
    calcular_numero_parcelas,
    calcular_vencimentos_da_compra,
    definir_limite_comprador,
    dividir_valor_em_parcelas,
    estornar_parcela,
    liberar_comprador,
    marcar_parcela_paga,
    rejeitar_compra_pendente,
)
from core.utils import abortar_seed_em_producao, formatar_cnpj, formatar_moeda
from empresas.models import ConfiguracaoPlataforma, Empresa, GrupoEmpresarial, IdentidadeVisual
from filiais.models import Filial
from finance_engine.calendario_operacional import dia_conta_capacidade, excecoes_do_mes, tipo_do_dia
from finance_engine.services import STATUS_CONSIDERADOS_NO_LIMITE, motor_financeiro
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, DiaOperacional, Receita, ReceitaExtra
from financeiro.services import calcular_capacidade_compra
from gestao_compras.models import EtapaFluxo, FluxoAprovacao, Provisao, SolicitacaoAprovacao
from gestao_compras.services import criar_provisao, efetivar_provisao, motor_aprovacao_provisao
from notificacoes.models import Notificacao
from usuarios.models import PerfilAcesso, Permissao, Usuario, UsuarioEmpresa, UsuarioFilial

try:
    from PIL import Image, ImageDraw

    PIL_DISPONIVEL = True
except ImportError:  # Pillow já é dependência do projeto (Sprint 6); só por segurança.
    PIL_DISPONIVEL = False

SENHA_DEMO = "nexbuy123"

# Início do CNPJ de toda empresa fictícia deste seed (Farmácia Vida Plena e
# Drogaria Vida Plena Norte). Empresa fora dele num servidor = dado real.
PREFIXO_CNPJ_FICTICIO = "98765432"

CATEGORIAS_DEMO = [
    "Medicamentos",
    "Genéricos",
    "Perfumaria",
    "Higiene",
    "Insumos",
    "Material de Escritório",
    "Serviços",
]

CENTROS_CUSTO_DEMO = ["Compras", "Financeiro", "Administrativo"]

# Nome de produto é texto livre em ItemProvisao (o NEXBUY não tem cadastro
# de produtos nem controle de estoque — decisão mantida desde o MVP
# inicial). Aqui são só nomes realistas para a demonstração, não um
# catálogo persistido.
PRODUTOS_DEMO = [
    "Dipirona Monoidratada 500mg (cx 20cp)",
    "Paracetamol 750mg (cx 20cp)",
    "Amoxicilina 500mg (cx 15cp)",
    "Vitamina C 1g Efervescente (tubo)",
    "Protetor Solar FPS 60 (200ml)",
    "Álcool em Gel 70% (500ml)",
    "Sabonete Líquido Antisséptico (250ml)",
    "Máscara Descartável Tripla (cx 50un)",
    "Fralda Geriátrica G (pacote)",
    "Papel A4 (resma 500fl)",
]

# ---------------------------------------------------------------------------
# Histórico financeiro de 12 meses (Análise Financeira)
#
# Tudo é RELATIVO ao mês corrente (k = 0): k = -1 é o mês passado, k = +1 o
# próximo. A mesma história aparece em qualquer data do calendário.
# ---------------------------------------------------------------------------

# Percentual da disponibilidade (receita − custos fixos − custos variáveis)
# destinado às compras. Com custos fixos de ~21% e variáveis de ~8% da
# receita, 90% da disponibilidade equivale a compras de ~63% da receita —
# o peso normal de compras de uma farmácia (referências da própria Análise:
# RD Saúde 2024 e Sincofarma-SP). Com os 30% de antes, o limite diário dos
# compradores cobria só ~20% da receita e a DRE da demonstração saía com
# margem bruta de 97%.
PERCENTUAL_COMPRAS_DEMO = Decimal("90")

MESES_DE_HISTORICO = 13  # k = -13..-1: 12 meses na janela da Análise + 1 de aquecimento das parcelas

# k -> (fator da receita mensal sobre a base da loja, compras aprovadas em
# fração da receita total do mês). Pico de vendas em k = -3 e queda de ~3%
# ao mês até o mês corrente: a Saúde Financeira acusa a tendência tanto no
# mês corrente quanto no último mês fechado (e os custos fixos passam a
# pesar mais de 21% da receita — "Atenção"). k = -5 é o mês ruim — reforço
# de compras no laboratório muito acima do normal, fechado em prejuízo.
# k = 0: a fração vale para o mês INTEIRO e é aplicada no ritmo dos dias
# úteis já vividos (ver `_compras_historicas_do_mes`); k = +1 só tem
# receita (projeção usada pela capacidade das provisões da virada de mês).
PERFIL_MENSAL = {
    -13: (Decimal("0.95"), Decimal("0.63")),
    -12: (Decimal("0.97"), Decimal("0.64")),
    -11: (Decimal("0.94"), Decimal("0.62")),
    -10: (Decimal("0.92"), Decimal("0.65")),
    -9: (Decimal("0.95"), Decimal("0.63")),
    -8: (Decimal("0.97"), Decimal("0.64")),
    -7: (Decimal("0.99"), Decimal("0.62")),
    -6: (Decimal("1.02"), Decimal("0.65")),
    -5: (Decimal("1.04"), Decimal("0.77")),
    -4: (Decimal("1.07"), Decimal("0.60")),
    -3: (Decimal("1.10"), Decimal("0.64")),
    -2: (Decimal("1.07"), Decimal("0.66")),
    -1: (Decimal("1.04"), Decimal("0.65")),
    0: (Decimal("1.01"), Decimal("0.68")),
    1: (Decimal("1.02"), None),
}
MES_RUIM = -5

# Base da receita mensal de cada loja (multiplicada pelo fator do mês):
# Loja Centro fica entre ~R$ 257 mil e ~R$ 311 mil; Loja Bairro entre
# ~R$ 143 mil e ~R$ 173 mil.
LOJAS_DEMO = {
    "Loja Centro": {
        "base_receita": Decimal("280000"),
        "semente": 1,
        "custos_fixos": [
            # (descrição, fornecedor, valor mensal, dia do vencimento) —
            # ~20% a 22% da receita: Folha ~15%, Aluguel ~3%, demais ~3%.
            ("Folha de Pagamento", "", Decimal("45600"), 5),
            ("Aluguel", "Imobiliária Parecis", Decimal("9500"), 10),
            ("Energia e Água", "Concessionária Local", Decimal("5600"), 15),
            ("Honorários contábeis", "Escritório de contabilidade", Decimal("2300"), 10),
            ("Sistema, internet e telefone", "Provedor local", Decimal("1500"), 12),
        ],
        "receitas_extras": [
            # (dia, descrição, categoria, % da receita mensal ou None = rendimento, observação)
            (10, "Repasse de convênios (PBM) — Farmácia Popular", ReceitaExtra.Categoria.CONVENIOS,
             Decimal("0.023"), "Repasse mensal do programa, conferido no extrato."),
            (5, "Aplicação de injetáveis e aferição de pressão", ReceitaExtra.Categoria.SERVICOS,
             Decimal("0.0068"), ""),
            (1, "Rendimento da aplicação financeira (CDB)", ReceitaExtra.Categoria.RENDIMENTOS, None, ""),
        ],
    },
    "Loja Bairro": {
        "base_receita": Decimal("156000"),
        "semente": 3,
        "custos_fixos": [
            ("Folha de Pagamento", "", Decimal("26200"), 5),
            ("Aluguel", "Imobiliária Primavera", Decimal("5800"), 10),
            ("Energia e Água", "Concessionária Local", Decimal("2950"), 15),
            ("Sistema, internet e telefone", "Provedor local", Decimal("850"), 12),
        ],
        "receitas_extras": [
            (10, "Repasse de convênios (PBM) — Farmácia Popular", ReceitaExtra.Categoria.CONVENIOS,
             Decimal("0.019"), "Repasse mensal do programa, conferido no extrato."),
            (8, "Aferição de glicemia e pressão arterial", ReceitaExtra.Categoria.SERVICOS,
             Decimal("0.0085"), ""),
        ],
    },
}

# Custos variáveis de todo mês, em % da receita mensal (~8,4% no total),
# lançados com a data prevista do pagamento dentro do mês.
CUSTOS_VARIAVEIS_MENSAIS = [
    ("Impostos sobre vendas", Decimal("0.045"), 20),
    ("Taxas de cartão (maquininhas)", Decimal("0.023"), 28),
    ("Comissões de vendas", Decimal("0.010"), 30),
    ("Entregas (motoboy)", Decimal("0.006"), 25),
]

# Pedidos grandes do mês (acima do limite do dia, já aprovados): (dia
# alvo, fornecedor, categoria, prazo, fração das compras do mês, observação).
PEDIDOS_PROGRAMADOS = [
    (3, "Laboratório Vitalis", "Medicamentos", Compra.PrazoPagamento.D30_60_90, Decimal("0.12"),
     "[DEMO] Histórico — pedido mensal direto do laboratório (acima do limite do dia, aprovado)."),
    (12, "BelezaPura Perfumaria", "Perfumaria", Compra.PrazoPagamento.D30_60, Decimal("0.10"),
     "[DEMO] Histórico — pedido de perfumaria do mês (acima do limite do dia, aprovado)."),
    (20, "Higicare Produtos de Higiene", "Higiene", Compra.PrazoPagamento.D30, Decimal("0.08"),
     "[DEMO] Histórico — pedido de higiene do mês (acima do limite do dia, aprovado)."),
]
FRACAO_LABORATORIO_MES_RUIM = Decimal("0.22")
OBSERVACAO_MES_RUIM = (
    "[DEMO] Histórico — compra reforçada no laboratório por negociação de volume, paga em 30 dias: "
    "mês de compras muito acima do normal."
)

# Reposição do dia a dia com as distribuidoras (rodízio determinístico).
ROTACAO_REPOSICAO = [
    ("FarmaMax Medicamentos", "Medicamentos", Compra.PrazoPagamento.D30),
    ("MedForte Distribuidora", "Genéricos", Compra.PrazoPagamento.D30_60),
    ("FarmaMax Medicamentos", "Medicamentos", Compra.PrazoPagamento.D14),
    ("MedForte Distribuidora", "Medicamentos", Compra.PrazoPagamento.D30),
    ("MedForte Distribuidora", "Genéricos", Compra.PrazoPagamento.AVISTA),
    ("FarmaMax Medicamentos", "Medicamentos", Compra.PrazoPagamento.D30_60),
    ("Higicare Produtos de Higiene", "Insumos", Compra.PrazoPagamento.D30),
]
OBSERVACAO_REPOSICAO = "[DEMO] Histórico — reposição do dia com a distribuidora."
PREFIXO_HISTORICO = "[DEMO] Histórico"
# Pesos da reposição diária (variação natural de um dia para o outro).
PESOS_DIARIOS = [
    Decimal("0.78"), Decimal("0.95"), Decimal("0.86"), Decimal("1.00"),
    Decimal("0.72"), Decimal("0.90"), Decimal("0.83"), Decimal("0.97"),
]
CENTAVO = Decimal("0.01")


def _somar_meses(ano, mes, delta):
    indice = ano * 12 + (mes - 1) + delta
    return indice // 12, indice % 12 + 1


def _dia_no_mes(ano, mes, dia):
    return date(ano, mes, min(dia, calendar.monthrange(ano, mes)[1]))


def _ruido(k, semente):
    """Variação determinística de -1% a +1% (curvas das duas lojas não
    ficam idênticas, e a execução repetida dá sempre o mesmo número)."""
    return Decimal((k * 7 + semente) % 5 - 2) / Decimal("200")


def _receita_mensal_demo(dados_loja, k):
    fator = PERFIL_MENSAL[k][0] * (1 + _ruido(k, dados_loja["semente"]))
    return (dados_loja["base_receita"] * fator / 100).quantize(Decimal("1"), ROUND_HALF_UP) * 100


def recusar_se_houver_dados_reais():
    """Servidor (DEBUG=False, fora da suíte de testes — mesmo critério de
    `abortar_seed_em_producao`): recusa o seed se o banco já tem QUALQUER
    empresa fora da faixa fictícia (CNPJ que não começa com 98765432),
    mesmo com ALLOW_SEED_IN_PRODUCTION na linha do comando. Essa empresa é
    de uso real (criada pela cliente no Primeiro Acesso, por exemplo): o
    seed misturaria a farmácia fictícia e usuários com senha pública aos
    dados de verdade. Roda antes de qualquer gravação — nada é gravado.

    Na demonstração local (DEBUG=True) nada muda. A conferência é pelos
    dígitos do CNPJ (um CNPJ antigo gravado com máscara também é
    reconhecido).

    Primeiro Acesso concluído também recusa: ele só existe no uso real (o
    seed nunca o marca), e a empresa cadastrada nele pode ter qualquer
    CNPJ — o seed sobrescreveria uma com o prefixo fictício."""
    from django.conf import settings
    from django.core.management.base import CommandError

    from core.models import EstadoInstalacao

    if settings.DEBUG or getattr(settings, "TESTING", False):
        return
    if EstadoInstalacao.objects.filter(concluido=True).exists():
        raise CommandError(
            "'seed_demo' recusado: o Primeiro Acesso já foi concluído neste banco — ele é de uso real. "
            "O seed misturaria a farmácia fictícia e usuários com senha pública aos dados de verdade, por "
            "isso a recusa vale mesmo com ALLOW_SEED_IN_PRODUCTION. Nada foi gravado. Se este servidor "
            "passou a ser de uso real, marque NEXBUY_USO_REAL=True no .env."
        )
    reais = [
        nome
        for nome, cnpj in Empresa.objects.order_by("pk").values_list("nome", "cnpj")
        if not "".join(c for c in (cnpj or "") if c.isdigit()).startswith(PREFIXO_CNPJ_FICTICIO)
    ]
    if not reais:
        return
    nomes = ", ".join(reais[:3]) + (f" e mais {len(reais) - 3}" if len(reais) > 3 else "")
    raise CommandError(
        f"'seed_demo' recusado: este banco já tem {len(reais)} empresa(s) com dados reais ({nomes}) — "
        "CNPJ fora da faixa fictícia da demonstração. O seed misturaria a farmácia fictícia e usuários "
        "com senha pública aos dados de verdade, por isso a recusa vale mesmo com "
        "ALLOW_SEED_IN_PRODUCTION. Nada foi gravado. Se este servidor passou a ser de uso real, marque "
        "NEXBUY_USO_REAL=True no .env."
    )


def _gerar_logo_fake():
    """PNG sintético (círculo branco sobre azul, iniciais "VP") — mesma
    técnica já usada em `empresas/tests.py` para testar upload de logo,
    aqui reaproveitada só para a empresa de demonstração ter uma logo
    fictícia de verdade (item 2 da Sprint)."""
    if not PIL_DISPONIVEL:
        return None
    imagem = Image.new("RGB", (240, 240), "#1D4E89")
    desenho = ImageDraw.Draw(imagem)
    desenho.ellipse((24, 24, 216, 216), fill="#FFFFFF")
    desenho.text((92, 108), "VP", fill="#1D4E89")
    buffer = BytesIO()
    imagem.save(buffer, format="PNG")
    return ContentFile(buffer.getvalue(), name="logo_farmacia_vida_plena.png")


class Command(BaseCommand):
    help = "Popula uma experiência de demonstração completa do NEXBUY (Demo Experience 1.0), em uma empresa fictícia própria."

    # Demo publicada na internet: ver `--manter-senhas` na docstring do
    # módulo. Atributos de classe (e não só de `handle`) porque alguns
    # testes chamam métodos internos direto, sem passar por `handle`.
    manter_senhas = False
    usuarios_com_senha_publica_nesta_execucao = frozenset()

    def add_arguments(self, parser):
        parser.add_argument(
            "--manter-senhas",
            action="store_true",
            help=(
                "Não troca a senha de quem já existe (usuários novos recebem a senha pública de "
                "demonstração). Use na demonstração publicada na internet, depois de definir_senha_demo."
            ),
        )

    @transaction.atomic
    def handle(self, *args, **options):
        abortar_seed_em_producao("seed_demo")
        recusar_se_houver_dados_reais()
        self.manter_senhas = bool(options.get("manter_senhas"))
        self.usuarios_com_senha_publica_nesta_execucao = set()
        empresa, filial, filial_bairro, usuarios = self._criar_empresa_e_usuarios()
        self._criar_identidade_visual(empresa)
        self._criar_configuracao_financeira(empresa)
        # Vínculos multi-filial ANTES de qualquer Compra/Provisão — ver nota
        # de ordenação na docstring de `_criar_vinculos_filial`.
        self._criar_vinculos_filial(usuarios, filial, filial_bairro)
        categorias, centros_custo = self._criar_cadastros(empresa)
        fornecedores = self._criar_fornecedores(empresa)

        # Sprint de Consolidação (Gate 2A, P0-1/P1-4): Fluxo de Aprovação
        # multi-etapa na empresa PRINCIPAL — ANTES das provisões, porque
        # `criar_provisao` só encaminha a uma etapa se o fluxo já existir
        # no momento da criação. Precisa ser a empresa principal (e não a
        # 2ª empresa, como antes) porque é lá que os compradores de
        # demonstração realmente lançam — só assim o fluxo é demonstrável
        # ao vivo, não só visível como configuração estática no NCC.
        self._criar_fluxo_aprovacao(empresa)

        # CORE 1.0 (Épicos 2 e 12): Calendário Operacional e Configuração da
        # Plataforma ANTES do cálculo de capacidade — o limite diário da
        # demonstração já nasce refletindo o feriado/bloqueio de exemplo.
        excecoes_calendario = self._criar_calendario_operacional(empresa)
        self._criar_configuracao_plataforma(empresa)

        self._limpar_transacoes_anteriores(filial, filial_bairro)
        # Receita mensal, custos fixos e custos variáveis dos 12 meses (+
        # aquecimento e o mês seguinte) DEPOIS da limpeza: os custos
        # variáveis e as receitas fora da janela são apagados nela.
        self._criar_financeiro_base(filial)
        self._criar_financeiro_base_filial_bairro(filial_bairro)
        # Receitas extras (lançamento manual) ANTES do cálculo da
        # capacidade: elas somam à receita mensal no Motor, então o limite
        # diário usado para montar a história de compras já as considera.
        # Recriadas do zero a cada execução (limpas logo acima) — rodar o
        # seed 2x nunca duplica.
        receitas_extras = self._criar_receitas_extras(filial, filial_bairro)

        capacidade = calcular_capacidade_compra(filial, date.today().year, date.today().month)
        limite_diario = capacidade["limite_diario"]

        compras_criadas = self._criar_compras_mes_anterior(filial, fornecedores, categorias, centros_custo, usuarios)
        compras_criadas += self._criar_compras(filial, fornecedores, categorias, centros_custo, usuarios, limite_diario)
        compras_criadas += self._criar_compra_filial_bairro(
            filial_bairro, fornecedores, categorias, centros_custo, usuarios
        )
        provisoes_criadas = self._criar_provisoes(filial, fornecedores, categorias, usuarios, limite_diario)

        # CORE 1.0 (Épicos 8, 9 e 14): segunda empresa do grupo para
        # demonstrar o seletor de contexto/visão consolidada, e um fluxo de
        # aprovação de exemplo configurado nela (visível no NCC).
        segunda_empresa = self._criar_segunda_empresa(empresa, usuarios)

        # CORE 1.0 (Épico 7): RBAC de exemplo — criado DEPOIS das
        # transações, de propósito: o limite individual não interfere na
        # história já semeada; ele aparece ao vivo, na primeira compra que
        # o comprador fizer durante a apresentação.
        self._criar_rbac_demo(empresa, usuarios)

        # RC do Épico 01 (Correção 03): Motor de Capacidade em ação —
        # limite individual definido PELO SERVICE do Financeiro (gera
        # LogConfiguracao e notificação, visíveis no NCC e no sino) e uma
        # compradora bloqueada, para demonstrar a compra barrada na origem.
        # Depois das transações, como o RBAC: não altera a história semeada.
        self._criar_capacidade_demo(empresa, usuarios)

        # Pacote de Demonstração Comercial (Etapa 02): o roteiro de Compras
        # acima só demonstra Aprovada e Pendente — os outros dois status de
        # `Compra.Status` (Rejeitada e Bloqueada) nunca apareciam na
        # demonstração. Chamado DEPOIS de `_criar_capacidade_demo` de
        # propósito: só a partir daqui Carla (demo_comprador3) já está
        # bloqueada, condição necessária para o cenário "Bloqueada" abaixo.
        compras_criadas += self._criar_compra_rejeitada_e_bloqueada(
            filial, fornecedores, categorias, centros_custo, usuarios, limite_diario
        )

        # Prompt 2 (pré-Etapa 02), Gate D (Seção 9): eventos de auditoria
        # das categorias novas de `RegistroAuditoria` — depois de toda a
        # "história" do mês e do Motor de Capacidade, mesma razão de
        # `_criar_capacidade_demo` (não interfere em nada já semeado).
        self._criar_eventos_auditoria_gate_d(empresa, filial, filial_bairro, segunda_empresa, usuarios)

        # Análise Financeira: compras aprovadas dos 12 meses de histórico e
        # do mês corrente até ontem — por ÚLTIMO, de propósito: nada acima
        # (roteiro do mês, provisões, parcela baixada/estornada da
        # auditoria) enxerga essas compras, então a história ao vivo da
        # demonstração continua exatamente a mesma.
        historico = self._criar_historico_de_compras(
            filial, filial_bairro, fornecedores, categorias, centros_custo, usuarios
        )

        self._relatorio(
            empresa, filial, categorias, fornecedores, compras_criadas, provisoes_criadas, limite_diario,
            segunda_empresa, excecoes_calendario, filial_bairro=filial_bairro, receitas_extras=receitas_extras,
            historico=historico,
        )

    # ------------------------------------------------------------------
    # Empresa, filial e usuários
    # ------------------------------------------------------------------

    def _criar_empresa_e_usuarios(self):
        grupo, _ = GrupoEmpresarial.objects.get_or_create(nome="Grupo Vida Plena Farmácias")

        # Gate pré-Etapa 10 (S1-1): o CNPJ "98.765.432/0001-10" usado aqui
        # desde sempre NUNCA teve dígito verificador válido — passou
        # despercebido porque nada no seed chamava `full_clean()`. Trocado
        # por um CNPJ com o mesmo prefixo (mesma "cara" de dado fictício)
        # mas matematicamente válido (`core.validators.cnpj_e_valido`).
        # Gate pré-Etapa 10 (S1-1, item 3): lookup em dígitos — `Empresa`
        # agora persiste o CNPJ de forma canônica (só dígitos), então
        # comparar com uma string mascarada nunca bateria na 2ª execução.
        empresa, _ = Empresa.objects.update_or_create(
            cnpj="98765432000198",
            defaults={
                "nome": "Farmácia Vida Plena",
                "razao_social": "Vida Plena Farmácias Ltda",
                "grupo": grupo,
                "segmento": "Farmacêutico",
                "inscricao_estadual": "147.258.369",
                "telefone": "(66) 3411-5566",
                "email": "contato@farmaciavidaplena.com.br",
                "endereco": "Avenida Brasil, 1200 — Centro",
                "cidade": "Campo Novo do Parecis",
                "estado": "MT",
                "cep": "78360-000",
            },
        )

        # Gate pré-Etapa 10 (S1-1): a auditoria encontrou NENHUMA Filial
        # marcada como Matriz em nenhuma Empresa do seed — a raiz do
        # problema era `empresas/views_wizard.py` nunca setar
        # `tipo_estabelecimento` (já corrigido). A Loja Centro é o
        # estabelecimento fiscal raiz desta Empresa: vira Matriz e ganha
        # cadastro fiscal/endereço/responsável completo (CNPJ próprio
        # válido, razão social, IE, endereço e responsável — `nome_gerente`
        # abaixo é só o rótulo local pro relatório final).
        filial, _ = Filial.objects.update_or_create(
            empresa=empresa, nome="Loja Centro",
            defaults={
                "tipo_estabelecimento": Filial.TipoEstabelecimento.MATRIZ,
                # Gate C (Prompt 2, Seção 6): código interno fictício e
                # estável — identificador próprio da loja usado pela equipe
                # (ex.: em relatórios e na conferência de lançamentos).
                "codigo_interno": "F-CENTRO-01",
                "cnpj": "98765432000198",
                "razao_social": "Vida Plena Farmácias Ltda",
                "inscricao_estadual": "147.258.369",
                "endereco": "Avenida Brasil, 1200", "numero": "1200", "bairro": "Centro",
                "cidade": "Campo Novo do Parecis", "estado": "MT", "cep": "78360-000",
                "telefone": "(66) 3411-5566", "email": "contato@farmaciavidaplena.com.br",
                "ativo": True,
            },
        )

        # Sprint de Correções Críticas (Seção 7/9): segunda Filial DENTRO da
        # mesma Empresa principal — diferente da "Drogaria Vida Plena Norte"
        # (uma empresa/tenant à parte, já existente desde o CORE 1.0), esta
        # filial demonstra o cenário que a Sprint corrigiu de verdade:
        # multi-filial dentro de UMA empresa, via `UsuarioFilial` explícito
        # (ver `_criar_vinculos_filial`).
        filial_bairro, _ = Filial.objects.update_or_create(
            empresa=empresa, nome="Loja Bairro",
            defaults={
                "codigo_interno": "F-BAIRRO-01",
                "cnpj": "33445566000186",
                "razao_social": "Vida Plena Farmácias Ltda — Filial Bairro",
                "isento_inscricao_estadual": True,
                "endereco": "Rua das Palmeiras, 480", "numero": "480", "bairro": "Jardim Primavera",
                "cidade": "Campo Novo do Parecis", "estado": "MT", "cep": "78360-120",
                "telefone": "(66) 3411-5599",
                "ativo": True,
            },
        )

        usuarios_dados = [
            # Gate pré-Etapa 10 (S1-2): o Proprietário da demonstração NUNCA
            # pode ser is_staff/is_superuser — superusuário ignora o RBAC
            # inteiro (`core.permissions.usuario_tem_permissao` tem bypass
            # explícito), o que invalidava qualquer teste do "Proprietário
            # Operacional" feito com esta conta. O catálogo de permissões
            # (`core.permissions.CATALOGO_PERMISSOES`) já concede ao perfil
            # Proprietário tudo que ele precisa sem esse bypass.
            ("demo_proprietario", Usuario.Perfil.PROPRIETARIO, "Roberto", "Almeida", None, False),
            ("demo_gerente", Usuario.Perfil.GERENTE, "Fernanda", "Costa", filial, False),
            ("demo_financeiro", Usuario.Perfil.FINANCEIRO, "Marcos", "Vinícius", filial, False),
            ("demo_comprador", Usuario.Perfil.COMPRADOR, "Juliana", "Ramos", filial, False),
            ("demo_comprador2", Usuario.Perfil.COMPRADOR, "Pedro", "Henrique", filial, False),
            # RC do Épico 01 (Correção 03): terceira compradora, bloqueada
            # pelo Financeiro no fim do seed — a tela "Capacidade dos
            # Compradores" mostra os 3 estados (limite, sem gasto, bloqueada)
            # e o dashboard dela demonstra a compra barrada na origem.
            ("demo_comprador3", Usuario.Perfil.COMPRADOR, "Carla", "Menezes", filial, False),
        ]
        usuarios = {}
        for username, perfil, first_name, last_name, fil, acesso_total in usuarios_dados:
            usuario, criado = Usuario.objects.get_or_create(username=username)
            usuario.first_name = first_name
            usuario.last_name = last_name
            usuario.perfil = perfil
            usuario.empresa = empresa
            usuario.filial = fil
            usuario.is_staff = acesso_total
            usuario.is_superuser = acesso_total
            # Os 6 de login sempre saem ATIVOS: na demo publicada a cliente
            # (como Proprietário) pode desativar um deles em Usuários e
            # Permissões, e renovar o cenário devolve o acesso "um a um".
            usuario.is_active = True
            self._aplicar_senha_publica(usuario, criado)
            usuario.save()
            usuarios[username] = usuario

        # Gate pré-Etapa 10 (S1-1): responsável só pode ser atribuído
        # depois que os Usuários existem — a Loja Centro é a filial
        # principal do Gerente (fallback de `filiais_autorizadas_para`
        # cobre o caso sem `UsuarioFilial` explícito) e a Loja Bairro tem
        # vínculo explícito com o Financeiro (ver `_criar_vinculos_filial`).
        Filial.objects.filter(pk=filial.pk).update(
            responsavel_usuario=usuarios["demo_gerente"],
            responsavel_telefone="(66) 99988-7766",
            responsavel_email="gerente@farmaciavidaplena.com.br",
        )
        Filial.objects.filter(pk=filial_bairro.pk).update(
            responsavel_usuario=usuarios["demo_financeiro"],
            responsavel_telefone="(66) 99977-6655",
            responsavel_email="financeiro@farmaciavidaplena.com.br",
        )
        filial.refresh_from_db()
        filial_bairro.refresh_from_db()

        return empresa, filial, filial_bairro, usuarios

    def _aplicar_senha_publica(self, usuario, criado):
        """Senha pública de demonstração (DEMO_MODE.md) — exceto com
        `--manter-senhas`, em que quem já existia continua com a senha
        atual. Não salva: quem chama salva o usuário junto com o resto."""
        if criado or not self.manter_senhas:
            usuario.set_password(SENHA_DEMO)
            if isinstance(self.usuarios_com_senha_publica_nesta_execucao, set):
                self.usuarios_com_senha_publica_nesta_execucao.add(usuario.username)

    def _criar_identidade_visual(self, empresa):
        # Bug de duplicação (centenas de arquivos idênticos em
        # media/identidade/logos/): o PNG gerado por `_gerar_logo_fake` é
        # sempre o mesmo conteúdo determinístico, mas cada reset de banco
        # (sem limpar a pasta `media/` junto) recriava o registro e chamava
        # `logo.save(...)` de novo — o `FileSystemStorage` padrão, ao achar
        # que o nome já existe fisicamente em disco, cunha um sufixo
        # aleatório novo em vez de reaproveitar. Corrigido reaproveitando o
        # arquivo físico já existente sempre que o conteúdo é o mesmo, em
        # vez de deixar o storage gerar um nome novo a cada execução.
        identidade, criada = IdentidadeVisual.objects.get_or_create(
            empresa=empresa, defaults={"nome_exibicao": "Vida Plena Farmácias"}
        )
        if not PIL_DISPONIVEL:
            return
        nome_arquivo = "logo_farmacia_vida_plena.png"
        caminho_relativo = f"identidade/logos/{nome_arquivo}"
        if identidade.logo and identidade.logo.name == caminho_relativo and default_storage.exists(caminho_relativo):
            # Já aponta para o arquivo canônico e ele existe fisicamente —
            # idempotente de verdade, nada a fazer.
            return
        logo = _gerar_logo_fake()
        if logo is None:
            return
        if default_storage.exists(caminho_relativo):
            # O conteúdo é sempre determinístico (mesmo PNG gerado sempre) —
            # reaproveita o arquivo físico já existente em vez de deixar o
            # FileSystemStorage cunhar um nome novo com sufixo aleatório a
            # cada reset de banco.
            identidade.logo.name = caminho_relativo
            identidade.nome_exibicao = "Vida Plena Farmácias"
            identidade.save(update_fields=["logo", "nome_exibicao"])
        else:
            identidade.nome_exibicao = "Vida Plena Farmácias"
            identidade.logo.save(nome_arquivo, logo, save=True)

    def _criar_configuracao_financeira(self, empresa):
        """Capacidade Financeira da empresa de demonstração — ver
        `PERCENTUAL_COMPRAS_DEMO` (compras de ~63% da receita quando o
        limite diário é usado por inteiro, o peso normal de uma farmácia)."""
        ConfiguracaoFinanceira.objects.update_or_create(
            empresa=empresa,
            defaults={
                "percentual_compras": PERCENTUAL_COMPRAS_DEMO,
                "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
                "cor_principal": "",
            },
        )

    def _meses_da_receita(self):
        """(k, 1º dia do mês) de k = -13 até o mês seguinte (k = +1)."""
        hoje = date.today()
        meses = []
        for k in range(-MESES_DE_HISTORICO, 2):
            ano, mes = _somar_meses(hoje.year, hoje.month, k)
            meses.append((k, date(ano, mes, 1)))
        return meses

    def _criar_financeiro_da_loja(self, loja):
        """Receita mensal de 13 meses de histórico + mês corrente + mês
        seguinte (sazonalidade de `PERFIL_MENSAL`), custos fixos da loja e
        custos variáveis de todo mês (impostos, cartão, comissões, entregas).

        Showcase (Seção 4): a receita do mês seguinte continua existindo —
        provisões/parcelas que caem na virada de mês têm capacidade
        calculável. Idempotente: receita por `update_or_create` (filial +
        mês), custos fixos por descrição (os que saíram da lista são
        apagados), custos variáveis recriados do zero (apagados em
        `_limpar_transacoes_anteriores`)."""
        dados = LOJAS_DEMO[loja.nome]
        for k, mes in self._meses_da_receita():
            Receita.objects.update_or_create(
                filial=loja, mes=mes, defaults={"faturamento": _receita_mensal_demo(dados, k)}
            )

        descricoes_fixas = []
        for descricao, fornecedor_nome, valor, dia in dados["custos_fixos"]:
            CustoFixo.objects.update_or_create(
                filial=loja,
                descricao=descricao,
                defaults={"fornecedor": fornecedor_nome, "valor": valor, "dia_vencimento": dia, "ativo": True},
            )
            descricoes_fixas.append(descricao)
        CustoFixo.objects.filter(filial=loja).exclude(descricao__in=descricoes_fixas).delete()

        variaveis = []
        for k, mes in self._meses_da_receita():
            receita_mensal = _receita_mensal_demo(dados, k)
            for descricao, fracao, dia in CUSTOS_VARIAVEIS_MENSAIS:
                variaveis.append(CustoVariavel(
                    empresa=loja.empresa, filial=loja, descricao=descricao,
                    valor=(receita_mensal * fracao).quantize(CENTAVO, ROUND_HALF_UP),
                    data_prevista=_dia_no_mes(mes.year, mes.month, dia),
                ))
        CustoVariavel.objects.bulk_create(variaveis)

    def _criar_financeiro_base(self, filial):
        self._criar_financeiro_da_loja(filial)
        # Showcase (Seção 4): custo variável sempre em data PRÓXIMA (hoje+5,
        # cruzando a virada de mês sem sustos) — antes era o dia 14 fixo do
        # mês, que já podia ter passado. A chave do update_or_create perdeu
        # a data de propósito: com a data na chave, cada execução em um dia
        # diferente criaria um registro novo (idempotência quebrada).
        custos_variaveis = [
            ("Campanha Sazonal de Inverno", Decimal("8500"), date.today() + timedelta(days=5)),
        ]
        for descricao, valor, data_prevista in custos_variaveis:
            CustoVariavel.objects.update_or_create(
                filial=filial, descricao=descricao,
                defaults={"valor": valor, "data_prevista": data_prevista},
            )

    def _criar_receitas_extras(self, filial, filial_bairro):
        """Receitas extras realistas de todo mês nas duas lojas (lançamento
        manual — mudança de escopo): repasse de convênio/PBM, serviços
        farmacêuticos e, na Loja Centro, rendimento de aplicação. No mês
        corrente as datas nunca ficam no futuro (dia <= hoje), para a
        demonstração fazer sentido em qualquer dia do calendário.

        Devolve as receitas extras do mês corrente da Loja Centro (usadas no
        relatório do console). Idempotente: `_limpar_transacoes_anteriores`
        apaga as receitas extras das filiais de demonstração antes desta
        chamada."""
        hoje = date.today()
        extras = []
        do_mes_centro = []
        for loja in (filial, filial_bairro):
            dados = LOJAS_DEMO[loja.nome]
            for k, mes in self._meses_da_receita():
                if k > 0:
                    continue  # receita extra é fato consumado — nunca lançada no futuro
                receita_mensal = _receita_mensal_demo(dados, k)
                for dia, descricao, categoria, fracao, observacao in dados["receitas_extras"]:
                    data_receita = _dia_no_mes(mes.year, mes.month, dia)
                    if k == 0:
                        data_receita = hoje.replace(day=min(dia, hoje.day))
                    if fracao is None:  # rendimento da aplicação: valor pequeno que varia pouco
                        valor = Decimal("380.35") + Decimal(15 * ((k + MESES_DE_HISTORICO) % 7))
                    else:
                        valor = (receita_mensal * fracao * (1 + _ruido(k, dados["semente"] + 2))).quantize(
                            CENTAVO, ROUND_HALF_UP
                        )
                    receita = ReceitaExtra(
                        empresa=loja.empresa, filial=loja, data=data_receita, descricao=descricao,
                        categoria=categoria, valor=valor, observacao=observacao,
                    )
                    extras.append(receita)
                    if k == 0 and loja == filial:
                        do_mes_centro.append(receita)
        ReceitaExtra.objects.bulk_create(extras)
        return do_mes_centro

    def _criar_financeiro_base_filial_bairro(self, filial_bairro):
        """Receita própria da Loja Bairro (Seção 10) — sem isso ela seria
        uma filial "fantasma", sem capacidade de compra calculável — agora
        com o mesmo histórico de 12 meses e os custos próprios da loja
        (Análise Financeira "Todas as filiais" soma as duas lojas)."""
        self._criar_financeiro_da_loja(filial_bairro)

    def _criar_vinculos_filial(self, usuarios, filial_centro, filial_bairro):
        """Sprint de Correções Críticas (Seção 7): vínculo `UsuarioFilial`
        explícito. O Financeiro e o segundo Comprador de demonstração
        ganham as DUAS filiais — precisa ser as duas, nunca só a nova:
        assim que um usuário ganha QUALQUER vínculo explícito,
        `filiais_autorizadas_para` (Seção 9) para de usar o fallback de
        compatibilidade (que devolvia a filial principal de graça) e passa
        a valer exclusivamente a lista explícita. Rodar isto ANTES de criar
        as Compras/Provisões do roteiro é obrigatório: sem o vínculo na
        Loja Centro, a compra de Pedro (demo_comprador2) lá dentro seria
        barrada pela revalidação do próprio service (Seção 11).

        Gate C (Prompt 2, Seção 7): a auditoria encontrou demo_gerente,
        demo_comprador e demo_comprador3 sem NENHUM `UsuarioFilial`
        explícito — dependiam inteiramente do fallback legado (o
        `Usuario.filial` de cada um). Usuários criados pelo `seed_demo` não
        são contas legadas; cada Gerente/Financeiro/Comprador ativo ganha
        pelo menos o vínculo explícito com a própria Filial principal."""
        for chave_usuario in ("demo_financeiro", "demo_comprador2"):
            for filial in (filial_centro, filial_bairro):
                UsuarioFilial.objects.update_or_create(
                    usuario=usuarios[chave_usuario], filial=filial, defaults={"ativo": True}
                )
        for chave_usuario in ("demo_gerente", "demo_comprador", "demo_comprador3"):
            UsuarioFilial.objects.update_or_create(
                usuario=usuarios[chave_usuario], filial=filial_centro, defaults={"ativo": True}
            )

    # ------------------------------------------------------------------
    # Cadastros
    # ------------------------------------------------------------------

    def _criar_cadastros(self, empresa):
        categorias = {}
        for nome in CATEGORIAS_DEMO:
            categoria, _ = Categoria.objects.get_or_create(empresa=empresa, nome=nome)
            categorias[nome] = categoria

        centros_custo = {}
        from cadastros.models import CentroCusto

        for nome in CENTROS_CUSTO_DEMO:
            centro, _ = CentroCusto.objects.get_or_create(empresa=empresa, nome=nome)
            centros_custo[nome] = centro

        return categorias, centros_custo

    def _criar_fornecedores(self, empresa):
        fornecedores_dados = [
            (
                "MedForte Distribuidora",
                {
                    "razao_social": "MedForte Distribuidora de Medicamentos Ltda",
                    # Showcase: os 5 CNPJs de fornecedor nunca tinham dígito
                    # verificador válido (a correção S1-1 alcançou só
                    # Empresa/Filial). Mesmos prefixos, DVs agora corretos.
                    "cnpj": "21.111.222/0001-51",
                    "inscricao_estadual": "141.111.222",
                    "telefone": "(66) 3211-4433",
                    "whatsapp": "(66) 99911-4433",
                    "email": "vendas@medforte.com.br",
                    "cidade": "Cuiabá",
                    "estado": "MT",
                },
            ),
            (
                "Laboratório Vitalis",
                {
                    "razao_social": "Vitalis Indústria Farmacêutica S.A.",
                    "cnpj": "21.333.444/0001-19",
                    "inscricao_estadual": "141.333.444",
                    "telefone": "(11) 4002-8899",
                    "email": "comercial@vitalis.com.br",
                    "cidade": "São Paulo",
                    "estado": "SP",
                },
            ),
            (
                "BelezaPura Perfumaria",
                {
                    "razao_social": "BelezaPura Cosméticos e Perfumaria Ltda",
                    "cnpj": "21.555.666/0001-86",
                    "telefone": "(65) 3344-7788",
                    "whatsapp": "(65) 99944-7788",
                    "email": "pedidos@belezapura.com.br",
                    "cidade": "Cuiabá",
                    "estado": "MT",
                },
            ),
            (
                "Higicare Produtos de Higiene",
                {
                    "razao_social": "Higicare Produtos de Higiene Ltda",
                    "cnpj": "21.777.888/0001-43",
                    "telefone": "(66) 3455-9900",
                    "email": "contato@higicare.com.br",
                    "cidade": "Campo Novo do Parecis",
                    "estado": "MT",
                },
            ),
            (
                "FarmaMax Medicamentos",
                {
                    "razao_social": "FarmaMax Comércio de Medicamentos Ltda",
                    "cnpj": "21.999.000/0001-17",
                    "inscricao_estadual": "141.999.000",
                    "telefone": "(66) 3466-1122",
                    "whatsapp": "(66) 99966-1122",
                    "email": "vendas@farmamax.com.br",
                    "cidade": "Tangará da Serra",
                    "estado": "MT",
                },
            ),
        ]
        fornecedores = {}
        for nome, dados in fornecedores_dados:
            fornecedor, _ = Fornecedor.objects.update_or_create(empresa=empresa, nome=nome, defaults=dados)
            fornecedores[nome] = fornecedor
        return fornecedores

    def _criar_fluxo_aprovacao(self, empresa):
        """Fluxo de Aprovação multi-etapa de exemplo (Épico 8) — Gerente
        decide sozinho até R$ 2.000,00; acima disso, a solicitação avança
        para o Financeiro. `criar_provisao` encontra este fluxo sozinho
        (é só filtrar por empresa + ativo) — nenhuma mudança de regra,
        só dar à empresa principal da demo a mesma configuração que só
        existia (e nunca podia ser demonstrada ao vivo) na 2ª empresa."""
        fluxo, criado = FluxoAprovacao.objects.get_or_create(
            empresa=empresa, nome="Fluxo Padrão — Gerente e Financeiro", defaults={"ativo": True}
        )
        if not fluxo.ativo:
            fluxo.ativo = True
            fluxo.save(update_fields=["ativo"])
        if criado:
            EtapaFluxo.objects.create(
                fluxo=fluxo, ordem=1, perfil_aprovador=Usuario.Perfil.GERENTE,
                valor_maximo=Decimal("2000.00"), prazo_dias=2,
                observacao="Alçada do Gerente: até R$ 2.000,00.",
            )
            EtapaFluxo.objects.create(
                fluxo=fluxo, ordem=2, perfil_aprovador=Usuario.Perfil.FINANCEIRO, prazo_dias=2,
                observacao="Acima da alçada do Gerente, decide o Financeiro.",
            )
        return fluxo

    # ------------------------------------------------------------------
    # Transações (Compras e Provisões) — sempre via services reais
    # ------------------------------------------------------------------

    def _limpar_transacoes_anteriores(self, filial, filial_bairro):
        """Recria a "história" do mês do zero a cada execução, para que as
        datas sempre façam sentido em relação ao dia de hoje. Afeta as duas
        filiais da empresa de demonstração (isoladas de qualquer dado real).

        Também limpa as notificações da empresa de demonstração (Sprint de
        Consolidação, Gate 2A, P0-1: idempotência de verdade) — sem isto,
        cada `seed_demo` soma às notificações da execução anterior e o sino
        acumula dezenas de "não lidas" repetidas a cada reset, o que
        atrapalha (não ajuda) a demonstração comercial.

        Sprint de Apresentação Comercial (Seção 11.2): a trilha de
        auditoria da EMPRESA FICTÍCIA agora também é recriada do zero a
        cada execução — antes, cada `PREPARAR` repetido duplicava as linhas
        da Central de Auditoria e do Log de Configuração, e a "história"
        auditada parava de bater com as Compras/Provisões (que sempre foram
        recriadas). Isto NÃO enfraquece o caráter append-only da auditoria
        no ambiente normal: a limpeza vive exclusivamente DENTRO deste
        comando de seed, que é bloqueado com DEBUG=False
        (`abortar_seed_em_producao`) e só alcança as empresas de
        demonstração (CNPJs fictícios 98765432*). Nenhuma view, service ou
        tela ganhou qualquer caminho de apagar auditoria.

        Histórico de 12 meses (Análise Financeira): as compras do histórico
        saem junto com as demais Compras; os custos variáveis mensais são
        recriados do zero (`_criar_financeiro_da_loja`); receitas mensais
        fora da janela (13 meses antes até o mês seguinte) são apagadas —
        rodar o seed em outro mês não deixa um "rabo" de meses antigos.

        Limites individuais e bloqueios dos compradores de demonstração
        voltam a "sem limite/liberado" ANTES do roteiro: `_criar_rbac_demo`
        e `_criar_capacidade_demo` os definem de novo no fim. Sem isso, a
        2ª execução lançava o roteiro com os limites da 1ª já valendo e
        compras que nasceram Aprovadas viravam Pendentes (idempotência)."""
        from empresas.models import LogConfiguracao

        Compra.objects.filter(filial__in=(filial, filial_bairro)).delete()
        Provisao.objects.filter(filial__in=(filial, filial_bairro)).delete()
        # Receitas extras de demonstração são recriadas do zero a cada
        # execução (`_criar_receitas_extras`) — idempotência de verdade.
        ReceitaExtra.objects.filter(filial__in=(filial, filial_bairro)).delete()
        CustoVariavel.objects.filter(filial__in=(filial, filial_bairro)).delete()
        Receita.objects.filter(filial__in=(filial, filial_bairro)).exclude(
            mes__in=[mes for _k, mes in self._meses_da_receita()]
        ).delete()
        UsuarioEmpresa.objects.filter(
            empresa=filial.empresa, usuario__username__startswith="demo_",
        ).update(limite_compra=None, bloqueado=False)
        Notificacao.objects.filter(empresa=filial.empresa).delete()
        RegistroAuditoria.objects.filter(empresa__cnpj__startswith="98765432").delete()
        LogConfiguracao.objects.filter(empresa__cnpj__startswith="98765432").delete()

    def _criar_compras_mes_anterior(self, filial, fornecedores, categorias, centros_custo, usuarios):
        """Showcase (Seção 4): pré-história no MÊS ANTERIOR, com datas
        RELATIVAS a hoje — garante que dashboards, relatórios e a Agenda
        Financeira nunca abrem vazios mesmo quando a demonstração roda nos
        primeiros dias do mês (quando quase todo o roteiro do mês corrente
        ainda está no futuro e é pulado). A compra de hoje-30 em D30 gera
        uma parcela vencendo por volta de HOJE — a Agenda sempre tem um
        vencimento imediato de compra, não só custos fixos.

        Só na Loja Centro (na Loja Bairro a única compra lançada pelo
        service é a de HOJE — `core/tests.py::test_compra_de_demonstracao_
        na_loja_bairro` usa `.get()` no dia de hoje; o histórico dela vem de
        `_criar_historico_de_compras`). Proporções baixas (<= 0.40 do limite diário do mês
        anterior): tudo nasce Aprovado — a fila de pendências do mês
        corrente continua contando a história de sempre. A Receita do mês
        anterior é criada em `_criar_financeiro_base`. Idempotente: as
        Compras são recriadas do zero a cada execução."""
        hoje = date.today()
        mes_anterior_ref = hoje.replace(day=1) - timedelta(days=1)
        capacidade_anterior = calcular_capacidade_compra(filial, mes_anterior_ref.year, mes_anterior_ref.month)
        limite_anterior = capacidade_anterior["limite_diario"]

        roteiro_anterior = [
            (30, Decimal("0.30"), "MedForte Distribuidora", "Genéricos", "demo_comprador", Compra.PrazoPagamento.D30),
            (25, Decimal("0.40"), "FarmaMax Medicamentos", "Medicamentos", "demo_comprador2", Compra.PrazoPagamento.D30_60),
            (20, Decimal("0.25"), "Higicare Produtos de Higiene", "Higiene", "demo_comprador", Compra.PrazoPagamento.D30),
        ]
        criadas = []
        for dias_atras, proporcao, fornecedor_nome, categoria_nome, username, prazo in roteiro_anterior:
            data_compra = hoje - timedelta(days=dias_atras)
            if data_compra.month == hoje.month and data_compra.year == hoje.year:
                # Fim de mês: o dia já pertence ao mês corrente e o roteiro
                # normal cobre a história — não duplica a narrativa.
                continue
            valor = (
                (limite_anterior * proporcao).quantize(Decimal("0.01"))
                if limite_anterior > 0 else Decimal("180.00")
            )
            avaliacao = avaliar_e_criar_compra(
                filial=filial,
                fornecedor=fornecedores[fornecedor_nome],
                valor=valor,
                categoria=categorias[categoria_nome],
                centro_custo=centros_custo["Compras"],
                data_compra=data_compra,
                prazo_pagamento=prazo,
                prazo_personalizado_dias=None,
                usuario=usuarios[username],
                observacao="[DEMO] Pedido do mês anterior (histórico).",
            )
            criadas.append(avaliacao.compra)
        return criadas

    def _criar_compras(self, filial, fornecedores, categorias, centros_custo, usuarios, limite_diario):
        hoje = date.today()
        ultimo_dia = calendar.monthrange(hoje.year, hoje.month)[1]
        # Ajuste final (produto-e-demo): seed rodado num sábado, domingo ou
        # feriado datava o pedido "de hoje" num dia SEM limite — o Dashboard
        # Executivo abria com "Capacidade de hoje excedida" e as lojas em
        # "Excedido". Os itens "de hoje" vão para o último dia que conta
        # capacidade (hoje, num dia útil).
        dia_referencia = self._dia_de_referencia(filial.empresa, hoje)

        def dia_seguro(dia):
            return min(dia, ultimo_dia)

        # (dia, proporção do limite diário, fornecedor, categoria, comprador)
        # — a proporção controla deliberadamente a cor do dia no calendário:
        # dias tranquilos (verde), um dia de atenção (laranja) e um dia
        # crítico (vermelho), como pedido no item 10 da Sprint.
        roteiro = [
            (2, Decimal("0.25"), "FarmaMax Medicamentos", "Medicamentos", "demo_comprador"),
            (4, Decimal("0.35"), "MedForte Distribuidora", "Genéricos", "demo_comprador2"),
            (7, Decimal("0.40"), "BelezaPura Perfumaria", "Perfumaria", "demo_comprador"),
            (9, Decimal("0.20"), "Higicare Produtos de Higiene", "Higiene", "demo_comprador2"),
            (12, Decimal("0.55"), "Laboratório Vitalis", "Medicamentos", "demo_comprador"),
            (15, Decimal("0.85"), "MedForte Distribuidora", "Genéricos", "demo_comprador"),
            (18, Decimal("1.35"), "FarmaMax Medicamentos", "Medicamentos", "demo_comprador2"),
            (21, Decimal("0.30"), "Higicare Produtos de Higiene", "Higiene", "demo_comprador"),
            (24, Decimal("0.45"), "BelezaPura Perfumaria", "Perfumaria", "demo_comprador2"),
        ]

        # CORE 1.0 (Épico 4): prazos variados para a Agenda Financeira e o
        # card "Próximos vencimentos" nunca abrirem vazios — inclui
        # parcelamentos 30/60 e 30/60/90 e um personalizado em 4x.
        prazos_roteiro = [
            Compra.PrazoPagamento.D30,
            Compra.PrazoPagamento.D30_60,
            Compra.PrazoPagamento.AVISTA,
            Compra.PrazoPagamento.D30_60_90,
            Compra.PrazoPagamento.D30,
            Compra.PrazoPagamento.D30_60_90,
            Compra.PrazoPagamento.D30,
            Compra.PrazoPagamento.PERSONALIZADO,
            Compra.PrazoPagamento.D30_60,
        ]

        criadas = []
        for indice, (dia, proporcao, fornecedor_nome, categoria_nome, username) in enumerate(roteiro):
            data_compra = date(hoje.year, hoje.month, dia_seguro(dia))
            if data_compra > hoje:
                continue  # não cria "história" no futuro — só o calendário mostra o futuro em branco
            if data_compra == hoje:
                data_compra = dia_referencia
            valor = (limite_diario * proporcao).quantize(Decimal("0.01")) if limite_diario > 0 else Decimal("150.00")
            prazo = prazos_roteiro[indice % len(prazos_roteiro)]
            avaliacao = avaliar_e_criar_compra(
                filial=filial,
                fornecedor=fornecedores[fornecedor_nome],
                valor=valor,
                categoria=categorias[categoria_nome],
                centro_custo=centros_custo["Compras"],
                data_compra=data_compra,
                prazo_pagamento=prazo,
                prazo_personalizado_dias=15 if prazo == Compra.PrazoPagamento.PERSONALIZADO else None,
                numero_parcelas=4 if prazo == Compra.PrazoPagamento.PERSONALIZADO else 1,
                usuario=usuarios[username],
                observacao="[DEMO] Pedido de demonstração.",
            )
            criadas.append(avaliacao.compra)

        # Um pedido de hoje (ou do último dia útil), sempre presente, para o
        # Dashboard nunca abrir vazio.
        if not any(c.data_compra == dia_referencia for c in criadas):
            valor_hoje = (limite_diario * Decimal("0.30")).quantize(Decimal("0.01")) if limite_diario > 0 else Decimal("150.00")
            avaliacao_hoje = avaliar_e_criar_compra(
                filial=filial,
                fornecedor=fornecedores["FarmaMax Medicamentos"],
                valor=valor_hoje,
                categoria=categorias["Medicamentos"],
                centro_custo=centros_custo["Compras"],
                data_compra=dia_referencia,
                prazo_pagamento=Compra.PrazoPagamento.AVISTA,
                prazo_personalizado_dias=None,
                usuario=usuarios["demo_comprador"],
                observacao="[DEMO] Pedido de demonstração.",
            )
            criadas.append(avaliacao_hoje.compra)

        return criadas

    def _criar_compra_filial_bairro(self, filial_bairro, fornecedores, categorias, centros_custo, usuarios):
        """Sprint de Correções Críticas (Seção 11): uma Compra real na
        Loja Bairro, lançada por Pedro (demo_comprador2) — autorizado nas
        DUAS filiais desde `_criar_vinculos_filial` — mostra o seletor de
        filial de Nova Compra funcionando ao vivo, não só como vínculo
        configurado silenciosamente no banco.

        Datada no dia de referência (hoje, ou o último dia útil quando hoje
        não conta capacidade — ver `_dia_de_referencia`)."""
        hoje = date.today()
        dia_referencia = self._dia_de_referencia(filial_bairro.empresa, hoje)
        capacidade_bairro = calcular_capacidade_compra(filial_bairro, hoje.year, hoje.month)
        limite_diario_bairro = capacidade_bairro["limite_diario"]
        valor = (
            (limite_diario_bairro * Decimal("0.30")).quantize(Decimal("0.01"))
            if limite_diario_bairro > 0 else Decimal("120.00")
        )
        avaliacao = avaliar_e_criar_compra(
            filial=filial_bairro,
            fornecedor=fornecedores["Higicare Produtos de Higiene"],
            valor=valor,
            categoria=categorias["Higiene"],
            centro_custo=centros_custo["Compras"],
            data_compra=dia_referencia,
            prazo_pagamento=Compra.PrazoPagamento.D30,
            prazo_personalizado_dias=None,
            usuario=usuarios["demo_comprador2"],
            observacao="[DEMO] Pedido de demonstração — Loja Bairro.",
        )
        return [avaliacao.compra]

    def _criar_provisoes(self, filial, fornecedores, categorias, usuarios, limite_diario):
        hoje = date.today()

        # Showcase (Seção 4): as datas das provisões agora são deltas REAIS
        # a partir de hoje (cruzam a virada de mês naturalmente) — antes
        # eram presas ao mês corrente por `min(dia, ultimo_dia)`, o que no
        # fim do mês empilhava tudo no último dia e nunca criava a provisão
        # "de amanhã". A Receita do mês seguinte (criada em
        # `_criar_financeiro_base`) garante o cálculo de saldo dessas datas.
        def dia_relativo(dias_a_frente):
            return hoje + timedelta(days=dias_a_frente)

        def itens(*produtos_valores):
            return [
                {"produto": produto, "quantidade": Decimal("1"), "valor_unitario": valor}
                for produto, valor in produtos_valores
            ]

        criadas = {
            "aprovada": None, "pendente": None, "reprovada": None, "ajustes": None, "normal": None,
            "efetivada": None, "autoaprovada": None,
        }

        base = limite_diario if limite_diario > 0 else Decimal("3000.00")

        # 1) Provisão dentro do saldo — nasce Provisionada, sem necessidade de aprovação.
        provisao_normal, _, _ = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador"],
            fornecedor=fornecedores["Higicare Produtos de Higiene"],
            categoria=categorias["Higiene"],
            data_provisao=dia_relativo(2),
            observacoes="Reposição mensal de itens de higiene.",
            itens_dados=itens(("Sabonete Líquido Antisséptico (250ml)", (base * Decimal("0.10")).quantize(Decimal("0.01")))),
        )
        criadas["normal"] = provisao_normal

        # 2) Provisão acima do saldo, aprovada em seguida — mostra o fluxo completo de decisão.
        provisao_aprovada, solicitacao_aprovada, excedeu = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador2"],
            fornecedor=fornecedores["Laboratório Vitalis"],
            categoria=categorias["Medicamentos"],
            data_provisao=dia_relativo(3),
            observacoes="Reforço de compra para campanha de inverno — acima do saldo do dia.",
            itens_dados=itens(
                ("Vitamina C 1g Efervescente (tubo)", (base * Decimal("0.90")).quantize(Decimal("0.01"))),
                ("Paracetamol 750mg (cx 20cp)", (base * Decimal("0.60")).quantize(Decimal("0.01"))),
            ),
        )
        if excedeu and solicitacao_aprovada:
            # Com o Fluxo de Aprovação ativo (P1-4), a etapa do Gerente só é
            # final se o valor couber na alçada dele — caso contrário a
            # solicitação avança para o Financeiro e precisa de uma segunda
            # decisão para realmente terminar "aprovada". `aprovar` já
            # retorna a Provisão em qualquer um dos dois casos; o jeito
            # seguro de saber se ainda falta uma etapa é reconsultar a
            # solicitação.
            motor_aprovacao_provisao.aprovar(
                solicitacao_aprovada, usuarios["demo_gerente"], "Aprovado pela Gerência — dentro do processo padrão."
            )
            solicitacao_aprovada.refresh_from_db()
            if solicitacao_aprovada.status == SolicitacaoAprovacao.Status.PENDENTE:
                motor_aprovacao_provisao.aprovar(
                    solicitacao_aprovada, usuarios["demo_financeiro"],
                    "Aprovado pelo Financeiro — reforço sazonal já previsto no orçamento.",
                )
        criadas["aprovada"] = provisao_aprovada

        # 3) Provisão acima do saldo, ainda pendente — a fila de aprovação nunca aparece vazia.
        provisao_pendente, _, _ = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador"],
            fornecedor=fornecedores["MedForte Distribuidora"],
            categoria=categorias["Genéricos"],
            data_provisao=dia_relativo(4),
            observacoes="Compra programada de genéricos — aguardando aprovação.",
            itens_dados=itens(("Amoxicilina 500mg (cx 15cp)", (base * Decimal("1.10")).quantize(Decimal("0.01")))),
        )
        criadas["pendente"] = provisao_pendente

        # 4) Provisão acima do saldo, rejeitada — mostra o desfecho negativo também.
        provisao_reprovada, solicitacao_reprovada, excedeu_reprovada = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador2"],
            fornecedor=fornecedores["FarmaMax Medicamentos"],
            categoria=categorias["Medicamentos"],
            data_provisao=dia_relativo(1),
            observacoes="Pedido extra fora do planejamento do mês.",
            itens_dados=itens(("Dipirona Monoidratada 500mg (cx 20cp)", (base * Decimal("1.20")).quantize(Decimal("0.01")))),
        )
        if excedeu_reprovada and solicitacao_reprovada:
            motor_aprovacao_provisao.rejeitar(
                solicitacao_reprovada, usuarios["demo_financeiro"], "Fora do orçamento do mês — reavaliar no próximo ciclo de compras."
            )
        criadas["reprovada"] = provisao_reprovada

        # 5) Provisão com ajustes solicitados — mostra o 3º desfecho possível (Sprint 6).
        provisao_ajustes, solicitacao_ajustes, excedeu_ajustes = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador"],
            fornecedor=fornecedores["BelezaPura Perfumaria"],
            categoria=categorias["Perfumaria"],
            data_provisao=dia_relativo(5),
            observacoes="Linha nova de perfumaria — quantidade a confirmar com o fornecedor.",
            itens_dados=itens(("Protetor Solar FPS 60 (200ml)", (base * Decimal("1.05")).quantize(Decimal("0.01")))),
        )
        if excedeu_ajustes and solicitacao_ajustes:
            motor_aprovacao_provisao.solicitar_ajustes(
                solicitacao_ajustes, usuarios["demo_gerente"], "Confirmar quantidade mínima de compra com o fornecedor antes de aprovar."
            )
        criadas["ajustes"] = provisao_ajustes

        # 6) Provisão prevista para amanhã — alimenta o insight "Há compras previstas para amanhã".
        # Showcase (Seção 4): a provisão de amanhã existe SEMPRE — inclusive
        # na virada de mês (a Receita do mês seguinte garante o cálculo).
        amanha = hoje + timedelta(days=1)
        criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador2"],
            fornecedor=fornecedores["Higicare Produtos de Higiene"],
            categoria=categorias["Higiene"],
            data_provisao=amanha,
            observacoes="Reposição programada para amanhã.",
            itens_dados=itens(("Álcool em Gel 70% (500ml)", (base * Decimal("0.20")).quantize(Decimal("0.01")))),
        )

        # 7) Provisão aprovada E EFETIVADA — o fluxo completo que a Sprint
        # de Correções Críticas implementou (Seção 12): Provisão -> Compra
        # real, com parcela gerada e o badge "Efetivada" na timeline. Antes
        # desta Sprint o status EFETIVADA existia no enum mas nunca era
        # alcançado por nenhum caminho do sistema — vale a pena mostrar ao
        # vivo. Data no PASSADO recente (histórico já concluído), não na
        # janela de "próximos dias" das demais provisões pendentes; o valor
        # é o DOBRO da base para garantir que excede o saldo do dia
        # independente do que mais já esteja lançado nesse dia.
        dia_efetivada = hoje - timedelta(days=3)
        provisao_efetivar, solicitacao_efetivar, excedeu_efetivar = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_comprador"],
            fornecedor=fornecedores["MedForte Distribuidora"],
            categoria=categorias["Material de Escritório"],
            data_provisao=dia_efetivada,
            observacoes="Material de escritório recorrente — provisão já efetivada em compra real.",
            itens_dados=itens(("Papel A4 (resma 500fl)", (base * Decimal("2.00")).quantize(Decimal("0.01")))),
        )
        if excedeu_efetivar and solicitacao_efetivar:
            motor_aprovacao_provisao.aprovar(
                solicitacao_efetivar, usuarios["demo_gerente"], "Aprovado — item recorrente já previsto no orçamento."
            )
            solicitacao_efetivar.refresh_from_db()
            if solicitacao_efetivar.status == SolicitacaoAprovacao.Status.PENDENTE:
                motor_aprovacao_provisao.aprovar(
                    solicitacao_efetivar, usuarios["demo_financeiro"], "Aprovado pelo Financeiro — dentro do orçamento."
                )
        provisao_efetivar.refresh_from_db()
        if provisao_efetivar.status == Provisao.Status.APROVADA:
            efetivar_provisao(
                provisao_id=provisao_efetivar.pk, usuario=usuarios["demo_financeiro"],
                prazo_pagamento=Compra.PrazoPagamento.D30,
            )
            provisao_efetivar.refresh_from_db()
        criadas["efetivada"] = provisao_efetivar

        # 8) Provisão com AUTOAPROVAÇÃO CONTROLADA — Gate pré-Etapa 10
        # (S1-3, item 6): "comprove... autoaprovação destacada". Só é
        # possível porque `_criar_configuracao_plataforma` ligou
        # `permitir_autoaprovacao` para esta empresa — em qualquer outra
        # empresa (padrão) `autoaprovacao_bloqueada` recusaria isto. O
        # Proprietário de demonstração (não-superusuário desde o Gate,
        # ver S1-2) cria E decide a própria solicitação — cenário real de
        # cliente pequeno sem outra pessoa disponível para aprovar.
        provisao_autoaprovada, solicitacao_autoaprovada, excedeu_auto = criar_provisao(
            filial=filial,
            comprador=usuarios["demo_proprietario"],
            fornecedor=fornecedores["Higicare Produtos de Higiene"],
            categoria=categorias["Higiene"],
            data_provisao=dia_relativo(6),
            observacoes="Compra emergencial decidida diretamente pelo Proprietário — autoaprovação controlada.",
            itens_dados=itens(("Álcool em Gel 70% (500ml)", (base * Decimal("1.50")).quantize(Decimal("0.01")))),
        )
        if excedeu_auto and solicitacao_autoaprovada:
            # Proprietário sempre pode decidir qualquer etapa
            # (`usuario_pode_decidir_etapa`) — mas se o valor ultrapassar a
            # alçada da 1ª etapa (Gerente), a solicitação avança para a 2ª
            # (Financeiro) em vez de finalizar; chamar `aprovar` de novo
            # decide a etapa seguinte, mesmo padrão dos outros cenários
            # multi-etapa acima.
            motor_aprovacao_provisao.aprovar(
                solicitacao_autoaprovada, usuarios["demo_proprietario"],
                "Autoaprovação controlada — sem outro aprovador disponível no momento (justificativa exigida pela tela).",
            )
            solicitacao_autoaprovada.refresh_from_db()
            if solicitacao_autoaprovada.status == SolicitacaoAprovacao.Status.PENDENTE:
                motor_aprovacao_provisao.aprovar(
                    solicitacao_autoaprovada, usuarios["demo_proprietario"],
                    "Autoaprovação controlada — 2ª etapa também decidida diretamente pelo Proprietário.",
                )
        criadas["autoaprovada"] = provisao_autoaprovada

        return criadas

    # ------------------------------------------------------------------
    # Calendário Operacional, Plataforma e RBAC (CORE 1.0 — Épicos 2, 7 e 12)
    # ------------------------------------------------------------------

    def _criar_calendario_operacional(self, empresa):
        """Exceções de exemplo no mês corrente: um feriado, um dia bloqueado
        e um sábado especial — escolhidos deliberadamente FORA dos dias do
        roteiro de compras (2, 4, 7, 9, 12, 15, 18, 21, 24) e da janela de
        provisões futuras (hoje+1..hoje+5), para não mudar a narrativa de
        cores do calendário que a demonstração já conta."""
        hoje = date.today()
        ultimo_dia = calendar.monthrange(hoje.year, hoje.month)[1]
        dias_roteiro = {2, 4, 7, 9, 12, 15, 18, 21, 24}
        janela_provisoes = {hoje.day + n for n in range(0, 6)}

        def dia_livre(candidatos, ocupados=()):
            # Ajuste final (produto-e-demo): o feriado/bloqueio de exemplo
            # caía num domingo (ex.: 25/10/2026) — dia que já não tem limite,
            # então o exemplo não demonstrava efeito nenhum. Só dias de semana.
            for dia in candidatos:
                if (dia <= ultimo_dia and dia > hoje.day + 5 and dia not in dias_roteiro
                        and dia not in janela_provisoes and dia not in ocupados
                        and date(hoje.year, hoje.month, dia).weekday() < 5):
                    return dia
            return None

        DiaOperacional.objects.filter(empresa=empresa).delete()
        criadas = []
        # Preferidos primeiro; se todos caírem em fim de semana, qualquer dia
        # de semana livre que sobre no mês.
        restantes = list(range(hoje.day + 6, ultimo_dia + 1))

        dia_feriado = dia_livre([25, 26, 28, hoje.day + 7] + restantes)
        if dia_feriado:
            registro = DiaOperacional.objects.create(
                empresa=empresa, data=date(hoje.year, hoje.month, dia_feriado),
                tipo=DiaOperacional.Tipo.FERIADO, observacao="Feriado municipal (exemplo da demonstração).",
            )
            criadas.append(registro)

        dia_bloqueado = dia_livre([27, 29, 30, hoje.day + 9] + restantes, ocupados={dia_feriado})
        if dia_bloqueado and dia_bloqueado != dia_feriado:
            registro = DiaOperacional.objects.create(
                empresa=empresa, data=date(hoje.year, hoje.month, dia_bloqueado),
                tipo=DiaOperacional.Tipo.BLOQUEADO, observacao="Inventário da loja — compras suspensas (exemplo).",
            )
            criadas.append(registro)

        # Primeiro sábado suficientemente à frente vira "Especial" (conta
        # capacidade) — mostra o tipo que PROMOVE um dia, não só bloqueia.
        for dia in range(hoje.day + 6, ultimo_dia + 1):
            data_candidata = date(hoje.year, hoje.month, dia)
            if data_candidata.weekday() == 5 and dia not in {dia_feriado, dia_bloqueado}:
                registro = DiaOperacional.objects.create(
                    empresa=empresa, data=data_candidata,
                    tipo=DiaOperacional.Tipo.ESPECIAL, observacao="Sábado de mutirão de compras (exemplo).",
                )
                criadas.append(registro)
                break

        # Fim de mês (não coube com folga no mês corrente): os exemplos vão
        # para o MÊS SEGUINTE — visíveis pela navegação da tela do
        # Calendário Operacional e sem nenhum efeito no limite do mês
        # atual (o denominador de dias úteis é calculado por mês).
        #
        # Bomba de data (corrigida): o plano B rodava só com `if not
        # criadas` — quando o mês corrente comportava apenas o FERIADO (ex.:
        # 22/02 em ano não bissexto) ou apenas o sábado ESPECIAL (ex.:
        # 25/10/2026), nenhum dia BLOQUEADO nascia e a demonstração (e
        # `test_dia_bloqueado_para_compras_existe`) ficava sem o exemplo.
        # Agora o BLOQUEADO do mês seguinte é garantido sempre que o mês
        # corrente não tiver um (o FERIADO também, desde o ajuste final); o
        # sábado especial do mês seguinte continua só para quando nada coube
        # no mês corrente.
        ano_prox, mes_prox = (hoje.year + 1, 1) if hoje.month == 12 else (hoje.year, hoje.month + 1)
        nada_no_mes_corrente = not criadas
        # Ajuste final (produto-e-demo): o feriado de exemplo também passa a
        # ser garantido (antes, um mês corrente que só comportava o sábado
        # especial ficava sem feriado nenhum).
        if not any(registro.tipo == DiaOperacional.Tipo.FERIADO for registro in criadas):
            # 1º dia de semana a partir do dia 7 (feriado num domingo não
            # demonstra nada — o dia já não tem limite).
            data_feriado = date(ano_prox, mes_prox, 7)
            while data_feriado.weekday() >= 5:
                data_feriado += timedelta(days=1)
            criadas.append(
                DiaOperacional.objects.create(
                    empresa=empresa, data=data_feriado,
                    tipo=DiaOperacional.Tipo.FERIADO, observacao="Feriado municipal (exemplo da demonstração).",
                )
            )
        if not any(registro.tipo == DiaOperacional.Tipo.BLOQUEADO for registro in criadas):
            # 1º dia de semana a partir do dia 14 (o inventário nunca cai
            # num domingo); get_or_create por segurança contra colisão.
            data_bloqueio = date(ano_prox, mes_prox, 14)
            while data_bloqueio.weekday() >= 5:
                data_bloqueio += timedelta(days=1)
            registro, _ = DiaOperacional.objects.get_or_create(
                empresa=empresa, data=data_bloqueio,
                defaults={
                    "tipo": DiaOperacional.Tipo.BLOQUEADO,
                    "observacao": "Inventário da loja — compras suspensas (exemplo).",
                },
            )
            if registro.tipo != DiaOperacional.Tipo.BLOQUEADO:
                registro.tipo = DiaOperacional.Tipo.BLOQUEADO
                registro.observacao = "Inventário da loja — compras suspensas (exemplo)."
                registro.save(update_fields=["tipo", "observacao"])
            criadas.append(registro)
        if nada_no_mes_corrente:
            ocupados = {registro.data for registro in criadas}
            for dia in range(5, calendar.monthrange(ano_prox, mes_prox)[1] + 1):
                data_candidata = date(ano_prox, mes_prox, dia)
                if data_candidata.weekday() == 5 and data_candidata not in ocupados:
                    criadas.append(
                        DiaOperacional.objects.create(
                            empresa=empresa, data=data_candidata,
                            tipo=DiaOperacional.Tipo.ESPECIAL, observacao="Sábado de mutirão de compras (exemplo).",
                        )
                    )
                    break

        return criadas

    def _criar_configuracao_plataforma(self, empresa):
        """Configuração da Plataforma (NCC → Configurações Gerais) com
        valores de exemplo, para a tela nunca abrir vazia."""
        from datetime import time

        # Gate pré-Etapa 10 (S1-3, item 6): "autoaprovação controlada" ligada
        # de propósito na empresa de demonstração — sem isso não existe
        # NENHUM jeito de mostrar o evento de autoaprovação "destacado" na
        # Central de Auditoria (ver 8º cenário em `_criar_provisoes`).
        ConfiguracaoPlataforma.objects.update_or_create(
            empresa=empresa,
            defaults={
                "fuso_horario": "America/Cuiaba",
                "horario_abertura": time(8, 0),
                "horario_fechamento": time(18, 0),
                "parcelas_maximas": 12,
                "permitir_autoaprovacao": True,
                "justificativa_autoaprovacao": (
                    "Demonstração comercial: mostra a autoaprovação controlada ligada, com a "
                    "justificativa que a tela exige, exatamente como um cliente pequeno (sem outra "
                    "pessoa disponível para aprovar) configuraria em produção."
                ),
            },
        )

    def _criar_rbac_demo(self, empresa, usuarios):
        """RBAC de exemplo (Épico 7): um Perfil de Acesso reutilizável
        ("Consulta Financeira") atribuído à gerente de demonstração — ela
        passa a abrir a Agenda Financeira, acesso que o perfil legado
        Gerente não dá — e um limite de compra individual para o segundo
        comprador (compras acima de R$ 2.000,00 sempre pedem aprovação)."""
        perfil, _ = PerfilAcesso.objects.get_or_create(
            empresa=empresa,
            nome="Consulta Financeira",
            defaults={"descricao": "Permite consultar a Agenda Financeira e os dados financeiros (somente leitura)."},
        )
        perfil.permissoes.set(Permissao.objects.filter(codigo__in=["agenda.ver", "financeiro.ver"]))
        usuarios["demo_gerente"].perfis_acesso.add(perfil)

        UsuarioEmpresa.objects.update_or_create(
            usuario=usuarios["demo_comprador2"], empresa=empresa,
            defaults={"ativo": True, "limite_compra": Decimal("2000.00")},
        )

    def _criar_capacidade_demo(self, empresa, usuarios):
        """Motor de Capacidade (RC do Épico 01, Correção 03), pelos MESMOS
        services que a tela do Financeiro usa — cada ação fica auditada em
        LogConfiguracao (área "Capacidade dos Compradores") e notifica o
        comprador afetado:

        - Juliana (demo_comprador) ganha limite individual de R$ 3.500,00
          definido pelo Financeiro — alto o bastante para nao mudar a
          historia do mes; aparece no card "Meu limite por compra" dela.
        - Carla (demo_comprador3) e BLOQUEADA: o dashboard dela abre em
          "Bloqueado" e qualquer compra que ela tentar sai barrada na
          origem — o cenario ao vivo da tela Capacidade dos Compradores.
        - Pedro (demo_comprador2) mantem o limite de R$ 2.000,00 do RBAC.
        """
        financeiro = usuarios["demo_financeiro"]
        definir_limite_comprador(usuarios["demo_comprador"], empresa, Decimal("3500.00"), financeiro)
        bloquear_comprador(usuarios["demo_comprador3"], empresa, financeiro)

    def _criar_compra_rejeitada_e_bloqueada(
        self, filial, fornecedores, categorias, centros_custo, usuarios, limite_diario
    ):
        """Pacote de Demonstração Comercial (Etapa 02): completa os 4 status
        de `Compra.Status` na demonstração — Aprovada e Pendente já nasciam
        do roteiro de `_criar_compras`; aqui nascem Rejeitada e Bloqueada,
        os dois que faltavam.

        - **Rejeitada**: uma compra que excede o limite do dia nasce
          Pendente (a empresa usa "Solicitar Aprovação") — o Gerente rejeita
          em seguida, mesmo service (`rejeitar_compra_pendente`) que a tela
          de Aprovações usa.
        - **Bloqueada**: Carla (demo_comprador3) já está bloqueada pelo
          Financeiro nesta altura do seed (`_criar_capacidade_demo`, chamado
          logo antes) — qualquer compra lançada por ela sai barrada na
          origem automaticamente (`compras/services.py::avaliar_e_criar_compra`),
          independente de limite ou regra de excesso.

        Usa dias fora do roteiro principal de cores do calendário (que usa
        2, 4, 7, 9, 12, 15, 18, 21, 24) para não mudar a narrativa
        verde/laranja/vermelho já existente. Idempotente como o resto do
        comando: `_limpar_transacoes_anteriores` já apaga todas as Compras
        da filial no início da execução, então estas duas nascem do zero a
        cada `seed_demo`."""
        hoje = date.today()
        ultimo_dia = calendar.monthrange(hoje.year, hoje.month)[1]

        def dia_seguro(dia):
            return max(1, min(dia, ultimo_dia))

        valor_rejeitada = (
            (limite_diario * Decimal("1.60")).quantize(Decimal("0.01"))
            if limite_diario > 0 else Decimal("500.00")
        )
        avaliacao_rejeitada = avaliar_e_criar_compra(
            filial=filial,
            fornecedor=fornecedores["FarmaMax Medicamentos"],
            valor=valor_rejeitada,
            categoria=categorias["Medicamentos"],
            centro_custo=centros_custo["Compras"],
            data_compra=date(hoje.year, hoje.month, dia_seguro(hoje.day - 6)),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None,
            usuario=usuarios["demo_comprador2"],
            observacao="[DEMO] Pedido fora do orçamento do mês.",
        )
        compra_rejeitada = avaliacao_rejeitada.compra
        if compra_rejeitada.status == Compra.Status.PENDENTE:
            rejeitar_compra_pendente(compra_rejeitada, usuarios["demo_gerente"])
            compra_rejeitada.refresh_from_db()

        avaliacao_bloqueada = avaliar_e_criar_compra(
            filial=filial,
            fornecedor=fornecedores["Higicare Produtos de Higiene"],
            valor=Decimal("300.00"),
            categoria=categorias["Higiene"],
            centro_custo=centros_custo["Compras"],
            data_compra=hoje,
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None,
            usuario=usuarios["demo_comprador3"],
            observacao="[DEMO] Tentativa de compra por comprador bloqueado.",
        )

        return [compra_rejeitada, avaliacao_bloqueada.compra]

    # ------------------------------------------------------------------
    # Histórico de compras (Análise Financeira)
    # ------------------------------------------------------------------

    @staticmethod
    def _dia_de_referencia(empresa, hoje):
        """Dia dos itens "de hoje" do roteiro (pedido do dia da Loja Centro e
        a compra da Loja Bairro): o próprio hoje quando ele conta capacidade
        no Calendário Operacional; senão (sábado, domingo, feriado,
        bloqueio), o último dia anterior que conta — um item de hoje num dia
        sem limite abria a demonstração com "Capacidade de hoje excedida"."""
        dia = hoje
        for _ in range(15):
            if dia_conta_capacidade(tipo_do_dia(empresa, dia, excecoes_do_mes(empresa, dia.year, dia.month))):
                return dia
            dia -= timedelta(days=1)
        return hoje

    @staticmethod
    def _dias_com_capacidade(empresa, ano, mes):
        """Dias do mês que contam capacidade no Calendário Operacional (a
        mesma regra do Motor: seg-sex + especiais, sem feriado/bloqueio)."""
        excecoes = excecoes_do_mes(empresa, ano, mes)
        ultimo = calendar.monthrange(ano, mes)[1]
        dias = (date(ano, mes, numero) for numero in range(1, ultimo + 1))
        return [dia for dia in dias if dia_conta_capacidade(tipo_do_dia(empresa, dia, excecoes))]

    def _criar_historico_de_compras(self, filial, filial_bairro, fornecedores, categorias, centros_custo, usuarios):
        """Compras APROVADAS dos 13 meses anteriores e do mês corrente até
        ONTEM nas duas lojas, com parcelas geradas pelas mesmas funções do
        sistema (`calcular_vencimentos_da_compra`/`dividir_valor_em_parcelas`).
        Parcela com vencimento já passado nasce paga (a farmácia pagou em
        dia); a partir de hoje, pendente — a Agenda e o comprometimento dos
        próximos 30/60/90 dias ficam com a cara de uma operação real.

        Gravado direto pelo ORM (bulk_create): é passado já decidido — não
        gera notificação, auditoria nem passa pelo motor de aprovação, e o
        seed inteiro continua rodando em poucos segundos. Nunca cria compra
        para hoje nem para o futuro. Idempotente: tudo é apagado em
        `_limpar_transacoes_anteriores` junto com as demais Compras."""
        hoje = date.today()
        centro_custo = centros_custo["Compras"]
        compras = []
        for loja, compradores in (
            (filial, (usuarios["demo_comprador"], usuarios["demo_comprador2"])),
            (filial_bairro, (usuarios["demo_comprador2"],)),
        ):
            for k in range(-MESES_DE_HISTORICO, 1):
                compras += self._compras_historicas_do_mes(
                    loja, k, hoje, compradores, fornecedores, categorias, centro_custo
                )

        Compra.objects.bulk_create(compras, batch_size=500)
        parcelas = []
        for compra in compras:
            vencimentos = calcular_vencimentos_da_compra(compra)
            valores = dividir_valor_em_parcelas(compra.valor, len(vencimentos))
            for numero, (vencimento, valor) in enumerate(zip(vencimentos, valores), start=1):
                parcelas.append(ParcelaCompra(
                    compra=compra, numero=numero, data_vencimento=vencimento, valor=valor,
                    status=ParcelaCompra.Status.PAGA if vencimento < hoje else ParcelaCompra.Status.PENDENTE,
                ))
        ParcelaCompra.objects.bulk_create(parcelas, batch_size=1000)
        return {
            "compras": len(compras),
            "parcelas": len(parcelas),
            "valor": sum((compra.valor for compra in compras), Decimal("0")),
        }

    def _compras_historicas_do_mes(self, loja, k, hoje, compradores, fornecedores, categorias, centro_custo):
        """Compras (não gravadas) de UM mês de uma loja, somando com o que
        o roteiro já lançou nele a fração de `PERFIL_MENSAL`:

        - 3 pedidos grandes do mês (laboratório, perfumaria, higiene),
          acima do limite do dia e já aprovados;
        - o resto em reposição diária com as distribuidoras, distribuída
          pela vaga de cada dia útil em relação ao limite diário do mês.

        Mês corrente (k = 0): a meta é proporcional aos dias úteis já
        vividos, só dias ANTERIORES a hoje recebem compra, os pedidos
        grandes vão de preferência para dias que o roteiro já deixou
        vermelhos e a reposição nunca muda a cor que o roteiro deu a um dia
        (verde continua verde, laranja continua laranja) — a narrativa do
        calendário do mês continua a mesma."""
        ano, mes = _somar_meses(hoje.year, hoje.month, k)
        capacidade = motor_financeiro.capacidade_do_mes(loja, ano, mes)
        receita_total = capacidade.faturamento
        uteis = self._dias_com_capacidade(loja.empresa, ano, mes)
        if receita_total <= 0 or not uteis:
            return []
        alvo_mes = receita_total * PERFIL_MENSAL[k][1]
        if k == 0:
            vividos = Decimal(sum(1 for dia in uteis if dia <= hoje)) / Decimal(len(uteis))
            # Adiantado (^0,6): os pedidos grandes do mês (laboratório,
            # perfumaria) saem cedo e a reposição acompanha as vendas.
            alvo = alvo_mes * (vividos ** Decimal("0.6") if vividos > 0 else Decimal("0"))
            candidatos = [dia for dia in uteis if dia < hoje]
        else:
            alvo = alvo_mes
            candidatos = uteis
        if not candidatos:
            return []

        do_mes = Compra.objects.filter(filial=loja, data_compra__year=ano, data_compra__month=mes)
        existentes = {
            linha["data_compra"]: linha["total"]
            for linha in do_mes.filter(status__in=STATUS_CONSIDERADOS_NO_LIMITE)
            .values("data_compra").annotate(total=Sum("valor"))
        }
        aprovadas = do_mes.filter(status=Compra.Status.APROVADA).aggregate(total=Sum("valor"))["total"] or Decimal("0")
        restante = alvo - aprovadas
        if restante <= 0:
            return []
        limite = capacidade.limite_diario_base
        if limite <= 0:
            limite = alvo_mes / len(uteis)

        def nova_compra(dia, fornecedor_nome, categoria_nome, prazo, valor, observacao, usuario):
            return Compra(
                empresa=loja.empresa, filial=loja, fornecedor=fornecedores[fornecedor_nome], usuario=usuario,
                valor=valor, categoria=categorias[categoria_nome], centro_custo=centro_custo, data_compra=dia,
                prazo_pagamento=prazo, prazo_personalizado_dias=None,
                numero_parcelas=calcular_numero_parcelas(prazo), status=Compra.Status.APROVADA,
                observacao=observacao,
            )

        compras = []
        vermelhos = [dia for dia in candidatos if existentes.get(dia, Decimal("0")) > limite]
        dias_dos_pedidos = set()
        for indice, (dia_alvo, fornecedor_nome, categoria_nome, prazo, fracao, observacao) in enumerate(
            PEDIDOS_PROGRAMADOS
        ):
            if k == MES_RUIM and fornecedor_nome == "Laboratório Vitalis":
                # Pago de uma vez em 30 dias: o mês seguinte fecha o caixa no
                # vermelho (Créditos × Débitos mostra o reflexo do mês ruim).
                fracao, observacao, prazo = FRACAO_LABORATORIO_MES_RUIM, OBSERVACAO_MES_RUIM, Compra.PrazoPagamento.D30
            planejado = next((dia for dia in candidatos if dia.day >= dia_alvo), candidatos[-1])
            if k == 0:
                if vermelhos:
                    dia = vermelhos[indice % len(vermelhos)]
                elif not existentes.get(planejado):
                    dia = planejado
                else:
                    continue
            else:
                dia = planejado
            valor = min(alvo_mes * fracao, restante).quantize(CENTAVO, ROUND_HALF_UP)
            if valor < 100:
                continue
            compras.append(nova_compra(
                dia, fornecedor_nome, categoria_nome, prazo, valor, observacao,
                compradores[indice % len(compradores)],
            ))
            restante -= valor
            existentes[dia] = existentes.get(dia, Decimal("0")) + valor
            dias_dos_pedidos.add(dia)

        vagas = []
        for dia in candidatos:
            if dia in dias_dos_pedidos:
                continue
            ja_comprado = existentes.get(dia, Decimal("0"))
            uso = ja_comprado / limite
            if uso > 1:
                continue  # dia já vermelho pelo roteiro
            if uso >= Decimal("0.8"):
                teto = Decimal("0.98")  # laranja continua laranja
            elif ja_comprado > 0:
                teto = Decimal("0.78")  # verde do roteiro continua verde
            else:
                teto = Decimal("0.95")
            vaga = teto * limite - ja_comprado
            if vaga > 0:
                vagas.append((dia, vaga * PESOS_DIARIOS[(dia.day + k) % len(PESOS_DIARIOS)]))
        soma_vagas = sum((vaga for _dia, vaga in vagas), Decimal("0"))
        if restante <= 0 or soma_vagas <= 0:
            return compras
        escala = restante / soma_vagas
        if k == 0:
            escala = min(escala, Decimal("1"))  # mês corrente: nunca pinta um dia de vermelho

        rodizio = (k + MESES_DE_HISTORICO) * 3
        for dia, vaga in vagas:
            valor_dia = (vaga * escala).quantize(CENTAVO, ROUND_HALF_UP)
            if valor_dia < 150:
                continue
            fornecedor_nome, categoria_nome, prazo = ROTACAO_REPOSICAO[rodizio % len(ROTACAO_REPOSICAO)]
            compras.append(nova_compra(
                dia, fornecedor_nome, categoria_nome, prazo, valor_dia, OBSERVACAO_REPOSICAO,
                compradores[rodizio % len(compradores)],
            ))
            rodizio += 1
        return compras

    # ------------------------------------------------------------------
    # Segunda empresa (CORE 1.0 — contexto multiempresa + workflow demo)
    # ------------------------------------------------------------------

    def _criar_segunda_empresa(self, empresa_principal, usuarios):
        """Cria a "Drogaria Vida Plena Norte" no mesmo grupo e autoriza o
        proprietário de demonstração nela — demonstra o seletor de
        contexto/visão consolidada multiempresa. (O Fluxo de Aprovação de
        exemplo mora na empresa PRINCIPAL desde a Sprint de Consolidação,
        P1-4 — é lá que existem compradores para de fato exercitá-lo; esta
        2ª empresa não tem nenhum, então um fluxo aqui nunca seria
        demonstrável ao vivo.)"""
        # Gate pré-Etapa 10 (S1-1): mesmo problema de dígito verificador do
        # CNPJ da empresa principal — corrigido para um valor válido com o
        # mesmo prefixo (ver `core.validators.cnpj_e_valido`).
        segunda, _ = Empresa.objects.update_or_create(
            cnpj="98765432000279",
            defaults={
                "nome": "Drogaria Vida Plena Norte",
                "razao_social": "Vida Plena Farmácias Ltda — Filial Norte",
                "grupo": empresa_principal.grupo,
                "segmento": "Farmacêutico",
                "cidade": "Sapezal",
                "estado": "MT",
            },
        )
        # Esta Empresa não tem nenhum usuário próprio (só o Proprietário da
        # principal, autorizado via `UsuarioEmpresa` abaixo) — por isso o
        # responsável da Filial é uma pessoa de contato (texto livre), não
        # `responsavel_usuario`: aquele campo exige um Usuario cuja empresa
        # PRINCIPAL seja esta mesma Empresa (`Filial.clean()`), o que não é
        # o caso de nenhum usuário de demonstração existente.
        filial_norte, _ = Filial.objects.update_or_create(
            empresa=segunda, nome="Loja Norte",
            defaults={
                "tipo_estabelecimento": Filial.TipoEstabelecimento.MATRIZ,
                "codigo_interno": "F-NORTE-01",
                "cnpj": "22334455000186",
                "razao_social": "Vida Plena Farmácias Ltda — Filial Norte",
                "isento_inscricao_estadual": True,
                "endereco": "Rua Mato Grosso, 55", "numero": "55", "bairro": "Centro",
                "cidade": "Sapezal", "estado": "MT", "cep": "78365-000",
                # Gate C (Prompt 2, Seção 6): a auditoria encontrou esta
                # Filial ativa sem telefone próprio, considerada "completa"
                # por engano — telefone agora é exigido por
                # `Filial.cadastro_completo`.
                "telefone": "(65) 3383-1200",
                "responsavel_nome": "Antônio Ferreira", "responsavel_telefone": "(65) 99911-2233",
                "responsavel_email": "antonio.ferreira@farmaciavidaplena.com.br",
                "ativo": True,
            },
        )
        ConfiguracaoFinanceira.objects.update_or_create(
            empresa=segunda,
            defaults={"percentual_compras": Decimal("25"), "cor_principal": ""},
        )
        Receita.objects.update_or_create(
            filial=filial_norte, mes=date.today().replace(day=1), defaults={"faturamento": Decimal("140000")}
        )

        # Proprietário de demonstração autorizado na 2ª empresa (Épico 9) e
        # com limite individual de exemplo na principal (Épico 7).
        UsuarioEmpresa.objects.update_or_create(
            usuario=usuarios["demo_proprietario"], empresa=segunda, defaults={"ativo": True}
        )

        # Sprint de Consolidação (P1-4): limpeza de uma execução antiga do
        # seed — o "Fluxo Norte" chegou a ser criado aqui em versões
        # anteriores deste comando, antes de o fluxo de exemplo passar para
        # a empresa principal (única com compradores para exercitá-lo).
        FluxoAprovacao.objects.filter(empresa=segunda, nome="Fluxo Norte — Gerente e Financeiro").delete()

        return segunda

    # ------------------------------------------------------------------
    # Central de Auditoria — categorias novas do Gate D (Prompt 2, Seção 9)
    # ------------------------------------------------------------------

    def _criar_eventos_auditoria_gate_d(self, empresa, filial, filial_bairro, segunda_empresa, usuarios):
        """Prompt 2 (pré-Etapa 02), Gate D (Seção 9): as categorias novas de
        `RegistroAuditoria.Categoria` (usuários e acesso, Empresa/
        Configuração, Financeiro) só nascem de verdade quando alguém passa
        pelas TELAS reais (NCC, `empresas`, `financeiro`) — e este comando
        nunca simula requests HTTP. `limite_comprador_alterado` e
        `comprador_bloqueado` já saem naturais de `_criar_capacidade_demo`
        (chama os services reais `definir_limite_comprador`/
        `bloquear_comprador`, que registram o evento por dentro — não
        duplicados aqui). O restante é coberto chamando `registrar_evento`
        direto (o mesmo que as views fazem por dentro) ou os services reais
        (`liberar_comprador`, `marcar_parcela_paga`), com atores DIFERENTES
        — Proprietário, Gerente, Financeiro — em vez de sempre o mesmo.

        Sempre que já existe um objeto real semeado mais cedo (Empresa,
        Filial, Receita, Custo Fixo/Variável, Fluxo de Aprovação, Parcela,
        Configuração), `estado_depois` é o valor VERDADEIRO dele agora; só
        o `estado_antes` de alguns eventos é uma foto plausível do "antes"
        — a mesma liberdade narrativa que o resto deste comando já usa nas
        observações das Compras/Provisões de demonstração.

        Idempotente: os `registrar_evento` (e os services que já são
        idempotentes por si — `get_or_create`/`update_or_create` por
        dentro) podem ser chamados de novo em toda execução sem duplicar
        NENHUM objeto de negócio — só a Central de Auditoria acumula linhas
        novas, do mesmo jeito que `_criar_capacidade_demo` já faz."""
        proprietario = usuarios["demo_proprietario"]
        gerente = usuarios["demo_gerente"]
        financeiro = usuarios["demo_financeiro"]
        comprador2 = usuarios["demo_comprador2"]

        # 1) usuario_criado / usuario_status_alterado / usuario_filial_
        # principal_alterada: Beatriz é contratada pela Gerente (criada
        # INATIVA, aguardando documentação), depois ativada pelo
        # Proprietário e transferida da Loja Centro para a Loja Bairro —
        # um pequeno arco coerente, um usuário à parte dos 6 de login da
        # demonstração (username sem o prefixo "demo_" de propósito: não
        # pode contar no `SeedDemoTestCase`, que espera exatamente 6).
        beatriz, beatriz_criada = Usuario.objects.get_or_create(username="vp_atendente_beatriz")
        beatriz.first_name, beatriz.last_name = "Beatriz", "Nogueira"
        beatriz.perfil = Usuario.Perfil.COMPRADOR
        beatriz.empresa = empresa
        beatriz.filial = filial
        beatriz.email = "beatriz.nogueira@farmaciavidaplena.com.br"
        beatriz.is_active = False
        # `definir_senha_demo` deixa a senha dela INUTILIZÁVEL (ela não é um
        # dos 6 usuários de login) — com --manter-senhas isso se mantém.
        self._aplicar_senha_publica(beatriz, beatriz_criada)
        beatriz.save()
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_CRIADO,
            descricao=f"Usuário {beatriz.get_full_name()} criado ({beatriz.get_perfil_display()}).",
            empresa=empresa, usuario=gerente, filial=beatriz.filial,
            modulo="usuarios", acao="criar", tipo_objeto="Usuario", id_objeto=beatriz.pk,
            estado_depois={
                "username": beatriz.username, "perfil": beatriz.perfil,
                "filial_id": beatriz.filial_id, "is_active": beatriz.is_active,
            },
        )

        filial_antes_id = beatriz.filial_id
        beatriz.is_active = True
        beatriz.filial = filial_bairro
        beatriz.save(update_fields=["is_active", "filial"])
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_STATUS_ALTERADO,
            descricao=f"{beatriz.get_full_name()} — status de acesso alterado.",
            empresa=empresa, usuario=proprietario, filial=beatriz.filial,
            modulo="usuarios", acao="status", tipo_objeto="Usuario", id_objeto=beatriz.pk,
            estado_antes={"is_active": False}, estado_depois={"is_active": True},
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_FILIAL_PRINCIPAL_ALTERADA,
            descricao=f"{beatriz.get_full_name()} — Filial principal alterada.",
            empresa=empresa, usuario=gerente, filial=beatriz.filial,
            modulo="usuarios", acao="filial_principal", tipo_objeto="Usuario", id_objeto=beatriz.pk,
            estado_antes={"filial_id": filial_antes_id}, estado_depois={"filial_id": beatriz.filial_id},
        )
        # Gate C (Prompt 2, Seção 7): "o seed deve criar explicitamente ao
        # menos um UsuarioFilial ativo para cada Gerente, Financeiro e
        # Comprador ativo" — regra incondicional, sem exceção para atores
        # criados só para demonstrar eventos de auditoria. Beatriz é uma
        # Compradora ativa criada pelo próprio seed_demo, então também
        # precisa do vínculo explícito (mesmo padrão de `_criar_vinculos_filial`).
        UsuarioFilial.objects.update_or_create(usuario=beatriz, filial=filial_bairro, defaults={"ativo": True})

        # 2) usuario_editado: Pedro não tinha e-mail cadastrado — a Gerente
        # corrige o cadastro dele (mutação real e idempotente: mesmo
        # e-mail definido em toda execução).
        email_antes = comprador2.email
        comprador2.email = "pedro.henrique@farmaciavidaplena.com.br"
        comprador2.save(update_fields=["email"])
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_EDITADO,
            descricao=f"Dados de {comprador2.get_full_name() or comprador2.username} atualizados.",
            empresa=empresa, usuario=gerente, filial=comprador2.filial,
            modulo="usuarios", acao="editar", tipo_objeto="Usuario", id_objeto=comprador2.pk,
            estado_antes={
                "first_name": comprador2.first_name, "last_name": comprador2.last_name,
                "email": email_antes, "perfil": comprador2.perfil, "is_active": comprador2.is_active,
            },
            estado_depois={
                "first_name": comprador2.first_name, "last_name": comprador2.last_name,
                "email": comprador2.email, "perfil": comprador2.perfil, "is_active": comprador2.is_active,
            },
        )

        # 3) usuario_perfil_alterado: Fernanda foi promovida de Compradora
        # a Gerente (o perfil ATUAL dela, real, já é Gerente — só o "antes"
        # é a foto histórica da promoção).
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_PERFIL_ALTERADO,
            descricao=f"{gerente.get_full_name()} — perfil alterado.",
            empresa=empresa, usuario=proprietario, filial=gerente.filial,
            modulo="usuarios", acao="alterar_perfil", tipo_objeto="Usuario", id_objeto=gerente.pk,
            estado_antes={"perfil": Usuario.Perfil.COMPRADOR}, estado_depois={"perfil": gerente.perfil},
        )

        # 4) usuario_permissoes_alteradas: o RBAC de Fernanda ("Consulta
        # Financeira", concedido de verdade em `_criar_rbac_demo`) — aqui
        # só a linha de auditoria que a tela registraria, com o Proprietário
        # como autor da concessão.
        perfis_gerente = sorted(gerente.perfis_acesso.values_list("nome", flat=True))
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_PERMISSOES_ALTERADAS,
            descricao=f"Permissões/limites de {gerente.get_full_name()} atualizados.",
            empresa=empresa, usuario=proprietario, filial=gerente.filial,
            modulo="usuarios", acao="permissoes", tipo_objeto="Usuario", id_objeto=gerente.pk,
            estado_antes={"perfis_acesso": [], "permissoes_individuais": [], "empresas_autorizadas": [empresa.nome]},
            estado_depois={
                "perfis_acesso": perfis_gerente, "permissoes_individuais": [],
                "empresas_autorizadas": [empresa.nome], "filiais_adicionadas": [], "filiais_removidas": [],
            },
        )

        # 5) usuario_empresa_alterada: autorização do Proprietário na 2ª
        # empresa do grupo — vínculo REAL (`UsuarioEmpresa`) criado em
        # `_criar_segunda_empresa`.
        if segunda_empresa is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.USUARIO_EMPRESA_ALTERADA,
                descricao=f"{proprietario.get_full_name()} — autorização de Empresa alterada.",
                empresa=empresa, usuario=proprietario,
                modulo="usuarios", acao="empresas_autorizadas", tipo_objeto="Usuario", id_objeto=proprietario.pk,
                estado_antes={"empresas_autorizadas": [empresa.nome]},
                estado_depois={"empresas_autorizadas": [empresa.nome, segunda_empresa.nome]},
            )

        # 6) usuario_filial_alterada: Pedro ganhou vínculo explícito com a
        # Loja Bairro — vínculo REAL (`UsuarioFilial`) criado em
        # `_criar_vinculos_filial`.
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.USUARIO_FILIAL_ALTERADA,
            descricao=f"{comprador2.get_full_name()} — Vínculos de Filial alterados.",
            empresa=empresa, usuario=gerente, filial=filial_bairro,
            modulo="usuarios", acao="filiais_autorizadas", tipo_objeto="Usuario", id_objeto=comprador2.pk,
            estado_antes={"filiais_autorizadas": [filial.nome]},
            estado_depois={"filiais_autorizadas": [filial.nome, filial_bairro.nome]},
        )

        # 7) comprador_liberado: Pedro é bloqueado e liberado no mesmo dia
        # (pendência com fornecedor resolvida) — comprador DIFERENTE de
        # Carla, que continua bloqueada até o fim da demonstração (ver
        # `_criar_capacidade_demo`/`_relatorio`); services REAIS, mesmos
        # que a tela "Capacidade dos Compradores" usa.
        bloquear_comprador(comprador2, empresa, financeiro)
        liberar_comprador(comprador2, empresa, financeiro)

        # 8) empresa_criada: a 2ª empresa do grupo, criada de verdade em
        # `_criar_segunda_empresa` — aqui só a linha de auditoria.
        if segunda_empresa is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.EMPRESA_CRIADA,
                descricao=f"Empresa {segunda_empresa.nome} criada.",
                empresa=segunda_empresa, usuario=proprietario,
                modulo="empresas", acao="criar", tipo_objeto="Empresa", id_objeto=segunda_empresa.pk,
                estado_depois={
                    "nome": segunda_empresa.nome, "cnpj": segunda_empresa.cnpj,
                    "segmento": segunda_empresa.segmento,
                },
            )

        # 9) empresa_editada: ajuste cadastral na empresa principal, feito
        # pelo Proprietário (única pessoa com "empresa.gerenciar").
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.EMPRESA_EDITADA,
            descricao=f"Empresa {empresa.nome} — dados cadastrais editados.",
            empresa=empresa, usuario=proprietario,
            modulo="empresas", acao="editar", tipo_objeto="Empresa", id_objeto=empresa.pk,
            estado_antes={"telefone": "(66) 3411-0000", "email": empresa.email},
            estado_depois={"telefone": empresa.telefone, "email": empresa.email},
        )

        # 10 e 11) configuracao_plataforma_alterada / autoaprovacao_alterada:
        # mesma tela (NCC → Configurações Gerais); os valores "depois" já
        # são os reais, definidos em `_criar_configuracao_plataforma`
        # (`parcelas_maximas=12`, `permitir_autoaprovacao=True` — o padrão
        # do model é `False`, então o "antes" aqui é o valor real de
        # fábrica, não uma foto inventada).
        config_plataforma = ConfiguracaoPlataforma.objects.filter(empresa=empresa).first()
        if config_plataforma is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.CONFIGURACAO_PLATAFORMA_ALTERADA,
                descricao="Parcelas máximas permitidas alteradas.",
                empresa=empresa, usuario=proprietario,
                modulo="empresas", acao="configuracao_plataforma", tipo_objeto="ConfiguracaoPlataforma",
                id_objeto=config_plataforma.pk,
                estado_antes={"parcelas_maximas": 6},
                estado_depois={"parcelas_maximas": config_plataforma.parcelas_maximas},
            )
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.AUTOAPROVACAO_ALTERADA,
                descricao=(
                    "Configurações gerais da plataforma atualizadas. Autoaprovação controlada LIGADA — "
                    f'justificativa: "{config_plataforma.justificativa_autoaprovacao}".'
                ),
                empresa=empresa, usuario=proprietario,
                modulo="empresas", acao="autoaprovacao", tipo_objeto="ConfiguracaoPlataforma",
                id_objeto=config_plataforma.pk,
                estado_antes={"permitir_autoaprovacao": False},
                estado_depois={"permitir_autoaprovacao": config_plataforma.permitir_autoaprovacao},
                justificativa=config_plataforma.justificativa_autoaprovacao or "",
            )

        # 12) configuracao_financeira_alterada: `regra_excesso` real da
        # empresa é "aprovacao" (`_criar_financeiro_base`) — o padrão do
        # model é "alerta", então o "antes" também é o valor real de
        # fábrica.
        config_financeira = ConfiguracaoFinanceira.objects.filter(empresa=empresa).first()
        if config_financeira is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.CONFIGURACAO_FINANCEIRA_ALTERADA,
                descricao=(
                    "Configuração financeira atualizada — Forma de bloqueio ao ultrapassar o limite diário: "
                    "Permitir compra com alerta → Solicitar Aprovação."
                ),
                empresa=empresa, usuario=financeiro,
                modulo="financeiro", acao="configuracao_financeira",
                tipo_objeto="ConfiguracaoFinanceira", id_objeto=config_financeira.pk,
                estado_antes={"regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA},
                estado_depois={"regra_excesso": config_financeira.regra_excesso},
            )

        # 13) workflow_alterado: o Fluxo Padrão — Gerente e Financeiro, real,
        # criado em `_criar_fluxo_aprovacao` — aqui só a linha de auditoria
        # que `ncc_workflow_editar` registraria ao salvá-lo.
        fluxo = FluxoAprovacao.objects.filter(empresa=empresa, ativo=True).first()
        if fluxo is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.WORKFLOW_ALTERADO,
                descricao=f'Fluxo de aprovação "{fluxo.nome}" salvo.',
                empresa=empresa, usuario=proprietario,
                modulo="empresas", acao="workflow", tipo_objeto="FluxoAprovacao", id_objeto=fluxo.pk,
                estado_depois={
                    "nome": fluxo.nome, "ativo": fluxo.ativo,
                    "etapas": [
                        {
                            "ordem": etapa.ordem, "perfil_aprovador": etapa.perfil_aprovador,
                            "valor_maximo": str(etapa.valor_maximo) if etapa.valor_maximo is not None else None,
                            "prazo_dias": etapa.prazo_dias,
                        }
                        for etapa in fluxo.etapas.order_by("ordem")
                    ],
                },
            )

        # 14) dia_operacional_alterado: uma das exceções reais do mês,
        # criadas em `_criar_calendario_operacional` — sempre RECRIADAS do
        # zero a cada execução, então "antes" é sempre `None` (dia novo),
        # igual ao caminho de criação de `calendario_operacional`.
        dia_operacional = DiaOperacional.objects.filter(empresa=empresa).order_by("data").first()
        if dia_operacional is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.DIA_OPERACIONAL_ALTERADO,
                descricao=(
                    f"Dia {dia_operacional.data:%d/%m/%Y} marcado como {dia_operacional.get_tipo_display()}."
                ),
                empresa=empresa, usuario=financeiro,
                modulo="financeiro", acao="dia_operacional", tipo_objeto="DiaOperacional", id_objeto=dia_operacional.pk,
                estado_antes=None,
                estado_depois={
                    "data": dia_operacional.data.isoformat(), "tipo": dia_operacional.tipo,
                    "observacao": dia_operacional.observacao,
                },
            )

        # 15) receita_alterada: a Receita real da Loja Centro do mês atual
        # (`_criar_financeiro_base`) — "depois" é o faturamento real hoje.
        receita = Receita.objects.filter(filial=filial).order_by("-mes").first()
        if receita is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.RECEITA_ALTERADA,
                descricao=f"Receita de {filial.nome} ({receita.mes:%m/%Y}) editada.",
                empresa=empresa, usuario=financeiro, filial=filial,
                modulo="financeiro", acao="editar", tipo_objeto="Receita", id_objeto=receita.pk,
                estado_antes={"faturamento": str((receita.faturamento - Decimal("15000")).quantize(Decimal("0.01")))},
                estado_depois={"faturamento": str(receita.faturamento)},
            )

        # 16) custo_fixo_alterado: um dos Custos Fixos reais da Loja Centro.
        custo_fixo = CustoFixo.objects.filter(filial=filial).order_by("descricao").first()
        if custo_fixo is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.CUSTO_FIXO_ALTERADO,
                descricao=f'Custo fixo "{custo_fixo.descricao}" editado.',
                empresa=empresa, usuario=proprietario, filial=filial,
                modulo="financeiro", acao="editar", tipo_objeto="CustoFixo", id_objeto=custo_fixo.pk,
                estado_antes={"valor": str((custo_fixo.valor - Decimal("500")).quantize(Decimal("0.01")))},
                estado_depois={"valor": str(custo_fixo.valor)},
            )

        # 17) custo_variavel_alterado: o Custo Variável real da Loja Centro.
        custo_variavel = CustoVariavel.objects.filter(filial=filial).order_by("descricao").first()
        if custo_variavel is not None:
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.CUSTO_VARIAVEL_ALTERADO,
                descricao=f'Custo variável "{custo_variavel.descricao}" editado.',
                empresa=empresa, usuario=financeiro, filial=filial,
                modulo="financeiro", acao="editar", tipo_objeto="CustoVariavel", id_objeto=custo_variavel.pk,
                estado_antes={"valor": str((custo_variavel.valor - Decimal("1000")).quantize(Decimal("0.01")))},
                estado_depois={"valor": str(custo_variavel.valor)},
            )

        # 18) parcela_baixada: baixa manual de uma Parcela real e PENDENTE
        # (Compras recriadas do zero a cada execução em `_criar_compras`/
        # `_criar_compra_filial_bairro`) — service REAL
        # (`compras.services.marcar_parcela_paga`), mesmo caminho de
        # `financeiro.views.baixar_parcela`.
        parcela = (
            ParcelaCompra.objects.filter(
                compra__filial__in=(filial, filial_bairro), status=ParcelaCompra.Status.PENDENTE,
            )
            .order_by("data_vencimento", "numero")
            .first()
        )
        if parcela is not None:
            marcar_parcela_paga(parcela, financeiro)
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.PARCELA_BAIXADA,
                descricao=f"Parcela {parcela.numero} de {parcela.compra.fornecedor} marcada como paga.",
                empresa=parcela.compra.empresa, usuario=financeiro, filial=parcela.compra.filial,
                modulo="financeiro", acao="baixar", tipo_objeto="ParcelaCompra", id_objeto=parcela.pk,
                estado_antes={"status": "pendente"},
                estado_depois={"status": "paga", "valor": str(parcela.valor)},
            )

        # 19) parcela_estornada: Gate E (Seção 13) pede um "exemplo seguro de
        # estorno... que reverta ao estado esperado" — usa uma parcela
        # PENDENTE diferente da baixada no item 18 (nunca a mesma: a Agenda
        # precisa continuar mostrando pelo menos uma parcela paga E pelo
        # menos uma pendente), baixa e estorna na mesma execução, sempre
        # terminando de volta em PENDENTE — roteiro 100% reprodutível a
        # cada `seed_demo`, nunca deixa a demonstração num estado a meio
        # caminho. Services REAIS (`marcar_parcela_paga`/`estornar_parcela`),
        # mesmo caminho que `financeiro.views.baixar_parcela`/
        # `estornar_parcela` usam.
        parcela_estorno = (
            ParcelaCompra.objects.filter(
                compra__filial__in=(filial, filial_bairro), status=ParcelaCompra.Status.PENDENTE,
            )
            .exclude(pk=parcela.pk if parcela is not None else None)
            .order_by("data_vencimento", "numero")
            .first()
        )
        if parcela_estorno is not None:
            marcar_parcela_paga(parcela_estorno, financeiro)
            justificativa_estorno = "Baixa lançada na parcela errada por engano — corrigida no mesmo dia."
            # Proprietário (não Gerente — RBAC real de `agenda.baixar_parcela`
            # é só Proprietário/Financeiro, Seção 5) estorna a baixa que o
            # Financeiro tinha acabado de dar, diversificando o ator.
            estornar_parcela(parcela_estorno, proprietario, justificativa=justificativa_estorno)
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.PARCELA_ESTORNADA,
                descricao=f"Parcela {parcela_estorno.numero} de {parcela_estorno.compra.fornecedor} estornada — volta a pendente.",
                empresa=parcela_estorno.compra.empresa, usuario=proprietario, filial=parcela_estorno.compra.filial,
                modulo="financeiro", acao="estornar", tipo_objeto="ParcelaCompra", id_objeto=parcela_estorno.pk,
                estado_antes={"status": "paga", "valor": str(parcela_estorno.valor)},
                estado_depois={"status": "pendente"},
                justificativa=justificativa_estorno,
            )

    # ------------------------------------------------------------------
    # Relatório final no console
    # ------------------------------------------------------------------

    def _relatorio(self, empresa, filial, categorias, fornecedores, compras, provisoes, limite_diario,
                   segunda_empresa=None, excecoes_calendario=None, filial_bairro=None, receitas_extras=None,
                   historico=None):
        self.stdout.write(self.style.SUCCESS("Experiência de demonstração do NEXBUY (CORE 1.0) criada com sucesso!"))
        self.stdout.write("")
        self.stdout.write(f"Empresa: {empresa.nome} ({formatar_cnpj(empresa.cnpj)}) — Filial: {filial.nome}")
        if filial_bairro is not None:
            self.stdout.write(
                f"2ª filial da MESMA empresa (Sprint de Correções Críticas): {filial_bairro.nome} — "
                "demo_financeiro e demo_comprador2 (Pedro) autorizados nas duas via UsuarioFilial"
            )
        if segunda_empresa is not None:
            self.stdout.write(
                f"2ª empresa (contexto/consolidado): {segunda_empresa.nome} ({formatar_cnpj(segunda_empresa.cnpj)})"
            )
        self.stdout.write("Fluxo de Aprovação de exemplo (Gerente até R$ 2.000, depois Financeiro): empresa principal")
        self.stdout.write(f"Categorias: {len(categorias)} · Fornecedores: {len(fornecedores)}")
        self.stdout.write(f"Compras (pedidos) de demonstração: {len(compras)} — com parcelamentos 30/60, 30/60/90 e personalizado 4x")
        self.stdout.write("Status de Compra demonstrados: Aprovada, Pendente, Rejeitada e Bloqueada (Carla/demo_comprador3)")
        self.stdout.write(f"Provisões de demonstração: {len([p for p in provisoes.values() if p is not None])} (normal, aprovada, pendente, reprovada, ajustes, efetivada, autoaprovada)")
        self.stdout.write("Provisão \"efetivada\" já virou Compra real (Compra.provisao_origem) — timeline mostra o badge \"Efetivada\".")
        if excecoes_calendario:
            resumo_dias = ", ".join(
                f"{registro.data:%d/%m} ({registro.get_tipo_display()})" for registro in excecoes_calendario
            )
            self.stdout.write(f"Calendário Operacional: {resumo_dias}")
        self.stdout.write("RBAC de exemplo: perfil \"Consulta Financeira\" para demo_gerente (abre a Agenda Financeira)")
        self.stdout.write("Motor de Capacidade (RC): Juliana com limite R$ 3.500,00 (definido pelo Financeiro, auditado),")
        self.stdout.write("  Pedro com limite R$ 2.000,00 e Carla BLOQUEADA (compra barrada na origem)")
        self.stdout.write("Telas novas da RC: /financeiro/capacidade-compradores/ e /financeiro/calendario/ (login financeiro)")
        if receitas_extras:
            total_extras = sum((receita.valor for receita in receitas_extras), Decimal("0"))
            self.stdout.write(
                f"Receitas extras do mês ({filial.nome}): {len(receitas_extras)} lançamentos — "
                f"{formatar_moeda(total_extras, incluir_prefixo=True)} (somam à receita mensal no Motor)"
            )
        self.stdout.write(f"Limite diário calculado hoje: {formatar_moeda(limite_diario, incluir_prefixo=True)}")
        if historico:
            self.stdout.write(
                f"Histórico para a Análise Financeira: 12 meses (+1 de aquecimento) nas duas lojas — "
                f"{historico['compras']} compras aprovadas e {historico['parcelas']} parcelas "
                f"({formatar_moeda(historico['valor'], incluir_prefixo=True)}); receita, receitas extras, "
                f"custos fixos e variáveis de todo mês."
            )
            self.stdout.write(
                "  Análise Financeira (Proprietário, Gerente e Financeiro): /financeiro/analise/ — "
                "DRE, Créditos × Débitos e Saúde Financeira."
            )
        self.stdout.write("")
        if self.manter_senhas:
            self.stdout.write(
                "Usuários de demonstração (--manter-senhas: as senhas foram MANTIDAS — "
                "quem já existia continua com a senha atual):"
            )
        else:
            self.stdout.write("Usuários de demonstração (senha para todos: nexbuy123):")
        self.stdout.write("  - demo_proprietario (Proprietário) — Roberto Almeida")
        self.stdout.write("  - demo_gerente (Gerente) — Fernanda Costa")
        self.stdout.write("  - demo_financeiro (Financeiro) — Marcos Vinícius")
        self.stdout.write("  - demo_comprador (Comprador) — Juliana Ramos")
        self.stdout.write("  - demo_comprador2 (Comprador) — Pedro Henrique")
        self.stdout.write("  - demo_comprador3 (Comprador, BLOQUEADA) — Carla Menezes")
        if self.manter_senhas and self.usuarios_com_senha_publica_nesta_execucao:
            self.stdout.write(
                "  Criados agora, com a senha pública de demonstração: "
                + ", ".join(sorted(self.usuarios_com_senha_publica_nesta_execucao))
            )
        self.stdout.write("")
        self.stdout.write("Ver DEMO_MODE.md para como ativar o indicador visual de Modo Demonstração.")
        self._avisar_senha_publica_em_servidor()

    def _avisar_senha_publica_em_servidor(self):
        """Com DEBUG=False (servidor — o seed só roda lá com
        ALLOW_SEED_IN_PRODUCTION=True no próprio comando), termina com um
        aviso destacado se algum usuário da demonstração ainda entra com a
        senha pública. Mesmo critério de "servidor de verdade" do guard
        `abortar_seed_em_producao` (DEBUG e TESTING)."""
        from django.conf import settings

        from core.senha_demo import usa_senha_publica, usuarios_da_empresa_demo

        if settings.DEBUG or getattr(settings, "TESTING", False):
            return
        # Quem recebeu a senha pública nesta execução já é conhecido — só
        # os demais precisam da verificação (que custa um hash cada).
        ja_conhecidos = set(self.usuarios_com_senha_publica_nesta_execucao)
        com_senha_publica = sorted(
            usuario.username
            for usuario in usuarios_da_empresa_demo().filter(is_active=True)
            if usuario.username in ja_conhecidos or usa_senha_publica(usuario)
        )
        if not com_senha_publica:
            return
        faixa = "=" * 76
        self.stdout.write("")
        self.stdout.write(self.style.ERROR(faixa))
        self.stdout.write(self.style.ERROR(
            "ATENÇÃO: servidor (DEBUG=False) com usuário de demonstração usando a SENHA PÚBLICA:"
        ))
        self.stdout.write(self.style.ERROR("  " + ", ".join(com_senha_publica)))
        self.stdout.write(self.style.ERROR("Qualquer pessoa com o endereço do site entraria com eles. Troque AGORA:"))
        self.stdout.write(self.style.ERROR("  python manage.py definir_senha_demo"))
        self.stdout.write(self.style.ERROR(faixa))
