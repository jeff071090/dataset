"""Integrações futuras desativadas — regra da ida para a nuvem.

Decisão de escopo: o NEXBUY é 100% web e NÃO se integra a ERP
(Inovafarma), a conexões bancárias nem a recomendação automatizada;
receitas, custos, compras e provisões são lançados manualmente. A ÚNICA
integração prevista é o DDA, ainda não conectada.

Prova, de forma automatizada e reproduzível, que:
- o DDA continua sendo apenas um contrato abstrato
  (`finance_engine/interfaces.py`) sem nenhuma implementação concreta em
  lugar nenhum do código dos apps próprios do NEXBUY;
- os antigos contratos de ERP/Inovafarma, SQL Server, conexão bancária e
  recomendação automatizada não existem mais;
- a aplicação sobe normalmente sem nenhuma chave/segredo configurado,
  nenhuma dependência de SDK externo foi adicionada e nenhuma chamada de
  rede é feita;
- a tela de Integrações mostra SOMENTE o DDA, com rótulo honesto "Não
  conectado — integração prevista", e nunca mais cita
  Inovafarma/ERP/Open Finance/API Bancária/Inteligência Artificial."""
import inspect
import os
import re

from django.conf import settings
from django.test import Client, TestCase, override_settings

from core.tests_primeiro_acesso import PAYLOAD_VALIDO, TOKEN, realizar_primeiro_acesso
from finance_engine import interfaces
from usuarios.models import Usuario

APPS_PROPRIOS_DO_NEXBUY = (
    "core", "usuarios", "empresas", "filiais", "cadastros", "finance_engine",
    "financeiro", "compras", "dashboard", "gestao_compras", "notificacoes", "auditoria",
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONTRATOS_ABSTRATOS = (
    interfaces.IntegracaoDDABase,
)

# Contratos removidos pela decisão de escopo — não podem voltar.
CONTRATOS_REMOVIDOS = (
    "IntegracaoInovafarmaBase", "IntegracaoBancariaBase", "RecomendacaoIABase",
    "ERPConnectorBase", "SQLServerConectorBase", "SQLServerConnectorBase",
    "SQLServerLeituraBase", "SQLServerMapeamentoBase", "SQLServerImportacaoBase",
)

# Termos que a tela de Integrações NUNCA pode exibir (a integração com ERP
# não vai existir; conexão bancária e recomendação automatizada saíram do
# escopo). Busca com fronteira de palavra para "ERP"/"IA" não pegar
# pedaços de outras palavras.
TERMOS_PROIBIDOS_NA_TELA = (
    r"Inovafarma", r"\bERP\b", r"Open Finance", r"API Bancária",
    r"Inteligência Artificial", r"\bIA\b", r"SQL Server", r"estoque",
)

# Padrões que indicariam uma chamada de rede real para um provedor externo
# — nenhum deve aparecer no código próprio do NEXBUY (fora deste arquivo de
# teste e de `interfaces.py`, que só documenta o contrato).
PADROES_PROIBIDOS = (
    r"\bopenai\.", r"\banthropic\.", r"\bgoogle\.generativeai\b",
    r"\bpyodbc\b", r"\bpymssql\b",
    r"\brequests\.(get|post)\(\s*[\"']https?://(?!localhost|127\.0\.0\.1)",
)


def _arquivos_py_dos_apps_proprios():
    for app in APPS_PROPRIOS_DO_NEXBUY:
        app_dir = os.path.join(BASE_DIR, app)
        for raiz, _dirs, arquivos in os.walk(app_dir):
            if "migrations" in raiz.split(os.sep):
                continue
            for nome in arquivos:
                if nome.endswith(".py"):
                    yield os.path.join(raiz, nome)


def _texto_visivel(html):
    """HTML sem <script>/<style> e sem tags — só o texto que a pessoa lê."""
    sem_blocos = re.sub(r"<(script|style)\b.*?</\1>", " ", html, flags=re.S | re.I)
    return re.sub(r"<[^>]+>", " ", sem_blocos)


class NenhumaImplementacaoConcretaTestCase(TestCase):
    """O contrato do DDA continua só contrato — nenhuma subclasse concreta
    foi criada em lugar nenhum do código dos apps próprios (o registro de
    apps do Django já importou todo o código de views/models/services na
    hora de rodar os testes, então uma subclasse concreta escondida em
    qualquer módulo importável apareceria aqui)."""

    def test_todos_os_contratos_continuam_abstratos(self):
        for contrato in CONTRATOS_ABSTRATOS:
            with self.subTest(contrato=contrato.__name__):
                self.assertTrue(
                    inspect.isabstract(contrato) or bool(getattr(contrato, "__abstractmethods__", None)),
                    f"{contrato.__name__} deixou de ser um contrato abstrato puro.",
                )
                self.assertEqual(
                    contrato.__subclasses__(), [],
                    f"{contrato.__name__} já tem subclasse concreta: {contrato.__subclasses__()}",
                )

    def test_contratos_de_erp_banco_e_ia_foram_removidos(self):
        for nome in CONTRATOS_REMOVIDOS:
            with self.subTest(contrato=nome):
                self.assertFalse(hasattr(interfaces, nome), f"{nome} voltou a existir em interfaces.py")

    def test_nenhum_sdk_de_ia_erp_ou_banco_nas_dependencias(self):
        caminho_requirements = os.path.join(BASE_DIR, "requirements.txt")
        with open(caminho_requirements, "r", encoding="utf-8") as arquivo:
            conteudo = arquivo.read().lower()
        for pacote_proibido in ("openai", "anthropic", "google-generativeai", "pyodbc", "pymssql"):
            self.assertNotIn(pacote_proibido, conteudo, f"requirements.txt já depende de {pacote_proibido}")

    def test_nenhum_padrao_de_chamada_externa_no_codigo_proprio(self):
        arquivos_com_problema = []
        for caminho in _arquivos_py_dos_apps_proprios():
            if os.path.abspath(caminho) in (
                os.path.abspath(__file__),
                os.path.abspath(interfaces.__file__),
            ):
                continue
            with open(caminho, "r", encoding="utf-8") as arquivo:
                conteudo = arquivo.read()
            for padrao in PADROES_PROIBIDOS:
                if re.search(padrao, conteudo):
                    arquivos_com_problema.append((caminho, padrao))
        self.assertEqual(arquivos_com_problema, [], f"Padrão de chamada externa encontrado: {arquivos_com_problema}")


@override_settings(
    FEATURE_INOVAFARMA=False, FEATURE_DDA=False, FEATURE_IA=False,
    INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"],
)
class AplicacaoSobeSemChavesTestCase(TestCase):
    """A aplicação inteira — do Primeiro Acesso ao dashboard — sobe e
    funciona normalmente sem NENHUMA variável de ambiente de integração
    definida (as flags de settings já nascem `False` por padrão em
    `.env.example`; aqui confirmamos que `False` realmente não tenta
    nenhuma integração, em vez de travar por chave ausente)."""

    def test_flags_de_integracao_desligadas_por_padrao_nas_settings(self):
        # FEATURE_INOVAFARMA/FEATURE_IA não são mais usadas por nenhuma tela
        # (podem até sair de settings.py); se existirem, continuam False.
        self.assertFalse(getattr(settings, "FEATURE_INOVAFARMA", False))
        self.assertFalse(settings.FEATURE_DDA)
        self.assertFalse(getattr(settings, "FEATURE_IA", False))

    def test_primeiro_acesso_e_dashboard_funcionam_sem_nenhuma_chave_externa(self):
        cliente = Client()
        resposta = realizar_primeiro_acesso(cliente)
        self.assertEqual(resposta.status_code, 302)

        usuario = Usuario.objects.get(username="ana.proprietaria")
        cliente.force_login(usuario)
        resposta_dashboard = cliente.get("/")
        self.assertEqual(resposta_dashboard.status_code, 200)

    def _tela_de_integracoes(self):
        cliente = Client()
        realizar_primeiro_acesso(cliente)
        usuario = Usuario.objects.get(username="ana.proprietaria")
        cliente.force_login(usuario)
        resposta = cliente.get("/ncc/integracoes/")
        self.assertEqual(resposta.status_code, 200)
        return resposta

    def test_tela_de_integracoes_mostra_somente_o_dda_com_rotulo_honesto(self):
        resposta = self._tela_de_integracoes()

        integracoes = resposta.context["integracoes"]
        self.assertEqual([item["nome"] for item in integracoes], ["DDA"], "a tela só pode listar o DDA")
        dda = integracoes[0]
        self.assertFalse(dda["habilitada"], "DDA aparece habilitado sem nenhuma flag ligada.")
        self.assertEqual(dda["rotulo_status"], "Não conectado — integração prevista")

        conteudo = resposta.content.decode("utf-8")
        self.assertIn("Não conectado — integração prevista", conteudo)
        self.assertIn("Débito Direto Autorizado", conteudo)
        # O que o DDA fará (e o que nunca fará).
        self.assertIn("boletos/títulos apresentados ao CNPJ", conteudo)
        self.assertIn("Contas a Pagar", conteudo)
        self.assertIn("Nunca paga nada sozinho.", conteudo)
        # Texto de apoio: tudo é lançamento manual hoje.
        self.assertIn("lançamentos são <strong>manuais</strong>", conteudo)
        self.assertNotIn("Sincronizado", conteudo)
        self.assertNotIn("Conectado</", conteudo)
        self.assertNotIn("Última atualização", conteudo)

    def test_tela_de_integracoes_nao_cita_erp_banco_nem_ia(self):
        resposta = self._tela_de_integracoes()
        texto = _texto_visivel(resposta.content.decode("utf-8"))
        for termo in TERMOS_PROIBIDOS_NA_TELA:
            with self.subTest(termo=termo):
                self.assertIsNone(
                    re.search(termo, texto),
                    f"'{termo}' apareceu na tela de integrações — só o DDA pode ser citado",
                )

    def test_home_do_ncc_descreve_integracoes_so_com_o_dda(self):
        cliente = Client()
        realizar_primeiro_acesso(cliente)
        cliente.force_login(Usuario.objects.get(username="ana.proprietaria"))
        resposta = cliente.get("/ncc/")
        self.assertEqual(resposta.status_code, 200)
        cartoes = [
            modulo for categoria in resposta.context["categorias"] for modulo in categoria["modulos"]
            if modulo["url"] == "/ncc/integracoes/"
        ]
        self.assertEqual(len(cartoes), 1)
        descricao = cartoes[0]["descricao"]
        self.assertIn("DDA", descricao)
        for termo in TERMOS_PROIBIDOS_NA_TELA:
            with self.subTest(termo=termo):
                self.assertIsNone(re.search(termo, descricao), f"'{termo}' na descrição do card Integrações")

    def test_tela_de_integracoes_nao_tem_formulario_de_credencial(self):
        resposta = self._tela_de_integracoes()
        conteudo = resposta.content.decode("utf-8")
        for termo_proibido in ("senha", "password", "api_key", "api key", "token de acesso", "client_secret"):
            self.assertNotIn(termo_proibido, conteudo.lower(), f"'{termo_proibido}' apareceu na tela de integrações")


@override_settings(
    FEATURE_INOVAFARMA=True, FEATURE_DDA=True, FEATURE_IA=True,
    INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"],
)
class FlagsLigadasAindaSemImplementacaoTestCase(TestCase):
    """Mesmo que um operador ligue as feature flags manualmente (uso
    interno/QA), isso só muda o rótulo de UI do DDA (`habilitada=True`) —
    nunca ativa uma automação real, porque a automação real não existe. As
    flags antigas de ERP/IA ligadas não fazem aparecer nada na tela."""

    def test_flag_ligada_so_muda_rotulo_nunca_ativa_automacao_real(self):
        cliente = Client()
        realizar_primeiro_acesso(cliente)
        usuario = Usuario.objects.get(username="ana.proprietaria")
        cliente.force_login(usuario)

        resposta = cliente.get("/ncc/integracoes/")
        self.assertEqual(resposta.status_code, 200)
        integracoes = {item["nome"]: item for item in resposta.context["integracoes"]}
        self.assertEqual(list(integracoes), ["DDA"], "flags de ERP/IA ligadas não podem criar cartões novos")
        self.assertTrue(integracoes["DDA"]["habilitada"])

        texto = _texto_visivel(resposta.content.decode("utf-8"))
        for termo in TERMOS_PROIBIDOS_NA_TELA:
            with self.subTest(termo=termo):
                self.assertIsNone(re.search(termo, texto), f"'{termo}' apareceu com as flags ligadas")

        for contrato in CONTRATOS_ABSTRATOS:
            self.assertEqual(contrato.__subclasses__(), [], f"{contrato.__name__} ganhou implementação concreta")
