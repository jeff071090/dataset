"""Limite de tentativas de login (Sprint de Melhorias 1 — segurança).

Antes, o login aceitava tentativas sem fim: no PythonAnywhere não havia
nenhum freio, e na VPS só o nginx limitava a página /accounts/login/ (o
/admin e o primeiro acesso ficavam de fora). Uma senha fraca de comprador
era questão de tempo.

Sem dependência nova e sem migração: a Central de Auditoria JÁ grava toda
tentativa que falha (`auditoria/signals.py`, categoria LOGIN_FALHO, com o
usuário tentado e o IP). Aqui só contamos essas linhas numa janela de
tempo — funciona igual com 1 ou vários processos do servidor, porque a
contagem vem do banco.

Regra (ajustável no .env):
- 5 falhas para o MESMO usuário em 15 minutos → esse usuário fica 15
  minutos sem conseguir entrar;
- 20 falhas do MESMO IP em 15 minutos → esse IP fica 15 minutos sem
  conseguir entrar (freia quem testa vários usuários). Só vale para IP
  PÚBLICO: atrás de um balanceador (ex.: PythonAnywhere) o IP visto pode ser
  o do próprio balanceador, igual para todos — contar por ele pausaria o
  site inteiro. Nesses casos fica só a regra por usuário.

Enquanto bloqueado, nem chega a testar a senha — então as tentativas
seguintes não renovam o bloqueio: 15 minutos depois da última falha real,
o acesso volta sozinho. Nada muda para quem acerta a senha.
"""
import ipaddress
from datetime import timedelta

from django import forms
from django.conf import settings
from django.contrib.admin.forms import AdminAuthenticationForm
from django.contrib.auth.forms import AuthenticationForm
from django.utils import timezone

MENSAGEM_BLOQUEIO = (
    "Muitas tentativas de login sem sucesso. Por segurança, o acesso foi pausado por "
    "{minutos} minutos. Se esqueceu a senha, fale com o administrador da sua empresa."
)


def _descricao_falha(username):
    # Mesmo texto gravado por auditoria.signals._registrar_login_falho.
    return f"Tentativa de login falhou para o usuário '{username}'."


def _ip_publico(ip):
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


def login_bloqueado(username, ip):
    """True se o usuário ou o IP passou do limite de falhas na janela."""
    from auditoria.models import RegistroAuditoria

    janela = timezone.now() - timedelta(minutes=settings.LOGIN_JANELA_MINUTOS)
    falhas = RegistroAuditoria.objects.filter(
        categoria=RegistroAuditoria.Categoria.LOGIN_FALHO, criado_em__gte=janela
    )
    if username and falhas.filter(descricao=_descricao_falha(username)).count() >= settings.LOGIN_MAX_FALHAS_USUARIO:
        return True
    if ip and _ip_publico(ip) and falhas.filter(ip=ip).count() >= settings.LOGIN_MAX_FALHAS_IP:
        return True
    return False


class _LimiteDeTentativasMixin:
    # A tela de login mostra uma mensagem fixa ("Usuário ou senha inválidos")
    # para qualquer erro; com o bloqueio ela mostra o motivo verdadeiro.
    login_bloqueado = False

    def clean(self):
        from auditoria.services import ip_do_request

        username = (self.data.get("username") or "").strip()
        if login_bloqueado(username, ip_do_request(self.request)):
            self.login_bloqueado = True
            raise forms.ValidationError(
                MENSAGEM_BLOQUEIO.format(minutos=settings.LOGIN_JANELA_MINUTOS), code="login_bloqueado"
            )
        return super().clean()


class LoginComLimiteForm(_LimiteDeTentativasMixin, AuthenticationForm):
    """Formulário da tela de login do NEXBUY."""


class AdminLoginComLimiteForm(_LimiteDeTentativasMixin, AdminAuthenticationForm):
    """Formulário do login do /admin (suporte técnico)."""
