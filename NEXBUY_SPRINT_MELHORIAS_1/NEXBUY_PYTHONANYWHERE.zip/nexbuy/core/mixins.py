"""Mixins genéricos de CRUD escopado por empresa, reaproveitados pelos
cadastros administrativos (fornecedores, categorias, centros de custo).

CORE 1.0 (Épico 9): o escopo passou a ser a EMPRESA ATIVA do contexto
(`core.contexto.empresa_ativa`) — que, por padrão, é a mesma empresa
principal do usuário de sempre; só muda quando o usuário troca de
contexto no seletor do topo."""
from core.contexto import empresa_ativa


class EmpresaScopedListMixin:
    """Lista os registros da empresa ativa do contexto, com busca por nome e paginação."""

    paginate_by = 10
    search_param = "q"
    search_fields = ("nome",)

    def get_queryset(self):
        queryset = self.model.objects.filter(empresa=empresa_ativa(self.request))
        termo = self.request.GET.get(self.search_param, "").strip()
        if termo:
            from django.db.models import Q

            filtro = Q()
            for campo in self.search_fields:
                filtro |= Q(**{f"{campo}__icontains": termo})
            queryset = queryset.filter(filtro)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["termo_busca"] = self.request.GET.get(self.search_param, "")
        return context


class EmpresaScopedFormMixin:
    """Injeta o usuário logado e a empresa ativa no form, para que ele
    escopeie/valide pela empresa certa do contexto."""

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        kwargs["empresa"] = empresa_ativa(self.request)
        return kwargs
