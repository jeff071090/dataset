"""Views transversais do NEXBUY, sem dono em um app de domínio específico."""
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.db.models import Q
from django.http import Http404
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from core.contexto import definir_empresa_ativa, empresa_ativa
from core.permissions import (
    PERFIS_ANALISE_FINANCEIRA,
    PERFIS_GESTORES_FINANCEIROS,
    permissao_required,
    usuario_tem_permissao,
)

# Demo Comercial Showcase (Seção 7): os perfis que o apresentador troca
# durante a reunião. Whitelist fixa — o atalho e o prefill do login NUNCA
# aceitam um username fora desta lista, e a lista só é usada com
# `settings.DEMO_MODE` ligado.
#
# Demo na internet (PythonAnywhere): são os 6 usuários de login do
# `seed_demo` — a cliente testa cada um, um a um, inclusive o Pedro (limite
# individual de R$ 2.000,00 por compra, definido em `_criar_rbac_demo`) e a
# Carla (bloqueada pelo Financeiro em `_criar_capacidade_demo`). É também a
# lista que `manage.py definir_senha_demo` usa para trocar as senhas.
USUARIOS_DEMO_TROCA = (
    ("demo_proprietario", "Proprietário — Roberto Almeida"),
    ("demo_gerente", "Gerente — Fernanda Costa"),
    ("demo_financeiro", "Financeiro — Marcos Vinícius"),
    ("demo_comprador", "Comprador — Juliana Ramos"),
    ("demo_comprador2", "Comprador — Pedro Henrique (limite R$ 2.000)"),
    ("demo_comprador3", "Comprador — Carla Menezes (bloqueada)"),
)


def _somente_em_modo_demo(view):
    """Fora do modo demo a rota não existe: 404 ANTES de qualquer outro
    decorator (rodada final — com o @require_POST por fora, um GET dava
    405 e revelava a rota)."""
    from functools import wraps

    @wraps(view)
    def _view(request, *args, **kwargs):
        if not settings.DEMO_MODE:
            raise Http404
        return view(request, *args, **kwargs)

    return _view


@_somente_em_modo_demo
@require_POST
@login_required
def demo_trocar_perfil(request):
    """Troca de perfil da demonstração comercial (Showcase, Seção 7).

    NÃO é um bypass de autenticação: apenas encerra a sessão atual
    (`logout` real, mesma limpeza de sessão do botão Sair) e redireciona
    para a tela de login com o usuário fictício escolhido pré-preenchido —
    a senha continua sendo exigida pelo `LoginView` normal do Django.

    Fora do modo demo a rota simplesmente não existe (404): nada aparece
    na interface (o template só renderiza o atalho com `demo_mode`) e nem
    um POST direto funciona."""
    if not settings.DEMO_MODE:
        raise Http404
    usuario = request.POST.get("usuario", "")
    if usuario not in {u for u, _ in USUARIOS_DEMO_TROCA}:
        raise Http404
    logout(request)
    return redirect(f"{reverse('login')}?usuario={usuario}")


@login_required
def trocar_empresa(request):
    """Troca o contexto ativo (Épico 9 — CORE 1.0), sem novo login. Só POST;
    a validação de autorização vive em `core.contexto.definir_empresa_ativa`.
    Dashboard, Compras, Financeiro, Calendário e indicadores passam a
    refletir a nova empresa automaticamente (todas as telas resolvem a
    empresa via contexto)."""
    if request.method == "POST":
        empresa = request.user.empresas_disponiveis().filter(pk=request.POST.get("empresa_id")).first()
        if empresa is not None and definir_empresa_ativa(request, empresa):
            messages.success(request, f"Agora você está trabalhando em: {empresa.nome}.")
        else:
            messages.error(request, "Você não tem acesso a esta empresa.")
    # Sprint de Melhorias 1 (segurança): só volta para página DO PRÓPRIO
    # NEXBUY — um "proxima" apontando para outro site vira a tela inicial.
    proxima = request.POST.get("proxima") or ""
    if not url_has_allowed_host_and_scheme(proxima, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        proxima = "dashboard:home"
    return redirect(proxima)


@login_required
def bem_vindo(request):
    """Tela de apresentação do NEXBUY (Demo Experience 1.0, item 14) —
    explica objetivo, benefícios, módulos e perfis. Não lê nem grava
    nenhum dado de negócio; é puramente informativa."""
    return render(request, "core/bem_vindo.html")


@login_required
def meu_perfil(request):
    """Meu Perfil (Épico 2A — Etapa 01): a página responde "quem sou eu
    aqui?" — dados de apresentação, foto e troca da própria senha. Nada de
    permissão/empresa/perfil de acesso: isso é gestão, vive no Centro de
    Configurações."""
    from core.forms import PerfilProprioForm

    form_dados = PerfilProprioForm(instance=request.user, prefix="dados")
    form_senha = PasswordChangeForm(user=request.user, prefix="senha")

    if request.method == "POST":
        if "salvar_dados" in request.POST:
            form_dados = PerfilProprioForm(
                request.POST, request.FILES, instance=request.user, prefix="dados"
            )
            if form_dados.is_valid():
                form_dados.save()
                messages.success(request, "Seus dados foram atualizados.")
                return redirect("meu_perfil")
        elif "alterar_senha" in request.POST:
            form_senha = PasswordChangeForm(user=request.user, data=request.POST, prefix="senha")
            if form_senha.is_valid():
                form_senha.save()
                update_session_auth_hash(request, request.user)
                messages.success(request, "Senha alterada com sucesso.")
                return redirect("meu_perfil")

    for campo in form_senha.fields.values():
        campo.widget.attrs.setdefault("class", "form-control")

    return render(
        request,
        "core/meu_perfil.html",
        {"form_dados": form_dados, "form_senha": form_senha},
    )


# ---------------------------------------------------------------------------
# Busca Global (Épico 2A — Etapa 08)
# ---------------------------------------------------------------------------

# Catálogo de telas/ações pesquisáveis: (título, url estática, ícone,
# palavras-chave, teste de acesso). O teste recebe o usuário e decide se o
# resultado pode aparecer — os MESMOS critérios dos menus/views.
def _telas_pesquisaveis(user):
    """Cada atalho usa EXATAMENTE o gate da view de destino (nunca um link
    que dê 403):

    - view com `@permissao_required("x.y")` → `usuario_tem_permissao(user,
      "x.y")` (o RBAC aditivo abre o atalho junto com a view);
    - view com `@perfil_required(...)`/`PerfilRequiredMixin` (ou checagem
      de perfil dentro da view) → `perfil in (...)` com os MESMOS perfis —
      o RBAC não abre essas views, então o atalho também não pode abrir
      (ex.: um Gerente com `financeiro.ver` concedido NÃO acessa Receitas,
      que é por perfil)."""
    perfil = user.perfil

    def pode(codigo):
        return usuario_tem_permissao(user, codigo)

    # Views por PERFIL (financeiro/views PERFIS_VISUALIZACAO, compras/views
    # PERFIS_GESTAO_FORNECEDORES, cadastros/views PERFIS_GESTAO_CADASTROS —
    # todos = PERFIS_GESTORES_FINANCEIROS).
    e_gestor_financeiro = perfil in PERFIS_GESTORES_FINANCEIROS
    e_gestor = perfil in ("gerente", "proprietario", "financeiro")  # dashboard: aprovações/indicadores
    e_analise = perfil in PERFIS_ANALISE_FINANCEIRA
    # Rodada final: os títulos são os MESMOS do menu (core/navegacao.py) e o
    # catálogo cobre todas as telas do menu — antes faltavam Capacidade
    # Financeira, Checklist de Implantação, Integrações, Perfis de Acesso,
    # Workflow de Aprovações, Créditos × Débitos e Saúde Financeira. As
    # palavras-chave podem ter acento: a comparação normaliza os dois lados.
    telas = [
        ("Dashboard", "/", "bi-speedometer2", "início home painel", True),
        ("Nova Compra", "/compras/nova/", "bi-plus-circle-fill", "lançar comprar pedido registrar compra", pode("compras.lancar")),
        ("Histórico de Compras", "/compras/lista/", "bi-list-check", "histórico pedidos minhas compras todas", True),
        ("Calendário de Compras", "/gestao-compras/", "bi-calendar3", "provisão provisões dias calendário inteligente", pode("calendario.ver")),
        ("Nova Provisão", "/gestao-compras/nova/", "bi-journal-plus", "provisionar planejar compra futura", pode("provisoes.criar")),
        ("Aprovações", "/aprovacoes/", "bi-check2-square", "aprovar rejeitar pendentes efetivar efetivação provisões aprovadas", e_gestor),
        ("Simulador de Compra", "/compras/simulacao/", "bi-calculator-fill", "simular simulação e se", perfil in ("proprietario", "financeiro", "comprador")),
        ("Agenda Financeira", "/financeiro/agenda/", "bi-calendar2-week", "pagamentos vencimentos parcelas contas a pagar", pode("agenda.ver")),
        ("Calendário Financeiro", "/financeiro/calendario/", "bi-calendar3", "mensal semanal diário compromissos calendário inteligente", pode("financeiro.ver")),
        ("Planejamento Financeiro", "/financeiro/planejamento/", "bi-compass", "hub módulo financeiro", pode("financeiro.ver")),
        ("Capacidade Financeira", "/financeiro/configuracao/", "bi-sliders", "percentual compras dias úteis motor financeiro regras capacidade de compra configuração", e_gestor_financeiro),
        ("Compradores e Limites", "/financeiro/capacidade-compradores/", "bi-people-fill", "limite limites bloquear liberar comprador compradores capacidade dos compradores", pode("capacidade.gerenciar")),
        ("Calendário Operacional", "/financeiro/calendario-operacional/", "bi-calendar2-x", "feriado bloquear dia exceção dias bloqueados", pode("calendario.configurar")),
        ("Parcelamentos", "/financeiro/parcelamentos/", "bi-credit-card-2-front", "parcelas em aberto vencidas", pode("financeiro.ver")),
        ("Contas a Pagar", "/financeiro/contas-a-pagar/", "bi-receipt", "pagamentos compromissos do mês", pode("financeiro.ver")),
        ("Receitas", "/financeiro/receitas/", "bi-cash-coin", "faturamento receita mensal", e_gestor_financeiro),
        ("Receitas extras", "/financeiro/receitas/extras/", "bi-plus-square", "receita extra serviços farmacêuticos convênios convênio pbm rendimentos outras receitas", e_gestor_financeiro),
        ("Custos Fixos", "/financeiro/custos-fixos/", "bi-receipt", "custo fixo folha aluguel contas", e_gestor_financeiro),
        ("Custos Variáveis", "/financeiro/custos-variaveis/", "bi-arrow-left-right", "custo variável contas despesas", e_gestor_financeiro),
        ("Análise Financeira", "/financeiro/analise/", "bi-graph-up-arrow", "dre gerencial demonstrativo resultado lucro prejuízo margem créditos débitos saúde financeira", e_analise),
        ("Créditos × Débitos", "/financeiro/analise/creditos-debitos/", "bi-arrow-left-right", "análise financeira créditos e débitos caixa entradas saídas balancete saldo", e_analise),
        ("Saúde Financeira", "/financeiro/analise/saude/", "bi-heart-pulse", "análise financeira indicadores ponto de equilíbrio margem de segurança recomendações", e_analise),
        ("Timeline Financeira", "/timeline/", "bi-clock-history", "histórico motor", pode("timeline.ver")),
        ("Fornecedores", "/compras/fornecedores/", "bi-truck", "fornecedor cadastro", e_gestor_financeiro),
        ("Categorias", "/cadastros/categorias/", "bi-tags-fill", "categoria cadastro", e_gestor_financeiro),
        ("Centros de Custo", "/cadastros/centros-custo/", "bi-diagram-3-fill", "centro de custo cadastro", e_gestor_financeiro),
        ("Indicadores", "/indicadores/", "bi-graph-up-arrow", "kpi números consolidados ranking de fornecedores", e_gestor),
        ("Central de Relatórios", "/relatorios/", "bi-file-earmark-bar-graph", "relatórios imprimir exportar csv", pode("relatorios.ver")),
        ("Compras por Filial", "/compras/relatorios/por-filial/", "bi-building", "relatório cnpj ranking filiais", e_gestor),
        ("Compras por Comprador", "/compras/relatorios/por-comprador/", "bi-person-lines-fill", "relatório ranking compradores", e_gestor),
        ("Centro de Configurações", "/ncc/", "bi-sliders", "configurar configurações parametrizar ncc", pode("ncc.acessar")),
        ("Checklist de Implantação", "/ncc/checklist/", "bi-list-check", "implantação primeiros passos pendências", pode("ncc.acessar")),
        ("Integrações", "/ncc/integracoes/", "bi-plug", "integração dda banco boletos", pode("ncc.acessar")),
        ("Empresas e Filiais", "/ncc/estrutura/", "bi-building", "empresa filial filiais cnpj grupo loja dados da empresa", pode("ncc.acessar")),
        ("Usuários e Permissões", "/ncc/usuarios/", "bi-people-fill", "usuários criar usuário permissões", pode("ncc.acessar")),
        ("Perfis de Acesso", "/ncc/perfis/", "bi-person-badge", "perfil acesso permissões rbac", pode("ncc.acessar")),
        ("Workflow de Aprovações", "/ncc/workflow/", "bi-diagram-2", "fluxos de aprovação fluxo alçada etapas workflow", pode("workflow.configurar")),
        ("Auditoria do Sistema", "/ncc/auditoria/", "bi-shield-check", "auditoria logs histórico configuração", pode("ncc.acessar")),
        ("Notificações", "/notificacoes/", "bi-bell-fill", "avisos alertas", True),
        ("Meu Perfil", "/perfil/", "bi-person-circle", "senha foto conta", True),
        ("Manual do sistema", "/ajuda/", "bi-book", "ajuda manual central de ajuda como usar dúvidas perguntas frequentes", True),
        ("Bem-vindo ao NEXBUY", "/bem-vindo/", "bi-info-circle", "ajuda apresentação tour", True),
    ]
    return [t for t in telas if t[4]]


# Palavras que não ajudam a achar uma tela ("contas a pagar", "créditos x
# débitos") — ignoradas na consulta quando sobra alguma outra palavra.
_PALAVRAS_VAZIAS = frozenset({"a", "o", "as", "os", "e", "x", "de", "da", "do", "das", "dos", "em", "no", "na",
                              "para", "com", "por", "um", "uma"})


def normalizar_busca(texto):
    """Minúsculas, sem acento e sem pontuação ("Créditos × Débitos" →
    "creditos debitos"). Aplicada aos DOIS lados da comparação."""
    import re
    import unicodedata

    texto = unicodedata.normalize("NFKD", str(texto or "")).lower()
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return " ".join(re.sub(r"[^0-9a-z]+", " ", texto).split())


def casa_busca(termo_normalizado, texto):
    """True quando CADA palavra da consulta começa alguma palavra do texto
    (casamento por palavra: "receita extra" acha "Receitas extras"; "saude"
    acha "Saúde Financeira") ou a consulta inteira aparece no texto."""
    alvo = normalizar_busca(texto)
    if not termo_normalizado:
        return False
    if termo_normalizado in alvo:
        return True
    palavras = [p for p in termo_normalizado.split() if p not in _PALAVRAS_VAZIAS] or termo_normalizado.split()
    palavras_alvo = alvo.split()
    return all(any(w.startswith(p) for w in palavras_alvo) for p in palavras)


@login_required
def busca_global(request):
    """Pesquisa Global (Épico 2A — Etapa 08): telas/ações + registros que o
    usuário PODE ver — reutiliza os mesmos escopos por perfil da RC
    (`compras_visiveis_para`, `provisoes_visiveis_para`); nenhum resultado
    fora da autorização de quem pesquisa."""
    from compras.models import Fornecedor
    from compras.services import compras_visiveis_para
    from gestao_compras.services import provisoes_visiveis_para

    termo = (request.GET.get("q") or "").strip()
    resultados = {"telas": [], "compras": [], "provisoes": [], "fornecedores": []}
    # Sprint de Correções Críticas (Seção 16): busca global também deve
    # respeitar a empresa ATIVA, não a principal do usuário.
    empresa = empresa_ativa(request)

    if termo:
        # Rodada final: acentos e maiúsculas normalizados nos dois lados
        # ("Saúde", "saude", "SAÚDE" dão o mesmo resultado) e casamento por
        # palavra — antes era substring exata, e "Saúde Financeira",
        # "Créditos", "analise" ou "receita extra" não achavam nada.
        termo_normalizado = normalizar_busca(termo)
        resultados["telas"] = [
            {"titulo": titulo, "url": url, "icone": icone}
            for titulo, url, icone, chaves, _ok in _telas_pesquisaveis(request.user)
            if casa_busca(termo_normalizado, f"{titulo} {chaves}")
        ][:8]

        # Fornecedores: o SQLite só ignora maiúsculas em ASCII ("farmacia"
        # não achava "Farmácia") — a lista da empresa é pequena, então a
        # comparação normalizada roda em Python e os ids alimentam as
        # consultas de compras e provisões.
        ids_fornecedores = []
        if empresa is not None and termo_normalizado:
            ids_fornecedores = [
                pk for pk, nome in Fornecedor.objects.filter(empresa=empresa).values_list("pk", "nome")
                if casa_busca(termo_normalizado, nome)
            ]
        resultados["compras"] = list(
            compras_visiveis_para(request.user, empresa)
            .filter(Q(fornecedor_id__in=ids_fornecedores) | Q(fornecedor__nome__icontains=termo)
                    | Q(observacao__icontains=termo))
            .order_by("-data_compra")[:8]
        )
        resultados["provisoes"] = list(
            provisoes_visiveis_para(request.user, empresa)
            .filter(Q(fornecedor_id__in=ids_fornecedores) | Q(fornecedor__nome__icontains=termo))
            .select_related("fornecedor")
            .order_by("-data")[:8]
        )
        if request.user.perfil in PERFIS_GESTORES_FINANCEIROS and empresa is not None:
            resultados["fornecedores"] = list(
                Fornecedor.objects.filter(Q(pk__in=ids_fornecedores) | Q(nome__icontains=termo), empresa=empresa)
                .order_by("nome")[:8]
            )

    total = sum(len(v) for v in resultados.values())
    return render(
        request,
        "core/busca.html",
        {"termo": termo, "resultados": resultados, "total": total},
    )


@login_required
def configuracoes_redirect(request):
    """Épico 2A (Etapa 02): /configuracoes/ deixa de ser uma segunda
    central — quem pode acessar o Centro de Configurações vai para lá;
    o Financeiro (que usava a landing para achar a config do motor) vai
    para o hub de Planejamento Financeiro."""
    if usuario_tem_permissao(request.user, "ncc.acessar"):
        return redirect("/ncc/")
    if usuario_tem_permissao(request.user, "financeiro.ver"):
        return redirect("financeiro:planejamento")
    return redirect("dashboard:home")


@permissao_required("relatorios.ver")
def relatorios_home(request):
    """Central de Relatórios (Épico 2A — Etapa 01; Sprint de Consolidação
    — Gate 2A, P1-6): os relatórios com impressão profissional e
    exportação CSV ficam em destaque, com as ações já à mão; as demais
    visões analíticas que já existiam continuam listadas abaixo. Nenhuma
    regra nova — cada relatório continua sendo a MESMA consulta já
    escopada por perfil/permissão/empresa ativa das telas de origem."""
    user = request.user
    exportaveis = []
    outros = []

    def adicionar(lista, titulo, descricao, url, icone, pode):
        if pode:
            lista.append({"titulo": titulo, "descricao": descricao, "url": url, "icone": icone})

    e_gestor = user.perfil in ("gerente", "proprietario", "financeiro")

    # Análise Financeira (mudança de escopo): DRE Gerencial + Créditos ×
    # Débitos + Saúde Financeira — mesmo gate de perfil das views (o CSV do
    # card é o da DRE do mês atual). Nunca aparece para o Comprador.
    adicionar(
        exportaveis, "Análise Financeira (DRE)",
        "DRE gerencial do mês, créditos × débitos e saúde financeira, com curvas de 12 meses.",
        "/financeiro/analise/", "bi-graph-up-arrow", user.perfil in PERFIS_ANALISE_FINANCEIRA,
    )
    # Prioridade da Sprint de Consolidação (P1-6): impressão + CSV já prontos.
    adicionar(
        exportaveis, "Histórico de Compras", "Todas as compras que você pode ver, com status e valores.",
        "/compras/lista/", "bi-list-check", True,
    )
    adicionar(
        exportaveis, "Agenda Financeira", "Pagamentos e vencimentos — parcelas, contas fixas, variáveis e provisões.",
        "/financeiro/agenda/", "bi-calendar2-week", usuario_tem_permissao(user, "agenda.ver"),
    )
    adicionar(
        exportaveis, "Parcelamentos", "Parcelas em aberto, com vencidas em destaque.",
        "/financeiro/parcelamentos/", "bi-credit-card-2-front", usuario_tem_permissao(user, "financeiro.ver"),
    )
    adicionar(
        exportaveis, "Contas a Pagar", "Compromissos do mês fechado — pagamentos, contas e provisões.",
        "/financeiro/contas-a-pagar/", "bi-receipt", usuario_tem_permissao(user, "financeiro.ver"),
    )
    adicionar(
        exportaveis, "Compras por Comprador", "Ranking de quanto cada comprador gastou no mês.",
        "/compras/relatorios/por-comprador/", "bi-person-lines-fill", e_gestor,
    )
    adicionar(
        exportaveis, "Compras por CNPJ / Filial", "Ranking de compras por filial da empresa ativa.",
        "/compras/relatorios/por-filial/", "bi-building", e_gestor,
    )

    # Demais visões analíticas (sem impressão/CSV dedicados nesta Sprint).
    adicionar(
        outros, "Timeline Financeira", "Histórico dia a dia do Motor: compras, saldos e redistribuições.",
        "/timeline/", "bi-clock-history", usuario_tem_permissao(user, "timeline.ver"),
    )
    adicionar(
        outros, "Calendário Financeiro", "Visões mensal, semanal e diária do caixa comprometido.",
        "/financeiro/calendario/", "bi-calendar3", usuario_tem_permissao(user, "financeiro.ver"),
    )
    adicionar(
        outros, "Indicadores Consolidados", "KPIs operacionais do mês e ranking de fornecedores.",
        "/indicadores/", "bi-graph-up-arrow", e_gestor,
    )
    adicionar(
        outros, "Simulador de Compra", "\"E se eu comprasse X no dia Y?\" — sem gravar nada.",
        "/compras/simulacao/", "bi-calculator-fill", user.perfil in ("proprietario", "financeiro", "comprador"),
    )
    adicionar(
        outros, "Auditoria do Sistema", "Quem alterou o quê, e quando, nas parametrizações.",
        "/ncc/auditoria/", "bi-shield-check", usuario_tem_permissao(user, "ncc.acessar"),
    )

    return render(request, "core/relatorios.html", {"exportaveis": exportaveis, "outros": outros})
