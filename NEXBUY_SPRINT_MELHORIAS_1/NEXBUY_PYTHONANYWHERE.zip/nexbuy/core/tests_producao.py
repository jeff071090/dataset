"""Pronto para a Nuvem (VPS Hostinger + GitHub) — garantias de produção.

Cobre o que a implantação real depende e que nenhum outro arquivo de teste
vê: settings de produção montados a partir das variáveis de ambiente,
`/healthz/`, páginas de erro que funcionam SEM banco, página de falha de
CSRF, superusuário técnico com o modelo `Usuario` customizado, `.gitignore`
e os scripts de `deploy/` (fim de linha LF — CRLF quebra no Linux com
"bad interpreter" — e coerência entre nginx, gunicorn, systemd e o modelo
de variáveis).

`settings.py` só é avaliado quando o processo sobe, então os testes de
settings reexecutam o ARQUIVO num namespace isolado (`runpy.run_path`) com
um ambiente controlado — nunca alteram o `django.conf.settings` em uso.
"""
import fnmatch
import json
import os
import re
import runpy
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest import mock

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured, PermissionDenied
from django.core.management import call_command
from django.db import OperationalError
from django.template import loader
from django.test import Client, RequestFactory, SimpleTestCase, TestCase, override_settings
from django.urls import path

from core import views_healthcheck

BASE_DIR = Path(settings.BASE_DIR)
SETTINGS_PY = BASE_DIR / "nexbuy" / "settings.py"
DEPLOY_DIR = BASE_DIR / "deploy"

SECRET_KEY_FORTE = "k7Qm2-teste-producao-Xz9vR4pL8sW1nB6yT3cF0hJ5gD2aE7uI9oK4mN1qS8wV"

# Variáveis que settings.py lê e que precisam de valor determinístico nos
# testes (o `.env` local do desenvolvedor, carregado pelo load_dotenv, nunca
# sobrescreve variáveis já definidas — por isso todas são definidas aqui).
AMBIENTE_BASE = {
    "SECRET_KEY": SECRET_KEY_FORTE,
    "DEBUG": "False",
    "ALLOWED_HOSTS": "nexbuy.exemplo.com.br,www.nexbuy.exemplo.com.br",
    "CSRF_TRUSTED_ORIGINS": "",
    "USA_PROXY_HTTPS": "False",
    "SECURE_SSL_REDIRECT": "True",
    "SECURE_HSTS_SECONDS": "31536000",
    "SECURE_HSTS_INCLUDE_SUBDOMAINS": "True",
    "SECURE_HSTS_PRELOAD": "False",
    "DB_ENGINE": "sqlite3",
    "SQLITE_PATH": "",
    "SQLITE_WAL": "",
    "MEDIA_ROOT": "",
    "STATIC_ROOT": "",
    "ADMIN_URL": "",
    "LOG_LEVEL": "",
    "DEMO_MODE": "False",
}


def carregar_settings(**variaveis):
    """Executa nexbuy/settings.py com AMBIENTE_BASE + `variaveis` e devolve
    o namespace resultante (dict). O os.environ do processo volta ao estado
    original ao final."""
    ambiente = {**AMBIENTE_BASE, **{k: str(v) for k, v in variaveis.items()}}
    with mock.patch.dict(os.environ, ambiente):
        return runpy.run_path(str(SETTINGS_PY))


def _ler_bytes(caminho):
    return Path(caminho).read_bytes()


# ---------------------------------------------------------------------------
# 1. Settings de produção por variáveis de ambiente
# ---------------------------------------------------------------------------


class SettingsProducaoPorAmbienteTestCase(SimpleTestCase):
    def test_hardening_completo_com_debug_false(self):
        s = carregar_settings()
        self.assertFalse(s["DEBUG"])
        self.assertTrue(s["SECURE_SSL_REDIRECT"])
        self.assertTrue(s["SESSION_COOKIE_SECURE"])
        self.assertTrue(s["CSRF_COOKIE_SECURE"])
        self.assertTrue(s["SECURE_CONTENT_TYPE_NOSNIFF"])
        self.assertEqual(s["SECURE_HSTS_SECONDS"], 31536000)
        self.assertEqual(s["STORAGES"]["staticfiles"]["BACKEND"], "nexbuy.storage.NexbuyStaticFilesStorage")
        self.assertIn("whitenoise.middleware.WhiteNoiseMiddleware", s["MIDDLEWARE"])

    def test_csrf_trusted_origins_derivado_de_allowed_hosts_quando_vazio(self):
        s = carregar_settings(ALLOWED_HOSTS="nexbuy.exemplo.com.br,www.nexbuy.exemplo.com.br")
        self.assertEqual(
            s["CSRF_TRUSTED_ORIGINS"],
            ["https://nexbuy.exemplo.com.br", "https://www.nexbuy.exemplo.com.br"],
        )

    def test_curinga_nunca_vira_origem_confiavel_e_subdominio_vira_padrao(self):
        s = carregar_settings(ALLOWED_HOSTS="*,.nexbuy.exemplo.com.br")
        self.assertEqual(s["CSRF_TRUSTED_ORIGINS"], ["https://*.nexbuy.exemplo.com.br"])

    def test_csrf_trusted_origins_explicito_e_respeitado(self):
        s = carregar_settings(CSRF_TRUSTED_ORIGINS="https://outro.exemplo.com.br")
        self.assertEqual(s["CSRF_TRUSTED_ORIGINS"], ["https://outro.exemplo.com.br"])

    def test_em_desenvolvimento_nada_e_derivado(self):
        s = carregar_settings(DEBUG="True")
        self.assertEqual(s["CSRF_TRUSTED_ORIGINS"], [])
        self.assertNotIn("SECURE_PROXY_SSL_HEADER", s)
        self.assertNotIn("init_command", s["DATABASES"]["default"]["OPTIONS"])

    def test_proxy_https_so_quando_pedido(self):
        self.assertNotIn("SECURE_PROXY_SSL_HEADER", carregar_settings(USA_PROXY_HTTPS="False"))
        s = carregar_settings(USA_PROXY_HTTPS="True")
        self.assertEqual(s["SECURE_PROXY_SSL_HEADER"], ("HTTP_X_FORWARDED_PROTO", "https"))

    def test_sqlite_wal_em_producao_sem_perder_o_locking_immediate(self):
        s = carregar_settings()
        opcoes = s["DATABASES"]["default"]["OPTIONS"]
        self.assertEqual(opcoes["transaction_mode"], "IMMEDIATE")
        self.assertEqual(opcoes["timeout"], 20)
        self.assertEqual(opcoes["init_command"], "PRAGMA journal_mode=WAL;")

    def test_sqlite_wal_pode_ser_desligado_ou_forcado(self):
        self.assertNotIn("init_command", carregar_settings(SQLITE_WAL="False")["DATABASES"]["default"]["OPTIONS"])
        s = carregar_settings(DEBUG="True", SQLITE_WAL="True")
        self.assertEqual(s["DATABASES"]["default"]["OPTIONS"]["init_command"], "PRAGMA journal_mode=WAL;")

    def test_caminhos_de_producao_vem_do_ambiente(self):
        with tempfile.TemporaryDirectory() as pasta:
            s = carregar_settings(
                SQLITE_PATH=os.path.join(pasta, "db.sqlite3"),
                MEDIA_ROOT=os.path.join(pasta, "media"),
                STATIC_ROOT=os.path.join(pasta, "staticfiles"),
            )
        self.assertEqual(str(s["DATABASES"]["default"]["NAME"]), os.path.join(pasta, "db.sqlite3"))
        self.assertEqual(Path(s["MEDIA_ROOT"]), Path(pasta) / "media")
        self.assertEqual(Path(s["STATIC_ROOT"]), Path(pasta) / "staticfiles")

    def test_caminhos_padrao_preservados_sem_variavel(self):
        s = carregar_settings()
        self.assertEqual(Path(s["STATIC_ROOT"]), BASE_DIR / "staticfiles")
        self.assertEqual(Path(s["MEDIA_ROOT"]), BASE_DIR / "media")
        self.assertEqual(Path(s["DATABASES"]["default"]["NAME"]), BASE_DIR / "db.sqlite3")

    def test_admin_url_configuravel_e_normalizado(self):
        self.assertEqual(carregar_settings()["ADMIN_URL"], "admin/")
        self.assertEqual(carregar_settings(ADMIN_URL="/suporte-3f9a1c2e")["ADMIN_URL"], "suporte-3f9a1c2e/")
        self.assertEqual(carregar_settings(ADMIN_URL="suporte-3f9a1c2e/")["ADMIN_URL"], "suporte-3f9a1c2e/")

    def test_guard_da_secret_key_recusa_chaves_publicas_e_vazia(self):
        for chave in (
            "django-insecure-nexbuy-dev-key-troque-em-producao",
            "troque-esta-chave-por-uma-chave-secreta-e-unica-em-producao",
            "",
        ):
            with self.subTest(chave=chave), self.assertRaises(ImproperlyConfigured):
                carregar_settings(SECRET_KEY=chave)

    def test_preload_do_hsts_desligado_silencia_so_o_w021(self):
        self.assertEqual(carregar_settings()["SILENCED_SYSTEM_CHECKS"], ["security.W021"])
        self.assertNotIn("SILENCED_SYSTEM_CHECKS", carregar_settings(SECURE_HSTS_PRELOAD="True"))

    def test_logging_registra_erros_de_requisicao_no_console(self):
        s = carregar_settings()
        self.assertEqual(s["LOGGING"]["loggers"]["django.request"]["level"], "ERROR")
        self.assertIn("console", s["LOGGING"]["loggers"]["django.request"]["handlers"])
        self.assertEqual(s["LOGGING"]["handlers"]["console"]["class"], "logging.StreamHandler")

    def test_opcoes_do_banco_da_demo_continuam_iguais_as_do_principal(self):
        """A demo (settings_demo) herda OPTIONS por deepcopy — a mudança do
        WAL não pode quebrar essa igualdade (core/tests_pacote_demo.py)."""
        import importlib

        demo = importlib.import_module("nexbuy.settings_demo")
        principal = importlib.import_module("nexbuy.settings")
        self.assertEqual(demo.DATABASES["default"].get("OPTIONS"), principal.DATABASES["default"].get("OPTIONS"))


class ModoWalRealTestCase(SimpleTestCase):
    """O Django realmente aplica o PRAGMA do init_command numa conexão nova
    (arquivo temporário, nunca o banco do projeto)."""

    def test_conexao_nova_abre_em_modo_wal(self):
        from django.db.utils import ConnectionHandler

        opcoes = carregar_settings()["DATABASES"]["default"]["OPTIONS"]
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as pasta:
            # Handler PRÓPRIO (não o django.db.connections do projeto): o
            # alias "default" aqui é só um arquivo temporário.
            conexoes = ConnectionHandler(
                {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": os.path.join(pasta, "wal.sqlite3"), "OPTIONS": dict(opcoes)}}
            )
            conexao = conexoes["default"]
            # Mesmo caminho que o Django usa ao abrir uma conexão (parâmetros
            # + init_command), sem passar pelo ensure_connection que o
            # SimpleTestCase bloqueia.
            bruta = conexao.get_new_connection(conexao.get_connection_params())
            try:
                self.assertEqual(bruta.execute("PRAGMA journal_mode").fetchone()[0].lower(), "wal")
            finally:
                bruta.close()


class CheckDeployTestCase(SimpleTestCase):
    """`manage.py check --deploy` com as variáveis de produção sai limpo —
    é o mesmo comando que o instalador da VPS roda."""

    def test_check_deploy_sem_avisos(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as pasta:
            ambiente = {
                **os.environ,
                **AMBIENTE_BASE,
                "USA_PROXY_HTTPS": "True",
                "SQLITE_PATH": os.path.join(pasta, "check.sqlite3"),
                "PYTHONIOENCODING": "utf-8",
                # O runner exporta o settings da suíte (ex.: settings_demo);
                # a VPS usa o principal.
                "DJANGO_SETTINGS_MODULE": "nexbuy.settings",
            }
            resultado = subprocess.run(
                [sys.executable, "manage.py", "check", "--deploy", "--fail-level", "WARNING"],
                cwd=BASE_DIR, env=ambiente, capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=180,
            )
        self.assertEqual(resultado.returncode, 0, resultado.stdout + resultado.stderr)
        self.assertIn("no issues", resultado.stdout)


# ---------------------------------------------------------------------------
# 2. /healthz/
# ---------------------------------------------------------------------------


class HealthzTestCase(TestCase):
    def test_responde_200_ok_sem_login(self):
        resposta = Client().get("/healthz/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta["Content-Type"], "application/json")
        self.assertEqual(json.loads(resposta.content), {"status": "ok"})
        self.assertIn("no-store", resposta["Cache-Control"])

    def test_head_tambem_funciona_e_post_nao(self):
        self.assertEqual(Client().head("/healthz/").status_code, 200)
        self.assertEqual(Client().post("/healthz/").status_code, 405)

    def test_banco_fora_do_ar_responde_503_sem_vazar_detalhe(self):
        conexao_quebrada = mock.MagicMock()
        conexao_quebrada.cursor.side_effect = OperationalError(
            "unable to open database file /var/lib/nexbuy/db.sqlite3 SEGREDO-INTERNO"
        )
        with mock.patch.object(views_healthcheck, "connection", conexao_quebrada), \
                self.assertLogs("nexbuy.infra", level="ERROR"), \
                self.assertLogs("django.request", level="ERROR"):
            resposta = Client().get("/healthz/")
        self.assertEqual(resposta.status_code, 503)
        self.assertEqual(json.loads(resposta.content), {"status": "indisponivel"})
        conteudo = resposta.content.decode("utf-8")
        for proibido in ("SEGREDO-INTERNO", "/var/lib", "sqlite", "Traceback", "OperationalError"):
            self.assertNotIn(proibido, conteudo)


# ---------------------------------------------------------------------------
# 3. Páginas de erro SEM banco e falha de CSRF
# ---------------------------------------------------------------------------


def _view_que_quebra_o_banco(request):
    raise OperationalError("database is locked")


def _view_sem_permissao(request):
    raise PermissionDenied("Você não tem permissão para acessar esta página.")


# URLConf mínima usada só pelos testes abaixo (override de ROOT_URLCONF).
urlpatterns = [
    path("quebra-o-banco/", _view_que_quebra_o_banco),
    path("sem-permissao/", _view_sem_permissao),
]
handler403 = "core.views_healthcheck.erro_403"
handler500 = "core.views_healthcheck.erro_500"

PAGINAS_DE_ERRO = {
    "400.html": "Requisição inválida",
    "403.html": "Acesso negado",
    "404.html": "Página não encontrada",
    "500.html": "Algo deu errado",
    "403_csrf.html": "Sua sessão expirou",
}


class PaginasDeErroSemBancoTestCase(SimpleTestCase):
    """SimpleTestCase proíbe QUALQUER consulta ao banco — se uma página de
    erro tentasse consultar (context processor, usuário, empresa), o teste
    quebraria. É exatamente a situação do 500 com o banco fora do ar."""

    def _conferir_pagina(self, conteudo, titulo):
        self.assertIn(titulo, conteudo)
        self.assertIn("NEXBUY", conteudo)
        self.assertIn('lang="pt-br"', conteudo)
        self.assertIn('href="/"', conteudo)
        self.assertIn("Voltar ao início", conteudo)
        self.assertIn("css/nexbuy.css", conteudo)
        for proibido in ("None", "NaN", "Infinity", "Traceback", "{#", "#}", "{%", "%}"):
            self.assertNotIn(proibido, conteudo)

    def test_templates_renderizam_sem_request_e_sem_banco(self):
        for template_name, titulo in PAGINAS_DE_ERRO.items():
            with self.subTest(template=template_name):
                contexto = {"caminho": "/"} if template_name == "403_csrf.html" else {}
                self._conferir_pagina(loader.get_template(template_name).render(contexto), titulo)

    def test_handlers_configurados_na_urlconf_principal(self):
        from nexbuy import urls

        self.assertEqual(urls.handler400, "core.views_healthcheck.erro_400")
        self.assertEqual(urls.handler403, "core.views_healthcheck.erro_403")
        self.assertEqual(urls.handler404, "core.views_healthcheck.erro_404")
        self.assertEqual(urls.handler500, "core.views_healthcheck.erro_500")
        self.assertEqual(settings.CSRF_FAILURE_VIEW, "core.views_healthcheck.falha_csrf")

    def test_404_real_personalizado(self):
        resposta = self.client.get("/nexbuy-rota-inexistente-404/")
        self.assertEqual(resposta.status_code, 404)
        self._conferir_pagina(resposta.content.decode("utf-8"), "Página não encontrada")

    def test_400_host_nao_permitido_usa_a_pagina_propria(self):
        with self.assertLogs("django.security.DisallowedHost", level="ERROR"):
            resposta = self.client.get("/", HTTP_HOST="host-invalido.exemplo")
        self.assertEqual(resposta.status_code, 400)
        self._conferir_pagina(resposta.content.decode("utf-8"), "Requisição inválida")

    @override_settings(ROOT_URLCONF="core.tests_producao")
    def test_500_com_banco_fora_do_ar_mostra_pagina_amigavel(self):
        cliente = Client(raise_request_exception=False)
        with self.assertLogs("django.request", level="ERROR"):
            resposta = cliente.get("/quebra-o-banco/")
        self.assertEqual(resposta.status_code, 500)
        conteudo = resposta.content.decode("utf-8")
        self._conferir_pagina(conteudo, "Algo deu errado")
        self.assertNotIn("database is locked", conteudo)

    @override_settings(ROOT_URLCONF="core.tests_producao")
    def test_403_sem_contexto_de_usuario(self):
        with self.assertLogs("django.request", level="WARNING"):
            resposta = self.client.get("/sem-permissao/")
        self.assertEqual(resposta.status_code, 403)
        self._conferir_pagina(resposta.content.decode("utf-8"), "Acesso negado")

    def test_500_renderiza_mesmo_se_o_template_falhar(self):
        with mock.patch.object(views_healthcheck.loader, "get_template", side_effect=RuntimeError("quebrado")), \
                self.assertLogs("nexbuy.infra", level="ERROR"):
            resposta = views_healthcheck.erro_500(RequestFactory().get("/"))
        self.assertEqual(resposta.status_code, 500)
        conteudo = resposta.content.decode("utf-8")
        self.assertIn("Algo deu errado", conteudo)
        self.assertIn("Voltar ao início", conteudo)

    def test_falha_de_csrf_mostra_sessao_expirada_com_recarregar(self):
        cliente = Client(enforce_csrf_checks=True)
        with self.assertLogs("django.security.csrf", level="WARNING"):
            resposta = cliente.post("/accounts/login/", {"username": "x", "password": "y"})
        self.assertEqual(resposta.status_code, 403)
        conteudo = resposta.content.decode("utf-8")
        self._conferir_pagina(conteudo, "Sua sessão expirou")
        self.assertIn("Recarregar a página", conteudo)
        self.assertIn('href="/accounts/login/"', conteudo)
        # Com DEBUG=False (runner de testes), o motivo técnico não aparece.
        self.assertNotIn("CSRF", conteudo)

    def test_falha_de_csrf_nunca_recarrega_para_outro_site(self):
        for caminho in ("//outro-site.exemplo/x", "/\\outro-site.exemplo/x", "https://outro-site.exemplo/"):
            with self.subTest(caminho=caminho):
                request = RequestFactory().post("/qualquer/")
                request.path = caminho
                conteudo = views_healthcheck.falha_csrf(request, reason="teste").content.decode("utf-8")
                self.assertNotIn("outro-site.exemplo", conteudo)
                self.assertIn('href="/" class="btn btn-nx-primary', conteudo)


# ---------------------------------------------------------------------------
# 4. Superusuário técnico com o modelo Usuario customizado
# ---------------------------------------------------------------------------


@override_settings(INITIAL_SETUP_TOKEN="token-de-teste-producao")
class SuperusuarioTecnicoTestCase(TestCase):
    def test_createsuperuser_nao_interativo_funciona_com_usuario_customizado(self):
        from usuarios.models import Usuario

        with mock.patch.dict(os.environ, {"DJANGO_SUPERUSER_PASSWORD": "Sup0rte-Tecnico-Forte!2026"}):
            call_command(
                "createsuperuser", interactive=False, username="suporte.tecnico",
                email="suporte@exemplo.com.br", verbosity=0,
            )
        usuario = Usuario.objects.get(username="suporte.tecnico")
        self.assertTrue(usuario.is_superuser)
        self.assertTrue(usuario.is_staff)
        self.assertTrue(usuario.check_password("Sup0rte-Tecnico-Forte!2026"))

    def test_superusuario_criado_antes_fecha_o_primeiro_acesso(self):
        """A regra documentada no guia de deploy: o superusuário técnico só
        pode ser criado DEPOIS do Primeiro Acesso — qualquer usuário ativo
        fecha a tela /primeiro-acesso/."""
        from core.views_primeiro_acesso import _primeiro_acesso_disponivel
        from usuarios.models import Usuario

        self.assertTrue(_primeiro_acesso_disponivel())
        Usuario.objects.create_superuser("suporte.tecnico", "suporte@exemplo.com.br", "Sup0rte-Tecnico-Forte!2026")
        self.assertFalse(_primeiro_acesso_disponivel())


# ---------------------------------------------------------------------------
# 5. .gitignore, .gitattributes e scripts de deploy/
# ---------------------------------------------------------------------------


def _padroes_gitignore():
    linhas = (BASE_DIR / ".gitignore").read_text(encoding="utf-8").splitlines()
    return [linha.strip() for linha in linhas if linha.strip() and not linha.strip().startswith("#")]


def _ignorado(caminho, padroes):
    """Simulação simples das regras do git (suficiente para os padrões
    usados no projeto): último padrão que casa decide; "!" reinclui;
    padrão terminado em "/" casa com um diretório do caminho."""
    partes = caminho.split("/")
    resultado = False
    for padrao in padroes:
        negado = padrao.startswith("!")
        p = padrao[1:] if negado else padrao
        if p.endswith("/"):
            casou = any(fnmatch.fnmatch(parte, p[:-1]) for parte in partes[:-1])
        else:
            casou = fnmatch.fnmatch(partes[-1], p) or fnmatch.fnmatch(caminho, p)
        if casou:
            resultado = not negado
    return resultado


class GitignoreTestCase(SimpleTestCase):
    def test_segredos_bancos_midia_e_saidas_de_teste_ficam_fora_do_github(self):
        padroes = _padroes_gitignore()
        for caminho in (
            ".env", "db.sqlite3", "db_demo_cliente.sqlite3", "db.sqlite3-wal", "db.sqlite3-shm",
            "media/identidade/logos/logo.png", "media_demo_cliente/identidade/logos/logo.png",
            "staticfiles/css/nexbuy.css", "venv/Scripts/python.exe", "core/__pycache__/views.cpython-312.pyc",
            "core/views.pyc", "test_run_core.txt", "cookies.txt", "servidor.log",
            "qa_etapa02_screenshots/login.png", "Thumbs.db", ".DS_Store",
        ):
            with self.subTest(caminho=caminho):
                self.assertTrue(_ignorado(caminho, padroes), f"{caminho} iria para o GitHub")

    def test_codigo_e_modelos_documentados_continuam_versionados(self):
        padroes = _padroes_gitignore()
        for caminho in (
            ".env.example", "deploy/env.producao.exemplo", "deploy/instalar_servidor.sh",
            "manage.py", "requirements.txt", "static/vendor/bootstrap/css/bootstrap.min.css",
            "templates/404.html", "docs/DEPLOY_HOSTINGER_GITHUB.md", ".github/workflows/testes.yml",
        ):
            with self.subTest(caminho=caminho):
                self.assertFalse(_ignorado(caminho, padroes), f"{caminho} ficaria fora do GitHub")

    def test_gitattributes_forca_lf_nos_arquivos_do_servidor(self):
        texto = (BASE_DIR / ".gitattributes").read_text(encoding="utf-8")
        for extensao in ("*.sh", "*.conf", "*.service", "*.timer", "*.env.exemplo", "*.exemplo"):
            with self.subTest(extensao=extensao):
                self.assertRegex(texto, rf"(?m)^{re.escape(extensao)}\s+text eol=lf\s*$")


class ScriptsDeployTestCase(SimpleTestCase):
    def _scripts(self):
        scripts = sorted(DEPLOY_DIR.glob("*.sh"))
        self.assertGreaterEqual(len(scripts), 6)
        return scripts

    def test_scripts_existem(self):
        nomes = {p.name for p in self._scripts()}
        for esperado in ("instalar_servidor.sh", "atualizar.sh", "backup.sh", "restaurar_backup.sh",
                         "criar_suporte_tecnico.sh", "nexbuy-manage.sh", "_comum.sh"):
            self.assertIn(esperado, nomes)

    def test_todos_os_arquivos_de_deploy_tem_fim_de_linha_lf(self):
        arquivos = [p for p in DEPLOY_DIR.iterdir() if p.is_file()]
        arquivos.append(BASE_DIR / ".github" / "workflows" / "testes.yml")
        for arquivo in arquivos:
            with self.subTest(arquivo=arquivo.name):
                self.assertNotIn(b"\r", _ler_bytes(arquivo), f"{arquivo.name} tem CR (fim de linha Windows)")

    def test_scripts_tem_shebang_bash_e_modo_estrito(self):
        for script in self._scripts():
            with self.subTest(script=script.name):
                conteudo = _ler_bytes(script).decode("utf-8")
                self.assertTrue(conteudo.startswith("#!/usr/bin/env bash\n"), script.name)
                if script.name != "_comum.sh":
                    self.assertIn("set -Eeuo pipefail", conteudo)

    def test_scripts_nunca_tem_bom_utf8(self):
        for arquivo in DEPLOY_DIR.iterdir():
            if arquivo.is_file():
                with self.subTest(arquivo=arquivo.name):
                    self.assertFalse(_ler_bytes(arquivo).startswith(b"\xef\xbb\xbf"))

    def test_socket_e_pastas_coerentes_entre_nginx_gunicorn_systemd_e_env(self):
        nginx = (DEPLOY_DIR / "nginx_nexbuy.conf").read_text(encoding="utf-8")
        gunicorn = (DEPLOY_DIR / "gunicorn.conf.py").read_text(encoding="utf-8")
        servico = (DEPLOY_DIR / "nexbuy.service").read_text(encoding="utf-8")
        exemplo = (DEPLOY_DIR / "env.producao.exemplo").read_text(encoding="utf-8")

        self.assertIn("unix:/run/nexbuy/gunicorn.sock", nginx)
        self.assertIn("unix:/run/nexbuy/gunicorn.sock", gunicorn)
        self.assertIn("RuntimeDirectory=nexbuy", servico)
        self.assertIn("EnvironmentFile=/etc/nexbuy/nexbuy.env", servico)
        self.assertIn("--config /opt/nexbuy/app/deploy/gunicorn.conf.py", servico)
        self.assertIn("__SERVER_NAMES__", nginx)
        self.assertIn("client_max_body_size", nginx)
        self.assertIn("X-Forwarded-Proto $scheme", nginx)

        self.assertIn("STATIC_ROOT=/var/lib/nexbuy/staticfiles", exemplo)
        self.assertIn("alias /var/lib/nexbuy/staticfiles/;", nginx)
        self.assertIn("MEDIA_ROOT=/var/lib/nexbuy/media", exemplo)
        self.assertIn("alias /var/lib/nexbuy/media/;", nginx)
        self.assertIn("SQLITE_PATH=/var/lib/nexbuy/db.sqlite3", exemplo)

    def test_modelo_de_env_nunca_traz_segredo_e_documenta_tudo_que_o_instalador_gera(self):
        exemplo = (DEPLOY_DIR / "env.producao.exemplo").read_text(encoding="utf-8")
        self.assertRegex(exemplo, r"(?m)^SECRET_KEY=$")
        self.assertRegex(exemplo, r"(?m)^INITIAL_SETUP_TOKEN=$")
        # Rodada final (regra mudou): FEATURE_INOVAFARMA/FEATURE_IA saíram do
        # escopo — o settings não as lê, então nem o instalador as grava nem
        # o modelo as documenta como linha ativa (eram flags mortas que
        # sugeriam integrações que não existem). Só o DDA segue previsto.
        for linha in ("DEBUG=False", "DEMO_MODE=False", "USA_PROXY_HTTPS=True", "ALLOW_SEED_IN_PRODUCTION=False",
                      "FEATURE_DDA=False"):
            self.assertRegex(exemplo, rf"(?m)^{re.escape(linha)}$")
        for morta in ("FEATURE_INOVAFARMA", "FEATURE_IA"):
            self.assertNotRegex(exemplo, rf"(?m)^{morta}=")

        instalador = (DEPLOY_DIR / "instalar_servidor.sh").read_text(encoding="utf-8")
        bloco = instalador.split('cat > "$ENV_FILE" <<EOF', 1)[1].split("\nEOF", 1)[0]
        geradas = set(re.findall(r"(?m)^([A-Z][A-Z0-9_]*)=", bloco))
        documentadas = set(re.findall(r"(?m)^#?\s*([A-Z][A-Z0-9_]*)=", exemplo))
        self.assertTrue({"SECRET_KEY", "INITIAL_SETUP_TOKEN", "ALLOWED_HOSTS", "SQLITE_PATH"} <= geradas)
        self.assertEqual(geradas - documentadas, set())
        self.assertFalse({"FEATURE_INOVAFARMA", "FEATURE_IA"} & geradas)

    def test_instalador_nunca_sobrescreve_o_env_existente(self):
        """criar_env (a única escrita do nexbuy.env) só é chamado no ramo
        "o arquivo NÃO existe" — com o arquivo presente, só "mantido"."""
        instalador = (DEPLOY_DIR / "instalar_servidor.sh").read_text(encoding="utf-8")
        inicio_if = instalador.index('    if [[ -f "$ENV_FILE" ]]; then\n')
        ramo_else = instalador.index("    else\n        criar_env\n", inicio_if)
        self.assertIn("mantido sem nenhuma alteração", instalador[inicio_if:ramo_else])
        self.assertEqual(len(re.findall(r"(?m)^\s+criar_env\s*$", instalador)), 1)
        self.assertEqual(instalador.count('cat > "$ENV_FILE"'), 1)
        corpo_criar_env = instalador.split("criar_env() {", 1)[1].split("\n}\n", 1)[0]
        self.assertIn('cat > "$ENV_FILE"', corpo_criar_env)

    def test_backup_usa_api_online_do_sqlite_e_retencao(self):
        backup = (DEPLOY_DIR / "backup.sh").read_text(encoding="utf-8")
        self.assertIn(".backup", backup)
        self.assertIn("PRAGMA integrity_check", backup)
        self.assertIn('RETENCAO_DIAS:-14', backup)
        atualizar = (DEPLOY_DIR / "atualizar.sh").read_text(encoding="utf-8")
        self.assertLess(atualizar.index("backup.sh"), atualizar.index("migrate --noinput"))

    def test_workflow_do_github_roda_a_suite_completa(self):
        workflow = (BASE_DIR / ".github" / "workflows" / "testes.yml").read_text(encoding="utf-8")
        self.assertIn('python-version: "3.12"', workflow)
        self.assertIn("pip install -r requirements.txt", workflow)
        self.assertIn("makemigrations --check --dry-run", workflow)
        self.assertIn("manage.py test --settings=nexbuy.settings_demo", workflow)
        self.assertIn('DEBUG: "True"', workflow)


class DocumentacaoDeDeployTestCase(SimpleTestCase):
    def test_guia_de_deploy_cobre_o_caminho_inteiro(self):
        texto = (BASE_DIR / "docs" / "DEPLOY_HOSTINGER_GITHUB.md").read_text(encoding="utf-8")
        for trecho in (
            "Ubuntu 24.04", "KVM 2", "git push", "deploy key", "instalar_servidor.sh",
            "/primeiro-acesso/", "INITIAL_SETUP_TOKEN", "Usuários e Permissões", "createsuperuser",
            "journalctl -u nexbuy", "502", "DisallowedHost", "CSRF", "certbot", "atualizar.sh", "backup.sh",
        ):
            with self.subTest(trecho=trecho):
                self.assertIn(trecho, texto)

    def test_guia_de_operacao_existe_com_backup_restauracao_e_atualizacao(self):
        texto = (BASE_DIR / "docs" / "OPERACAO_BACKUP_E_ATUALIZACAO.md").read_text(encoding="utf-8")
        for trecho in ("backup.sh", "restaurar_backup.sh", "atualizar.sh", "/var/backups/nexbuy", "healthz"):
            with self.subTest(trecho=trecho):
                self.assertIn(trecho, texto)
