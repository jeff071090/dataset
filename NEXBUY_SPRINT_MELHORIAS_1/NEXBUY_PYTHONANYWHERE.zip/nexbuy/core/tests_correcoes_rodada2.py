"""Regressão dos defeitos apontados pelos críticos independentes (rodada 2).

Cada classe trava um defeito que existia antes da correção:

- Compradores e Limites num dia sem limite (fim de semana/feriado) mostrava
  o limite-base de dia útil e a dotação como "Disponível/Livre";
- painel do Financeiro lia só a 1ª filial do contexto (pagamentos de hoje
  sumiam; cabeçalho, barra lateral e corpo falavam de filiais diferentes);
- valores negativos como "sobram R$ -920,22" / "Hoje R$ -675";
- estado sem receita pintado de verde ("Compra liberada"/"Liberada");
- widget "Resultado do mês" sem o aviso de análise incompleta;
- nomes diferentes para a mesma tela (Ajuda × menu × título × cards);
- contraste do texto de apoio dos KPIs e impressão da Saúde Financeira.

Os testes de dia sem limite cadastram HOJE como feriado no Calendário
Operacional — independem do dia da semana em que a suíte roda.
"""
import re
from datetime import date
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.test import Client, SimpleTestCase, TestCase, override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor, ParcelaCompra
from core.utils_testes import garantir_capacidade_no_dia
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, DiaOperacional, Receita
from usuarios.models import Usuario, UsuarioEmpresa, UsuarioFilial

TERMOS_PROIBIDOS_HTML = ("None", "NaN", "Infinity")


def _html(teste, resposta):
    teste.assertEqual(resposta.status_code, 200)
    html = resposta.content.decode()
    for termo in TERMOS_PROIBIDOS_HTML:
        teste.assertIsNone(re.search(rf">[^<]*\b{termo}\b[^<]*<", html), termo)
    return html


def _titulo(html):
    achado = re.search(r'<div class="nx-topbar-title">\s*(.*?)\s*<', html, re.S)
    return achado.group(1).strip() if achado else None


@override_settings(ALLOWED_HOSTS=["*"])
class CenarioRodada2(TestCase):
    """Empresa com duas filiais ("Loja Bairro" vem antes de "Loja Centro"
    na ordem alfabética — exatamente o caso do defeito do painel do
    Financeiro, cuja filial é a Centro)."""

    def setUp(self):
        self.hoje = date.today()
        self.empresa = Empresa.objects.create(nome="Farmácia Rodada 2", cnpj="64.000.000/0001-64")
        self.bairro = Filial.objects.create(empresa=self.empresa, nome="Loja Bairro")
        self.centro = Filial.objects.create(empresa=self.empresa, nome="Loja Centro")
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, percentual_compras=Decimal("50"),
                                              dias_uteis_manual=20)
        for filial in (self.bairro, self.centro):
            Receita.objects.create(filial=filial, mes=self.hoje.replace(day=1), faturamento=Decimal("100000.00"))

        def usuario(username, perfil, filial, **extra):
            u = Usuario.objects.create_user(username=username, password="x", perfil=perfil, empresa=self.empresa,
                                            filial=filial, **extra)
            UsuarioEmpresa.objects.get_or_create(usuario=u, empresa=self.empresa)
            return u

        self.proprietario = usuario("prop_r2", Usuario.Perfil.PROPRIETARIO, None)
        self.financeiro = usuario("fin_r2", Usuario.Perfil.FINANCEIRO, self.centro, first_name="Ana")
        UsuarioFilial.objects.create(usuario=self.financeiro, filial=self.bairro)
        UsuarioFilial.objects.create(usuario=self.financeiro, filial=self.centro)
        self.gerente = usuario("ger_r2", Usuario.Perfil.GERENTE, self.centro)
        self.comprador = usuario("comp_r2", Usuario.Perfil.COMPRADOR, self.centro, first_name="Pedro")
        UsuarioEmpresa.objects.filter(usuario=self.comprador).update(limite_compra=Decimal("1500.00"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Distribuidora R2")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos R2")

    def cliente(self, usuario):
        client = Client()
        client.force_login(usuario)
        return client

    def hoje_feriado(self):
        DiaOperacional.objects.update_or_create(
            empresa=self.empresa, data=self.hoje, defaults={"tipo": DiaOperacional.Tipo.FERIADO},
        )

    def compra(self, filial, valor, status=Compra.Status.APROVADA, usuario=None):
        return Compra.objects.create(
            empresa=self.empresa, filial=filial, fornecedor=self.fornecedor, usuario=usuario or self.comprador,
            valor=Decimal(valor), categoria=self.categoria, data_compra=self.hoje, status=status,
        )


class CompradoresELimitesEmDiaSemLimiteTestCase(CenarioRodada2):
    def test_limite_de_hoje_e_dotacoes_avisam_que_hoje_nao_e_dia_de_compra(self):
        self.hoje_feriado()
        resposta = self.cliente(self.financeiro).get("/financeiro/capacidade-compradores/")
        html = _html(self, resposta)
        # A filial padrão é a do próprio usuário (a do cabeçalho), não a 1ª do contexto.
        self.assertEqual(resposta.context["filial"], self.centro)
        self.assertEqual(resposta.context["limite_hoje"], 0)
        self.assertTrue(resposta.context["hoje_sem_limite"])
        self.assertIn("Limite de hoje da filial", html)
        self.assertIn("hoje (feriado) sem limite", html)
        self.assertIn("data-nx-dia-sem-compra", html)
        self.assertIn("sem compra hoje", html)
        self.assertIn("Dia sem compra", html)
        self.assertNotIn(">Livre<", html.replace('<span class="nx-badge-dot"></span>', ""))
        self.assertNotIn("capacidade a distribuir hoje", html)

    def test_dia_util_continua_mostrando_disponivel(self):
        garantir_capacidade_no_dia(self.empresa)
        resposta = self.cliente(self.financeiro).get("/financeiro/capacidade-compradores/")
        html = _html(self, resposta)
        self.assertFalse(resposta.context["hoje_sem_limite"])
        self.assertGreater(resposta.context["limite_hoje"], 0)
        self.assertIn("capacidade a distribuir hoje", html)
        self.assertIn("R$ 1.500,00", html)
        self.assertNotIn("sem compra hoje", html)

    def test_card_de_dotacao_do_comprador_nao_diz_acima_disso_vai_para_aprovacao(self):
        self.hoje_feriado()
        html = _html(self, self.cliente(self.comprador).get("/"))
        self.assertIn("data-nx-dotacao-dia-sem-compra", html)
        self.assertIn("hoje (feriado) não é dia de compra", html)
        self.assertNotIn("acima disso vai para aprovação", html)


class PainelFinanceiroMesmaFilialTestCase(CenarioRodada2):
    def test_pagamento_de_hoje_da_outra_filial_aparece_e_numeros_do_dia_sao_da_filial_do_usuario(self):
        compra = self.compra(self.bairro, "847.29")
        ParcelaCompra.objects.create(compra=compra, numero=1, data_vencimento=self.hoje, valor=Decimal("847.29"))
        resposta = self.cliente(self.financeiro).get("/")
        html = _html(self, resposta)
        self.assertEqual(resposta.context["filial_foco"], self.centro)
        self.assertEqual(resposta.context["pagamentos_hoje"]["quantidade"], 1)
        self.assertEqual(resposta.context["pagamentos_hoje"]["itens"][0]["filial_nome"], "Loja Bairro")
        self.assertNotIn("Nenhum pagamento previsto para hoje", html)
        self.assertIn("R$ 847,29", html)
        self.assertIn("Próximos dias e dias críticos · Loja Centro", html)
        self.assertIn("Compradores hoje · Loja Centro", html)

    def test_alertas_dizem_de_qual_filial_sao(self):
        self.hoje_feriado()
        self.compra(self.bairro, "675.00")
        self.compra(self.centro, "920.22")
        resposta = self.cliente(self.financeiro).get("/")
        titulos = {(a["titulo"], a["filial_nome"]) for a in resposta.context["alertas"]}
        self.assertIn(("Capacidade de hoje excedida", "Loja Bairro"), titulos)
        self.assertIn(("Capacidade de hoje excedida", "Loja Centro"), titulos)


class NegativosViramExcedidoTestCase(CenarioRodada2):
    def test_gerente_financeiro_e_proprietario_nao_mostram_saldo_negativo_cru(self):
        self.hoje_feriado()
        self.compra(self.centro, "920.22")

        html_ger = _html(self, self.cliente(self.gerente).get("/"))
        self.assertIn("Limite de hoje", html_ger)
        self.assertIn("Loja Centro: hoje (feriado) sem limite", html_ger)
        self.assertIn("excedido em R$ 920,22", html_ger)
        self.assertNotIn("sobram R$ -", html_ger)

        html_fin = _html(self, self.cliente(self.financeiro).get("/"))
        self.assertIn("data-nx-chip-excedido", html_fin)
        self.assertIn("excedido R$ 920", html_fin)
        self.assertNotRegex(html_fin, r'class="valor">R\$ -')

        resposta = self.cliente(self.proprietario).get("/")
        html_pro = _html(self, resposta)
        linha = next(f for f in resposta.context["resumo_empresas"][0]["filiais"] if f["filial"] == self.centro)
        self.assertEqual(linha["limite_hoje"], 0)
        self.assertEqual(linha["excedido_hoje"], Decimal("920.22"))
        self.assertIn(">Limite de hoje<", html_pro)
        self.assertIn("hoje (feriado) sem limite · dia útil:", html_pro)
        self.assertIn("excedido em R$ 920,22", html_pro)


class EstadoSemReceitaNeutroTestCase(CenarioRodada2):
    def setUp(self):
        super().setUp()
        self.nova = Filial.objects.create(empresa=self.empresa, nome="Filial Nova")
        self.comprador_novo = Usuario.objects.create_user(
            username="comp_nova_r2", password="x", perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa,
            filial=self.nova,
        )

    def test_proximos_dias_do_comprador_ficam_neutros_e_mensagens_dizem_quem_age(self):
        from dashboard.viewmodels import viewmodel_comprador

        payload = viewmodel_comprador(self.comprador_novo, self.hoje)
        self.assertTrue(payload["calendario_preview"])
        self.assertTrue(all(d["sem_configuracao"] for d in payload["calendario_preview"]))
        self.assertTrue(all(d["sem_configuracao"] for d in payload["tendencia_proximos_dias"]))

        html = _html(self, self.cliente(self.comprador_novo).get("/"))
        self.assertIn("data-nx-preview-sem-configuracao", html)
        self.assertIn("Sem configuração (falta a receita do mês)", html)
        self.assertNotIn("nx-calendar-day nx-cor-verde", html)
        self.assertIn("O Financeiro ainda não lançou a receita do mês", html)
        self.assertNotIn("cadastre o faturamento", html.lower())
        # Barra lateral: "—" e "aguardando a receita", nunca "R$ 0,00 · Disponível".
        self.assertIn("data-nx-sidebar-nao-configurado", html)
        self.assertIn("Aguardando a receita do mês", html)
        for termo in ("Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal", "Meta Mensal"):
            self.assertNotIn(termo, html)

    def test_indicadores_mostram_sem_configuracao_e_nao_liberada(self):
        resposta = self.cliente(self.proprietario).get("/indicadores/")
        html = _html(self, resposta)
        linha = next(l for l in resposta.context["por_filial"] if l["filial"] == self.nova)
        self.assertFalse(linha["configurada"])
        trecho = html.split("Filial Nova", 1)[1].split("</tr>", 1)[0]
        self.assertIn("Sem configuração", trecho)
        self.assertNotIn("Liberada", trecho)


class WidgetResultadoIncompletoTestCase(CenarioRodada2):
    def test_sem_compras_aprovadas_o_widget_avisa_como_a_dre(self):
        from financeiro.services_analise import resumo_resultado_do_mes

        CustoFixo.objects.create(filial=self.centro, descricao="Folha", valor=Decimal("32300.00"), dia_vencimento=5)
        resumo = resumo_resultado_do_mes([self.centro, self.bairro], self.proprietario, self.hoje)
        self.assertTrue(resumo["incompleto"])
        self.assertEqual(resumo["lacunas"]["faltando_texto"], "as compras aprovadas")

        for usuario in (self.proprietario, self.financeiro, self.gerente):
            html = _html(self, self.cliente(usuario).get("/"))
            self.assertIn("data-an-widget-incompleto", html, usuario.username)
            self.assertIn("incompleto: faltam as compras aprovadas", html, usuario.username)

        self.compra(self.centro, "1500.00")
        resumo = resumo_resultado_do_mes([self.centro, self.bairro], self.proprietario, self.hoje)
        self.assertFalse(resumo["incompleto"])
        self.assertNotIn("data-an-widget-incompleto", _html(self, self.cliente(self.proprietario).get("/")))


class NomesCanonicosTestCase(CenarioRodada2):
    """Uma tela, um nome: o do menu e da Ajuda, repetido no título, na
    trilha e nos cards do Centro de Configurações."""

    def test_titulos_das_telas(self):
        cliente = self.cliente(self.proprietario)
        esperados = {
            "/financeiro/configuracao/": "Capacidade Financeira",
            "/financeiro/capacidade-compradores/": "Compradores e Limites",
            "/compras/lista/": "Histórico de Compras",
            "/gestao-compras/": "Calendário de Compras",
            "/ncc/usuarios/": "Usuários e Permissões",
            "/ncc/auditoria/": "Auditoria do Sistema",
            "/ncc/integracoes/": "Integrações",
            "/ncc/gerais/": "Configurações Gerais",
            "/ncc/perfis/": "Perfis de Acesso",
            "/ncc/workflow/": "Workflow de Aprovações",
        }
        for url, titulo in esperados.items():
            html = _html(self, cliente.get(url))
            self.assertEqual(_titulo(html), titulo, url)
            self.assertNotIn("NCC —", html, url)

    def test_cards_do_centro_de_configuracoes_abrem_a_tela_do_proprio_nome(self):
        html = _html(self, self.cliente(self.proprietario).get("/ncc/"))
        cards = dict(
            (titulo.strip(), url)
            for url, titulo in re.findall(r'<a href="([^"]+)" class="nx-card nx-card-hover[^>]*>.*?'
                                          r'<div class="fw-semibold">([^<]+)</div>', html, re.S)
        )
        self.assertEqual(cards.get("Capacidade Financeira"), "/financeiro/configuracao/")
        self.assertEqual(cards.get("Compradores e Limites"), "/financeiro/capacidade-compradores/")
        self.assertEqual(cards.get("Usuários e Permissões"), "/ncc/usuarios/")
        self.assertEqual(cards.get("Auditoria do Sistema"), "/ncc/auditoria/")

    def test_menu_e_trilha_usam_o_mesmo_nome(self):
        from core.navegacao import TRILHAS

        self.assertEqual(TRILHAS["financeiro:configuracao"][-1][0], "Capacidade Financeira")
        self.assertEqual(TRILHAS["financeiro:capacidade_compradores"][-1][0], "Compradores e Limites")
        self.assertEqual(TRILHAS["ncc:auditoria"][-1][0], "Auditoria do Sistema")
        html = _html(self, self.cliente(self.proprietario).get("/"))
        self.assertNotIn("Capacidade e Limites", html)


class CssContrasteEImpressaoTestCase(SimpleTestCase):
    def _css(self, nome):
        return (Path(settings.BASE_DIR) / "static" / "css" / nome).read_text(encoding="utf-8")

    def test_texto_de_apoio_dos_kpis_coloridos_tem_contraste_aa(self):
        css = self._css("nexbuy.css")
        self.assertIn(".nx-kpi-tint .nx-kpi-hint { color: var(--nx-gray-700); }", css)
        self.assertIn(".nx-kpi-tint .nx-kpi-hint.nx-text-red { color: var(--nx-danger-dark); }", css)
        self.assertIn(".nx-text-red { color: var(--nx-danger-dark); }", css)

        def luminancia(hexa):
            canais = [int(hexa[i:i + 2], 16) / 255 for i in (1, 3, 5)]
            lin = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in canais]
            return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]

        texto = luminancia("#475569")
        for fundo in ("#EFF6FF", "#F0FDF4", "#FFFBEB", "#FEF2F2", "#F5F3FF", "#ECFEFF"):
            razao = (luminancia(fundo) + 0.05) / (texto + 0.05)
            self.assertGreaterEqual(razao, 4.5, fundo)

    def test_impressao_da_grade_de_indicadores_em_fluxo_normal(self):
        css = self._css("analise.css")
        impressao = css.split("@media print", 1)[1]
        self.assertIn("[data-an-indicadores] { display: block !important;", impressao)
        self.assertIn("display: inline-block !important;", impressao)
        self.assertIn("break-inside: avoid", impressao)
