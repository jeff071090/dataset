"""Regressão da rodada final de correção do produto (críticos independentes,
rodada 2 — funcional, UX/escopo e produção).

Cada classe trava um defeito que existia antes da correção:

- receita mensal com dia ≠ 01 num mês que já tinha receita dava HTTP 500
  (IntegrityError) e, com dia 01, a página só recarregava sem mensagem;
- Calendário de Compras sem seletor de filial (Proprietário preso na 1ª em
  ordem alfabética) e provisões do dia sem link para a timeline;
- provisão aprovada sem caminho navegável até o "Efetivar";
- DRE / Créditos × Débitos num mês sem receita mostravam "prejuízo" e
  "saíram mais do que entraram"; meses antes da implantação com custos;
- composição do mês com sinal duplo "(−) ... R$ -10.500,00";
- busca global sem normalizar acentos e sem várias telas do menu;
- hub Planejamento Financeiro e botões do Calendário Financeiro com links
  que davam 403 para o Gerente com RBAC aditivo;
- textos: Bem-vindo, Dados da Empresa ("/admin/"), Agenda 90 dias,
  fluxo de aprovação salvo inativo em silêncio, /demo/trocar-perfil/ 405;
- cor computada da variação da DRE e fundo do tour na impressão
  (navegador real, quando o Playwright estiver instalado).
"""
import importlib.util
import re
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.test import Client, SimpleTestCase, TestCase, override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from core.utils_testes import garantir_capacidade_no_dia
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, Receita
from gestao_compras.models import ItemProvisao, Provisao
from notificacoes.models import Notificacao
from usuarios.models import Permissao, Usuario, UsuarioEmpresa, UsuarioFilial

BASE_DIR = Path(settings.BASE_DIR)
TERMOS_PROIBIDOS_HTML = ("None", "NaN", "Infinity")


def _html(teste, resposta, status=200):
    teste.assertEqual(resposta.status_code, status)
    html = resposta.content.decode()
    for termo in TERMOS_PROIBIDOS_HTML:
        teste.assertIsNone(re.search(rf">[^<]*\b{termo}\b[^<]*<", html), termo)
    return html


def _mes_seguinte(dia):
    return (dia.replace(day=28) + timedelta(days=7)).replace(day=1)


def _mes_anterior(dia):
    return (dia.replace(day=1) - timedelta(days=1)).replace(day=1)


@override_settings(ALLOWED_HOSTS=["*"], DEMO_MODE=False)
class CenarioRodadaFinal(TestCase):
    """Empresa com "Filial Centro" e "Matriz" — a Centro vem antes na ordem
    alfabética, exatamente o caso do Calendário preso na 1ª filial."""

    def setUp(self):
        self.hoje = date.today()
        self.mes = self.hoje.replace(day=1)
        self.empresa = Empresa.objects.create(nome="Farmácia Rodada Final", cnpj="11.222.333/0001-81")
        self.centro = Filial.objects.create(empresa=self.empresa, nome="Filial Centro")
        self.matriz = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, percentual_compras=Decimal("50"),
                                              dias_uteis_manual=20)
        for filial in (self.centro, self.matriz):
            Receita.objects.create(filial=filial, mes=self.mes, faturamento=Decimal("100000.00"))

        def usuario(username, perfil, filial, **extra):
            u = Usuario.objects.create_user(username=username, password="x", perfil=perfil,
                                            empresa=self.empresa, filial=filial, **extra)
            UsuarioEmpresa.objects.get_or_create(usuario=u, empresa=self.empresa)
            return u

        self.proprietario = usuario("prop_rf", Usuario.Perfil.PROPRIETARIO, None)
        self.financeiro = usuario("fin_rf", Usuario.Perfil.FINANCEIRO, self.matriz)
        self.gerente = usuario("ger_rf", Usuario.Perfil.GERENTE, self.matriz)
        self.comprador = usuario("comp_rf", Usuario.Perfil.COMPRADOR, self.matriz)
        for u in (self.financeiro, self.gerente):
            UsuarioFilial.objects.create(usuario=u, filial=self.matriz)
            UsuarioFilial.objects.create(usuario=u, filial=self.centro)
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Medfarma Distribuidora")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos RF")

    def cliente(self, usuario):
        c = Client()
        c.force_login(usuario)
        return c

    def conceder(self, usuario, *codigos):
        """RBAC aditivo (mesmo recurso da ficha do usuário)."""
        for codigo in codigos:
            usuario.permissoes_individuais.add(Permissao.objects.get(codigo=codigo))

    def provisao(self, filial, status, valor=Decimal("5000.00"), data=None):
        provisao = Provisao.objects.create(
            empresa=self.empresa, filial=filial, comprador=self.comprador, fornecedor=self.fornecedor,
            categoria=self.categoria, data=data or self.hoje, status=status,
        )
        ItemProvisao.objects.create(provisao=provisao, produto="Dipirona", quantidade=Decimal("1"),
                                    valor_unitario=valor)
        provisao.recalcular_valor_total()
        return provisao


# ---------------------------------------------------------------------------
# 1. Receita mensal: unicidade filial + mês com mensagem clara
# ---------------------------------------------------------------------------

class ReceitaDuplicadaTestCase(CenarioRodadaFinal):
    def _post(self, dados, url="/financeiro/receitas/nova/"):
        return self.cliente(self.financeiro).post(url, dados)

    def test_dia_diferente_de_01_no_mesmo_mes_mostra_mensagem_e_nao_da_500(self):
        dia = self.mes.replace(day=15)
        resposta = self._post({"filial": self.matriz.pk, "mes": dia.isoformat(), "faturamento": "1.000,00"})
        html = _html(self, resposta)
        self.assertIn(f"Já existe receita de {self.mes:%m/%Y} para Matriz — edite a existente", html)
        existente = Receita.objects.get(filial=self.matriz, mes=self.mes)
        self.assertIn(f'href="/financeiro/receitas/{existente.pk}/editar/"', html)
        self.assertEqual(Receita.objects.filter(filial=self.matriz).count(), 1)
        self.assertEqual(existente.faturamento, Decimal("100000.00"))

    def test_dia_01_duplicado_tambem_mostra_a_mensagem(self):
        resposta = self._post({"filial": self.matriz.pk, "mes": self.mes.isoformat(), "faturamento": "1.000,00"})
        self.assertIn("Já existe receita de", _html(self, resposta))

    def test_editar_outra_receita_para_um_mes_ocupado(self):
        anterior = Receita.objects.create(filial=self.matriz, mes=_mes_anterior(self.hoje),
                                          faturamento=Decimal("80000.00"))
        resposta = self._post(
            {"filial": self.matriz.pk, "mes": self.mes.replace(day=20).isoformat(), "faturamento": "80.000,00"},
            url=f"/financeiro/receitas/{anterior.pk}/editar/",
        )
        self.assertIn("Já existe receita de", _html(self, resposta))
        anterior.refresh_from_db()
        self.assertEqual(anterior.mes, _mes_anterior(self.hoje))

    def test_mes_livre_com_qualquer_dia_grava_no_dia_1(self):
        seguinte = _mes_seguinte(self.hoje)
        resposta = self._post({"filial": self.matriz.pk, "mes": seguinte.replace(day=17).isoformat(),
                               "faturamento": "90.000,00"})
        self.assertEqual(resposta.status_code, 302)
        self.assertTrue(Receita.objects.filter(filial=self.matriz, mes=seguinte).exists())

    def test_templates_de_cadastro_mostram_erros_gerais(self):
        for nome in ("financeiro/receita_form.html", "financeiro/custofixo_form.html",
                     "financeiro/custovariavel_form.html", "cadastros/categoria_form.html",
                     "cadastros/centrocusto_form.html", "compras/fornecedor_form.html",
                     "empresas/ncc/usuario_novo.html"):
            texto = (BASE_DIR / "templates" / nome).read_text(encoding="utf-8")
            self.assertIn("partials/_form_erros_gerais.html", texto, nome)


# ---------------------------------------------------------------------------
# 2. Calendário de Compras: seletor de filial e link para a timeline
# ---------------------------------------------------------------------------

class CalendarioFilialTestCase(CenarioRodadaFinal):
    def test_proprietario_escolhe_a_filial_e_os_links_levam_a_filial(self):
        cliente = self.cliente(self.proprietario)
        html = _html(self, cliente.get("/gestao-compras/"))
        self.assertIn("data-nx-seletor-filial", html)
        self.assertRegex(html, rf'<option value="{self.matriz.pk}"\s*>Matriz</option>')
        self.assertIn("Filial Centro —", html)  # padrão: 1ª em ordem alfabética

        html = _html(self, cliente.get("/gestao-compras/", {"filial": self.matriz.pk}))
        self.assertIn("Matriz —", html)
        self.assertRegex(html, rf'<option value="{self.matriz.pk}" selected>Matriz</option>')
        self.assertRegex(html, rf'href="\?ano=\d{{4}}&mes=\d+&filial={self.matriz.pk}">&laquo; Mês anterior')
        self.assertRegex(html, rf'href="\?ano=\d{{4}}&mes=\d+&filial={self.matriz.pk}">Próximo mês')
        self.assertIn(f'href="/gestao-compras/nova/?filial={self.matriz.pk}"', html)

    def test_nova_provisao_ja_vem_com_a_filial_do_calendario(self):
        resposta = self.cliente(self.proprietario).get("/gestao-compras/nova/", {"filial": self.matriz.pk})
        self.assertEqual(resposta.context["form"]["filial"].value(), self.matriz.pk)
        # Filial de fora da autorização é ignorada (não pré-seleciona nada).
        outra = Filial.objects.create(empresa=Empresa.objects.create(nome="Outra", cnpj="22.333.444/0001-81"),
                                      nome="Alheia")
        resposta = self.cliente(self.proprietario).get("/gestao-compras/nova/", {"filial": outra.pk})
        self.assertNotEqual(resposta.context["form"]["filial"].value(), outra.pk)

    def test_provisao_do_dia_tem_link_para_a_timeline(self):
        provisao = self.provisao(self.matriz, Provisao.Status.PROVISIONADA)
        html = _html(self, self.cliente(self.proprietario).get("/gestao-compras/", {"filial": self.matriz.pk}))
        self.assertIn(f'href="/gestao-compras/provisao/{provisao.pk}/timeline/"', html)

    def test_comprador_continua_sem_seletor_e_sem_vocabulario_financeiro(self):
        Receita.objects.filter(filial=self.matriz).delete()
        html = _html(self, self.cliente(self.comprador).get("/gestao-compras/"))
        self.assertNotIn("data-nx-seletor-filial", html)
        self.assertNotIn("faturamento", html.lower())
        for termo in ("Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal", "Meta Mensal"):
            self.assertNotIn(termo, html)
        self.assertIn("Aguardando a configuração financeira do mês", html)


# ---------------------------------------------------------------------------
# 3. Provisão aprovada → caminho até o Efetivar
# ---------------------------------------------------------------------------

class AguardandoEfetivacaoTestCase(CenarioRodadaFinal):
    def test_financeiro_e_gerente_veem_as_aprovadas_com_link_para_efetivar(self):
        aprovada = self.provisao(self.matriz, Provisao.Status.APROVADA)
        dentro = self.provisao(self.centro, Provisao.Status.PROVISIONADA, Decimal("300.00"))
        pendente = self.provisao(self.matriz, Provisao.Status.AGUARDANDO_APROVACAO)
        for usuario, url in ((self.financeiro, "/gestao-compras/aprovacao/"), (self.gerente, "/aprovacoes/"),
                             (self.proprietario, "/aprovacoes/")):
            html = _html(self, self.cliente(usuario).get(url))
            self.assertIn("Aprovadas aguardando efetivação", html, usuario.username)
            bloco = html.split("data-nx-aguardando-efetivacao", 1)[1]
            self.assertIn(f'href="/gestao-compras/provisao/{aprovada.pk}/efetivar/"', bloco)
            self.assertIn(f'href="/gestao-compras/provisao/{aprovada.pk}/timeline/"', bloco)
            self.assertIn(f'href="/gestao-compras/provisao/{dentro.pk}/efetivar/"', bloco)
            self.assertNotIn(f"/gestao-compras/provisao/{pendente.pk}/efetivar/", bloco)
            # O link leva a uma tela que abre (gate da view = gate do link).
            self.assertEqual(self.cliente(usuario).get(f"/gestao-compras/provisao/{aprovada.pk}/efetivar/").status_code, 200)
            # Ajuste final (produto-e-demo): no celular o "Efetivar" ficava
            # fora da tela (tabela de 694px em 360px). Abaixo de 768px, Data,
            # Filial, Valor e Situação se empilham na célula do Fornecedor —
            # a coluna da Ação nunca é escondida.
            tabela = bloco.split("</table>", 1)[0]
            self.assertIn("data-nx-aguardando-resumo-celular", tabela)
            self.assertIn('<th class="text-end">Ação</th>', tabela)
            celula_acao = tabela.split(f'href="/gestao-compras/provisao/{aprovada.pk}/efetivar/"', 1)[0].rsplit("<td", 1)[1]
            self.assertNotIn("d-none", celula_acao)
            for coluna in ("Data", "Filial", "Situação"):
                self.assertIn(f'<th class="d-none d-md-table-cell">{coluna}</th>', tabela)

    def test_efetivada_sai_da_lista(self):
        aprovada = self.provisao(self.matriz, Provisao.Status.APROVADA)
        Compra.objects.create(
            empresa=self.empresa, filial=self.matriz, fornecedor=self.fornecedor, usuario=self.financeiro,
            valor=aprovada.valor_total, categoria=self.categoria, data_compra=self.hoje,
            status=Compra.Status.APROVADA, provisao_origem=aprovada,
        )
        html = _html(self, self.cliente(self.financeiro).get("/gestao-compras/aprovacao/"))
        self.assertNotIn("data-nx-aguardando-efetivacao", html)

    def test_aprovacao_final_notifica_com_link_para_a_timeline(self):
        from gestao_compras.services import criar_provisao, motor_aprovacao_provisao

        garantir_capacidade_no_dia(self.empresa, self.hoje)
        provisao, solicitacao, excedeu = criar_provisao(
            filial=self.matriz, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=self.hoje, observacoes="",
            itens_dados=[{"produto": "Lote grande", "quantidade": Decimal("1"), "valor_unitario": Decimal("999999")}],
        )
        self.assertTrue(excedeu)
        motor_aprovacao_provisao.aprovar(solicitacao, self.proprietario, "ok")
        link = f"/gestao-compras/provisao/{provisao.pk}/timeline/"
        self.assertTrue(Notificacao.objects.filter(usuario=self.comprador, titulo="Provisão aprovada", link=link).exists())
        for usuario in (self.financeiro, self.gerente):
            notificacao = Notificacao.objects.get(usuario=usuario, titulo__startswith="Provisão aprovada — aguardando")
            self.assertEqual(notificacao.link, link)
            self.assertEqual(self.cliente(usuario).get(link).status_code, 200)
        self.assertFalse(Notificacao.objects.filter(usuario=self.proprietario, titulo__startswith="Provisão aprovada").exists())


# ---------------------------------------------------------------------------
# 4. Análise Financeira: mês sem receita, antes da implantação, incompleto
# ---------------------------------------------------------------------------

class AnaliseSemReceitaTestCase(CenarioRodadaFinal):
    def setUp(self):
        super().setUp()
        CustoFixo.objects.create(filial=self.matriz, descricao="Folha", valor=Decimal("39500.00"), dia_vencimento=5)
        self.seguinte = _mes_seguinte(self.hoje)

    def test_dre_de_mes_sem_receita_nao_mostra_prejuizo(self):
        from financeiro.services_analise import AnaliseFinanceira, montar_dre

        dados = montar_dre(AnaliseFinanceira([self.centro, self.matriz]), self.seguinte.year, self.seguinte.month)
        linhas = {linha["chave"]: linha for linha in dados["linhas"]}
        self.assertEqual(linhas["resultado"]["rotulo"], "(=) Resultado operacional")
        for chave in ("resultado", "margem_bruta", "margem_contribuicao", "receita_total"):
            self.assertEqual(linhas[chave]["atual_fmt"], "—", chave)
            self.assertEqual(linhas[chave]["variacao_fmt"], "—", chave)
            self.assertEqual(linhas[chave]["classe_variacao"], "an-var-neutra", chave)
        self.assertEqual(linhas["custos_fixos"]["atual_fmt"], "R$ 39.500,00")  # o que foi lançado continua

        url = f"/financeiro/analise/?ano={self.seguinte.year}&mes={self.seguinte.month}"
        html = _html(self, self.cliente(self.proprietario).get(url))
        tabela = html.split('data-an-tabela="dre"', 1)[1].split("</table>", 1)[0]
        self.assertNotIn("prejuízo", tabela)
        self.assertNotIn("R$ -", tabela)
        self.assertIn("data-an-cascata-sem-receita", html)
        self.assertNotIn('data-an-tabela="cascata"', html)

    def test_creditos_debitos_de_mes_sem_receita_nao_calcula_saldo(self):
        url = f"/financeiro/analise/creditos-debitos/?ano={self.seguinte.year}&mes={self.seguinte.month}"
        resposta = self.cliente(self.proprietario).get(url)
        html = _html(self, resposta)
        self.assertEqual(resposta.context["cd"]["kpis"]["saldo_fmt"], "—")
        self.assertNotIn("saíram mais do que entraram", html)
        self.assertIn("aguardando a receita do mês", html)
        linha = next(l for l in resposta.context["cd"]["tabela"] if l["selecionado"])
        self.assertEqual(linha["saldo_fmt"], "—")
        # O mês atual (com receita) continua com saldo calculado.
        atual = self.cliente(self.proprietario).get("/financeiro/analise/creditos-debitos/")
        self.assertNotEqual(atual.context["cd"]["kpis"]["saldo_fmt"], "—")

    def test_mes_antes_da_implantacao_fica_sem_dados(self):
        from financeiro.services_analise import AnaliseFinanceira

        antigo = _mes_anterior(_mes_anterior(_mes_anterior(self.hoje)))
        dre = AnaliseFinanceira([self.centro, self.matriz]).dre(antigo.year, antigo.month)
        self.assertTrue(dre.antes_da_implantacao)
        self.assertEqual(dre.custos_fixos, Decimal("0"))
        html = _html(self, self.cliente(self.proprietario).get(
            f"/financeiro/analise/?ano={antigo.year}&mes={antigo.month}"))
        self.assertIn("data-an-antes-implantacao", html)
        self.assertNotIn("R$ -39.500,00", html)

    def test_mes_incompleto_diz_provisorio_e_cascata_sem_sinal_duplo(self):
        from financeiro.services_analise import AnaliseFinanceira, montar_dre

        dados = montar_dre(AnaliseFinanceira([self.centro, self.matriz]), self.hoje.year, self.hoje.month)
        linhas = {linha["chave"]: linha for linha in dados["linhas"]}
        self.assertTrue(dados["lacunas"]["incompleto"])  # sem compras aprovadas no mês
        self.assertEqual(linhas["resultado"]["rotulo"], "(=) Resultado operacional — provisório")
        resposta = self.cliente(self.proprietario).get("/financeiro/analise/")
        cascata = {e["rotulo"]: e["valor_fmt"] for e in resposta.context["cascata_tabela"]}
        self.assertEqual(cascata["(−) Custos fixos"], "R$ 39.500,00")
        self.assertFalse(any(v.startswith("R$ -") for r, v in cascata.items() if r.startswith("(−)")))

    def test_saude_mostra_a_formula_com_os_numeros_do_calculo(self):
        Compra.objects.create(
            empresa=self.empresa, filial=self.matriz, fornecedor=self.fornecedor, usuario=self.financeiro,
            valor=Decimal("12500.00"), categoria=self.categoria, data_compra=self.hoje, status=Compra.Status.APROVADA,
        )
        html = _html(self, self.cliente(self.proprietario).get("/financeiro/analise/saude/"))
        formula = html.split("data-an-formula-equilibrio>", 1)[1].split("</div>", 1)[0]
        self.assertIn("custos fixos × receita ÷ margem de contribuição", formula)
        self.assertIn("R$ 39.500,00 × R$ 200.000,00 ÷ R$ 187.500,00", formula)
        self.assertIn("margem de contribuição de 93,75%", html)


# ---------------------------------------------------------------------------
# 5. Busca global: acentos, palavras e telas do menu com o gate da view
# ---------------------------------------------------------------------------

class BuscaGlobalRodadaFinalTestCase(CenarioRodadaFinal):
    def titulos(self, usuario, termo):
        resposta = self.cliente(usuario).get("/buscar/", {"q": termo})
        _html(self, resposta)
        return [t["titulo"] for t in resposta.context["resultados"]["telas"]]

    def test_acentos_e_maiusculas_nos_dois_lados(self):
        casos = {
            "Saúde Financeira": "Saúde Financeira", "saude": "Saúde Financeira", "SAÚDE": "Saúde Financeira",
            "Créditos": "Créditos × Débitos", "debitos": "Créditos × Débitos",
            "analise": "Análise Financeira", "prejuízo": "Análise Financeira", "convênio": "Receitas extras",
            "receita extra": "Receitas extras", "Capacidade Financeira": "Capacidade Financeira",
            "Checklist": "Checklist de Implantação", "Integracoes": "Integrações",
            "perfis de acesso": "Perfis de Acesso", "fluxos de aprovação": "Workflow de Aprovações",
            "contas a pagar": "Contas a Pagar",
        }
        for termo, esperado in casos.items():
            self.assertIn(esperado, self.titulos(self.proprietario, termo), termo)

    def test_fornecedor_com_acento_acha_sem_acento(self):
        Fornecedor.objects.create(empresa=self.empresa, nome="Farmácia São João Distribuidora")
        resposta = self.cliente(self.proprietario).get("/buscar/", {"q": "farmacia sao joao"})
        nomes = [f.nome for f in resposta.context["resultados"]["fornecedores"]]
        self.assertIn("Farmácia São João Distribuidora", nomes)

    def test_novas_telas_respeitam_o_gate_da_view(self):
        self.assertNotIn("Capacidade Financeira", self.titulos(self.gerente, "capacidade financeira"))
        self.assertNotIn("Saúde Financeira", self.titulos(self.comprador, "saude"))
        self.assertNotIn("Checklist de Implantação", self.titulos(self.financeiro, "checklist"))
        self.conceder(self.gerente, "financeiro.ver")
        self.assertIn("Contas a Pagar", self.titulos(self.gerente, "contas a pagar"))
        self.assertNotIn("Receitas extras", self.titulos(self.gerente, "receita extra"))


# ---------------------------------------------------------------------------
# 6. Links sem 403: hub Planejamento Financeiro e Calendário Financeiro
# ---------------------------------------------------------------------------

class LinksSem403TestCase(CenarioRodadaFinal):
    def test_hub_so_mostra_cartoes_que_abrem_e_com_os_nomes_do_menu(self):
        self.conceder(self.gerente, "financeiro.ver")
        cliente = self.cliente(self.gerente)
        resposta = cliente.get("/financeiro/planejamento/")
        _html(self, resposta)
        for area in resposta.context["areas"]:
            self.assertIn(cliente.get(area["url"]).status_code, (200, 302), area["titulo"])
        titulos = {area["titulo"] for area in resposta.context["areas"]}
        self.assertNotIn("Receitas", titulos)
        self.assertIn("Calendário Financeiro", titulos)

        titulos_fin = {a["titulo"] for a in self.cliente(self.financeiro).get("/financeiro/planejamento/").context["areas"]}
        for nome in ("Calendário Financeiro", "Compradores e Limites", "Calendário Operacional", "Simulador",
                     "Receitas", "Custos Fixos", "Capacidade Financeira"):
            self.assertIn(nome, titulos_fin)
        for antigo in ("Calendário Inteligente", "Limites dos Compradores", "Dias Bloqueados", "Simulações"):
            self.assertNotIn(antigo, titulos_fin)

    def test_botoes_do_calendario_financeiro_seguem_o_gate(self):
        self.conceder(self.gerente, "financeiro.ver")
        html = _html(self, self.cliente(self.gerente).get("/financeiro/calendario/"))
        self.assertNotIn('href="/compras/simulacao/', html)
        self.assertNotIn('href="/financeiro/calendario-operacional/"', html)
        html = _html(self, self.cliente(self.financeiro).get("/financeiro/calendario/"))
        self.assertIn('href="/compras/simulacao/', html)
        self.assertIn('href="/financeiro/calendario-operacional/"', html)


# ---------------------------------------------------------------------------
# 7. Rótulos, textos e fluxos menores
# ---------------------------------------------------------------------------

class TextosETelasTestCase(CenarioRodadaFinal):
    def test_indicadores_e_ranking_dizem_que_somam_pendentes(self):
        html = _html(self, self.cliente(self.gerente).get("/indicadores/"))
        self.assertIn("data-nx-regra-comprado", html)
        self.assertIn("aprovadas + aguardando aprovação", html.split("Fornecedores do mês", 1)[1])

    def test_bem_vindo_diz_que_provisao_vai_para_aprovacao(self):
        html = _html(self, self.cliente(self.proprietario).get("/bem-vindo/"))
        self.assertNotIn("aprovação automática", html)
        self.assertIn("enviada automaticamente para aprovação", html)
        self.assertIn("data-nx-modulo-analise", html)
        html = _html(self, self.cliente(self.comprador).get("/bem-vindo/"))
        self.assertNotIn("data-nx-modulo-analise", html)
        self.assertNotIn("Faturamento", html)

    def test_telas_da_cliente_nao_mandam_para_o_admin(self):
        for url in ("/empresas/", "/ncc/estrutura/"):
            html = _html(self, self.cliente(self.proprietario).get(url))
            self.assertNotIn("/admin/", html, url)
            self.assertNotIn("Painel Admin", html, url)
            self.assertIn("suporte técnico", html, url)

    def test_agenda_tem_botao_90_dias(self):
        html = _html(self, self.cliente(self.financeiro).get("/financeiro/agenda/", {"dias": 90}))
        self.assertIn("data-nx-agenda-90", html)

    def test_fluxo_novo_nasce_ativo_e_inativo_e_avisado(self):
        cliente = self.cliente(self.proprietario)
        resposta = cliente.get("/ncc/workflow/novo/")
        self.assertTrue(resposta.context["form"]["ativo"].value())
        dados = {
            "nome": "Alçadas", "etapas-TOTAL_FORMS": "1", "etapas-INITIAL_FORMS": "0",
            "etapas-MIN_NUM_FORMS": "0", "etapas-MAX_NUM_FORMS": "1000",
            "etapas-0-ordem": "1", "etapas-0-perfil_aprovador": Usuario.Perfil.GERENTE, "etapas-0-prazo_dias": "",
        }
        resposta = cliente.post("/ncc/workflow/novo/", dados, follow=True)
        self.assertIn("salvo como INATIVO", resposta.content.decode())

    @override_settings(DEMO_MODE=False)
    def test_rota_de_troca_de_perfil_da_demo_nao_existe_fora_do_modo_demo(self):
        self.assertEqual(Client().get("/demo/trocar-perfil/").status_code, 404)
        self.assertEqual(self.cliente(self.proprietario).get("/demo/trocar-perfil/").status_code, 404)
        self.assertEqual(self.cliente(self.proprietario).post("/demo/trocar-perfil/").status_code, 404)

    def test_primeiro_acesso_sem_opcao_vazia_duplicada(self):
        from core.forms_primeiro_acesso import PrimeiroAcessoForm

        vazias = [valor for valor, _rotulo in PrimeiroAcessoForm().fields["estado"].choices if not valor]
        self.assertEqual(len(vazias), 1)

    def test_proprietario_sem_receita_ve_traco_e_nao_r_0(self):
        Receita.objects.all().delete()
        html = _html(self, self.cliente(self.proprietario).get("/"))
        valor = html.split("data-nx-receita-total>", 1)[1].split("</div>", 1)[0]
        self.assertEqual(valor.strip(), "&mdash;")


# ---------------------------------------------------------------------------
# 8. Arquivos de deploy e documentação
# ---------------------------------------------------------------------------

class DeployEDocumentacaoTestCase(SimpleTestCase):
    def test_atualizar_volta_a_versao_anterior_sozinho(self):
        texto = (BASE_DIR / "deploy" / "atualizar.sh").read_bytes()
        self.assertNotIn(b"\r", texto)
        conteudo = texto.decode("utf-8")
        self.assertIn("trap 'desfazer_atualizacao $?' EXIT", conteudo)
        self.assertIn('git -C "$APP_DIR" reset --hard --quiet "$ATU_ANTERIOR"', conteudo)
        # Cada etapa arma a flag ANTES de rodar (o trap sabe o que desfazer).
        for flag, comando in (("ATU_PIP_INICIADO=1", "pip install --quiet"),
                              ("ATU_MIGRATE_INICIADO=1", "migrate --noinput"),
                              ("ATU_STATIC_INICIADO=1", "collectstatic --noinput"),
                              ("ATU_REINICIADO=1", 'systemctl restart "$SERVICO"')):
            corpo_main = conteudo.split("main() {", 1)[1]
            self.assertLess(corpo_main.index(flag), corpo_main.index(comando), flag)
        guia = (BASE_DIR / "docs" / "OPERACAO_BACKUP_E_ATUALIZACAO.md").read_text(encoding="utf-8")
        self.assertIn("o script volta sozinho para a versão anterior", guia)

    def test_nginx_recusa_https_de_host_desconhecido(self):
        nginx = (BASE_DIR / "deploy" / "nginx_nexbuy.conf").read_text(encoding="utf-8")
        self.assertIn("listen 443 ssl default_server;", nginx)
        self.assertIn("ssl_reject_handshake on;", nginx)

    def test_guias_sem_caminho_local_desta_maquina(self):
        for nome in ("DEPLOY_HOSTINGER_GITHUB.md", "OPERACAO_BACKUP_E_ATUALIZACAO.md", "MANUAL_DO_USUARIO.md",
                     "PRIMEIROS_PASSOS_ADMINISTRADOR.md"):
            self.assertNotRegex((BASE_DIR / "docs" / nome).read_text(encoding="utf-8"), r"C:\\Users", nome)

    def test_manuais_usam_os_nomes_do_menu_atual(self):
        for nome in ("MANUAL_DO_USUARIO.md", "PRIMEIROS_PASSOS_ADMINISTRADOR.md"):
            texto = (BASE_DIR / "docs" / nome).read_text(encoding="utf-8")
            self.assertNotIn("Capacidade e Limites", texto, nome)
            self.assertIn("Capacidade Financeira", texto, nome)
        guia = (BASE_DIR / "docs" / "PRIMEIROS_PASSOS_ADMINISTRADOR.md").read_text(encoding="utf-8")
        self.assertIn("**Compras › Fornecedores**", guia)
        self.assertIn("Aprovadas aguardando", guia)

    def test_readme_manual_tem_collectstatic_e_aviso_de_https(self):
        readme = (BASE_DIR / "README.md").read_text(encoding="utf-8")
        self.assertIn("collectstatic --noinput", readme)
        self.assertIn("SECURE_SSL_REDIRECT=False", readme)

    def test_css_da_variacao_vence_a_regra_do_bootstrap(self):
        css = (BASE_DIR / "static" / "css" / "analise.css").read_text(encoding="utf-8")
        for classe in ("an-var-boa", "an-var-ruim", "an-var-neutra"):
            self.assertIn(f".nx-analise .table td.{classe}", css)
        nexbuy = (BASE_DIR / "static" / "css" / "nexbuy.css").read_text(encoding="utf-8")
        impressao = nexbuy.split("@media print", 1)[1]
        self.assertIn(".modal-backdrop", impressao)


# ---------------------------------------------------------------------------
# 9. Navegador real: cor computada e impressão com o tour aberto
# ---------------------------------------------------------------------------

_TEM_PLAYWRIGHT = importlib.util.find_spec("playwright") is not None

if _TEM_PLAYWRIGHT:
    from django.contrib.staticfiles.testing import StaticLiveServerTestCase
else:  # pragma: no cover - CI sem requirements-dev.txt
    StaticLiveServerTestCase = TestCase


@override_settings(ALLOWED_HOSTS=["*"], DEMO_MODE=False)
class NavegadorRealTestCase(StaticLiveServerTestCase):
    """Só roda onde o Playwright (requirements-dev.txt) está instalado com o
    Chromium; no GitHub Actions (só requirements.txt) é pulado — as
    garantias estáticas equivalentes ficam em DeployEDocumentacaoTestCase."""

    def setUp(self):
        if not _TEM_PLAYWRIGHT:
            self.skipTest("Playwright não instalado (requirements-dev.txt).")
        hoje = date.today()
        empresa = Empresa.objects.create(nome="Farmácia Navegador", cnpj="33.444.555/0001-81")
        filial = Filial.objects.create(empresa=empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(empresa=empresa, percentual_compras=Decimal("50"), dias_uteis_manual=20)
        anterior = _mes_anterior(hoje)
        Receita.objects.create(filial=filial, mes=anterior, faturamento=Decimal("100000.00"))
        Receita.objects.create(filial=filial, mes=hoje.replace(day=1), faturamento=Decimal("120000.00"))
        CustoFixo.objects.create(filial=filial, descricao="Folha", valor=Decimal("30000.00"), dia_vencimento=5)
        fornecedor = Fornecedor.objects.create(empresa=empresa, nome="Fornecedor Navegador")
        categoria = Categoria.objects.create(empresa=empresa, nome="Medicamentos")
        usuario = Usuario.objects.create_user(username="prop_nav", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
                                              empresa=empresa)
        UsuarioEmpresa.objects.get_or_create(usuario=usuario, empresa=empresa)
        for data, valor in ((anterior.replace(day=10), "5000.00"), (hoje.replace(day=1), "20000.00")):
            Compra.objects.create(empresa=empresa, filial=filial, fornecedor=fornecedor, usuario=usuario,
                                  valor=Decimal(valor), categoria=categoria, data_compra=data,
                                  status=Compra.Status.APROVADA)
        cliente = Client()
        cliente.force_login(usuario)
        self.sessao = cliente.cookies[settings.SESSION_COOKIE_NAME].value

    def test_cor_computada_da_variacao_e_fundo_do_tour_na_impressao(self):
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            try:
                navegador = p.chromium.launch()
            except Exception as exc:  # Chromium do Playwright não baixado
                self.skipTest(f"Chromium do Playwright indisponível: {exc}")
            try:
                contexto = navegador.new_context()
                contexto.add_cookies([{"name": settings.SESSION_COOKIE_NAME, "value": self.sessao,
                                       "url": self.live_server_url}])
                pagina = contexto.new_page()
                pagina.goto(self.live_server_url + "/financeiro/analise/")
                # Cor COMPUTADA da célula (não só a classe) = cor do token do
                # tema (--an-critico / --an-bom), medida num elemento de prova.
                cores = pagina.evaluate("""() => {
                    const raiz = document.querySelector('.nx-analise');
                    const token = (nome) => {
                        const prova = document.createElement('span');
                        prova.style.color = 'var(' + nome + ')';
                        raiz.appendChild(prova);
                        const cor = getComputedStyle(prova).color;
                        prova.remove();
                        return cor;
                    };
                    const cor = (sel) => { const el = document.querySelector(sel); return el ? getComputedStyle(el).color : null; };
                    return {
                        ruim: cor('tr[data-an-linha="compras"] td.an-var-ruim'),
                        boa: cor('tr[data-an-linha="receita_total"] td.an-var-boa'),
                        critico: token('--an-critico'), bom: token('--an-bom'),
                    };
                }""")
                self.assertEqual(cores["ruim"], cores["critico"])
                self.assertEqual(cores["boa"], cores["bom"])
                self.assertNotEqual(cores["ruim"], "rgb(0, 0, 0)")
                self.assertNotEqual(cores["boa"], "rgb(0, 0, 0)")

                pagina.evaluate("() => document.querySelector('[data-nx-iniciar-tour]').click()")
                pagina.wait_for_selector(".modal-backdrop", state="attached")
                pagina.emulate_media(media="print")
                visivel = pagina.evaluate(
                    "() => [...document.querySelectorAll('.modal-backdrop')].some(e => getComputedStyle(e).display !== 'none')"
                )
                self.assertFalse(visivel, "o fundo do tour sairia na impressão")
            finally:
                navegador.close()


class AuditoriaAntesDepoisLegivelTestCase(CenarioRodadaFinal):
    """Ajuste final (produto-e-demo): o "Antes/Depois" da Central de
    Auditoria (Cena 7 da demonstração) imprimia o dict Python cru, com o
    literal "None" na tela (`{'valor_maximo': None}` do fluxo de aprovação
    do seed). Agora: uma linha por campo, vazio "—", booleano sim/não."""

    def test_antes_depois_sem_none_nem_dict_cru(self):
        from auditoria.models import RegistroAuditoria
        from auditoria.services import registrar_evento
        from core.templatetags.core_extras import estado_auditoria

        self.assertEqual(estado_auditoria(None), "—")
        self.assertEqual(estado_auditoria({}), "—")
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.FILIAL_EDITADA, descricao="Fluxo de aprovação alterado",
            empresa=self.empresa, usuario=self.proprietario,
            estado_antes={"ativo": True, "etapas": []},
            estado_depois={"ativo": False, "etapas": [{"ordem": 2, "perfil_aprovador": "financeiro", "valor_maximo": None}]},
        )
        html = self.cliente(self.proprietario).get("/ncc/central-auditoria/").content.decode()
        detalhe = html.split(">Antes</div>", 1)[1].split("</tr>", 1)[0]
        self.assertNotIn("None", detalhe)
        self.assertNotIn("{'", detalhe)
        self.assertIn("ativo: sim\netapas: —", detalhe)
        self.assertIn("ativo: não\netapas: [{ordem: 2, perfil_aprovador: financeiro, valor_maximo: —}]", detalhe)
