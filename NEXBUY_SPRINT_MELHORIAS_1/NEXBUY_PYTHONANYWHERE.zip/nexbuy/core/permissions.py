"""Controle de acesso por perfil de usuário, usado nas views de todos os apps."""
from functools import wraps

from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied

from usuarios.models import Usuario

# Grupos de perfis reutilizados por mais de um app (Sprint 4.1, auditoria —
# antes definidos de forma idêntica e independente em `compras/views.py`,
# `cadastros/views.py` e `financeiro/views.py`). Centralizados aqui para que
# cada app importe em vez de redeclarar a mesma tupla.
TODOS_OS_PERFIS = (
    Usuario.Perfil.PROPRIETARIO,
    Usuario.Perfil.GERENTE,
    Usuario.Perfil.FINANCEIRO,
    Usuario.Perfil.COMPRADOR,
)

PERFIS_GESTORES_FINANCEIROS = (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO)

PERFIS_APROVADORES_PROVISAO = (
    Usuario.Perfil.PROPRIETARIO,
    Usuario.Perfil.GERENTE,
    Usuario.Perfil.FINANCEIRO,
)

# Análise Financeira (DRE Gerencial, Créditos × Débitos e Saúde Financeira):
# decisão da cliente na mudança de escopo — Proprietário, Gerente e
# Financeiro. O Comprador NUNCA acessa (nem menu, nem dashboard, nem tour).
# Gate por perfil (`perfil_required`) nas views e `perfis=` no menu.
PERFIS_ANALISE_FINANCEIRA = (
    Usuario.Perfil.PROPRIETARIO,
    Usuario.Perfil.GERENTE,
    Usuario.Perfil.FINANCEIRO,
)

# ---------------------------------------------------------------------------
# Motor de Permissões — RBAC (Épico 7, CORE 1.0)
#
# Fonte única do catálogo de permissões e do mapeamento dos 4 perfis
# legados. O motor é ADITIVO: um usuário sem nenhum PerfilAcesso/permissão
# individual atribuído tem exatamente os acessos que o perfil legado sempre
# deu; atribuições explícitas só SOMAM acessos, nunca subtraem — o que
# garante que todo comportamento (e teste) anterior permaneça idêntico.
# ---------------------------------------------------------------------------

# (codigo, nome, perfis legados que já possuem esta permissão)
CATALOGO_PERMISSOES = (
    ("dashboard.ver", "Ver o Dashboard", TODOS_OS_PERFIS),
    # Gate A (Prompt 2, pré-Etapa 02): o Proprietário Operacional é um ator
    # real da operação, não só um aprovador — ele lança Compra e cria
    # Provisão como qualquer Comprador faria, além de poder decidir. A
    # separação de funções (não aprovar a própria solicitação) continua
    # garantida por `autoaprovacao_controlada_permitida` nos services, não
    # pelo RBAC de tela.
    ("compras.lancar", "Lançar Compra", (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.COMPRADOR)),
    ("compras.ver", "Ver Compras", TODOS_OS_PERFIS),
    ("compras.aprovar", "Aprovar/Rejeitar Compras", (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.GERENTE)),
    ("compras.simular", "Usar o Simulador de Compra", (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO, Usuario.Perfil.COMPRADOR)),
    ("provisoes.criar", "Criar Provisões", (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.COMPRADOR)),
    ("provisoes.aprovar", "Decidir Aprovações de Provisão", PERFIS_APROVADORES_PROVISAO),
    # Sprint de Correções Críticas (Seção 12) — transformar uma Provisão
    # aprovada num compromisso real (Compra). Mesmos perfis que decidem a
    # aprovação: quem pode aprovar o gasto também pode confirmar que ele
    # de fato aconteceu.
    ("provisoes.efetivar", "Efetivar Provisão em Compra", PERFIS_APROVADORES_PROVISAO),
    ("calendario.ver", "Ver o Calendário Inteligente", (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.COMPRADOR)),
    ("calendario.configurar", "Configurar o Calendário Operacional", PERFIS_GESTORES_FINANCEIROS),
    ("agenda.ver", "Ver a Agenda Financeira", PERFIS_GESTORES_FINANCEIROS),
    ("agenda.baixar_parcela", "Marcar parcela como paga", PERFIS_GESTORES_FINANCEIROS),
    ("financeiro.ver", "Ver dados financeiros", PERFIS_GESTORES_FINANCEIROS),
    # RC do Épico 01 (Correção 01): a Timeline Financeira expõe o day-walk
    # completo do Motor (limites, redistribuições, transferências) — dados
    # do planejamento, restritos aos perfis gestores. O RBAC aditivo segue
    # valendo: um Comprador específico pode receber a permissão.
    ("timeline.ver", "Ver a Timeline Financeira", PERFIS_APROVADORES_PROVISAO),
    # RC do Épico 01 (Correção 03): a capacidade pertence ao Financeiro —
    # distribuir limite entre compradores, bloquear/liberar comprador.
    ("capacidade.gerenciar", "Gerir Compradores e Limites", PERFIS_GESTORES_FINANCEIROS),
    # Gate A: Proprietário também visualiza e cadastra Receita/Custo Fixo/
    # Custo Variável — não é exclusivo do Financeiro.
    ("financeiro.cadastrar", "Cadastrar Receitas e Custos", (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO)),
    ("cadastros.gerenciar", "Gerenciar Fornecedores, Categorias e Centros de Custo", PERFIS_GESTORES_FINANCEIROS),
    ("configuracoes.gerenciar", "Acessar a Central de Configurações", PERFIS_GESTORES_FINANCEIROS),
    ("empresa.gerenciar", "Editar Empresa e Identidade Visual", (Usuario.Perfil.PROPRIETARIO,)),
    # Sprint de Correções Críticas (Seção 6) — cadastro/edição/ativação de
    # Filial, distinto de "empresa.gerenciar" (que edita a Empresa em si).
    ("filiais.gerenciar", "Cadastrar e Gerenciar Filiais", (Usuario.Perfil.PROPRIETARIO,)),
    ("workflow.configurar", "Configurar Fluxos de Aprovação", (Usuario.Perfil.PROPRIETARIO,)),
    ("ncc.acessar", "Acessar o NEXBUY Control Center", (Usuario.Perfil.PROPRIETARIO,)),
    ("notificacoes.ver", "Ver notificações", TODOS_OS_PERFIS),
    # Fechamento Final (Prompt 1, Seção 8) — Central de Auditoria: código
    # próprio (em vez de reaproveitar "ncc.acessar") para permitir delegar
    # só a auditoria, sem abrir o resto do Control Center.
    # Gate pré-Etapa 10 (S1-3, item 7): renomeado de "auditoria.visualizar"
    # para "auditoria.ver", conforme o Prompt 1 original — migration
    # `usuarios.0011_renomear_permissao_auditoria_ver` preserva qualquer
    # atribuição já feita ao código antigo (troca o `codigo` no MESMO
    # registro de `Permissao`, então o vínculo M2M com `PerfilAcesso`
    # nunca se perde).
    ("auditoria.ver", "Ver a Central de Auditoria", (Usuario.Perfil.PROPRIETARIO,)),
    # Gate B (Prompt 2, Seção 5): estava totalmente ausente do catálogo —
    # a Central de Relatórios (`core/views.py::relatorios_home`) não tinha
    # nenhum gate de permissão, então concede a todos os 4 perfis, exatamente
    # o acesso que a tela já dava a todo usuário autenticado (nenhum perfil
    # perde acesso que já tinha).
    ("relatorios.ver", "Acessar a Central de Relatórios", TODOS_OS_PERFIS),
)

# {perfil: frozenset(codigos)} — resolvido em memória, sem consulta a banco.
_PERMISSOES_POR_PERFIL = {}
for _codigo, _nome, _perfis in CATALOGO_PERMISSOES:
    for _perfil in _perfis:
        _PERMISSOES_POR_PERFIL.setdefault(_perfil, set()).add(_codigo)


# ---------------------------------------------------------------------------
# Épico 2A (Etapa 03) — metadados de APRESENTAÇÃO do catálogo, para o painel
# visual de permissões. Estruturas ADITIVAS e separadas de propósito: a tupla
# `CATALOGO_PERMISSOES` (fonte do RBAC e das migrations) permanece intacta.
# ---------------------------------------------------------------------------

# Grupos exibidos na gestão de usuários — (grupo, prefixos/códigos que o compõem).
GRUPOS_PERMISSOES = (
    ("Compras", ("compras.", "provisoes.", "calendario.ver")),
    ("Financeiro", ("financeiro.", "agenda.", "capacidade.", "calendario.configurar")),
    ("Relatórios", ("timeline.",)),
    ("Cadastros", ("cadastros.",)),
    ("Administração", ("empresa.", "filiais.", "workflow.", "ncc.")),
    ("Auditoria", ("auditoria.",)),
    ("Sistema", ("dashboard.", "notificacoes.")),
)

# O que cada permissão FAZ, em linguagem de negócio (exibido no painel).
DESCRICOES_PERMISSOES = {
    "dashboard.ver": "Permite abrir o painel inicial do seu perfil.",
    "compras.lancar": "Permite lançar novas compras para a filial.",
    "compras.ver": "Permite visualizar o histórico de compras autorizado ao perfil.",
    "compras.aprovar": "Permite aprovar ou rejeitar compras acima do limite.",
    "compras.simular": "Permite usar o simulador \"e se eu comprasse X no dia Y?\".",
    "provisoes.criar": "Permite planejar compras futuras (provisões) no calendário.",
    "provisoes.aprovar": "Permite decidir solicitações de aprovação de provisões.",
    "provisoes.efetivar": "Permite transformar uma Provisão aprovada numa Compra real (compromisso financeiro).",
    "calendario.ver": "Permite abrir o Calendário Inteligente do comprador.",
    "calendario.configurar": "Permite bloquear dias e criar exceções no Calendário Operacional.",
    "agenda.ver": "Permite visualizar a Agenda Financeira (pagamentos e vencimentos).",
    "agenda.baixar_parcela": "Permite marcar parcelas como pagas na Agenda.",
    "financeiro.ver": "Permite visualizar indicadores e dados financeiros completos.",
    "financeiro.cadastrar": "Permite cadastrar receitas, custos fixos e variáveis.",
    "timeline.ver": "Permite visualizar a Timeline Financeira completa do Motor.",
    "capacidade.gerenciar": "Permite redistribuir capacidade, definir limites e bloquear/liberar compradores.",
    "cadastros.gerenciar": "Permite gerenciar fornecedores, categorias e centros de custo.",
    "configuracoes.gerenciar": "Permite acessar as telas de configuração do dia a dia.",
    "empresa.gerenciar": "Permite editar os dados da empresa e a identidade visual.",
    "filiais.gerenciar": "Permite cadastrar, editar, ativar e desativar filiais da empresa ativa.",
    "workflow.configurar": "Permite configurar fluxos de aprovação, alçadas e prazos.",
    "ncc.acessar": "Permite abrir o Centro de Configurações (parametrização completa).",
    "notificacoes.ver": "Permite receber e abrir as notificações do sistema.",
    "auditoria.ver": "Permite abrir a Central de Auditoria (segurança, configuração, compras e provisões).",
}


def grupo_da_permissao(codigo: str) -> str:
    """Grupo de exibição de um código de permissão (Etapa 03)."""
    for grupo, prefixos in GRUPOS_PERMISSOES:
        for prefixo in prefixos:
            if codigo == prefixo or codigo.startswith(prefixo):
                return grupo
    return "Sistema"


def permissoes_do_perfil_legado(perfil) -> frozenset:
    return frozenset(_PERMISSOES_POR_PERFIL.get(perfil, ()))


def usuario_tem_permissao(usuario, codigo: str) -> bool:
    """Checagem central do RBAC: perfil legado (em memória, caminho rápido)
    OU qualquer PerfilAcesso/permissão individual atribuídos (banco)."""
    if usuario is None or not getattr(usuario, "is_authenticated", False):
        return False
    if usuario.is_superuser:
        return True
    if codigo in _PERMISSOES_POR_PERFIL.get(usuario.perfil, ()):
        return True
    if not usuario.pk:
        return False
    return (
        usuario.permissoes_individuais.filter(codigo=codigo).exists()
        or usuario.perfis_acesso.filter(permissoes__codigo=codigo).exists()
    )


def permissoes_do_usuario(usuario) -> set:
    """Conjunto completo de códigos de permissão de um usuário — perfil
    legado + perfis de acesso + individuais. Usado nas telas de gestão."""
    if usuario is None or not getattr(usuario, "is_authenticated", False):
        return set()
    codigos = set(_PERMISSOES_POR_PERFIL.get(usuario.perfil, ()))
    if usuario.pk:
        codigos.update(usuario.permissoes_individuais.values_list("codigo", flat=True))
        codigos.update(usuario.perfis_acesso.values_list("permissoes__codigo", flat=True))
    codigos.discard(None)
    return codigos


def autoaprovacao_controlada_permitida(empresa) -> bool:
    """Fechamento Final (Prompt 1, Seção 6): por padrão, quem CRIA uma
    Provisão ou Compra nunca pode APROVAR a própria solicitação — nem
    sendo Gerente, Proprietário ou superusuário (separação de funções).
    Só quando a empresa liga explicitamente "autoaprovação controlada"
    (`ConfiguracaoPlataforma.permitir_autoaprovacao`, com justificativa
    obrigatória) essa regra é suspensa. Import tardio de propósito — este
    módulo (`core`) nunca importa models de app específico no topo do
    arquivo, para não criar dependência circular."""
    from empresas.models import ConfiguracaoPlataforma

    if empresa is None:
        return False
    config = ConfiguracaoPlataforma.objects.filter(empresa=empresa).first()
    return bool(config and config.permitir_autoaprovacao)


def permissao_required(codigo: str):
    """Decorator de view por permissão do catálogo (RBAC) — o equivalente
    granular do `perfil_required`, usado nas telas novas do CORE 1.0."""

    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped(request, *args, **kwargs):
            if not usuario_tem_permissao(request.user, codigo):
                raise PermissionDenied("Você não tem permissão para acessar esta página.")
            return view_func(request, *args, **kwargs)

        return _wrapped

    return decorator


def perfil_required(*perfis_permitidos):
    """Decorator para views baseadas em função: restringe acesso por perfil."""

    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped(request, *args, **kwargs):
            if request.user.perfil not in perfis_permitidos:
                raise PermissionDenied("Você não tem permissão para acessar esta página.")
            return view_func(request, *args, **kwargs)

        return _wrapped

    return decorator


class PerfilRequiredMixin(LoginRequiredMixin):
    """Mixin para Class Based Views: restringe acesso por perfil."""

    perfis_permitidos = ()

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return self.handle_no_permission()
        if self.perfis_permitidos and request.user.perfil not in self.perfis_permitidos:
            raise PermissionDenied("Você não tem permissão para acessar esta página.")
        return super().dispatch(request, *args, **kwargs)
