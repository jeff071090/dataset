from django import forms


class BootstrapFormMixin:
    """Aplica classes do Bootstrap 5 automaticamente aos campos do formulário."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs.setdefault("class", "form-check-input")
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                widget.attrs.setdefault("class", "form-select")
            else:
                widget.attrs.setdefault("class", "form-control")


class MoedaFormMixin:
    """Aplica máscara e localização brasileira (ex.: "1.234,56") aos campos
    monetários listados em `campos_moeda` (Sprint 6, item 1).

    Só os campos explicitamente listados são afetados — de propósito, não
    qualquer `DecimalField` do form, porque nem todo `DecimalField` é
    dinheiro (percentuais em `ConfiguracaoFinanceira`, quantidade em
    `ItemProvisao`, etc. não devem ganhar máscara nem prefixo "R$").

    `localize=True` faz o Django aceitar de volta, na hora de validar, o
    texto que a máscara em `static/js/nexbuy.js` produz (`data-nx-moeda`) —
    mesma formatação usada por `{{ valor|floatformat:2 }}` nos templates
    (`USE_THOUSAND_SEPARATOR`, em `settings.py`) e por
    `core.utils.formatar_moeda` nas mensagens. Um único padrão em Banco,
    Models, Forms, Templates, JS e Mensagens."""

    campos_moeda = ()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nome in self.campos_moeda:
            field = self.fields.get(nome)
            if field is None:
                continue
            field.localize = True
            field.widget = forms.TextInput(
                attrs={
                    "class": "form-control nx-money-input",
                    "inputmode": "decimal",
                    "autocomplete": "off",
                    "data-nx-moeda": "true",
                }
            )


class PerfilProprioForm(BootstrapFormMixin, forms.ModelForm):
    """Página "Meu Perfil" (Épico 2A): o que o PRÓPRIO usuário edita —
    apresentação e contato. Perfil de acesso, empresa, filial e permissões
    são gestão do Centro de Configurações, nunca do próprio usuário."""

    class Meta:
        # Import tardio proposital: `core.forms` é importado por forms de
        # vários apps — resolver o model aqui evita qualquer ordem de
        # import infeliz durante o carregamento das apps.
        from usuarios.models import Usuario as _Usuario

        model = _Usuario
        fields = ["first_name", "last_name", "email", "foto"]
        labels = {"first_name": "Nome", "last_name": "Sobrenome", "email": "E-mail", "foto": "Foto"}
