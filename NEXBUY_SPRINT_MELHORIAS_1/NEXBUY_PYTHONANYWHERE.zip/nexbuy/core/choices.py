"""Listas de opções (`choices`) reaproveitadas por mais de um app.

Centralizadas aqui para não duplicar a mesma lista em cada model que
precisa dela (Sprint 6 — `empresas.Empresa` passou a precisar do mesmo
`UF_CHOICES` que `compras.Fornecedor` já usava desde a Etapa 2)."""

UF_CHOICES = [
    ("", "---------"),
    ("AC", "AC"), ("AL", "AL"), ("AP", "AP"), ("AM", "AM"), ("BA", "BA"), ("CE", "CE"),
    ("DF", "DF"), ("ES", "ES"), ("GO", "GO"), ("MA", "MA"), ("MT", "MT"), ("MS", "MS"),
    ("MG", "MG"), ("PA", "PA"), ("PB", "PB"), ("PR", "PR"), ("PE", "PE"), ("PI", "PI"),
    ("RJ", "RJ"), ("RN", "RN"), ("RS", "RS"), ("RO", "RO"), ("RR", "RR"), ("SC", "SC"),
    ("SP", "SP"), ("SE", "SE"), ("TO", "TO"),
]
