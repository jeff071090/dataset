"""Pacote de Demonstração Comercial (Etapa 02; Gate Final V2) — prova
programática, EXECUTÁVEL DE DENTRO DO PRÓPRIO ZIP DE DEMO, de que:

1. Os launchers de demonstração isolada passam
   `--settings=nexbuy.settings_demo` em TODA chamada de `manage.py`.
2. Nenhum `.bat` de demo contém uma referência de ESCRITA a `db.sqlite3`.
3. `nexbuy/settings_demo.py` realmente aponta banco/mídia para os arquivos
   de demo, nunca os principais, e não força `DEMO_MODE` (o launcher
   decide: `False` no cenário limpo, `True` no pronto).
4. O guia e o roteiro referenciam os launchers corretos e nunca instruem
   token na URL.

Este arquivo só depende de arquivos presentes no PACOTE DE DEMO (os 3
`.bat`, `nexbuy/settings_demo.py`, guia e roteiro) — por isso é
empacotado no ZIP de demo e roda de verdade lá dentro (Gate Final V2,
Bloqueador de contagem de testes). As garantias sobre o README de cada
pacote moram em `core/tests_readme_instalacao.py` (empacotável nos dois
ZIPs); a consistência entre os DOIS READMEs (que nunca coexistem dentro de
um pacote) mora em `core/tests_readme_cliente_ready.py` (árvore de
trabalho apenas).
"""
from pathlib import Path

from django.conf import settings
from django.test import SimpleTestCase

BASE_DIR = Path(settings.BASE_DIR)

# .bat de demo que precisam de --settings=nexbuy.settings_demo em toda
# chamada de manage.py. `resetar_demo_cliente_limpa.bat` também chama
# manage.py (migrate, no final) e precisa da mesma garantia.
LAUNCHERS_DEMO = [
    "iniciar_demo_cliente_limpa.bat",
    "iniciar_demo_cenario_pronto.bat",
    "resetar_demo_cliente_limpa.bat",
]

SETTINGS_DEMO_FLAG = "--settings=nexbuy.settings_demo"

# Palavras que, combinadas com "db.sqlite3" na mesma linha, indicariam uma
# referência de ESCRITA (apagar/sobrescrever/redirecionar) — não apenas uma
# menção informativa em echo/REM.
PALAVRAS_ESCRITA = ("del ", "erase ", "copy ", "move ", "ren ", "rd ", "rmdir", ">", ">>")


def _ler(nome_arquivo: str) -> str:
    caminho = BASE_DIR / nome_arquivo
    return caminho.read_text(encoding="utf-8")


class LauncherDemoSettingsTestCase(SimpleTestCase):
    """Todo launcher de demo precisa isolar 100% do banco/mídia principal —
    a garantia mecânica disso é `--settings=nexbuy.settings_demo` em toda
    chamada de `manage.py`."""

    def test_launchers_existem(self):
        for nome_arquivo in LAUNCHERS_DEMO:
            caminho = BASE_DIR / nome_arquivo
            self.assertTrue(caminho.exists(), f"{nome_arquivo} não existe")

    def test_toda_chamada_manage_py_usa_settings_demo(self):
        for nome_arquivo in LAUNCHERS_DEMO:
            texto = _ler(nome_arquivo)
            linhas_manage = [
                linha for linha in texto.splitlines()
                if "manage.py" in linha and not linha.strip().upper().startswith("REM")
            ]
            self.assertTrue(linhas_manage, f"{nome_arquivo}: nenhuma chamada a manage.py encontrada")
            for linha in linhas_manage:
                self.assertIn(
                    SETTINGS_DEMO_FLAG, linha,
                    f"{nome_arquivo}: chamada a manage.py sem {SETTINGS_DEMO_FLAG} -> {linha!r}",
                )

    def test_nenhum_bat_de_demo_tem_referencia_de_escrita_a_db_sqlite3(self):
        for nome_arquivo in LAUNCHERS_DEMO:
            texto = _ler(nome_arquivo)
            for numero_linha, linha in enumerate(texto.splitlines(), start=1):
                if "db.sqlite3" not in linha.lower():
                    continue
                linha_normalizada = linha.strip().lower()
                # Linhas puramente informativas (echo/REM) podem mencionar
                # "db.sqlite3" como texto (ex.: "nunca toca em db.sqlite3");
                # o que não pode existir é um COMANDO de escrita na mesma
                # linha (del/copy/move/ren/rd/rmdir/redirecionamento).
                eh_informativa = linha_normalizada.startswith("echo") or linha_normalizada.startswith("rem")
                tem_palavra_escrita = any(p in linha_normalizada for p in PALAVRAS_ESCRITA)
                if tem_palavra_escrita and not eh_informativa:
                    self.fail(
                        f"{nome_arquivo}:{numero_linha}: referência de escrita a db.sqlite3 -> {linha!r}"
                    )

    def test_launchers_nunca_ligam_debug_para_producao_no_arquivo_env(self):
        """DEBUG=True nos launchers é sempre `set DEBUG=True` (variável de
        ambiente do processo), nunca uma escrita em `.env` — confirma que
        nenhum launcher usa `echo`/redirecionamento para gravar DEBUG (ou
        qualquer outra variável) dentro de um arquivo `.env`."""
        for nome_arquivo in LAUNCHERS_DEMO:
            texto = _ler(nome_arquivo)
            self.assertNotRegex(
                texto, r">>?\s*\.env\b",
                f"{nome_arquivo}: não pode gravar nada em .env",
            )


class SettingsDemoIsolamentoTestCase(SimpleTestCase):
    """Importa o módulo `nexbuy.settings_demo` de verdade (não só lê o texto
    do arquivo) e confirma que o banco/mídia realmente apontam para os
    nomes de demo, nunca para os do ambiente principal."""

    def test_database_name_e_arquivo_de_demo_nunca_db_sqlite3(self):
        """A garantia real: o banco da demo é `db_demo_cliente.sqlite3`,
        nunca `db.sqlite3`.

        Microsprint V4 (Seção 12.6): a suíte agora TAMBÉM roda com
        `--settings=nexbuy.settings_demo`. Nesse modo, o test runner do
        Django troca legitimamente o NAME ativo pelo banco DE TESTE
        (ex.: `file:memorydb_...`) — comparar o atributo do módulo com o
        nome de arquivo da demo só é válido quando `settings_demo` NÃO é
        o settings ativo do runner. A intenção original fica preservada e
        REFORÇADA: (a) em qualquer modo, o nome configurado JAMAIS é
        `db.sqlite3` e (b) a linha-fonte do módulo aponta explicitamente
        para `db_demo_cliente.sqlite3` (verificação no código, imune ao
        override de teste)."""
        import importlib
        import inspect

        settings_demo = importlib.import_module("nexbuy.settings_demo")

        nome_banco = str(settings_demo.DATABASES["default"]["NAME"])
        self.assertNotEqual(Path(nome_banco).name, "db.sqlite3")

        # Reforço no CÓDIGO-FONTE (imune a qualquer override do runner):
        fonte = inspect.getsource(settings_demo)
        self.assertIn('DATABASES["default"]["NAME"] = BASE_DIR / "db_demo_cliente.sqlite3"', fonte)

        # Em runtime, o NAME é o arquivo da demo — ou, quando o runner de
        # teste do Django já criou os bancos de teste (caso da suíte
        # completa com --settings=nexbuy.settings_demo), um banco DE TESTE
        # reconhecível. Nunca qualquer outro arquivo real.
        eh_nome_de_demo = Path(nome_banco).name == "db_demo_cliente.sqlite3"
        eh_banco_de_teste = (
            nome_banco == ":memory:"
            or nome_banco.startswith("file:memorydb")
            or Path(nome_banco).name.startswith("test_")
        )
        self.assertTrue(
            eh_nome_de_demo or eh_banco_de_teste,
            f"NAME inesperado: {nome_banco}",
        )

    def test_media_root_e_pasta_de_demo_nunca_media(self):
        import importlib

        settings_demo = importlib.import_module("nexbuy.settings_demo")

        nome_pasta = Path(str(settings_demo.MEDIA_ROOT)).name
        self.assertNotEqual(nome_pasta, "media")
        self.assertEqual(nome_pasta, "media_demo_cliente")

    def test_demo_mode_vem_do_launcher_nao_e_forcado_no_settings(self):
        """Gate Final V2 (Bloqueador P1): `settings_demo` NÃO pode forçar
        `DEMO_MODE=True` — o cenário limpo/guiado reproduz a experiência
        cliente-ready, sem badge. Quem decide é o launcher, via variável de
        ambiente (`set DEMO_MODE=False` no limpo, `True` no pronto). O
        texto do módulo não pode conter um `DEMO_MODE = True` forçado."""
        from pathlib import Path as _P

        codigo = ( _P(settings.BASE_DIR) / "nexbuy" / "settings_demo.py").read_text(encoding="utf-8")
        import re as _re

        self.assertIsNone(
            _re.search(r"^DEMO_MODE\s*=\s*True\s*$", codigo, _re.M),
            "settings_demo.py não pode forçar DEMO_MODE=True — o launcher decide.",
        )

    def test_launcher_limpo_define_demo_mode_false_e_pronto_define_true(self):
        texto_limpo = _ler("iniciar_demo_cliente_limpa.bat")
        texto_pronto = _ler("iniciar_demo_cenario_pronto.bat")
        self.assertIn("set DEMO_MODE=False", texto_limpo)
        self.assertIn("set DEMO_MODE=True", texto_pronto)

    def test_allowed_hosts_restrito_a_loopback(self):
        import importlib

        settings_demo = importlib.import_module("nexbuy.settings_demo")

        self.assertEqual(set(settings_demo.ALLOWED_HOSTS), {"127.0.0.1", "localhost"})

    def test_database_options_preservadas_do_settings_principal(self):
        """O override troca só o NAME — OPTIONS (transaction_mode
        IMMEDIATE, usado para locking real no SQLite) precisa continuar
        vindo do settings.py principal, sem duplicar a lógica."""
        import importlib

        settings_demo = importlib.import_module("nexbuy.settings_demo")
        settings_principal = importlib.import_module("nexbuy.settings")

        self.assertEqual(
            settings_demo.DATABASES["default"].get("OPTIONS"),
            settings_principal.DATABASES["default"].get("OPTIONS"),
        )


class GuiaDemoDocumentacaoTestCase(SimpleTestCase):
    """Os dois documentos de demonstração (roteiro e guia técnico)
    precisam existir e referenciar os launchers corretos."""

    def test_guia_demo_cliente_existe_e_referencia_os_tres_launchers(self):
        texto = _ler("NEXBUY_GUIA_DEMO_CLIENTE.md")
        for nome_arquivo in LAUNCHERS_DEMO:
            self.assertIn(nome_arquivo, texto)

    def test_roteiro_demo_tem_dois_roteiros_e_nao_referencia_token_na_url(self):
        texto = _ler("NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md")
        self.assertIn("Roteiro A", texto)
        self.assertIn("Roteiro B", texto)
        self.assertIn("iniciar_demo_cliente_limpa.bat", texto)
        self.assertIn("iniciar_demo_cenario_pronto.bat", texto)
        # O novo mecanismo de Primeiro Acesso nunca aceita o token pela URL.
        # O roteiro PODE mencionar "?token=" só para dizer que isso nunca
        # deve ser feito (ex.: "nunca aceita `?token=...`") — o que não pode
        # existir é uma instrução de acesso real como
        # ".../primeiro-acesso/?token=<valor>".
        self.assertNotRegex(texto, r"primeiro-acesso/\?token=")
        self.assertIn("digite", texto.lower())
