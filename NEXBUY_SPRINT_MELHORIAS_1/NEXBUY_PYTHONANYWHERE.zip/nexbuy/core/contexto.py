"""Contexto por Empresa (Épico 9 — CORE 1.0).

O usuário autenticado trabalha sempre com UMA empresa ativa por vez — por
padrão a empresa principal do cadastro dele (`Usuario.empresa`, o
comportamento histórico), podendo alternar para qualquer empresa em que
tenha autorização explícita (`UsuarioEmpresa` ativa), sem novo login.

A escolha vive na sessão; a resolução é sempre validada contra
`Usuario.empresas_disponiveis()` — uma empresa não autorizada gravada na
sessão (ex.: autorização revogada depois da troca) é ignorada e o
contexto volta com segurança para a empresa principal.
"""
CHAVE_SESSAO_EMPRESA = "empresa_ativa_id"


def empresa_ativa(request):
    """Empresa ativa do request — a selecionada na sessão (se autorizada)
    ou a empresa principal do usuário. Cacheada no próprio request para
    custar no máximo 1 consulta por requisição."""
    if not hasattr(request, "user") or not request.user.is_authenticated:
        return None
    if hasattr(request, "_empresa_ativa_cache"):
        return request._empresa_ativa_cache

    empresa = request.user.empresa
    empresa_id = request.session.get(CHAVE_SESSAO_EMPRESA)
    if empresa_id and (empresa is None or empresa_id != empresa.pk):
        autorizada = request.user.empresas_disponiveis().filter(pk=empresa_id).first()
        if autorizada is not None:
            empresa = autorizada
        else:
            # Autorização não existe mais — limpa a escolha antiga.
            request.session.pop(CHAVE_SESSAO_EMPRESA, None)

    request._empresa_ativa_cache = empresa
    return empresa


def definir_empresa_ativa(request, empresa) -> bool:
    """Troca o contexto ativo (sem novo login). Só aceita empresa em que o
    usuário tem acesso; devolve True quando a troca foi aplicada."""
    if empresa is None or not request.user.is_authenticated:
        return False
    if not request.user.empresas_disponiveis().filter(pk=empresa.pk).exists():
        return False
    request.session[CHAVE_SESSAO_EMPRESA] = empresa.pk
    if hasattr(request, "_empresa_ativa_cache"):
        del request._empresa_ativa_cache
    return True


def filiais_do_contexto(request):
    """Filiais visíveis DENTRO da empresa ativa — o complemento de
    `Usuario.filiais_visiveis()` para telas sensíveis ao contexto."""
    empresa = empresa_ativa(request)
    if empresa is None:
        return request.user.filiais_visiveis()
    return request.user.filiais_visiveis(empresa=empresa)
