"""Validação do README presente NO PRÓPRIO pacote (Gate Final V2).

Este arquivo é EMPACOTÁVEL nos dois ZIPs (cliente-ready e demo): ele só
depende de `README.md` — que existe nos dois pacotes (no cliente-ready, é
a versão dedicada ao cliente; no demo e na árvore de trabalho, a versão
completa). As garantias abaixo valem para QUALQUER uma das versões:

1. a seção de instalação cliente-ready nunca instrui `seed_dados` nem
   `seed_demo`;
2. exige Python 3.12+ (nunca 3.11);
3. contém o alerta explícito de que o banco cliente-ready nunca deve
   receber dados de teste/demonstração.

Os testes que dependem de os DOIS arquivos de README coexistirem
(`README.md` completo + `README_CLIENTE_READY.md`) moram em
`core/tests_readme_cliente_ready.py`, que fica só na árvore de trabalho —
nunca dentro de um ZIP (nenhum pacote contém os dois arquivos ao mesmo
tempo, então esses testes não são executáveis de dentro de um pacote)."""
from pathlib import Path

from django.conf import settings
from django.test import SimpleTestCase

BASE_DIR = Path(settings.BASE_DIR)


def _secao_instalacao(texto: str) -> str:
    inicio = texto.index("## Instalação (cliente-ready)")
    candidatos = []
    for marcador in ("## Desenvolvimento interno", "## Preparação para nuvem"):
        pos = texto.find(marcador, inicio)
        if pos != -1:
            candidatos.append(pos)
    fim = min(candidatos) if candidatos else len(texto)
    return texto[inicio:fim]


class ReadmeInstalacaoTestCase(SimpleTestCase):
    def _texto(self):
        return (BASE_DIR / "README.md").read_text(encoding="utf-8")

    def test_secao_instalacao_nao_instrui_seed(self):
        secao = _secao_instalacao(self._texto())
        self.assertNotIn("seed_dados", secao)
        self.assertNotIn("seed_demo", secao)

    def test_exige_python_312(self):
        texto = self._texto()
        self.assertIn("3.12", _secao_instalacao(texto))
        self.assertNotIn("3.11", texto)

    def test_alerta_banco_cliente_ready_nunca_recebe_seed(self):
        self.assertIn("NUNCA deve receber", self._texto())
