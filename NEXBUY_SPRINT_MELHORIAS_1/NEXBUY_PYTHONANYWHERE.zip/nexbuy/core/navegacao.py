"""Navegação V4 — fonte única de verdade (Microsprint de Navegação, Etapa 02).

Este módulo é a ESTRUTURA DECLARATIVA de toda a navegação autenticada:
sidebar agrupada por tarefa, estado ativo, breadcrumbs e barra inferior
mobile. Nenhum template decide mais "quem vê o quê" — tudo nasce aqui e é
testável em Python puro (`core/tests_navegacao_v4.py`).

Regra de ouro (Seção 5 do microsprint): um item só aparece se o usuário
passar pelo MESMO gate que a view de destino usa —
- views com `@permissao_required("x.y")` → item com `permissao="x.y"`
  (o RBAC aditivo funciona: permissão concedida = item aparece);
- views com `@perfil_required(...)`/`PerfilRequiredMixin` → item com
  `perfis=(...)` idênticos aos da view (RBAC não adiciona acesso a essas
  views, então o menu tampouco pode adicionar o link).
Assim é impossível renderizar um link que resulte em 403.
"""
from core.permissions import PERFIS_ANALISE_FINANCEIRA, permissoes_do_usuario

PROPRIETARIO = "proprietario"
GERENTE = "gerente"
FINANCEIRO = "financeiro"
COMPRADOR = "comprador"


def _item(id, rotulo, url_name, icone="", permissao=None, perfis=None,
          rotas=(), prefixos=(), title=None):
    return {
        "id": id, "rotulo": rotulo, "url_name": url_name, "icone": icone,
        "permissao": permissao, "perfis": perfis,
        "rotas": (url_name,) + tuple(rotas), "prefixos": tuple(prefixos),
        "title": title or rotulo,
    }


def _grupo(id, rotulo, icone, itens, rotas_grupo=(), prefixos_grupo=()):
    return {
        "id": id, "rotulo": rotulo, "icone": icone, "itens": itens,
        "link_unico": False,
        "rotas_grupo": tuple(rotas_grupo), "prefixos_grupo": tuple(prefixos_grupo),
    }


def _link(id, rotulo, url_name, icone, permissao=None, perfis=None,
          rotas=(), prefixos=(), title=None):
    d = _item(id, rotulo, url_name, icone, permissao, perfis, rotas, prefixos, title)
    d["link_unico"] = True
    return d


# ---------------------------------------------------------------------------
# Blocos reutilizados entre perfis
# ---------------------------------------------------------------------------

_ROTAS_APROVACOES = (
    "compras:aprovacao", "compras:aprovar", "compras:rejeitar",
    "gestao_compras:aprovacao_list", "gestao_compras:aprovar",
    "gestao_compras:rejeitar", "gestao_compras:solicitar_ajustes",
)
_ROTAS_AGENDA = ("financeiro:baixar_parcela", "financeiro:estornar_parcela")
_ROTAS_CAPACIDADE = (
    "financeiro:capacidade_definir_limite", "financeiro:capacidade_bloquear",
    "financeiro:capacidade_liberar",
)
_ROTAS_RECEITAS = ("financeiro:receita_create", "financeiro:receita_update",
                   "financeiro:receita_excluir",
                   # Receitas extras vivem dentro do item "Receitas" (mesmo
                   # gate de perfil), sem item novo de menu.
                   "financeiro:receitaextra_list", "financeiro:receitaextra_create",
                   "financeiro:receitaextra_update", "financeiro:receitaextra_excluir")
_ROTAS_CUSTOS_FIXOS = ("financeiro:custofixo_create", "financeiro:custofixo_update",
                       "financeiro:custofixo_excluir", "financeiro:custofixo_reativar")
_ROTAS_CUSTOS_VARIAVEIS = ("financeiro:custovariavel_create",
                           "financeiro:custovariavel_update",
                           "financeiro:custovariavel_excluir")
_ROTAS_FORNECEDORES = ("compras:fornecedor_list", "compras:fornecedor_create",
                       "compras:fornecedor_update", "compras:fornecedor_excluir",
                       "compras:fornecedor_reativar")
_ROTAS_CADASTROS = ("cadastros:categoria_list", "cadastros:categoria_create",
                    "cadastros:categoria_update", "cadastros:categoria_excluir",
                    "cadastros:categoria_reativar", "cadastros:centrocusto_list",
                    "cadastros:centrocusto_create", "cadastros:centrocusto_update",
                    "cadastros:centrocusto_excluir", "cadastros:centrocusto_reativar")
_ROTAS_PROVISAO_DETALHE = ("gestao_compras:provisao_timeline",
                           "gestao_compras:efetivar_provisao")

_GESTORES = (PROPRIETARIO, GERENTE, FINANCEIRO)          # compras/views PERFIS_GESTORES
_VISUALIZACAO_FIN = (PROPRIETARIO, FINANCEIRO)           # financeiro/views PERFIS_VISUALIZACAO
_SIMULACAO = (PROPRIETARIO, FINANCEIRO, COMPRADOR)       # compras/views PERFIS_SIMULACAO
# Cadastros de apoio (Fornecedores, Categorias, Centros de Custo): o MESMO
# gate das views — `PerfilRequiredMixin` com
# compras/views PERFIS_GESTAO_FORNECEDORES e cadastros/views
# PERFIS_GESTAO_CADASTROS (ambos = PERFIS_GESTORES_FINANCEIROS). Gate por
# PERFIL, não por `cadastros.gerenciar`: o RBAC aditivo não abre essas
# views, então o menu também não pode abrir o link.
_CADASTROS = (PROPRIETARIO, FINANCEIRO)
_ROTAS_CATEGORIAS = tuple(r for r in _ROTAS_CADASTROS if r.startswith("cadastros:categoria_"))
_ROTAS_CENTROS = tuple(r for r in _ROTAS_CADASTROS if r.startswith("cadastros:centrocusto_"))


def _itens_cadastros():
    """Fornecedores, Categorias e Centros de Custo — o banco de produção
    começa limpo e a primeira compra exige fornecedor e categoria, então os
    três precisam estar à mão no menu (antes só se chegava pela busca ou
    pelo Checklist de Implantação)."""
    return [
        _item("fornecedores", "Fornecedores", "compras:fornecedor_list",
              perfis=_CADASTROS, rotas=_ROTAS_FORNECEDORES,
              prefixos=("/compras/fornecedores/",),
              title="Cadastro de fornecedores — necessário antes da primeira compra"),
        _item("categorias", "Categorias", "cadastros:categoria_list",
              perfis=_CADASTROS, rotas=_ROTAS_CATEGORIAS,
              prefixos=("/cadastros/categorias/",),
              title="Categorias de compra — necessárias antes da primeira compra"),
        _item("centros_custo", "Centros de Custo", "cadastros:centrocusto_list",
              perfis=_CADASTROS, rotas=_ROTAS_CENTROS,
              prefixos=("/cadastros/centros-custo/",),
              title="Centros de custo para classificar as compras"),
    ]


# Análise Financeira: o MESMO gate das views (perfil_required(*PERFIS_ANALISE_FINANCEIRA)).
_ANALISE = PERFIS_ANALISE_FINANCEIRA
_ROTAS_ANALISE = ("financeiro:analise_creditos_debitos", "financeiro:analise_saude")


def _estrutura_por_perfil():
    """Monta (sempre do zero — sem estado) a estrutura dos 4 perfis."""
    inicio = _link("inicio", "Início", "dashboard:home", "bi-speedometer2",
                   rotas=("dashboard:home",), title="Dashboard")

    aprovacoes_item = _item("aprovacoes", "Aprovações", "dashboard:aprovacoes",
                            "bi-check2-square", perfis=(PROPRIETARIO, GERENTE),
                            rotas=_ROTAS_APROVACOES,
                            title="Tudo o que aguarda a sua decisão")

    grupo_compras_prop = _grupo("compras", "Compras", "bi-cart-check", [
        _item("nova_compra", "Nova Compra", "compras:nova", permissao="compras.lancar",
              title="Registrar uma compra já realizada ou confirmada"),
        _item("historico_compras", "Histórico de Compras", "compras:lista",
              permissao="compras.ver"),
        aprovacoes_item,
        _item("calendario_compras", "Calendário de Compras", "gestao_compras:calendario",
              permissao="calendario.ver", rotas=_ROTAS_PROVISAO_DETALHE,
              title="Calendário de Provisões de compra"),
        _item("nova_provisao", "Nova Provisão", "gestao_compras:nova_provisao",
              permissao="provisoes.criar",
              title="Planejar e reservar valor para uma compra futura"),
        _item("simulador", "Simulador", "compras:simulacao", perfis=_SIMULACAO,
              title="Simular uma compra sem gravar nada"),
        # Cadastros usados pela compra (fornecedor, categoria, centro de
        # custo) ficam no grupo Compras — o 1º nível continua com 6 entradas.
    ] + _itens_cadastros(),
       rotas_grupo=_ROTAS_FORNECEDORES + _ROTAS_CADASTROS,
       prefixos_grupo=("/compras/fornecedores/", "/cadastros/"))

    analise_titulo = "DRE Gerencial, créditos × débitos e saúde financeira"

    grupo_financeiro_prop = _grupo("financeiro", "Financeiro", "bi-wallet2", [
        _item("planejamento", "Planejamento Financeiro", "financeiro:planejamento",
              permissao="financeiro.ver",
              rotas=("financeiro:receita_list",) + _ROTAS_RECEITAS
              + ("financeiro:custofixo_list",) + _ROTAS_CUSTOS_FIXOS
              + ("financeiro:custovariavel_list",) + _ROTAS_CUSTOS_VARIAVEIS
              + ("financeiro:contas_a_pagar", "financeiro:calendario_operacional"),
              title="Hub com receitas, custos, contas a pagar e calendário operacional"),
        _item("agenda", "Agenda Financeira", "financeiro:agenda",
              permissao="agenda.ver", rotas=_ROTAS_AGENDA),
        _item("calendario_financeiro", "Calendário Financeiro",
              "financeiro:calendario_financeiro", permissao="financeiro.ver",
              title="Calendário Financeiro (visões mensal, semanal e diária)"),
        # Nome canônico (menu = Ajuda = título = trilha): "Capacidade
        # Financeira". Antes o Proprietário via "Capacidade e Limites".
        _item("capacidade", "Capacidade Financeira", "financeiro:configuracao",
              perfis=_VISUALIZACAO_FIN,
              title="Percentuais, dias úteis e regras do Motor Financeiro"),
        _item("compradores", "Compradores e Limites",
              "financeiro:capacidade_compradores", permissao="capacidade.gerenciar",
              rotas=_ROTAS_CAPACIDADE, title="Limites e bloqueios por comprador"),
        _item("parcelamentos", "Parcelamentos", "financeiro:parcelamentos",
              permissao="financeiro.ver"),
        _item("analise_financeira", "Análise Financeira", "financeiro:analise_dre",
              "bi-graph-up-arrow", perfis=_ANALISE, rotas=_ROTAS_ANALISE,
              prefixos=("/financeiro/analise/",), title=analise_titulo),
    ])

    grupo_gestao = _grupo("gestao", "Gestão", "bi-people", [
        _item("empresas", "Empresas e Filiais", "ncc:estrutura",
              permissao="ncc.acessar",
              rotas=("ncc:filiais", "ncc:filial_nova", "ncc:filial_editar",
                     "empresas:editar", "empresas:identidade_visual"),
              prefixos=("/ncc/filiais/",),
              title="Grupo, empresas (CNPJ) e filiais"),
        _item("usuarios", "Usuários e Permissões", "ncc:usuarios",
              permissao="ncc.acessar",
              rotas=("ncc:usuario_novo", "ncc:usuario_editar"),
              prefixos=("/ncc/usuarios/",)),
        _item("perfis_acesso", "Perfis de Acesso", "ncc:perfis",
              permissao="ncc.acessar", rotas=("ncc:perfil_editar",)),
    ])

    grupo_relatorios_prop = _grupo("relatorios", "Relatórios",
                                   "bi-file-earmark-bar-graph", [
        _item("central_relatorios", "Central de Relatórios", "relatorios",
              permissao="relatorios.ver"),
        _item("indicadores", "Indicadores", "dashboard:indicadores",
              perfis=(PROPRIETARIO, GERENTE),
              title="Indicadores por filial e fornecedores do mês"),
        _item("timeline", "Timeline Financeira", "dashboard:timeline",
              permissao="timeline.ver"),
        _item("rel_por_filial", "Compras por Filial", "compras:relatorio_por_filial",
              perfis=_GESTORES),
        _item("rel_por_comprador", "Compras por Comprador",
              "compras:relatorio_por_comprador", perfis=_GESTORES),
    ])

    grupo_config = _grupo("configuracoes", "Configurações", "bi-sliders", [
        # Categorias/Centros de Custo (/cadastros/) saíram daqui: agora têm
        # item próprio no grupo Compras (senão dois itens ficariam ativos).
        _item("ncc_home", "Centro de Configurações", "ncc:home",
              permissao="ncc.acessar",
              rotas=("ncc:gerais", "ncc:motor", "ncc:workflow", "ncc:workflow_novo",
                     "ncc:workflow_editar", "ncc:compras", "ncc:dashboard",
                     "ncc:notificacoes", "ncc:implantacao")),
        _item("checklist", "Checklist de Implantação", "ncc:checklist",
              permissao="ncc.acessar",
              title="Checklist de Implantação — verificado direto no banco"),
        _item("integracoes", "Integrações", "ncc:integracoes",
              permissao="ncc.acessar",
              title="DDA — integração bancária prevista, ainda não conectada"),
        _item("auditoria", "Auditoria do Sistema", "ncc:auditoria",
              permissao="ncc.acessar", rotas=("ncc:central_auditoria",)),
    ])

    grupo_planejamento_fin = _grupo("planejamento", "Planejamento", "bi-compass", [
        _item("planejamento_hub", "Planejamento Financeiro", "financeiro:planejamento",
              permissao="financeiro.ver", title="Hub com todas as áreas do módulo"),
        _item("capacidade", "Capacidade Financeira", "financeiro:configuracao",
              perfis=_VISUALIZACAO_FIN,
              title="Percentuais, dias úteis e regras do Motor"),
        _item("receitas", "Receitas", "financeiro:receita_list",
              perfis=_VISUALIZACAO_FIN, rotas=_ROTAS_RECEITAS,
              prefixos=("/financeiro/receitas/",)),
        _item("custos_fixos", "Custos Fixos", "financeiro:custofixo_list",
              perfis=_VISUALIZACAO_FIN, rotas=_ROTAS_CUSTOS_FIXOS,
              prefixos=("/financeiro/custos-fixos/",)),
        _item("custos_variaveis", "Custos Variáveis", "financeiro:custovariavel_list",
              perfis=_VISUALIZACAO_FIN, rotas=_ROTAS_CUSTOS_VARIAVEIS,
              prefixos=("/financeiro/custos-variaveis/",)),
        _item("contas_a_pagar", "Contas a Pagar", "financeiro:contas_a_pagar",
              permissao="financeiro.ver"),
        _item("parcelamentos", "Parcelamentos", "financeiro:parcelamentos",
              permissao="financeiro.ver"),
        _item("calendario_operacional", "Calendário Operacional",
              "financeiro:calendario_operacional", permissao="calendario.configurar",
              title="Feriados, bloqueios e dias especiais"),
        # Cadastros de apoio dentro do MESMO grupo (o menu do Financeiro tem
        # um único grupo — core/tests_navegacao_v4 e financeiro/tests_analise).
    ] + _itens_cadastros(),
       rotas_grupo=_ROTAS_FORNECEDORES + _ROTAS_CADASTROS,
       prefixos_grupo=("/compras/fornecedores/", "/cadastros/"))

    grupo_planejamento_compras = _grupo("planejamento_compras",
                                        "Planejamento de Compras", "bi-calendar3", [
        _item("nova_provisao", "Nova Provisão", "gestao_compras:nova_provisao",
              permissao="provisoes.criar",
              title="Planejar e reservar valor para uma compra futura"),
        _item("calendario_compras", "Calendário de Compras", "gestao_compras:calendario",
              permissao="calendario.ver", rotas=_ROTAS_PROVISAO_DETALHE),
    ])

    return {
        PROPRIETARIO: [
            inicio, grupo_compras_prop, grupo_financeiro_prop, grupo_gestao,
            grupo_relatorios_prop, grupo_config,
        ],
        FINANCEIRO: [
            inicio,
            _link("agenda", "Agenda Financeira", "financeiro:agenda",
                  "bi-calendar2-week", permissao="agenda.ver", rotas=_ROTAS_AGENDA),
            _link("calendario_financeiro", "Calendário Financeiro",
                  "financeiro:calendario_financeiro", "bi-calendar3",
                  permissao="financeiro.ver",
                  title="Calendário Financeiro (inteligente) — mensal, semanal e diário"),
            _link("compradores", "Compradores e Limites",
                  "financeiro:capacidade_compradores", "bi-people-fill",
                  permissao="capacidade.gerenciar", rotas=_ROTAS_CAPACIDADE,
                  title="Limites e bloqueios por comprador"),
            grupo_planejamento_fin,
            _link("analise_financeira", "Análise Financeira", "financeiro:analise_dre",
                  "bi-graph-up-arrow", perfis=_ANALISE, rotas=_ROTAS_ANALISE,
                  prefixos=("/financeiro/analise/",), title=analise_titulo),
            _link("relatorios", "Relatórios", "relatorios",
                  "bi-file-earmark-bar-graph", permissao="relatorios.ver",
                  rotas=("compras:relatorio_por_filial",
                         "compras:relatorio_por_comprador")),
        ],
        GERENTE: [
            inicio,
            _link("aprovacoes", "Aprovações", "dashboard:aprovacoes",
                  "bi-check2-square", perfis=(PROPRIETARIO, GERENTE),
                  rotas=_ROTAS_APROVACOES,
                  title="Tudo o que aguarda a sua decisão"),
            _link("indicadores", "Indicadores", "dashboard:indicadores",
                  "bi-graph-up-arrow", perfis=(PROPRIETARIO, GERENTE),
                  title="Indicadores por filial e fornecedores do mês"),
            _link("agenda", "Agenda Financeira", "financeiro:agenda",
                  "bi-calendar2-week", permissao="agenda.ver", rotas=_ROTAS_AGENDA,
                  title="Agenda Financeira (acesso concedido)"),
            _link("analise_financeira", "Análise Financeira", "financeiro:analise_dre",
                  "bi-graph-up-arrow", perfis=_ANALISE, rotas=_ROTAS_ANALISE,
                  prefixos=("/financeiro/analise/",), title=analise_titulo),
            _link("relatorios", "Relatórios", "relatorios",
                  "bi-file-earmark-bar-graph", permissao="relatorios.ver",
                  rotas=("compras:relatorio_por_filial",
                         "compras:relatorio_por_comprador")),
        ],
        COMPRADOR: [
            inicio,
            _link("nova_compra", "Nova Compra", "compras:nova", "bi-plus-circle-fill",
                  permissao="compras.lancar",
                  title="Registrar uma compra já realizada ou confirmada"),
            grupo_planejamento_compras,
            _link("historico_compras", "Histórico de Compras", "compras:lista",
                  "bi-clock-history", permissao="compras.ver",
                  title="Histórico das minhas compras"),
            _link("simulador", "Simulador", "compras:simulacao", "bi-calculator-fill",
                  perfis=_SIMULACAO, title="Simular uma compra sem gravar nada"),
            _link("agenda", "Agenda Financeira", "financeiro:agenda",
                  "bi-calendar2-week", permissao="agenda.ver", rotas=_ROTAS_AGENDA,
                  title="Agenda Financeira (acesso concedido)"),
            _link("timeline", "Timeline Financeira", "dashboard:timeline",
                  "bi-graph-up", permissao="timeline.ver",
                  title="Timeline Financeira (acesso concedido)"),
        ],
    }


# ---------------------------------------------------------------------------
# Barra de navegação inferior (mobile) — no máximo 4 ações por perfil
# ---------------------------------------------------------------------------

def _mobile_por_perfil():
    inicio = _item("m_inicio", "Início", "dashboard:home", "bi-speedometer2")
    return {
        COMPRADOR: [
            inicio,
            _item("m_nova_compra", "Nova Compra", "compras:nova",
                  "bi-plus-circle-fill", permissao="compras.lancar"),
            _item("m_calendario", "Calendário", "gestao_compras:calendario",
                  "bi-calendar3", permissao="calendario.ver",
                  rotas=("gestao_compras:nova_provisao",) + _ROTAS_PROVISAO_DETALHE),
        ],
        FINANCEIRO: [
            inicio,
            _item("m_agenda", "Agenda", "financeiro:agenda", "bi-calendar2-week",
                  permissao="agenda.ver", rotas=_ROTAS_AGENDA),
            _item("m_calendario", "Calendário", "financeiro:calendario_financeiro",
                  "bi-calendar3", permissao="financeiro.ver"),
        ],
        GERENTE: [
            inicio,
            _item("m_aprovacoes", "Aprovações", "dashboard:aprovacoes",
                  "bi-check2-square", perfis=(PROPRIETARIO, GERENTE),
                  rotas=_ROTAS_APROVACOES),
            _item("m_indicadores", "Indicadores", "dashboard:indicadores",
                  "bi-graph-up-arrow", perfis=(PROPRIETARIO, GERENTE)),
        ],
        PROPRIETARIO: [
            inicio,
            _item("m_aprovacoes", "Aprovações", "dashboard:aprovacoes",
                  "bi-check2-square", perfis=(PROPRIETARIO, GERENTE),
                  rotas=_ROTAS_APROVACOES),
            _item("m_relatorios", "Relatórios", "relatorios",
                  "bi-file-earmark-bar-graph", permissao="relatorios.ver"),
        ],
    }


# Reservas por perfil caso um destino padrão do mobile não seja autorizado
# (o RBAC do NEXBUY é aditivo — na prática os padrões acima sempre passam,
# mas a regra da Seção 9.2 exige substituição, nunca um link 403).
def _mobile_reservas():
    return {
        COMPRADOR: [
            _item("m_historico", "Histórico", "compras:lista", "bi-clock-history",
                  permissao="compras.ver"),
            _item("m_simulador", "Simulador", "compras:simulacao",
                  "bi-calculator-fill", perfis=_SIMULACAO),
        ],
        FINANCEIRO: [
            _item("m_planejamento", "Planejamento", "financeiro:planejamento",
                  "bi-compass", permissao="financeiro.ver"),
            _item("m_relatorios", "Relatórios", "relatorios",
                  "bi-file-earmark-bar-graph", permissao="relatorios.ver"),
        ],
        GERENTE: [
            _item("m_relatorios", "Relatórios", "relatorios",
                  "bi-file-earmark-bar-graph", permissao="relatorios.ver"),
        ],
        PROPRIETARIO: [
            _item("m_nova_compra", "Nova Compra", "compras:nova",
                  "bi-plus-circle-fill", permissao="compras.lancar"),
        ],
    }


# ---------------------------------------------------------------------------
# Breadcrumbs — trilha declarada por rota (view_name)
# ---------------------------------------------------------------------------
# Cada trilha é uma lista de (rotulo, url_name|None, permissao|None). O
# último nível é sempre a página atual (sem link). Níveis anteriores só
# viram link se o usuário tiver a permissão indicada — caso contrário
# aparecem como texto simples (nunca um link que dê 403).

_C_PLANEJAMENTO = ("Planejamento Financeiro", "financeiro:planejamento", "financeiro.ver")
_C_RECEITAS = ("Receitas", "financeiro:receita_list", None)
_C_RECEITAS_EXTRAS = ("Receitas extras", "financeiro:receitaextra_list", None)
_C_CUSTOS_FIXOS = ("Custos Fixos", "financeiro:custofixo_list", None)
_C_CUSTOS_VARIAVEIS = ("Custos Variáveis", "financeiro:custovariavel_list", None)
_C_USUARIOS = ("Usuários e Permissões", "ncc:usuarios", "ncc.acessar")
_C_FILIAIS = ("Filiais", "ncc:filiais", "ncc.acessar")
_C_EMPRESAS = ("Empresas e Filiais", "ncc:estrutura", "ncc.acessar")
_C_NCC = ("Centro de Configurações", "ncc:home", "ncc.acessar")
_C_RELATORIOS = ("Central de Relatórios", "relatorios", "relatorios.ver")
_C_CAL_COMPRAS = ("Calendário de Compras", "gestao_compras:calendario", "calendario.ver")
_C_AGENDA = ("Agenda Financeira", "financeiro:agenda", "agenda.ver")
_C_APROVACOES = ("Aprovações", "dashboard:aprovacoes", None)
_C_FORNECEDORES = ("Fornecedores", "compras:fornecedor_list", None)
_C_CATEGORIAS = ("Categorias", "cadastros:categoria_list", None)
_C_CENTROS = ("Centros de Custo", "cadastros:centrocusto_list", None)
_C_PERFIS = ("Perfis de Acesso", "ncc:perfis", "ncc.acessar")
_C_WORKFLOW = ("Workflow de Aprovações", "ncc:workflow", "ncc.acessar")
_C_CAPACIDADE = ("Compradores e Limites", "financeiro:capacidade_compradores",
                 "capacidade.gerenciar")
# Gate por perfil (não por permissão RBAC): só quem passou pelo
# perfil_required da Análise chega nestas páginas, então o nível pode linkar.
_C_ANALISE = ("Análise Financeira", "financeiro:analise_dre", None)

_FIM = lambda rotulo: (rotulo, None, None)  # noqa: E731 — página atual

TRILHAS = {
    # Compras
    "compras:nova": [_FIM("Nova Compra")],
    "compras:lista": [_FIM("Histórico de Compras")],
    "compras:simulacao": [_FIM("Simulador de Compra")],
    "compras:aprovacao": [_C_APROVACOES, _FIM("Compras acima do limite")],
    "gestao_compras:calendario": [_FIM("Calendário de Compras")],
    "gestao_compras:nova_provisao": [_C_CAL_COMPRAS, _FIM("Nova Provisão")],
    "gestao_compras:aprovacao_list": [_C_APROVACOES, _FIM("Provisões para decidir")],
    "gestao_compras:provisao_timeline": [_C_CAL_COMPRAS, _FIM("Timeline da Provisão")],
    "compras:fornecedor_list": [_FIM("Fornecedores")],
    "compras:fornecedor_create": [_C_FORNECEDORES, _FIM("Novo Fornecedor")],
    "compras:fornecedor_update": [_C_FORNECEDORES, _FIM("Editar Fornecedor")],
    # Financeiro / Planejamento
    "financeiro:planejamento": [_FIM("Planejamento Financeiro")],
    "financeiro:agenda": [_FIM("Agenda Financeira")],
    "financeiro:calendario_financeiro": [_FIM("Calendário Financeiro")],
    "financeiro:configuracao": [_C_PLANEJAMENTO, _FIM("Capacidade Financeira")],
    "financeiro:capacidade_compradores": [_FIM("Compradores e Limites")],
    "financeiro:parcelamentos": [_C_PLANEJAMENTO, _FIM("Parcelamentos")],
    "financeiro:contas_a_pagar": [_C_PLANEJAMENTO, _FIM("Contas a Pagar")],
    "financeiro:calendario_operacional": [_C_PLANEJAMENTO, _FIM("Calendário Operacional")],
    # Análise Financeira: Início › Análise Financeira › <tela>
    "financeiro:analise_dre": [_C_ANALISE, _FIM("DRE Gerencial")],
    "financeiro:analise_creditos_debitos": [_C_ANALISE, _FIM("Créditos × Débitos")],
    "financeiro:analise_saude": [_C_ANALISE, _FIM("Saúde Financeira")],
    "financeiro:receita_list": [_C_PLANEJAMENTO, _FIM("Receitas")],
    "financeiro:receita_create": [_C_PLANEJAMENTO, _C_RECEITAS, _FIM("Nova Receita")],
    "financeiro:receita_update": [_C_PLANEJAMENTO, _C_RECEITAS, _FIM("Editar Receita")],
    "financeiro:receitaextra_list": [_C_PLANEJAMENTO, _C_RECEITAS, _FIM("Receitas extras")],
    "financeiro:receitaextra_create": [_C_PLANEJAMENTO, _C_RECEITAS, _C_RECEITAS_EXTRAS,
                                       _FIM("Nova receita extra")],
    "financeiro:receitaextra_update": [_C_PLANEJAMENTO, _C_RECEITAS, _C_RECEITAS_EXTRAS,
                                       _FIM("Editar receita extra")],
    "financeiro:receitaextra_excluir": [_C_PLANEJAMENTO, _C_RECEITAS, _C_RECEITAS_EXTRAS,
                                        _FIM("Excluir receita extra")],
    "financeiro:custofixo_list": [_C_PLANEJAMENTO, _FIM("Custos Fixos")],
    "financeiro:custofixo_create": [_C_PLANEJAMENTO, _C_CUSTOS_FIXOS,
                                    _FIM("Novo Custo Fixo")],
    "financeiro:custofixo_update": [_C_PLANEJAMENTO, _C_CUSTOS_FIXOS,
                                    _FIM("Editar Custo Fixo")],
    "financeiro:custovariavel_list": [_C_PLANEJAMENTO, _FIM("Custos Variáveis")],
    "financeiro:custovariavel_create": [_C_PLANEJAMENTO, _C_CUSTOS_VARIAVEIS,
                                        _FIM("Novo Custo Variável")],
    "financeiro:custovariavel_update": [_C_PLANEJAMENTO, _C_CUSTOS_VARIAVEIS,
                                        _FIM("Editar Custo Variável")],
    # Cadastros de apoio
    "cadastros:categoria_list": [_FIM("Categorias")],
    "cadastros:categoria_create": [_C_CATEGORIAS, _FIM("Nova Categoria")],
    "cadastros:categoria_update": [_C_CATEGORIAS, _FIM("Editar Categoria")],
    "cadastros:centrocusto_list": [_FIM("Centros de Custo")],
    "cadastros:centrocusto_create": [_C_CENTROS, _FIM("Novo Centro de Custo")],
    "cadastros:centrocusto_update": [_C_CENTROS, _FIM("Editar Centro de Custo")],
    # Dashboard / transversais com trilha própria
    "dashboard:aprovacoes": [_FIM("Aprovações")],
    "dashboard:indicadores": [_FIM("Indicadores")],
    "dashboard:timeline": [_FIM("Timeline Financeira")],
    "relatorios": [_FIM("Central de Relatórios")],
    "compras:relatorio_por_filial": [_C_RELATORIOS, _FIM("Compras por Filial")],
    "compras:relatorio_por_comprador": [_C_RELATORIOS, _FIM("Compras por Comprador")],
    # Gestão (NCC)
    "ncc:home": [_FIM("Centro de Configurações")],
    "ncc:estrutura": [_FIM("Empresas e Filiais")],
    "ncc:filiais": [_C_EMPRESAS, _FIM("Filiais")],
    "ncc:filial_nova": [_C_EMPRESAS, _C_FILIAIS, _FIM("Nova Filial")],
    "ncc:filial_editar": [_C_EMPRESAS, _C_FILIAIS, _FIM("Editar Filial")],
    "ncc:usuarios": [_FIM("Usuários e Permissões")],
    "ncc:usuario_novo": [_C_USUARIOS, _FIM("Novo Usuário")],
    "ncc:usuario_editar": [_C_USUARIOS, _FIM("Editar Usuário")],
    "ncc:perfis": [_FIM("Perfis de Acesso")],
    "ncc:perfil_editar": [_C_PERFIS, _FIM("Editar Perfil de Acesso")],
    "ncc:gerais": [_C_NCC, _FIM("Configurações Gerais")],
    "ncc:motor": [_C_NCC, _FIM("Motor Financeiro")],
    "ncc:workflow": [_C_NCC, _FIM("Workflow de Aprovações")],
    "ncc:workflow_novo": [_C_NCC, _C_WORKFLOW, _FIM("Novo Workflow")],
    "ncc:workflow_editar": [_C_NCC, _C_WORKFLOW, _FIM("Editar Workflow")],
    "ncc:compras": [_C_NCC, _FIM("Configurações de Compras")],
    "ncc:dashboard": [_C_NCC, _FIM("Configurações de Dashboards")],
    "ncc:notificacoes": [_C_NCC, _FIM("Configurações de Notificações")],
    "ncc:integracoes": [_C_NCC, _FIM("Integrações")],
    "ncc:checklist": [_C_NCC, _FIM("Checklist de Implantação")],
    "ncc:auditoria": [_C_NCC, _FIM("Auditoria do Sistema")],
    "ncc:central_auditoria": [("Auditoria", "ncc:auditoria", "ncc.acessar"),
                              _FIM("Central de Auditoria")],
    "ncc:implantacao": [_C_NCC, _FIM("Assistente de Implantação")],
    "empresas:editar": [_C_EMPRESAS, _FIM("Dados da Empresa")],
    "empresas:identidade_visual": [_C_EMPRESAS, _FIM("Identidade Visual")],
    "notificacoes:lista": [_FIM("Notificações")],
    "busca_global": [_FIM("Pesquisa Global")],
    "meu_perfil": [_FIM("Meu Perfil")],
    "bem_vindo": [_FIM("Bem-vindo ao NEXBUY")],
    # Central de Ajuda: Início › Ajuda
    "ajuda": [_FIM("Ajuda")],
}


# ---------------------------------------------------------------------------
# Montagem por request
# ---------------------------------------------------------------------------

def _permitido(entrada, user, perms):
    """Aplica o MESMO gate da view de destino (permissão RBAC ou perfil)."""
    if user.is_superuser:
        return True
    if entrada.get("perfis") is not None:
        return user.perfil in entrada["perfis"]
    if entrada.get("permissao"):
        return entrada["permissao"] in perms
    return True


def pode_acessar(user, permissao=None, perfis=None):
    """Mesmo gate do menu para links fora do menu (hub Planejamento
    Financeiro, botões do Calendário Financeiro...): `permissao` para views
    com @permissao_required, `perfis` para views por perfil. Nunca um link
    que dê 403 (rodada final: o hub mostrava 12 cartões sem gate e 7 davam
    403 para o Gerente com financeiro.ver concedido por Perfil de Acesso)."""
    perms = permissoes_do_usuario(user) if permissao else set()
    return _permitido({"permissao": permissao, "perfis": perfis}, user, perms)


def _resolver(request):
    match = getattr(request, "resolver_match", None)
    view_name = match.view_name if match else ""
    return view_name, (request.path or "")


def _ativo(entrada, view_name, path):
    if view_name and view_name in entrada["rotas"]:
        return True
    return any(path.startswith(p) for p in entrada["prefixos"])


def montar_navegacao(user, request):
    """Sidebar: lista de grupos/links já filtrados e com estado ativo."""
    from django.urls import reverse

    perms = permissoes_do_usuario(user)
    view_name, path = _resolver(request)
    estrutura = _estrutura_por_perfil().get(user.perfil) or _estrutura_por_perfil()[COMPRADOR]

    resultado = []
    for entrada in estrutura:
        if entrada.get("link_unico"):
            if not _permitido(entrada, user, perms):
                continue
            resultado.append({
                "link_unico": True, "id": entrada["id"], "rotulo": entrada["rotulo"],
                "icone": entrada["icone"], "title": entrada["title"],
                "url": reverse(entrada["url_name"]),
                "ativo": _ativo(entrada, view_name, path),
            })
            continue
        itens = []
        for item in entrada["itens"]:
            if not _permitido(item, user, perms):
                continue
            itens.append({
                "id": item["id"], "rotulo": item["rotulo"], "title": item["title"],
                "url": reverse(item["url_name"]),
                "ativo": _ativo(item, view_name, path),
            })
        if not itens:
            continue
        grupo_ativo = (any(i["ativo"] for i in itens)
                       or (view_name and view_name in entrada["rotas_grupo"])
                       or any(path.startswith(p) for p in entrada["prefixos_grupo"]))
        resultado.append({
            "link_unico": False, "id": entrada["id"], "rotulo": entrada["rotulo"],
            "icone": entrada["icone"], "itens": itens,
            "ativo": grupo_ativo, "aberto": grupo_ativo,
        })
    return resultado


def montar_nav_mobile(user, request):
    """Barra inferior mobile: até 3 destinos + o botão Menu (no template)."""
    from django.urls import reverse

    perms = permissoes_do_usuario(user)
    view_name, path = _resolver(request)
    padrao = _mobile_por_perfil().get(user.perfil) or _mobile_por_perfil()[COMPRADOR]
    reservas = list(_mobile_reservas().get(user.perfil, ()))

    itens = []
    for item in padrao:
        if not _permitido(item, user, perms):
            # Seção 9.2: substitui pelo próximo destino permitido mais útil.
            substituto = next((r for r in reservas if _permitido(r, user, perms)), None)
            if substituto is None:
                continue
            reservas.remove(substituto)
            item = substituto
        itens.append({
            "id": item["id"], "rotulo": item["rotulo"], "icone": item["icone"],
            "url": reverse(item["url_name"]),
            "ativo": _ativo(item, view_name, path),
        })
    return itens[:3]


def montar_breadcrumbs(user, request):
    """Trilha estrutural da página atual (lista de dicts prontos p/ template)."""
    from django.urls import reverse

    view_name, _ = _resolver(request)
    if not view_name or view_name == "dashboard:home":
        return []  # o Dashboard inicial não exibe breadcrumb (Seção 7.2)
    trilha = TRILHAS.get(view_name)
    if not trilha:
        return []

    perms = permissoes_do_usuario(user)
    crumbs = [{"rotulo": "Início", "url": reverse("dashboard:home"), "atual": False}]
    total = len(trilha)
    for indice, (rotulo, url_name, permissao) in enumerate(trilha):
        ultimo = indice == total - 1
        pode_linkar = (url_name is not None and not ultimo
                       and (permissao is None or user.is_superuser or permissao in perms))
        crumbs.append({
            "rotulo": rotulo,
            "url": reverse(url_name) if pode_linkar else "",
            "atual": ultimo,
        })
    return crumbs
