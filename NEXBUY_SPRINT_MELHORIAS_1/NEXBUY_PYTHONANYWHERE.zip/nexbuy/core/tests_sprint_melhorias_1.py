"""Sprint de Melhorias 1 — segurança e usabilidade, sem mudar a essência do
NEXBUY (limite de compra do dia, aprovação e análise do mês).

Cada classe trava uma melhoria:
- CSV sem fórmula do Excel;
- Assistente de Implantação só para o suporte;
- conta do suporte e perfil global fora do alcance do cliente;
- senha inicial com as regras completas;
- limite de tentativas de login;
- troca de empresa sem redirecionar para outro site;
- histórico de compras paginado;
- "Sábado é dia de compra";
- alertas e recomendações honestos quando falta lançamento.
"""
from datetime import date, timedelta
from decimal import Decimal

from django.test import Client, TestCase
from django.test.utils import override_settings
from django.utils import timezone

from auditoria.models import RegistroAuditoria
from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from core.relatorios import celula_segura, resposta_csv
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, Receita
from usuarios.models import PerfilAcesso, Permissao, Usuario

SENHA = "Farmacia#Forte2026"


def _empresa(nome, cnpj):
    empresa = Empresa.objects.create(nome=nome, cnpj=cnpj)
    filial = Filial.objects.create(empresa=empresa, nome="Matriz")
    return empresa, filial


class CsvSemFormulaTestCase(TestCase):
    def test_celula_que_comeca_com_formula_ganha_apostrofo(self):
        for perigosa in ("=HYPERLINK(\"http://x\";\"clique\")", "+1+1", "@SOMA(A1)", "-2+3", "\t=1"):
            self.assertTrue(celula_segura(perigosa).startswith("'"), perigosa)

    def test_numeros_e_textos_comuns_nao_mudam(self):
        for comum in ("-3.300,00", "1.500,00", "-15", "Juliana Ramos", "", "Medicamentos"):
            self.assertEqual(celula_segura(comum), comum)
        self.assertEqual(celula_segura(Decimal("10")), Decimal("10"))

    def test_resposta_csv_aplica_a_protecao(self):
        conteudo = resposta_csv("x.csv", ["Nome"], [["=1+1"], ["-10,00"]]).content.decode("utf-8-sig")
        self.assertIn("'=1+1", conteudo)
        self.assertIn("-10,00", conteudo)
        self.assertNotIn("'-10,00", conteudo)


@override_settings(ALLOWED_HOSTS=["*"])
class AssistenteSoParaSuporteTestCase(TestCase):
    def setUp(self):
        self.empresa, self.filial = _empresa("Farmácia A", "11.444.777/0001-61")
        self.proprietario = Usuario.objects.create_user(
            username="dono_a", password=SENHA, perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.suporte = Usuario.objects.create_user(
            username="suporte", password=SENHA, perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
            is_superuser=True, is_staff=True,
        )

    def test_proprietario_nao_abre_o_assistente(self):
        self.client.force_login(self.proprietario)
        self.assertEqual(self.client.get("/ncc/implantacao/").status_code, 403)
        self.assertEqual(self.client.post("/ncc/implantacao/", {"acao": "avancar"}).status_code, 403)

    def test_proprietario_nao_ve_o_atalho_do_assistente(self):
        self.client.force_login(self.proprietario)
        self.assertNotContains(self.client.get("/ncc/"), "/ncc/implantacao/")

    def test_suporte_continua_usando_o_assistente(self):
        self.client.force_login(self.suporte)
        self.assertEqual(self.client.get("/ncc/implantacao/").status_code, 200)
        self.assertContains(self.client.get("/ncc/"), "/ncc/implantacao/")


@override_settings(ALLOWED_HOSTS=["*"])
class ContaDoSuporteEPerfilGlobalTestCase(TestCase):
    def setUp(self):
        self.empresa, self.filial = _empresa("Farmácia B", "22.555.888/0001-02")
        self.proprietario = Usuario.objects.create_user(
            username="dono_b", password=SENHA, perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.suporte = Usuario.objects.create_user(
            username="suporte_b", password=SENHA, perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
            is_superuser=True, is_staff=True,
        )
        self.client.force_login(self.proprietario)

    def test_proprietario_nao_gera_senha_para_a_conta_do_suporte(self):
        senha_antes = Usuario.objects.get(pk=self.suporte.pk).password
        resposta = self.client.post(f"/ncc/usuarios/{self.suporte.pk}/", {"gerar_senha": "1"})
        self.assertEqual(resposta.status_code, 404)
        self.assertEqual(Usuario.objects.get(pk=self.suporte.pk).password, senha_antes)

    def test_perfil_global_nao_e_editado_nem_adotado_pelo_cliente(self):
        global_ = PerfilAcesso.objects.create(nome="Global", empresa=None)
        resposta = self.client.post(
            f"/ncc/perfis/{global_.pk}/",
            {"nome": "Sequestrado", "descricao": "", "permissoes": list(Permissao.objects.values_list("pk", flat=True)[:3])},
        )
        self.assertEqual(resposta.status_code, 302)
        global_.refresh_from_db()
        self.assertEqual(global_.nome, "Global")
        self.assertIsNone(global_.empresa_id)
        self.assertEqual(global_.permissoes.count(), 0)

    def test_perfil_da_propria_empresa_continua_editavel(self):
        proprio = PerfilAcesso.objects.create(nome="Consulta", empresa=self.empresa)
        self.client.post(f"/ncc/perfis/{proprio.pk}/", {"nome": "Consulta Financeira", "descricao": ""})
        proprio.refresh_from_db()
        self.assertEqual(proprio.nome, "Consulta Financeira")


@override_settings(ALLOWED_HOSTS=["*"])
class SenhaInicialForteTestCase(TestCase):
    def setUp(self):
        self.empresa, self.filial = _empresa("Farmácia C", "33.666.999/0001-03")
        self.proprietario = Usuario.objects.create_user(
            username="dono_c", password=SENHA, perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client.force_login(self.proprietario)

    def _criar(self, senha, username="novo_comprador"):
        return self.client.post("/ncc/usuarios/novo/", {
            "first_name": "Ana", "last_name": "Lima", "email": "ana@exemplo.com", "username": username,
            "filial": self.filial.pk, "perfil": Usuario.Perfil.COMPRADOR, "is_active": "on", "senha_inicial": senha,
        })

    def test_senha_so_de_numeros_ou_comum_e_recusada(self):
        for fraca in ("12345678", "password", "novo_comprador1"):
            self._criar(fraca)
            self.assertFalse(Usuario.objects.filter(username="novo_comprador").exists(), fraca)

    def test_senha_forte_cria_o_usuario(self):
        self._criar(SENHA)
        self.assertTrue(Usuario.objects.filter(username="novo_comprador").exists())


@override_settings(ALLOWED_HOSTS=["*"], LOGIN_MAX_FALHAS_USUARIO=5, LOGIN_MAX_FALHAS_IP=20, LOGIN_JANELA_MINUTOS=15)
class LimiteDeTentativasDeLoginTestCase(TestCase):
    def setUp(self):
        self.empresa, self.filial = _empresa("Farmácia D", "44.777.000/0001-04")
        Usuario.objects.create_user(username="juliana", password=SENHA, perfil=Usuario.Perfil.COMPRADOR,
                                    empresa=self.empresa, filial=self.filial)
        Usuario.objects.create_user(username="pedro", password=SENHA, perfil=Usuario.Perfil.COMPRADOR,
                                    empresa=self.empresa, filial=self.filial)

    def _login(self, username, senha, ip="45.10.0.1"):
        return Client(REMOTE_ADDR=ip).post("/accounts/login/", {"username": username, "password": senha})

    def test_cinco_falhas_pausam_o_usuario_mesmo_com_a_senha_certa(self):
        for _ in range(5):
            self.assertEqual(self._login("juliana", "errada").status_code, 200)
        resposta = self._login("juliana", SENHA)
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Muitas tentativas de login")

    def test_outro_usuario_nao_e_afetado(self):
        for _ in range(5):
            self._login("juliana", "errada", ip="45.10.0.2")
        self.assertEqual(self._login("pedro", SENHA, ip="45.10.0.3").status_code, 302)

    def test_bloqueio_acaba_depois_da_janela(self):
        for _ in range(5):
            self._login("juliana", "errada")
        RegistroAuditoria.objects.filter(categoria=RegistroAuditoria.Categoria.LOGIN_FALHO).update(
            criado_em=timezone.now() - timedelta(days=1)
        )
        self.assertEqual(self._login("juliana", SENHA).status_code, 302)

    def test_ip_com_muitas_falhas_e_pausado(self):
        for i in range(20):
            self._login(f"inexistente{i}", "errada", ip="45.9.9.9")
        self.assertContains(self._login("pedro", SENHA, ip="45.9.9.9"), "Muitas tentativas de login")
        self.assertEqual(self._login("pedro", SENHA, ip="45.10.0.4").status_code, 302)

    def test_ip_interno_de_balanceador_nunca_pausa_o_site_inteiro(self):
        # PythonAnywhere: todos chegam com o IP interno do balanceador.
        for i in range(25):
            self._login(f"inexistente{i}", "errada", ip="10.0.0.9")
        self.assertEqual(self._login("pedro", SENHA, ip="10.0.0.9").status_code, 302)


@override_settings(ALLOWED_HOSTS=["*"])
class TrocaDeEmpresaSemRedirecionamentoExternoTestCase(TestCase):
    def test_proxima_de_outro_site_vira_a_tela_inicial(self):
        empresa, filial = _empresa("Farmácia E", "55.888.111/0001-05")
        dono = Usuario.objects.create_user(username="dono_e", password=SENHA,
                                           perfil=Usuario.Perfil.PROPRIETARIO, empresa=empresa)
        self.client.force_login(dono)
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": empresa.pk, "proxima": "https://golpe.exemplo/"})
        self.assertEqual(resposta.status_code, 302)
        self.assertNotIn("golpe.exemplo", resposta["Location"])
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": empresa.pk, "proxima": "/compras/lista/"})
        self.assertEqual(resposta["Location"], "/compras/lista/")


@override_settings(ALLOWED_HOSTS=["*"])
class HistoricoPaginadoTestCase(TestCase):
    def setUp(self):
        self.empresa, self.filial = _empresa("Farmácia F", "66.999.222/0001-06")
        self.dono = Usuario.objects.create_user(username="dono_f", password=SENHA,
                                                perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa)
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Distribuidora")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos")
        Compra.objects.bulk_create([
            Compra(empresa=self.empresa, filial=self.filial, fornecedor=fornecedor, categoria=categoria,
                   usuario=self.dono, valor=Decimal("10.00"), data_compra=date(2026, 6, 1) + timedelta(days=i % 28),
                   status=Compra.Status.APROVADA)
            for i in range(60)
        ])
        self.client.force_login(self.dono)

    def test_cinquenta_por_pagina_e_total_de_todas(self):
        resposta = self.client.get("/compras/lista/")
        self.assertEqual(len(resposta.context["compras"]), 50)
        self.assertEqual(resposta.context["total_valor"], Decimal("600.00"))
        self.assertContains(resposta, "Página 1 de 2")
        self.assertEqual(len(self.client.get("/compras/lista/?page=2").context["compras"]), 10)

    def test_csv_continua_com_todas_as_compras(self):
        conteudo = self.client.get("/compras/lista/?formato=csv").content.decode("utf-8-sig")
        self.assertEqual(len([linha for linha in conteudo.splitlines() if linha]) - 1, 60)


@override_settings(ALLOWED_HOSTS=["*"])
class SabadoDiaDeCompraTestCase(TestCase):
    def setUp(self):
        self.empresa, self.filial = _empresa("Farmácia G", "77.000.333/0001-07")

    def test_opcao_desligada_mantem_segunda_a_sexta(self):
        from finance_engine.calendario_operacional import dias_uteis_operacionais
        # Outubro/2026: 22 dias de segunda a sexta e 5 sábados.
        self.assertEqual(dias_uteis_operacionais(self.empresa, 2026, 10), 22)

    def test_opcao_ligada_conta_os_sabados(self):
        from finance_engine.calendario_operacional import dia_conta_capacidade, dias_uteis_operacionais, tipo_do_dia
        self.empresa.sabado_dia_de_compra = True
        self.empresa.save()
        self.assertEqual(dias_uteis_operacionais(self.empresa, 2026, 10), 27)
        self.assertTrue(dia_conta_capacidade(tipo_do_dia(self.empresa, date(2026, 10, 17))))
        self.assertFalse(dia_conta_capacidade(tipo_do_dia(self.empresa, date(2026, 10, 18))))  # domingo

    def test_sabado_ligado_recebe_limite_no_motor(self):
        from finance_engine.services import motor_financeiro
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, percentual_compras=Decimal("50"))
        Receita.objects.create(filial=self.filial, mes=date(2026, 10, 1), faturamento=Decimal("100000"))
        self.empresa.sabado_dia_de_compra = True
        self.empresa.save()
        posicoes = motor_financeiro.calcular_posicoes_do_mes(self.filial, 2026, 10)
        sabado = next(p for p in posicoes if p.data == date(2026, 10, 17))
        self.assertGreater(sabado.limite_efetivo, 0)

    def test_tela_liga_e_desliga_com_auditoria(self):
        dono = Usuario.objects.create_user(username="dono_g", password=SENHA,
                                           perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa)
        self.client.force_login(dono)
        self.client.post("/financeiro/calendario-operacional/", {"acao": "sabado", "sabado_dia_de_compra": "1"})
        self.empresa.refresh_from_db()
        self.assertTrue(self.empresa.sabado_dia_de_compra)
        self.assertTrue(RegistroAuditoria.objects.filter(empresa=self.empresa, acao="sabado_dia_de_compra").exists())
        self.assertContains(self.client.get("/financeiro/calendario-operacional/"), "Ligado: sábado é dia de compra")
        self.client.post("/financeiro/calendario-operacional/", {"acao": "sabado", "sabado_dia_de_compra": "0"})
        self.empresa.refresh_from_db()
        self.assertFalse(self.empresa.sabado_dia_de_compra)


class AlertasSemReceitaTestCase(TestCase):
    def test_mes_sem_receita_gera_um_aviso_claro_e_nenhum_dia_critico(self):
        from finance_engine.alertas import gerar_alertas
        empresa, filial = _empresa("Farmácia H", "88.111.444/0001-08")
        ConfiguracaoFinanceira.objects.create(empresa=empresa, percentual_compras=Decimal("50"))
        alertas = gerar_alertas(filial, date(2026, 10, 1))
        titulos = [a.titulo for a in alertas]
        self.assertIn("Receita do mês não lançada", titulos)
        self.assertNotIn("Dia crítico à frente", titulos)
        self.assertNotIn("Capacidade de hoje excedida", titulos)


class RecomendacaoHonestaTestCase(TestCase):
    def test_sem_ponto_de_equilibrio_por_falta_de_dado_nao_diz_que_compras_passam_da_receita(self):
        from types import SimpleNamespace

        from financeiro.services_analise import gerar_recomendacoes
        # Mês sem compras lançadas: margem de contribuição positiva, resultado
        # negativo (custos fixos altos) e ponto de equilíbrio indisponível.
        dre = SimpleNamespace(
            receita_total=Decimal("50000"), resultado=Decimal("-15000"), compras=Decimal("0"),
            custos_variaveis=Decimal("5000"), custos_fixos=Decimal("60000"),
            margem_contribuicao=Decimal("45000"), pct=lambda valor: None,
        )
        tendencia = {"status": "sem_dado"}
        comprometimento = {"status": "sem_dado", "janelas": [{}], "vencidas": Decimal("0")}
        textos = " ".join(r["texto"] for r in gerar_recomendacoes(dre, None, tendencia, comprometimento, None, {}))
        self.assertNotIn("já passam", textos)
