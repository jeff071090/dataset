"""Testes do app `core` (Sprint 6 — padronização monetária, item 1; Sprint
de Consolidação — Gate 2A, P0-1: `seed_demo`).

Rode com: python manage.py test core
"""
import os
import subprocess
import sys
from datetime import date
from decimal import Decimal
from pathlib import Path
from unittest import mock

from django import forms
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase
from django.test.utils import override_settings

from .forms import MoedaFormMixin
from .utils import formatar_moeda


class FormatarMoedaTestCase(TestCase):
    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_formata_com_separador_de_milhar_e_duas_casas(self):
        self.assertEqual(formatar_moeda(Decimal("52500")), "52.500,00")

    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_formata_valor_sem_casas_decimais_originais(self):
        self.assertEqual(formatar_moeda(Decimal("1234.5")), "1.234,50")

    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_formata_zero(self):
        self.assertEqual(formatar_moeda(Decimal("0")), "0,00")

    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_formata_negativo(self):
        self.assertEqual(formatar_moeda(Decimal("-500.4")), "-500,40")

    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_com_prefixo(self):
        self.assertEqual(formatar_moeda(Decimal("10"), incluir_prefixo=True), "R$ 10,00")

    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_arredonda_como_o_floatformat_dos_templates_em_vez_de_truncar(self):
        """Crítico funcional (rodada 1): 28.260 ÷ 22 = 1.284,5454… — o
        cabeçalho do Comprador (texto montado em Python) mostrava
        "R$ 1.284,54" e a barra lateral/calendário (floatformat) "1.284,55"."""
        from django.template.defaultfilters import floatformat

        limite = Decimal("28260") / 22
        self.assertEqual(formatar_moeda(limite, incluir_prefixo=True), "R$ 1.284,55")
        self.assertEqual(formatar_moeda(limite), floatformat(limite, 2))
        self.assertEqual(formatar_moeda(Decimal("0.999"), incluir_prefixo=True), "R$ 1,00")
        self.assertEqual(formatar_moeda(Decimal("0.005")), "0,01")
        self.assertEqual(formatar_moeda(Decimal("-415.455")), "-415,46")
        self.assertEqual(formatar_moeda(1284.545454), "1.284,55")


class MoedaFormMixinTestCase(TestCase):
    """Só os campos listados em `campos_moeda` ganham máscara — os demais
    `DecimalField` do form (ex.: quantidade, percentual) continuam com o
    widget padrão do Django."""

    def _form_class(self):
        class FormTeste(MoedaFormMixin, forms.Form):
            campos_moeda = ("valor",)
            valor = forms.DecimalField()
            quantidade = forms.DecimalField()

        return FormTeste

    def test_campo_moeda_vira_text_input_localizado(self):
        form = self._form_class()()
        self.assertIsInstance(form.fields["valor"].widget, forms.TextInput)
        self.assertTrue(form.fields["valor"].localize)
        self.assertEqual(form.fields["valor"].widget.attrs.get("data-nx-moeda"), "true")

    def test_campo_fora_da_lista_nao_e_alterado(self):
        form = self._form_class()()
        self.assertNotIsInstance(form.fields["quantidade"].widget, forms.TextInput)
        self.assertIsNone(form.fields["quantidade"].widget.attrs.get("data-nx-moeda"))

    @override_settings(USE_THOUSAND_SEPARATOR=True)
    def test_aceita_valor_formatado_em_pt_br(self):
        form = self._form_class()(data={"valor": "1.234,56", "quantidade": "2"})
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["valor"], Decimal("1234.56"))


class SeedDemoTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, P0-1): o Gate encontrou o `seed_demo`
    sem NENHUM teste automatizado, apesar de ser a base de toda demonstração
    comercial. Cobre: idempotência real (rodar 2x não duplica nada, nem
    notificações), receita ancorada no mês ATUAL independente do dia, os 6
    usuários (incluindo Carla/demo_comprador3, ausente até esta Sprint) e o
    Fluxo de Aprovação multi-etapa na empresa PRINCIPAL (P1-4 — antes só
    existia numa 2ª empresa sem nenhum comprador, logo nunca demonstrável)."""

    def test_idempotente_rodar_duas_vezes_nao_duplica(self):
        from cadastros.models import Categoria
        from compras.models import Compra, Fornecedor
        from empresas.models import Empresa
        from gestao_compras.models import Provisao
        from notificacoes.models import Notificacao
        from usuarios.models import Usuario

        call_command("seed_demo")

        empresa = Empresa.objects.get(cnpj="98765432000198")
        contagens_apos_primeira_execucao = {
            "empresas": Empresa.objects.filter(cnpj__startswith="98765432").count(),
            "usuarios": Usuario.objects.filter(username__startswith="demo_").count(),
            "fornecedores": Fornecedor.objects.filter(empresa=empresa).count(),
            "categorias": Categoria.objects.filter(empresa=empresa).count(),
            "compras": Compra.objects.filter(filial__empresa=empresa).count(),
            "provisoes": Provisao.objects.filter(filial__empresa=empresa).count(),
            "notificacoes": Notificacao.objects.filter(empresa=empresa).count(),
        }
        self.assertEqual(contagens_apos_primeira_execucao["empresas"], 2)
        self.assertEqual(contagens_apos_primeira_execucao["usuarios"], 6)

        call_command("seed_demo")

        contagens_apos_segunda_execucao = {
            "empresas": Empresa.objects.filter(cnpj__startswith="98765432").count(),
            "usuarios": Usuario.objects.filter(username__startswith="demo_").count(),
            "fornecedores": Fornecedor.objects.filter(empresa=empresa).count(),
            "categorias": Categoria.objects.filter(empresa=empresa).count(),
            "compras": Compra.objects.filter(filial__empresa=empresa).count(),
            "provisoes": Provisao.objects.filter(filial__empresa=empresa).count(),
            "notificacoes": Notificacao.objects.filter(empresa=empresa).count(),
        }
        self.assertEqual(contagens_apos_segunda_execucao, contagens_apos_primeira_execucao)

    def test_receita_do_mes_atual_sempre_existe_independente_do_dia(self):
        from empresas.models import Empresa
        from filiais.models import Filial
        from financeiro.models import Receita

        call_command("seed_demo")

        empresa = Empresa.objects.get(cnpj="98765432000198")
        filial = Filial.objects.get(empresa=empresa, nome="Loja Centro")
        receita = Receita.objects.get(filial=filial, mes=date.today().replace(day=1))
        self.assertGreater(receita.faturamento, Decimal("0"))

    def test_seis_usuarios_incluindo_carla_bloqueada(self):
        from usuarios.models import Usuario, UsuarioEmpresa

        call_command("seed_demo")

        carla = Usuario.objects.get(username="demo_comprador3")
        self.assertEqual(carla.perfil, Usuario.Perfil.COMPRADOR)
        self.assertEqual(carla.first_name, "Carla")
        autorizacao = UsuarioEmpresa.objects.get(usuario=carla, empresa=carla.empresa)
        self.assertTrue(autorizacao.bloqueado)

    def test_fluxo_de_aprovacao_multietapa_na_empresa_principal(self):
        """P1-4: o fluxo Gerente→Financeiro precisa estar na empresa
        PRINCIPAL (onde há compradores de verdade) — não mais só na 2ª
        empresa, que não tem nenhum comprador para exercitá-lo ao vivo."""
        from empresas.models import Empresa
        from gestao_compras.models import FluxoAprovacao
        from usuarios.models import Usuario

        call_command("seed_demo")

        principal = Empresa.objects.get(cnpj="98765432000198")
        segunda = Empresa.objects.get(cnpj="98765432000279")

        fluxo = FluxoAprovacao.objects.get(empresa=principal, ativo=True)
        etapas = list(fluxo.etapas_ordenadas())
        self.assertEqual(len(etapas), 2)
        self.assertEqual(etapas[0].perfil_aprovador, Usuario.Perfil.GERENTE)
        self.assertFalse(FluxoAprovacao.objects.filter(empresa=segunda).exists())

    def test_provisao_aprovada_do_seed_percorre_o_fluxo_ate_o_fim(self):
        """A provisão "aprovada em seguida" do roteiro precisa terminar
        realmente APROVADA mesmo com o fluxo multi-etapa ativo — se ela
        exceder a alçada do Gerente, o seed precisa completar a 2ª etapa
        (Financeiro) sozinho, não parar "aguardando o Financeiro"."""
        from gestao_compras.models import Provisao

        call_command("seed_demo")

        provisao = Provisao.objects.get(
            filial__empresa__cnpj="98765432000198", comprador__username="demo_comprador2",
            fornecedor__nome="Laboratório Vitalis",
        )
        self.assertEqual(provisao.status, Provisao.Status.APROVADA)

    def test_segunda_filial_e_vinculos_multifilial(self):
        """Sprint de Correções Críticas (Seção 7/9): a demonstração ganhou
        uma 2ª Filial DENTRO da empresa principal (diferente da 2ª empresa,
        que já existia) — o Financeiro e o 2º Comprador de demonstração
        ficam explicitamente vinculados às duas via `UsuarioFilial`, o
        cenário que a Sprint corrigiu de verdade."""
        from empresas.models import Empresa
        from filiais.models import Filial
        from usuarios.models import Usuario, UsuarioFilial, filiais_autorizadas_para

        call_command("seed_demo")

        empresa = Empresa.objects.get(cnpj="98765432000198")
        self.assertEqual(
            set(Filial.objects.filter(empresa=empresa).values_list("nome", flat=True)),
            {"Loja Centro", "Loja Bairro"},
        )

        financeiro = Usuario.objects.get(username="demo_financeiro")
        comprador2 = Usuario.objects.get(username="demo_comprador2")
        for usuario in (financeiro, comprador2):
            self.assertEqual(
                set(UsuarioFilial.objects.filter(usuario=usuario, ativo=True).values_list("filial__nome", flat=True)),
                {"Loja Centro", "Loja Bairro"},
            )
            self.assertEqual(
                set(filiais_autorizadas_para(usuario, empresa).values_list("nome", flat=True)),
                {"Loja Centro", "Loja Bairro"},
            )

    def test_compra_de_demonstracao_na_loja_bairro(self):
        """A 2ª filial não fica vazia — o 2º Comprador (autorizado nas
        duas) lança uma Compra real lá, exercitando o seletor de filial de
        Nova Compra ao vivo.

        Regra ajustada (demonstração da Análise Financeira): a Loja Bairro
        passou a ter também 12 meses de HISTÓRICO de compras aprovadas
        (sempre em dias anteriores a hoje) — sem isso a DRE "Todas as
        filiais" somava a receita da loja com compra zero. O contrato
        continua o mesmo e fica mais estrito: HOJE existe exatamente UMA
        compra na Loja Bairro (`.get()`), a lançada pelo service por Pedro,
        e o histórico existe só no passado.

        REGRA MUDOU (ajuste final, produto-e-demo): com o seed rodado num
        sábado, domingo ou feriado, a compra "de hoje" caía num dia sem
        limite e o Dashboard Executivo abria com "Capacidade de hoje
        excedida". Ela agora é datada no DIA DE REFERÊNCIA do seed — hoje
        num dia útil (o contrato antigo, inalterado), senão o último dia
        anterior que conta capacidade. Como esse dia pode ser anterior a
        hoje (e ter compras do histórico), a busca exclui o histórico."""
        from compras.models import Compra
        from core.management.commands.seed_demo import Command as SeedDemo
        from filiais.models import Filial

        call_command("seed_demo")

        filial_bairro = Filial.objects.get(empresa__cnpj="98765432000198", nome="Loja Bairro")
        dia_referencia = SeedDemo._dia_de_referencia(filial_bairro.empresa, date.today())
        compra = Compra.objects.exclude(observacao__startswith="[DEMO] Histórico").get(
            filial=filial_bairro, data_compra=dia_referencia
        )
        self.assertEqual(compra.usuario.username, "demo_comprador2")
        self.assertFalse(compra.observacao.startswith("[DEMO] Histórico"))
        # Nada da história ao vivo cai num dia sem limite.
        self.assertFalse(
            Compra.objects.filter(filial=filial_bairro, data_compra__gt=dia_referencia)
            .exclude(observacao__startswith="[DEMO] Histórico").exists()
        )
        self.assertTrue(
            Compra.objects.filter(filial=filial_bairro, data_compra__lt=date.today(), status=Compra.Status.APROVADA).exists()
        )
        self.assertFalse(Compra.objects.filter(filial=filial_bairro, data_compra__gt=date.today()).exists())

    def test_provisao_efetivada_do_seed_gera_compra_vinculada(self):
        """Sprint de Correções Críticas (Seção 12): a demonstração ganhou um
        6º desfecho de Provisão — aprovada E efetivada — mostrando o fluxo
        Provisão -> Compra real que antes desta Sprint nunca era alcançado
        por nenhum caminho do sistema."""
        from decimal import Decimal

        from compras.models import Compra
        from gestao_compras.models import Provisao

        call_command("seed_demo")

        provisao = Provisao.objects.get(
            filial__empresa__cnpj="98765432000198", status=Provisao.Status.EFETIVADA,
        )
        compra = Compra.objects.get(provisao_origem=provisao)
        self.assertEqual(compra.valor, provisao.valor_total)
        self.assertGreaterEqual(compra.parcelas.count(), 1)
        self.assertEqual(sum((p.valor for p in compra.parcelas.all()), Decimal("0")), compra.valor)

    def test_todos_os_nao_proprietarios_ativos_tem_vinculo_filial_explicito(self):
        """Prompt 2, Gate C (Seção 7): a auditoria encontrou demo_gerente,
        demo_comprador e demo_comprador3 sem NENHUM `UsuarioFilial`
        explícito — dependiam do fallback legado. Usuários do `seed_demo`
        não são contas legadas."""
        from usuarios.models import Usuario, UsuarioFilial

        call_command("seed_demo")

        nao_proprietarios = Usuario.objects.filter(
            is_active=True, username__startswith="demo_",
        ).exclude(perfil=Usuario.Perfil.PROPRIETARIO)
        self.assertGreaterEqual(nao_proprietarios.count(), 5)
        for usuario in nao_proprietarios:
            self.assertTrue(
                UsuarioFilial.objects.filter(usuario=usuario, ativo=True).exists(),
                f"{usuario.username} não tem UsuarioFilial explícito ativo",
            )

    def test_todas_as_filiais_ativas_do_seed_estao_completas(self):
        """Prompt 2, Gate C (Seção 6): zero Filiais ativas incompletas no
        banco de demonstração — a regressão específica era `Loja Norte`
        sem telefone."""
        from filiais.models import Filial

        call_command("seed_demo")

        incompletas = [f.nome for f in Filial.objects.filter(ativo=True) if not f.cadastro_completo]
        self.assertEqual(incompletas, [])

    def test_compra_rejeitada_e_bloqueada_do_seed(self):
        """Pacote de Demonstração Comercial (Etapa 02): o roteiro de Compras
        só demonstrava Aprovada e Pendente — `_criar_compra_rejeitada_e_
        bloqueada` completa os outros dois status de `Compra.Status`."""
        from compras.models import Compra

        call_command("seed_demo")

        empresa_principal = "98765432000198"
        rejeitada = Compra.objects.get(
            filial__empresa__cnpj=empresa_principal, status=Compra.Status.REJEITADA,
        )
        self.assertEqual(rejeitada.usuario.username, "demo_comprador2")

        bloqueada = Compra.objects.get(
            filial__empresa__cnpj=empresa_principal, status=Compra.Status.BLOQUEADA,
        )
        self.assertEqual(bloqueada.usuario.username, "demo_comprador3")

        # Idempotência: rodar de novo não duplica nenhum dos dois cenários.
        call_command("seed_demo")
        self.assertEqual(
            Compra.objects.filter(
                filial__empresa__cnpj=empresa_principal, status=Compra.Status.REJEITADA,
            ).count(),
            1,
        )
        self.assertEqual(
            Compra.objects.filter(
                filial__empresa__cnpj=empresa_principal, status=Compra.Status.BLOQUEADA,
            ).count(),
            1,
        )


class SeedDemoDiasSemLimiteTestCase(TestCase):
    """Ajuste final (produto-e-demo): (1) seed rodado num sábado, domingo ou
    feriado datava os itens "de hoje" num dia sem limite — o Dashboard
    Executivo abria com dois "Capacidade de hoje excedida" e as lojas em
    "Excedido"; (2) o feriado de exemplo do Calendário Operacional podia
    cair num domingo (dia que já não tem limite — o exemplo não mostrava
    efeito nenhum)."""

    def test_dia_de_referencia_pula_fim_de_semana_e_feriado(self):
        from core.management.commands.seed_demo import Command as SeedDemo
        from empresas.models import Empresa
        from financeiro.models import DiaOperacional

        empresa = Empresa.objects.create(nome="Farmácia Calendário Seed", cnpj="64.000.000/0001-64")
        self.assertEqual(SeedDemo._dia_de_referencia(empresa, date(2026, 9, 28)), date(2026, 9, 28))  # segunda
        self.assertEqual(SeedDemo._dia_de_referencia(empresa, date(2026, 9, 27)), date(2026, 9, 25))  # domingo
        self.assertEqual(SeedDemo._dia_de_referencia(empresa, date(2026, 9, 26)), date(2026, 9, 25))  # sábado
        DiaOperacional.objects.create(empresa=empresa, data=date(2026, 9, 25), tipo=DiaOperacional.Tipo.FERIADO)
        self.assertEqual(SeedDemo._dia_de_referencia(empresa, date(2026, 9, 27)), date(2026, 9, 24))
        # Domingo, 1º do mês: volta para o último dia útil do mês anterior.
        self.assertEqual(SeedDemo._dia_de_referencia(empresa, date(2026, 11, 1)), date(2026, 10, 30))

    def test_feriado_e_bloqueio_de_exemplo_nunca_caem_em_fim_de_semana(self):
        from datetime import timedelta

        from core.management.commands import seed_demo
        from empresas.models import Empresa
        from financeiro.models import DiaOperacional

        empresa = Empresa.objects.create(nome="Farmácia Exemplos Seed", cnpj="65.000.000/0001-65")

        class DataFixa(date):
            valor = None

            @classmethod
            def today(cls):
                return cls.valor

        dia = date(2026, 1, 1)
        with mock.patch.object(seed_demo, "date", DataFixa):
            while dia <= date(2027, 12, 31):
                DataFixa.valor = dia
                criadas = seed_demo.Command()._criar_calendario_operacional(empresa)
                tipos = {registro.tipo for registro in criadas}
                self.assertIn(DiaOperacional.Tipo.BLOQUEADO, tipos, dia)
                self.assertIn(DiaOperacional.Tipo.FERIADO, tipos, dia)
                for registro in criadas:
                    if registro.tipo in (DiaOperacional.Tipo.FERIADO, DiaOperacional.Tipo.BLOQUEADO):
                        self.assertLess(registro.data.weekday(), 5, f"hoje={dia}: {registro.tipo} em {registro.data}")
                dia += timedelta(days=1)

    def test_seed_nao_abre_com_capacidade_de_hoje_excedida_em_dia_sem_limite(self):
        from compras.models import Compra
        from core.management.commands.seed_demo import Command as SeedDemo
        from filiais.models import Filial
        from finance_engine.alertas import gerar_alertas
        from finance_engine.calendario_operacional import dia_conta_capacidade, tipo_do_dia

        call_command("seed_demo")
        hoje = date.today()
        for nome in ("Loja Centro", "Loja Bairro"):
            loja = Filial.objects.get(empresa__cnpj="98765432000198", nome=nome)
            ao_vivo = Compra.objects.filter(filial=loja, status=Compra.Status.APROVADA).exclude(
                observacao__startswith="[DEMO] Histórico"
            )
            if dia_conta_capacidade(tipo_do_dia(loja.empresa, hoje)):
                # Dia útil: o contrato de sempre — o item "de hoje" é de hoje.
                self.assertEqual(SeedDemo._dia_de_referencia(loja.empresa, hoje), hoje)
                self.assertTrue(ao_vivo.filter(data_compra=hoje).exists(), nome)
            else:
                self.assertFalse(ao_vivo.filter(data_compra=hoje).exists(), nome)
                titulos = [alerta.titulo for alerta in gerar_alertas(loja, hoje)]
                self.assertNotIn("Capacidade de hoje excedida", titulos, nome)
                dia_referencia = SeedDemo._dia_de_referencia(loja.empresa, hoje)
                self.assertTrue(ao_vivo.filter(data_compra=dia_referencia).exists(), nome)


class SeedProducaoGuardTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, Parte 10): `seed_demo`/`seed_dados`
    criam usuários com a senha pública `nexbuy123` (documentada em
    DEMO_MODE.md) — nunca podem rodar em produção real (DEBUG=False) sem a
    autorização explícita ALLOW_SEED_IN_PRODUCTION=True.

    O test runner do Django força DEBUG=False durante toda a suíte (ver o
    comentário de `nexbuy.settings.TESTING`) — por isso os testes que
    simulam "produção de verdade" precisam desligar TESTING também via
    `override_settings`, senão estariam testando o próprio mecanismo que os
    deixa passar, não o bloqueio em si."""

    @override_settings(DEBUG=False, TESTING=False)
    def test_seed_demo_aborta_em_producao_por_padrao(self):
        with self.assertRaises(CommandError):
            call_command("seed_demo")

    @override_settings(DEBUG=False, TESTING=False)
    def test_seed_dados_aborta_em_producao_por_padrao(self):
        with self.assertRaises(CommandError):
            call_command("seed_dados")

    @override_settings(DEBUG=False, TESTING=False)
    def test_seed_demo_roda_com_autorizacao_explicita(self):
        from empresas.models import Empresa

        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            call_command("seed_demo")
        self.assertTrue(Empresa.objects.filter(cnpj="98765432000198").exists())

    @override_settings(DEBUG=False, TESTING=False)
    def test_seed_dados_roda_com_autorizacao_explicita(self):
        from empresas.models import Empresa

        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            call_command("seed_dados")
        self.assertTrue(Empresa.objects.filter(cnpj="12345678000195").exists())

    @override_settings(DEBUG=True, TESTING=False)
    def test_guard_nao_atrapalha_desenvolvimento_normal(self):
        # Cenário real do dia a dia: um dev roda "python manage.py
        # seed_demo" na própria máquina (DEBUG=True), fora de qualquer
        # suíte de testes — por isso TESTING=False aqui, sem depender do
        # sinal que só existe dentro do "manage.py test".
        from empresas.models import Empresa

        call_command("seed_dados")
        self.assertTrue(Empresa.objects.filter(cnpj="12345678000195").exists())

    def test_guard_nao_atrapalha_a_propria_suite_de_testes(self):
        # Sem nenhum override: é exatamente o ambiente real do "manage.py
        # test" (DEBUG=False forçado pelo runner, TESTING=True) — o resto
        # da suíte (SeedDemoTestCase etc.) depende de seed_demo funcionar
        # aqui sem exigir ALLOW_SEED_IN_PRODUCTION.
        from empresas.models import Empresa

        call_command("seed_demo")
        self.assertTrue(Empresa.objects.filter(cnpj="98765432000198").exists())


class SettingsProducaoTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, Parte 10): `settings.py` só decide
    isso na hora de o processo subir (não a cada requisição), então os dois
    primeiros testes rodam num processo Python separado (`manage.py check`)
    para validar de verdade o `DEBUG=False` real — `override_settings` não
    serviria aqui, porque o bloco de segurança já rodou (ou não) quando o
    módulo `settings.py` foi importado pela primeira vez, muito antes de
    qualquer teste começar."""

    BASE_DIR = Path(__file__).resolve().parent.parent

    def _rodar_check(self, **env_overrides):
        ambiente = {**os.environ, **{k: str(v) for k, v in env_overrides.items()}}
        return subprocess.run(
            [sys.executable, "manage.py", "check"],
            cwd=self.BASE_DIR,
            env=ambiente,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=60,
        )

    def test_recusa_subir_em_producao_com_secret_key_insegura(self):
        resultado = self._rodar_check(
            DEBUG="False", SECRET_KEY="django-insecure-nexbuy-dev-key-troque-em-producao"
        )
        self.assertNotEqual(resultado.returncode, 0)
        self.assertIn("SECRET_KEY", resultado.stderr)

    def test_sobe_em_producao_com_secret_key_real(self):
        resultado = self._rodar_check(DEBUG="False", SECRET_KEY="x" * 60, ALLOWED_HOSTS="exemplo.com.br")
        self.assertEqual(resultado.returncode, 0, resultado.stderr)

    def test_hardening_nao_se_aplica_em_desenvolvimento(self):
        # O processo de teste atual já subiu com DEBUG=True (padrão do
        # projeto) — o bloco `if not DEBUG` nunca rodou, então estes
        # atributos ficam no default inseguro-para-produção do próprio
        # Django, confirmando que o hardening não vaza para o dia a dia.
        from django.conf import settings

        self.assertFalse(settings.SECURE_SSL_REDIRECT)
        self.assertFalse(settings.SESSION_COOKIE_SECURE)
        self.assertFalse(settings.CSRF_COOKIE_SECURE)


class BackfillParcelasOrfasTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 15/19): Compras Aprovadas
    lançadas antes do Épico 4 (Compras Parceladas) existir nunca ganharam
    `ParcelaCompra` — o compromisso delas não aparece na Agenda Financeira,
    em Contas a Pagar nem em Parcelamentos. `diagnosticar_parcelas_orfas` é
    somente leitura; `backfill_parcelas_orfas` grava (respeitando
    --dry-run) e é idempotente — rodar de novo depois de corrigido não
    encontra mais nada a fazer."""

    def setUp(self):
        from io import StringIO

        from cadastros.models import Categoria
        from compras.models import Compra, Fornecedor, ParcelaCompra
        from empresas.models import Empresa
        from filiais.models import Filial
        from usuarios.models import Usuario

        self.StringIO = StringIO
        self.ParcelaCompra = ParcelaCompra
        self.empresa = Empresa.objects.create(nome="Empresa Backfill", cnpj="96.000.000/0001-96")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Backfill")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Backfill")
        self.comprador = Usuario.objects.create_user(
            username="comprador_backfill", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        # Simula uma Compra histórica (pré-Épico 4): Aprovada, sem NENHUMA
        # parcela — criada direto, sem passar por `avaliar_e_criar_compra`/
        # `gerar_parcelas_da_compra`.
        self.compra_orfa = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, usuario=self.comprador,
            valor=Decimal("777.77"), categoria=self.categoria, data_compra=date(2026, 1, 10),
            prazo_pagamento=Compra.PrazoPagamento.D30_60_90, prazo_personalizado_dias=None,
            numero_parcelas=3, status=Compra.Status.APROVADA, observacao="",
        )

    def test_diagnostico_e_somente_leitura(self):
        saida = self.StringIO()
        call_command("diagnosticar_parcelas_orfas", stdout=saida)
        texto = saida.getvalue()
        self.assertIn(f"Compra #{self.compra_orfa.pk}", texto)
        self.assertIn("Fornecedor Backfill", texto)
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).count(), 0)

    def test_backfill_dry_run_nao_grava_nada(self):
        saida = self.StringIO()
        call_command("backfill_parcelas_orfas", "--dry-run", stdout=saida)
        texto = saida.getvalue()
        self.assertIn("SIMULAÇÃO", texto)
        self.assertIn("Nada foi gravado", texto)
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).count(), 0)

    def test_backfill_real_gera_parcelas_com_soma_exata(self):
        saida = self.StringIO()
        call_command("backfill_parcelas_orfas", stdout=saida)
        parcelas = list(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).order_by("numero"))
        self.assertEqual(len(parcelas), 3)  # prazo D30_60_90
        self.assertEqual(sum(p.valor for p in parcelas), Decimal("777.77"))
        self.assertIn("1 compra(s) corrigida(s)", saida.getvalue())

    def test_backfill_e_idempotente_na_segunda_execucao(self):
        call_command("backfill_parcelas_orfas", stdout=self.StringIO())
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).count(), 3)

        saida_segunda = self.StringIO()
        call_command("backfill_parcelas_orfas", stdout=saida_segunda)
        self.assertIn("Nenhuma Compra Aprovada sem parcelas encontrada", saida_segunda.getvalue())
        # Não duplicou nada na segunda execução.
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).count(), 3)

    @override_settings(DEBUG=False, TESTING=False)
    def test_backfill_aborta_em_producao_por_padrao(self):
        with self.assertRaises(CommandError):
            call_command("backfill_parcelas_orfas", "--dry-run", stdout=self.StringIO())
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).count(), 0)

    @override_settings(DEBUG=False, TESTING=False)
    def test_backfill_roda_em_producao_com_autorizacao_explicita(self):
        with mock.patch.dict(os.environ, {"ALLOW_BACKFILL_IN_PRODUCTION": "True"}):
            call_command("backfill_parcelas_orfas", "--dry-run", stdout=self.StringIO())
        # --dry-run continua sem gravar nada, mesmo com a autorização.
        self.assertEqual(self.ParcelaCompra.objects.filter(compra=self.compra_orfa).count(), 0)


class DiagnosticarAutorizacoesForaDoGrupoTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 4.3: `UsuarioEmpresa` ativos
    cujo Grupo diverge do Grupo da empresa principal do usuário nunca
    concedem acesso de verdade (`empresas_disponiveis()` já os ignora),
    mas o dado inconsistente em si precisa ser encontrável e, se pedido
    explicitamente, corrigível sem apagar histórico."""

    def setUp(self):
        from io import StringIO

        from empresas.models import Empresa, GrupoEmpresarial
        from usuarios.models import Usuario, UsuarioEmpresa

        self.StringIO = StringIO
        self.UsuarioEmpresa = UsuarioEmpresa

        grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo Diagnostico 1")
        grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo Diagnostico 2")
        self.empresa_principal = Empresa.objects.create(
            nome="Empresa Principal Diagnostico", cnpj="96.111.111/0001-96", grupo=grupo_1,
        )
        self.empresa_mesmo_grupo = Empresa.objects.create(
            nome="Empresa Mesmo Grupo Diagnostico", cnpj="96.222.222/0001-96", grupo=grupo_1,
        )
        self.empresa_outro_grupo = Empresa.objects.create(
            nome="Empresa Outro Grupo Diagnostico", cnpj="96.333.333/0001-96", grupo=grupo_2,
        )
        self.usuario = Usuario.objects.create_user(
            username="usuario_diagnostico_grupo", password="x", empresa=self.empresa_principal,
        )
        self.autorizacao_valida = UsuarioEmpresa.objects.create(
            usuario=self.usuario, empresa=self.empresa_mesmo_grupo, ativo=True,
        )
        self.autorizacao_inconsistente = UsuarioEmpresa.objects.create(
            usuario=self.usuario, empresa=self.empresa_outro_grupo, ativo=True,
        )

    def test_diagnostico_encontra_a_autorizacao_fora_do_grupo(self):
        saida = self.StringIO()
        call_command("diagnosticar_autorizacoes_fora_do_grupo", stdout=saida)
        texto = saida.getvalue()
        self.assertIn("usuario_diagnostico_grupo", texto)
        self.assertIn("Empresa Outro Grupo Diagnostico", texto)
        self.assertNotIn("Empresa Mesmo Grupo Diagnostico", texto)

    def test_sem_flag_nao_altera_nada_padrao_seguro(self):
        call_command("diagnosticar_autorizacoes_fora_do_grupo", stdout=self.StringIO())
        self.autorizacao_inconsistente.refresh_from_db()
        self.assertTrue(self.autorizacao_inconsistente.ativo)

    def test_dry_run_explicito_nao_altera_nada(self):
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--dry-run", stdout=self.StringIO())
        self.autorizacao_inconsistente.refresh_from_db()
        self.assertTrue(self.autorizacao_inconsistente.ativo)

    def test_corrigir_desativa_sem_apagar(self):
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--corrigir", stdout=self.StringIO())
        self.autorizacao_inconsistente.refresh_from_db()
        self.assertFalse(self.autorizacao_inconsistente.ativo)
        self.assertTrue(self.UsuarioEmpresa.objects.filter(pk=self.autorizacao_inconsistente.pk).exists())
        # A autorização válida (mesmo Grupo) nunca é tocada.
        self.autorizacao_valida.refresh_from_db()
        self.assertTrue(self.autorizacao_valida.ativo)

    def test_corrigir_e_idempotente(self):
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--corrigir", stdout=self.StringIO())
        saida_segunda = self.StringIO()
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--corrigir", stdout=saida_segunda)
        self.assertIn("Nenhuma autorização", saida_segunda.getvalue())

    def test_dry_run_e_corrigir_juntos_e_erro(self):
        with self.assertRaises(CommandError):
            call_command(
                "diagnosticar_autorizacoes_fora_do_grupo", "--dry-run", "--corrigir", stdout=self.StringIO(),
            )


class DiagnosticoTambemEncontraVinculoDeFilialForaDoGrupoTestCase(TestCase):
    """Revisão adversarial (Fechamento Final): o comando original só
    checava `UsuarioEmpresa`, deixando um ponto cego — um `UsuarioFilial`
    apontando para uma filial de empresa fora do Grupo (vínculo direto, ou
    órfão depois que um `--corrigir` anterior desativou só a autorização de
    empresa correspondente) nunca era listado nem corrigido. A extensão do
    comando fecha esse ponto cego."""

    def setUp(self):
        from io import StringIO

        from empresas.models import Empresa, GrupoEmpresarial
        from filiais.models import Filial
        from usuarios.models import Usuario, UsuarioFilial

        self.StringIO = StringIO
        self.UsuarioFilial = UsuarioFilial

        grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo Diagnostico Filial 1")
        grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo Diagnostico Filial 2")
        self.empresa_principal = Empresa.objects.create(
            nome="Empresa Principal Diagnostico Filial", cnpj="97.111.111/0001-97", grupo=grupo_1,
        )
        self.empresa_outro_grupo = Empresa.objects.create(
            nome="Empresa Outro Grupo Diagnostico Filial", cnpj="97.222.222/0001-97", grupo=grupo_2,
        )
        self.filial_principal = Filial.objects.create(empresa=self.empresa_principal, nome="Filial Principal")
        self.filial_outro_grupo = Filial.objects.create(empresa=self.empresa_outro_grupo, nome="Filial Outro Grupo")

        self.usuario = Usuario.objects.create_user(
            username="usuario_diagnostico_vinculo_filial", password="x", empresa=self.empresa_principal,
        )
        self.vinculo_valido = UsuarioFilial.objects.create(
            usuario=self.usuario, filial=self.filial_principal, ativo=True,
        )
        # Vínculo direto para uma filial de empresa de outro Grupo, SEM
        # nenhum `UsuarioEmpresa` correspondente — exatamente o caso que o
        # comando original não enxergava.
        self.vinculo_inconsistente = UsuarioFilial.objects.create(
            usuario=self.usuario, filial=self.filial_outro_grupo, ativo=True,
        )

    def test_diagnostico_encontra_o_vinculo_de_filial_fora_do_grupo(self):
        saida = self.StringIO()
        call_command("diagnosticar_autorizacoes_fora_do_grupo", stdout=saida)
        texto = saida.getvalue()
        self.assertIn("usuario_diagnostico_vinculo_filial", texto)
        self.assertIn("Filial Outro Grupo", texto)
        self.assertNotIn("Filial Principal", texto)

    def test_corrigir_desativa_o_vinculo_sem_apagar(self):
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--corrigir", stdout=self.StringIO())
        self.vinculo_inconsistente.refresh_from_db()
        self.assertFalse(self.vinculo_inconsistente.ativo)
        self.assertTrue(self.UsuarioFilial.objects.filter(pk=self.vinculo_inconsistente.pk).exists())
        self.vinculo_valido.refresh_from_db()
        self.assertTrue(self.vinculo_valido.ativo)

    def test_corrigir_e_idempotente_para_vinculo_de_filial(self):
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--corrigir", stdout=self.StringIO())
        saida_segunda = self.StringIO()
        call_command("diagnosticar_autorizacoes_fora_do_grupo", "--corrigir", stdout=saida_segunda)
        self.assertIn("Nenhuma autorização", saida_segunda.getvalue())


class BuscaGlobalCrossTenantTestCase(TestCase):
    """`busca_global` (`/buscar/`) nunca tinha nenhum teste no repo, apesar
    de filtrar `Fornecedor` diretamente por `empresa=empresa_ativa(request)`
    — o ponto mais direto de vazamento cross-tenant da tela. NOTA: o perfil
    logado aqui é Proprietário, não Gerente — `resultados["fornecedores"]`
    só é populado quando `request.user.perfil in PERFIS_GESTORES_FINANCEIROS`
    (`core/views.py`, ~linha 154), e essa constante é
    `(Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO)`
    (`core/permissions.py`) — Gerente NÃO está nela. Com um Gerente logado a
    busca de Fornecedor nunca roda (a lista fica sempre vazia), o que
    tornaria o teste de "encontra fornecedor da própria empresa" inútil
    (passaria por vacuidade, não por checar isolamento real); Proprietário é
    o perfil mínimo que de fato exercita o filtro `empresa=empresa_ativa`."""

    def setUp(self):
        from compras.models import Fornecedor
        from empresas.models import Empresa
        from usuarios.models import Usuario

        self.Fornecedor = Fornecedor

        self.empresa_a = Empresa.objects.create(nome="Empresa Busca Global A", cnpj="95.111.111/0001-95")
        self.empresa_b = Empresa.objects.create(nome="Empresa Busca Global B", cnpj="95.222.222/0001-95")

        self.usuario_a = Usuario.objects.create_user(
            username="proprietario_busca_global_a", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa_a,
        )
        self.fornecedor_b = Fornecedor.objects.create(empresa=self.empresa_b, nome="Fornecedor Exclusivo B")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_busca_global_nunca_retorna_fornecedor_de_outra_empresa(self):
        from django.test import Client

        client = Client()
        client.force_login(self.usuario_a)
        resposta = client.get("/buscar/", {"q": "Exclusivo"})
        self.assertEqual(resposta.status_code, 200)
        self.assertNotContains(resposta, "Fornecedor Exclusivo B")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_busca_global_encontra_fornecedor_da_propria_empresa(self):
        from django.test import Client

        self.Fornecedor.objects.create(empresa=self.empresa_a, nome="Fornecedor Proprio A")

        client = Client()
        client.force_login(self.usuario_a)
        resposta = client.get("/buscar/", {"q": "Proprio"})
        self.assertContains(resposta, "Fornecedor Proprio A")


class ValidarCnpjTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 4.4: dígito verificador de CNPJ
    construído do zero (módulo 11, duas passadas). Em vez de confiar num
    CNPJ "real" decorado (risco de errar de memória), o teste central gera
    a própria base e os próprios dígitos verificadores via o algoritmo
    documentado e confere que o validador aceita o resultado — uma prova
    de consistência interna do cálculo, não uma tabela de dados externos."""

    def _gerar_cnpj_valido(self, base12: str) -> str:
        from core.validators import PESOS_CNPJ_PRIMEIRO_DIGITO, PESOS_CNPJ_SEGUNDO_DIGITO, \
            _calcular_digito_verificador_cnpj

        primeiro = _calcular_digito_verificador_cnpj(base12, PESOS_CNPJ_PRIMEIRO_DIGITO)
        segundo = _calcular_digito_verificador_cnpj(base12 + primeiro, PESOS_CNPJ_SEGUNDO_DIGITO)
        return base12 + primeiro + segundo

    def test_cnpj_gerado_pelo_proprio_algoritmo_e_aceito(self):
        from core.validators import cnpj_e_valido

        for base12 in ("112223330001", "123456780001", "987654320001"):
            cnpj = self._gerar_cnpj_valido(base12)
            self.assertTrue(cnpj_e_valido(cnpj), f"{cnpj} deveria ser válido (gerado pelo próprio algoritmo)")

    def test_cnpj_com_mascara_tambem_e_aceito(self):
        from core.validators import cnpj_e_valido

        cnpj_limpo = self._gerar_cnpj_valido("111222330001")
        cnpj_mascarado = f"{cnpj_limpo[:2]}.{cnpj_limpo[2:5]}.{cnpj_limpo[5:8]}/{cnpj_limpo[8:12]}-{cnpj_limpo[12:]}"
        self.assertTrue(cnpj_e_valido(cnpj_mascarado))

    def test_digito_verificador_errado_e_rejeitado(self):
        from core.validators import cnpj_e_valido

        cnpj = self._gerar_cnpj_valido("111222330001")
        ultimo_digito_trocado = cnpj[:-1] + str((int(cnpj[-1]) + 1) % 10)
        self.assertFalse(cnpj_e_valido(ultimo_digito_trocado))

    def test_todos_os_digitos_iguais_e_sempre_rejeitado(self):
        """Armadilha clássica do módulo 11 (mesma do CPF): uma sequência
        com todos os dígitos iguais pode até bater matematicamente com o
        checksum, mas nunca é um CNPJ real emitido."""
        from core.validators import cnpj_e_valido

        for digito in "1234567890":
            self.assertFalse(cnpj_e_valido(digito * 14))

    def test_tamanho_errado_e_rejeitado(self):
        from core.validators import cnpj_e_valido

        self.assertFalse(cnpj_e_valido("123456789"))
        self.assertFalse(cnpj_e_valido(""))
        self.assertFalse(cnpj_e_valido(None))

    def test_validar_cnpj_model_validator_aceita_valido_e_rejeita_invalido(self):
        from django.core.exceptions import ValidationError

        from core.validators import validar_cnpj

        cnpj_valido = self._gerar_cnpj_valido("111222330001")
        validar_cnpj(cnpj_valido)  # não levanta

        with self.assertRaises(ValidationError):
            validar_cnpj("11.111.111/1111-11")

    def test_inscricao_estadual_estruturalmente_plausivel(self):
        from core.validators import inscricao_estadual_estruturalmente_plausivel as ie_plausivel

        self.assertTrue(ie_plausivel("123.456.789.012"))
        self.assertTrue(ie_plausivel("12345678"))
        self.assertFalse(ie_plausivel(""))
        self.assertFalse(ie_plausivel("1"))
        self.assertFalse(ie_plausivel("abc"))


class DiagnosticarFiliaisTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 4.4/4.5: comando somente-leitura
    que lista Filiais com cadastro fiscal incompleto — nunca corrige (não
    há valor certo para preencher sozinho)."""

    def setUp(self):
        from io import StringIO

        from empresas.models import Empresa
        from filiais.models import Filial

        self.StringIO = StringIO
        self.empresa = Empresa.objects.create(nome="Empresa Diagnostico Filial", cnpj="54.000.000/0001-54")
        self.filial_incompleta = Filial.objects.create(empresa=self.empresa, nome="Filial Incompleta")
        self.filial_completa = Filial.objects.create(
            empresa=self.empresa, nome="Filial Completa", cnpj="11222333000181",
            razao_social="Filial Completa Comércio Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", numero="1", bairro="Centro", cidade="Cuiabá",
            estado="MT", cep="78000-000", telefone="(65) 99999-1111",
            responsavel_nome="Fulano de Tal", responsavel_telefone="(65) 99999-0000",
        )
        self.filial_inativa_incompleta = Filial.objects.create(
            empresa=self.empresa, nome="Filial Inativa Incompleta", ativo=False,
        )

    def test_lista_apenas_filiais_ativas_incompletas(self):
        saida = self.StringIO()
        call_command("diagnosticar_filiais", stdout=saida)
        texto = saida.getvalue()
        self.assertIn("Filial Incompleta", texto)
        self.assertNotIn("Filial Completa", texto)
        self.assertNotIn("Filial Inativa Incompleta", texto)

    def test_indica_o_que_esta_faltando(self):
        saida = self.StringIO()
        call_command("diagnosticar_filiais", stdout=saida)
        texto = saida.getvalue()
        self.assertIn("CNPJ", texto)
        self.assertIn("endereço completo", texto)

    def test_nenhuma_incompleta_reporta_sucesso(self):
        self.filial_incompleta.delete()
        self.filial_inativa_incompleta.delete()
        saida = self.StringIO()
        call_command("diagnosticar_filiais", stdout=saida)
        self.assertIn("Nenhuma Filial", saida.getvalue())

    def test_dry_run_explicito_funciona_igual(self):
        saida = self.StringIO()
        call_command("diagnosticar_filiais", "--dry-run", stdout=saida)
        self.assertIn("Filial Incompleta", saida.getvalue())

    def test_nunca_altera_nenhum_dado(self):
        call_command("diagnosticar_filiais", stdout=self.StringIO())
        self.filial_incompleta.refresh_from_db()
        self.assertTrue(self.filial_incompleta.ativo)
        self.assertIsNone(self.filial_incompleta.cnpj)


class ProprietarioOperacionalTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 6: "Proprietário Operacional" —
    um Proprietário precisa ter acesso funcional COMPLETO usando só o
    RBAC nativo (perfil + `CATALOGO_PERMISSOES`), nunca precisando de
    `is_staff`/`is_superuser` (essas duas flags só abrem o /admin/ cru do
    Django, fora do RBAC da aplicação — não deveriam ser um requisito para
    o dono do negócio operar o próprio sistema). Este teste é o contrato:
    cria um Proprietário deliberadamente SEM as duas flags e confirma que
    ele alcança todas as telas de gestão que importam."""

    def setUp(self):
        from django.test import Client

        from empresas.models import Empresa
        from filiais.models import Filial
        from usuarios.models import Usuario

        self.Usuario = Usuario
        self.empresa = Empresa.objects.create(nome="Empresa Proprietario Operacional", cnpj="64.000.000/0001-64")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_operacional", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
            is_staff=False, is_superuser=False,
        )
        self.assertFalse(self.proprietario.is_staff)
        self.assertFalse(self.proprietario.is_superuser)
        self.client = Client()
        self.client.force_login(self.proprietario)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_acessa_todas_as_telas_de_gestao_sem_is_staff_nem_is_superuser(self):
        urls_get_200 = [
            "/ncc/", "/ncc/gerais/", "/ncc/estrutura/", "/ncc/filiais/", "/ncc/filiais/nova/",
            "/ncc/usuarios/", "/ncc/usuarios/novo/", "/ncc/perfis/", "/ncc/motor/", "/ncc/workflow/",
            "/empresas/", "/empresas/identidade-visual/",
        ]
        for url in urls_get_200:
            with self.subTest(url=url):
                resposta = self.client.get(url)
                self.assertEqual(resposta.status_code, 200, f"{url} deveria devolver 200, deu {resposta.status_code}")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_edita_dados_da_empresa_sem_is_staff_nem_is_superuser(self):
        resposta = self.client.post("/empresas/", {
            "razao_social": "Empresa Proprietario Operacional Ltda", "nome": "Empresa Proprietario Operacional",
            "inscricao_estadual": "", "telefone": "", "email": "", "endereco": "", "cidade": "", "estado": "",
            "cep": "",
        })
        self.assertEqual(resposta.status_code, 302)
        self.empresa.refresh_from_db()
        self.assertEqual(self.empresa.razao_social, "Empresa Proprietario Operacional Ltda")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_aprova_provisao_de_outro_usuario_sem_is_staff_nem_is_superuser(self):
        from cadastros.models import Categoria
        from compras.models import Fornecedor
        from financeiro.models import ConfiguracaoFinanceira, Receita
        from gestao_compras.services import criar_provisao

        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=20,
        )
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("100000"))
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Prop Operacional")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Prop Operacional")
        comprador = self.Usuario.objects.create_user(
            username="comprador_prop_operacional", password="x", perfil=self.Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        _, solicitacao, excedeu = criar_provisao(
            filial=self.filial, comprador=comprador, fornecedor=fornecedor, categoria=categoria,
            data_provisao=date.today(), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 999999}],
        )
        self.assertTrue(excedeu)

        resposta = self.client.post(
            f"/gestao-compras/aprovacao/{solicitacao.pk}/aprovar/", {"justificativa": "aprovado pelo dono"}
        )
        self.assertEqual(resposta.status_code, 302)
        solicitacao.refresh_from_db()
        self.assertEqual(solicitacao.status, solicitacao.Status.APROVADA)
