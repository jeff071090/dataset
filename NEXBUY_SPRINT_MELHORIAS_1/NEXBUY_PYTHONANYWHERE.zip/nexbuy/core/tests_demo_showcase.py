"""Demo Comercial Showcase — testes obrigatórios (Seção 13 do prompt).

Cobrem exatamente o que o Showcase adicionou ou promete:

1. Launchers novos (`PREPARAR/INICIAR/RESETAR_DEMO_NEXBUY.bat` +
   `demo_abrir_navegador.py`) — mesmas garantias mecânicas dos launchers
   antigos (settings_demo em toda chamada de manage.py, nunca escrever em
   `db.sqlite3` nem em `.env`) mais as novas (porta, espera de HTTP 200,
   confirmação do reset).
2. Troca de perfil de demonstração (Seção 7) — só existe em DEMO_MODE,
   logout REAL, prefill por whitelist, nunca ecoa valor arbitrário.
3. Cenário do seed (Seção 4) — login real dos 4 perfis com as credenciais
   publicadas, datas relativas (amanhã/7 dias/histórico), dia bloqueado,
   CNPJs fictícios matematicamente válidos.
4. Golden path (Seção 6) — provisão dentro do limite, acima do limite,
   aprovação pelo Gerente/Financeiro, status refletido, agenda e auditoria.
5. Menus sem 403/500 (Seção 13) — TODO link autorizado da sidebar e da
   barra mobile dos 4 perfis responde 200/302, nunca 403/404/500.

Nenhum teste existente foi alterado ou removido por este arquivo.
"""
import re
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.core.management import call_command
from django.test import Client, SimpleTestCase, TestCase, override_settings

BASE_DIR = Path(settings.BASE_DIR)

LAUNCHERS_SHOWCASE = [
    "PREPARAR_DEMO_NEXBUY.bat",
    "INICIAR_DEMO_NEXBUY.bat",
    "RESETAR_DEMO_NEXBUY.bat",
]

SETTINGS_DEMO_FLAG = "--settings=nexbuy.settings_demo"

# Mesmo critério do core/tests_pacote_demo.py: menção a db.sqlite3 em linha
# de COMANDO (não echo/REM) combinada com escrita/redirecionamento é proibida.
PALAVRAS_ESCRITA = ("del ", "erase ", "copy ", "move ", "ren ", "rd ", "rmdir", ">", ">>")

CREDENCIAIS_DEMO = [
    ("demo_proprietario", "proprietario"),
    ("demo_gerente", "gerente"),
    ("demo_financeiro", "financeiro"),
    ("demo_comprador", "comprador"),
]
SENHA_DEMO = "nexbuy123"

# Termos financeiros sensíveis que NUNCA podem chegar ao HTML do Comprador
# (mesma varredura por string das suítes RC/Etapa 02).
TERMOS_PROIBIDOS_COMPRADOR = ("Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal")


def _ler(nome_arquivo: str) -> str:
    return (BASE_DIR / nome_arquivo).read_text(encoding="utf-8")


class LaunchersShowcaseTestCase(SimpleTestCase):
    """Seção 8 — os 3 launchers novos, com as garantias mecânicas herdadas
    dos antigos MAIS as novas exigidas pelo Showcase."""

    def test_launchers_e_helper_existem(self):
        for nome_arquivo in LAUNCHERS_SHOWCASE + ["demo_abrir_navegador.py"]:
            self.assertTrue((BASE_DIR / nome_arquivo).exists(), f"{nome_arquivo} não existe")

    def test_toda_chamada_manage_py_usa_settings_demo(self):
        for nome_arquivo in LAUNCHERS_SHOWCASE:
            texto = _ler(nome_arquivo)
            linhas_manage = [
                linha for linha in texto.splitlines()
                if "manage.py" in linha and not linha.strip().upper().startswith("REM")
            ]
            self.assertTrue(linhas_manage, f"{nome_arquivo}: nenhuma chamada a manage.py")
            for linha in linhas_manage:
                self.assertIn(
                    SETTINGS_DEMO_FLAG, linha,
                    f"{nome_arquivo}: chamada a manage.py sem {SETTINGS_DEMO_FLAG} -> {linha!r}",
                )

    def test_nenhuma_referencia_de_escrita_a_db_sqlite3(self):
        for nome_arquivo in LAUNCHERS_SHOWCASE:
            for numero, linha in enumerate(_ler(nome_arquivo).splitlines(), start=1):
                if "db.sqlite3" not in linha.lower():
                    continue
                normalizada = linha.strip().lower()
                eh_informativa = normalizada.startswith("echo") or normalizada.startswith("rem")
                if any(p in normalizada for p in PALAVRAS_ESCRITA) and not eh_informativa:
                    self.fail(f"{nome_arquivo}:{numero}: referência de escrita a db.sqlite3 -> {linha!r}")

    def test_launchers_nunca_gravam_em_env(self):
        for nome_arquivo in LAUNCHERS_SHOWCASE:
            self.assertNotRegex(
                _ler(nome_arquivo), r">>?\s*\.env\b",
                f"{nome_arquivo}: não pode gravar nada em .env",
            )

    def test_preparar_valida_python_migra_semeia_e_checa(self):
        texto = _ler("PREPARAR_DEMO_NEXBUY.bat")
        self.assertIn("python --version", texto)
        self.assertIn("sys.version_info >= (3, 12)", texto)
        self.assertIn("python -m venv venv", texto)
        self.assertIn("pip install -r requirements.txt", texto)
        self.assertIn(f"migrate --noinput {SETTINGS_DEMO_FLAG}", texto)
        self.assertIn(f"seed_demo {SETTINGS_DEMO_FLAG}", texto)
        self.assertIn(f"check {SETTINGS_DEMO_FLAG}", texto)

    def test_iniciar_detecta_porta_espera_http_e_valida_preparacao(self):
        texto = _ler("INICIAR_DEMO_NEXBUY.bat")
        self.assertIn("netstat", texto)
        self.assertIn(":verificar_porta", texto)
        self.assertIn("demo_abrir_navegador.py", texto)
        self.assertIn("PREPARAR_DEMO_NEXBUY.bat", texto)  # instrução de próximo passo nos erros
        self.assertIn("set DEMO_MODE=True", texto)
        self.assertRegex(texto, r"runserver 127\.0\.0\.1:%PORT% " + re.escape(SETTINGS_DEMO_FLAG))

    def test_helper_so_abre_navegador_com_http_200_local(self):
        texto = _ler("demo_abrir_navegador.py")
        self.assertIn("127.0.0.1", texto)
        self.assertIn("resposta.status == 200", texto)
        self.assertIn("webbrowser.open", texto)
        # Sem internet e sem serviço externo (Seção 2): nenhuma URL http(s)
        # que não seja o loopback local.
        for url_externa in re.findall(r"https?://[^\s\"']+", texto):
            self.assertIn("127.0.0.1", url_externa, f"URL externa proibida no helper: {url_externa}")

    def test_nenhum_echo_com_parenteses_dentro_de_bloco_if(self):
        """Regressão real (corretiva pós-V2): um `echo` com parênteses
        DENTRO de um bloco `if (...)` do cmd fecha o bloco no meio e mata o
        parse do script inteiro ("... foi inesperado neste momento") — foi
        exatamente assim que o INICIAR quebrou no Windows real, e o mesmo
        bug já tinha derrubado o resetar antigo. Parênteses em echo são
        permitidos SÓ fora de blocos."""
        for nome_arquivo in LAUNCHERS_SHOWCASE:
            profundidade = 0
            for numero, linha in enumerate(_ler(nome_arquivo).splitlines(), start=1):
                limpa = linha.strip()
                if profundidade > 0 and limpa.lower().startswith("echo"):
                    self.assertNotRegex(
                        limpa, r"[()]",
                        f"{nome_arquivo}:{numero}: echo com parêntese dentro de bloco if -> {linha!r}",
                    )
                if limpa == ")" or limpa.startswith(") else"):
                    profundidade = max(0, profundidade - 1)
                if limpa.endswith("("):
                    profundidade += 1

    def test_resetar_pede_confirmacao_e_recria_o_cenario(self):
        texto = _ler("RESETAR_DEMO_NEXBUY.bat")
        self.assertIn('set /p CONFIRMA=', texto)
        self.assertIn('"%CONFIRMA%"=="SIM"', texto)
        self.assertIn("db_demo_cliente.sqlite3", texto)
        self.assertIn("media_demo_cliente", texto)
        self.assertIn(f"seed_demo {SETTINGS_DEMO_FLAG}", texto)
        # A exclusão é sempre pelo nome exato de demo — nunca um glob.
        self.assertNotIn("*.sqlite3", texto)


class TrocaPerfilDemoTestCase(TestCase):
    """Seção 7 — troca de perfil exclusiva do DEMO_MODE, sem bypass."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo")

    def _login(self, username):
        ok = self.client.login(username=username, password=SENHA_DEMO)
        assert ok, f"login de {username} falhou"

    @override_settings(DEMO_MODE=True)
    def test_atalho_e_reiniciar_tour_aparecem_no_menu_em_demo_mode(self):
        self._login("demo_proprietario")
        resposta = self.client.get("/")
        self.assertContains(resposta, "Trocar perfil de demonstração")
        self.assertContains(resposta, "Reiniciar tour")

    @override_settings(DEMO_MODE=False)
    def test_atalho_nao_existe_fora_do_demo_mode(self):
        self._login("demo_proprietario")
        resposta = self.client.get("/")
        self.assertNotContains(resposta, "Trocar perfil de demonstração")
        self.assertNotContains(resposta, "Reiniciar tour")
        # E nem por POST direto: a rota devolve 404.
        resposta = self.client.post("/demo/trocar-perfil/", {"usuario": "demo_gerente"})
        self.assertEqual(resposta.status_code, 404)

    @override_settings(DEMO_MODE=True)
    def test_troca_encerra_a_sessao_e_preenche_o_login(self):
        self._login("demo_proprietario")
        resposta = self.client.post("/demo/trocar-perfil/", {"usuario": "demo_gerente"})
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(resposta.url, "/accounts/login/?usuario=demo_gerente")
        # Sessão realmente encerrada (logout de verdade, não troca mágica):
        resposta_dashboard = self.client.get("/")
        self.assertEqual(resposta_dashboard.status_code, 302)
        self.assertIn("/accounts/login/", resposta_dashboard.url)
        # Login com o usuário preenchido — e a senha continua obrigatória
        # (o form é o LoginView normal do Django).
        resposta_login = self.client.get("/accounts/login/?usuario=demo_gerente")
        self.assertContains(resposta_login, 'value="demo_gerente"')
        self.assertContains(resposta_login, 'type="password"')

    @override_settings(DEMO_MODE=True)
    def test_username_fora_da_whitelist_e_rejeitado(self):
        self._login("demo_proprietario")
        resposta = self.client.post("/demo/trocar-perfil/", {"usuario": "admin"})
        self.assertEqual(resposta.status_code, 404)

    @override_settings(DEMO_MODE=True)
    def test_prefill_nunca_ecoa_valor_arbitrario_da_url(self):
        resposta = self.client.get("/accounts/login/?usuario=<script>alert(1)</script>")
        self.assertEqual(resposta.status_code, 200)
        self.assertNotContains(resposta, "alert(1)")
        resposta = self.client.get("/accounts/login/?usuario=usuario_inventado")
        self.assertNotContains(resposta, 'value="usuario_inventado"')

    @override_settings(DEMO_MODE=True)
    def test_troca_exige_post_e_login(self):
        self._login("demo_proprietario")
        self.assertEqual(self.client.get("/demo/trocar-perfil/").status_code, 405)
        self.client.logout()
        resposta = self.client.post("/demo/trocar-perfil/", {"usuario": "demo_gerente"})
        self.assertEqual(resposta.status_code, 302)
        self.assertIn("/accounts/login/", resposta.url)


class SeedShowcaseTestCase(TestCase):
    """Seção 4 — o cenário fictício funciona em QUALQUER dia do calendário."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo")

    def test_login_real_dos_quatro_perfis_com_as_credenciais_publicadas(self):
        for username, _ in CREDENCIAIS_DEMO:
            client = Client()
            self.assertTrue(
                client.login(username=username, password=SENHA_DEMO),
                f"login de {username} com a senha publicada falhou",
            )
            resposta = client.get("/")
            self.assertEqual(resposta.status_code, 200, f"dashboard de {username}")

    def test_provisao_de_amanha_sempre_existe(self):
        from gestao_compras.models import Provisao

        amanha = date.today() + timedelta(days=1)
        self.assertTrue(
            Provisao.objects.filter(filial__empresa__cnpj="98765432000198", data=amanha).exists(),
            "a provisão de amanhã precisa existir mesmo na virada de mês",
        )

    def test_historia_passada_sempre_existe(self):
        from compras.models import Compra

        hoje = date.today()
        passadas = Compra.objects.filter(
            filial__empresa__cnpj="98765432000198", data_compra__lte=hoje
        ).count()
        self.assertGreaterEqual(passadas, 4, "dashboards/relatórios nunca podem abrir vazios")

    def test_vencimento_de_compra_em_janela_proxima(self):
        from compras.models import ParcelaCompra

        hoje = date.today()
        janela = (hoje - timedelta(days=3), hoje + timedelta(days=14))
        self.assertTrue(
            ParcelaCompra.objects.filter(
                compra__filial__empresa__cnpj="98765432000198",
                data_vencimento__range=janela,
            ).exists(),
            "a Agenda precisa ter vencimento de compra em janela próxima, em qualquer data",
        )

    def test_dia_bloqueado_para_compras_existe(self):
        from financeiro.models import DiaOperacional

        self.assertTrue(
            DiaOperacional.objects.filter(
                empresa__cnpj="98765432000198", tipo=DiaOperacional.Tipo.BLOQUEADO,
            ).exists()
        )

    def test_todos_os_cnpjs_ficticios_sao_matematicamente_validos(self):
        from compras.models import Fornecedor
        from core.validators import cnpj_e_valido
        from empresas.models import Empresa
        from filiais.models import Filial

        for empresa in Empresa.objects.filter(cnpj__startswith="98765432"):
            self.assertTrue(cnpj_e_valido(empresa.cnpj), f"Empresa {empresa.nome}: {empresa.cnpj}")
        for filial in Filial.objects.filter(empresa__cnpj__startswith="98765432"):
            if filial.cnpj:
                self.assertTrue(cnpj_e_valido(filial.cnpj), f"Filial {filial.nome}: {filial.cnpj}")
        for fornecedor in Fornecedor.objects.filter(empresa__cnpj="98765432000198"):
            self.assertTrue(cnpj_e_valido(fornecedor.cnpj), f"Fornecedor {fornecedor.nome}: {fornecedor.cnpj}")

    def test_custo_variavel_em_data_proxima(self):
        from financeiro.models import CustoVariavel

        hoje = date.today()
        custo = CustoVariavel.objects.get(
            filial__nome="Loja Centro", descricao="Campanha Sazonal de Inverno"
        )
        self.assertGreaterEqual(custo.data_prevista, hoje)
        self.assertLessEqual(custo.data_prevista, hoje + timedelta(days=10))

    def test_receitas_dos_meses_vizinhos_existem(self):
        from financeiro.models import Receita

        mes_atual = date.today().replace(day=1)
        mes_anterior = (mes_atual - timedelta(days=1)).replace(day=1)
        mes_seguinte = (mes_atual + timedelta(days=32)).replace(day=1)
        for mes in (mes_anterior, mes_atual, mes_seguinte):
            self.assertTrue(
                Receita.objects.filter(filial__nome="Loja Centro", mes=mes).exists(),
                f"Receita da Loja Centro ausente para {mes:%m/%Y}",
            )

    def test_calendario_do_comprador_marca_o_dia_nao_operacional(self):
        """Correção real do Showcase: `obter_calendario_mensal` nunca
        repassava `tipo_dia` — o template pintava todo dia como útil."""
        from filiais.models import Filial
        from financeiro.models import DiaOperacional
        from gestao_compras.services import obter_calendario_mensal

        excecao = (
            DiaOperacional.objects.filter(empresa__cnpj="98765432000198")
            .order_by("data").first()
        )
        self.assertIsNotNone(excecao)
        filial = Filial.objects.get(empresa__cnpj="98765432000198", nome="Loja Centro")
        dias = obter_calendario_mensal(filial, excecao.data.year, excecao.data.month)
        dia = next(d for d in dias if d["data"] == excecao.data)
        self.assertEqual(dia["tipo_dia"], excecao.tipo)


class GoldenPathShowcaseTestCase(TestCase):
    """Seção 6 — a história contínua da apresentação, executada de verdade
    pelas views (nunca por ORM direto nos passos do apresentador)."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo")

    def _login(self, username):
        ok = self.client.login(username=username, password=SENHA_DEMO)
        assert ok, f"login de {username} falhou"

    def _post_provisao(self, fornecedor, categoria, filial, valor: str, data_provisao):
        return self.client.post("/gestao-compras/nova/", {
            "filial": filial.pk, "fornecedor": fornecedor.pk, "categoria": categoria.pk,
            "data": data_provisao.isoformat(), "observacoes": "Golden path do Showcase.",
            "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0",
            "itens-MIN_NUM_FORMS": "0", "itens-MAX_NUM_FORMS": "1000",
            "itens-0-produto": "Item golden path", "itens-0-quantidade": "1",
            "itens-0-valor_unitario": valor, "itens-0-id": "",
        })

    def test_golden_path_completo_provisao_aprovacao_reflexo_auditoria(self):
        from cadastros.models import Categoria
        from compras.models import Fornecedor
        from filiais.models import Filial
        from gestao_compras.models import Provisao, SolicitacaoAprovacao

        filial = Filial.objects.get(empresa__cnpj="98765432000198", nome="Loja Centro")
        fornecedor = Fornecedor.objects.create(empresa=filial.empresa, nome="Fornecedor Golden Path")
        categoria = Categoria.objects.get(empresa=filial.empresa, nome="Medicamentos")
        hoje = date.today()
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem
        # limite próprio — numa quinta/sexta, "hoje + 2" cai no sábado/
        # domingo. A premissa do passo 3 ("dentro do limite") fica explícita.
        from core.utils_testes import garantir_capacidade_no_dia

        data_provisao = garantir_capacidade_no_dia(filial.empresa, hoje + timedelta(days=2))

        # 3) Comprador registra uma provisão DENTRO do limite.
        self._login("demo_comprador")
        resposta = self._post_provisao(fornecedor, categoria, filial, "50,00", data_provisao)
        self.assertEqual(resposta.status_code, 302, resposta.content[:300])
        provisao_dentro = Provisao.objects.latest("pk")
        self.assertEqual(provisao_dentro.status, Provisao.Status.PROVISIONADA)

        # 4) Provisão ACIMA do limite — vira solicitação pendente.
        resposta = self._post_provisao(fornecedor, categoria, filial, "99999,00", data_provisao)
        self.assertEqual(resposta.status_code, 302, resposta.content[:300])
        provisao_acima = Provisao.objects.latest("pk")
        self.assertEqual(provisao_acima.status, Provisao.Status.AGUARDANDO_APROVACAO)
        solicitacao = SolicitacaoAprovacao.objects.get(provisao=provisao_acima)
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.PENDENTE)

        # 5) Gerente abre a fila e aprova (1ª etapa do fluxo).
        self._login("demo_gerente")
        fila = self.client.get("/gestao-compras/aprovacao/")
        self.assertContains(fila, "Fornecedor Golden Path")
        resposta = self.client.post(
            f"/gestao-compras/aprovacao/{solicitacao.pk}/aprovar/",
            {"justificativa": "Aprovado na demonstração."},
        )
        self.assertEqual(resposta.status_code, 302)
        solicitacao.refresh_from_db()
        if solicitacao.status == SolicitacaoAprovacao.Status.PENDENTE:
            # Acima da alçada do Gerente (R$ 2.000) o fluxo avança para o
            # Financeiro — 2ª etapa, decidida por ele. Regra real do motor.
            self._login("demo_financeiro")
            resposta = self.client.post(
                f"/gestao-compras/aprovacao/{solicitacao.pk}/aprovar/",
                {"justificativa": "Aprovado pelo Financeiro na demonstração."},
            )
            self.assertEqual(resposta.status_code, 302)
            solicitacao.refresh_from_db()
        self.assertEqual(solicitacao.status, SolicitacaoAprovacao.Status.APROVADA)
        provisao_acima.refresh_from_db()
        self.assertEqual(provisao_acima.status, Provisao.Status.APROVADA)

        # 6) Comprador vê o status atualizado na timeline.
        self._login("demo_comprador")
        timeline = self.client.get(f"/gestao-compras/provisao/{provisao_acima.pk}/timeline/")
        self.assertEqual(timeline.status_code, 200)
        self.assertContains(timeline, "Aprovada")

        # 7) Financeiro vê o reflexo na agenda/planejamento (regras reais).
        self._login("demo_financeiro")
        agenda = self.client.get("/financeiro/agenda/")
        self.assertEqual(agenda.status_code, 200)
        self.assertContains(agenda, "Fornecedor Golden Path")

        # 8) Custos e contas a pagar respondem sem erro.
        self.assertEqual(self.client.get("/financeiro/contas-a-pagar/").status_code, 200)

        # 9) Proprietário confere relatório e auditoria da operação.
        self._login("demo_proprietario")
        self.assertEqual(self.client.get("/compras/relatorios/por-filial/").status_code, 200)
        auditoria = self.client.get("/ncc/central-auditoria/")
        self.assertEqual(auditoria.status_code, 200)
        from gestao_compras.models import HistoricoProvisao

        self.assertTrue(
            HistoricoProvisao.objects.filter(provisao=provisao_acima).exists(),
            "a aprovação precisa deixar trilha na timeline/histórico",
        )

    def test_comprador_nao_recebe_dados_financeiros_sensiveis(self):
        self._login("demo_comprador")
        for url in ("/", "/compras/nova/", "/gestao-compras/"):
            resposta = self.client.get(url)
            self.assertEqual(resposta.status_code, 200, url)
            html = resposta.content.decode("utf-8", errors="replace")
            for termo in TERMOS_PROIBIDOS_COMPRADOR:
                self.assertNotIn(termo, html, f"{url}: termo sensível '{termo}' vazou para o Comprador")

    def test_compradora_bloqueada_ve_o_bloqueio_no_dashboard(self):
        client = Client()
        self.assertTrue(client.login(username="demo_comprador3", password=SENHA_DEMO))
        resposta = client.get("/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Bloqueado")


class MenusSemErroShowcaseTestCase(TestCase):
    """Seção 13 — nenhum link autorizado dos 4 menus responde 403/404/500."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo")

    def _urls_do_menu(self, resposta):
        urls = []
        for entrada in resposta.context["nav_grupos"]:
            if entrada.get("link_unico"):
                urls.append(entrada["url"])
            else:
                urls.extend(item["url"] for item in entrada["itens"])
        urls.extend(item["url"] for item in resposta.context["nav_mobile"] if item.get("url"))
        return urls

    def test_todos_os_links_autorizados_dos_quatro_menus_respondem(self):
        for username, rotulo in CREDENCIAIS_DEMO:
            client = Client()
            self.assertTrue(client.login(username=username, password=SENHA_DEMO), username)
            inicial = client.get("/")
            self.assertEqual(inicial.status_code, 200, username)
            urls = self._urls_do_menu(inicial)
            self.assertTrue(urls, f"{username}: menu vazio?")
            for url in sorted(set(urls)):
                resposta = client.get(url)
                self.assertIn(
                    resposta.status_code, (200, 302),
                    f"{rotulo}: link autorizado {url} respondeu {resposta.status_code}",
                )

    def test_integracoes_continuam_nao_conectadas(self):
        client = Client()
        self.assertTrue(client.login(username="demo_proprietario", password=SENHA_DEMO))
        resposta = client.get("/ncc/integracoes/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Não conectado")


TERMOS_PROIBIDOS_HTML = ("None", "NaN", "Infinity", "Traceback (most recent", "Internal Server Error")
_CSRF = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')
URLS_ANALISE = ("/financeiro/analise/", "/financeiro/analise/creditos-debitos/", "/financeiro/analise/saude/")


def _mes_relativo(hoje, delta):
    indice = hoje.year * 12 + (hoje.month - 1) + delta
    return indice // 12, indice % 12 + 1


class AnaliseFinanceiraDemoTestCase(TestCase):
    """Demonstração da Análise Financeira: o histórico do `seed_demo` tem
    de parecer uma farmácia de verdade (antes: compras de ~3% da receita,
    margem bruta de ~97% e Saúde toda verde — irreal para a cliente) e os
    alertas precisam aparecer. Datas sempre relativas a hoje."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo")

    def _analise(self, *nomes_lojas):
        from filiais.models import Filial
        from financeiro.services_analise import AnaliseFinanceira

        filiais = Filial.objects.filter(empresa__cnpj="98765432000198", nome__in=nomes_lojas)
        self.assertEqual(filiais.count(), len(nomes_lojas))
        return AnaliseFinanceira(filiais, date.today())

    def test_doze_meses_de_historico_nas_duas_lojas(self):
        from compras.models import Compra
        from financeiro.models import CustoVariavel, Receita, ReceitaExtra

        hoje = date.today()
        for loja in ("Loja Centro", "Loja Bairro"):
            for delta in range(-11, 1):
                ano, mes = _mes_relativo(hoje, delta)
                filtro_mes = {"filial__nome": loja, "filial__empresa__cnpj": "98765432000198"}
                self.assertTrue(
                    Receita.objects.filter(mes__year=ano, mes__month=mes, **filtro_mes).exists(),
                    f"{loja}: sem receita em {mes:02d}/{ano}",
                )
                self.assertTrue(
                    ReceitaExtra.objects.filter(data__year=ano, data__month=mes, **filtro_mes).exists(),
                    f"{loja}: sem receita extra em {mes:02d}/{ano}",
                )
                self.assertTrue(
                    CustoVariavel.objects.filter(data_prevista__year=ano, data_prevista__month=mes, **filtro_mes).exists(),
                    f"{loja}: sem custo variável em {mes:02d}/{ano}",
                )
                if delta < 0:
                    self.assertTrue(
                        Compra.objects.filter(
                            data_compra__year=ano, data_compra__month=mes, status=Compra.Status.APROVADA, **filtro_mes
                        ).exists(),
                        f"{loja}: sem compra aprovada em {mes:02d}/{ano}",
                    )

    def test_dre_do_ultimo_mes_fechado_parece_farmacia(self):
        """Mês passado (fechado), nas duas visões que a demonstração usa:
        Todas as filiais (Proprietário/Financeiro) e Loja Centro (Gerente)."""
        hoje = date.today()
        ano, mes = _mes_relativo(hoje, -1)
        for lojas in (("Loja Centro", "Loja Bairro"), ("Loja Centro",)):
            dre = self._analise(*lojas).dre(ano, mes)
            self.assertTrue(dre.receita_configurada)
            with self.subTest(lojas=lojas):
                self.assertTrue(Decimal("58") <= dre.pct(dre.compras) <= Decimal("72"), dre.pct(dre.compras))
                self.assertTrue(Decimal("28") <= dre.pct(dre.margem_bruta) <= Decimal("42"), dre.pct(dre.margem_bruta))
                self.assertTrue(Decimal("18") <= dre.pct(dre.custos_fixos) <= Decimal("26"), dre.pct(dre.custos_fixos))
                self.assertTrue(Decimal("6") <= dre.pct(dre.custos_variaveis) <= Decimal("11"), dre.pct(dre.custos_variaveis))
                self.assertTrue(Decimal("0") < dre.pct(dre.resultado) <= Decimal("12"), dre.pct(dre.resultado))
                self.assertGreater(dre.receitas_extras, Decimal("0"))

    def test_curva_de_12_meses_varia_e_tem_um_mes_ruim(self):
        hoje = date.today()
        analise = self._analise("Loja Centro", "Loja Bairro")
        meses = analise.janela(hoje.year, hoje.month)
        self.assertEqual(len(meses), 12)
        serie = [analise.dre(*m) for m in meses]
        self.assertTrue(all(d.receita_configurada for d in serie))
        receitas = [d.receita_total for d in serie]
        self.assertGreaterEqual(max(receitas) / min(receitas), Decimal("1.08"), "curva de receita sem sazonalidade")
        com_prejuizo = [d.rotulo for d in serie if d.resultado < 0]
        self.assertEqual(len(com_prejuizo), 1, f"deveria haver exatamente um mês ruim: {com_prejuizo}")
        fechados = serie[:-1]
        self.assertTrue(
            any(d.pct(d.compras) > Decimal("73") for d in fechados), "o mês ruim precisa ter compras muito acima"
        )

    def test_creditos_debitos_mostra_o_caixa_no_vermelho_depois_do_mes_ruim(self):
        from financeiro.services_analise import montar_creditos_debitos

        hoje = date.today()
        dados = montar_creditos_debitos(self._analise("Loja Centro", "Loja Bairro"), hoje.year, hoje.month)
        self.assertEqual(len(dados["tabela"]), 12)
        saldos = [linha["caixa"].saldo for linha in dados["tabela"]]
        self.assertTrue(any(saldo < 0 for saldo in saldos), "nenhum mês com o caixa no vermelho")
        self.assertGreater(sum(saldos), Decimal("0"), "no acumulado de 12 meses a farmácia é lucrativa")
        self.assertGreater(dados["atual"].parcelas, Decimal("0"))

    def test_saude_do_mes_corrente_e_do_mes_fechado_tem_atencao_e_recomendacoes(self):
        """Mês corrente (abertura padrão da tela) e último mês fechado (o
        que o Guia abre até o dia 24): os dois com alerta de verdade."""
        from financeiro.services_analise import montar_saude

        hoje = date.today()
        for (ano, mes), lojas in (
            ((hoje.year, hoje.month), ("Loja Centro", "Loja Bairro")),
            ((hoje.year, hoje.month), ("Loja Centro",)),
            (_mes_relativo(hoje, -1), ("Loja Centro", "Loja Bairro")),
            (_mes_relativo(hoje, -1), ("Loja Centro",)),
        ):
            with self.subTest(lojas=lojas, mes=mes):
                saude = montar_saude(self._analise(*lojas), ano, mes)
                self.assertFalse(saude["sem_receita"])
                self.assertFalse(saude["lacunas"]["incompleto"])
                status_indicadores = [indicador["status"] for indicador in saude["indicadores"]]
                self.assertIn("atencao", status_indicadores)
                self.assertNotIn("sem_dado", status_indicadores)
                self.assertIn(saude["tendencia"]["status"], ("atencao", "critico"))
                alertas = [r for r in saude["recomendacoes"] if r["nivel"] in ("atencao", "critico")]
                self.assertGreaterEqual(len(alertas), 2, [r["texto"] for r in saude["recomendacoes"]])

    def test_historico_so_no_passado_com_parcelas_que_fecham(self):
        from django.db.models import Count, F

        from compras.models import Compra, ParcelaCompra

        hoje = date.today()
        historico = Compra.objects.filter(
            filial__empresa__cnpj="98765432000198", observacao__startswith="[DEMO] Histórico"
        )
        self.assertGreater(historico.count(), 100)
        self.assertFalse(historico.filter(data_compra__gte=hoje).exists(), "histórico nunca hoje nem no futuro")
        self.assertFalse(historico.exclude(status=Compra.Status.APROVADA).exists())
        # Soma em Python (Decimal): no SQLite o SUM() das parcelas volta em
        # ponto flutuante e a comparação no banco acusaria centavos fantasmas.
        somas = {}
        for compra_id, valor in ParcelaCompra.objects.filter(compra__in=historico).values_list("compra_id", "valor"):
            somas[compra_id] = somas.get(compra_id, Decimal("0")) + valor
        divergentes = [
            compra_id for compra_id, valor in historico.values_list("pk", "valor") if somas.get(compra_id) != valor
        ]
        self.assertEqual(divergentes, [], "soma das parcelas diferente do valor da compra")
        self.assertFalse(
            historico.annotate(quantidade=Count("parcelas")).exclude(quantidade=F("numero_parcelas")).exists()
        )
        self.assertFalse(
            ParcelaCompra.objects.filter(
                compra__in=historico, status=ParcelaCompra.Status.PENDENTE, data_vencimento__lt=hoje
            ).exists(),
            "parcela do histórico vencida e não paga",
        )

    def test_telas_da_analise_para_proprietario_gerente_e_financeiro(self):
        for username in ("demo_proprietario", "demo_gerente", "demo_financeiro"):
            client = Client()
            self.assertTrue(client.login(username=username, password=SENHA_DEMO))
            for url in URLS_ANALISE:
                with self.subTest(usuario=username, url=url):
                    resposta = client.get(url)
                    self.assertEqual(resposta.status_code, 200)
                    html = _CSRF.sub(r"\1\2", resposta.content.decode("utf-8"))
                    for termo in TERMOS_PROIBIDOS_HTML:
                        self.assertNotIn(termo, html)
                    self.assertIn("R$", html)

    def test_comprador_continua_sem_analise_nem_dado_financeiro(self):
        client = Client()
        self.assertTrue(client.login(username="demo_comprador", password=SENHA_DEMO))
        for url in URLS_ANALISE:
            self.assertEqual(client.get(url).status_code, 403, url)
        inicial = client.get("/")
        html = inicial.content.decode("utf-8")
        for termo in TERMOS_PROIBIDOS_COMPRADOR + ("Meta Mensal", "Análise Financeira", "/financeiro/analise/"):
            self.assertNotIn(termo, html, f"'{termo}' vazou para o Comprador")

    def test_guia_tem_a_cena_da_analise_financeira(self):
        js = (BASE_DIR / "static" / "js" / "guia_apresentacao.js").read_text(encoding="utf-8")
        cenas = js.split("var CENAS = [", 1)[1].split("];", 1)[0]
        self.assertIn("A farmácia está saudável?", cenas)
        self.assertIn('href: "/financeiro/analise/"', cenas)
        for tela in ("DRE", "Créditos × Débitos", "Saúde Financeira"):
            self.assertIn(tela, cenas)
        self.assertNotIn("isNaN", js)
        self.assertNotIn("NaN", js)
