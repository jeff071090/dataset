"""Modo Apresentação — Sprint de Apresentação Comercial (Seções 5 e 9).

Duas telas exclusivas da demonstração: a ABERTURA (`/demo/apresentacao/`,
com o mapa de valor embutido) e o ENCERRAMENTO (`/demo/encerramento/`).

Regras de segurança comercial (Seção 13 do prompt):

- Fora do modo demo (`settings.DEMO_MODE=False`) as rotas devolvem 404 —
  não existem, não renderizam, não respondem.
- Nenhuma das telas exige ou concede acesso: a abertura leva ao LOGIN REAL
  (com o usuário de demonstração pré-preenchido pela whitelist já testada
  da troca de perfil — a senha continua obrigatória); o encerramento só
  tem links de navegação. Nenhum bypass, nenhum formulário, nenhuma
  escrita em banco, nenhuma chamada externa.
"""
from django.conf import settings
from django.http import Http404
from django.shortcuts import render


def _somente_demo():
    if not settings.DEMO_MODE:
        raise Http404


def demo_apresentacao(request):
    """Tela de abertura da apresentação comercial (Seção 5.1) + mapa de
    valor (Seção 5.2, na mesma página — o botão secundário o revela)."""
    _somente_demo()
    return render(request, "core/demo_apresentacao.html")


def demo_encerramento(request):
    """Tela de encerramento da apresentação (Seção 9)."""
    _somente_demo()
    return render(request, "core/demo_encerramento.html")
