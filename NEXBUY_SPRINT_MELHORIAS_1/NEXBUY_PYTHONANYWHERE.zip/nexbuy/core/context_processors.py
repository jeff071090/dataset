"""Context processors globais do NEXBUY."""
from django.conf import settings

from empresas.models import IdentidadeVisual


def contexto_core(request):
    """Contexto do CORE 1.0, disponível em toda página autenticada:
    empresa ativa + empresas disponíveis (Épico 9), contador de
    notificações não lidas (Épico 11) e permissões do RBAC usadas pelo
    menu (Épico 7). Consultas mínimas e por requisição."""
    if not hasattr(request, "user") or not request.user.is_authenticated:
        return {}
    from core.contexto import empresa_ativa
    from core.permissions import usuario_tem_permissao
    from notificacoes.services import contar_nao_lidas

    empresa = empresa_ativa(request)
    empresas = list(request.user.empresas_disponiveis())

    # Épico 2A.5 (visual): card "Capacidade do dia" na sidebar — a posição
    # de HOJE do Motor (dado diário que estes perfis já veem nos próprios
    # dashboards; nenhum número confidencial novo). Um widget decorativo
    # jamais pode derrubar uma página: qualquer erro aqui degrada para
    # "sem card", silenciosamente.
    sidebar_capacidade = None
    if request.user.filial_id:
        try:
            from datetime import date

            from finance_engine.calculations import calcular_percentual_utilizado
            from finance_engine.services import motor_financeiro

            from usuarios.models import Usuario

            hoje = date.today()
            if request.user.perfil == Usuario.Perfil.COMPRADOR:
                # Crítico funcional (rodada 1): para o Comprador, o card usa
                # a MESMA resposta do dashboard dele ("quanto ainda posso
                # comprar hoje" = menor entre dotação e filial, com a % na
                # mesma base) — antes mostrava só a filial.
                from dashboard.viewmodels import capacidade_do_comprador_hoje

                capacidade = capacidade_do_comprador_hoje(request.user, request.user.filial, hoje)
                disponivel = capacidade["capacidade_disponivel"]
                limite = capacidade["base_do_percentual"]
                utilizado = capacidade["utilizado_na_base"]
                percentual = capacidade["percentual_utilizado"]
                cor = capacidade["cor_do_dia"]
                rotulo_limite = (
                    "Minha dotação" if capacidade["capacidade_limitada_por"] == "dotacao_pessoal"
                    else "Limite do dia"
                )
            else:
                posicao = motor_financeiro.posicao_do_dia(request.user.filial, hoje)
                disponivel = posicao.saldo_do_dia
                limite = posicao.limite_efetivo
                utilizado = posicao.comprado
                percentual = calcular_percentual_utilizado(posicao.comprado, posicao.limite_efetivo)
                cor = posicao.cor
                rotulo_limite = "Limite do dia"
            # Mesmo arredondamento do floatformat:0 do dashboard (141,67% → 142%).
            from decimal import ROUND_HALF_UP, Decimal

            percentual_real = int(Decimal(percentual).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            from financeiro.services import capacidade_configurada

            sidebar_capacidade = {
                # Críticos (rodada 2): sem receita no mês o card dizia
                # "R$ 0,00 — Disponível — Limite do dia R$ 0,00", como se
                # fosse um limite calculado. Estado próprio: "—" e
                # "aguardando a receita do mês" (nenhum dado financeiro).
                "nao_configurado": not capacidade_configurada(request.user.filial, hoje.year, hoje.month),
                "disponivel": disponivel,
                "excedido": -disponivel if disponivel < 0 else 0,
                "limite": limite,
                "rotulo_limite": rotulo_limite,
                "utilizado": utilizado,
                # A BARRA para em 100% (não estoura o contêiner); o TEXTO
                # mostra a % real (ex.: 132%), a mesma do dashboard.
                "percentual": percentual_real,
                "largura_barra": min(percentual_real, 100),
                # Limite <= 0 (sem receita no mês, custos maiores que a
                # receita ou dia sem capacidade): a % seria só o marcador
                # interno "esgotado" (200%), não uma proporção real.
                "sem_limite": limite <= 0,
                # Sem limite e sem nada comprado (fim de semana, feriado, mês
                # sem receita): neutro — nem verde ("liberado") nem vermelho.
                "cor": "neutro" if limite <= 0 and utilizado <= 0 else cor,
            }
        except Exception:  # noqa: BLE001 — widget da sidebar é opcional por design
            sidebar_capacidade = None

    return {
        "empresa_ativa": empresa,
        "empresas_disponiveis": empresas,
        "mostrar_seletor_empresa": len(empresas) > 1,
        "notificacoes_nao_lidas": contar_nao_lidas(request.user),
        "pode_acessar_ncc": usuario_tem_permissao(request.user, "ncc.acessar"),
        "pode_ver_agenda": usuario_tem_permissao(request.user, "agenda.ver"),
        "pode_ver_timeline": usuario_tem_permissao(request.user, "timeline.ver"),
        "sidebar_capacidade": sidebar_capacidade,
    }


def navegacao(request):
    """Microsprint de Navegação V4: injeta a navegação estruturada em toda
    página autenticada — sidebar agrupada (`nav_grupos`), barra inferior
    mobile (`nav_mobile`) e a trilha estrutural (`breadcrumbs`). Tudo nasce
    da fonte única `core/navegacao.py`, já filtrado pelas MESMAS permissões
    que as views usam (nunca um link 403). Sem consultas além das poucas
    de `permissoes_do_usuario` (zero para os perfis legados)."""
    if not hasattr(request, "user") or not request.user.is_authenticated:
        return {}
    from core.navegacao import montar_breadcrumbs, montar_nav_mobile, montar_navegacao

    return {
        "nav_grupos": montar_navegacao(request.user, request),
        "nav_mobile": montar_nav_mobile(request.user, request),
        "breadcrumbs": montar_breadcrumbs(request.user, request),
    }


def demo_mode(request):
    """Expõe `demo_mode` para qualquer template (Demo Experience 1.0, item
    1) — só liga o indicador visual "Modo Demonstração"; não altera
    nenhuma regra de negócio nem consulta o banco.

    Demo Comercial Showcase (Seção 7): `usuarios_demo_troca` alimenta o
    atalho "Trocar perfil de demonstração" (menu de conta) e o prefill do
    usuário na tela de login — SEMPRE vazio fora do modo demo, então nem o
    atalho nem o prefill existem no ambiente cliente-ready.

    Demo na internet (PythonAnywhere): `demo_exibir_senha` decide se a tela
    de login mostra a dica com os usuários e a senha pública
    (`settings.DEMO_EXIBIR_SENHA`, que por padrão segue o DEBUG — ligado só
    na demonstração local). Sempre False fora do modo demo."""
    if not settings.DEMO_MODE:
        return {"demo_mode": False, "demo_exibir_senha": False, "usuarios_demo_troca": []}
    from core.views import USUARIOS_DEMO_TROCA

    return {
        "demo_mode": True,
        "demo_exibir_senha": bool(getattr(settings, "DEMO_EXIBIR_SENHA", False)),
        "usuarios_demo_troca": [usuario for usuario, _rotulo in USUARIOS_DEMO_TROCA],
        "usuarios_demo_troca_rotulados": USUARIOS_DEMO_TROCA,
    }


def identidade_visual_login(request):
    """Disponibiliza a Identidade Visual no template de login (Sprint 6,
    item 3), onde `request.user` ainda não está autenticado — nas demais
    páginas, `user.empresa.identidade_visual` já resolve isso sem consulta
    extra.

    Assume a primeira Identidade Visual cadastrada, pragmático para o
    padrão real de implantação do NEXBUY hoje (uma Empresa por instalação/
    cliente). Um SaaS multiempresa de verdade precisaria resolver o
    tenant por subdomínio/URL antes do login — fora do escopo desta Sprint."""
    if request.user.is_authenticated:
        return {}
    return {"identidade_visual_login": IdentidadeVisual.objects.select_related("empresa").first()}
