"""Microsprint de Navegação V4 — testes obrigatórios (Seção 12).

Cobrem: menus por perfil (12.1), estado ativo do grupo/item em rotas
internas (12.2), breadcrumbs (12.3), ações rápidas e nomenclatura (12.4) e
a barra de navegação inferior mobile (12.5). Todos executam contra o HTML
REAL renderizado pelas views (mesmo cenário quase-vazio pós-Primeiro
Acesso dos testes de estados vazios), nunca contra a estrutura em memória
isolada — se o template quebrar o contrato, o teste quebra junto.
"""
import re
from datetime import date
from decimal import Decimal

from django.test import Client, TestCase, override_settings

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from core.tests_primeiro_acesso import TOKEN, realizar_primeiro_acesso
from empresas.models import Empresa
from filiais.models import Filial
from usuarios.models import Permissao, Usuario


@override_settings(INITIAL_SETUP_TOKEN=TOKEN, ALLOWED_HOSTS=["*"])
class NavegacaoV4Base(TestCase):
    """Cenário quase-vazio real (Primeiro Acesso + 1 usuário por perfil)."""

    @classmethod
    def setUpTestData(cls):
        client = Client()
        resposta = realizar_primeiro_acesso(client)
        assert resposta.status_code == 302, f"Primeiro Acesso falhou: {resposta.content[:300]}"
        cls.empresa = Empresa.objects.get(cnpj="11222333000181")
        cls.filial = Filial.objects.get(empresa=cls.empresa)
        cls.proprietario = Usuario.objects.get(username="ana.proprietaria")
        cls.gerente = Usuario.objects.create_user(
            username="gerente.nav", password="Teste!2026Forte", perfil=Usuario.Perfil.GERENTE,
            empresa=cls.empresa, filial=cls.filial,
        )
        cls.financeiro = Usuario.objects.create_user(
            username="financeiro.nav", password="Teste!2026Forte", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=cls.empresa, filial=cls.filial,
        )
        cls.comprador = Usuario.objects.create_user(
            username="comprador.nav", password="Teste!2026Forte", perfil=Usuario.Perfil.COMPRADOR,
            empresa=cls.empresa, filial=cls.filial,
        )

    def html(self, url, usuario, status=200):
        self.client.force_login(usuario)
        resposta = self.client.get(url)
        self.assertEqual(resposta.status_code, status, f"{url} -> {resposta.status_code}")
        return resposta.content.decode("utf-8", errors="replace")

    # -- helpers de asserção sobre o HTML real da sidebar -------------------

    def grupo_esta(self, html, grupo_id, aberto):
        padrao = (r'aria-expanded="%s"[^>]*aria-controls="nxGrupo-%s"'
                  % ("true" if aberto else "false", grupo_id))
        self.assertRegex(html, padrao,
                         f"grupo '{grupo_id}' deveria estar {'aberto' if aberto else 'fechado'}")

    def sublink_ativo(self, html, rotulo):
        padrao = r'class="nx-nav-sublink active"[^>]*>\s*' + re.escape(rotulo)
        self.assertRegex(html, padrao, f"sub-item '{rotulo}' deveria estar ativo")

    def link_topo_ativo(self, html, rotulo):
        padrao = (r'class="nx-nav-link active"[^>]*>\s*<i[^>]*></i>'
                  r'<span class="nx-nav-label">' + re.escape(rotulo))
        self.assertRegex(html, padrao, f"link '{rotulo}' deveria estar ativo")

    def rotulos_da_sidebar(self, html):
        aside = html.split('<aside class="nx-sidebar"', 1)[1].split("</aside>", 1)[0]
        return aside


class MenusPorPerfilTestCase(NavegacaoV4Base):
    """Seção 12.1 — composição dos menus."""

    def test_proprietario_tem_6_entradas_de_primeiro_nivel(self):
        html = self.html("/", self.proprietario)
        aside = self.rotulos_da_sidebar(html)
        # 1 link único (Início) + 5 grupos = 6 destinos no primeiro nível —
        # nunca mais os 14 links equivalentes da V3.
        self.assertEqual(aside.count("nx-nav-grupo-btn"), 5)
        for rotulo in ("Início", "Compras", "Financeiro", "Gestão", "Relatórios", "Configurações"):
            self.assertIn(f'<span class="nx-nav-label">{rotulo}</span>', aside)
        # Itens reagrupados continuam existindo (nenhum item autorizado perdido).
        # Críticos (rodada 2) — a REGRA do nome mudou: /financeiro/configuracao/
        # tem um nome canônico só (menu = Ajuda = título = trilha), "Capacidade
        # Financeira"; o menu do Proprietário dizia "Capacidade e Limites".
        for rotulo in ("Nova Compra", "Histórico de Compras", "Aprovações",
                       "Calendário de Compras", "Nova Provisão", "Simulador",
                       "Planejamento Financeiro", "Agenda Financeira",
                       "Calendário Financeiro", "Capacidade Financeira",
                       "Compradores e Limites", "Parcelamentos",
                       "Empresas e Filiais", "Usuários e Permissões", "Perfis de Acesso",
                       "Central de Relatórios", "Indicadores", "Timeline Financeira",
                       "Centro de Configurações", "Checklist de Implantação",
                       "Integrações", "Auditoria do Sistema"):
            self.assertIn(rotulo, aside, f"item '{rotulo}' sumiu do menu do Proprietário")

    def test_comprador_nao_ve_gestao_nem_financeiro(self):
        html = self.html("/", self.comprador)
        aside = self.rotulos_da_sidebar(html)
        for proibido in ("Usuários e Permissões", "Empresas e Filiais",
                         "Centro de Configurações", "Compradores e Limites",
                         "Contas a Pagar", "Custos Fixos", "Receitas"):
            self.assertNotIn(proibido, aside)
        # E sem os aditivos que não foram concedidos:
        self.assertNotIn("Agenda Financeira", aside)
        self.assertNotIn("Timeline Financeira", aside)
        # Mas com a navegação operacional completa:
        for rotulo in ("Início", "Nova Compra", "Planejamento de Compras",
                       "Nova Provisão", "Calendário de Compras",
                       "Histórico de Compras", "Simulador"):
            self.assertIn(rotulo, aside)

    def test_gerente_menu_simples_sem_funcoes_administrativas(self):
        html = self.html("/", self.gerente)
        aside = self.rotulos_da_sidebar(html)
        for rotulo in ("Início", "Aprovações", "Indicadores", "Relatórios"):
            self.assertIn(rotulo, aside)
        for proibido in ("Agenda Financeira",  # sem a permissão aditiva
                         "Usuários e Permissões", "Centro de Configurações",
                         "Nova Compra", "Simulador"):
            self.assertNotIn(proibido, aside)

    def test_financeiro_planejamento_agrupado_sem_duplicidade(self):
        html = self.html("/", self.financeiro)
        aside = self.rotulos_da_sidebar(html)
        self.assertEqual(aside.count("nx-nav-grupo-btn"), 1)  # só o grupo Planejamento
        for rotulo in ("Início", "Agenda Financeira", "Calendário Financeiro",
                       "Compradores e Limites", "Planejamento", "Receitas",
                       "Custos Fixos", "Custos Variáveis", "Contas a Pagar",
                       "Parcelamentos", "Calendário Operacional", "Relatórios"):
            self.assertIn(rotulo, aside)
        # Cada destino aparece UMA vez (sem competir hub × atalho):
        self.assertEqual(aside.count('href="/financeiro/agenda/"'), 1)
        self.assertEqual(aside.count('href="/financeiro/parcelamentos/"'), 1)

    def test_rbac_aditivo_continua_funcionando_no_menu(self):
        agenda = Permissao.objects.get(codigo="agenda.ver")
        self.comprador.permissoes_individuais.add(agenda)
        try:
            html = self.html("/", self.comprador)
            self.assertIn("Agenda Financeira", self.rotulos_da_sidebar(html))
        finally:
            self.comprador.permissoes_individuais.remove(agenda)

    def test_perfil_saiu_da_sidebar_mas_continua_no_menu_de_conta(self):
        html = self.html("/", self.proprietario)
        aside = self.rotulos_da_sidebar(html)
        self.assertNotRegex(aside, r'href="/perfil/"')
        # menu de conta (topbar) mantém Meu Perfil e Sair:
        self.assertIn('href="/perfil/"', html)
        self.assertIn("Meu Perfil", html)
        self.assertIn("Sair", html)


class EstadoAtivoTestCase(NavegacaoV4Base):
    """Seção 12.2 — grupo pai destacado/expandido e item filho ativo."""

    def test_dashboard_ativa_inicio(self):
        html = self.html("/", self.proprietario)
        self.link_topo_ativo(html, "Início")

    def test_filiais_ativa_gestao_empresas_e_filiais(self):
        html = self.html("/ncc/filiais/", self.proprietario)
        self.grupo_esta(html, "gestao", aberto=True)
        self.sublink_ativo(html, "Empresas e Filiais")

    def test_formulario_de_filial_mantem_gestao_ativa(self):
        html = self.html("/ncc/filiais/nova/", self.proprietario)
        self.grupo_esta(html, "gestao", aberto=True)
        self.sublink_ativo(html, "Empresas e Filiais")

    def test_integracoes_ativa_configuracoes(self):
        html = self.html("/ncc/integracoes/", self.proprietario)
        self.grupo_esta(html, "configuracoes", aberto=True)
        self.sublink_ativo(html, "Integrações")

    def test_central_auditoria_ativa_configuracoes_auditoria(self):
        html = self.html("/ncc/central-auditoria/", self.proprietario)
        self.grupo_esta(html, "configuracoes", aberto=True)
        self.sublink_ativo(html, "Auditoria do Sistema")

    def test_usuarios_lista_e_formulario_ativam_gestao_usuarios(self):
        for url in ("/ncc/usuarios/", "/ncc/usuarios/novo/"):
            html = self.html(url, self.proprietario)
            self.grupo_esta(html, "gestao", aberto=True)
            self.sublink_ativo(html, "Usuários e Permissões")

    def test_planejamento_e_paginas_internas_ativam_financeiro(self):
        casos = {
            "/financeiro/planejamento/": "Planejamento Financeiro",
            "/financeiro/receitas/": "Planejamento Financeiro",
            "/financeiro/custos-fixos/": "Planejamento Financeiro",
            "/financeiro/calendario-operacional/": "Planejamento Financeiro",
            "/financeiro/contas-a-pagar/": "Planejamento Financeiro",
        }
        for url, rotulo in casos.items():
            html = self.html(url, self.proprietario)
            self.grupo_esta(html, "financeiro", aberto=True)
            self.sublink_ativo(html, rotulo)

    def test_financeiro_perfil_ve_planejamento_expandido_com_filho_ativo(self):
        casos = {
            "/financeiro/receitas/": "Receitas",
            "/financeiro/custos-fixos/": "Custos Fixos",
            "/financeiro/calendario-operacional/": "Calendário Operacional",
            "/financeiro/contas-a-pagar/": "Contas a Pagar",
        }
        for url, rotulo in casos.items():
            html = self.html(url, self.financeiro)
            self.grupo_esta(html, "planejamento", aberto=True)
            self.sublink_ativo(html, rotulo)

    def test_relatorio_de_compras_ativa_relatorios_nao_compras(self):
        html = self.html("/compras/relatorios/por-filial/", self.proprietario)
        self.grupo_esta(html, "relatorios", aberto=True)
        self.grupo_esta(html, "compras", aberto=False)
        self.sublink_ativo(html, "Compras por Filial")

    def test_calendario_de_compras_ativa_grupo_compras(self):
        html = self.html("/gestao-compras/", self.proprietario)
        self.grupo_esta(html, "compras", aberto=True)
        self.sublink_ativo(html, "Calendário de Compras")

    def test_timeline_de_provisao_mantem_planejamento_de_compras_ativo(self):
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Nav")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Nav")
        self.client.force_login(self.comprador)
        resposta = self.client.post("/gestao-compras/nova/", {
            "filial": self.filial.pk, "fornecedor": fornecedor.pk, "categoria": categoria.pk,
            "data": date.today().isoformat(), "observacoes": "",
            "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0",
            "itens-MIN_NUM_FORMS": "0", "itens-MAX_NUM_FORMS": "1000",
            "itens-0-produto": "Item teste navegação", "itens-0-quantidade": "1",
            "itens-0-valor_unitario": "10,00", "itens-0-id": "",
        })
        self.assertEqual(resposta.status_code, 302, resposta.content[:300])
        from gestao_compras.models import Provisao

        provisao = Provisao.objects.latest("pk")
        html = self.html(f"/gestao-compras/provisao/{provisao.pk}/timeline/", self.comprador)
        self.grupo_esta(html, "planejamento_compras", aberto=True)
        self.sublink_ativo(html, "Calendário de Compras")

    def test_aprovacoes_ativa_o_item_do_gerente(self):
        html = self.html("/aprovacoes/", self.gerente)
        self.link_topo_ativo(html, "Aprovações")


class BreadcrumbsTestCase(NavegacaoV4Base):
    """Seção 12.3 — trilha estrutural."""

    def test_dashboard_nao_tem_breadcrumb(self):
        html = self.html("/", self.proprietario)
        self.assertNotIn('aria-label="Navegação estrutural"', html)

    def test_paginas_internas_tem_breadcrumb_com_aria(self):
        casos = {
            "/financeiro/custos-fixos/novo/": ("Novo Custo Fixo", "/financeiro/custos-fixos/"),
            "/ncc/filiais/nova/": ("Nova Filial", "/ncc/filiais/"),
            "/ncc/usuarios/novo/": ("Novo Usuário", "/ncc/usuarios/"),
            "/ncc/central-auditoria/": ("Central de Auditoria", "/ncc/auditoria/"),
            "/compras/relatorios/por-filial/": ("Compras por Filial", "/relatorios/"),
        }
        for url, (atual, link_pai) in casos.items():
            html = self.html(url, self.proprietario)
            self.assertIn('aria-label="Navegação estrutural"', html, url)
            self.assertRegex(html, r'aria-current="page">\s*<span>' + re.escape(atual))
            self.assertIn(f'href="{link_pai}"', html, f"{url}: nível anterior deveria linkar {link_pai}")
            self.assertNotIn("javascript:history.back()", html)

    def test_breadcrumb_comeca_em_inicio_com_link_funcional(self):
        html = self.html("/financeiro/receitas/", self.financeiro)
        trecho = html.split('aria-label="Navegação estrutural"', 1)[1].split("</nav>", 1)[0]
        self.assertIn('href="/"', trecho)
        self.assertIn("Início", trecho)

    def test_breadcrumb_respeita_permissao_no_nivel_anterior(self):
        # O comprador vê a timeline da própria provisão; o nível anterior
        # "Calendário de Compras" é permitido (calendario.ver) e vira link.
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor BC")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria BC")
        self.client.force_login(self.comprador)
        self.client.post("/gestao-compras/nova/", {
            "filial": self.filial.pk, "fornecedor": fornecedor.pk, "categoria": categoria.pk,
            "data": date.today().isoformat(), "observacoes": "",
            "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0",
            "itens-MIN_NUM_FORMS": "0", "itens-MAX_NUM_FORMS": "1000",
            "itens-0-produto": "Item BC", "itens-0-quantidade": "1",
            "itens-0-valor_unitario": "10,00", "itens-0-id": "",
        })
        from gestao_compras.models import Provisao

        provisao = Provisao.objects.latest("pk")
        html = self.html(f"/gestao-compras/provisao/{provisao.pk}/timeline/", self.comprador)
        trecho = html.split('aria-label="Navegação estrutural"', 1)[1].split("</nav>", 1)[0]
        self.assertIn('href="/gestao-compras/"', trecho)
        self.assertIn("Timeline da Provisão", trecho)


class AcoesRapidasTestCase(NavegacaoV4Base):
    """Seção 12.4 — destinos e rótulos das ações rápidas."""

    def test_novo_usuario_aponta_direto_para_o_cadastro(self):
        html = self.html("/", self.proprietario)
        self.assertRegex(html, r'href="/ncc/usuarios/novo/"[^>]*>[^<]*<i[^>]*></i>\s*Novo Usuário')

    def test_acao_primaria_continuar_implantacao_quando_checklist_incompleto(self):
        # Cenário quase-vazio: sem aprovações pendentes e checklist < 13/13.
        html = self.html("/", self.proprietario)
        self.assertIn("Continuar Implantação", html)
        self.assertNotIn("Revisar Aprovações", html)

    def test_acao_primaria_revisar_aprovacoes_quando_ha_pendencia(self):
        fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor QA")
        categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria QA")
        Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=fornecedor,
            usuario=self.comprador, valor=Decimal("100.00"), categoria=categoria,
            data_compra=date.today(), status=Compra.Status.PENDENTE,
        )
        html = self.html("/", self.proprietario)
        self.assertIn("Revisar Aprovações", html)

    def test_financeiro_rotulo_novo_custo_fixo(self):
        html = self.html("/", self.financeiro)
        self.assertRegex(html, r'href="/financeiro/custos-fixos/novo/"[^>]*>[^<]*<i[^>]*></i>\s*Novo Custo Fixo')
        self.assertNotIn("Nova Conta", html)

    def test_comprador_ve_explicacao_compra_versus_provisao(self):
        html = self.html("/", self.comprador)
        self.assertIn("registra uma compra já realizada ou confirmada", html)
        self.assertIn("planeja e reserva valor para uma compra futura", html)


class NavegacaoMobileTestCase(NavegacaoV4Base):
    """Seção 12.5 — barra de navegação inferior."""

    def bloco_mobile(self, html):
        self.assertIn('class="nx-mobile-nav"', html)
        return html.split('class="nx-mobile-nav"', 1)[1].split("</nav>", 1)[0]

    def test_quatro_acoes_ou_menos_por_perfil(self):
        for usuario in (self.proprietario, self.gerente, self.financeiro, self.comprador):
            bloco = self.bloco_mobile(self.html("/", usuario))
            self.assertLessEqual(bloco.count("nx-mobile-nav-item"), 4,
                                 f"{usuario.username}: mais de 4 ações na barra mobile")
            self.assertIn("data-nx-sidebar-toggle", bloco)  # botão Menu → sidebar
            self.assertIn(">Menu<", bloco)

    def test_destinos_por_perfil(self):
        esperados = {
            self.comprador: ('href="/"', 'href="/compras/nova/"', 'href="/gestao-compras/"'),
            self.financeiro: ('href="/"', 'href="/financeiro/agenda/"', 'href="/financeiro/calendario/"'),
            self.gerente: ('href="/"', 'href="/aprovacoes/"', 'href="/indicadores/"'),
            self.proprietario: ('href="/"', 'href="/aprovacoes/"', 'href="/relatorios/"'),
        }
        for usuario, hrefs in esperados.items():
            bloco = self.bloco_mobile(self.html("/", usuario))
            for href in hrefs:
                self.assertIn(href, bloco, f"{usuario.username}: destino {href} ausente")

    def test_estado_ativo_na_barra_mobile(self):
        bloco = self.bloco_mobile(self.html("/financeiro/agenda/", self.financeiro))
        self.assertRegex(bloco, r'class="nx-mobile-nav-item active"[^>]*href="/financeiro/agenda/"')

    def test_barra_ausente_em_pagina_nao_autenticada(self):
        self.client.logout()
        resposta = self.client.get("/accounts/login/")
        self.assertNotIn("nx-mobile-nav", resposta.content.decode("utf-8", "replace"))

    def test_comprador_sem_links_financeiros_na_barra(self):
        bloco = self.bloco_mobile(self.html("/", self.comprador))
        self.assertNotIn("/financeiro/", bloco)
