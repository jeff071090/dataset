"""Demonstração publicada na internet (PythonAnywhere, conta grátis) — ver
docs/DEPLOY_PYTHONANYWHERE_DEMO.md.

Cobre o que muda quando a MESMA demonstração do PC do apresentador vai para
um endereço aberto na internet:

1. `DEMO_EXIBIR_SENHA` — a dica "usuários + senha pública" da tela de login
   só aparece na demo local (padrão: segue o DEBUG); no servidor, um aviso
   neutro sem usuário nem senha.
2. `/robots.txt` pelo Django e `<meta name="robots" content="noindex,
   nofollow">` com `demo_mode`.
3. Troca de perfil com os 6 usuários do `seed_demo` (antes eram 4).
4. `manage.py definir_senha_demo` — troca as senhas só da empresa fictícia,
   nunca por argumento/ambiente, validada pelas regras do projeto.
5. `seed_demo --manter-senhas` e o aviso destacado com DEBUG=False.
6. Arquivos de deploy/pythonanywhere/ (LF, sem segredo, pins iguais aos do
   requirements.txt, `bash -n`), o gerador do zip e o guia.
7. Correções da rodada de verificação (simulação da publicação, crítico do
   guia e revisão de segurança): Auditoria do Sistema com Log de
   Configuração sem usuário (era 500), senhas já definidas que não mudam ao
   repetir o preparar.sh, falha fechada (`--bloquear`), variações da senha
   pública recusadas, `--verificar` conferindo todos os usuários ativos,
   leitura do .env igual à do python-dotenv, correção do endereço EU no
   .env, os 6 reativados pelo seed e o guia corrigido.

Os testes que rodam o seed usam o hasher MD5 (só nos testes): o que se
confere aqui é QUAL senha cada usuário tem, não o algoritmo — e o PBKDF2 de
produção custaria segundos por verificação.
"""
import importlib.util
import io
import os
import re
import runpy
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from unittest import mock

from django.conf import settings
from django.contrib.auth.hashers import check_password
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import Client, SimpleTestCase, TestCase, override_settings

from core.tests_producao import AMBIENTE_BASE

BASE_DIR = Path(settings.BASE_DIR)
PA_DIR = BASE_DIR / "deploy" / "pythonanywhere"
SETTINGS_PY = BASE_DIR / "nexbuy" / "settings.py"
GUIA = BASE_DIR / "docs" / "DEPLOY_PYTHONANYWHERE_DEMO.md"

SENHA_PUBLICA = "nexbuy123"
HASHER_RAPIDO = ["django.contrib.auth.hashers.MD5PasswordHasher"]
SEIS = (
    "demo_proprietario", "demo_gerente", "demo_financeiro",
    "demo_comprador", "demo_comprador2", "demo_comprador3",
)
AVISO_NEUTRO = "Ambiente de demonstração com dados fictícios. Entre com o usuário e a senha que você recebeu."
TERMOS_PROIBIDOS_COMPRADOR = (
    "Faturamento", "Folha de Pagamento", "Aluguel", "Capacidade mensal", "Meta Mensal",
    "Análise Financeira", "DRE",
)
ARQUIVOS_PA = (
    "_comum_pa.sh", "preparar.sh", "atualizar_demo.sh", "backup_demo.sh",
    "atualizar.sh", "backup.sh", "restaurar.sh", "ativar_uso_real.sh", "voltar_demonstracao.sh",
    "requirements-pythonanywhere.txt", "wsgi_pythonanywhere.py",
    "nexbuy.env.pythonanywhere.exemplo", "gerar_pacote.py",
)
# Nomes antigos que viraram atalho (exec) para o script geral.
ATALHOS_PA = {"atualizar_demo.sh": "atualizar.sh", "backup_demo.sh": "backup.sh"}


class MidiaTemporariaMixin:
    """O seed grava o logo da farmácia fictícia em MEDIA_ROOT — aqui numa
    pasta temporária, nunca dentro da árvore do projeto."""

    @classmethod
    def setUpClass(cls):
        cls._pasta_midia = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        cls._override_midia = override_settings(MEDIA_ROOT=cls._pasta_midia.name)
        cls._override_midia.enable()
        try:
            super().setUpClass()
        except Exception:
            cls._override_midia.disable()
            cls._pasta_midia.cleanup()
            raise

    @classmethod
    def tearDownClass(cls):
        try:
            super().tearDownClass()
        finally:
            cls._override_midia.disable()
            cls._pasta_midia.cleanup()


def _seed(*args):
    saida = io.StringIO()
    call_command("seed_demo", *args, stdout=saida)
    return saida.getvalue()


def _definir(*args, stdin_interativo=None, getpass_respostas=None):
    """Roda definir_senha_demo capturando stdout/stderr. Com
    `stdin_interativo`, simula (ou nega) um terminal; com
    `getpass_respostas`, o que seria digitado."""
    from core.management.commands.definir_senha_demo import Command

    saida, erros = io.StringIO(), io.StringIO()
    patches = []
    if stdin_interativo is not None:
        patches.append(mock.patch.object(Command, "_terminal_interativo", return_value=stdin_interativo))
    if getpass_respostas is not None:
        patches.append(mock.patch("getpass.getpass", side_effect=list(getpass_respostas)))
    for patch in patches:
        patch.start()
    try:
        call_command("definir_senha_demo", *args, stdout=saida, stderr=erros)
    finally:
        for patch in reversed(patches):
            patch.stop()
    return saida.getvalue(), erros.getvalue()


def _usuario(username):
    from usuarios.models import Usuario

    return Usuario.objects.get(username=username)


def _tem_senha(username, senha):
    return check_password(senha, _usuario(username).password)


def _html(resposta):
    return resposta.content.decode("utf-8")


def _parece_segredo(texto):
    """Sequências longas com letras E algarismos (cara de chave/token
    gerado). Linhas de traços e nomes compostos não contam."""
    return [
        trecho for trecho in re.findall(r"[A-Za-z0-9_\-]{32,}", texto)
        if re.search(r"[A-Za-z]", trecho) and re.search(r"\d", trecho)
    ]


# ---------------------------------------------------------------------------
# 1. DEMO_EXIBIR_SENHA
# ---------------------------------------------------------------------------


class DemoExibirSenhaSettingsTestCase(SimpleTestCase):
    """`settings.py` só decide na subida do processo: o arquivo é executado
    num namespace isolado (mesma técnica de core/tests_producao.py), sem o
    .env local do desenvolvedor (load_dotenv desligado aqui)."""

    def _carregar(self, **variaveis):
        ambiente = {**AMBIENTE_BASE, **{k: str(v) for k, v in variaveis.items()}}
        with mock.patch.dict(os.environ, ambiente), mock.patch("dotenv.load_dotenv"):
            if "DEMO_EXIBIR_SENHA" not in variaveis:
                os.environ.pop("DEMO_EXIBIR_SENHA", None)
            return runpy.run_path(str(SETTINGS_PY))

    def test_padrao_segue_o_debug(self):
        self.assertFalse(self._carregar(DEBUG="False")["DEMO_EXIBIR_SENHA"])
        self.assertTrue(self._carregar(DEBUG="True")["DEMO_EXIBIR_SENHA"])

    def test_variavel_explicita_vence_o_padrao(self):
        self.assertTrue(self._carregar(DEBUG="False", DEMO_EXIBIR_SENHA="True")["DEMO_EXIBIR_SENHA"])
        self.assertFalse(self._carregar(DEBUG="True", DEMO_EXIBIR_SENHA="False")["DEMO_EXIBIR_SENHA"])


class LoginDaDemoNaInternetTestCase(TestCase):
    @override_settings(DEMO_MODE=True, DEMO_EXIBIR_SENHA=False)
    def test_sem_exibir_senha_o_login_nao_mostra_usuario_nem_senha(self):
        html = _html(Client().get("/accounts/login/"))
        self.assertNotIn(SENHA_PUBLICA, html)
        self.assertNotIn("demo_", html)
        self.assertNotIn("Usuários de demonstração", html)
        self.assertIn(AVISO_NEUTRO, html)
        self.assertIn("data-nx-login-aviso-demo", html)
        # O prefill da troca de perfil continua funcionando (whitelist).
        html = _html(Client().get("/accounts/login/?usuario=demo_comprador3"))
        self.assertIn('value="demo_comprador3"', html)
        self.assertNotIn(SENHA_PUBLICA, html)

    @override_settings(DEMO_MODE=True, DEMO_EXIBIR_SENHA=True)
    def test_demo_local_continua_com_a_dica_e_os_6_usuarios(self):
        html = _html(Client().get("/accounts/login/"))
        self.assertIn(SENHA_PUBLICA, html)
        self.assertIn("Usuários de demonstração", html)
        for username in SEIS:
            self.assertIn(username, html)
        self.assertNotIn(AVISO_NEUTRO, html)

    @override_settings(DEMO_MODE=False, DEMO_EXIBIR_SENHA=True)
    def test_fora_do_modo_demo_nem_dica_nem_aviso(self):
        html = _html(Client().get("/accounts/login/"))
        self.assertNotIn(SENHA_PUBLICA, html)
        self.assertNotIn(AVISO_NEUTRO, html)
        self.assertNotIn("demo_", html)

    def test_context_processor_nunca_exibe_fora_do_modo_demo(self):
        from django.test import RequestFactory

        from core.context_processors import demo_mode

        requisicao = RequestFactory().get("/")
        with self.settings(DEMO_MODE=False, DEMO_EXIBIR_SENHA=True):
            self.assertFalse(demo_mode(requisicao)["demo_exibir_senha"])
        with self.settings(DEMO_MODE=True, DEMO_EXIBIR_SENHA=False):
            self.assertFalse(demo_mode(requisicao)["demo_exibir_senha"])
        with self.settings(DEMO_MODE=True, DEMO_EXIBIR_SENHA=True):
            self.assertTrue(demo_mode(requisicao)["demo_exibir_senha"])

    def test_nenhum_template_ou_script_promete_a_senha_publica_fora_do_login(self):
        """A única tela que pode citar a senha pública é o login (e só com
        demo_exibir_senha)."""
        encontrados = []
        for pasta, padrao in ((BASE_DIR / "templates", "*.html"), (BASE_DIR / "static" / "js", "*.js")):
            for arquivo in pasta.rglob(padrao):
                if SENHA_PUBLICA in arquivo.read_text(encoding="utf-8"):
                    encontrados.append(arquivo.relative_to(BASE_DIR).as_posix())
        self.assertEqual(encontrados, ["templates/registration/login.html"])
        login = (BASE_DIR / "templates" / "registration" / "login.html").read_text(encoding="utf-8")
        trecho = login.split("{% if demo_exibir_senha %}", 1)[1].split("{% else %}", 1)[0]
        self.assertIn(SENHA_PUBLICA, trecho)

    def test_templates_alterados_sem_comentario_multilinha(self):
        for nome in ("registration/login.html", "base.html", "core/demo_apresentacao.html",
                     "core/demo_encerramento.html"):
            texto = (BASE_DIR / "templates" / nome).read_text(encoding="utf-8")
            self.assertIsNone(re.search(r"\{#[^#]*\n", texto), nome)


# ---------------------------------------------------------------------------
# 2. robots.txt e noindex
# ---------------------------------------------------------------------------


class RobotsENoindexTestCase(TestCase):
    def test_robots_txt_pelo_django(self):
        for demo in (True, False):
            with self.settings(DEMO_MODE=demo):
                resposta = Client().get("/robots.txt")
                self.assertEqual(resposta.status_code, 200)
                self.assertTrue(resposta["Content-Type"].startswith("text/plain"))
                self.assertEqual(resposta.content.decode(), "User-agent: *\nDisallow: /\n")
        self.assertEqual(Client().post("/robots.txt").status_code, 405)

    def test_mesmo_texto_do_nginx_da_vps_sem_conflito(self):
        """Na VPS o nginx responde /robots.txt sozinho (a requisição nem
        chega ao Django) — o texto tem de ser o mesmo."""
        from core.views_healthcheck import ROBOTS_TXT

        nginx = (BASE_DIR / "deploy" / "nginx_nexbuy.conf").read_text(encoding="utf-8")
        self.assertIn("location = /robots.txt", nginx)
        self.assertIn('return 200 "' + ROBOTS_TXT.replace("\n", "\\n") + '";', nginx)

    @override_settings(DEMO_MODE=True)
    def test_noindex_no_login_e_nas_paginas_demo(self):
        for url in ("/accounts/login/", "/demo/apresentacao/", "/demo/encerramento/"):
            with self.subTest(url=url):
                resposta = Client().get(url)
                self.assertEqual(resposta.status_code, 200)
                self.assertIn('<meta name="robots" content="noindex, nofollow">', _html(resposta))

    @override_settings(DEMO_MODE=False)
    def test_sem_noindex_fora_do_modo_demo(self):
        self.assertNotIn('name="robots"', _html(Client().get("/accounts/login/")))


# ---------------------------------------------------------------------------
# 3. Troca de perfil com os 6 usuários
# ---------------------------------------------------------------------------


@override_settings(PASSWORD_HASHERS=HASHER_RAPIDO)
class SeisUsuariosDaTrocaTestCase(MidiaTemporariaMixin, TestCase):
    @classmethod
    def setUpTestData(cls):
        _seed()

    def test_lista_tem_os_6_e_todos_existem_no_seed_com_os_nomes_certos(self):
        from core.views import USUARIOS_DEMO_TROCA
        from usuarios.models import UsuarioEmpresa

        self.assertEqual(tuple(u for u, _ in USUARIOS_DEMO_TROCA), SEIS)
        for username, rotulo in USUARIOS_DEMO_TROCA:
            with self.subTest(username=username):
                usuario = _usuario(username)
                self.assertTrue(usuario.empresa.cnpj.startswith("98765432"))
                self.assertIn(usuario.get_full_name(), rotulo)
                self.assertTrue(rotulo.startswith(usuario.get_perfil_display()))
        rotulos = dict(USUARIOS_DEMO_TROCA)
        pedro = _usuario("demo_comprador2")
        self.assertEqual(
            UsuarioEmpresa.objects.get(usuario=pedro, empresa=pedro.empresa).limite_compra, 2000
        )
        self.assertIn("limite R$ 2.000", rotulos["demo_comprador2"])
        carla = _usuario("demo_comprador3")
        self.assertTrue(UsuarioEmpresa.objects.get(usuario=carla, empresa=carla.empresa).bloqueado)
        self.assertIn("bloqueada", rotulos["demo_comprador3"])

    @override_settings(DEMO_MODE=True)
    def test_menu_mostra_as_6_opcoes(self):
        from core.views import USUARIOS_DEMO_TROCA

        self.assertTrue(self.client.login(username="demo_proprietario", password=SENHA_PUBLICA))
        html = _html(self.client.get("/"))
        self.assertEqual(html.count('name="usuario" value="demo_'), 6)
        for _username, rotulo in USUARIOS_DEMO_TROCA:
            self.assertIn(rotulo, html)
        # Menu comprido rola por dentro em tela baixa.
        self.assertIn("max-height:calc(100vh - 5rem);overflow-y:auto;", html)

    @override_settings(DEMO_MODE=True)
    def test_troca_para_pedro_e_carla(self):
        for destino in ("demo_comprador2", "demo_comprador3"):
            with self.subTest(destino=destino):
                self.assertTrue(self.client.login(username="demo_gerente", password=SENHA_PUBLICA))
                resposta = self.client.post("/demo/trocar-perfil/", {"usuario": destino})
                self.assertEqual(resposta.status_code, 302)
                self.assertEqual(resposta.url, f"/accounts/login/?usuario={destino}")
                self.assertIn(f'value="{destino}"', _html(self.client.get(resposta.url)))

    @override_settings(DEMO_MODE=True)
    def test_dashboard_da_carla_bloqueada_nao_se_contradiz(self):
        """Simulação da publicação: o destaque dizia "Bloqueado" e a Central
        de Decisão, logo abaixo, "Hoje você pode comprar normalmente."."""
        from dashboard.insights import MENSAGEM_BLOQUEADO

        self.assertTrue(self.client.login(username="demo_comprador3", password=SENHA_PUBLICA))
        html = _html(self.client.get("/"))
        self.assertIn("Bloqueado", html)
        self.assertIn(MENSAGEM_BLOQUEADO, html)
        for frase in ("Hoje você pode comprar normalmente.", "O saldo disponível está confortável.",
                      "Seu limite diário está saudável."):
            self.assertNotIn(frase, html)

    @override_settings(DEMO_MODE=True)
    def test_rotulos_novos_nao_levam_termo_financeiro_ao_comprador(self):
        for username in ("demo_comprador", "demo_comprador2", "demo_comprador3"):
            client = Client()
            self.assertTrue(client.login(username=username, password=SENHA_PUBLICA))
            html = _html(client.get("/"))
            for termo in TERMOS_PROIBIDOS_COMPRADOR:
                with self.subTest(usuario=username, termo=termo):
                    self.assertNotIn(termo, html)


# ---------------------------------------------------------------------------
# 4. definir_senha_demo
# ---------------------------------------------------------------------------


@override_settings(PASSWORD_HASHERS=HASHER_RAPIDO)
class DefinirSenhaDemoTestCase(MidiaTemporariaMixin, TestCase):
    @classmethod
    def setUpTestData(cls):
        from empresas.models import Empresa
        from usuarios.models import Usuario

        _seed()
        cls.empresa_demo = Empresa.objects.get(cnpj="98765432000198")
        outra = Empresa.objects.create(nome="Farmácia de Outro Cliente", cnpj="11.222.333/0001-81")
        Usuario.objects.create_user(
            "comprador_outra_empresa", password=SENHA_PUBLICA, empresa=outra, perfil=Usuario.Perfil.COMPRADOR,
        )
        suporte = Usuario.objects.create_superuser("suporte_tecnico_demo", "suporte@exemplo.com.br", SENHA_PUBLICA)
        suporte.empresa = cls.empresa_demo
        suporte.save()

    def _hashes(self, *usernames):
        from usuarios.models import Usuario

        return dict(Usuario.objects.filter(username__in=usernames).values_list("username", "password"))

    def test_gerar_aplica_a_mesma_senha_forte_aos_6_e_a_publica_para_de_funcionar(self):
        saida, _erros = _definir("--gerar")
        senhas = re.findall(r"(?m)^\s+Senha: (\S+)$", saida)
        self.assertEqual(len(senhas), 1, saida)
        senha = senhas[0]
        self.assertGreaterEqual(len(senha), 14)
        self.assertIsNone(re.search(r"[0O1lIio]", senha), "senha gerada com caractere ambíguo")
        self.assertTrue(any(c.isupper() for c in senha) and any(c.islower() for c in senha)
                        and any(c.isdigit() for c in senha))
        for username in SEIS:
            with self.subTest(username=username):
                self.assertTrue(_tem_senha(username, senha))
                self.assertFalse(_tem_senha(username, SENHA_PUBLICA))
                self.assertFalse(Client().login(username=username, password=SENHA_PUBLICA))
        self.assertTrue(Client().login(username="demo_comprador3", password=senha))

    def test_individual_gera_uma_senha_diferente_por_usuario(self):
        saida, _erros = _definir("--individual", "--gerar")
        pares = dict(re.findall(r"Usuário: (\S+)\s+Senha: (\S+)", saida))
        self.assertEqual(set(pares), set(SEIS))
        self.assertEqual(len(set(pares.values())), 6)
        for username, senha in pares.items():
            self.assertTrue(_tem_senha(username, senha), username)

    def test_subconjunto_so_troca_os_escolhidos_e_avisa_dos_outros(self):
        saida, erros = _definir("--usuarios", "demo_gerente, demo_comprador2", "--gerar")
        senha = re.findall(r"(?m)^\s+Senha: (\S+)$", saida)[0]
        self.assertTrue(_tem_senha("demo_gerente", senha))
        self.assertTrue(_tem_senha("demo_comprador2", senha))
        for username in ("demo_proprietario", "demo_financeiro", "demo_comprador", "demo_comprador3"):
            self.assertTrue(_tem_senha(username, SENHA_PUBLICA), username)
            self.assertIn(username, erros)

    def test_um_so_usuario_gerado_mostra_a_senha(self):
        """O "esqueceu a senha" do guia gera para UM usuário — a senha tem de
        aparecer (uma vez) no console."""
        saida, _erros = _definir("--usuarios", "demo_gerente", "--gerar")
        self.assertIn("SENHA GERADA (para demo_gerente):", saida)
        senhas = re.findall(r"(?m)^\s+Senha: (\S+)$", saida)
        self.assertEqual(len(senhas), 1, saida)
        self.assertTrue(_tem_senha("demo_gerente", senhas[0]))

    def test_usuario_fora_da_lista_e_recusado(self):
        with self.assertRaisesMessage(CommandError, "fora da lista de demonstração"):
            _definir("--usuarios", "comprador_outra_empresa", "--gerar")
        self.assertTrue(_tem_senha("comprador_outra_empresa", SENHA_PUBLICA))

    def test_atendente_do_historico_fica_com_senha_inutilizavel(self):
        self.assertTrue(_tem_senha("vp_atendente_beatriz", SENHA_PUBLICA))
        saida, _erros = _definir("--gerar")
        self.assertIn("vp_atendente_beatriz", saida)
        beatriz = _usuario("vp_atendente_beatriz")
        self.assertFalse(beatriz.has_usable_password())
        self.assertFalse(Client().login(username="vp_atendente_beatriz", password=SENHA_PUBLICA))

    def test_outra_empresa_e_superusuario_ficam_intocados(self):
        antes = self._hashes("comprador_outra_empresa", "suporte_tecnico_demo")
        _definir("--gerar")
        _definir("--individual", "--gerar")
        self.assertEqual(self._hashes("comprador_outra_empresa", "suporte_tecnico_demo"), antes)
        self.assertTrue(_tem_senha("comprador_outra_empresa", SENHA_PUBLICA))
        self.assertTrue(_tem_senha("suporte_tecnico_demo", SENHA_PUBLICA))

    def test_interativo_recusa_senha_numerica_e_aceita_a_forte(self):
        forte = "Tulipa-Azul-4827"
        saida, erros = _definir(
            stdin_interativo=True,
            getpass_respostas=["12345678", "12345678", forte, forte],
        )
        self.assertIn("Senha recusada", erros)
        self.assertIn("NÃO aparece enquanto você digita", saida)
        self.assertNotIn(forte, saida + erros)
        for username in SEIS:
            self.assertTrue(_tem_senha(username, forte), username)

    def test_interativo_desiste_depois_de_3_tentativas_sem_mudar_nada(self):
        with self.assertRaisesMessage(CommandError, "Nenhuma senha foi alterada"):
            _definir(
                stdin_interativo=True,
                getpass_respostas=["12345678", "12345678", "senha", "senha", SENHA_PUBLICA, SENHA_PUBLICA],
            )
        for username in SEIS:
            self.assertTrue(_tem_senha(username, SENHA_PUBLICA), username)

    def test_interativo_recusa_confirmacao_diferente(self):
        with self.assertRaises(CommandError):
            _definir(
                stdin_interativo=True,
                getpass_respostas=["Tulipa-Azul-4827", "Tulipa-Azul-4828"] * 3,
            )
        self.assertTrue(_tem_senha("demo_proprietario", SENHA_PUBLICA))

    def test_individual_interativo_pergunta_usuario_por_usuario(self):
        respostas = []
        for indice in range(6):
            senha = f"Girassol-Verde-{indice}9{indice}"
            respostas += [senha, senha]
        _definir("--individual", stdin_interativo=True, getpass_respostas=respostas)
        for indice, username in enumerate(SEIS):
            self.assertTrue(_tem_senha(username, f"Girassol-Verde-{indice}9{indice}"), username)

    def test_sem_terminal_recusa_sem_gerar(self):
        with self.assertRaisesMessage(CommandError, "terminal interativo"):
            _definir(stdin_interativo=False)
        self.assertTrue(_tem_senha("demo_proprietario", SENHA_PUBLICA))

    def test_senha_nunca_entra_por_argumento_nem_por_variavel_de_ambiente(self):
        from core.management.commands.definir_senha_demo import Command

        parser = Command().create_parser("manage.py", "definir_senha_demo")
        opcoes = {opcao for acao in parser._actions for opcao in acao.option_strings}
        self.assertTrue({"--gerar", "--individual", "--usuarios", "--verificar"} <= opcoes)
        self.assertFalse({o for o in opcoes if "senha" in o or "password" in o})
        with self.assertRaises(CommandError):
            call_command("definir_senha_demo", "--senha", "Tulipa-Azul-4827")
        fonte = (BASE_DIR / "core" / "management" / "commands" / "definir_senha_demo.py").read_text(encoding="utf-8")
        self.assertNotIn("os.environ", fonte)
        self.assertNotIn("getenv", fonte)

    def test_verificar_sai_com_codigo_diferente_de_zero_enquanto_sobrar_senha_publica(self):
        """Revisão de segurança: o --verificar é o portão que os scripts usam
        para dizer "o site não aceita a senha pública" — por isso confere
        (só leitura) TODOS os usuários ativos, inclusive superusuário e
        usuário de outra empresa com a senha pública (antes passavam como
        "OK"). A troca continua restrita à demonstração: esses dois o
        comando manda trocar à mão."""
        saida = io.StringIO()
        with self.assertRaises(CommandError) as contexto:
            call_command("definir_senha_demo", "--verificar", stdout=saida)
        self.assertEqual(contexto.exception.returncode, 3)
        for username in (*SEIS, "vp_atendente_beatriz", "comprador_outra_empresa", "suporte_tecnico_demo"):
            self.assertIn(username, saida.getvalue())

        antes = self._hashes("comprador_outra_empresa", "suporte_tecnico_demo")
        _definir("--gerar")
        self.assertEqual(self._hashes("comprador_outra_empresa", "suporte_tecnico_demo"), antes)
        saida = io.StringIO()
        with self.assertRaises(CommandError) as contexto:
            call_command("definir_senha_demo", "--verificar", stdout=saida)
        self.assertEqual(contexto.exception.returncode, 3)
        self.assertIn("changepassword", str(contexto.exception))
        fora = saida.getvalue().split("Fora da demonstração", 1)[1]
        self.assertIn("comprador_outra_empresa", fora)
        self.assertIn("suporte_tecnico_demo", fora)
        for username in SEIS:
            self.assertNotIn(username, saida.getvalue())

        for username in ("comprador_outra_empresa", "suporte_tecnico_demo"):
            usuario = _usuario(username)
            usuario.set_password("Outra-Senha-Forte-829")
            usuario.save()
        saida = io.StringIO()
        call_command("definir_senha_demo", "--verificar", stdout=saida)
        self.assertIn("OK: nenhum usuário ativo usa a senha pública", saida.getvalue())

    def test_verificar_ignora_inativo_de_fora_e_avisa_usuario_demo_desativado(self):
        from usuarios.models import Usuario

        Usuario.objects.filter(username__in=("comprador_outra_empresa", "suporte_tecnico_demo")).update(is_active=False)
        _definir("--gerar")
        Usuario.objects.filter(username="demo_comprador").update(is_active=False)
        saida = io.StringIO()
        call_command("definir_senha_demo", "--verificar", stdout=saida)
        self.assertIn("DESATIVADOS", saida.getvalue())
        self.assertIn("demo_comprador", saida.getvalue())
        self.assertIn("--renovar-cenario", saida.getvalue())

    def test_bloquear_desativa_so_a_senha_publica_e_verificar_sai_com_4(self):
        from usuarios.models import Usuario

        Usuario.objects.filter(username__in=("comprador_outra_empresa", "suporte_tecnico_demo")).update(is_active=False)
        _definir("--usuarios", "demo_gerente", "--gerar")
        senha_gerente = _usuario("demo_gerente").password
        antes_fora = self._hashes("comprador_outra_empresa", "suporte_tecnico_demo")

        saida, _erros = _definir("--bloquear")
        self.assertIn("DESATIVADA", saida)
        for username in ("demo_proprietario", "demo_financeiro", "demo_comprador", "demo_comprador2",
                         "demo_comprador3", "vp_atendente_beatriz"):
            with self.subTest(username=username):
                self.assertFalse(_usuario(username).has_usable_password())
                self.assertFalse(Client().login(username=username, password=SENHA_PUBLICA))
        # Quem já tinha senha própria continua com ela; fora do escopo, intocado.
        self.assertEqual(_usuario("demo_gerente").password, senha_gerente)
        self.assertEqual(self._hashes("comprador_outra_empresa", "suporte_tecnico_demo"), antes_fora)

        saida = io.StringIO()
        with self.assertRaises(CommandError) as contexto:
            call_command("definir_senha_demo", "--verificar", stdout=saida)
        self.assertEqual(contexto.exception.returncode, 4)
        self.assertIn("SEM SENHA", saida.getvalue())
        self.assertNotIn("demo_gerente", saida.getvalue())

        from core.senha_demo import usuarios_demo_sem_senha

        pendentes = ",".join(u.username for u in usuarios_demo_sem_senha())
        _definir("--usuarios", pendentes, "--gerar")
        self.assertEqual(_usuario("demo_gerente").password, senha_gerente)
        call_command("definir_senha_demo", "--verificar", stdout=io.StringIO())

        # Idempotente: sem ninguém com a senha pública, não mexe em nada.
        saida, _erros = _definir("--bloquear")
        self.assertIn("nada a desativar", saida)

    def test_bloquear_so_sozinho(self):
        for combinacao in (("--bloquear", "--gerar"), ("--bloquear", "--verificar"),
                           ("--bloquear", "--usuarios", "demo_gerente")):
            with self.subTest(combinacao=combinacao), self.assertRaises(CommandError):
                _definir(*combinacao)
        self.assertTrue(_tem_senha("demo_proprietario", SENHA_PUBLICA))

    def test_variacoes_da_senha_publica_sao_recusadas(self):
        """Revisão de segurança: comparar só a string exata deixava passar
        Nexbuy123, nexbuy1234, nexbuy123!... — o primeiro palpite de quem
        conhece a demo local. E a senha digitada precisa de 12 caracteres."""
        from core.management.commands.definir_senha_demo import Command

        demo = [_usuario(username) for username in SEIS]
        for senha in ("nexbuy123", "Nexbuy123", "NEXBUY123", "nexbuy1234", "nexbuy123!", "nexbuy2026",
                      "Nexbuy@123", "N3xbuy-123", "Senha-do-Nexbuy-2026", "Meu nexbuy 123 forte"):
            with self.subTest(senha=senha):
                self.assertTrue(Command._problemas_da_senha(senha, demo), senha)
        problemas = Command._problemas_da_senha("Tulipa-Az-1", demo)
        self.assertTrue(any("12 caracteres" in problema for problema in problemas), problemas)
        for senha in ("Tulipa-Azul-4827", "Balcao-Centro-2026", "Girassol Verde 88"):
            with self.subTest(senha=senha):
                self.assertEqual(Command._problemas_da_senha(senha, demo), [], senha)

    def test_nomes_obvios_do_site_sao_recusados_mesmo_com_numeros_no_lugar_de_letras(self):
        """Conferência final: 'N3xbuy123456' e 'VidaPlena2026' passavam —
        o nome da farmácia fictícia aparece na tela de login anônima e o
        login não tem limite de tentativas. Só a senha DIGITADA da demo
        tem esta regra; o validador global não (senhas da farmácia real)."""
        from core.management.commands.definir_senha_demo import Command
        from core.senha_demo import SenhaPublicaDemoValidator

        demo = [_usuario(username) for username in SEIS]
        for senha in ("N3xbuy123456", "n3xbuy2026!!", "VidaPlena2026", "vidaplena123", "V1d4Pl3n4-2026",
                      "Farmácia-Centro-2026", "f@rmacia-2026x", "VIDA-PLENA-centro-26", "Demo-Loja-Centro-1"):
            with self.subTest(senha=senha):
                problemas = Command._problemas_da_senha(senha, demo)
                self.assertTrue(problemas, senha)
        self.assertIsNone(SenhaPublicaDemoValidator().validate("Farmácia-Centro-2026"))

    def test_interativo_recusa_variacao_da_senha_publica_de_ponta_a_ponta(self):
        with self.assertRaisesMessage(CommandError, "Nenhuma senha foi alterada"):
            _definir(
                stdin_interativo=True,
                getpass_respostas=["Nexbuy123", "Nexbuy123", "nexbuy123!", "nexbuy123!", "Nexbuy@2026x", "Nexbuy@2026x"],
            )
        for username in SEIS:
            self.assertTrue(_tem_senha(username, SENHA_PUBLICA), username)
        from django.contrib.auth import authenticate

        self.assertIsNone(authenticate(username="demo_proprietario", password="Nexbuy123"))

    def test_regra_de_senha_do_projeto_recusa_a_publica_em_qualquer_troca(self):
        """O validador entra em AUTH_PASSWORD_VALIDATORS: Meu Perfil e
        Primeiro Acesso recusam a senha pública e as variações; o cadastro
        de usuário do NCC também (senha inicial)."""
        from django.contrib.auth.password_validation import validate_password
        from django.core.exceptions import ValidationError

        from empresas.forms_ncc import UsuarioNovoForm
        from usuarios.models import Usuario

        self.assertIn("core.senha_demo.SenhaPublicaDemoValidator",
                      [item["NAME"] for item in settings.AUTH_PASSWORD_VALIDATORS])
        for senha in (SENHA_PUBLICA, "Nexbuy123!", "nexbuy1234"):
            with self.subTest(senha=senha), self.assertRaises(ValidationError):
                validate_password(senha)
        validate_password("Tulipa-Azul-4827")

        dados = {
            "first_name": "Nova", "last_name": "Pessoa", "email": "nova@exemplo.com.br",
            "username": "nova_pessoa_demo", "perfil": Usuario.Perfil.PROPRIETARIO, "is_active": "on",
        }
        form = UsuarioNovoForm(data={**dados, "senha_inicial": "Nexbuy123"}, empresa=self.empresa_demo)
        self.assertFalse(form.is_valid())
        self.assertIn("senha_inicial", form.errors)
        form = UsuarioNovoForm(data={**dados, "senha_inicial": "senha12345"}, empresa=self.empresa_demo)
        self.assertTrue(form.is_valid(), form.errors)

        # Meu Perfil (PasswordChangeForm do Django, com as regras do projeto).
        _definir("--usuarios", "demo_gerente", "--gerar")
        gerente = _usuario("demo_gerente")
        gerente.set_password("Senha-Atual-Forte-55")
        gerente.save()
        from django.contrib.auth.forms import PasswordChangeForm

        form = PasswordChangeForm(user=gerente, data={
            "old_password": "Senha-Atual-Forte-55", "new_password1": "Nexbuy@123", "new_password2": "Nexbuy@123",
        })
        self.assertFalse(form.is_valid())
        self.assertIn("new_password2", form.errors)

    def test_auditoria_do_sistema_abre_depois_de_definir_senha_demo(self):
        """Simulação da publicação: o definir_senha_demo grava um Log de
        Configuração SEM usuário (quem roda é o suporte, no console) e a tela
        Auditoria do Sistema do Proprietário dava 500 — o template usava
        `log.usuario.username` como argumento de filtro, que o Django não
        silencia quando o usuário é None."""
        from django.urls import reverse

        _definir("--gerar")
        self.client.force_login(_usuario("demo_proprietario"))
        resposta = self.client.get(reverse("ncc:auditoria"))
        self.assertEqual(resposta.status_code, 200)
        html = _html(resposta)
        self.assertIn("comando definir_senha_demo", html)
        self.assertNotIn("None", html)
        _definir("--bloquear")
        self.assertEqual(self.client.get(reverse("ncc:auditoria")).status_code, 200)

    def test_verificar_nao_combina_com_troca(self):
        with self.assertRaises(CommandError):
            _definir("--verificar", "--gerar")

    def test_registra_no_log_de_configuracao_sem_a_senha(self):
        from empresas.models import LogConfiguracao

        saida, _erros = _definir("--gerar")
        senha = re.findall(r"(?m)^\s+Senha: (\S+)$", saida)[0]
        log = LogConfiguracao.objects.filter(empresa=self.empresa_demo, area="Usuários e Permissões").latest("criado_em")
        self.assertIn("definir_senha_demo", log.descricao)
        self.assertIn("6 usuário(s)", log.descricao)
        self.assertNotIn(senha, log.descricao)
        self.assertFalse(LogConfiguracao.objects.filter(descricao__contains=senha).exists())

    @override_settings(DEBUG=False, TESTING=False)
    def test_funciona_com_debug_false(self):
        saida, _erros = _definir("--gerar")
        senha = re.findall(r"(?m)^\s+Senha: (\S+)$", saida)[0]
        self.assertTrue(_tem_senha("demo_financeiro", senha))


# ---------------------------------------------------------------------------
# 4b. Telas com usuário nulo (Log de Configuração / históricos)
# ---------------------------------------------------------------------------


class UsuarioNuloNosTemplatesTestCase(TestCase):
    """`LogConfiguracao.usuario`, `HistoricoCompra.usuario`,
    `HistoricoProvisao.usuario` e `Compra.usuario` são FKs anuláveis
    (SET_NULL). `{{ x.usuario.get_full_name|default:x.usuario.username }}`
    levanta VariableDoesNotExist quando `x.usuario` é None — o Django só
    silencia a variável principal, nunca o ARGUMENTO do filtro — e a tela
    inteira vira 500. Toda ocorrência precisa estar dentro de
    `{% if x.usuario %}`."""

    ANULAVEIS = ("log.usuario", "evento.usuario", "compra.usuario", "parcela.compra.usuario")

    def test_nenhum_template_usa_fk_anulavel_como_argumento_de_filtro_sem_guarda(self):
        problemas = []
        for arquivo in (BASE_DIR / "templates").rglob("*.html"):
            for numero, linha in enumerate(arquivo.read_text(encoding="utf-8").splitlines(), start=1):
                for variavel in self.ANULAVEIS:
                    argumento = f"|default:{variavel}."
                    if argumento in linha:
                        antes = linha.split(argumento, 1)[0]
                        if "{% if " + variavel + " %}" not in antes:
                            problemas.append(f"{arquivo.relative_to(BASE_DIR).as_posix()}:{numero}")
        self.assertEqual(problemas, [])

    def test_auditoria_renderiza_log_e_historicos_sem_usuario(self):
        from datetime import date
        from decimal import Decimal

        from django.urls import reverse

        from cadastros.models import Categoria
        from compras.models import Compra, Fornecedor, HistoricoCompra
        from empresas.models import Empresa, LogConfiguracao
        from filiais.models import Filial
        from usuarios.models import Usuario

        empresa = Empresa.objects.create(nome="Farmácia Teste Nulo", cnpj="11222333000181")
        filial = Filial.objects.create(empresa=empresa, nome="Centro")
        proprietario = Usuario.objects.create_user(
            "dono_teste_nulo", password="Senha-Forte-Teste-1", empresa=empresa,
            perfil=Usuario.Perfil.PROPRIETARIO, first_name="Dono",
        )
        LogConfiguracao.objects.create(empresa=empresa, usuario=None, area="Usuários e Permissões",
                                       descricao="Registro do suporte, sem usuário.")
        fornecedor = Fornecedor.objects.create(empresa=empresa, nome="Distribuidora Nula")
        categoria = Categoria.objects.create(empresa=empresa, nome="Medicamentos")
        compra = Compra.objects.create(
            empresa=empresa, filial=filial, fornecedor=fornecedor, usuario=None, categoria=categoria,
            valor=Decimal("100.00"), data_compra=date.today(),
        )
        HistoricoCompra.objects.create(compra=compra, usuario=None, acao=HistoricoCompra.Acao.CRIACAO)

        self.client.force_login(proprietario)
        resposta = self.client.get(reverse("ncc:auditoria"))
        self.assertEqual(resposta.status_code, 200)
        html = _html(resposta)
        self.assertIn("Registro do suporte, sem usuário.", html)
        self.assertIn("(sistema)", html)
        self.assertNotIn("None", html)


# ---------------------------------------------------------------------------
# 5. seed_demo --manter-senhas
# ---------------------------------------------------------------------------


def _contagens():
    from cadastros.models import Categoria
    from compras.models import Compra, Fornecedor
    from empresas.models import Empresa
    from gestao_compras.models import Provisao
    from notificacoes.models import Notificacao
    from usuarios.models import Usuario

    empresa = Empresa.objects.get(cnpj="98765432000198")
    return {
        "empresas": Empresa.objects.filter(cnpj__startswith="98765432").count(),
        "usuarios": Usuario.objects.filter(username__startswith="demo_").count(),
        "fornecedores": Fornecedor.objects.filter(empresa=empresa).count(),
        "categorias": Categoria.objects.filter(empresa=empresa).count(),
        "compras": Compra.objects.filter(filial__empresa=empresa).count(),
        "provisoes": Provisao.objects.filter(filial__empresa=empresa).count(),
        "notificacoes": Notificacao.objects.filter(empresa=empresa).count(),
    }


@override_settings(PASSWORD_HASHERS=HASHER_RAPIDO)
class SeedManterSenhasTestCase(MidiaTemporariaMixin, TestCase):
    def test_manter_senhas_preserva_a_senha_e_o_seed_segue_idempotente(self):
        _seed()
        saida, _erros = _definir("--gerar")
        senha = re.findall(r"(?m)^\s+Senha: (\S+)$", saida)[0]
        antes = _contagens()

        relatorio = _seed("--manter-senhas")
        self.assertIn("as senhas foram MANTIDAS", relatorio)
        self.assertNotIn("senha para todos", relatorio)
        self.assertEqual(_contagens(), antes)
        for username in SEIS:
            self.assertTrue(_tem_senha(username, senha), username)
            self.assertFalse(_tem_senha(username, SENHA_PUBLICA), username)
        self.assertFalse(_usuario("vp_atendente_beatriz").has_usable_password())

        # Contrato antigo intacto: sem a flag, o seed volta à senha pública
        # (a demonstração local depende disso).
        relatorio = _seed()
        self.assertIn("senha para todos: nexbuy123", relatorio)
        self.assertEqual(_contagens(), antes)
        for username in (*SEIS, "vp_atendente_beatriz"):
            self.assertTrue(_tem_senha(username, SENHA_PUBLICA), username)

    def test_renovar_o_cenario_reativa_os_6_usuarios(self):
        """A cliente, como Proprietária, pode desativar um usuário de
        demonstração em Usuários e Permissões; renovar o cenário devolve o
        acesso "um a um" (o seed não mexia em is_active dos 6)."""
        from usuarios.models import Usuario

        _seed()
        _definir("--gerar")
        Usuario.objects.filter(username__in=("demo_comprador", "demo_gerente")).update(is_active=False)
        _seed("--manter-senhas")
        for username in SEIS:
            self.assertTrue(_usuario(username).is_active, username)

    @override_settings(DEBUG=False, TESTING=False)
    def test_bloqueio_do_seed_no_servidor_nunca_manda_por_no_env(self):
        from core.utils import abortar_seed_em_producao

        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("ALLOW_SEED_IN_PRODUCTION", None)
            with self.assertRaises(CommandError) as contexto:
                abortar_seed_em_producao("seed_demo")
        mensagem = str(contexto.exception)
        self.assertNotIn("no .env e rode", mensagem)
        self.assertIn("NUNCA no .env", mensagem)
        self.assertIn("atualizar_demo.sh --renovar-cenario", mensagem)
        self.assertIn("seed_demo --manter-senhas", mensagem)
        self.assertIn("definir_senha_demo --verificar", mensagem)

    @override_settings(DEBUG=False, TESTING=False)
    def test_aviso_destacado_no_servidor_enquanto_houver_senha_publica(self):
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            relatorio = _seed()
            self.assertIn("SENHA PÚBLICA", relatorio)
            self.assertIn("python manage.py definir_senha_demo", relatorio)
            self.assertIn("demo_proprietario", relatorio.split("SENHA PÚBLICA", 1)[1])

            _definir("--gerar")
            relatorio = _seed("--manter-senhas")
        self.assertNotIn("SENHA PÚBLICA", relatorio)
        self.assertNotIn("definir_senha_demo", relatorio)


@override_settings(PASSWORD_HASHERS=HASHER_RAPIDO)
class SeedManterSenhasBancoNovoTestCase(MidiaTemporariaMixin, TestCase):
    @override_settings(DEBUG=True, TESTING=False)
    def test_usuarios_novos_nascem_com_a_senha_publica_e_sem_aviso_na_demo_local(self):
        relatorio = _seed("--manter-senhas")
        for username in (*SEIS, "vp_atendente_beatriz"):
            self.assertTrue(_tem_senha(username, SENHA_PUBLICA), username)
        self.assertIn("Criados agora, com a senha pública de demonstração", relatorio)
        self.assertNotIn("SENHA PÚBLICA", relatorio)


# ---------------------------------------------------------------------------
# 6. Arquivos de deploy/pythonanywhere/
# ---------------------------------------------------------------------------


def _ler(nome):
    return (PA_DIR / nome).read_text(encoding="utf-8")


def _bash():
    """O bash do Git no Windows (o do System32 é o WSL, que pode nem estar
    instalado); no Linux, o do PATH."""
    if os.name == "nt":
        candidatos = [Path(r"C:\Program Files\Git\bin\bash.exe")]
        encontrado = shutil.which("bash")
        if encontrado and "system32" not in encontrado.lower():
            candidatos.append(Path(encontrado))
    else:
        encontrado = shutil.which("bash")
        candidatos = [Path(encontrado)] if encontrado else []
    for candidato in candidatos:
        if candidato.exists():
            return str(candidato)
    return None


class ArquivosPythonAnywhereTestCase(SimpleTestCase):
    def test_todos_os_arquivos_existem(self):
        for nome in ARQUIVOS_PA:
            self.assertTrue((PA_DIR / nome).is_file(), nome)

    def test_arquivos_vao_para_o_github(self):
        from core.tests_producao import _ignorado, _padroes_gitignore

        padroes = _padroes_gitignore()
        for nome in ARQUIVOS_PA:
            self.assertFalse(_ignorado(f"deploy/pythonanywhere/{nome}", padroes), nome)
        self.assertFalse(_ignorado("docs/DEPLOY_PYTHONANYWHERE_DEMO.md", padroes))
        self.assertFalse(_ignorado("core/management/commands/definir_senha_demo.py", padroes))

    def test_fim_de_linha_lf_e_sem_bom(self):
        for arquivo in PA_DIR.iterdir():
            if arquivo.is_file():
                with self.subTest(arquivo=arquivo.name):
                    conteudo = arquivo.read_bytes()
                    self.assertNotIn(b"\r", conteudo)
                    self.assertFalse(conteudo.startswith(b"\xef\xbb\xbf"))

    def test_scripts_bash_com_shebang_e_modo_estrito(self):
        for script in sorted(PA_DIR.glob("*.sh")):
            with self.subTest(script=script.name):
                conteudo = script.read_text(encoding="utf-8")
                self.assertTrue(conteudo.startswith("#!/usr/bin/env bash\n"))
                if script.name != "_comum_pa.sh":
                    self.assertIn("set -euo pipefail", conteudo)
                if script.name in ATALHOS_PA:
                    # Atalho: só repassa tudo ao script geral.
                    self.assertIn(f'exec bash "$SCRIPT_DIR/{ATALHOS_PA[script.name]}" "$@"', conteudo)
                elif script.name != "_comum_pa.sh":
                    self.assertIn('. "$SCRIPT_DIR/_comum_pa.sh"', conteudo)

    def test_nenhum_segredo_nem_senha_publica(self):
        for arquivo in sorted(PA_DIR.iterdir()):
            if not arquivo.is_file():
                continue
            texto = arquivo.read_text(encoding="utf-8")
            with self.subTest(arquivo=arquivo.name):
                self.assertNotIn(SENHA_PUBLICA, texto)
                for nome, valor in re.findall(r"(?m)^\s*(SECRET_KEY|INITIAL_SETUP_TOKEN|DB_PASSWORD)=(.*)$", texto):
                    self.assertTrue(valor == "" or valor.startswith("$"), f"{nome}={valor!r}")
                # Nada com cara de chave/token de verdade.
                self.assertEqual(_parece_segredo(texto), [])

    def test_pins_iguais_aos_do_requirements(self):
        def pins(caminho):
            resultado = {}
            for linha in caminho.read_text(encoding="utf-8").splitlines():
                linha = linha.split("#", 1)[0].strip()
                if linha:
                    nome, versao = linha.split("==")
                    resultado[nome.strip().lower()] = versao.strip()
            return resultado

        principal = pins(BASE_DIR / "requirements.txt")
        pa = pins(PA_DIR / "requirements-pythonanywhere.txt")
        self.assertEqual(set(pa), {"django", "whitenoise", "python-dotenv", "pillow"})
        for nome, versao in pa.items():
            self.assertEqual(versao, principal[nome], nome)
        self.assertNotIn("gunicorn", pa)
        self.assertNotIn("psycopg2-binary", pa)

    def test_env_gerado_pelo_preparar_e_seguro_e_documentado(self):
        preparar = _ler("preparar.sh")
        bloco = preparar.split('cat > "$temporario" <<EOF', 1)[1].split("\nEOF", 1)[0]
        linhas = dict(re.findall(r"(?m)^([A-Z][A-Z0-9_]*)=(.*)$", bloco))
        esperado = {
            "DEBUG": "False", "DEMO_MODE": "True", "DEMO_EXIBIR_SENHA": "False",
            "SECURE_SSL_REDIRECT": "False", "USA_PROXY_HTTPS": "True", "SQLITE_WAL": "False",
            "INITIAL_SETUP_TOKEN": "", "ALLOWED_HOSTS": "${DOMINIO}",
            "CSRF_TRUSTED_ORIGINS": "https://${DOMINIO}", "SECRET_KEY": "${chave}",
        }
        for nome, valor in esperado.items():
            self.assertEqual(linhas.get(nome), valor, nome)
        for nome in ("SQLITE_PATH", "MEDIA_ROOT", "STATIC_ROOT", "ADMIN_URL"):
            self.assertIn(nome, linhas)
        self.assertNotIn("ALLOW_SEED_IN_PRODUCTION", bloco)
        self.assertIn("chmod 600", preparar)
        # O .env só é criado quando NÃO existe.
        inicio = preparar.index('if [[ -f "$ENV_FILE" ]]; then')
        self.assertIn("mantido sem nenhuma alteração", preparar[inicio:preparar.index("    criar_env\n", inicio)])
        self.assertEqual(len(re.findall(r"(?m)^\s+criar_env\s*$", preparar)), 1)

        exemplo = _ler("nexbuy.env.pythonanywhere.exemplo")
        documentadas = set(re.findall(r"(?m)^#?\s*([A-Z][A-Z0-9_]*)=", exemplo))
        self.assertEqual(set(linhas) - documentadas, set())
        self.assertNotRegex(exemplo, r"(?m)^ALLOW_SEED_IN_PRODUCTION=")

    def test_seed_so_com_autorizacao_na_linha_do_comando(self):
        todos = {nome: _ler(nome) for nome in sorted(p.name for p in PA_DIR.glob("*.sh"))}
        ocorrencias = [
            (nome, linha.strip()) for nome, texto in todos.items() for linha in texto.splitlines()
            if "ALLOW_SEED_IN_PRODUCTION=" in linha and not linha.strip().startswith("#")
        ]
        self.assertEqual(ocorrencias, [("_comum_pa.sh", "( export ALLOW_SEED_IN_PRODUCTION=True; cd \"$APP_DIR\" && \"$VENV_PY\" manage.py \"$@\" )")])
        for nome in ("preparar.sh", "atualizar.sh", "ativar_uso_real.sh"):
            for linha in todos[nome].splitlines():
                if "seed_demo" in linha and "manage" in linha and not linha.strip().startswith("#"):
                    self.assertIn("manage_seed", linha, f"{nome}: {linha}")
        for texto in todos.values():
            self.assertNotIn("settings_demo", texto)

    def test_atualizar_renova_mantendo_senhas_com_confirmacao_e_backup(self):
        atualizar = _ler("atualizar.sh")
        comum = _ler("_comum_pa.sh")
        self.assertIn("seed_demo --manter-senhas", atualizar)
        self.assertIn('[[ "$resposta" == "SIM" ]]', comum)
        self.assertIn("--sim", atualizar)
        corpo = atualizar.split("etapa \"1/7\"", 1)[1]
        self.assertLess(corpo.index("confirmar_apagar_cenario"), corpo.index("backup.sh"))
        self.assertLess(corpo.index("backup.sh"), corpo.index("migrate --noinput"))
        self.assertLess(corpo.index("migrate --noinput"), corpo.index("seed_demo --manter-senhas"))
        self.assertIn("definir_senha_demo --verificar", atualizar)
        self.assertIn("recarregar_site", atualizar)

    def test_preparar_cobre_todas_as_etapas_na_ordem(self):
        preparar = _ler("preparar.sh")
        ordem = [
            "python3.13 python3.12", "-m venv", "instalar_dependencias", "criar_env",
            "migrate --noinput", "collectstatic --noinput", "check --deploy", "manage_seed seed_demo",
            "definir_senha_demo ${ARGS_SENHA", "definir_senha_demo --verificar || falhar", "WSGI_ORIGINAL_BACKUP",
            "recarregar_site", "Security > Force HTTPS",
        ]
        posicoes = [preparar.index(trecho) for trecho in ordem]
        self.assertEqual(posicoes, sorted(posicoes))
        for opcao in ("--gerar-senha", "--senha-individual", "--eu", "--recriar-cenario", "--sem-wsgi"):
            self.assertIn(f"{opcao})", preparar)
        for variavel in ("NEXBUY_HOME", "NEXBUY_PYTHON", "NEXBUY_VENV", "PA_DOMINIO"):
            self.assertIn(variavel, _ler("_comum_pa.sh") + preparar)
        self.assertIn('"$VENV_DIR/Scripts/python.exe"', _ler("_comum_pa.sh"))

    def test_backup_usa_a_api_do_sqlite_e_guarda_5(self):
        backup = _ler("backup.sh")
        self.assertIn("pip install --no-cache-dir", _ler("_comum_pa.sh"))
        self.assertIn(".backup(", backup)
        self.assertIn("PRAGMA integrity_check", backup)
        self.assertIn("MANTER=5", backup)
        self.assertIn("nexbuy_${CARIMBO}", backup)
        self.assertIn("date +%Y-%m-%d_%H%M", backup)
        self.assertNotRegex(backup, r"(?m)^\s*cp .*sqlite3")
        self.assertIn("aba Files", backup)

    def test_modelo_wsgi(self):
        texto = _ler("wsgi_pythonanywhere.py")
        compile(texto, "wsgi_pythonanywhere.py", "exec")
        self.assertIn('CAMINHO_DO_PROJETO = "/home/SEU_USUARIO/nexbuy"', texto)
        self.assertIn('os.environ["DJANGO_SETTINGS_MODULE"] = "nexbuy.settings"', texto)
        self.assertNotIn('"nexbuy.settings_demo"', texto)
        self.assertIn("application = get_wsgi_application()", texto)
        self.assertIn("NEXBUY_WSGI_PYTHONANYWHERE", texto)

    def test_bash_n_de_todos_os_scripts(self):
        bash = _bash()
        if bash is None:
            self.skipTest("bash não encontrado (no Windows: Git Bash em C:\\Program Files\\Git\\bin\\bash.exe)")
        for script in sorted(PA_DIR.glob("*.sh")):
            with self.subTest(script=script.name):
                resultado = subprocess.run(
                    [bash, "-n", script.as_posix()], capture_output=True, text=True, timeout=60,
                )
                self.assertEqual(resultado.returncode, 0, resultado.stderr)

    def test_senhas_ja_definidas_nunca_mudam_sem_trocar_senha(self):
        """Simulação da publicação: repetir `preparar.sh --gerar-senha` (seta
        para cima no console) trocava as senhas dos 6 sem aviso — a senha
        que a cliente recebeu parava de valer. Agora só quem está SEM senha
        recebe senha; trocar exige --trocar-senha (e SIM)."""
        preparar = _ler("preparar.sh")
        etapa8 = preparar.split('etapa "8/9"', 1)[1].split('etapa "9/9"', 1)[0]
        self.assertIn("--trocar-senha)", preparar)
        self.assertLess(etapa8.index("definir_senha_demo --bloquear"), etapa8.index("listar_demo_sem_senha"))
        self.assertLess(etapa8.index("listar_demo_sem_senha"), etapa8.index("definir_senha_demo ${ARGS_SENHA"))
        bloco_trocar = etapa8.split('if [[ "$TROCAR_SENHA" == "1" ]]; then', 1)[1].split("elif", 1)[0]
        self.assertIn('confirmar_troca_de_senha "$CONFIRMADO"', bloco_trocar)
        self.assertIn('ARGS_SENHA+=(--usuarios "$SEM_SENHA")', etapa8)
        self.assertIn("MANTIDAS", etapa8)
        # PRECISA_SENHA só liga com --trocar-senha ou com usuário sem senha.
        self.assertEqual(len(re.findall(r"PRECISA_SENHA=1", etapa8)), 2)
        self.assertNotRegex(etapa8, r'GERAR_SENHA" == "1" \|\| "\$SENHA_INDIVIDUAL" == "1" \]\]; then\s+PRECISA_SENHA=1')
        comum = _ler("_comum_pa.sh")
        self.assertIn('[[ "$resposta" == "SIM" ]] || falhar "Cancelado: as senhas continuam as mesmas."', comum)

        atualizar = _ler("atualizar.sh")
        chamadas = [
            linha.strip() for linha in atualizar.splitlines()
            if "manage definir_senha_demo" in linha and not linha.strip().startswith("#")
        ]
        self.assertTrue(chamadas)
        for linha in chamadas:
            self.assertTrue(
                "--verificar" in linha or "--bloquear" in linha or '"${ARGS_SENHA[@]}"' in linha, linha,
            )
        self.assertIn('ARGS_SENHA=(--usuarios "$SEM_SENHA")', atualizar)

    def test_falha_fechada_bloqueia_a_senha_publica_antes_de_pedir_a_nova(self):
        for nome in ("preparar.sh", "atualizar.sh"):
            with self.subTest(script=nome):
                texto = _ler(nome)
                self.assertLess(texto.index("definir_senha_demo --bloquear"), texto.index("listar_demo_sem_senha)"))
                self.assertIn("conferir_force_https", texto)
        preparar = _ler("preparar.sh")
        self.assertLess(preparar.index("manage_seed seed_demo"), preparar.index("definir_senha_demo --bloquear"))

    def _rodar_comum(self, corpo, *, com_venv, ambiente_extra=None):
        bash = _bash()
        if bash is None:
            self.skipTest("bash não encontrado (no Windows: Git Bash em C:\\Program Files\\Git\\bin\\bash.exe)")
        import sys

        pasta = Path(tempfile.mkdtemp(prefix="nexbuy_comum_"))
        self.addCleanup(shutil.rmtree, pasta, True)
        venv = Path(sys.executable).resolve().parent.parent if com_venv else pasta / "sem_venv"
        script = (
            "set -euo pipefail\n"
            f"SCRIPT_DIR='{PA_DIR.as_posix()}'\n"
            '. "$SCRIPT_DIR/_comum_pa.sh"\n'
            + corpo
        )
        ambiente = {**os.environ, "NEXBUY_HOME": pasta.as_posix(), "NEXBUY_VENV": venv.as_posix(),
                    "PYTHONIOENCODING": "utf-8", **(ambiente_extra or {})}
        resultado = subprocess.run(
            [bash, "-c", script], capture_output=True, text=True, encoding="utf-8", timeout=120, env=ambiente,
        )
        return pasta, resultado

    def test_trava_de_debug_le_o_env_como_o_python_dotenv(self):
        """Revisão de segurança: o grep antigo não via `export DEBUG=True`,
        `DEBUG = True` nem `DEBUG=True # comentário` — o settings (python-
        dotenv) via DEBUG ligado e os scripts seguiam. Vale com o virtualenv
        (dotenv_values) e sem ele (leitor em bash)."""
        formatos = {
            "export": "DEBUG=False\nexport DEBUG=True\nALLOW_SEED_IN_PRODUCTION=False\nexport ALLOW_SEED_IN_PRODUCTION=True\n",
            "espacos": "DEBUG=False\nDEBUG = True\nALLOW_SEED_IN_PRODUCTION = sim\n",
            "comentario": "DEBUG=False\nDEBUG=True # comentario\nALLOW_SEED_IN_PRODUCTION=1 # nao\n",
            "aspas": "DEBUG=False\nDEBUG=\"True\"\nALLOW_SEED_IN_PRODUCTION='yes'\n",
        }
        corpo = (
            'for arquivo in "$PASTA_ENVS"/*.env; do\n'
            '  ENV_FILE="$arquivo"\n'
            '  for v in DEBUG ALLOW_SEED_IN_PRODUCTION; do\n'
            '    if env_ligado "$v"; then echo "$(basename "$arquivo") $v LIGADO"; else echo "$(basename "$arquivo") $v DESLIGADO"; fi\n'
            '  done\n'
            '  ENV_FILE="$arquivo.inexistente"; echo "sem_env [$(valor_env DEBUG padrao)]"\n'
            'done\n'
        )
        for com_venv in (True, False):
            with self.subTest(leitor="python-dotenv" if com_venv else "bash"):
                envs = Path(tempfile.mkdtemp(prefix="nexbuy_envs_"))
                self.addCleanup(shutil.rmtree, envs, True)
                for nome, conteudo in formatos.items():
                    (envs / f"{nome}.env").write_bytes(conteudo.encode("utf-8"))
                _pasta, resultado = self._rodar_comum(
                    corpo, com_venv=com_venv, ambiente_extra={"PASTA_ENVS": envs.as_posix()},
                )
                self.assertEqual(resultado.returncode, 0, resultado.stderr)
                linhas = resultado.stdout.splitlines()
                for nome in formatos:
                    self.assertIn(f"{nome}.env DEBUG LIGADO", linhas)
                    self.assertIn(f"{nome}.env ALLOW_SEED_IN_PRODUCTION LIGADO", linhas)
                self.assertIn("sem_env [padrao]", linhas)

    def test_valor_env_e_desligado_quando_deve(self):
        corpo = (
            'ENV_FILE="$PASTA_ENVS/ok.env"\n'
            'env_ligado DEBUG && echo "DEBUG LIGADO" || echo "DEBUG DESLIGADO"\n'
            'echo "HOSTS [$(valor_env ALLOWED_HOSTS)]"\n'
            'echo "VAZIO [$(valor_env SQLITE_PATH /padrao/db.sqlite3)]"\n'
            'echo "AUSENTE [$(valor_env ADMIN_URL admin/)]"\n'
        )
        for com_venv in (True, False):
            with self.subTest(leitor="python-dotenv" if com_venv else "bash"):
                envs = Path(tempfile.mkdtemp(prefix="nexbuy_envs_"))
                self.addCleanup(shutil.rmtree, envs, True)
                (envs / "ok.env").write_bytes(
                    b"DEBUG=False\nALLOWED_HOSTS=nexbuydemo.pythonanywhere.com\nSQLITE_PATH=\n# DEBUG=True\n"
                )
                _pasta, resultado = self._rodar_comum(
                    corpo, com_venv=com_venv, ambiente_extra={"PASTA_ENVS": envs.as_posix()},
                )
                self.assertEqual(resultado.returncode, 0, resultado.stderr)
                self.assertEqual(resultado.stdout.splitlines(), [
                    "DEBUG DESLIGADO", "HOSTS [nexbuydemo.pythonanywhere.com]",
                    "VAZIO [/padrao/db.sqlite3]", "AUSENTE [admin/]",
                ])

    def test_eu_corrige_so_o_endereco_do_env(self):
        """Crítico do guia: numa conta EU em que o script rodou antes como US,
        `preparar.sh --eu` gravava o WSGI da EU mas deixava o .env com o host
        US (site em 400). Agora corrige ALLOWED_HOSTS e CSRF_TRUSTED_ORIGINS e
        mais nada."""
        preparar = _ler("preparar.sh")
        self.assertIn('if [[ "$REGIAO" == "eu" || -n "${PA_DOMINIO:-}" ]]; then\n                # Endereço', preparar)
        self.assertIn("gravar_dominio_no_env", preparar)
        corpo = (
            'ENV_FILE="$PASTA_ENVS/eu.env"\n'
            'DOMINIO="nexbuyeu.eu.pythonanywhere.com"\n'
            "gravar_dominio_no_env\n"
            'cat "$ENV_FILE"\n'
        )
        envs = Path(tempfile.mkdtemp(prefix="nexbuy_envs_"))
        self.addCleanup(shutil.rmtree, envs, True)
        (envs / "eu.env").write_bytes(
            b"SECRET_KEY=valor-de-teste-nao-secreto\nDEBUG=False\nALLOWED_HOSTS=nexbuyeu.pythonanywhere.com\n"
            b"export CSRF_TRUSTED_ORIGINS=https://nexbuyeu.pythonanywhere.com\nSQLITE_WAL=False\n"
        )
        _pasta, resultado = self._rodar_comum(corpo, com_venv=False, ambiente_extra={"PASTA_ENVS": envs.as_posix()})
        self.assertEqual(resultado.returncode, 0, resultado.stderr)
        self.assertEqual(resultado.stdout.splitlines(), [
            "SECRET_KEY=valor-de-teste-nao-secreto", "DEBUG=False", "SQLITE_WAL=False",
            "ALLOWED_HOSTS=nexbuyeu.eu.pythonanywhere.com",
            "CSRF_TRUSTED_ORIGINS=https://nexbuyeu.eu.pythonanywhere.com",
        ])


# ---------------------------------------------------------------------------
# 7. gerar_pacote.py
# ---------------------------------------------------------------------------


def _modulo_gerar_pacote():
    """Carrega o script sem deixar __pycache__ dentro de deploy/pythonanywhere/."""
    import sys

    spec = importlib.util.spec_from_file_location("gerar_pacote_pa", PA_DIR / "gerar_pacote.py")
    modulo = importlib.util.module_from_spec(spec)
    antes = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(modulo)
    finally:
        sys.dont_write_bytecode = antes
    return modulo


class GerarPacoteTestCase(SimpleTestCase):
    INCLUIDOS = {
        "manage.py", "core/views.py", "deploy/pythonanywhere/preparar.sh", ".env.example",
        "templates/base.html", "static/css/nexbuy.css",
    }
    EXCLUIDOS = {
        ".env", ".env.local", ".env.producao", "nexbuy.env", "db.sqlite3", "db.sqlite3-wal",
        "db_demo_cliente.sqlite3", "venv/Lib/site.py", "core/__pycache__/views.cpython-314.pyc",
        "media/identidade/logo.png", "media_demo_cliente/x.png", "staticfiles/css/a.css",
        "qa_showcase_screenshots/tela.png", "test_run_core.txt", "servidor.log", "cookies.txt",
        "chave.pem", "servidor.key", "pacote_antigo.zip",
    }

    def setUp(self):
        self.modulo = _modulo_gerar_pacote()
        self.pasta = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.addCleanup(self.pasta.cleanup)
        self.raiz = Path(self.pasta.name) / "projeto"
        for relativo in self.INCLUIDOS | self.EXCLUIDOS:
            caminho = self.raiz / relativo
            caminho.parent.mkdir(parents=True, exist_ok=True)
            caminho.write_text("#!/usr/bin/env bash\n" if relativo.endswith(".sh") else "x\n", encoding="utf-8")

    def test_gera_zip_so_com_o_que_iria_para_o_git(self):
        destino = Path(self.pasta.name) / "saida"
        with mock.patch("sys.stdout", new_callable=io.StringIO) as saida:
            codigo = self.modulo.main(["--raiz", str(self.raiz), str(destino)])
        self.assertEqual(codigo, 0)
        self.assertIn("SHA-256", saida.getvalue())
        self.assertIn(f"Arquivos: {len(self.INCLUIDOS)}", saida.getvalue())
        with zipfile.ZipFile(destino / "NEXBUY_PYTHONANYWHERE.zip") as pacote:
            nomes = pacote.namelist()
            self.assertTrue(all(nome.startswith("nexbuy/") for nome in nomes))
            self.assertTrue(all("\\" not in nome for nome in nomes))
            self.assertEqual({nome[len("nexbuy/"):] for nome in nomes}, self.INCLUIDOS)
            script = pacote.getinfo("nexbuy/deploy/pythonanywhere/preparar.sh")
            self.assertEqual((script.external_attr >> 16) & 0o777, 0o755)
            self.assertEqual(script.create_system, 3)
            self.assertEqual((pacote.getinfo("nexbuy/manage.py").external_attr >> 16) & 0o777, 0o644)

    def test_recusa_env_ou_banco_na_lista(self):
        for proibido in (".env", "db.sqlite3", "nexbuy.env", "core/.env.producao", "chave.pem"):
            with self.subTest(proibido=proibido), self.assertRaises(self.modulo.PacoteRecusado):
                self.modulo.verificar_conteudo([PurePosixPath("manage.py"), PurePosixPath(proibido)])
        self.modulo.verificar_conteudo([PurePosixPath("manage.py"), PurePosixPath(".env.example")])

    def test_recusa_destino_dentro_da_arvore(self):
        with mock.patch("sys.stderr", new_callable=io.StringIO) as erros:
            codigo = self.modulo.main(["--raiz", str(self.raiz), str(self.raiz / "deploy")])
        self.assertEqual(codigo, 2)
        self.assertIn("dentro da pasta do projeto", erros.getvalue())

    def test_pacote_da_arvore_real(self):
        destino = Path(self.pasta.name) / "real" / "NEXBUY_PYTHONANYWHERE.zip"
        with mock.patch("sys.stdout", new_callable=io.StringIO):
            codigo = self.modulo.main([str(destino)])
        self.assertEqual(codigo, 0)
        self.assertLess(destino.stat().st_size, 100 * 1024 * 1024)
        with zipfile.ZipFile(destino) as pacote:
            nomes = set(pacote.namelist())
            for obrigatorio in ("nexbuy/manage.py", "nexbuy/requirements.txt",
                                "nexbuy/deploy/pythonanywhere/preparar.sh",
                                "nexbuy/deploy/pythonanywhere/requirements-pythonanywhere.txt",
                                "nexbuy/docs/DEPLOY_PYTHONANYWHERE_DEMO.md"):
                self.assertIn(obrigatorio, nomes)
            for nome in nomes:
                base = nome.rsplit("/", 1)[-1]
                self.assertFalse(base == ".env" or base.startswith(".env.") and base != ".env.example", nome)
                self.assertNotIn(".sqlite3", nome)
                self.assertNotIn("/venv/", nome)
                self.assertNotIn("__pycache__", nome)
                self.assertFalse(nome.endswith(".zip"), nome)


# ---------------------------------------------------------------------------
# 8. Guia e documentação
# ---------------------------------------------------------------------------


class GuiaPythonAnywhereTestCase(SimpleTestCase):
    def test_guia_cobre_o_caminho_inteiro_com_os_rotulos_exatos(self):
        texto = GUIA.read_text(encoding="utf-8")
        for trecho in (
            "<seu-usuario>", "Beginner", "Add a new web app", "Manual configuration", "Python 3.13",
            "Upload a file", "Bash", "unzip -o NEXBUY_PYTHONANYWHERE.zip",
            "bash deploy/pythonanywhere/preparar.sh", "--gerar-senha", "--senha-individual",
            "Virtualenv", "/home/<seu-usuario>/.virtualenvs/nexbuy", "Static files", "/static/", "/media/",
            "/home/<seu-usuario>/nexbuy_static", "/home/<seu-usuario>/nexbuy_dados/media", "Force HTTPS",
            "Reload", "/demo/apresentacao/", "Run until 1 month from today", "--renovar-cenario",
            "atualizar_demo.sh", "backup_demo.sh", "gerar_pacote.py", "Error log", "DisallowedHost",
            "CSRF", "Too many redirects", "Something went wrong", "LGPD", "Fine-grained",
            "DEPLOY_HOSTINGER_GITHUB.md", "Pedro", "Carla", "Bloqueado",
        ):
            with self.subTest(trecho=trecho):
                self.assertIn(trecho, texto)
        for username in SEIS:
            self.assertIn(f"`{username}`", texto)
        partes = re.findall(r"(?m)^## (\d+)\. ", texto)
        self.assertEqual([int(p) for p in partes], list(range(16)))

    def test_guia_explica_a_renovacao_mensal_e_a_virada_do_mes(self):
        texto = GUIA.read_text(encoding="utf-8")
        secao = texto.split("## 8. ", 1)[1].split("\n## 9. ", 1)[0]
        for trecho in ("3 semanas", "Run until 1 month from today", "virada do mês", "--renovar-cenario",
                       "APAGA", "senhas são mantidas"):
            self.assertIn(trecho, secao)

    def test_guia_sem_senha_real_nem_caminho_desta_maquina(self):
        texto = GUIA.read_text(encoding="utf-8")
        self.assertNotIn(SENHA_PUBLICA, texto)
        self.assertNotRegex(texto, r"(?m)SECRET_KEY=\S")
        self.assertNotRegex(texto, r"C:\\Users")
        self.assertEqual(_parece_segredo(texto), [])
        self.assertNotIn("ALLOW_SEED_IN_PRODUCTION=True", texto)

    def test_guia_corrigido_pelos_criticos(self):
        """Pontos que os verificadores (simulação da publicação e crítico do
        guia) acharam errados ou faltando no guia."""
        texto = GUIA.read_text(encoding="utf-8")
        # O limite individual é dotação DIÁRIA acumulada, não teto por compra.
        self.assertNotRegex(texto, r"R\$ [\d.,]+ por compra")
        self.assertNotIn("limite por compra", texto)
        self.assertIn("R$ 3.500 por DIA", texto)
        self.assertIn("R$ 2.000 por DIA", texto)
        self.assertIn("Minha dotação do dia", texto)
        # Repetir o preparar.sh não troca senha; trocar é explícito.
        self.assertIn("--trocar-senha", texto)
        self.assertIn("as senhas não mudam", texto)
        self.assertNotIn("a senha\n  só é pedida se algum usuário ainda usar a senha pública", texto)
        # A escolha da senha vem ANTES do bloco de comandos.
        self.assertLess(texto.index("### 4.3 ANTES dos comandos"), texto.index("### 4.4 Os comandos"))
        self.assertLess(texto.index("| `bash deploy/pythonanywhere/preparar.sh --gerar-senha` |"),
                        texto.index("```bash\ncd ~\nunzip -o NEXBUY_PYTHONANYWHERE.zip"))
        # Estáticos: o WhiteNoise já serve; /media/ é que é obrigatório.
        self.assertNotIn('(sem isso a página abre "sem\n     estilo")', texto)
        self.assertIn("WhiteNoise", texto)
        self.assertIn("(**obrigatório**)", texto)
        # curl atrás do proxy do console: código final, nunca a 1ª linha do -I.
        self.assertNotIn("curl -sI", texto)
        self.assertIn("-w '%{http_code}\\n'", texto)
        self.assertIn("%{redirect_url}", texto)
        # 400 na conta EU: host certo e CSRF_TRUSTED_ORIGINS junto.
        self.assertIn("`ALLOWED_HOSTS=<seu-host>`", texto)
        self.assertIn("`CSRF_TRUSTED_ORIGINS=https://<seu-host>`", texto)
        # Comandos de console sem "<" (o bash leria como redirecionamento).
        for linha in texto.splitlines():
            comando = linha.strip().lstrip("-").strip().lstrip("`")
            if comando.startswith(("tail ", "curl ")):
                self.assertNotIn("<", linha, linha)
        self.assertIn("tail -n 50 /var/log/$USER.pythonanywhere.com.error.log", texto)
        # gerar_pacote: .env e bancos ficam de fora sozinhos (sem git).
        self.assertIn("ficam de fora **automaticamente**", texto)
        # Lacunas para leigo.
        for trecho in ("digite `powershell`", "| **WSGI** |", "| **SHA-256** |", "| **CSRF** |",
                       "Admin técnico (suporte)", "Python version", "as senhas, uma por usuário",
                       "mv nexbuy nexbuy_antigo", "rm -rf ~/nexbuy_antigo", "rm -rf ~/nexbuy_zip",
                       "DESATIVADOS"):
            self.assertIn(trecho, texto)

    def test_documentos_apontam_para_o_guia(self):
        self.assertIn("docs/DEPLOY_PYTHONANYWHERE_DEMO.md", (BASE_DIR / "README.md").read_text(encoding="utf-8"))
        self.assertIn(
            "DEPLOY_PYTHONANYWHERE_DEMO.md",
            (BASE_DIR / "docs" / "DEPLOY_HOSTINGER_GITHUB.md").read_text(encoding="utf-8"),
        )
        demo_mode = (BASE_DIR / "DEMO_MODE.md").read_text(encoding="utf-8")
        for trecho in ("DEMO_EXIBIR_SENHA", "definir_senha_demo", "--manter-senhas", "DEPLOY_PYTHONANYWHERE_DEMO.md"):
            self.assertIn(trecho, demo_mode)
        self.assertIn("DEMO_EXIBIR_SENHA", (BASE_DIR / ".env.example").read_text(encoding="utf-8"))
