"""Gate 1 (Sprint de Encerramento Definitivo) — testes de regressão de
ATOMICIDADE.

Contexto: toda view de escrita do sistema foi envolvida em
`transaction.atomic()` para que uma falha em `registrar_evento`
(`auditoria/services.py`) provoque ROLLBACK COMPLETO — a alteração de
negócio e os outros três mecanismos de histórico (`LogConfiguracao`,
`HistoricoCompra`, `HistoricoProvisao`) não podem ficar gravados pela
metade. Esta correção já foi aplicada em todos os arquivos de view
(`empresas/views_ncc.py`, `empresas/views.py`, `financeiro/views.py`) e os
services de Compra/Provisão (`compras/services.py`,
`gestao_compras/services.py`) já eram atômicos antes desta sprint.

Cada teste abaixo simula uma falha em `registrar_evento` (via
`unittest.mock.patch`, com o exceto exatamente no NAMESPACE que faz a
chamada — não no módulo de origem) e comprova que NADA sobrevive: nem o
objeto de negócio, nem nenhum dos mecanismos de histórico/auditoria.

Usa `TransactionTestCase` (não `TestCase`) deliberadamente: `TestCase`
envolve cada teste na sua PRÓPRIA transação externa que nunca é
efetivamente commitada, o que mascararia um `transaction.atomic()`
ausente no código sob teste (o rollback "funcionaria" mesmo sem a correção
real). `TransactionTestCase` grava de verdade e dá `flush` entre testes,
expondo o comportamento real do banco.

Rode com: python manage.py test core.tests_gate1_atomicidade --verbosity=2
"""
from datetime import date
from decimal import Decimal
from unittest import mock

from django.test import Client, TransactionTestCase, override_settings

from auditoria.models import RegistroAuditoria
from cadastros.models import Categoria
from compras.models import Compra, Fornecedor, HistoricoCompra, ParcelaCompra
from empresas.models import ConfiguracaoPlataforma, Empresa, LogConfiguracao
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, Receita
from gestao_compras.models import HistoricoProvisao, Provisao
from usuarios.models import Usuario, UsuarioEmpresa

FALHA_SIMULADA = RuntimeError("Falha simulada na Auditoria (teste de rollback)")


@override_settings(ALLOWED_HOSTS=["*"])
class FilialEdicaoAtomicidadeTestCase(TransactionTestCase):
    """Cenário 1 — Criar/editar Filial (`empresas/views_ncc.py::ncc_filial_editar`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Filial", cnpj="10.000.001/0001-01")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Teste", cidade="Cuiabá", ativo=True)
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate1_filial", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.proprietario)

    def test_falha_na_auditoria_reverte_edicao_de_filial(self):
        log_antes = LogConfiguracao.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("empresas.views_ncc.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                f"/ncc/filiais/{self.filial.pk}/",
                {"nome": "Matriz Teste Editada", "tipo_estabelecimento": "matriz", "cidade": "Cuiabá", "ativo": "on"},
            )

        self.filial.refresh_from_db()
        self.assertEqual(self.filial.nome, "Matriz Teste")
        self.assertEqual(LogConfiguracao.objects.count(), log_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class UsuarioEdicaoAtomicidadeTestCase(TransactionTestCase):
    """Cenário 2 — Edição de usuário/perfil/permissões
    (`empresas/views_ncc.py::ncc_usuario_editar`, ramo `salvar_dados`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Usuario", cnpj="10.000.002/0001-02")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate1_usuario", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.alvo = Usuario.objects.create_user(
            username="alvo_gate1_usuario", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial, first_name="Pedro", last_name="Original",
            email="pedro@original.com",
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.proprietario)

    def test_falha_na_auditoria_reverte_alteracao_de_perfil(self):
        log_antes = LogConfiguracao.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("empresas.views_ncc.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                f"/ncc/usuarios/{self.alvo.pk}/",
                {
                    "first_name": "Pedro", "last_name": "Editado", "email": "pedro@novo.com",
                    "perfil": Usuario.Perfil.FINANCEIRO, "filial": self.filial.pk, "is_active": "on",
                    "salvar_dados": "1",
                },
            )

        self.alvo.refresh_from_db()
        self.assertEqual(self.alvo.perfil, Usuario.Perfil.COMPRADOR)
        self.assertEqual(self.alvo.last_name, "Original")
        self.assertEqual(self.alvo.email, "pedro@original.com")
        self.assertEqual(LogConfiguracao.objects.count(), log_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class AutoaprovacaoAtomicidadeTestCase(TransactionTestCase):
    """Cenário 3 — Autoaprovação/configuração (`empresas/views_ncc.py::ncc_gerais`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Config", cnpj="10.000.003/0001-03")
        self.config = ConfiguracaoPlataforma.objects.create(empresa=self.empresa)
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate1_config", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.proprietario)

    def test_falha_na_auditoria_reverte_autoaprovacao(self):
        self.assertFalse(self.config.permitir_autoaprovacao)
        log_antes = LogConfiguracao.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("empresas.views_ncc.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                "/ncc/gerais/",
                {
                    "fuso_horario": "America/Cuiaba", "parcelas_maximas": "12",
                    "permitir_autoaprovacao": "on", "justificativa_autoaprovacao": "teste de rollback",
                },
            )

        self.config.refresh_from_db()
        self.assertFalse(self.config.permitir_autoaprovacao)
        self.assertEqual(LogConfiguracao.objects.count(), log_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class ReceitaEdicaoAtomicidadeTestCase(TransactionTestCase):
    """Cenário 4 — Receita (`financeiro/views.py::ReceitaUpdateView.form_valid`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Receita", cnpj="10.000.004/0001-04")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.financeiro = Usuario.objects.create_user(
            username="fin_gate1_receita", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.receita = Receita.objects.create(filial=self.filial, mes=date(2026, 8, 1), faturamento=Decimal("100000"))
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.financeiro)

    def test_falha_na_auditoria_reverte_edicao_de_receita(self):
        log_antes = LogConfiguracao.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("financeiro.views.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                f"/financeiro/receitas/{self.receita.pk}/editar/",
                {"filial": self.filial.pk, "mes": "2026-08-01", "faturamento": "999999.99"},
            )

        self.receita.refresh_from_db()
        self.assertEqual(self.receita.faturamento, Decimal("100000"))
        self.assertEqual(LogConfiguracao.objects.count(), log_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class BaixarParcelaAtomicidadeTestCase(TransactionTestCase):
    """Cenário 5 — Baixa de parcela (`financeiro/views.py::baixar_parcela`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Baixa", cnpj="10.000.005/0001-05")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Gate1 Baixa")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Gate1 Baixa")
        self.financeiro = Usuario.objects.create_user(
            username="fin_gate1_baixa", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.compra = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, categoria=self.categoria,
            valor=Decimal("1000.00"), data_compra=date(2026, 8, 1), status=Compra.Status.APROVADA,
        )
        self.parcela = ParcelaCompra.objects.create(
            compra=self.compra, numero=1, data_vencimento=date(2026, 9, 1), valor=Decimal("1000.00"),
            status=ParcelaCompra.Status.PENDENTE,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.financeiro)

    def test_falha_na_auditoria_reverte_baixa_de_parcela(self):
        historico_antes = HistoricoCompra.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("financeiro.views.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(f"/financeiro/agenda/parcela/{self.parcela.pk}/baixar/")

        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, ParcelaCompra.Status.PENDENTE)
        self.assertEqual(HistoricoCompra.objects.count(), historico_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class EstornarParcelaAtomicidadeTestCase(TransactionTestCase):
    """Cenário 6 — Estorno de parcela (`financeiro/views.py::estornar_parcela`)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Estorno", cnpj="10.000.006/0001-06")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Gate1 Estorno")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Gate1 Estorno")
        self.financeiro = Usuario.objects.create_user(
            username="fin_gate1_estorno", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.compra = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, categoria=self.categoria,
            valor=Decimal("1000.00"), data_compra=date(2026, 8, 1), status=Compra.Status.APROVADA,
        )
        # Parcela já paga — pré-condição do estorno (dado direto, sem baixa
        # via requisição, para isolar só o comportamento do estorno).
        self.parcela = ParcelaCompra.objects.create(
            compra=self.compra, numero=1, data_vencimento=date(2026, 9, 1), valor=Decimal("1000.00"),
            status=ParcelaCompra.Status.PAGA,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.financeiro)

    def test_falha_na_auditoria_reverte_estorno_de_parcela(self):
        historico_antes = HistoricoCompra.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("financeiro.views.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                f"/financeiro/agenda/parcela/{self.parcela.pk}/estornar/",
                {"justificativa": "Baixa lançada na parcela errada por engano."},
            )

        self.parcela.refresh_from_db()
        self.assertEqual(self.parcela.status, ParcelaCompra.Status.PAGA)
        self.assertEqual(HistoricoCompra.objects.count(), historico_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class BloquearCompradorAtomicidadeTestCase(TransactionTestCase):
    """Cenário 7 — Limite/bloqueio de Comprador
    (`financeiro/views_capacidade.py::capacidade_bloquear` →
    `compras/services.py::bloquear_comprador`, que já tinha
    `transaction.atomic()` interno antes desta sprint)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Bloqueio", cnpj="10.000.007/0001-07")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.financeiro = Usuario.objects.create_user(
            username="fin_gate1_bloqueio", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.comprador = Usuario.objects.create_user(
            username="comp_gate1_bloqueio", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        # Autorização já existente e explicitamente desbloqueada — isola o
        # teste do comportamento de `get_or_create` (não é sobre criar ou
        # não a UsuarioEmpresa, é sobre `bloqueado` nunca virar True).
        self.autorizacao = UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, ativo=True, bloqueado=False,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.financeiro)

    def test_falha_na_auditoria_reverte_bloqueio_de_comprador(self):
        usuario_empresa_antes = UsuarioEmpresa.objects.count()
        log_antes = LogConfiguracao.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("compras.services.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(f"/financeiro/capacidade-compradores/{self.comprador.pk}/bloquear/")

        self.autorizacao.refresh_from_db()
        self.assertFalse(self.autorizacao.bloqueado)
        self.assertEqual(UsuarioEmpresa.objects.count(), usuario_empresa_antes)
        self.assertEqual(LogConfiguracao.objects.count(), log_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class NovaCompraAtomicidadeTestCase(TransactionTestCase):
    """Cenário 8 — Lançamento de Compra
    (`compras/views.py::nova_compra` → `compras/services.py::avaliar_e_criar_compra`,
    que já tinha `transaction.atomic()` interno antes desta sprint)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Compra", cnpj="10.000.008/0001-08")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz Gate1 Compra", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
        )
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Gate1 Compra")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Gate1 Compra")
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate1_compra", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
            empresa=self.empresa, is_staff=False, is_superuser=False,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.proprietario)

    def test_falha_na_auditoria_reverte_lancamento_de_compra(self):
        compras_antes = Compra.objects.count()
        historico_antes = HistoricoCompra.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("compras.services.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                "/compras/nova/",
                {
                    "filial": self.filial.pk, "fornecedor": self.fornecedor.pk, "valor": "50,00",
                    "categoria": self.categoria.pk, "data_compra": date.today().isoformat(),
                    "prazo_pagamento": Compra.PrazoPagamento.AVISTA,
                },
            )

        self.assertEqual(Compra.objects.count(), compras_antes)
        self.assertEqual(HistoricoCompra.objects.count(), historico_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)


@override_settings(ALLOWED_HOSTS=["*"])
class NovaProvisaoAtomicidadeTestCase(TransactionTestCase):
    """Cenário 9 — Criação de Provisão
    (`gestao_compras/views.py::nova_provisao` →
    `gestao_compras/services.py::criar_provisao`, que já tinha
    `transaction.atomic()` interno antes desta sprint)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate1 Provisao", cnpj="10.000.009/0001-09")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz Gate1 Provisao", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa)
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Gate1 Provisao")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Gate1 Provisao")
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate1_provisao", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
            empresa=self.empresa, is_staff=False, is_superuser=False,
        )
        self.client = Client(raise_request_exception=False)
        self.client.force_login(self.proprietario)

    def test_falha_na_auditoria_reverte_criacao_de_provisao(self):
        provisoes_antes = Provisao.objects.count()
        historico_antes = HistoricoProvisao.objects.count()
        auditoria_antes = RegistroAuditoria.objects.count()

        with mock.patch("gestao_compras.services.registrar_evento", side_effect=FALHA_SIMULADA):
            self.client.post(
                "/gestao-compras/nova/",
                {
                    "filial": self.filial.pk, "fornecedor": self.fornecedor.pk, "categoria": self.categoria.pk,
                    "data": date.today().isoformat(), "observacoes": "",
                    "itens-TOTAL_FORMS": "1", "itens-INITIAL_FORMS": "0",
                    "itens-MIN_NUM_FORMS": "0", "itens-MAX_NUM_FORMS": "1000",
                    "itens-0-produto": "Item Gate1 Provisao", "itens-0-quantidade": "1",
                    "itens-0-valor_unitario": "50,00",
                },
            )

        self.assertEqual(Provisao.objects.count(), provisoes_antes)
        self.assertEqual(HistoricoProvisao.objects.count(), historico_antes)
        self.assertEqual(RegistroAuditoria.objects.count(), auditoria_antes)
