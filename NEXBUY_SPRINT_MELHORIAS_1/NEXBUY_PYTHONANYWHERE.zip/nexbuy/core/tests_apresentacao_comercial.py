"""Sprint de Apresentação Comercial — testes obrigatórios (Seção 14).

Cobrem o que a sprint adicionou:

1. Tela de abertura (`/demo/apresentacao/`) com o mapa de valor embutido;
2. Tela de encerramento (`/demo/encerramento/`);
3. 404 das duas rotas fora de `DEMO_MODE` (segurança comercial, Seção 13);
4. Guia da apresentação: renderiza só em demo, não contém formulário e a
   renderização não altera nada no banco;
5. Links das 8 cenas da narrativa respondem para o perfil indicado na cena;
6. Seed/preparação repetida SEM duplicar a Central de Auditoria (Seção 11.2);
7. Documentos ativos sem referências correntes a V3/664 (Seção 11.1).

Mudança de escopo (ida para a nuvem): o mapa de valor da abertura exigia
"Próximos conectores" com "Inovafarma" e "Não habilitada" (IA). A regra
mudou — não haverá integração com ERP, e IA/estoque não são prometidos —,
então o teste passou a exigir "Integração prevista" só com o DDA e a
AUSÊNCIA explícita desses termos na abertura, no encerramento e na cena 7
do guia.

Versão com Análise Financeira: o guia ganhou a cena "6. A farmácia está
saudável?" (DRE, Créditos × Débitos e Saúde Financeira, perfil Financeiro
ou Proprietário) entre a Agenda e a Auditoria — as cenas seguintes foram
renumeradas (6 → 7 e 7 → 8). O teste de títulos passou a exigir as 8 cenas
(regra mudou: uma cena a mais, nenhuma removida) e o link da cena nova
entrou na lista de links que precisam responder 200.
"""
import re
from pathlib import Path

from django.conf import settings
from django.core.management import call_command
from django.test import Client, SimpleTestCase, TestCase, override_settings

BASE_DIR = Path(settings.BASE_DIR)
SENHA_DEMO = "nexbuy123"

# (href, username com acesso pela narrativa) — as cenas mandam trocar de
# perfil ANTES de abrir a tela; o contrato testado é exatamente esse.
LINKS_DAS_CENAS = [
    ("/", "demo_proprietario"),                      # Cena 1
    ("/gestao-compras/nova/", "demo_comprador"),     # Cenas 2 e 3
    ("/gestao-compras/aprovacao/", "demo_gerente"),  # Cena 4 (1ª etapa)
    ("/gestao-compras/aprovacao/", "demo_financeiro"),  # Cena 4 (2ª etapa)
    ("/financeiro/agenda/", "demo_financeiro"),      # Cena 5
    ("/financeiro/analise/", "demo_financeiro"),     # Cena 6 (Análise Financeira)
    ("/financeiro/analise/", "demo_proprietario"),   # Cena 6 (o Proprietário também vê)
    ("/ncc/central-auditoria/", "demo_proprietario"),  # Cena 7
    ("/ncc/integracoes/", "demo_proprietario"),      # Cena 8
]

# Mudança de escopo (nuvem): nada disso pode ser prometido no Modo
# Apresentação — sem ERP/Inovafarma, sem conexão bancária, sem IA, sem
# controle de estoque. Só o DDA segue como integração prevista.
TERMOS_FORA_DO_ESCOPO = (
    r"Inovafarma", r"\bERP\b", r"SQL Server", r"Open Finance", r"API Bancária",
    r"Inteligência Artificial", r"\bIA\b", r"estoque",
)


def _texto_visivel(html):
    """HTML sem <script>/<style> e sem tags — só o texto que a pessoa lê."""
    sem_blocos = re.sub(r"<(script|style)\b.*?</\1>", " ", html, flags=re.S | re.I)
    return re.sub(r"<[^>]+>", " ", sem_blocos)


@override_settings(DEMO_MODE=True)
class AberturaEncerramentoTestCase(TestCase):
    """Seções 5.1, 5.2 e 9 — as duas telas do Modo Apresentação."""

    def test_abertura_renderiza_sem_login_com_mensagem_e_resultados(self):
        resposta = self.client.get("/demo/apresentacao/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "NEXBUY")
        self.assertContains(resposta, "Da intenção de compra à decisão")
        self.assertContains(resposta, "Inteligência que guia decisões")
        self.assertContains(resposta, "matriz e filiais")
        for resultado in (
            "Previsibilidade financeira", "Autonomia com limites",
            "Aprovações no momento certo", "Auditoria de ponta a ponta",
        ):
            self.assertContains(resposta, resultado)
        self.assertContains(resposta, "Iniciar demonstração")
        self.assertContains(resposta, "Ver o que o NEXBUY entrega hoje")
        self.assertContains(resposta, "Ambiente de demonstração — dados fictícios")

    def test_cta_leva_ao_login_real_sem_bypass(self):
        resposta = self.client.get("/demo/apresentacao/")
        # O botão principal aponta para o LOGIN normal (usuário da whitelist
        # pré-preenchido; a senha continua obrigatória).
        self.assertContains(resposta, '/accounts/login/?usuario=demo_proprietario')
        # Nenhum formulário na abertura — nada de coleta de dados/bypass.
        self.assertNotContains(resposta, "<form")

    def test_mapa_de_valor_presente_e_honesto(self):
        resposta = self.client.get("/demo/apresentacao/")
        self.assertContains(resposta, "Disponível agora")
        self.assertContains(resposta, "Multiempresa e multifilial")
        self.assertContains(resposta, "Receitas e custos lançados manualmente")
        self.assertContains(resposta, "Análise Financeira")
        # Mudança de escopo (nuvem): a única integração prevista é o DDA,
        # ainda não conectada — o mapa não promete mais ERP/Inovafarma nem IA.
        self.assertContains(resposta, "Integração prevista")
        self.assertContains(resposta, "DDA")
        self.assertContains(resposta, "Não conectado")
        texto = _texto_visivel(resposta.content.decode("utf-8"))
        for termo in TERMOS_FORA_DO_ESCOPO:
            with self.subTest(termo=termo):
                self.assertIsNone(re.search(termo, texto), f"abertura ainda promete '{termo}'")

    def test_encerramento_renderiza_com_resumo_e_sem_formulario(self):
        resposta = self.client.get("/demo/encerramento/")
        self.assertEqual(resposta.status_code, 200)
        self.assertContains(resposta, "Da intenção de compra à decisão.")
        for passo in ("Planejou", "Aplicou limites", "Aprovou",
                      "Refletiu no Financeiro", "Registrou na Auditoria"):
            self.assertContains(resposta, passo)
        self.assertContains(resposta, "Vamos aplicar este fluxo à realidade da sua operação?")
        self.assertContains(resposta, "Voltar ao Dashboard")
        self.assertNotContains(resposta, "<form")

    def test_encerramento_sem_erp_e_com_dda_como_integracao_prevista(self):
        resposta = self.client.get("/demo/encerramento/")
        self.assertContains(resposta, "DDA: integração futura prevista (hoje não conectada).")
        texto = _texto_visivel(resposta.content.decode("utf-8"))
        for termo in TERMOS_FORA_DO_ESCOPO:
            with self.subTest(termo=termo):
                self.assertIsNone(re.search(termo, texto), f"encerramento ainda promete '{termo}'")


@override_settings(DEMO_MODE=False)
class RotasForaDoDemoTestCase(TestCase):
    """Seção 13 — fora do modo demo, as rotas de apresentação NÃO existem."""

    def test_abertura_e_encerramento_dao_404(self):
        self.assertEqual(self.client.get("/demo/apresentacao/").status_code, 404)
        self.assertEqual(self.client.get("/demo/encerramento/").status_code, 404)


class GuiaApresentacaoTestCase(TestCase):
    """Seção 5.3 — guia recolhível do apresentador."""

    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo")

    def _login(self, username):
        ok = self.client.login(username=username, password=SENHA_DEMO)
        assert ok, f"login de {username} falhou"

    @override_settings(DEMO_MODE=True)
    def test_guia_renderiza_no_modo_demo_com_as_oito_cenas(self):
        self._login("demo_proprietario")
        resposta = self.client.get("/")
        self.assertContains(resposta, "Guia da apresentação")
        self.assertContains(resposta, "data-guia-avancar")
        self.assertContains(resposta, "data-guia-reiniciar")
        # Microsprint corretiva: as cenas moram no JS EXTERNALIZADO (nunca
        # inline no HTML) — o arquivo estático precisa ter as 8 cenas
        # (a 6ª, da Análise Financeira, entrou na versão nova).
        self.assertContains(resposta, "js/guia_apresentacao.js")
        self.assertContains(resposta, "css/guia_apresentacao.css")
        js = (BASE_DIR / "static" / "js" / "guia_apresentacao.js").read_text(encoding="utf-8")
        for titulo in (
            "1. Uma visão para toda a operação", "2. Autonomia sem perder o controle",
            "3. O controle aparece quando é necessário", "4. A decisão chega à pessoa certa",
            "5. A compra deixa de ser surpresa", "6. A farmácia está saudável?",
            "7. Toda decisão deixa uma história", "8. O que está pronto e para onde evoluir",
        ):
            self.assertIn(titulo, js, f"cena ausente do guia: {titulo}")

    def test_cenas_do_guia_nao_prometem_erp_ia_nem_estoque(self):
        js = (BASE_DIR / "static" / "js" / "guia_apresentacao.js").read_text(encoding="utf-8")
        cenas = js.split("var CENAS = [", 1)[1].split("];", 1)[0]
        self.assertIn("DDA", cenas, "a cena 8 precisa citar o DDA como integração prevista")
        for termo in TERMOS_FORA_DO_ESCOPO:
            with self.subTest(termo=termo):
                self.assertIsNone(re.search(termo, cenas), f"guia ainda promete '{termo}'")

    @override_settings(DEMO_MODE=True)
    def test_guia_inicia_recolhido_e_html_sem_token_proibido(self):
        """Correções do gate do relatório consolidado: (a) o guia chega do
        servidor RECOLHIDO — nunca cobre Agenda/Auditoria ao abrir a tela;
        (b) nenhuma tela renderizada em modo demo pode conter o literal
        proibido "NaN" (o script inline antigo usava um identificador com
        esse literal e reprovava as varreduras com DEMO_MODE=True)."""
        self._login("demo_proprietario")
        # Mesma mitigação de core/tests_estados_vazios.py: o VALOR do token
        # CSRF é aleatório e pode coincidentemente conter "NaN" — remove-se
        # só o valor (nunca o campo) antes da varredura.
        csrf_re = re.compile(r'(name="csrfmiddlewaretoken" value=")[^"]+(")')
        for url in ("/", "/financeiro/agenda/", "/ncc/central-auditoria/"):
            resposta = self.client.get(url)
            self.assertEqual(resposta.status_code, 200, url)
            html = csrf_re.sub(r"\1\2", resposta.content.decode("utf-8", errors="replace"))
            self.assertIn('id="nxGuia" class="nx-guia-recolhido"', html, f"{url}: guia não inicia recolhido")
            self.assertNotIn("NaN", html, f"{url}: literal proibido no HTML renderizado")
        # E o próprio JS externalizado também não usa o identificador com o literal.
        js = (BASE_DIR / "static" / "js" / "guia_apresentacao.js").read_text(encoding="utf-8")
        self.assertNotIn("isNaN", js)

    @override_settings(DEMO_MODE=False)
    def test_guia_nao_existe_fora_do_modo_demo(self):
        self._login("demo_proprietario")
        resposta = self.client.get("/")
        self.assertNotContains(resposta, "Guia da apresentação")
        self.assertNotContains(resposta, "nxGuia")

    @override_settings(DEMO_MODE=True)
    def test_guia_nao_contem_formulario_e_nao_altera_o_banco(self):
        from compras.models import Compra
        from gestao_compras.models import Provisao
        from auditoria.models import RegistroAuditoria

        self._login("demo_proprietario")
        antes = (Compra.objects.count(), Provisao.objects.count(), RegistroAuditoria.objects.count())
        resposta = self.client.get("/")
        html = resposta.content.decode("utf-8", errors="replace")
        guia = html.split('id="nxGuia"', 1)[1]
        self.assertNotIn("<form", guia, "o guia nunca pode executar ações pelo apresentador")
        depois = (Compra.objects.count(), Provisao.objects.count(), RegistroAuditoria.objects.count())
        self.assertEqual(antes, depois, "renderizar o guia não pode alterar o banco")

    @override_settings(DEMO_MODE=True)
    def test_links_da_narrativa_respondem_para_o_perfil_da_cena(self):
        for href, username in LINKS_DAS_CENAS:
            client = Client()
            self.assertTrue(client.login(username=username, password=SENHA_DEMO), username)
            resposta = client.get(href)
            self.assertEqual(
                resposta.status_code, 200,
                f"cena com {username}: {href} -> {resposta.status_code}",
            )


class SeedSemDuplicarAuditoriaTestCase(TestCase):
    """Seção 11.2 — preparação repetida não pode duplicar a auditoria."""

    def test_segunda_execucao_do_seed_nao_duplica_auditoria_nem_logs(self):
        from auditoria.models import RegistroAuditoria
        from empresas.models import LogConfiguracao

        call_command("seed_demo")
        auditoria_1 = RegistroAuditoria.objects.filter(empresa__cnpj__startswith="98765432").count()
        logs_1 = LogConfiguracao.objects.filter(empresa__cnpj__startswith="98765432").count()
        self.assertGreater(auditoria_1, 0)

        call_command("seed_demo")
        auditoria_2 = RegistroAuditoria.objects.filter(empresa__cnpj__startswith="98765432").count()
        logs_2 = LogConfiguracao.objects.filter(empresa__cnpj__startswith="98765432").count()

        self.assertEqual(auditoria_2, auditoria_1, "Central de Auditoria duplicou na 2ª execução")
        self.assertEqual(logs_2, logs_1, "Log de Configuração duplicou na 2ª execução")


class DocumentosAtualizadosTestCase(SimpleTestCase):
    """Seção 11.1 — nenhum documento ativo pode citar 664/V3 como estado atual."""

    def test_readme_e_demo_mode_sem_referencias_correntes_a_v3(self):
        for nome in ("README.md", "DEMO_MODE.md"):
            texto = (BASE_DIR / nome).read_text(encoding="utf-8")
            self.assertNotIn("664 testes", texto, f"{nome} ainda cita 664 testes")
            self.assertNotIn("test_run_DEMO_FINAL_V3", texto, f"{nome} ainda cita o log V3")
            self.assertIn("test_run_APRESENTACAO.txt", texto, f"{nome} precisa citar o log atual")

    def test_readme_cita_a_contagem_atual_da_suite(self):
        texto = (BASE_DIR / "README.md").read_text(encoding="utf-8")
        ocorrencias = re.findall(r"(\d{3}) testes", texto)
        self.assertTrue(ocorrencias, "README precisa citar a contagem da suíte")
        for valor in ocorrencias:
            self.assertGreaterEqual(int(valor), 724, f"contagem desatualizada no README: {valor}")
