"""Uso real no servidor (NEXBUY_USO_REAL) e as recusas do `seed_demo`.

A cliente passou a testar o NEXBUY com os dados DE VERDADE da farmácia
(compras reais dos compradores, receitas e custos reais do financeiro) no
mesmo servidor da demonstração. Daqui em diante, nenhum seed pode misturar a
farmácia fictícia e usuários com senha pública a esses dados:

1. `settings.USO_REAL` (NEXBUY_USO_REAL=True no .env): o seed recusa SEMPRE
   — com qualquer DEBUG, dentro ou fora da suíte de testes e mesmo com
   ALLOW_SEED_IN_PRODUCTION na linha do comando. Também desliga o Modo
   Demonstração (selo, tour, troca de perfil com os usuários demo_*).
2. Servidor (DEBUG=False) com qualquer empresa fora da faixa fictícia
   (CNPJ que não começa com 98765432): recusa mesmo com a autorização.
3. A demonstração local (DEBUG=True) e a renovação da demonstração no
   servidor (só empresas fictícias) continuam funcionando.

Toda recusa acontece antes de qualquer gravação: o banco fica exatamente
como estava. Mesma convenção de core/tests.py::SeedProducaoGuardTestCase:
"servidor de verdade" nos testes é `override_settings(DEBUG=False,
TESTING=False)`, porque o runner força DEBUG=False na suíte inteira.
"""
import io
import os
import runpy
import subprocess
import sys
import tempfile
from unittest import mock

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import SimpleTestCase, TestCase, override_settings

from core.tests_producao import AMBIENTE_BASE, SETTINGS_PY

SENHA_PUBLICA = "nexbuy123"
HASHER_RAPIDO = ["django.contrib.auth.hashers.MD5PasswordHasher"]
CNPJ_DEMO = "98765432000198"
# CNPJ válido fora da faixa fictícia: a "empresa real" dos testes.
CNPJ_REAL = "11222333000181"


def _seed(*args):
    saida = io.StringIO()
    call_command("seed_demo", *args, stdout=saida)
    return saida.getvalue()


def _fotografia():
    """Contagens que provam que nada foi gravado."""
    from compras.models import Compra
    from empresas.models import Empresa, GrupoEmpresarial
    from filiais.models import Filial
    from financeiro.models import Receita
    from usuarios.models import Usuario

    return {
        "empresas": sorted(Empresa.objects.values_list("cnpj", flat=True)),
        "grupos": GrupoEmpresarial.objects.count(),
        "filiais": Filial.objects.count(),
        "usuarios": sorted(Usuario.objects.values_list("username", flat=True)),
        "compras": Compra.objects.count(),
        "receitas": Receita.objects.count(),
    }


def _criar_empresa_real():
    from empresas.models import Empresa
    from filiais.models import Filial
    from usuarios.models import Usuario

    empresa = Empresa.objects.create(nome="Drogaria Real do Teste", cnpj=CNPJ_REAL)
    Filial.objects.create(empresa=empresa, nome="Matriz")
    Usuario.objects.create_user("dona_real", password="Senha-Forte-Teste-1", empresa=empresa)
    return empresa


class MidiaTemporariaMixin:
    """O seed grava a logo da farmácia fictícia em MEDIA_ROOT — aqui numa
    pasta temporária, nunca dentro da árvore do projeto."""

    @classmethod
    def setUpClass(cls):
        cls._pasta_midia = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        cls._override_midia = override_settings(MEDIA_ROOT=cls._pasta_midia.name)
        cls._override_midia.enable()
        try:
            super().setUpClass()
        except Exception:
            cls._override_midia.disable()
            cls._pasta_midia.cleanup()
            raise

    @classmethod
    def tearDownClass(cls):
        try:
            super().tearDownClass()
        finally:
            cls._override_midia.disable()
            cls._pasta_midia.cleanup()


# ---------------------------------------------------------------------------
# 1. settings.py
# ---------------------------------------------------------------------------


class UsoRealSettingsTestCase(SimpleTestCase):
    """`settings.py` executado num namespace isolado (técnica de
    core/tests_producao.py), sem o .env local do desenvolvedor."""

    def _carregar(self, **variaveis):
        ambiente = {**AMBIENTE_BASE, **{k: str(v) for k, v in variaveis.items()}}
        with mock.patch.dict(os.environ, ambiente), mock.patch("dotenv.load_dotenv"):
            for nome in ("NEXBUY_USO_REAL", "DEMO_EXIBIR_SENHA"):
                if nome not in variaveis:
                    os.environ.pop(nome, None)
            return runpy.run_path(str(SETTINGS_PY))

    def test_padrao_e_desligado_e_a_demonstracao_segue_igual(self):
        s = self._carregar(DEBUG="True", DEMO_MODE="True")
        self.assertFalse(s["USO_REAL"])
        self.assertTrue(s["DEMO_MODE"])
        self.assertTrue(s["DEMO_EXIBIR_SENHA"])

    def test_uso_real_ligado_pelo_env(self):
        for valor in ("True", "true", "1", "sim"):
            self.assertTrue(self._carregar(NEXBUY_USO_REAL=valor)["USO_REAL"], valor)
        self.assertFalse(self._carregar(NEXBUY_USO_REAL="False")["USO_REAL"])

    def test_uso_real_desliga_modo_demonstracao_e_dica_de_senha(self):
        """Um .env que ainda traga DEMO_MODE=True do tempo da demonstração
        não mostra selo, tour nem a troca de perfil com usuários demo_*."""
        s = self._carregar(NEXBUY_USO_REAL="True", DEMO_MODE="True", DEMO_EXIBIR_SENHA="True")
        self.assertTrue(s["USO_REAL"])
        self.assertFalse(s["DEMO_MODE"])
        self.assertFalse(s["DEMO_EXIBIR_SENHA"])


# ---------------------------------------------------------------------------
# 2. USO_REAL: recusa sempre
# ---------------------------------------------------------------------------


class SeedRecusadoEmUsoRealTestCase(TestCase):
    def _confere_recusa(self, comando="seed_demo"):
        antes = _fotografia()
        with self.assertRaises(CommandError) as contexto:
            call_command(comando, stdout=io.StringIO())
        mensagem = str(contexto.exception)
        self.assertIn("USO REAL", mensagem)
        self.assertIn("NEXBUY_USO_REAL=True", mensagem)
        self.assertIn("Nada foi gravado", mensagem)
        self.assertNotIn(SENHA_PUBLICA, mensagem)
        self.assertEqual(_fotografia(), antes)
        return mensagem

    @override_settings(USO_REAL=True, DEBUG=False, TESTING=False)
    def test_recusa_no_servidor_mesmo_com_allow_na_linha_do_comando(self):
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            self._confere_recusa()

    @override_settings(USO_REAL=True, DEBUG=True, TESTING=False)
    def test_recusa_ate_com_debug_true(self):
        self._confere_recusa()

    @override_settings(USO_REAL=True)
    def test_recusa_ate_dentro_da_suite_de_testes(self):
        # Sem DEBUG/TESTING trocados: o mesmo ambiente que deixa o seed
        # passar no resto da suíte (TESTING=True). "Sempre" é sempre.
        self._confere_recusa()

    @override_settings(USO_REAL=True, DEBUG=False, TESTING=False)
    def test_recusa_com_dados_reais_e_preserva_tudo(self):
        _criar_empresa_real()
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            self._confere_recusa()

    @override_settings(USO_REAL=True, DEBUG=False, TESTING=False)
    def test_seed_dados_tambem_e_recusado(self):
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            mensagem = self._confere_recusa("seed_dados")
        self.assertIn("'seed_dados'", mensagem)


class SeedUsoRealPelaLinhaDeComandoTestCase(SimpleTestCase):
    """De ponta a ponta, num processo separado: NEXBUY_USO_REAL=True no
    ambiente -> settings.USO_REAL -> recusa com código de saída != 0, sem
    traceback e com o arquivo do banco byte a byte igual."""

    def test_codigo_de_saida_diferente_de_zero_e_banco_intocado(self):
        import hashlib
        import sqlite3

        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as pasta:
            banco = os.path.join(pasta, "db.sqlite3")
            conexao = sqlite3.connect(banco)
            conexao.execute("CREATE TABLE dado_real (texto TEXT)")
            conexao.execute("INSERT INTO dado_real VALUES ('compra real da farmácia')")
            conexao.commit()
            conexao.close()
            with open(banco, "rb") as arquivo:
                assinatura = hashlib.sha256(arquivo.read()).hexdigest()
            ambiente = {
                **os.environ,
                "DJANGO_SETTINGS_MODULE": "nexbuy.settings",
                "NEXBUY_USO_REAL": "True",
                "ALLOW_SEED_IN_PRODUCTION": "True",
                "DEBUG": "True",
                "SQLITE_PATH": banco,
                "MEDIA_ROOT": os.path.join(pasta, "media"),
                "PYTHONIOENCODING": "utf-8",
            }
            for nome in ("BACKUP_DIARIO", "DEMO_MODE"):
                ambiente.pop(nome, None)
            for comando in ("seed_demo", "seed_dados"):
                processo = subprocess.run(
                    [sys.executable, "manage.py", comando],
                    cwd=settings.BASE_DIR, env=ambiente, capture_output=True, text=True,
                    encoding="utf-8", errors="replace", timeout=120,
                )
                self.assertNotEqual(processo.returncode, 0, comando)
                self.assertIn("USO REAL", processo.stderr, comando)
                self.assertNotIn("Traceback", processo.stderr, comando)
                self.assertNotIn(SENHA_PUBLICA, processo.stdout + processo.stderr, comando)
                with open(banco, "rb") as arquivo:
                    self.assertEqual(hashlib.sha256(arquivo.read()).hexdigest(), assinatura, comando)


# ---------------------------------------------------------------------------
# 3. Servidor com dados reais (sem USO_REAL marcado)
# ---------------------------------------------------------------------------


@override_settings(PASSWORD_HASHERS=HASHER_RAPIDO)
class SeedRecusadoComDadosReaisTestCase(MidiaTemporariaMixin, TestCase):
    @override_settings(DEBUG=False, TESTING=False)
    def test_empresa_real_no_servidor_recusa_mesmo_com_allow(self):
        _criar_empresa_real()
        antes = _fotografia()
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            with self.assertRaises(CommandError) as contexto:
                _seed()
        mensagem = str(contexto.exception)
        self.assertIn("dados reais", mensagem)
        self.assertIn("Drogaria Real do Teste", mensagem)
        self.assertIn("mesmo com ALLOW_SEED_IN_PRODUCTION", mensagem)
        self.assertIn("NEXBUY_USO_REAL=True", mensagem)
        self.assertIn("Nada foi gravado", mensagem)
        self.assertNotIn(SENHA_PUBLICA, mensagem)
        self.assertEqual(_fotografia(), antes)
        self.assertNotIn(CNPJ_DEMO, _fotografia()["empresas"])

    @override_settings(DEBUG=False, TESTING=False)
    def test_empresa_real_junto_da_demonstracao_tambem_recusa(self):
        """Servidor que JÁ tinha a demonstração e onde a cliente criou a
        empresa dela: renovar o cenário fictício não pode mais rodar."""
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            _seed()
            _criar_empresa_real()
            antes = _fotografia()
            with self.assertRaises(CommandError):
                _seed("--manter-senhas")
        self.assertEqual(_fotografia(), antes)

    @override_settings(DEBUG=False, TESTING=False)
    def test_sem_allow_continua_a_recusa_de_sempre(self):
        _criar_empresa_real()
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("ALLOW_SEED_IN_PRODUCTION", None)
            with self.assertRaises(CommandError) as contexto:
                _seed()
        self.assertIn("bloqueado com DEBUG=False", str(contexto.exception))

    @override_settings(DEBUG=False, TESTING=False)
    def test_lista_no_maximo_tres_nomes(self):
        from empresas.models import Empresa

        for indice, cnpj in enumerate(("11222333000181", "11444777000161", "45723174000110", "60701190000104")):
            Empresa.objects.create(nome=f"Empresa Real {indice + 1}", cnpj=cnpj)
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            with self.assertRaises(CommandError) as contexto:
                _seed()
        mensagem = str(contexto.exception)
        self.assertIn("4 empresa(s)", mensagem)
        self.assertIn("Empresa Real 3 e mais 1", mensagem)
        self.assertNotIn("Empresa Real 4", mensagem)

    @override_settings(DEBUG=False, TESTING=False)
    def test_primeiro_acesso_concluido_recusa_mesmo_com_cnpj_do_prefixo_ficticio(self):
        """O Primeiro Acesso só existe no uso real. Feito com um CNPJ da faixa
        fictícia (o formulário antigo aceitava), o seed sobrescreveria a
        empresa de verdade como se fosse a da demonstração."""
        from core.models import EstadoInstalacao
        from empresas.models import Empresa

        Empresa.objects.create(nome="Drogaria da Cliente", cnpj=CNPJ_DEMO)
        if not EstadoInstalacao.objects.update(concluido=True):
            EstadoInstalacao.objects.create(concluido=True)
        antes = _fotografia()
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            with self.assertRaises(CommandError) as contexto:
                _seed("--manter-senhas")
        mensagem = str(contexto.exception)
        self.assertIn("Primeiro Acesso já foi concluído", mensagem)
        self.assertIn("Nada foi gravado", mensagem)
        self.assertEqual(_fotografia(), antes)
        self.assertEqual(Empresa.objects.get().nome, "Drogaria da Cliente")

    @override_settings(DEBUG=False, TESTING=False)
    def test_cnpj_ficticio_gravado_com_mascara_nao_conta_como_real(self):
        from core.management.commands.seed_demo import recusar_se_houver_dados_reais
        from empresas.models import Empresa

        empresa = Empresa.objects.create(nome="Farmácia Vida Plena", cnpj=CNPJ_DEMO)
        # Dado antigo, de antes do CNPJ canônico (update() não passa pelo save()).
        Empresa.objects.filter(pk=empresa.pk).update(cnpj="98.765.432/0001-98")
        recusar_se_houver_dados_reais()  # não levanta


class PrimeiroAcessoRecusaCnpjFicticioTestCase(TestCase):
    """O CNPJ 98765432... é o da farmácia fictícia: a empresa de verdade
    nunca o usa — e os scripts do servidor reconhecem a demonstração por
    ele. O Primeiro Acesso aceitava (o CNPJ é válido)."""

    def _form(self, cnpj):
        from core.forms_primeiro_acesso import PrimeiroAcessoForm

        return PrimeiroAcessoForm(data={
            "first_name": "Ana", "last_name": "Teste", "username": "ana.proprietaria",
            "senha": "Senha-Forte-Teste-1x", "senha_confirmacao": "Senha-Forte-Teste-1x",
            "grupo_nome": "Grupo Teste", "nome": "Drogaria Teste", "razao_social": "Drogaria Teste Ltda",
            "cnpj": cnpj, "cidade": "Cuiabá", "estado": "MT", "filial_nome": "Matriz",
            "fuso_horario": "America/Cuiaba", "confirmo": "on",
        })

    def test_cnpj_da_demonstracao_e_recusado_com_ou_sem_mascara(self):
        for cnpj in (CNPJ_DEMO, "98.765.432/0001-98"):
            with self.subTest(cnpj=cnpj):
                form = self._form(cnpj)
                self.assertFalse(form.is_valid())
                self.assertIn("CNPJ fictício da demonstração", " ".join(form.errors["cnpj"]))

    def test_cnpj_de_verdade_continua_aceito(self):
        form = self._form("11.222.333/0001-81")
        self.assertTrue(form.is_valid(), form.errors)


# ---------------------------------------------------------------------------
# 4. O que continua funcionando
# ---------------------------------------------------------------------------


@override_settings(PASSWORD_HASHERS=HASHER_RAPIDO)
class DemonstracaoContinuaFuncionandoTestCase(MidiaTemporariaMixin, TestCase):
    @override_settings(DEBUG=True, TESTING=False)
    def test_demo_local_com_debug_true_semeia_normalmente(self):
        relatorio = _seed()
        self.assertIn(f"senha para todos: {SENHA_PUBLICA}", relatorio)
        self.assertIn(CNPJ_DEMO, _fotografia()["empresas"])
        self.assertIn("demo_proprietario", _fotografia()["usuarios"])

    @override_settings(DEBUG=True, TESTING=False)
    def test_demo_local_nao_olha_empresas_de_outros_cnpjs(self):
        """No PC do desenvolvedor (DEBUG=True) o seed convive com a empresa
        de desenvolvimento ou qualquer outra — a recusa é só de servidor."""
        _criar_empresa_real()
        _seed()
        self.assertIn(CNPJ_DEMO, _fotografia()["empresas"])
        self.assertIn(CNPJ_REAL, _fotografia()["empresas"])

    @override_settings(DEBUG=False, TESTING=False)
    def test_servidor_de_demonstracao_renova_o_cenario(self):
        """Só empresas fictícias (as duas do próprio seed): a renovação da
        demonstração publicada continua igual (atualizar_demo.sh
        --renovar-cenario)."""
        with mock.patch.dict(os.environ, {"ALLOW_SEED_IN_PRODUCTION": "True"}):
            _seed()
            antes = _fotografia()
            _seed("--manter-senhas")
        self.assertEqual(_fotografia()["empresas"], antes["empresas"])
        self.assertEqual(_fotografia()["usuarios"], antes["usuarios"])
        self.assertTrue(all(cnpj.startswith("98765432") for cnpj in antes["empresas"]))

    def test_suite_de_testes_segue_semeando_sem_autorizacao(self):
        # Ambiente real do "manage.py test" (DEBUG=False forçado, TESTING=True):
        # o resto da suíte depende do seed aqui, mesmo com outra empresa no banco.
        _criar_empresa_real()
        _seed()
        self.assertIn(CNPJ_DEMO, _fotografia()["empresas"])
