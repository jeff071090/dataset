# NEXBUY — Guia Rápido do Apresentador (Demo Comercial Showcase)

Tudo que você precisa para apresentar o NEXBUY com confiança, em 1 página.
Funciona **sem internet** depois de preparado (a única exceção é o primeiro
`PREPARAR`, que baixa as dependências Python uma vez).

## 1. Preparação inicial (uma vez por máquina)

Dê **dois cliques** em:

```
PREPARAR_DEMO_NEXBUY.bat
```

Ele valida o Python, cria o ambiente, instala as dependências, aplica as
migrações **somente no banco de demonstração** e cria o cenário fictício
completo (Farmácia Vida Plena, Loja Centro e Loja Bairro, com **12 meses de
histórico** de receitas, custos e compras para a Análise Financeira). Ao
final mostra "PREPARACAO CONCLUIDA".

## 2. Iniciar a demonstração (um clique)

```
INICIAR_DEMO_NEXBUY.bat
```

- Escolhe sozinho uma porta livre (8000, 8001, 8002, 8010 ou 8080);
- Abre o navegador sozinho **quando a aplicação já está respondendo**;
- Mantém a janela aberta com os logs — **não feche durante a reunião**.

**URL**: a janela mostra o endereço (ex.: `http://127.0.0.1:8000/`).

## 3. Credenciais fictícias (senha para todas: `nexbuy123`)

| Usuário | Perfil | Pessoa fictícia |
|---|---|---|
| `demo_proprietario` | Proprietário | Roberto Almeida |
| `demo_gerente` | Gerente | Fernanda Costa |
| `demo_financeiro` | Financeiro | Marcos Vinícius |
| `demo_comprador` | Comprador | Juliana Ramos |

Extras para cenas específicas: `demo_comprador2` (Pedro, limite R$ 2.000)
e `demo_comprador3` (Carla, **bloqueada** — mostra a compra barrada).

> Estas credenciais existem SOMENTE nesta demonstração — nunca no
> ambiente cliente-ready.

## 4. Trocar de perfil durante a reunião (sem constrangimento)

Clique no **seu nome (canto superior direito) → "Trocar perfil de
demonstração" → escolha o perfil**. O sistema encerra a sessão e volta ao
login **com o usuário já preenchido** — digite só a senha `nexbuy123`.
É autenticação real (sem atalho mágico); a troca leva ~5 segundos.

No mesmo menu há **"Reiniciar tour"** para reapresentar o tour guiado do
perfil atual.

## 5. Resetar o cenário (antes de cada reunião)

```
RESETAR_DEMO_NEXBUY.bat
```

Digite `SIM` para confirmar. Ele apaga **somente** o banco/mídia de
demonstração e recria exatamente o cenário inicial (mesmos números,
datas sempre relativas ao dia de hoje). O banco principal `db.sqlite3`
NUNCA é tocado.

## 6. Problemas comuns e solução

| Problema | Solução |
|---|---|
| "Python nao encontrado no PATH" | Instale o Python 3.12+ em python.org marcando **Add python.exe to PATH**; rode o PREPARAR de novo. |
| "Falha ao instalar as dependencias" | Precisa de internet só nesta etapa. Conecte e rode o PREPARAR de novo (ou rode `venv\Scripts\python.exe -m pip install -r requirements.txt` para ver o erro). |
| "Nenhuma porta livre" | Feche janelas antigas de demo/outros servidores locais e rode o INICIAR de novo — ele testa 8000, 8001, 8002, 8010 e 8080. |
| Navegador não abriu sozinho | Aguarde até 60s; se não abrir, digite o endereço mostrado na janela. A causa real de qualquer erro aparece na própria janela, nunca só uma página genérica. |
| "Rode PREPARAR_DEMO_NEXBUY.bat primeiro" | A preparação ainda não foi concluída nesta máquina — passo 1. |
| Dados "bagunçados" após ensaios | Rode o RESETAR (passo 5). |
| Comprador em "Hoje não é dia de compra" | É a regra, não defeito: em sábado, domingo ou feriado não há limite de compra próprio (só dias úteis contam no Calendário Operacional) e uma provisão para hoje vai para aprovação. O reset feito num dia desses coloca os pedidos "de hoje" do cenário no último dia útil (sem alerta de "Capacidade de hoje excedida"). Apresente em dia útil; num fim de semana, use a tela para explicar o Calendário Operacional. |
| "Resultado do mês" com margem alta e selo "parcial" | É o mês em andamento: a receita já é a do mês inteiro e as compras só vão até hoje. Comente o "Mês fechado" ao lado e a mini-curva (só meses fechados). |

## 7. Modo Apresentação (novo)

Com o servidor no ar, comece a reunião pela **tela de abertura**:
`http://127.0.0.1:<porta>/demo/apresentacao/` — logo, mensagem central,
botão "Iniciar demonstração" (leva ao login real, já preenchido) e o
mapa de valor ("Ver o que o NEXBUY entrega hoje"). Encerre em
`/demo/encerramento/`. Dentro do sistema, o **Guia da apresentação**
(canto inferior direito) mostra a cena atual e a próxima das 8 cenas —
minimizável, reiniciável, e nunca executa nada por você. Tudo isso existe
SOMENTE no modo demonstração.

## 8. Roteiro da apresentação

Ver `ROTEIRO_DEMO_COMERCIAL_NEXBUY.md` (as 8 cenas + versões de 5, 15 e
30 minutos — a Cena 6, "A farmácia está saudável?", é a da Análise
Financeira), `NEXBUY_GUIA_DE_CONDUCAO_DA_REUNIAO.md` (como conduzir),
`NEXBUY_PERGUNTAS_PARA_DESCOBERTA.md` e
`NEXBUY_RESPOSTAS_PERGUNTAS_DIFICEIS.md` (objeções), além de
`CHECKLIST_ANTES_DA_REUNIAO.md` (30 minutos antes). O que o produto faz
hoje × o que é evolução futura: `MAPA_CAPACIDADES_NEXBUY.md`.

## 9. Os números da Análise Financeira (para não se surpreender)

O cenário tem 12 meses de uma farmácia plausível nas duas lojas: Loja
Centro com receita de ~R$ 257 mil a ~R$ 311 mil por mês e Loja Bairro de
~R$ 143 mil a ~R$ 173 mil, com sazonalidade; compras aprovadas em torno de
60% a 66% da receita; custos variáveis ~8% (impostos, cartão, comissões,
entregas); custos fixos ~20% a 22%; resultado de alguns % da receita. De
propósito: **um mês fechou no prejuízo** (5 meses atrás — compras muito
acima do normal), o **caixa ficou no vermelho no mês seguinte** a ele e a
**receita caiu nos últimos 3 meses** — por isso a Saúde Financeira mostra
indicadores em "Atenção" e recomendações em reais. O mês corrente vai
sendo preenchido até ontem — a DRE do mês corrente compara as compras até
hoje com a receita do mês inteiro, então só fica representativa no fim do
mês. O link do Guia da apresentação já abre o **último mês fechado até o
dia 24** (do dia 25 em diante, o mês corrente); pelo menu, use « mês
anterior ».

## 10. Escopo em 4 frases (decore)

- O NEXBUY é **100% web**; não se integra a ERP e não controla estoque.
- **Receitas, custos, compras: lançamento manual** — é isso que alimenta a
  projeção de compra e os limites dos compradores.
- **Análise Financeira** (DRE, créditos × débitos, saúde financeira) para
  Proprietário, Gerente e Financeiro; o Comprador não vê dado financeiro
  sensível.
- **DDA: integração futura prevista (não conectada).**
