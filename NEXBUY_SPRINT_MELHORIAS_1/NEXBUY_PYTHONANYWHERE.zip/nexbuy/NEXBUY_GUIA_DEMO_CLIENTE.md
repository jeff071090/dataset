# NEXBUY — Guia Técnico da Demo Comercial (Pacote B)

Este é o guia de **como preparar e rodar** a demonstração comercial isolada
do NEXBUY. Não é o roteiro de apresentação (para "o que falar e mostrar em
cada minuto", ver
[NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md](NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md)).
Este documento é para quem vai efetivamente **operar o computador** durante
a apresentação.

## A garantia de isolamento

A demo comercial roda com `nexbuy/settings_demo.py`, que sobrescreve só o
necessário do `nexbuy/settings.py` principal:

| | Ambiente principal (cliente-ready) | Demo comercial (este pacote) |
|---|---|---|
| Banco de dados | `db.sqlite3` | `db_demo_cliente.sqlite3` |
| Mídia (uploads) | `media\` | `media_demo_cliente\` |
| Settings | `nexbuy.settings` (padrão) | `nexbuy.settings_demo` |
| `DEMO_MODE` | conforme `.env` (normalmente `False`) | **decidido pelo launcher**: `False` no cenário limpo (sem badge — a experiência é idêntica à do cliente real), `True` no cenário pronto (badge "Modo Demonstração" visível, dados fictícios) |

**Nomes de arquivo diferentes — nunca o mesmo banco.** Não é uma flag que
liga/desliga um comportamento no mesmo arquivo: são dois arquivos
fisicamente diferentes. Rodar a demo, resetá-la, ou rodar `seed_demo` nela
não tem NENHUMA forma de alcançar `db.sqlite3` ou `media\`, mesmo por
engano — contanto que você sempre use os launchers abaixo (que já passam
`--settings=nexbuy.settings_demo` em toda chamada de `manage.py`) e nunca
rode `manage.py` diretamente sem essa flag durante uma demo.

## Qual launcher usar

| Situação | Launcher | O que ele faz |
|---|---|---|
| Provar que o produto é real, cadastro ao vivo (Roteiro A) | `iniciar_demo_cliente_limpa.bat` | Aplica as migrações no banco de demo (nunca apaga o que já existia), gera um token de Primeiro Acesso só para a sessão, abre `/primeiro-acesso/` |
| Demonstração rápida com histórico já pronto (Roteiro B) | `iniciar_demo_cenario_pronto.bat` | Aplica as migrações, roda `seed_demo` (idempotente), abre `/accounts/login/` com as credenciais de demo |
| Resetar o banco de demo (qualquer um dos dois cenários) | `resetar_demo_cliente_limpa.bat` | Apaga **só** `db_demo_cliente.sqlite3` e `media_demo_cliente\`, pede confirmação digitada, recria o banco vazio |

Os três `.bat` ficam na raiz do projeto e devem ser executados com duplo
clique (ou `cmd.exe`) — não precisam de terminal já aberto. Todos verificam
Python 3.12+ no PATH antes de continuar, e reaproveitam o `venv\` do
projeto (instalando dependências automaticamente se necessário).

### Antes de uma apresentação

1. Decide qual roteiro vai usar (ver a tabela em
   [NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md](NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md)).
2. Se já usou esta máquina para uma demo anterior e quer começar limpo, rode
   `resetar_demo_cliente_limpa.bat` primeiro (ele pede "Digite SIM" antes de
   apagar qualquer coisa).
3. Rode o launcher do roteiro escolhido. Deixe a janela do terminal aberta
   durante toda a apresentação — fechá-la encerra o servidor.
4. Ao terminar, feche a janela do terminal (ou `Ctrl+C`) para encerrar o
   servidor local.

### Token de Primeiro Acesso (Roteiro A)

`iniciar_demo_cliente_limpa.bat` gera um token novo e aleatório a cada
execução (`secrets.token_urlsafe(32)`) e o define **só como variável de
ambiente do processo do servidor daquela sessão** — nunca grava esse valor
em nenhum arquivo `.env`. Ele aparece no terminal, em destaque, para você
copiar e digitar no formulário que abre em `/primeiro-acesso/`. Feche a
janela do terminal e o token deixa de existir — a próxima execução gera um
token novo.

## O que NUNCA fazer

- **Nunca copiar `db.sqlite3` por cima de `db_demo_cliente.sqlite3`** (ou
  vice-versa). São bancos com propósitos diferentes — misturar os dois
  contamina tanto a demo quanto (pior) um ambiente real de cliente.
- **Nunca editar `nexbuy/settings_demo.py` para apontar para o banco
  principal.** Se algum dia precisar ajustar esse arquivo, o `DATABASES["default"]["NAME"]`
  e o `MEDIA_ROOT` sempre devem apontar para nomes com o sufixo `_demo_cliente`
  — nunca `db.sqlite3`/`media`.
- **Nunca rodar `manage.py` sem `--settings=nexbuy.settings_demo` durante
  uma demo.** Sem essa flag, o comando usa o settings padrão
  (`nexbuy.settings`) e opera no banco/mídia principal — exatamente o que
  este pacote existe para evitar. Os três launchers já passam essa flag em
  toda chamada; se for rodar algo manualmente (ex.: `manage.py shell` para
  inspecionar um dado da demo), lembre sempre da flag.
- **Nunca apagar `db_demo_cliente.sqlite3`/`media_demo_cliente\` na mão**
  fora do `resetar_demo_cliente_limpa.bat` — o script já valida os nomes
  exatos antes de excluir qualquer coisa; apagar manualmente (ex.: um
  "limpar pasta" genérico) é como um comando amplo pode acabar levando
  junto algo que não devia.
- **Nunca expor a demo fora da máquina do apresentador** — os launchers já
  sobem o servidor só em `127.0.0.1`; não altere isso para `0.0.0.0` nem
  abra a porta no firewall para acesso externo.
- **Nunca prometer ao cliente algo que a demo não mostrou ao vivo** — ver o
  bloco "Não prometer ao cliente" no roteiro.

## Perguntas frequentes

**"Rodei a demo sem resetar antes — os dados da apresentação anterior ainda
estão lá. Problema?"** Não, por design: nenhum launcher apaga dados
silenciosamente. Para o Roteiro B (`seed_demo`), isso não importa — o
comando é idempotente e recria a "história" do mês sozinho. Para o
Roteiro A, se quiser um cadastro do zero, rode
`resetar_demo_cliente_limpa.bat` antes.

**"A demo puxa algum dado de outro sistema (ERP, banco)?"** Não. O NEXBUY
é 100% web e não se integra a ERP (decisão da cliente): receitas, custos,
compras — lançamento manual, e é isso que alimenta a projeção de compra, os
limites dos compradores e a Análise Financeira (DRE, créditos × débitos,
saúde financeira — para Proprietário, Gerente e Financeiro). DDA:
integração futura prevista (não conectada) — a tela de Integrações mostra
exatamente isso.

**"Preciso reinstalar tudo numa máquina nova?"** Sim, mas os launchers já
cuidam disso sozinhos (verificam o Python, criam o `venv\` se não existir e
instalam as dependências de `requirements.txt`). Não é preciso nenhum passo
manual além de ter Python 3.12+ instalado.

**"Posso rodar a demo e o ambiente cliente-ready ao mesmo tempo, na mesma
máquina?"** Tecnicamente sim (bancos e portas — ambos usam a porta 8000 por
padrão — mas nunca ao mesmo tempo na mesma porta). Evite rodar os dois
simultaneamente para não confundir qual servidor está respondendo em
`http://127.0.0.1:8000/`.
