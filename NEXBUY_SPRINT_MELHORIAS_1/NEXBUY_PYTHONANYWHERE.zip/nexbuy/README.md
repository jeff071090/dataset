# NEXBUY — Gestão de Compras e Capacidade Financeira

O NEXBUY responde, todos os dias, à pergunta de quem compra: **"Eu posso comprar hoje?"**

A empresa lança **manualmente** a receita do mês e os custos. Com esses números, o
Motor Financeiro calcula quanto cada filial pode comprar por dia (o **limite do dia**),
confere cada compra e cada provisão contra esse limite e mostra, na **Análise
Financeira**, o resultado do mês (DRE, créditos × débitos e saúde financeira). Todo
valor segue o padrão brasileiro (R$ 1.234,56).

Esta versão foi feita para farmácias, com a estrutura grupo → empresa (CNPJ) →
filiais → usuários, pronta para vários CNPJs e filiais. O sistema é **100% web**
e roda numa VPS (Hostinger) com o código num repositório privado do GitHub.

## Documentação

| Documento | Para quem | Conteúdo |
|---|---|---|
| [docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md](docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md) | Administrador da empresa | Roteiro de implantação na ordem certa, com checklist para imprimir |
| [docs/MANUAL_DO_USUARIO.md](docs/MANUAL_DO_USUARIO.md) | Toda a equipe | Manual completo por perfil, glossário da Análise Financeira e perguntas frequentes |
| [docs/DEPLOY_HOSTINGER_GITHUB.md](docs/DEPLOY_HOSTINGER_GITHUB.md) | Quem instala | Passo a passo: GitHub, VPS Hostinger, domínio, HTTPS e Primeiro Acesso |
| [docs/OPERACAO_BACKUP_E_ATUALIZACAO.md](docs/OPERACAO_BACKUP_E_ATUALIZACAO.md) | Quem mantém o servidor | Backup, restauração, atualização de versão, saída da fase de teste e comandos úteis |
| [docs/DEPLOY_PYTHONANYWHERE_DEMO.md](docs/DEPLOY_PYTHONANYWHERE_DEMO.md) | Quem apresenta o NEXBUY | Demonstração **grátis** na internet (PythonAnywhere), só com dados fictícios, para a cliente testar os 6 usuários de demonstração |
| [docs/PYTHONANYWHERE_USO_REAL.md](docs/PYTHONANYWHERE_USO_REAL.md) | Quem administra o site no PythonAnywhere | Troca da demonstração pelo **uso real** no mesmo site (`ativar_uso_real.sh`): Primeiro Acesso da proprietária, backup diário automático, atualização, restauração, limites do plano grátis e a mudança para a VPS |

Dentro do sistema, o mesmo manual está na **Central de Ajuda** (`/ajuda/`, ícone
**?** no topo › **Manual do sistema**). Ela se adapta ao perfil de quem está logado
e pode ser impressa ou salva em PDF.

## Escopo desta versão

- **Lançamentos manuais, sem ERP:** receita mensal, receitas extras, custos fixos,
  custos variáveis, compras e provisões são lançados pela própria interface. Não há
  integração com o sistema de vendas da farmácia.
- **Sem controle de estoque:** na Análise Financeira, as compras aprovadas do mês
  fazem o papel do custo da mercadoria.
- **DDA — integração futura, não conectada:** a tela `/ncc/integracoes/` mostra o DDA
  como "Não conectado — integração prevista". Nada é sincronizado, pago ou baixado
  automaticamente; o contrato fica em `finance_engine/interfaces.py`
  (`IntegracaoDDABase`), sem implementação.
- **Análise Financeira** (Proprietário, Gerente e Financeiro): DRE Gerencial,
  Créditos × Débitos e Saúde Financeira, com curvas de 12 meses, semáforo contra
  referências do varejo farmacêutico e recomendações.
- **Banco de produção limpo:** o sistema nasce sem nenhum dado. O administrador é
  criado pelo Primeiro Acesso Seguro e cadastra todo o resto.

## Principais funcionalidades

- **Motor Financeiro único** (`finance_engine`): capacidade de compra, limite do dia,
  saldo acumulado, redistribuição e simulação num só lugar, usados por todas as telas.
- **Receitas e custos:** receita mensal por filial, receitas extras (serviços,
  convênios/PBM, rendimentos e outras), custos fixos recorrentes e custos variáveis.
- **Compras** com parcelamento (à vista, 7/14/30/60 dias, 30/60, 30/60/90 ou
  personalizado) e regra configurável quando o limite do dia é ultrapassado:
  bloquear, solicitar aprovação ou permitir com alerta.
- **Provisões de compra** num Calendário de Compras com semáforo por dia e
  Workflow de Aprovações por etapas, alçada e prazo; a provisão aprovada é
  efetivada em compra.
- **Agenda Financeira, Contas a Pagar e Parcelamentos:** vencimentos, baixa e estorno
  de parcela com justificativa.
- **Limites dos compradores:** limite individual por dia, bloqueio e liberação.
- **Dashboards por perfil**, **Central de Relatórios** (impressão e CSV; os totais
  somam só compras aprovadas) e **Central de Notificações**.
- **RBAC:** perfis de acesso reutilizáveis que somam permissões, isolamento entre
  empresas e **Central de Auditoria** (trilha que não pode ser apagada).
- **Primeiro Acesso Seguro** e **Checklist de Implantação** (13 itens verificados
  direto no banco).
- **Central de Ajuda** (`/ajuda/`) por perfil, imprimível.

## Perfis de usuário

| Perfil | O que faz |
|---|---|
| **Proprietário** (administrador) | Vê todas as filiais; cria usuários, filiais e perfis de acesso; configura o sistema; decide aprovações; lança compras e provisões; acessa a Análise Financeira e a Auditoria |
| **Financeiro** | Lança receitas e custos; configura a capacidade de compra; define limites, bloqueia e libera compradores; opera a Agenda (baixa e estorno); acessa a Análise Financeira |
| **Gerente** | Decide compras e provisões acima do limite; acompanha indicadores, relatórios e a Análise Financeira |
| **Comprador** | Vê o limite do dia, lança compras, planeja provisões e usa o Simulador — nunca vê receita, custos nem a Análise Financeira |

O administrador pode somar permissões a qualquer usuário em **Gestão › Perfis de
Acesso**; o Comprador continua sem acesso aos números financeiros da empresa.

## Regra de cálculo

```
Receita do mês (receita mensal + receitas extras)
(-) Custos fixos ativos
(-) Custos variáveis previstos para o mês
= Disponibilidade financeira

Disponibilidade financeira × Percentual destinado às compras
= Capacidade mensal de compra (- Percentual de segurança)

Capacidade mensal ajustada ÷ Dias úteis do mês (automático ou manual)
= Limite do dia (base)

(+ Saldo acumulado dos dias anteriores, se "Saldo acumulativo" estiver ligado)
(- Excedente redistribuído, se "Redistribuição automática" estiver ligada)
= Limite do dia efetivo
```

A receita mensal é lançada **por filial e por mês** (não se repete sozinha); os
custos fixos ativos contam todo mês.

## Tecnologias

- **Backend:** Python 3.12+ e Django 6 (`Django==6.0.7`)
- **Frontend:** HTML, CSS, Bootstrap 5, Bootstrap Icons e JavaScript simples, todos
  servidos localmente (sem CDN)
- **Banco de dados:** SQLite (padrão); PostgreSQL trocando só variáveis de ambiente
- **Produção:** gunicorn + nginx + whitenoise, HTTPS com Let's Encrypt, backup diário

## Estrutura do projeto

```
nexbuy/             # Configuração (settings, urls, wsgi/asgi)
core/               # Base: Primeiro Acesso, navegação, permissões, Central de Ajuda
usuarios/           # Usuário (perfil, empresa, filial) + RBAC
empresas/           # Grupo, Empresa, Identidade Visual, Control Center (/ncc/), checklist
filiais/            # Filiais de cada empresa
cadastros/          # Categorias e Centros de Custo
finance_engine/     # MOTOR FINANCEIRO — toda regra de cálculo
financeiro/         # Receitas, custos, configuração, Agenda, calendários, Análise Financeira
compras/            # Fornecedores, compras, parcelas, relatórios, simulador
gestao_compras/     # Provisões, Calendário de Compras, aprovações
dashboard/          # Dashboards por perfil + Timeline Financeira
auditoria/          # Registro de auditoria
notificacoes/       # Central de Notificações
templates/, static/ # Telas e arquivos estáticos (Bootstrap e ícones locais)
deploy/             # Instalador, atualização, backup, limpeza da fase de teste e configs da VPS
docs/               # Manuais (ver "Documentação", acima)
```

## Instalação (cliente-ready)

> **Produção (VPS Hostinger):** siga
> [docs/DEPLOY_HOSTINGER_GITHUB.md](docs/DEPLOY_HOSTINGER_GITHUB.md). O instalador
> `deploy/instalar_servidor.sh` prepara tudo e gera sozinho a `SECRET_KEY` e o
> `INITIAL_SETUP_TOKEN` em `/etc/nexbuy/nexbuy.env`.
>
> ⚠️ **O banco cliente-ready NUNCA deve receber dados de teste nem de
> demonstração.** Ele começa **totalmente vazio** — sem empresa, sem usuário, sem
> compra, provisão, receita ou custo — e permanece assim até o próprio cliente
> cadastrar a empresa pelo Primeiro Acesso. Os comandos que criam dados fictícios
> estão só na seção de desenvolvimento, mais abaixo, e ficam bloqueados quando
> `DEBUG=False`.

Instalação manual (Windows 11 ou Linux), com **Python 3.12+** instalado (o
projeto usa `Django==6.0.7`, que exige Python 3.12 ou mais recente). É o caminho
para **conferir o sistema numa máquina local**; a produção de verdade (HTTPS, nginx,
gunicorn, backup) é montada pelo instalador da VPS —
[docs/DEPLOY_HOSTINGER_GITHUB.md](docs/DEPLOY_HOSTINGER_GITHUB.md).

```bash
# 1. Ambiente virtual
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Linux

# 2. Dependências
pip install -r requirements.txt

# 3. Variáveis de ambiente
copy .env.example .env         # Windows
# cp .env.example .env         # Linux

# 4. Gerar uma SECRET_KEY única e colar no .env (SECRET_KEY=...)
python -c "from django.core.management.utils import get_random_secret_key as g; print(g())"

# 5. No .env: DEBUG=False, ALLOWED_HOSTS=127.0.0.1,localhost e um INITIAL_SETUP_TOKEN forte:
python -c "import secrets; print(secrets.token_urlsafe(32))"
#    Só para testar nesta máquina, SEM HTTPS: no .env, SECURE_SSL_REDIRECT=False
#    (o .env.example vem com True — sem HTTPS, http://localhost:8000 redirecionaria
#    para https://, que o runserver não atende). Em produção, deixe True.

# 6. Criar o banco (vazio — nenhum dado é inserido)
python manage.py migrate --noinput

# 7. Arquivos estáticos (obrigatório com DEBUG=False: sem isto as telas ficam sem CSS)
python manage.py collectstatic --noinput

# 8. Subir a aplicação
python manage.py runserver --insecure  # teste local (DEBUG=False): abra http://localhost:8000
# gunicorn nexbuy.wsgi:application     # produção (Linux, atrás do nginx com HTTPS)
```

Com `DEBUG=False` o Django exige HTTPS de verdade (cookies seguros, HSTS): um teste
local sem HTTPS serve para conferir as telas, não para uso da equipe. Para colocar
no ar, siga o guia da VPS (o instalador configura HTTPS, `collectstatic`, serviço e
backup sozinho).

## Primeiro Acesso (o administrador)

1. Abra `/primeiro-acesso/` — **sem nada na URL** (o token nunca vai na URL).
2. Digite o `INITIAL_SETUP_TOKEN` no formulário.
3. Cadastre o **administrador** (perfil Proprietário: nome, usuário e senha forte),
   a empresa (CNPJ) e a primeira filial. Você tem 15 minutos depois do token.
4. Entre em `/accounts/login/` com o usuário e a senha do administrador.
5. A rota `/primeiro-acesso/` se desativa sozinha e não pode ser repetida.

Daí em diante, o administrador segue
[docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md](docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md)
(ou a seção "Primeiros passos" da Central de Ajuda): dados da empresa, filiais,
usuários e perfis, configuração financeira, receitas, custos, limites dos
compradores, fluxo de aprovação e checklist. Nenhum passo exige `/admin`, shell ou
acesso ao banco. O **Assistente de Implantação** (`/ncc/implantacao/`) **não** faz
parte deste caminho: ele cria um grupo e uma empresa novos.

### Fase de teste → uso real

A equipe pode treinar no próprio sistema com lançamentos fictícios antes do uso real.
Como compras e provisões gravadas não são editadas nem apagadas pela tela, a saída da
fase de teste é feita no servidor, uma vez, antes do primeiro lançamento de verdade:
`deploy/limpar_dados_de_teste.sh` (comando `manage.py limpar_movimentacoes`) simula,
pede o CNPJ de novo, faz backup e apaga só as movimentações daquela empresa —
cadastros, usuários, configurações e a Central de Auditoria ficam. Quando e como:
[docs/OPERACAO_BACKUP_E_ATUALIZACAO.md](docs/OPERACAO_BACKUP_E_ATUALIZACAO.md)
(seção 8) e [docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md](docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md)
(seção 16). Caso extremo: `deploy/zerar_banco.sh` recria o banco vazio e reabre o
Primeiro Acesso.

## Desenvolvimento interno (não faz parte da instalação do cliente)

> Esta seção é só para quem desenvolve o NEXBUY. **Nada aqui faz parte da
> instalação de um cliente real.**

```bash
python manage.py migrate
python manage.py runserver
```

Dados fictícios para desenvolvimento — **nunca no banco de um cliente**:

- **`python manage.py seed_dados`** — empresa de desenvolvimento ("Farmácia Modelo")
  com usuários de teste (`proprietario`, `gerente`, `financeiro`, `comprador`).
- **`python manage.py seed_demo`** — empresa de demonstração ("Farmácia Vida Plena").
  No pacote de demonstração isolado ele roda sempre com
  `--settings=nexbuy.settings_demo` (banco e mídia próprios; ver
  [DEMO_MODE.md](DEMO_MODE.md) e
  [NEXBUY_GUIA_DEMO_CLIENTE.md](NEXBUY_GUIA_DEMO_CLIENTE.md)).

Os dois comandos criam usuários com senha pública (`nexbuy123`) e ficam
**bloqueados** com `DEBUG=False`, a menos que `ALLOW_SEED_IN_PRODUCTION=True` —
nunca ligue essa variável num banco real. Na VPS, o atalho `nexbuy-manage` recusa
`seed_demo`, `seed_dados` e `flush`. Se um seed for rodado por engano no banco de um
cliente, o banco precisa ser descartado e recriado do zero (`deploy/zerar_banco.sh`, que faz backup antes).

Para desenvolver sem tocar no banco padrão, aponte `SQLITE_PATH` para outro arquivo.

## Testes automatizados

```bash
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py test --settings=nexbuy.settings_demo          # suíte completa
python manage.py test core financeiro --settings=nexbuy.settings_demo   # por app
```

A suíte completa tem mais de 890 testes e roda sempre num banco temporário —
nunca toca no banco real. O GitHub Actions (`.github/workflows/testes.yml`)
repete `check`, `check --deploy`, a checagem de migrações e a suíte completa a
cada push na `main`: com X vermelho no commit, não atualize a VPS. O pacote de
demonstração comercial registra o resultado da própria suíte em
`test_run_APRESENTACAO.txt`.

## Fora do escopo desta versão

- Integração com ERP/sistema de vendas e com bancos (o DDA é a única integração
  prevista, ainda não conectada)
- Controle de estoque e cadastro detalhado de produtos
- Pagamento disparado pelo sistema
- Recuperação de senha por e-mail (a senha é redefinida pelo administrador)
- Aplicativo nativo (o NEXBUY é responsivo no navegador do celular)
