"""Configuração do gunicorn do NEXBUY na VPS (lida por deploy/nexbuy.service).

Cada valor pode ser ajustado sem editar este arquivo, pelas variáveis
GUNICORN_* em /etc/nexbuy/nexbuy.env (depois: systemctl restart nexbuy).
"""
import multiprocessing
import os

# nginx -> gunicorn por socket unix local (nunca uma porta TCP exposta).
# /run/nexbuy é criado pelo systemd (RuntimeDirectory=nexbuy).
bind = os.environ.get("GUNICORN_BIND") or "unix:/run/nexbuy/gunicorn.sock"

# Hostinger KVM 1 (1 vCPU) -> 3 processos; KVM 2 (2 vCPU) -> 5. Limitado a 5:
# o SQLite serializa as escritas, então mais processos só disputariam o
# mesmo lock. Cada processo atende 2 requisições em paralelo (threads).
workers = int(os.environ.get("GUNICORN_WORKERS") or min(multiprocessing.cpu_count() * 2 + 1, 5))
threads = int(os.environ.get("GUNICORN_THREADS") or 2)
worker_class = "gthread"

# Uma requisição que passe disso é abortada (e registrada no log). O nginx
# espera 90 s (proxy_read_timeout), sempre mais que este valor.
timeout = int(os.environ.get("GUNICORN_TIMEOUT") or 60)
graceful_timeout = 30
keepalive = 5

# Recicla cada processo de tempos em tempos (protege contra vazamento de
# memória de longo prazo), com variação para não reciclarem todos juntos.
max_requests = 1000
max_requests_jitter = 100

# Log de acesso fica com o nginx (/var/log/nginx/nexbuy.access.log); aqui
# só erros e avisos do gunicorn, no journal: journalctl -u nexbuy
accesslog = None
errorlog = "-"
loglevel = os.environ.get("GUNICORN_LOGLEVEL") or "info"

proc_name = "nexbuy"

# Gunicorn 25.1+ abre um socket de controle em $HOME por padrão; o NEXBUY
# não usa (reinício/recarga são pelo systemctl).
control_socket_disable = True
