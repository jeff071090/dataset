#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# NEXBUY — caminhos e funções compartilhados pelos scripts de deploy.
#
# Não execute este arquivo direto: ele é carregado (source) por
# atualizar.sh, backup.sh, restaurar_backup.sh, criar_suporte_tecnico.sh e
# nexbuy-manage.sh. O instalador (instalar_servidor.sh) também o carrega
# depois de o código estar em /opt/nexbuy/app.
#
# Layout na VPS:
#   /opt/nexbuy/app              código (git clone do GitHub; dono root)
#   /opt/nexbuy/venv             ambiente Python (dono root)
#   /etc/nexbuy/nexbuy.env       variáveis de produção (600, root:nexbuy)
#   /var/lib/nexbuy/db.sqlite3   banco de dados (600, nexbuy)
#   /var/lib/nexbuy/media/       uploads (logo/favicon) — servido pelo nginx
#   /var/lib/nexbuy/staticfiles/ collectstatic — servido pelo nginx
#   /var/backups/nexbuy/         backups diários (700, root)
#   /run/nexbuy/gunicorn.sock    socket do gunicorn (nginx -> gunicorn)
# ---------------------------------------------------------------------------

APP_USER="${APP_USER:-nexbuy}"
NEXBUY_HOME="${NEXBUY_HOME:-/opt/nexbuy}"
APP_DIR="${APP_DIR:-$NEXBUY_HOME/app}"
VENV_DIR="${VENV_DIR:-$NEXBUY_HOME/venv}"
DATA_DIR="${DATA_DIR:-/var/lib/nexbuy}"
ENV_DIR="${ENV_DIR:-/etc/nexbuy}"
ENV_FILE="${ENV_FILE:-$ENV_DIR/nexbuy.env}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/nexbuy}"
SOCKET_GUNICORN="${SOCKET_GUNICORN:-/run/nexbuy/gunicorn.sock}"
SERVICO="${SERVICO:-nexbuy}"

if [[ -t 1 ]]; then
    _COR_AZUL=$'\033[1;34m'; _COR_VERDE=$'\033[1;32m'; _COR_AMARELA=$'\033[1;33m'
    _COR_VERMELHA=$'\033[1;31m'; _COR_FIM=$'\033[0m'
else
    _COR_AZUL=""; _COR_VERDE=""; _COR_AMARELA=""; _COR_VERMELHA=""; _COR_FIM=""
fi

info()   { printf '%s==>%s %s\n' "$_COR_AZUL" "$_COR_FIM" "$*"; }
ok()     { printf '%s[ OK ]%s %s\n' "$_COR_VERDE" "$_COR_FIM" "$*"; }
aviso()  { printf '%s[AVISO]%s %s\n' "$_COR_AMARELA" "$_COR_FIM" "$*" >&2; }
falhar() { printf '%s[ERRO]%s %s\n' "$_COR_VERMELHA" "$_COR_FIM" "$*" >&2; exit 1; }

exigir_root() {
    [[ "$(id -u)" -eq 0 ]] || falhar "Rode como root (ex.: sudo bash $0)."
}

exigir_env() {
    [[ -f "$ENV_FILE" ]] || falhar "Arquivo $ENV_FILE não existe. Rode primeiro deploy/instalar_servidor.sh."
}

# Lê UMA variável do nexbuy.env sem executar o arquivo (última ocorrência
# vence; aspas simples/duplas externas são removidas).
valor_env() {
    local nome="$1" padrao="${2:-}" linha valor
    linha="$(grep -E "^[[:space:]]*${nome}=" "$ENV_FILE" 2>/dev/null | tail -n 1 || true)"
    if [[ -z "$linha" ]]; then
        printf '%s' "$padrao"
        return 0
    fi
    valor="${linha#*=}"
    valor="${valor%\"}"; valor="${valor#\"}"
    valor="${valor%\'}"; valor="${valor#\'}"
    printf '%s' "${valor:-$padrao}"
}

# Roda "manage.py <argumentos>" com o ambiente de produção, como o usuário
# do sistema (nunca como root — o banco e os uploads pertencem a ele).
nexbuy_manage() {
    exigir_env
    (
        set -a
        # shellcheck disable=SC1090
        . "$ENV_FILE"
        set +a
        export PYTHONUNBUFFERED=1
        cd "$APP_DIR"
        umask 027
        runuser -u "$APP_USER" -- "$VENV_DIR/bin/python" manage.py "$@"
    )
}

# Consulta /healthz/ direto no socket do gunicorn (sem depender de DNS nem
# de certificado). Tenta por até N segundos (padrão 30).
aguardar_healthz_socket() {
    local host="$1" tentativas="${2:-30}" i resposta
    for ((i = 1; i <= tentativas; i++)); do
        resposta="$(curl -fsS --max-time 5 --unix-socket "$SOCKET_GUNICORN" \
            -H "X-Forwarded-Proto: https" "http://${host}/healthz/" 2>/dev/null || true)"
        if [[ "$resposta" == *'"ok"'* ]]; then
            return 0
        fi
        sleep 1
    done
    return 1
}

# Consulta https://<host>/healthz/ passando pelo nginx e pelo certificado.
aguardar_healthz_https() {
    local host="$1" tentativas="${2:-15}" i resposta
    for ((i = 1; i <= tentativas; i++)); do
        resposta="$(curl -fsS --max-time 10 "https://${host}/healthz/" 2>/dev/null || true)"
        if [[ "$resposta" == *'"ok"'* ]]; then
            return 0
        fi
        sleep 2
    done
    return 1
}

# Primeiro host de ALLOWED_HOSTS (o domínio principal).
dominio_principal() {
    local hosts
    hosts="$(valor_env ALLOWED_HOSTS)"
    printf '%s' "${hosts%%,*}"
}
