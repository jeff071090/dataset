#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — rodar comandos do manage.py na VPS com o ambiente de produção
#
#   sudo nexbuy-manage <comando> [argumentos]     (atalho criado pelo instalador)
#   sudo bash /opt/nexbuy/app/deploy/nexbuy-manage.sh <comando> [argumentos]
#
# Exemplos:
#   sudo nexbuy-manage showmigrations
#   sudo nexbuy-manage check --deploy
#   sudo nexbuy-manage changepassword NOME_DO_USUARIO
#
# Carrega /etc/nexbuy/nexbuy.env e roda como o usuário "nexbuy" (dono do
# banco) — nunca como root. Comandos que APAGAM dados em massa (flush,
# sqlflush) e os que criam dados fictícios (seed_demo, seed_dados) são
# recusados aqui: o banco de produção é da farmácia.
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

main() {
    exigir_root
    [[ $# -gt 0 ]] || falhar "Informe o comando. Ex.: nexbuy-manage showmigrations"
    case "$1" in
        flush|sqlflush|seed_demo|seed_dados)
            falhar "O comando '$1' não é permitido no banco de produção."
            ;;
    esac
    nexbuy_manage "$@"
}

main "$@"
exit $?
