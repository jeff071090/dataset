#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — atualizar a VPS com a última versão do GitHub
#
#   sudo bash /opt/nexbuy/app/deploy/atualizar.sh
#
# Ordem:
#   1. backup do banco + mídia (antes de qualquer mudança);
#   2. git fetch + avanço rápido (--ff-only) da branch atual;
#   3. dependências (pip install -r requirements.txt);
#   4. migrações do banco (migrate);
#   5. arquivos estáticos (collectstatic);
#   6. reinício do serviço + conferência do /healthz/.
#
# Se QUALQUER passo falhar depois que o código novo chegou ao disco (passos 3
# a 6), o script volta sozinho para a versão anterior: código (git reset),
# dependências, arquivos estáticos e modelo do serviço — e, se o serviço já
# tinha sido reiniciado, reinicia de novo na versão anterior. Assim o
# gunicorn nunca fica com código novo "pela metade" no disco (cada worker
# reciclado pelo max_requests importa o código do disco). As migrações do
# banco NÃO são desfeitas sozinhas: se chegaram a rodar, o script mostra
# como restaurar o backup do passo 1.
#
# Opcional: BRANCH=main (padrão: a branch já em uso no servidor).
# Nunca apaga dados e nunca mexe em /etc/nexbuy/nexbuy.env.
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

# Estado da atualização, lido pelo trap de saída (desfazer_atualizacao).
ATU_ANTERIOR=""
ATU_CODIGO_TROCADO=0
ATU_PIP_INICIADO=0
ATU_MIGRATE_INICIADO=0
ATU_STATIC_INICIADO=0
ATU_SERVICO_TROCADO=0
ATU_REINICIADO=0
ATU_CONCLUIDO=0

# Trap de saída: roda em QUALQUER saída do script (erro de comando com o
# set -e, falhar(), exit 1). Só age quando o código novo já estava no disco
# e a atualização não terminou com o /healthz/ ok.
desfazer_atualizacao() {
    local status="$1"
    if [[ "$status" -eq 0 || "$ATU_CODIGO_TROCADO" -ne 1 || "$ATU_CONCLUIDO" -eq 1 ]]; then
        return 0
    fi
    set +e
    aviso "A atualização FALHOU (código de saída $status). Voltando para a versão anterior automaticamente..."
    if git -C "$APP_DIR" reset --hard --quiet "$ATU_ANTERIOR"; then
        chown -R root:root "$APP_DIR"
        ok "Código de volta à versão anterior: $(git -C "$APP_DIR" log -1 --format='%h %s')"
    else
        aviso "Não consegui voltar o código sozinho. Rode: cd $APP_DIR && git reset --hard $ATU_ANTERIOR"
    fi
    if [[ "$ATU_PIP_INICIADO" -eq 1 ]]; then
        info "Reinstalando as dependências da versão anterior"
        if "$VENV_DIR/bin/python" -m pip install --quiet -r "$APP_DIR/requirements.txt"; then
            ok "Dependências da versão anterior reinstaladas"
        else
            aviso "Falha ao reinstalar as dependências. Rode: $VENV_DIR/bin/python -m pip install -r $APP_DIR/requirements.txt"
        fi
    fi
    if [[ "$ATU_STATIC_INICIADO" -eq 1 ]]; then
        if nexbuy_manage collectstatic --noinput >/dev/null; then
            ok "Arquivos estáticos da versão anterior recolocados"
        else
            aviso "Falha no collectstatic da versão anterior. Rode: bash $APP_DIR/deploy/nexbuy-manage.sh collectstatic --noinput"
        fi
    fi
    if [[ "$ATU_SERVICO_TROCADO" -eq 1 ]]; then
        install -m 644 "$APP_DIR/deploy/nexbuy.service" /etc/systemd/system/nexbuy.service && systemctl daemon-reload \
            && ok "Modelo do serviço systemd da versão anterior recolocado"
    fi
    if [[ "$ATU_REINICIADO" -eq 1 ]]; then
        systemctl restart "$SERVICO"
        if aguardar_healthz_socket "$(dominio_principal)" 40; then
            ok "Sistema de volta no ar na versão anterior (/healthz/ ok)."
        else
            aviso "O sistema também não respondeu na versão anterior. Veja o motivo: journalctl -u $SERVICO -n 100 --no-pager"
        fi
    else
        ok "O serviço não chegou a ser reiniciado: o sistema continua no ar na versão anterior."
    fi
    if [[ "$ATU_MIGRATE_INICIADO" -eq 1 ]]; then
        aviso "As migrações da versão nova chegaram a rodar no banco. Se o sistema apresentar erro na versão"
        aviso "anterior, restaure o backup feito no passo 1 (pede confirmação e reinicia o serviço):"
        aviso "  bash $APP_DIR/deploy/restaurar_backup.sh \$(ls -t $BACKUP_DIR/nexbuy_db_*.gz | head -n 1)"
    fi
    aviso "O backup feito no passo 1 está em $BACKUP_DIR."
    aviso "Depois de corrigido no GitHub (com o ✓ verde nos testes), rode de novo: bash $APP_DIR/deploy/atualizar.sh"
    return 0
}

# Tudo dentro de main(): o bash lê a função inteira antes de executar, então
# o "git pull" pode trocar este próprio arquivo no meio da execução sem que
# o restante do script vire uma mistura da versão velha com a nova.
main() {
    exigir_root
    exigir_env
    trap 'desfazer_atualizacao $?' EXIT
    umask 022
    cd "$APP_DIR"
    [[ -d .git ]] || falhar "$APP_DIR não é um repositório git — atualize copiando os arquivos ou reinstale pelo git clone."

    local branch anterior novo
    branch="${BRANCH:-$(git rev-parse --abbrev-ref HEAD)}"
    if [[ "$branch" == "HEAD" ]]; then
        falhar "O código está fixado numa versão antiga (detached HEAD, ex.: depois de um retorno de versão). Rode: cd $APP_DIR && git checkout main — ou BRANCH=main bash $0"
    fi
    if [[ "$(git rev-parse --abbrev-ref HEAD)" != "$branch" ]]; then
        git checkout "$branch"
    fi
    anterior="$(git rev-parse HEAD)"
    ATU_ANTERIOR="$anterior"

    info "1/6 Backup antes de atualizar"
    bash "$SCRIPT_DIR/backup.sh"

    info "2/6 Código: buscando a branch '$branch' no GitHub"
    git fetch --prune origin "$branch"
    if ! git diff --quiet || ! git diff --cached --quiet; then
        git status --short
        falhar "Há arquivos alterados à mão em $APP_DIR (listados acima). Nada foi atualizado. Desfaça as alterações locais (git checkout -- ARQUIVO) ou salve-as no GitHub antes."
    fi
    git merge --ff-only "origin/$branch" \
        || falhar "O servidor não conseguiu avançar para origin/$branch (histórico divergente). Nada foi reiniciado; o sistema segue na versão anterior."
    novo="$(git rev-parse HEAD)"
    # Daqui em diante o código novo está no disco: qualquer falha volta tudo.
    [[ "$anterior" == "$novo" ]] || ATU_CODIGO_TROCADO=1
    chown -R root:root "$APP_DIR"
    if [[ "$anterior" == "$novo" ]]; then
        ok "Código já estava na última versão ($(git log -1 --format='%h %s'))"
    else
        ok "Código atualizado: $(git rev-list --count "$anterior..$novo") commit(s)"
        git --no-pager log -n 20 --oneline --no-decorate "$anterior..$novo" | sed 's/^/    /'
    fi

    info "3/6 Dependências"
    ATU_PIP_INICIADO=1
    "$VENV_DIR/bin/python" -m pip install --quiet -r "$APP_DIR/requirements.txt"
    ok "Dependências em dia"

    info "4/6 Migrações do banco"
    ATU_MIGRATE_INICIADO=1
    nexbuy_manage migrate --noinput

    info "5/6 Arquivos estáticos"
    ATU_STATIC_INICIADO=1
    nexbuy_manage collectstatic --noinput
    "$VENV_DIR/bin/python" -m compileall -q "$APP_DIR" >/dev/null 2>&1 || true

    info "6/6 Reiniciando o serviço"
    # O modelo do serviço pode ter mudado junto com o código.
    if ! cmp -s "$APP_DIR/deploy/nexbuy.service" /etc/systemd/system/nexbuy.service; then
        ATU_SERVICO_TROCADO=1
        install -m 644 "$APP_DIR/deploy/nexbuy.service" /etc/systemd/system/nexbuy.service
        systemctl daemon-reload
        ok "Serviço systemd atualizado"
    fi
    nexbuy_manage check --deploy
    ATU_REINICIADO=1
    systemctl restart "$SERVICO"
    if aguardar_healthz_socket "$(dominio_principal)" 40; then
        ATU_CONCLUIDO=1
        ok "Atualização concluída — /healthz/ respondeu ok ($(git log -1 --format='%h %s'))."
    else
        journalctl -u "$SERVICO" -n 60 --no-pager >&2 || true
        # O trap de saída volta o código, as dependências e os estáticos e
        # reinicia na versão anterior (e mostra o backup, se houve migração).
        aviso "O sistema NÃO respondeu depois da atualização (motivo no log acima)."
        exit 1
    fi
}

main "$@"
exit $?
