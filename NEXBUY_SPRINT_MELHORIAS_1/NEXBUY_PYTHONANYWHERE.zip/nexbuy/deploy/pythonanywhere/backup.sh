#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — backup do banco no PythonAnywhere (demonstração ou uso real)
#
#     cd ~/nexbuy
#     bash deploy/pythonanywhere/backup.sh
#
# - Cópia íntegra pela API de backup do SQLite (sqlite3.Connection.backup do
#   Python) — nunca "cp" do arquivo aberto, que pode copiar o banco no meio
#   de uma gravação do site. A cópia é conferida com PRAGMA integrity_check.
# - Destino: ~/nexbuy_backups/nexbuy_AAAA-MM-DD_HHMM.sqlite3
# - Guarda as 5 cópias manuais mais recentes; em USO REAL (marcador no .env,
#   ou banco com empresa de verdade / Primeiro Acesso feito), as 10 mais
#   recentes (a cota do plano grátis é 512 MB). Só apaga cópias manuais
#   antigas (nexbuy_*.sqlite3): os backups diários automáticos
#   (diario_*.sqlite3) e as pastas demonstracao_final_* nunca são tocados.
# - Para baixar para o seu computador: aba Files > pasta nexbuy_backups >
#   ícone de download ao lado do arquivo.
#
# O atualizar.sh e o restaurar.sh já rodam este backup antes de mexer no
# banco. backup_demo.sh é o nome antigo deste script e continua valendo.
# Uso interno (ativar_uso_real.sh): --destino ARQUIVO grava a cópia nesse
# arquivo, sem mexer nas cópias guardadas.
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum_pa.sh"

DESTINO_FIXO=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --destino)
            [[ $# -ge 2 && -n "$2" ]] || falhar "Faltou o arquivo depois de --destino."
            DESTINO_FIXO="$2"
            shift
            ;;
        -h|--ajuda|--help) mostrar_ajuda "${BASH_SOURCE[0]}"; exit 0 ;;
        *) falhar "Opção desconhecida: $1" "Uso: bash deploy/pythonanywhere/backup.sh" ;;
    esac
    shift
done

BANCO="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
MANTER=5
TIPO="da demonstração"
if uso_real_no_env; then
    MANTER=10
    TIPO="do NEXBUY (uso real)"
elif [[ -z "$DESTINO_FIXO" && -f "$BANCO" ]]; then
    # Sem o marcador, mas com empresa de verdade ou Primeiro Acesso feito no
    # banco: retenção do uso real (o .env pode ter vindo errado).
    estado_do_banco "$BANCO"
    if (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
        MANTER=10
        TIPO="do NEXBUY (uso real: o banco tem dados reais)"
    fi
fi

etapa "backup" "Cópia do banco $TIPO"
[[ -f "$BANCO" ]] || falhar "Banco não encontrado em $BANCO." \
    "Rode primeiro: bash deploy/pythonanywhere/preparar.sh"

PYTHON_BACKUP="$(python_dos_scripts)" || falhar "Não achei um Python para fazer a cópia."

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR" 2>/dev/null || true
if [[ -n "$DESTINO_FIXO" ]]; then
    [[ ! -e "$DESTINO_FIXO" ]] || falhar "O arquivo $DESTINO_FIXO já existe — nada foi copiado."
    mkdir -p "$(dirname "$DESTINO_FIXO")"
    DESTINO="$DESTINO_FIXO"
else
    CARIMBO="$(date +%Y-%m-%d_%H%M)"
    DESTINO="$BACKUP_DIR/nexbuy_${CARIMBO}.sqlite3"
    # Duas cópias no mesmo minuto: sufixo _02, _03... (com zero à esquerda,
    # para a ordem alfabética continuar sendo a cronológica).
    contador=2
    while [[ -e "$DESTINO" ]]; do
        DESTINO="$BACKUP_DIR/nexbuy_${CARIMBO}_$(printf '%02d' "$contador").sqlite3"
        contador=$((contador + 1))
    done
fi
PARCIAL="$DESTINO.parcial"

"$PYTHON_BACKUP" - "$BANCO" "$PARCIAL" <<'PY' || { rm -f "$PARCIAL"; falhar "A cópia do banco falhou (mensagem acima)."; }
import sqlite3
import sys

origem, destino = sys.argv[1], sys.argv[2]
fonte = sqlite3.connect(origem, timeout=30)
copia = sqlite3.connect(destino)
try:
    fonte.backup(copia)
    resultado = copia.execute("PRAGMA integrity_check").fetchone()[0]
finally:
    copia.close()
    fonte.close()
if resultado != "ok":
    print(f"A cópia não passou no integrity_check: {resultado}", file=sys.stderr)
    sys.exit(1)
PY
mv -f "$PARCIAL" "$DESTINO"
chmod 600 "$DESTINO" 2>/dev/null || true
ok "Backup: $DESTINO ($(du -h "$DESTINO" | cut -f1))"

if [[ -n "$DESTINO_FIXO" ]]; then
    exit 0
fi

# Retenção: só as $MANTER cópias manuais mais recentes (os nomes têm data e
# hora, então a ordem alfabética é a cronológica). O padrão nexbuy_*.sqlite3
# na pasta de cima nunca pega diario_*.sqlite3 nem demonstracao_final_*/.
shopt -s nullglob
COPIAS=("$BACKUP_DIR"/nexbuy_*.sqlite3)
shopt -u nullglob
if (( ${#COPIAS[@]} > MANTER )); then
    mapfile -t ORDENADAS < <(printf '%s\n' "${COPIAS[@]}" | sort)
    for (( i = 0; i < ${#ORDENADAS[@]} - MANTER; i++ )); do
        rm -f "${ORDENADAS[$i]}"
        info "Removido (mais antigo que as $MANTER últimas): $(basename "${ORDENADAS[$i]}")"
    done
fi
ok "Cópias manuais guardadas em $BACKUP_DIR: $(find "$BACKUP_DIR" -maxdepth 1 -name 'nexbuy_*.sqlite3' | wc -l | tr -d ' ') (máximo $MANTER)"
DIARIOS="$(find "$BACKUP_DIR" -maxdepth 1 -name 'diario_*.sqlite3' | wc -l | tr -d ' ')"
if [[ "$DIARIOS" != "0" ]]; then
    info "Backups diários automáticos (diario_*.sqlite3): $DIARIOS — não são mexidos aqui."
fi
info "Para baixar: aba Files > pasta nexbuy_backups > ícone de download ao lado do arquivo."
