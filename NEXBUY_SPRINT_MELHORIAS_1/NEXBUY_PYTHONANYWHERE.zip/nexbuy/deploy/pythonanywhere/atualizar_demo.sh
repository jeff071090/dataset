#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — nome antigo da atualização no PythonAnywhere. Continua
# funcionando: faz exatamente o mesmo que deploy/pythonanywhere/atualizar.sh
# (use aquele), com as mesmas opções.
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/atualizar.sh" "$@"
