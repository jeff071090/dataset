#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — volta o site do PythonAnywhere do USO REAL para a DEMONSTRAÇÃO
#
# Só serve ANTES do Primeiro Acesso (ex.: a troca foi feita por engano):
# traz de volta a demonstração que o ativar_uso_real.sh guardou em
# ~/nexbuy_backups/demonstracao_final_AAAA-MM-DD_HHMM/.
#
#     cd ~/nexbuy
#     bash deploy/pythonanywhere/voltar_demonstracao.sh
#
# Sem argumento, usa a pasta demonstracao_final_* mais recente. Para
# escolher outra, passe a pasta:
#     bash deploy/pythonanywhere/voltar_demonstracao.sh ~/nexbuy_backups/demonstracao_final_AAAA-MM-DD_HHMM
#
# ANTES de mexer em qualquer coisa, confere (e recusa, sem alterar nada):
#   - o site não tem dado real: nenhuma empresa fora da demonstração,
#     nenhum usuário ativo de fora dela e o Primeiro Acesso NÃO foi feito;
#   - a pasta escolhida tem um banco íntegro da demonstração.
# Depois, nesta ordem:
#   1. pede para digitar VOLTAR (ou --sim);
#   2. faz um backup do banco atual (backup.sh);
#   3. restaura o banco da demonstração (pela API de backup do SQLite) e
#      aplica as migrações pendentes;
#   4. MOVE os uploads atuais para ~/nexbuy_backups/media_antes_da_volta_.../
#      (nunca apaga) e copia os da demonstração;
#   5. deixa o .env como demonstração (NEXBUY_USO_REAL=False,
#      DEMO_MODE=True, sem token do Primeiro Acesso, sem backup diário) — o
#      resto do .env (chave secreta, endereço do site) fica igual;
#   6. roda o atualizar.sh (senhas de demonstração conferidas, recarga).
# A pasta demonstracao_final_* continua guardada.
#
# Opções:
#   --sim       não pede para digitar VOLTAR
#   --sem-wsgi  não recarrega o site (testes fora do PythonAnywhere)
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum_pa.sh"

CONFIRMADO=0
SEM_WSGI=0
PASTA=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --sim) CONFIRMADO=1 ;;
        --sem-wsgi) SEM_WSGI=1 ;;
        -h|--ajuda|--help) mostrar_ajuda "${BASH_SOURCE[0]}"; exit 0 ;;
        -*) falhar "Opção desconhecida: $1" "Opções válidas: --sim --sem-wsgi" ;;
        *)
            [[ -z "$PASTA" ]] || falhar "Informe UMA pasta só."
            PASTA="${1%/}"
            ;;
    esac
    shift
done

# ---------------------------------------------------------------------------
etapa "1/6" "Conferindo a instalação e o banco atual (nada é alterado aqui)"
# ---------------------------------------------------------------------------
exigir_instalacao
definir_dominio ""
if env_ligado DEBUG; then
    falhar "O $ENV_FILE está com DEBUG ligado — proibido num site na internet." \
        "Edite o arquivo e deixe DEBUG=False; depois rode de novo. Nada foi alterado."
fi
if env_ligado ALLOW_SEED_IN_PRODUCTION; then
    falhar "O $ENV_FILE tem ALLOW_SEED_IN_PRODUCTION ligado — isso vale para o site inteiro." \
        "Apague essa linha do .env e rode de novo. Nada foi alterado."
fi
BANCO="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
MIDIA="$(valor_env MEDIA_ROOT "$DADOS_DIR_PADRAO/media")"
MIDIA="${MIDIA%/}"
estado_do_banco "$BANCO"
mostrar_estado_do_banco
if banco_tem_dados_reais; then
    falhar "Recusado: o site tem dados REAIS ($(resumo_dados_reais))." \
        "Voltar para a demonstração apagaria esses dados — por isso só vale ANTES do Primeiro Acesso." \
        "Nada foi alterado: o banco, o .env e os uploads continuam exatamente como estavam." \
        "PARE aqui: não apague nem copie nada à mão. Para apresentações, use a demonstração do computador."
fi
if ! uso_real_no_env && [[ "$BANCO_SITUACAO" == "ok" ]] && (( QTD_EMPRESAS > 0 )); then
    ok "O site já está na DEMONSTRAÇÃO (o .env não tem NEXBUY_USO_REAL=True) — nada foi alterado."
    exit 0
fi
ok "O site não tem dado real (o Primeiro Acesso não foi feito): dá para voltar."

# ---------------------------------------------------------------------------
etapa "2/6" "Conferindo a demonstração guardada"
# ---------------------------------------------------------------------------
if [[ -z "$PASTA" ]]; then
    shopt -s nullglob
    GUARDADAS=("$BACKUP_DIR"/demonstracao_final_*/)
    shopt -u nullglob
    (( ${#GUARDADAS[@]} > 0 )) || falhar "Não achei nenhuma pasta demonstracao_final_* em $BACKUP_DIR." \
        "Sem a cópia guardada pelo ativar_uso_real.sh não há demonstração para trazer de volta." \
        "Nada foi alterado. Veja a lista com: ls -l ~/nexbuy_backups/"
    mapfile -t GUARDADAS < <(printf '%s\n' "${GUARDADAS[@]}" | sort)
    PASTA="${GUARDADAS[${#GUARDADAS[@]} - 1]%/}"
    info "Usando a demonstração guardada mais recente (para outra, passe a pasta no comando)."
fi
[[ -d "$PASTA" ]] || falhar "Pasta não encontrada: $PASTA" "Nada foi alterado. Veja a lista com: ls -l ~/nexbuy_backups/"
[[ -f "$PASTA/db.sqlite3" ]] || falhar "A pasta $PASTA não tem o db.sqlite3 da demonstração." \
    "Nada foi alterado. Escolha uma pasta demonstracao_final_* de ~/nexbuy_backups/."
conferir_banco_do_nexbuy "$PASTA/db.sqlite3" || falhar \
    "O banco guardado em $PASTA não serve (mensagem acima). Nada foi alterado."

# Cópia particular: o backup de segurança (etapa 4) e a restauração leem
# dela — a pasta guardada nunca é alterada.
COPIA_ORIGEM="$(dirname "$BANCO")/.voltar.$$.sqlite3"
mkdir -p "$(dirname "$BANCO")"
trap 'rm -f "$COPIA_ORIGEM" "$COPIA_ORIGEM-journal"' EXIT
cp "$PASTA/db.sqlite3" "$COPIA_ORIGEM" || falhar "Não consegui ler $PASTA/db.sqlite3." "Nada foi alterado."
chmod 600 "$COPIA_ORIGEM" 2>/dev/null || true

# Conferido o banco ATUAL acima; agora o guardado (as variáveis do
# estado_do_banco passam a ser dele até a etapa 5).
estado_do_banco "$COPIA_ORIGEM"
if [[ "$BANCO_SITUACAO" != "ok" ]] || (( QTD_EMPRESAS == 0 )) || banco_tem_dados_reais; then
    falhar "A pasta $PASTA não tem a demonstração (empresas: $QTD_EMPRESAS; reais: $QTD_EMPRESAS_REAIS)." \
        "Nada foi alterado. Escolha uma pasta demonstracao_final_* de ~/nexbuy_backups/."
fi
ok "Demonstração guardada íntegra: $PASTA"
info "  empresas: $NOMES_EMPRESAS_DEMO — usuários ativos: $QTD_ATIVOS"
NOMES_DA_DEMONSTRACAO="$NOMES_EMPRESAS_DEMO"

# ---------------------------------------------------------------------------
etapa "3/6" "Confirmação"
# ---------------------------------------------------------------------------
printf '\n%s' "$_COR_AMARELA"
printf '%s\n' "  O site volta a ser a DEMONSTRAÇÃO ($NOMES_DA_DEMONSTRACAO), exatamente como estava"
printf '%s\n' "  em $(basename "$PASTA"), com as mesmas senhas de antes nos acessos demo_*."
printf '%s\n' "  O Primeiro Acesso fecha (o token sai do .env) e o backup diário automático é desligado."
printf '%s\n' "  Antes, uma cópia do banco atual e os uploads atuais vão para ~/nexbuy_backups/."
printf '%s\n' "  Peça para ninguém usar o site nos próximos minutos."
printf '%s\n' "$_COR_FIM"
if [[ "$CONFIRMADO" == "1" ]]; then
    info "Confirmado por --sim."
else
    [[ -t 0 ]] || falhar "Sem terminal para confirmar. Nada foi alterado." "Rode no console Bash ou acrescente --sim."
    RESPOSTA=""
    read -r -p "    Para voltar à demonstração, digite VOLTAR (em maiúsculas) e tecle Enter: " RESPOSTA
    [[ "$RESPOSTA" == "VOLTAR" ]] || falhar "Cancelado: nada foi alterado." \
        "Para voltar, rode de novo e digite VOLTAR."
fi

# ---------------------------------------------------------------------------
etapa "4/6" "Backup do banco atual"
# ---------------------------------------------------------------------------
if [[ -f "$BANCO" ]]; then
    bash "$SCRIPT_DIR/backup.sh" || falhar "O backup falhou — nada foi alterado." \
        "Confira o espaço em disco (aba Files) e rode de novo."
else
    aviso "Não há banco atual — nada para guardar."
fi

# ---------------------------------------------------------------------------
etapa "5/6" "Restaurando a demonstração"
# ---------------------------------------------------------------------------
copiar_banco_por_cima "$COPIA_ORIGEM" "$BANCO" || falhar "A restauração falhou (mensagem acima)." \
    "O .env e os uploads não foram tocados; o banco anterior está em $BACKUP_DIR. Rode de novo."
chmod 600 "$BANCO" 2>/dev/null || true
ok "Banco da demonstração restaurado (de $PASTA)."
manage migrate --noinput || falhar "O migrate falhou depois da restauração (veja acima)." \
    "O .env e os uploads não foram tocados; o banco anterior está em $BACKUP_DIR."
ok "Migrações conferidas."

# Uploads: os atuais são MOVIDOS (nunca apagados); os da demonstração, copiados.
if [[ -d "$MIDIA" ]]; then
    if [[ -n "$(ls -A "$MIDIA" 2>/dev/null)" ]]; then
        GUARDA_MIDIA="$BACKUP_DIR/media_antes_da_volta_$(date +%Y-%m-%d_%H%M%S)"
        mkdir -p "$BACKUP_DIR"
        mv "$MIDIA" "$GUARDA_MIDIA"
        ok "Uploads que estavam no site guardados em $GUARDA_MIDIA"
    else
        rmdir "$MIDIA"
    fi
fi
mkdir -p "$(dirname "$MIDIA")"
if [[ -d "$PASTA/media" ]]; then
    cp -R "$PASTA/media" "$MIDIA"
    ok "Logo e arquivos da demonstração de volta em $MIDIA"
else
    mkdir -p "$MIDIA"
    info "A demonstração guardada não tinha uploads."
fi

# ---------------------------------------------------------------------------
etapa "6/6" ".env da demonstração e atualização do site"
# ---------------------------------------------------------------------------
gravar_no_env NEXBUY_USO_REAL=False DEMO_MODE=True "INITIAL_SETUP_TOKEN=" BACKUP_DIARIO=False
ok ".env de volta à demonstração: NEXBUY_USO_REAL=False, DEMO_MODE=True, Primeiro Acesso fechado"
ok "e backup diário desligado. O resto do .env (chave secreta, endereço do site) ficou igual."
ARGUMENTOS_ATUALIZAR=()
if [[ "$SEM_WSGI" == "1" ]]; then
    ARGUMENTOS_ATUALIZAR+=(--sem-wsgi)
fi
bash "$SCRIPT_DIR/atualizar.sh" ${ARGUMENTOS_ATUALIZAR[@]+"${ARGUMENTOS_ATUALIZAR[@]}"} || falhar \
    "A demonstração já voltou (banco, uploads e .env), mas a atualização parou (veja acima)." \
    "Siga a instrução acima e rode: bash deploy/pythonanywhere/atualizar.sh"

printf '\n%s\n' "=========================================================================="
printf '%s\n' " A DEMONSTRAÇÃO voltou: https://$DOMINIO/  (a cópia $(basename "$PASTA") continua guardada)."
printf '%s\n' " Os acessos demo_* entram com as mesmas senhas de antes da troca."
printf '%s\n' "=========================================================================="
