#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — passa o site do PythonAnywhere da DEMONSTRAÇÃO para o USO REAL
#
# Rode UMA vez, no console Bash do PythonAnywhere, de dentro de ~/nexbuy,
# depois de atualizar o código (guia: docs/PYTHONANYWHERE_USO_REAL.md):
#
#     cd ~/nexbuy
#     bash deploy/pythonanywhere/ativar_uso_real.sh
#
# O que faz, nesta ordem:
#   1. confere a instalação e o que existe hoje no banco;
#   2. instala as dependências (nada é apagado se isso falhar);
#   3. pede para digitar APAGAR, explicando o que sai e o que fica guardado;
#   4. guarda o banco e os arquivos da demonstração em
#      ~/nexbuy_backups/demonstracao_final_AAAA-MM-DD_HHMM/ (dá para voltar);
#   5. troca o banco por um banco NOVO e VAZIO (mesmo endereço do .env) e
#      esvazia a pasta de uploads — somem a farmácia fictícia, os 6 usuários
#      de demonstração e todos os lançamentos;
#   6. liga o uso real no .env (DEMO_MODE=False, NEXBUY_USO_REAL=True,
#      backup diário automático) com um token NOVO para o Primeiro Acesso —
#      o resto do .env (chave secreta, endereço do site...) fica igual;
#   7. atualiza os estáticos, recarrega o site e testa as páginas;
#   8. mostra UMA vez o endereço e o token do Primeiro Acesso (também se o
#      script parar depois de gravar o token no .env).
#
# Opções:
#   --sim         não pergunta antes de apagar (normalmente pede APAGAR)
#   --novo-token  gera OUTRO token para o Primeiro Acesso — só enquanto a
#                 proprietária ainda não o fez (não apaga nada)
#   --descartar-empresas-da-demonstracao
#                 a cliente cadastrou empresa DENTRO da demonstração (ex.:
#                 pelo Assistente de Implantação): sem esta opção o script
#                 recusa; com ela, essas empresas saem junto com a
#                 demonstração (ficam guardadas na mesma cópia)
#   --sem-wsgi    não recarrega o site (testes fora do PythonAnywhere)
#
# Seguro para repetir: com o site já em uso real, o script se recusa a
# apagar qualquer coisa — se a troca parou no meio, ele a termina
# (estáticos e recarga) sem apagar nada. Nunca apaga um banco de uso real
# (empresa de verdade, CNPJ fora do prefixo 98765432 da demonstração, ou
# Primeiro Acesso já feito).
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum_pa.sh"

CONFIRMADO=0
NOVO_TOKEN=0
DESCARTAR=0
SEM_WSGI=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --sim) CONFIRMADO=1 ;;
        --novo-token) NOVO_TOKEN=1 ;;
        --descartar-empresas-da-demonstracao) DESCARTAR=1 ;;
        --sem-wsgi) SEM_WSGI=1 ;;
        -h|--ajuda|--help) mostrar_ajuda "${BASH_SOURCE[0]}"; exit 0 ;;
        *) falhar "Opção desconhecida: $1" \
            "Opções válidas: --sim --novo-token --descartar-empresas-da-demonstracao --sem-wsgi" ;;
    esac
    shift
done

# Se o script parar DEPOIS de gravar o token no .env (ex.: o collectstatic
# falhou, disco cheio, Ctrl+C), o token já vale e mais ninguém o veria: o
# quadro aparece na saída do script, UMA vez, mesmo nesse caso.
TOKEN_GRAVADO=0
mostrar_token_se_parou() {
    if [[ "$TOKEN_GRAVADO" == "1" ]]; then
        TOKEN_GRAVADO=0
        printf '\n' >&2
        aviso "O script PAROU antes do fim, mas o .env já tem o token novo do Primeiro Acesso (quadro abaixo)."
        aviso "Corrija o problema acima e rode de novo: bash deploy/pythonanywhere/ativar_uso_real.sh"
        aviso "(ele termina a troca sem apagar nada, e o token continua o mesmo)."
        mostrar_token_primeiro_acesso "$TOKEN_NOVO"
        TOKEN_NOVO=""
    fi
}
trap mostrar_token_se_parou EXIT

# Recarrega o site e confere as páginas do uso real (sem --sem-wsgi).
recarregar_e_conferir() {
    local paginas=("$@")
    if [[ "$SEM_WSGI" == "1" ]]; then
        info "Recarga pulada (--sem-wsgi). No PythonAnywhere: botão verde Reload na aba Web."
        return 0
    fi
    if ! recarregar_site; then
        aviso "Sem a recarga, o site continua com a configuração antiga: clique em Reload na aba Web."
        return 0
    fi
    if ! command -v curl >/dev/null 2>&1; then
        info "Sem curl: abra https://$DOMINIO/primeiro-acesso/ no navegador para conferir."
        return 0
    fi
    if aguardar_site_no_ar; then
        conferir_paginas "${paginas[@]}" || aviso "Alguma página respondeu diferente do esperado (acima). Clique em Reload na aba Web e confira de novo."
    fi
    conferir_force_https || true
}

# Gera um token novo, grava no .env e devolve em TOKEN_NOVO (nunca em log).
trocar_token() {
    TOKEN_NOVO="$(gerar_token)"
    gravar_no_env "INITIAL_SETUP_TOKEN=$TOKEN_NOVO"
    TOKEN_GRAVADO=1
}

# ---------------------------------------------------------------------------
etapa "1/8" "Conferindo a instalação"
# ---------------------------------------------------------------------------
exigir_instalacao
definir_dominio ""
if env_ligado DEBUG; then
    falhar "O $ENV_FILE está com DEBUG ligado — proibido num site na internet." \
        "Edite o arquivo e deixe DEBUG=False; depois rode de novo. Nada foi apagado."
fi
if env_ligado ALLOW_SEED_IN_PRODUCTION; then
    falhar "O $ENV_FILE tem ALLOW_SEED_IN_PRODUCTION ligado — isso vale para o site inteiro." \
        "Apague essa linha do .env e rode de novo. Nada foi apagado."
fi
BANCO="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
MIDIA="$(valor_env MEDIA_ROOT "$DADOS_DIR_PADRAO/media")"
ESTATICOS="$(valor_env STATIC_ROOT "$STATIC_DIR_PADRAO")"
ok "Código em $APP_DIR — site https://$DOMINIO/"
ok "Banco em $BANCO — uploads em $MIDIA"

# ---------------------------------------------------------------------------
etapa "2/8" "O que existe hoje no banco"
# ---------------------------------------------------------------------------
estado_do_banco "$BANCO"
mostrar_estado_do_banco

BANCO_SEM_DADOS=0
if [[ "$BANCO_SITUACAO" != "ok" ]] || (( QTD_EMPRESAS == 0 && QTD_ATIVOS == 0 )); then
    BANCO_SEM_DADOS=1
fi

MISTO=0
if banco_misto; then
    # A cliente cadastrou empresa DENTRO da demonstração (sem Primeiro
    # Acesso). Com ou sem o marcador no .env, só sai com ordem explícita —
    # e nunca se sugere o marcador: o fictício ficaria no uso real.
    MISTO=1
    if [[ "$DESCARTAR" != "1" ]]; then
        falhar "O banco é a DEMONSTRAÇÃO com empresa cadastrada DENTRO dela: $NOMES_EMPRESAS_REAIS." \
            "Por segurança, sem uma ordem explícita este script nunca apaga um banco com dados reais. Nada foi alterado." \
            "Junto dela estão a farmácia fictícia ($NOMES_EMPRESAS_DEMO), os usuários de demonstração e" \
            "tudo o que foi lançado. NÃO ponha o marcador NEXBUY_USO_REAL à mão: o fictício ficaria no uso real." \
            "Se a cliente só testou na demonstração e vai começar do zero no uso real (ela cadastra a empresa" \
            "de novo no Primeiro Acesso), descarte tudo — fica guardado numa cópia em ~/nexbuy_backups/:" \
            "    bash deploy/pythonanywhere/ativar_uso_real.sh --descartar-empresas-da-demonstracao"
    fi
    aviso "--descartar-empresas-da-demonstracao: as empresas cadastradas na demonstração ($NOMES_EMPRESAS_REAIS)"
    aviso "saem do site junto com a demonstração (ficam guardadas na mesma cópia)."
elif [[ "$DESCARTAR" == "1" ]]; then
    info "--descartar-empresas-da-demonstracao não muda nada aqui: não há empresa cadastrada na demonstração."
fi

if [[ "$MISTO" == "1" ]]; then
    : # segue a troca (a confirmação APAGAR lista tudo o que sai)
elif uso_real_no_env; then
    if banco_tem_dados_reais; then
        # Já em uso real (dados reais, ou Primeiro Acesso já concluído): não
        # apaga NADA, em hipótese alguma.
        if [[ "$NOVO_TOKEN" == "1" ]]; then
            falhar "O Primeiro Acesso já foi feito: não existe mais token a gerar. Nada foi alterado." \
                "Quem esqueceu a senha: a proprietária gera uma senha provisória em Usuários e Permissões."
        fi
        printf '\n'
        ok "Este site JÁ ESTÁ em USO REAL — nada foi apagado nem alterado."
        info "Para atualizar o sistema: bash deploy/pythonanywhere/atualizar.sh"
        mostrar_backup_diario_recente "$(valor_env BACKUP_DIARIO_DIR "$BACKUP_DIR")"
        exit 0
    fi
    if [[ "$BANCO_SITUACAO" == "ok" && "$BANCO_SEM_DADOS" == "1" ]]; then
        # Uso real com o Primeiro Acesso por fazer: banco vazio, nada a apagar.
        if [[ "$NOVO_TOKEN" != "1" ]]; then
            printf '\n'
            ok "Este site já está em USO REAL, esperando o Primeiro Acesso — nada foi apagado."
            # Se a troca anterior parou depois do APAGAR (ex.: o collectstatic
            # falhou), é aqui que ela termina: estáticos, recarga e conferência.
            # ---------------------------------------------------------------
            etapa "3/8" "Estáticos e recarga do site (termina a troca, se ela parou no meio)"
            # ---------------------------------------------------------------
            manage collectstatic --noinput -v 0 || falhar "O collectstatic falhou (veja acima). Nada foi apagado." \
                "Corrija (ex.: espaço em disco: rm -rf ~/.cache/pip) e rode este script de novo."
            ok "Arquivos estáticos atualizados em $ESTATICOS."
            if [[ -n "$(valor_env INITIAL_SETUP_TOKEN)" ]]; then
                recarregar_e_conferir "/accounts/login/=200" "/primeiro-acesso/=200" "/demo/apresentacao/=404"
                info "O endereço https://$DOMINIO/primeiro-acesso/ fica aberto com o MESMO token (o que está no .env)."
            else
                recarregar_e_conferir "/accounts/login/=200" "/demo/apresentacao/=404"
                aviso "O .env está sem token: o endereço do Primeiro Acesso está fechado."
            fi
            info "Não viu o quadro PRIMEIRO ACESSO com o token (o script parou antes do fim) ou perdeu o token?"
            info "Gere outro (o antigo deixa de valer):"
            info "    bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token"
            exit 0
        fi
        # -------------------------------------------------------------------
        etapa "3/8" "Token novo para o Primeiro Acesso"
        # -------------------------------------------------------------------
        trocar_token
        ok "Token novo gravado no .env (o anterior deixou de valer)."
        recarregar_e_conferir "/primeiro-acesso/=200" "/demo/apresentacao/=404"
        TOKEN_GRAVADO=0
        mostrar_token_primeiro_acesso "$TOKEN_NOVO"
        TOKEN_NOVO=""
        exit 0
    fi
    if [[ "$BANCO_SITUACAO" == "ok" ]]; then
        # Marcador ligado, mas o banco ainda é o da demonstração (só empresas e
        # usuários fictícios): a troca ficou pela metade. Segue a troca.
        aviso "O .env já diz USO REAL, mas o banco ainda é o da demonstração — a troca vai ser concluída agora."
    else
        aviso "O .env já diz USO REAL, mas o banco ainda não existe — ele vai ser criado agora."
    fi
else
    if (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
        # Só dados reais (o banco misto já foi tratado acima): é um site em
        # uso real cujo .env perdeu o marcador.
        falhar "O banco já é de USO REAL ($(resumo_dados_reais))." \
            "Por segurança, este script nunca apaga um banco com dados reais. Nada foi alterado." \
            "Falta só o marcador NEXBUY_USO_REAL=True no .env. Rode bash deploy/pythonanywhere/atualizar.sh:" \
            "ele grava o marcador e atualiza o sistema sem apagar nada."
    fi
    if [[ "$NOVO_TOKEN" == "1" ]]; then
        info "--novo-token não é preciso agora: a troca já gera um token novo."
    fi
fi

# Banco sem empresa e sem usuário ativo (ou nem existe): nada a confirmar nem
# a guardar — ex.: a troca anterior parou depois de esvaziar o banco.
BANCO_VAZIO="$BANCO_SEM_DADOS"

# ---------------------------------------------------------------------------
etapa "3/8" "Dependências (antes de qualquer mudança)"
# ---------------------------------------------------------------------------
instalar_dependencias
ok "Dependências em dia."

# ---------------------------------------------------------------------------
etapa "4/8" "Confirmação"
# ---------------------------------------------------------------------------
if [[ "$BANCO_VAZIO" == "1" ]]; then
    ok "O banco não tem empresa nem usuário: não há dado para apagar."
else
    printf '\n%s' "$_COR_VERMELHA"
    printf '%s\n' "  ATENÇÃO: a partir daqui o site deixa de ser demonstração. SAI do site:"
    printf '%s\n' "    - as empresas fictícias (${NOMES_EMPRESAS_DEMO:-Farmácia Vida Plena});"
    if [[ "$MISTO" == "1" ]]; then
        printf '%s\n' "    - as empresas cadastradas DENTRO da demonstração: $NOMES_EMPRESAS_REAIS;"
    fi
    # A mesma contagem da etapa 2 ("de demonstração: N"): além dos 6 de
    # login, o cenário tem outros usuários fictícios da farmácia.
    printf '%s\n' "    - os $((QTD_ATIVOS - QTD_ATIVOS_FORA_DEMO)) usuários ativos da demonstração, entre eles os 6 acessos"
    printf '%s\n' "      que a cliente usava (demo_proprietario, demo_gerente, demo_financeiro,"
    printf '%s\n' "      demo_comprador, demo_comprador2, demo_comprador3): DEIXAM DE EXISTIR;"
    printf '%s\n' "    - todas as compras, provisões, aprovações, lançamentos financeiros e a"
    printf '%s\n' "      auditoria da demonstração — inclusive o que a cliente lançou nela;"
    if (( QTD_ATIVOS_FORA_DEMO > 0 )); then
        printf '%s\n' "    - também os usuários que não são de demonstração: $NOMES_ATIVOS_FORA_DEMO;"
    fi
    printf '%s\n' "    - o logo e os arquivos enviados na demonstração."
    printf '%s\n' "  FICA GUARDADO (dá para voltar): cópia completa do banco e dos arquivos em"
    printf '%s\n' "    ~/nexbuy_backups/demonstracao_final_AAAA-MM-DD_HHMM/"
    printf '%s\n' "  CONTINUA IGUAL: o código, o endereço do site, a chave secreta e o virtualenv."
    printf '%s\n' "  A demonstração do computador (Desktop) não muda em nada."
    printf '%s\n' "  Peça para ninguém usar o site nos próximos 2 minutos."
    printf '%s\n' "$_COR_FIM"
    if [[ "$CONFIRMADO" == "1" ]]; then
        info "Confirmado por --sim."
    else
        [[ -t 0 ]] || falhar "Sem terminal para confirmar. Nada foi apagado." "Rode no console Bash ou acrescente --sim."
        RESPOSTA=""
        read -r -p "    Para continuar, digite APAGAR (em maiúsculas) e tecle Enter: " RESPOSTA
        [[ "$RESPOSTA" == "APAGAR" ]] || falhar "Cancelado: nada foi apagado." \
            "Para fazer a troca, rode de novo e digite APAGAR."
    fi
fi

# ---------------------------------------------------------------------------
etapa "5/8" "Guardando a demonstração"
# ---------------------------------------------------------------------------
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR" 2>/dev/null || true
ARQUIVO=""
if [[ "$BANCO_VAZIO" == "1" ]]; then
    ok "Banco vazio: nada para guardar."
else
    CARIMBO="$(date +%Y-%m-%d_%H%M)"
    ARQUIVO="$BACKUP_DIR/demonstracao_final_$CARIMBO"
    contador=2
    while [[ -e "$ARQUIVO" ]]; do
        ARQUIVO="$BACKUP_DIR/demonstracao_final_${CARIMBO}_$(printf '%02d' "$contador")"
        contador=$((contador + 1))
    done
    mkdir -p "$ARQUIVO"
    chmod 700 "$ARQUIVO" 2>/dev/null || true
    bash "$SCRIPT_DIR/backup.sh" --destino "$ARQUIVO/db.sqlite3" || falhar \
        "A cópia do banco da demonstração falhou — nada foi apagado." \
        "Confira o espaço em disco (aba Files) e rode de novo."
    ok "Banco da demonstração guardado (cópia íntegra): $ARQUIVO/db.sqlite3"
fi

# ---------------------------------------------------------------------------
etapa "6/8" "Banco novo e vazio"
# ---------------------------------------------------------------------------
mkdir -p "$(dirname "$BANCO")"
chmod 700 "$(dirname "$BANCO")" 2>/dev/null || true
NOVO="$BANCO.novo.$$"
rm -f "$NOVO" "$NOVO-journal"
info "Criando as tabelas num banco novo (migrate; leva alguns segundos)..."
( export SQLITE_PATH="$NOVO"; manage migrate --noinput ) || {
    rm -f "$NOVO" "$NOVO-journal"
    falhar "O migrate do banco novo falhou (veja acima). O banco do site NÃO foi trocado." \
        "Rode o script de novo; se repetir, veja o Error log na aba Web."
}
if [[ -f "$BANCO" ]]; then
    # Troca pela API de backup do SQLite: o banco do site recebe o conteúdo do
    # banco novo numa transação só (o site pode estar no ar).
    copiar_banco_por_cima "$NOVO" "$BANCO" || {
        rm -f "$NOVO" "$NOVO-journal"
        falhar "Não consegui trocar o banco (mensagem acima). A cópia da demonstração está em ${ARQUIVO:-$BACKUP_DIR}." \
            "Rode o script de novo."
    }
    rm -f "$NOVO" "$NOVO-journal"
else
    mv -f "$NOVO" "$BANCO"
fi
chmod 600 "$BANCO" 2>/dev/null || true
estado_do_banco "$BANCO"
(( QTD_EMPRESAS == 0 && QTD_ATIVOS == 0 )) || falhar "O banco novo não ficou vazio — confira a mensagem acima." \
    "A cópia da demonstração está em ${ARQUIVO:-$BACKUP_DIR}."
ok "Banco novo e vazio no mesmo lugar: $BANCO"

if [[ -d "$MIDIA" ]] && [[ -n "$(ls -A "$MIDIA" 2>/dev/null)" ]]; then
    if [[ -n "$ARQUIVO" ]]; then
        mv "$MIDIA" "$ARQUIVO/media"
        ok "Arquivos enviados na demonstração guardados em $ARQUIVO/media"
    else
        DESCARTE="$BACKUP_DIR/media_antes_do_uso_real_$(date +%Y-%m-%d_%H%M%S)"
        mv "$MIDIA" "$DESCARTE"
        ok "Arquivos que estavam na pasta de uploads guardados em $DESCARTE"
    fi
fi
mkdir -p "$MIDIA"
ok "Pasta de uploads vazia: $MIDIA"

if [[ -n "$ARQUIVO" ]]; then
    DEMO_MODE_ANTES="$(valor_env DEMO_MODE "(sem a linha)")"
    USO_REAL_ANTES="$(valor_env NEXBUY_USO_REAL "(sem a linha)")"
    {
        printf '%s\n' "NEXBUY — demonstração guardada em $(date '+%d/%m/%Y %H:%M') pelo ativar_uso_real.sh"
        printf '%s\n' ""
        printf '%s\n' "db.sqlite3  banco da demonstração (empresa fictícia, usuários demo_* e lançamentos)"
        printf '%s\n' "media/      logo e arquivos enviados na demonstração (se havia)"
        printf '%s\n' ""
        printf '%s\n' "Antes da troca, o .env tinha: DEMO_MODE=$DEMO_MODE_ANTES e NEXBUY_USO_REAL=$USO_REAL_ANTES."
        printf '%s\n' "Para VOLTAR à demonstração (só enquanto ninguém fez o Primeiro Acesso), no console:"
        printf '%s\n' "    cd ~/nexbuy"
        printf '%s\n' "    bash deploy/pythonanywhere/voltar_demonstracao.sh $ARQUIVO"
        printf '%s\n' "O script confere tudo antes de mexer e recusa se o site já tiver dado real."
        printf '%s\n' "Guia: docs/PYTHONANYWHERE_USO_REAL.md, parte \"Voltar para a demonstração\"."
        printf '%s\n' "Esta pasta pode ser apagada quando o uso real estiver conferido."
    } > "$ARQUIVO/LEIA-ME.txt"
    find "$ARQUIVO" -type d -exec chmod 700 {} + 2>/dev/null || true
    find "$ARQUIVO" -type f -exec chmod 600 {} + 2>/dev/null || true
fi

# ---------------------------------------------------------------------------
etapa "7/8" "Configuração de uso real (.env)"
# ---------------------------------------------------------------------------
TOKEN_NOVO="$(gerar_token)"
gravar_no_env DEMO_MODE=False DEMO_EXIBIR_SENHA=False NEXBUY_USO_REAL=True \
    "INITIAL_SETUP_TOKEN=$TOKEN_NOVO" BACKUP_DIARIO=True "BACKUP_DIARIO_DIR=$BACKUP_DIR" \
    BACKUP_DIARIO_MANTER=14
TOKEN_GRAVADO=1
ok ".env atualizado: DEMO_MODE=False, DEMO_EXIBIR_SENHA=False, NEXBUY_USO_REAL=True,"
ok "token novo do Primeiro Acesso e backup diário automático (14 cópias em $BACKUP_DIR)."
info "O resto do .env (chave secreta, endereço do site, Admin técnico) ficou igual."

# ---------------------------------------------------------------------------
etapa "8/8" "Estáticos, conferência e recarga do site"
# ---------------------------------------------------------------------------
manage collectstatic --noinput -v 0 || falhar "O collectstatic falhou (veja acima)." \
    "O banco já está vazio e o .env já está em uso real. Corrija e rode de novo este mesmo comando" \
    "(bash deploy/pythonanywhere/ativar_uso_real.sh): ele termina a troca sem apagar nada. O token" \
    "está no quadro abaixo; se o quadro não aparecer, gere outro com --novo-token."
ok "Arquivos estáticos atualizados em $ESTATICOS."
info "Conferência de segurança (check --deploy) — só informativa:"
if ! manage check --deploy; then
    aviso "O check --deploy apontou problema (acima). O script continua; confira depois."
fi
explicar_aviso_w008
recarregar_e_conferir "/accounts/login/=200" "/primeiro-acesso/=200" "/demo/apresentacao/=404"
mostrar_uso_do_disco

TOKEN_GRAVADO=0
mostrar_token_primeiro_acesso "$TOKEN_NOVO"
TOKEN_NOVO=""
printf '%s\n' " Daqui para a frente:"
printf '%s\n' "  - A CADA 3 SEMANAS: aba Web > 'Run until 1 month from today' (com 1 mês sem"
printf '%s\n' "    esse clique o site sai do ar; nada é apagado e o mesmo botão o traz de volta)."
printf '%s\n' "  - O site faz sozinho um backup por dia (no primeiro acesso do dia) em"
printf '%s\n' "    ~/nexbuy_backups/ (diario_AAAA-MM-DD.sqlite3). Toda semana, baixe o mais"
printf '%s\n' "    recente para o computador: aba Files > nexbuy_backups > ícone de download."
printf '%s\n' "  - Versão nova do sistema: bash deploy/pythonanywhere/atualizar.sh"
printf '%s\n' "  - A cópia da demonstração ficou em ${ARQUIVO:-(nada a guardar)}"
printf '%s\n' "=========================================================================="
