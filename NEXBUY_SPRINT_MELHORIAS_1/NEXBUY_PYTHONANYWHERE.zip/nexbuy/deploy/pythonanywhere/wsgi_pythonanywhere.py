# NEXBUY_WSGI_PYTHONANYWHERE — arquivo WSGI da demonstração no PythonAnywhere.
#
# O deploy/pythonanywhere/preparar.sh grava este conteúdo SOZINHO no arquivo
# WSGI do seu web app (/var/www/<seu-usuario>_pythonanywhere_com_wsgi.py),
# trocando SEU_USUARIO pelo seu usuário. Só use este modelo à mão se o
# script não conseguiu (plano B):
#
#   1. Aba Web > seção "Code" > clique no link do "WSGI configuration file".
#   2. Apague TODO o conteúdo do editor e cole este arquivo inteiro.
#   3. Troque SEU_USUARIO (linha CAMINHO_DO_PROJETO) pelo seu usuário do
#      PythonAnywhere — só letras minúsculas, sem os sinais < >.
#   4. Clique em "Save" e depois no botão "Reload" (canto superior direito).
#
# Nada de senha, SECRET_KEY ou token aqui: tudo isso fica no arquivo
# /home/SEU_USUARIO/nexbuy/.env, que o próprio nexbuy/settings.py já lê.
import os
import sys

CAMINHO_DO_PROJETO = "/home/SEU_USUARIO/nexbuy"

if CAMINHO_DO_PROJETO not in sys.path:
    sys.path.insert(0, CAMINHO_DO_PROJETO)

# Sempre o settings PRINCIPAL (nunca nexbuy.settings_demo, que só aceita
# 127.0.0.1/localhost e daria "400 Bad Request" na internet). O modo
# demonstração vem de DEMO_MODE=True no .env.
os.environ["DJANGO_SETTINGS_MODULE"] = "nexbuy.settings"

from django.core.wsgi import get_wsgi_application  # noqa: E402

application = get_wsgi_application()
