#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# NEXBUY — caminhos e funções compartilhados pelos scripts do PythonAnywhere
# (preparar.sh, atualizar.sh, backup.sh, restaurar.sh, ativar_uso_real.sh e
# os nomes antigos atualizar_demo.sh/backup_demo.sh). NÃO execute este
# arquivo direto: ele é carregado (source) pelos outros.
#
# Layout no PythonAnywhere (conta grátis, usuário <u>):
#   /home/<u>/nexbuy/                    código (unzip do NEXBUY_PYTHONANYWHERE.zip)
#   /home/<u>/nexbuy/.env                variáveis (lidas pelo settings.py; 600)
#   /home/<u>/.virtualenvs/nexbuy/       ambiente Python
#   /home/<u>/nexbuy_dados/db.sqlite3    banco (FORA da pasta do código)
#   /home/<u>/nexbuy_dados/media/        uploads (logo da empresa)
#   /home/<u>/nexbuy_static/             collectstatic (aba Web > Static files)
#   /home/<u>/nexbuy_backups/            cópias do banco:
#       nexbuy_AAAA-MM-DD_HHMM.sqlite3       feitas pelo backup.sh (retenção própria)
#       diario_AAAA-MM-DD.sqlite3            backup diário automático do próprio site
#                                            (uso real: BACKUP_DIARIO=True no .env)
#       demonstracao_final_AAAA-MM-DD_HHMM/  banco + arquivos da demonstração,
#                                            guardados pelo ativar_uso_real.sh
#   /var/www/<u>_pythonanywhere_com_wsgi.py   arquivo WSGI do web app
#
# Uso real: o .env tem NEXBUY_USO_REAL=True (gravado pelo ativar_uso_real.sh).
# Nesse modo NENHUM script roda o cenário fictício (seed_demo) nem mexe em
# senha de demonstração (definir_senha_demo). E, mesmo sem o marcador, o
# seed nunca roda num banco com empresa de verdade (CNPJ fora do prefixo
# 98765432 da demonstração).
#
# Para testar fora do PythonAnywhere (ex.: Git Bash no Windows):
#   NEXBUY_HOME      substitui o $HOME (use C:/... no Windows, nunca /c/...)
#   NEXBUY_PYTHON    Python usado para criar o virtualenv
#   NEXBUY_VENV      caminho do virtualenv (padrão: $NEXBUY_HOME/.virtualenvs/nexbuy)
#   NEXBUY_WSGI_DIR  pasta dos arquivos WSGI (padrão: /var/www)
#   PA_USUARIO       usuário do PythonAnywhere (padrão: $USER)
#   PA_DOMINIO       endereço do site (padrão: <usuario>.pythonanywhere.com)
#   NEXBUY_PULAR_PIP=1  SÓ PARA TESTES: não roda o "pip install" (o virtualenv
#                    do projeto já tem as dependências). Nunca use no servidor.
# ---------------------------------------------------------------------------

# O .env da pasta do código é a ÚNICA fonte de configuração — igual para o
# site e para o console. Uma variável destas exportada no terminal passaria
# na frente do .env (o load_dotenv não sobrescreve), então sai do ambiente
# deste script. ALLOW_SEED_IN_PRODUCTION entra só no comando do seed.
unset DJANGO_SETTINGS_MODULE SECRET_KEY DEBUG DEMO_MODE DEMO_EXIBIR_SENHA ALLOWED_HOSTS \
    CSRF_TRUSTED_ORIGINS SECURE_SSL_REDIRECT USA_PROXY_HTTPS SQLITE_WAL SQLITE_PATH MEDIA_ROOT \
    STATIC_ROOT ADMIN_URL INITIAL_SETUP_TOKEN ALLOW_SEED_IN_PRODUCTION DB_ENGINE LOG_LEVEL FEATURE_DDA \
    NEXBUY_USO_REAL BACKUP_DIARIO BACKUP_DIARIO_DIR BACKUP_DIARIO_MANTER
export DJANGO_SETTINGS_MODULE="nexbuy.settings"
export PYTHONIOENCODING="${PYTHONIOENCODING:-utf-8}"
export PYTHONUNBUFFERED=1

if [[ -t 1 ]]; then
    _COR_AZUL=$'\033[1;34m'; _COR_VERDE=$'\033[1;32m'; _COR_AMARELA=$'\033[1;33m'
    _COR_VERMELHA=$'\033[1;31m'; _COR_NEGRITO=$'\033[1m'; _COR_FIM=$'\033[0m'
else
    _COR_AZUL=""; _COR_VERDE=""; _COR_AMARELA=""; _COR_VERMELHA=""; _COR_NEGRITO=""; _COR_FIM=""
fi

etapa()  { printf '\n%s[%s]%s %s%s%s\n' "$_COR_AZUL" "$1" "$_COR_FIM" "$_COR_NEGRITO" "$2" "$_COR_FIM"; }
info()   { printf '    %s\n' "$*"; }
ok()     { printf '    %s[ OK ]%s %s\n' "$_COR_VERDE" "$_COR_FIM" "$*"; }
aviso()  { printf '    %s[AVISO]%s %s\n' "$_COR_AMARELA" "$_COR_FIM" "$*" >&2; }
falhar() {
    printf '\n%s[ERRO]%s %s\n' "$_COR_VERMELHA" "$_COR_FIM" "$1" >&2
    shift
    local linha
    for linha in "$@"; do
        printf '       %s\n' "$linha" >&2
    done
    exit 1
}

# --- Caminhos ----------------------------------------------------------------
# SCRIPT_DIR vem de quem carregou este arquivo.
APP_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
HOME_BASE="${NEXBUY_HOME:-$HOME}"
HOME_BASE="${HOME_BASE%/}"
PA_USUARIO="${PA_USUARIO:-${USER:-$(id -un 2>/dev/null || echo usuario)}}"
PA_USUARIO="$(printf '%s' "$PA_USUARIO" | tr '[:upper:]' '[:lower:]')"
ENV_FILE="$APP_DIR/.env"
VENV_DIR="${NEXBUY_VENV:-$HOME_BASE/.virtualenvs/nexbuy}"
WSGI_DIR="${NEXBUY_WSGI_DIR:-/var/www}"
WSGI_ORIGINAL_BACKUP="$HOME_BASE/nexbuy_wsgi_original.py"
BACKUP_DIR="$HOME_BASE/nexbuy_backups"
DADOS_DIR_PADRAO="$HOME_BASE/nexbuy_dados"
STATIC_DIR_PADRAO="$HOME_BASE/nexbuy_static"
REQUISITOS="$APP_DIR/deploy/pythonanywhere/requirements-pythonanywhere.txt"
VENV_PY=""

# Cache do .env — só para gastar menos CPU (cada leitura pelo python-dotenv é
# um processo Python; o console grátis tem 100 s de CPU por dia).
# carregar_env lê TODAS as variáveis numa chamada só; valor_env usa o cache
# somente enquanto o arquivo tiver EXATAMENTE o conteúdo que foi lido —
# qualquer mudança (deste script ou de fora dele) volta à leitura direta.
declare -gA _ENV_CACHE=()
_ENV_CACHE_ARQUIVO=""
_ENV_CACHE_CONTEUDO=""

carregar_env() {
    local saida linha chave valor
    _ENV_CACHE=()
    _ENV_CACHE_ARQUIVO=""
    _ENV_CACHE_CONTEUDO=""
    if [[ ! -f "$ENV_FILE" ]] || ! localizar_venv_python; then
        return 0
    fi
    saida="$("$VENV_PY" - "$ENV_FILE" <<'PY'
import sys
try:
    from dotenv import dotenv_values
except ImportError:
    sys.exit(2)
for chave, valor in dotenv_values(sys.argv[1]).items():
    if valor is not None:
        valor = valor.replace("\\", "\\\\").replace("\t", "\\t").replace("\r", "\\r").replace("\n", "\\n")
        sys.stdout.write(f"{chave}\t{valor}\n")
PY
)" || return 0
    while IFS= read -r linha; do
        linha="${linha%$'\r'}"
        if [[ "$linha" != *$'\t'* ]]; then
            continue
        fi
        chave="${linha%%$'\t'*}"
        printf -v valor '%b' "${linha#*$'\t'}"
        _ENV_CACHE[$chave]="$valor"
    done <<< "$saida"
    _ENV_CACHE_CONTEUDO="$(<"$ENV_FILE")"
    _ENV_CACHE_ARQUIVO="$ENV_FILE"
}

# O cache vale para o .env atual, com o mesmo conteúdo de quando foi lido?
env_em_cache() {
    [[ -n "$_ENV_CACHE_ARQUIVO" && "$_ENV_CACHE_ARQUIVO" == "$ENV_FILE" && -f "$ENV_FILE" ]] || return 1
    [[ "$(<"$ENV_FILE")" == "$_ENV_CACHE_CONTEUDO" ]]
}

# Lê UMA variável do .env sem executar o arquivo. Sem .env, sem a variável
# ou com valor vazio: o padrão.
#
# Com o virtualenv pronto, quem lê é o próprio python-dotenv (dotenv_values)
# — o MESMO leitor que o settings.py usa. Assim "export DEBUG=True",
# "DEBUG = True" e "DEBUG=True # comentário" valem aqui exatamente como
# valem para o site (um grep simples não via esses formatos, e a trava de
# DEBUG deixava passar). Antes do virtualenv existir (etapa 1 do
# preparar.sh), um leitor em bash que entende os mesmos formatos comuns.
valor_env() {
    local nome="$1" padrao="${2:-}" valor="" codigo=0
    if [[ ! -f "$ENV_FILE" ]]; then
        printf '%s' "$padrao"
        return 0
    fi
    if env_em_cache; then
        if [[ -n "${_ENV_CACHE[$nome]+x}" ]]; then
            printf '%s' "${_ENV_CACHE[$nome]:-$padrao}"
        else
            printf '%s' "$padrao"
        fi
        return 0
    fi
    if localizar_venv_python; then
        valor="$("$VENV_PY" - "$ENV_FILE" "$nome" <<'PY'
import sys
try:
    from dotenv import dotenv_values
except ImportError:
    sys.exit(2)
valor = dotenv_values(sys.argv[1]).get(sys.argv[2])
if valor is None:
    sys.exit(1)
sys.stdout.write(valor)
PY
)" || codigo=$?
        case "$codigo" in
            0) printf '%s' "${valor:-$padrao}"; return 0 ;;
            1) printf '%s' "$padrao"; return 0 ;;
        esac
        # 2 (python-dotenv ainda não instalado) ou outro erro: leitor em bash.
    fi
    valor_env_bash "$nome" "$padrao"
}

# Leitor em bash (sem o virtualenv): última ocorrência vence; aceita
# "export ", espaços em volta do "=", aspas simples/duplas e comentário
# " # ..." no fim de valor sem aspas.
valor_env_bash() {
    local nome="$1" padrao="${2:-}" linha valor
    linha="$(grep -E "^[[:space:]]*(export[[:space:]]+)?${nome}[[:space:]]*=" "$ENV_FILE" 2>/dev/null | tail -n 1 || true)"
    if [[ -z "$linha" ]]; then
        printf '%s' "$padrao"
        return 0
    fi
    valor="${linha#*=}"
    valor="${valor%$'\r'}"
    valor="${valor#"${valor%%[![:space:]]*}"}"
    if [[ "$valor" == \"* ]]; then
        valor="${valor#\"}"; valor="${valor%%\"*}"
    elif [[ "$valor" == \'* ]]; then
        valor="${valor#\'}"; valor="${valor%%\'*}"
    else
        valor="${valor%%[[:space:]]#*}"
        valor="${valor%"${valor##*[![:space:]]}"}"
    fi
    printf '%s' "${valor:-$padrao}"
}

# Mesma regra do env_bool do settings.py: 1/true/sim/yes (sem diferenciar
# maiúsculas) = ligado; qualquer outra coisa = desligado.
env_ligado() {
    local valor
    valor="$(valor_env "$1" | tr '[:upper:]' '[:lower:]')"
    valor="${valor//[[:space:]]/}"
    [[ "$valor" == "1" || "$valor" == "true" || "$valor" == "sim" || "$valor" == "yes" ]]
}

# Nome do arquivo WSGI que o PythonAnywhere cria para um domínio: os pontos
# viram "_" (help.pythonanywhere.com/pages/DeployExistingDjangoProject/).
caminho_wsgi() {
    local dominio="$1"
    printf '%s/%s_wsgi.py' "$WSGI_DIR" "${dominio//./_}"
}

# Define DOMINIO e WSGI_FILE. Ordem: PA_DOMINIO > --eu > domínio já gravado
# no .env > <usuario>.pythonanywhere.com (com detecção de conta EU pelo nome
# do arquivo WSGI — nome deduzido pela regra oficial, sem página que o cite).
definir_dominio() {
    local regiao="${1:-}" do_env
    if [[ -n "${PA_DOMINIO:-}" ]]; then
        DOMINIO="$PA_DOMINIO"
    elif [[ "$regiao" == "eu" ]]; then
        DOMINIO="$PA_USUARIO.eu.pythonanywhere.com"
    else
        do_env="$(valor_env ALLOWED_HOSTS)"
        do_env="${do_env%%,*}"
        if [[ -n "$do_env" ]]; then
            DOMINIO="$do_env"
        else
            DOMINIO="$PA_USUARIO.pythonanywhere.com"
            if [[ ! -f "$(caminho_wsgi "$DOMINIO")" && -f "$(caminho_wsgi "$PA_USUARIO.eu.pythonanywhere.com")" ]]; then
                DOMINIO="$PA_USUARIO.eu.pythonanywhere.com"
                aviso "Conta EU detectada pelo arquivo WSGI: usando $DOMINIO."
            fi
        fi
    fi
    DOMINIO="$(printf '%s' "$DOMINIO" | tr '[:upper:]' '[:lower:]')"
    DOMINIO="${DOMINIO#https://}"; DOMINIO="${DOMINIO#http://}"; DOMINIO="${DOMINIO%/}"
    [[ "$DOMINIO" =~ ^[a-z0-9.-]+$ ]] || falhar "Endereço do site inválido: '$DOMINIO'." \
        "Use só o domínio, ex.: PA_DOMINIO=seuusuario.pythonanywhere.com"
    WSGI_FILE="$(caminho_wsgi "$DOMINIO")"
}

# Grava no .env o endereço do site (ALLOWED_HOSTS e CSRF_TRUSTED_ORIGINS),
# sem tocar nas outras linhas (a SECRET_KEY continua a mesma). Usado quando
# o endereço foi escolhido de propósito (--eu ou PA_DOMINIO) e o .env tinha
# outro — ex.: o script rodou antes como conta US numa conta EU.
gravar_dominio_no_env() {
    local temporario="$ENV_FILE.novo.$$"
    (
        umask 077
        grep -vE '^[[:space:]]*(export[[:space:]]+)?(ALLOWED_HOSTS|CSRF_TRUSTED_ORIGINS)[[:space:]]*=' "$ENV_FILE" > "$temporario" || true
        printf 'ALLOWED_HOSTS=%s\nCSRF_TRUSTED_ORIGINS=https://%s\n' "$DOMINIO" "$DOMINIO" >> "$temporario"
    )
    chmod 600 "$temporario"
    mv -f "$temporario" "$ENV_FILE"
    carregar_env
}

# O "Force HTTPS" da aba Web está ligado? Com ele, http:// responde 301 para
# https:// no balanceador do PythonAnywhere (a requisição nem chega ao
# Django, que tem SECURE_SSL_REDIRECT=False). Sem ele, a tela de login abre
# em http:// e a senha viajaria sem criptografia.
conferir_force_https() {
    local resultado codigo destino
    if ! command -v curl >/dev/null 2>&1; then
        info "Sem curl: confira você mesmo que http://$DOMINIO/ vai para https://."
        return 0
    fi
    resultado="$(curl -s -o /dev/null --max-time 20 -w '%{http_code} %{redirect_url}' "http://$DOMINIO/accounts/login/" 2>/dev/null || true)"
    codigo="${resultado%% *}"
    destino="${resultado#* }"
    if [[ "$codigo" =~ ^30[1278]$ && "$destino" == https://* ]]; then
        ok "Force HTTPS ligado: http://$DOMINIO/ redireciona para https://."
        return 0
    fi
    aviso "http://$DOMINIO/ NÃO redireciona para https:// (resposta '${codigo:-nenhuma}')."
    aviso "Ligue a chave 'Force HTTPS' na aba Web (seção Security) e clique em Reload — sem ela a"
    aviso "senha pode trafegar sem criptografia quando alguém digita o endereço com http://."
    return 1
}

# Acha o Python do virtualenv (bin/ no Linux; Scripts/ no Windows, só para testes).
localizar_venv_python() {
    if [[ -x "$VENV_DIR/bin/python" ]]; then
        VENV_PY="$VENV_DIR/bin/python"
    elif [[ -x "$VENV_DIR/Scripts/python.exe" ]]; then
        VENV_PY="$VENV_DIR/Scripts/python.exe"
    else
        VENV_PY=""
        return 1
    fi
    return 0
}

exigir_instalacao() {
    [[ -f "$APP_DIR/manage.py" ]] || falhar "Não achei $APP_DIR/manage.py." \
        "Descompacte o NEXBUY_PYTHONANYWHERE.zip na sua pasta (cd ~ ; unzip -o NEXBUY_PYTHONANYWHERE.zip)."
    if [[ ! -f "$ENV_FILE" && -f "$HOME_BASE/nexbuy_antigo/.env" ]]; then
        # Atualização (parte 9 do guia) em que faltou o "cp" do .env: a
        # configuração está na pasta antiga — nunca mandar criar outra.
        falhar "Não achei o $ENV_FILE: faltou trazer o .env da pasta antiga." \
            "Cole estas duas linhas:" \
            "cp ~/nexbuy_antigo/.env ~/nexbuy/.env" \
            "chmod 600 ~/nexbuy/.env" \
            "e rode este script de novo. Nada foi alterado."
    fi
    [[ -f "$ENV_FILE" ]] || falhar "Não achei $ENV_FILE." \
        "Rode primeiro: bash deploy/pythonanywhere/preparar.sh"
    localizar_venv_python || falhar "Não achei o virtualenv em $VENV_DIR." \
        "Rode primeiro: bash deploy/pythonanywhere/preparar.sh"
    carregar_env
}

# manage.py com o settings principal e o .env da pasta do código.
manage() {
    ( cd "$APP_DIR" && "$VENV_PY" manage.py "$@" )
}

# Dos 6 usuários de login, os que estão SEM senha (depois do --bloquear),
# separados por vírgula ("" = nenhum). Para o script se o Django falhar.
listar_demo_sem_senha() {
    local saida linha
    saida="$( { manage shell -c "from core.senha_demo import usuarios_demo_sem_senha; print('LISTA=' + ','.join(u.username for u in usuarios_demo_sem_senha()))" 2>&1 || true; } )"
    linha="$(printf '%s\n' "$saida" | grep '^LISTA=' | tail -n 1 | tr -d '\r' || true)"
    if [[ -z "$linha" ]]; then
        printf '%s\n' "$saida" >&2
        falhar "Não consegui consultar as senhas dos usuários de demonstração (mensagem acima)." \
            "Rode o script de novo; se repetir, veja o Error log na aba Web."
    fi
    printf '%s' "${linha#LISTA=}"
}

# O seed é bloqueado com DEBUG=False; a autorização vale SÓ para este
# comando (nunca vai para o .env, que também vale para o site).
#
# Última barreira (os scripts já não chamam o seed nesses casos): nunca em
# uso real, nunca num banco com empresa de verdade e nunca num banco em que
# o Primeiro Acesso já foi feito — com ou sem o marcador.
manage_seed() {
    if uso_real_no_env; then
        falhar "Recusado: este site está em USO REAL (NEXBUY_USO_REAL=True no .env)." \
            "O cenário fictício nunca roda aqui. Nada foi alterado."
    fi
    estado_do_banco
    if (( QTD_EMPRESAS_REAIS > 0 )); then
        falhar "Recusado: o banco tem empresa de verdade ($NOMES_EMPRESAS_REAIS)." \
            "O cenário fictício nunca roda num banco com dados reais. Nada foi alterado."
    fi
    if (( INSTALACAO_CONCLUIDA == 1 )); then
        falhar "Recusado: o Primeiro Acesso já foi feito neste banco (ele é de USO REAL)." \
            "O cenário fictício nunca roda num banco com dados reais. Nada foi alterado."
    fi
    ( export ALLOW_SEED_IN_PRODUCTION=True; cd "$APP_DIR" && "$VENV_PY" manage.py "$@" )
}

# Recarrega o site: mexer no arquivo WSGI faz o PythonAnywhere recarregar o
# web app (mesmo efeito do botão Reload da aba Web).
recarregar_site() {
    if [[ -f "$WSGI_FILE" ]]; then
        touch "$WSGI_FILE"
        ok "Site recarregado (touch em $WSGI_FILE)."
        return 0
    fi
    aviso "Arquivo WSGI $WSGI_FILE não encontrado — clique em Reload na aba Web."
    return 1
}

# Pede "SIM" antes de apagar o cenário (a não ser com --sim).
confirmar_apagar_cenario() {
    local ja_confirmado="$1" resposta=""
    printf '\n%s' "$_COR_VERMELHA"
    printf '%s\n' "  ATENÇÃO: renovar o cenário APAGA as compras, provisões, aprovações,"
    printf '%s\n' "  lançamentos financeiros e a auditoria da empresa de demonstração —"
    printf '%s\n' "  inclusive TUDO o que a cliente lançou nela — e recria a história"
    printf '%s\n' "  fictícia com datas a partir de hoje. As senhas dos usuários são MANTIDAS."
    printf '%s\n' "  Antes, uma cópia do banco vai para ~/nexbuy_backups/."
    printf '%s\n' "$_COR_FIM"
    if [[ "$ja_confirmado" == "1" ]]; then
        info "Confirmado por --sim."
        return 0
    fi
    [[ -t 0 ]] || falhar "Sem terminal para confirmar." "Rode no console Bash ou acrescente --sim."
    read -r -p "    Para continuar, digite SIM (em maiúsculas) e tecle Enter: " resposta
    [[ "$resposta" == "SIM" ]] || falhar "Cancelado: nada foi apagado." "Para renovar, rode de novo e digite SIM."
}

# Pede "SIM" antes de SUBSTITUIR senhas que já foram definidas (a não ser
# com --sim): quem já recebeu a senha antiga deixa de conseguir entrar.
confirmar_troca_de_senha() {
    local ja_confirmado="$1" resposta=""
    printf '\n%s' "$_COR_AMARELA"
    printf '%s\n' "  ATENÇÃO: as senhas ATUAIS dos usuários de demonstração serão SUBSTITUÍDAS."
    printf '%s\n' "  A senha que você já mandou à cliente deixa de valer — mande a nova depois."
    printf '%s\n' "$_COR_FIM"
    if [[ "$ja_confirmado" == "1" ]]; then
        info "Confirmado por --sim."
        return 0
    fi
    [[ -t 0 ]] || falhar "Sem terminal para confirmar a troca das senhas." "Rode no console Bash ou acrescente --sim."
    read -r -p "    Para trocar as senhas, digite SIM (em maiúsculas) e tecle Enter: " resposta
    [[ "$resposta" == "SIM" ]] || falhar "Cancelado: as senhas continuam as mesmas." \
        "Para trocar, rode de novo com --trocar-senha e digite SIM."
}

# Uso do disco (cota de 512 MB no plano grátis) — mesma soma da ajuda do
# PythonAnywhere (pages/DiskQuota/); /tmp só conta no servidor de verdade.
mostrar_uso_do_disco() {
    local bytes megas alvos=()
    local nullglob_antes
    nullglob_antes="$(shopt -p nullglob || true)"
    shopt -s nullglob
    alvos=("$HOME_BASE"/.[!.]* "$HOME_BASE"/*)
    if [[ -z "${NEXBUY_HOME:-}" && -d /tmp ]]; then
        alvos+=(/tmp)
    fi
    eval "$nullglob_antes"
    bytes="$( { du -s -B 1 "${alvos[@]}" 2>/dev/null || true; } | awk '{s+=$1} END {print s+0}')"
    megas=$(( ${bytes:-0} / 1024 / 1024 ))
    if (( megas > 400 )); then
        aviso "Disco: ${megas} MB usados de 512 MB. Libere espaço: rm -rf ~/.cache/pip ; apague ~/NEXBUY_PYTHONANYWHERE.zip e backups antigos em ~/nexbuy_backups/."
    else
        ok "Disco: ${megas} MB usados de 512 MB."
    fi
}

# ===========================================================================
# Uso real, backup e banco (ativar_uso_real.sh, atualizar.sh, preparar.sh,
# backup.sh, restaurar.sh)
# ===========================================================================

# Uso real = NEXBUY_USO_REAL ligado no .env (mesma regra do env_bool do
# settings.py). Quem grava o marcador é o ativar_uso_real.sh.
uso_real_no_env() {
    env_ligado NEXBUY_USO_REAL
}

# Mostra a ajuda do cabeçalho de um script (o bloco entre as linhas "# ====").
mostrar_ajuda() {
    awk 'NR > 2 && /^# =========/ {exit} NR > 2 {sub(/^# ?/, ""); print}' "$1"
}

# Um Python para ler/copiar o banco: o do virtualenv; sem ele, o
# NEXBUY_PYTHON ou o do sistema.
python_dos_scripts() {
    local candidato
    if localizar_venv_python; then
        printf '%s' "$VENV_PY"
        return 0
    fi
    for candidato in "${NEXBUY_PYTHON:-}" python3.13 python3.12 python3; do
        if [[ -n "$candidato" ]] && command -v "$candidato" >/dev/null 2>&1; then
            printf '%s' "$candidato"
            return 0
        fi
    done
    return 1
}

# Dependências do requirements-pythonanywhere.txt no virtualenv.
instalar_dependencias() {
    if [[ "${NEXBUY_PULAR_PIP:-}" == "1" ]]; then
        aviso "Instalação das dependências PULADA (NEXBUY_PULAR_PIP=1 — só para testes fora do PythonAnywhere)."
        return 0
    fi
    "$VENV_PY" -m pip install --no-cache-dir --disable-pip-version-check -q -r "$REQUISITOS" || falhar \
        "A instalação das dependências falhou (veja a mensagem acima)." \
        "Causas comuns: disco cheio (rm -rf ~/.cache/pip) ou queda de conexão — rode o script de novo."
    rm -rf "$HOME_BASE/.cache/pip"
}

# Lê o banco SEM alterar nada (nem cria o arquivo) e define:
#   BANCO_SITUACAO         ausente | sem_tabelas | ok
#   QTD_EMPRESAS           todas as empresas
#   QTD_EMPRESAS_REAIS     empresas cujo CNPJ NÃO começa com 98765432 (o
#                          prefixo fictício da demonstração), ativas ou não
#   QTD_EMPRESAS_ATIVAS    empresas ativas
#   QTD_ATIVOS             usuários ativos
#   QTD_ATIVOS_FORA_DEMO   usuários ativos que não são de empresa fictícia
#   QTD_USUARIOS_DEMO      quantos dos 6 usuários demo_* existem
#   INSTALACAO_CONCLUIDA   1 = o Primeiro Acesso já foi concluído
#   NOMES_EMPRESAS_REAIS, NOMES_EMPRESAS_DEMO, NOMES_ATIVOS_FORA_DEMO (até 5,
#   para as mensagens)
# Sem argumento, lê o banco do SQLITE_PATH do .env.
estado_do_banco() {
    local caminho="${1:-}" python saida linha numero
    if [[ -z "$caminho" ]]; then
        caminho="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
    fi
    BANCO_SITUACAO=""; QTD_EMPRESAS=0; QTD_EMPRESAS_REAIS=0; QTD_EMPRESAS_ATIVAS=0
    QTD_ATIVOS=0; QTD_ATIVOS_FORA_DEMO=0; QTD_USUARIOS_DEMO=0; INSTALACAO_CONCLUIDA=0
    NOMES_EMPRESAS_REAIS=""; NOMES_EMPRESAS_DEMO=""; NOMES_ATIVOS_FORA_DEMO=""
    python="$(python_dos_scripts)" || falhar "Não achei um Python para ler o banco."
    saida="$("$python" - "$caminho" <<'PY'
import sqlite3
import sys
from pathlib import Path

PREFIXO_DEMO = "98765432"
USUARIOS_DEMO = {
    "demo_proprietario", "demo_gerente", "demo_financeiro",
    "demo_comprador", "demo_comprador2", "demo_comprador3",
}


def linha(chave, valor):
    sys.stdout.write(f"{chave}={valor}\n")


def so_digitos(texto):
    return "".join(c for c in str(texto or "") if c.isdigit())


def lista(nomes):
    nomes = [" ".join(str(nome or "").split()) for nome in nomes]
    texto = ", ".join(nomes[:5])
    return texto + (f" e mais {len(nomes) - 5}" if len(nomes) > 5 else "")


caminho = Path(sys.argv[1])
if not caminho.is_file():
    linha("SITUACAO", "ausente")
    sys.exit(0)
conexao = sqlite3.connect(str(caminho), timeout=30)
try:
    tabelas = {nome for (nome,) in conexao.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if not {"empresas_empresa", "usuarios_usuario"} <= tabelas:
        linha("SITUACAO", "sem_tabelas")
        sys.exit(0)
    empresas = conexao.execute("SELECT id, cnpj, ativo, nome FROM empresas_empresa").fetchall()
    usuarios = conexao.execute("SELECT username, is_active, empresa_id FROM usuarios_usuario").fetchall()
    concluido = 0
    if "core_estadoinstalacao" in tabelas:
        concluido = conexao.execute("SELECT COUNT(*) FROM core_estadoinstalacao WHERE concluido").fetchone()[0]
finally:
    conexao.close()

ids_demo = {ident for ident, cnpj, _ativo, _nome in empresas if so_digitos(cnpj).startswith(PREFIXO_DEMO)}
reais = [nome for ident, _cnpj, _ativo, nome in empresas if ident not in ids_demo]
demo = [nome for ident, _cnpj, _ativo, nome in empresas if ident in ids_demo]
ativos = [usuario for usuario in usuarios if usuario[1]]
fora = [usuario[0] for usuario in ativos if usuario[2] not in ids_demo]
linha("SITUACAO", "ok")
linha("EMPRESAS", len(empresas))
linha("EMPRESAS_REAIS", len(reais))
linha("EMPRESAS_ATIVAS", sum(1 for empresa in empresas if empresa[2]))
linha("ATIVOS", len(ativos))
linha("ATIVOS_FORA_DEMO", len(fora))
linha("USUARIOS_DEMO", sum(1 for usuario in usuarios if usuario[0] in USUARIOS_DEMO))
linha("CONCLUIDO", 1 if concluido else 0)
linha("NOMES_REAIS", lista(reais))
linha("NOMES_DEMO", lista(demo))
linha("NOMES_FORA_DEMO", lista(fora))
PY
)" || falhar "Não consegui ler o banco $caminho (mensagem acima)." \
        "Nada foi alterado. Rode o script de novo; se repetir, veja o Error log na aba Web."
    while IFS= read -r linha; do
        linha="${linha%$'\r'}"
        case "$linha" in
            SITUACAO=*) BANCO_SITUACAO="${linha#*=}" ;;
            EMPRESAS=*) QTD_EMPRESAS="${linha#*=}" ;;
            EMPRESAS_REAIS=*) QTD_EMPRESAS_REAIS="${linha#*=}" ;;
            EMPRESAS_ATIVAS=*) QTD_EMPRESAS_ATIVAS="${linha#*=}" ;;
            ATIVOS=*) QTD_ATIVOS="${linha#*=}" ;;
            ATIVOS_FORA_DEMO=*) QTD_ATIVOS_FORA_DEMO="${linha#*=}" ;;
            USUARIOS_DEMO=*) QTD_USUARIOS_DEMO="${linha#*=}" ;;
            CONCLUIDO=*) INSTALACAO_CONCLUIDA="${linha#*=}" ;;
            NOMES_REAIS=*) NOMES_EMPRESAS_REAIS="${linha#*=}" ;;
            NOMES_DEMO=*) NOMES_EMPRESAS_DEMO="${linha#*=}" ;;
            NOMES_FORA_DEMO=*) NOMES_ATIVOS_FORA_DEMO="${linha#*=}" ;;
        esac
    done <<< "$saida"
    [[ -n "$BANCO_SITUACAO" ]] || falhar "A leitura do banco $caminho saiu incompleta." \
        "Nada foi alterado. Rode o script de novo."
    for numero in "$QTD_EMPRESAS" "$QTD_EMPRESAS_REAIS" "$QTD_EMPRESAS_ATIVAS" "$QTD_ATIVOS" \
        "$QTD_ATIVOS_FORA_DEMO" "$QTD_USUARIOS_DEMO" "$INSTALACAO_CONCLUIDA"; do
        [[ "$numero" =~ ^[0-9]+$ ]] || falhar "A leitura do banco $caminho saiu incompleta." \
            "Nada foi alterado. Rode o script de novo."
    done
}

# Empresa de verdade (CNPJ fora do prefixo fictício), usuário ativo que não
# é da demonstração ou Primeiro Acesso já concluído: o que nunca pode ser
# apagado. O Primeiro Acesso conta sozinho: ele só existe no uso real (o
# seed_demo nunca o marca) e a empresa cadastrada nele pode ter qualquer
# CNPJ — até um com o prefixo da demonstração.
banco_tem_dados_reais() {
    (( QTD_EMPRESAS_REAIS > 0 || QTD_ATIVOS_FORA_DEMO > 0 || INSTALACAO_CONCLUIDA == 1 ))
}

# Ainda há algo do cenário fictício: empresa com o prefixo 98765432 ou um
# dos 6 usuários demo_*.
banco_tem_demonstracao() {
    (( QTD_EMPRESAS > QTD_EMPRESAS_REAIS || QTD_USUARIOS_DEMO > 0 ))
}

# Demonstração com empresa cadastrada DENTRO dela (ex.: a cliente usou o
# Assistente de Implantação da demonstração) e sem Primeiro Acesso: não é
# uso real nem demonstração pura. Só sai com ordem explícita
# (ativar_uso_real.sh --descartar-empresas-da-demonstracao).
banco_misto() {
    (( INSTALACAO_CONCLUIDA == 0 && QTD_EMPRESAS_REAIS > 0 )) && banco_tem_demonstracao
}

# O banco é de USO REAL (empresa de verdade ou Primeiro Acesso feito) e não
# é o misto acima: é aqui que o .env PRECISA ter o marcador.
banco_de_uso_real() {
    (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )) && ! banco_misto
}

# Texto curto do que faz o banco contar como real (para as mensagens).
resumo_dados_reais() {
    local texto=""
    if [[ -n "$NOMES_EMPRESAS_REAIS" ]]; then
        texto="empresa: $NOMES_EMPRESAS_REAIS"
    fi
    if (( INSTALACAO_CONCLUIDA == 1 )); then
        texto+="${texto:+; }Primeiro Acesso já feito"
    fi
    if [[ -n "$NOMES_ATIVOS_FORA_DEMO" ]]; then
        texto+="${texto:+; }usuários: $NOMES_ATIVOS_FORA_DEMO"
    fi
    printf '%s' "$texto"
}

# Aviso do banco misto, com o caminho para sair dele (atualizar.sh e
# preparar.sh; o ativar_uso_real.sh tem a mensagem própria).
aviso_banco_misto() {
    aviso "O banco MISTURA a demonstração ($NOMES_EMPRESAS_DEMO) com empresa cadastrada dentro dela"
    aviso "($NOMES_EMPRESAS_REAIS). Para passar ao uso real descartando TUDO isso (fica guardado numa cópia):"
    aviso "    bash deploy/pythonanywhere/ativar_uso_real.sh --descartar-empresas-da-demonstracao"
}

# .env sem o marcador num banco de USO REAL (ex.: um .env antigo da
# demonstração trazido por engano numa atualização): regrava as linhas do
# uso real — o resto do .env fica igual. Sem o marcador o .env não é o do
# uso real, então BACKUP_DIARIO=False ali não foi escolha de ninguém.
gravar_marcador_uso_real() {
    gravar_no_env NEXBUY_USO_REAL=True DEMO_MODE=False DEMO_EXIBIR_SENHA=False BACKUP_DIARIO=True
    aviso "O banco é de USO REAL ($(resumo_dados_reais)), mas o .env não tinha NEXBUY_USO_REAL=True"
    aviso "(ex.: .env antigo da demonstração). Corrigido no .env: NEXBUY_USO_REAL=True, DEMO_MODE=False,"
    aviso "DEMO_EXIBIR_SENHA=False e BACKUP_DIARIO=True — o resto (chave secreta, endereço) ficou igual."
}

# Primeiro Acesso ainda por fazer — mesma regra da tela
# (core/views_primeiro_acesso.py): nenhum usuário ativo, nenhuma empresa
# ativa e a instalação não concluída.
primeiro_acesso_pendente() {
    if [[ "$BANCO_SITUACAO" != "ok" ]]; then
        return 0
    fi
    (( QTD_ATIVOS == 0 && QTD_EMPRESAS_ATIVAS == 0 && INSTALACAO_CONCLUIDA == 0 ))
}

mostrar_estado_do_banco() {
    case "$BANCO_SITUACAO" in
        ausente) info "Banco: ainda não existe." ;;
        sem_tabelas) info "Banco: existe, mas sem as tabelas do NEXBUY (vazio)." ;;
        *)
            info "Empresas no banco: $QTD_EMPRESAS (fictícias da demonstração: $((QTD_EMPRESAS - QTD_EMPRESAS_REAIS)); reais: $QTD_EMPRESAS_REAIS)"
            if [[ -n "$NOMES_EMPRESAS_DEMO" ]]; then
                info "  fictícias: $NOMES_EMPRESAS_DEMO"
            fi
            if [[ -n "$NOMES_EMPRESAS_REAIS" ]]; then
                info "  reais: $NOMES_EMPRESAS_REAIS"
            fi
            info "Usuários ativos: $QTD_ATIVOS (de demonstração: $((QTD_ATIVOS - QTD_ATIVOS_FORA_DEMO)); outros: $QTD_ATIVOS_FORA_DEMO)"
            if [[ -n "$NOMES_ATIVOS_FORA_DEMO" ]]; then
                info "  outros: $NOMES_ATIVOS_FORA_DEMO"
            fi
            if (( INSTALACAO_CONCLUIDA == 1 )); then
                info "Primeiro Acesso: JÁ FEITO (banco de uso real)."
            fi
            ;;
    esac
}

# Grava NOME=VALOR no .env sem tocar no resto (SECRET_KEY, endereço do site,
# Admin técnico e as outras linhas ficam iguais): troca a linha que já existe
# — em qualquer formato que o python-dotenv leia ("export NOME=...",
# "NOME = ...") — ou acrescenta no fim. Arquivo temporário + mv, permissão
# 600. Os valores só passam por variáveis do bash: nunca viram argumento de
# outro programa (que apareceria na lista de processos).
gravar_no_env() {
    local temporario="$ENV_FILE.novo.$$" par nome linha
    local -A novos=()
    local ordem=()
    for par in "$@"; do
        nome="${par%%=*}"
        [[ "$nome" =~ ^[A-Z][A-Z0-9_]*$ ]] || falhar "Nome de variável inválido para o .env: '$nome'."
        if [[ -z "${novos[$nome]+x}" ]]; then
            ordem+=("$nome")
        fi
        novos[$nome]="${par#*=}"
    done
    if ! (
        umask 077
        local -A gravados=()
        : > "$temporario"
        if [[ -f "$ENV_FILE" ]]; then
            while IFS= read -r linha || [[ -n "$linha" ]]; do
                linha="${linha%$'\r'}"
                if [[ "$linha" =~ ^[[:space:]]*(export[[:space:]]+)?([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*= ]]; then
                    nome="${BASH_REMATCH[2]}"
                    if [[ -n "${novos[$nome]+x}" ]]; then
                        if [[ -z "${gravados[$nome]+x}" ]]; then
                            printf '%s=%s\n' "$nome" "${novos[$nome]}"
                            gravados[$nome]=1
                        fi
                        continue
                    fi
                fi
                printf '%s\n' "$linha"
            done < "$ENV_FILE" > "$temporario"
        fi
        for nome in "${ordem[@]}"; do
            if [[ -z "${gravados[$nome]+x}" ]]; then
                printf '%s=%s\n' "$nome" "${novos[$nome]}" >> "$temporario"
            fi
        done
    ); then
        rm -f "$temporario"
        falhar "Não consegui gravar o $ENV_FILE." "Nada foi alterado no .env."
    fi
    chmod 600 "$temporario"
    mv -f "$temporario" "$ENV_FILE"
    carregar_env
}

# Token novo para o Primeiro Acesso (secrets.token_urlsafe, 43 caracteres).
# Quem chama grava no .env e mostra UMA vez na tela — nenhum log o recebe.
gerar_token() {
    local token
    token="$("$VENV_PY" -c 'import secrets, sys; sys.stdout.write(secrets.token_urlsafe(32))')" || falhar \
        "Não consegui gerar o token (mensagem acima)." "Rode o script de novo."
    token="${token//[^A-Za-z0-9_-]/}"
    (( ${#token} >= 40 )) || falhar "O token gerado saiu incompleto." "Rode o script de novo."
    printf '%s' "$token"
}

# Quadro com o endereço e o token do Primeiro Acesso — a ÚNICA vez em que o
# token aparece (fica só no .env, com permissão 600).
mostrar_token_primeiro_acesso() {
    local token="$1"
    printf '\n%s%s%s\n' "$_COR_VERDE" "==========================================================================" "$_COR_FIM"
    printf '%s%s%s\n' "$_COR_NEGRITO" " PRIMEIRO ACESSO — copie AGORA (o token NÃO aparece de novo)" "$_COR_FIM"
    printf '%s\n' "=========================================================================="
    printf '  %s %s%s%s\n' "Endereço ..." "$_COR_NEGRITO" "https://$DOMINIO/primeiro-acesso/" "$_COR_FIM"
    printf '  %s %s%s%s\n' "Token ......" "$_COR_NEGRITO" "$token" "$_COR_FIM"
    printf '%s\n' "--------------------------------------------------------------------------"
    printf '%s\n' "  1. Entregue o endereço e o token SÓ à proprietária, por um canal privado"
    printf '%s\n' "     (de preferência pessoalmente ou por ligação; por mensagem, mande o"
    printf '%s\n' "     token separado do endereço e peça que ela apague depois de usar)."
    printf '%s\n' "  2. Ela abre o endereço, cola o token e cadastra a empresa, a Matriz e o"
    printf '%s\n' "     login dela (perfil Proprietário), com a senha que ela mesma escolher."
    printf '%s\n' "  3. Feito isso, o endereço fecha sozinho e o token não serve para mais nada."
    printf '%s\n' "  Perdeu o token antes do Primeiro Acesso? Gere outro com:"
    printf '%s\n' "     bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token"
    printf '%s\n' "  Copiou? Digite clear (e Enter) para limpar a tela."
    printf '%s\n' "=========================================================================="
}

# Backup diário mais recente (diario_AAAA-MM-DD.sqlite3, feito pelo próprio
# site no primeiro acesso de cada dia); avisa se está velho.
mostrar_backup_diario_recente() {
    local pasta="$1" ultimo nome ano mes dia dias=""
    local arquivos=()
    if [[ -d "$pasta" ]]; then
        mapfile -t arquivos < <(find "$pasta" -maxdepth 1 -type f -name 'diario_*.sqlite3' 2>/dev/null | sort)
    fi
    if (( ${#arquivos[@]} == 0 )); then
        info "Backup diário mais recente: nenhum ainda — o site faz o primeiro no primeiro acesso do dia."
        return 0
    fi
    ultimo="${arquivos[${#arquivos[@]} - 1]}"
    nome="$(basename "$ultimo" .sqlite3)"
    IFS=- read -r ano mes dia <<< "${nome#diario_}"
    if date -d "$ano-$mes-$dia" +%s >/dev/null 2>&1; then
        dias=$(( ( $(date -d "$(date +%Y-%m-%d)" +%s) - $(date -d "$ano-$mes-$dia" +%s) ) / 86400 ))
    fi
    ok "Backup diário mais recente: $dia/$mes/$ano ($(basename "$ultimo"); ${#arquivos[@]} cópia(s) diária(s) guardada(s))."
    if [[ -n "$dias" ]] && (( dias >= 3 )); then
        aviso "O último backup diário tem $dias dias. É normal se ninguém usou o site nesses dias;"
        aviso "se a equipe usou, veja o Error log na aba Web (procure por 'backup')."
    fi
}

# Caminho completo, começando na raiz — a mesma exigência do site
# (core/backup_diario.py usa os.path.isabs). "C:/..." só aparece nos testes
# fora do PythonAnywhere (Git Bash no Windows).
caminho_completo() {
    [[ "$1" == /* || "$1" =~ ^[A-Za-z]:[/\\] ]]
}

# Uso real: backup diário automático ligado no .env. Linha que falta é
# acrescentada com o padrão; BACKUP_DIARIO=False escrito de propósito só
# gera aviso (quem desligou decide). BACKUP_DIARIO_DIR sem o caminho
# completo (ex.: "~/nexbuy_backups", escrito à mão) o site RECUSA — e não
# faria backup nenhum: o valor é regravado com o caminho completo.
conferir_backup_diario() {
    local faltando=() pasta corrigida
    if [[ -z "$(valor_env BACKUP_DIARIO)" ]]; then
        faltando+=("BACKUP_DIARIO=True")
    fi
    if [[ -z "$(valor_env BACKUP_DIARIO_DIR)" ]]; then
        faltando+=("BACKUP_DIARIO_DIR=$BACKUP_DIR")
    fi
    if [[ -z "$(valor_env BACKUP_DIARIO_MANTER)" ]]; then
        faltando+=("BACKUP_DIARIO_MANTER=14")
    fi
    if (( ${#faltando[@]} > 0 )); then
        gravar_no_env "${faltando[@]}"
        ok "Backup diário configurado no .env: ${faltando[*]}"
    fi
    pasta="$(valor_env BACKUP_DIARIO_DIR "$BACKUP_DIR")"
    if ! caminho_completo "$pasta"; then
        corrigida="$BACKUP_DIR"
        if [[ "$pasta" == "~/"* ]]; then
            corrigida="$HOME_BASE/${pasta#\~/}"
        fi
        corrigida="${corrigida%/}"
        aviso "BACKUP_DIARIO_DIR=$pasta no .env não é um caminho completo: o site RECUSA esse valor e"
        aviso "NÃO estava fazendo o backup diário. Corrigido no .env: BACKUP_DIARIO_DIR=$corrigida"
        gravar_no_env "BACKUP_DIARIO_DIR=$corrigida"
        pasta="$corrigida"
    fi
    if env_ligado BACKUP_DIARIO; then
        ok "Backup diário automático LIGADO (guarda as $(valor_env BACKUP_DIARIO_MANTER 14) cópias mais recentes)."
    else
        aviso "O backup diário automático está DESLIGADO (BACKUP_DIARIO no .env)."
        aviso "Com dados reais, ligue: no arquivo ~/nexbuy/.env deixe a linha BACKUP_DIARIO=True e clique em Reload."
    fi
    mkdir -p "$pasta"
    chmod 700 "$pasta" 2>/dev/null || true
    mostrar_backup_diario_recente "$pasta"
}

# Uso real: Modo Demonstração desligado no .env. Com NEXBUY_USO_REAL=True o
# settings.py já o ignora; sem o marcador (banco real detectado pelos
# scripts), ele valeria — por isso o aviso.
conferir_modo_demonstracao_desligado() {
    if env_ligado DEMO_MODE || env_ligado DEMO_EXIBIR_SENHA; then
        aviso "O .env de um site em uso real está com DEMO_MODE ou DEMO_EXIBIR_SENHA ligado."
        aviso "No arquivo ~/nexbuy/.env deixe DEMO_MODE=False e DEMO_EXIBIR_SENHA=False e clique em Reload."
    else
        ok "Modo Demonstração desligado no .env."
    fi
}

# Uso real: o token do Primeiro Acesso só serve enquanto ninguém o usou.
# Concluído o Primeiro Acesso (já existe usuário ativo), o valor sai do .env.
# Usa o estado lido por estado_do_banco (chame antes).
conferir_token_primeiro_acesso() {
    if primeiro_acesso_pendente; then
        if [[ -n "$(valor_env INITIAL_SETUP_TOKEN)" ]]; then
            aviso "O Primeiro Acesso AINDA NÃO foi feito: https://$DOMINIO/primeiro-acesso/ continua aberto"
            aviso "com o token gravado no .env (o do quadro PRIMEIRO ACESSO do ativar_uso_real.sh)."
            aviso "Se esse quadro não apareceu, ou a proprietária ainda não recebeu o token, gere outro:"
            aviso "    bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token"
        else
            aviso "O Primeiro Acesso ainda não foi feito, mas o .env está sem token (o endereço fica fechado)."
            aviso "Gere um token: bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token"
        fi
        return 0
    fi
    if [[ -n "$(valor_env INITIAL_SETUP_TOKEN)" ]]; then
        gravar_no_env "INITIAL_SETUP_TOKEN="
        ok "Primeiro Acesso já feito: o token foi APAGADO do .env (não serve para mais nada)."
    else
        ok "Primeiro Acesso já feito (o .env está sem token, como deve ser)."
    fi
}

# Código HTTP de uma página do site (GET, sem seguir redirecionamento).
codigo_http() {
    curl -s -o /dev/null --max-time 20 -w '%{http_code}' "https://$DOMINIO$1" 2>/dev/null || true
}

# Depois do Reload: espera a tela de login responder 200 (até ~1 minuto) e
# diz se o Django recebe o X-Forwarded-Proto. Retorna 1 se não respondeu.
aguardar_site_no_ar() {
    local tentativa codigo="" cabecalhos=""
    info "Testando https://$DOMINIO/accounts/login/ (até 1 minuto)..."
    for tentativa in 1 2 3 4 5 6; do
        sleep 10
        cabecalhos="$(curl -sS -I --max-time 20 "https://$DOMINIO/accounts/login/" 2>/dev/null || true)"
        codigo="$(printf '%s\n' "$cabecalhos" | awk 'toupper($1) ~ /^HTTP/ {c=$2} END {print c}')"
        if [[ "$codigo" == "200" ]]; then
            break
        fi
        info "Tentativa $tentativa: resposta '${codigo:-nenhuma}'..."
    done
    if [[ "$codigo" != "200" ]]; then
        aviso "O site não respondeu 200 (última resposta: '${codigo:-nenhuma}')."
        aviso "Veja o fim do log: tail -n 50 /var/log/$DOMINIO.error.log"
        return 1
    fi
    ok "Site no ar (HTTP 200 na tela de login)."
    if printf '%s\n' "$cabecalhos" | grep -qi '^strict-transport-security:'; then
        ok "O PythonAnywhere repassa o X-Forwarded-Proto: o Django reconhece o HTTPS."
    else
        info "O Django não recebeu o X-Forwarded-Proto (normal no PythonAnywhere):"
        info "mantenha SECURE_SSL_REDIRECT=False e a chave Force HTTPS ligada na aba Web."
    fi
    return 0
}

# Confere páginas no formato "caminho=código" (ex.: /demo/apresentacao/=404).
# Retorna 1 se alguma respondeu diferente do esperado.
conferir_paginas() {
    local par caminho esperado codigo divergiu=0
    for par in "$@"; do
        caminho="${par%%=*}"
        esperado="${par#*=}"
        codigo="$(codigo_http "$caminho")"
        if [[ "$codigo" == "$esperado" ]]; then
            ok "https://$DOMINIO$caminho respondeu $codigo, como esperado."
        else
            aviso "https://$DOMINIO$caminho respondeu '${codigo:-nada}' (o esperado era $esperado)."
            divergiu=1
        fi
    done
    return "$divergiu"
}

# Copia o banco ORIGEM para DENTRO do banco DESTINO pela API de backup do
# SQLite. Serve com o site no ar: a troca é uma transação do próprio SQLite,
# com as travas dele (quem lê no meio vê o banco antigo ou o novo, nunca um
# pedaço de cada; sem renomear arquivo aberto nem deixar "-journal" órfão).
# O resultado é conferido com PRAGMA integrity_check.
copiar_banco_por_cima() {
    local origem="$1" destino="$2" python
    python="$(python_dos_scripts)" || falhar "Não achei um Python para copiar o banco."
    "$python" - "$origem" "$destino" <<'PY'
import sqlite3
import sys
from pathlib import Path

origem, destino = sys.argv[1], sys.argv[2]
# Só leitura: se a origem sumiu, erro — nunca um banco vazio criado na hora
# e copiado por cima do banco do site.
fonte = sqlite3.connect(Path(origem).resolve().as_uri() + "?mode=ro", uri=True, timeout=30)
alvo = sqlite3.connect(destino, timeout=60)
try:
    fonte.backup(alvo)
    resultado = alvo.execute("PRAGMA integrity_check").fetchone()[0]
finally:
    alvo.close()
    fonte.close()
if resultado != "ok":
    print(f"O banco não passou no integrity_check depois da cópia: {resultado}", file=sys.stderr)
    sys.exit(1)
PY
}

# Confere, só lendo, que o arquivo é um banco SQLite íntegro do NEXBUY
# (PRAGMA integrity_check e as tabelas principais). Retorna 1 se não for
# (a mensagem vai para a tela).
conferir_banco_do_nexbuy() {
    local arquivo="$1" python
    python="$(python_dos_scripts)" || falhar "Não achei um Python para conferir o banco."
    "$python" - "$arquivo" <<'PY'
import sqlite3
import sys
from pathlib import Path

try:
    conexao = sqlite3.connect(Path(sys.argv[1]).resolve().as_uri() + "?mode=ro", uri=True, timeout=30)
    try:
        resultado = conexao.execute("PRAGMA integrity_check").fetchone()[0]
        tabelas = {nome for (nome,) in conexao.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    finally:
        conexao.close()
except sqlite3.Error as erro:
    print(f"Não abriu como banco SQLite: {erro}", file=sys.stderr)
    sys.exit(1)
if resultado != "ok":
    print(f"O banco não passou no integrity_check: {resultado}", file=sys.stderr)
    sys.exit(1)
if not {"usuarios_usuario", "empresas_empresa", "django_migrations"} <= tabelas:
    print("O arquivo é um banco SQLite, mas não tem as tabelas do NEXBUY.", file=sys.stderr)
    sys.exit(1)
PY
}

# Explicação do aviso security.W008 do "check --deploy" (o mesmo texto em
# todo script que roda o check).
explicar_aviso_w008() {
    info "O aviso security.W008 (SECURE_SSL_REDIRECT) é esperado aqui: quem redireciona para"
    info "HTTPS é a chave 'Force HTTPS' da aba Web (redirecionar nos dois lugares dá loop)."
}

# Opção de demonstração pedida num site em uso real: recusa antes de mexer
# em qualquer coisa.
recusar_opcao_de_demonstracao() {
    local opcao="$1" script="$2"
    falhar "A opção $opcao é da DEMONSTRAÇÃO, e este site está em USO REAL — nada foi alterado." \
        "No uso real não existe cenário fictício nem senha de demonstração: cada pessoa da" \
        "equipe entra com a própria senha (quem esqueceu: a proprietária gera uma senha" \
        "provisória em Usuários e Permissões). Rode sem a opção: bash deploy/pythonanywhere/$script"
}
