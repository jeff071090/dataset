#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — atualiza o site no PythonAnywhere (demonstração ou uso real)
#
# Depois de enviar um zip novo (código novo) e trazer o .env de volta:
#
#     cd ~/nexbuy
#     bash deploy/pythonanywhere/atualizar.sh
#
# Etapas: backup do banco, dependências, migrate, collectstatic, conferência
# do modo do site, recarga e teste do site. Nunca troca senha que já foi
# definida e nunca apaga dado nenhum.
#
# USO REAL (NEXBUY_USO_REAL=True no .env, gravado pelo ativar_uso_real.sh):
# nada de cenário fictício nem de senha de demonstração; apaga do .env o
# token do Primeiro Acesso quando a proprietária já o usou; confere o backup
# diário automático e mostra a data do mais recente. Banco de uso real
# (empresa de verdade ou Primeiro Acesso feito) com um .env SEM o marcador
# (ex.: .env antigo da demonstração): o marcador e as linhas do uso real
# voltam ao .env.
#
# DEMONSTRAÇÃO (só antes do uso real):
#   --renovar-cenario  recria a história fictícia com datas a partir de HOJE
#                      (APAGA o que foi lançado na empresa de demonstração,
#                      inclusive pela cliente; as senhas são mantidas)
#   --sim              não pergunta antes de renovar
#   --gerar-senha      se algum usuário de demonstração ficar sem senha, gera
#
# Outras opções:
#   --sem-wsgi         não recarrega o site (testes fora do PythonAnywhere)
#
# atualizar_demo.sh é o nome antigo deste script e continua valendo.
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum_pa.sh"

RENOVAR=0
CONFIRMADO=0
GERAR_SENHA=0
SEM_WSGI=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --renovar-cenario) RENOVAR=1 ;;
        --sim) CONFIRMADO=1 ;;
        --gerar-senha) GERAR_SENHA=1 ;;
        --sem-wsgi) SEM_WSGI=1 ;;
        -h|--ajuda|--help) mostrar_ajuda "${BASH_SOURCE[0]}"; exit 0 ;;
        *) falhar "Opção desconhecida: $1" "Opções válidas: --renovar-cenario --sim --gerar-senha --sem-wsgi" ;;
    esac
    shift
done

# ---------------------------------------------------------------------------
etapa "1/7" "Conferindo a instalação"
# ---------------------------------------------------------------------------
exigir_instalacao
definir_dominio ""
if env_ligado DEBUG; then
    falhar "O $ENV_FILE está com DEBUG ligado — proibido num site na internet." \
        "Edite o arquivo e deixe DEBUG=False; depois rode de novo."
fi
if env_ligado ALLOW_SEED_IN_PRODUCTION; then
    falhar "O $ENV_FILE tem ALLOW_SEED_IN_PRODUCTION ligado — isso vale para o site inteiro." \
        "Apague essa linha do .env e rode de novo."
fi
ok "Código em $APP_DIR — site https://$DOMINIO/"
BANCO="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
estado_do_banco "$BANCO"

# Uso real: pelo marcador do .env OU — defesa extra — por empresa de verdade
# ou Primeiro Acesso feito no banco (mesmo sem o marcador, o cenário
# fictício nunca roda sobre eles).
USO_REAL=0
MISTO=0
GRAVAR_MARCADOR=0
if banco_misto; then
    MISTO=1
fi
if uso_real_no_env; then
    USO_REAL=1
    ok "Modo: USO REAL (NEXBUY_USO_REAL=True no .env)."
elif (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
    USO_REAL=1
    aviso "O banco tem dados de verdade ($(resumo_dados_reais)), mas o .env não tem NEXBUY_USO_REAL=True."
    aviso "Por segurança, esta atualização age como USO REAL: nada de cenário fictício nem de senha de demonstração."
    if [[ "$MISTO" == "0" ]]; then
        GRAVAR_MARCADOR=1
    fi
else
    ok "Modo: DEMONSTRAÇÃO (dados fictícios)."
fi
if [[ "$USO_REAL" == "1" ]]; then
    if [[ "$RENOVAR" == "1" ]]; then
        recusar_opcao_de_demonstracao "--renovar-cenario" "atualizar.sh"
    fi
    if [[ "$GERAR_SENHA" == "1" ]]; then
        recusar_opcao_de_demonstracao "--gerar-senha" "atualizar.sh"
    fi
    # Só depois das recusas (que não mudam nada): banco de uso real com um
    # .env sem o marcador volta a ter as linhas do uso real.
    if [[ "$GRAVAR_MARCADOR" == "1" ]]; then
        gravar_marcador_uso_real
    fi
elif [[ "$RENOVAR" == "1" ]]; then
    # Pergunta ANTES de qualquer mudança: um "não" aqui não deixa nada pela metade.
    confirmar_apagar_cenario "$CONFIRMADO"
fi

# ---------------------------------------------------------------------------
etapa "2/7" "Backup do banco (antes de qualquer mudança)"
# ---------------------------------------------------------------------------
if [[ -f "$BANCO" ]]; then
    bash "$SCRIPT_DIR/backup.sh" || falhar "O backup falhou — nada foi alterado." \
        "Confira o espaço em disco (aba Files) e rode de novo."
else
    aviso "Ainda não há banco — backup pulado."
fi

# ---------------------------------------------------------------------------
etapa "3/7" "Dependências"
# ---------------------------------------------------------------------------
instalar_dependencias
ok "Dependências em dia."

# ---------------------------------------------------------------------------
etapa "4/7" "Banco de dados e arquivos estáticos"
# ---------------------------------------------------------------------------
manage migrate --noinput || falhar "O migrate falhou (veja acima). O backup está em $BACKUP_DIR."
ok "Banco atualizado (migrate)."
manage collectstatic --noinput -v 0 || falhar "O collectstatic falhou (veja acima)."
ok "Arquivos estáticos atualizados."

if [[ "$USO_REAL" == "1" ]]; then
    # -----------------------------------------------------------------------
    etapa "5/7" "Uso real: Primeiro Acesso e backup diário"
    # -----------------------------------------------------------------------
    estado_do_banco "$BANCO"
    conferir_token_primeiro_acesso
    conferir_backup_diario
    if [[ "$MISTO" == "1" ]]; then
        aviso_banco_misto
    else
        conferir_modo_demonstracao_desligado
    fi

    # -----------------------------------------------------------------------
    etapa "6/7" "Senhas"
    # -----------------------------------------------------------------------
    ok "Nada a fazer no uso real: cada pessoa da equipe entra com a própria senha."
    info "(Quem esqueceu a senha: a proprietária gera uma senha provisória em Usuários e Permissões.)"
else
    # -----------------------------------------------------------------------
    etapa "5/7" "Cenário fictício"
    # -----------------------------------------------------------------------
    if [[ "$RENOVAR" == "1" ]]; then
        info "Renovando o cenário (1 a 3 minutos; as senhas atuais são mantidas)..."
        manage_seed seed_demo --manter-senhas || falhar "O seed_demo falhou (veja acima)." \
            "Nada foi gravado pela metade (o seed roda numa transação). Backup em $BACKUP_DIR."
        ok "Cenário renovado com datas a partir de hoje."
    else
        ok "Cenário mantido (para recriar com datas de hoje: --renovar-cenario)."
    fi

    # -----------------------------------------------------------------------
    etapa "6/7" "Senhas dos usuários de demonstração"
    # -----------------------------------------------------------------------
    # Falha FECHADA (igual ao preparar.sh): quem ainda tem a senha pública fica
    # sem senha agora mesmo; só depois o script pede/gera a senha nova.
    manage definir_senha_demo --bloquear || falhar "Não consegui desativar a senha pública (veja acima)."
    SEM_SENHA="$(listar_demo_sem_senha)"
    if [[ -n "$SEM_SENHA" ]]; then
        aviso "Usuários de demonstração sem senha: ${SEM_SENHA//,/, } — definindo agora."
        ARGS_SENHA=(--usuarios "$SEM_SENHA")
        if [[ "$GERAR_SENHA" == "1" ]]; then
            ARGS_SENHA+=(--gerar)
        fi
        manage definir_senha_demo "${ARGS_SENHA[@]}" || falhar \
            "As senhas NÃO foram definidas: ${SEM_SENHA//,/, } continuam SEM senha (ninguém entra com eles)." \
            "Rode de novo com --gerar-senha, ou: $VENV_PY manage.py definir_senha_demo --usuarios $SEM_SENHA"
    else
        ok "Senhas mantidas (a cliente continua entrando com as mesmas)."
    fi
    manage definir_senha_demo --verificar || falhar "Ainda há usuário com a senha pública ou sem senha (lista acima)." \
        "Siga a instrução acima e rode este script de novo."
fi

# ---------------------------------------------------------------------------
etapa "7/7" "Recarregando o site"
# ---------------------------------------------------------------------------
if [[ "$SEM_WSGI" == "1" ]]; then
    info "Pulado (--sem-wsgi). No PythonAnywhere: botão Reload na aba Web."
elif recarregar_site; then
    if command -v curl >/dev/null 2>&1; then
        if aguardar_site_no_ar && [[ "$USO_REAL" == "1" ]]; then
            PAGINAS=("/demo/apresentacao/=404")
            if primeiro_acesso_pendente && [[ -n "$(valor_env INITIAL_SETUP_TOKEN)" ]]; then
                PAGINAS+=("/primeiro-acesso/=200")
            else
                PAGINAS+=("/primeiro-acesso/=404")
            fi
            conferir_paginas "${PAGINAS[@]}" || aviso "Alguma página respondeu diferente do esperado (acima). Clique em Reload na aba Web e confira de novo."
        fi
    else
        info "Sem curl: abra https://$DOMINIO/ no navegador para conferir."
    fi
    conferir_force_https || true
fi

mostrar_uso_do_disco
printf '\n%s\n' "=========================================================================="
printf '%s\n' " Pronto. Site: https://$DOMINIO/"
if [[ "$USO_REAL" == "1" ]]; then
    if [[ "$MISTO" == "1" ]]; then
        printf '%s\n' " ATENÇÃO: o banco mistura a demonstração com empresa cadastrada nela (aviso acima)."
    elif primeiro_acesso_pendente; then
        printf '%s\n' " Primeiro Acesso: AINDA NÃO FEITO — https://$DOMINIO/primeiro-acesso/"
    else
        printf '%s\n' " Uso real: $QTD_EMPRESAS empresa(s), $QTD_ATIVOS usuário(s) ativo(s)."
    fi
    if ! env_ligado BACKUP_DIARIO; then
        printf '%s\n' " ATENÇÃO: o backup diário automático está DESLIGADO (BACKUP_DIARIO no .env)."
    fi
    printf '%s\n' " Backups: diários automáticos + os deste script em ~/nexbuy_backups/."
    printf '%s\n' " Toda semana, baixe o backup mais recente para o computador (aba Files)."
fi
printf '%s\n' " Não esqueça: aba Web > 'Run until 1 month from today' (a cada 3 semanas)."
printf '%s\n' "=========================================================================="
