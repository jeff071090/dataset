#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — restaura um backup do banco no PythonAnywhere
#
#     cd ~/nexbuy
#     ls -l ~/nexbuy_backups/
#     bash deploy/pythonanywhere/restaurar.sh ~/nexbuy_backups/ARQUIVO.sqlite3
#
# Serve para qualquer cópia do NEXBUY: as do backup.sh (nexbuy_*.sqlite3),
# as diárias automáticas (diario_*.sqlite3) ou uma enviada pela aba Files.
#
# O que acontece, nesta ordem:
#   1. confere o arquivo (PRAGMA integrity_check; é um banco do NEXBUY?) e
#      mostra o que tem nele e no banco atual;
#   2. pede para digitar RESTAURAR (ou --sim);
#   3. faz um backup de SEGURANÇA do banco atual (dá para desfazer);
#   4. copia o backup para dentro do banco do site pela API de backup do
#      SQLite (o site pode estar no ar) e aplica as migrações pendentes
#      (backup de uma versão anterior do sistema);
#   5. recarrega o site.
# Tudo o que foi lançado DEPOIS do horário do backup deixa de aparecer.
# Os arquivos enviados (logo) não fazem parte do backup do banco: ficam como
# estão.
#
# Proteções: recusa o próprio banco do site como origem; nunca troca um
# banco com empresa de verdade (ou com o Primeiro Acesso feito) por um
# backup sem empresa de verdade (o da demonstração ou um vazio); em uso
# real, recusa backup da demonstração (para isso: voltar_demonstracao.sh).
#
# Opções:
#   --sim       não pede para digitar RESTAURAR
#   --sem-wsgi  não recarrega o site (testes fora do PythonAnywhere)
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum_pa.sh"

CONFIRMADO=0
SEM_WSGI=0
ORIGEM=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --sim) CONFIRMADO=1 ;;
        --sem-wsgi) SEM_WSGI=1 ;;
        -h|--ajuda|--help) mostrar_ajuda "${BASH_SOURCE[0]}"; exit 0 ;;
        -*) falhar "Opção desconhecida: $1" "Opções válidas: --sim --sem-wsgi" ;;
        *)
            [[ -z "$ORIGEM" ]] || falhar "Informe UM arquivo de backup só."
            ORIGEM="$1"
            ;;
    esac
    shift
done

# ---------------------------------------------------------------------------
etapa "1/5" "Conferindo o backup escolhido"
# ---------------------------------------------------------------------------
exigir_instalacao
definir_dominio ""
if env_ligado DEBUG; then
    falhar "O $ENV_FILE está com DEBUG ligado — proibido num site na internet." \
        "Edite o arquivo e deixe DEBUG=False; depois rode de novo."
fi
[[ -n "$ORIGEM" ]] || falhar "Diga qual backup restaurar." \
    "Veja a lista com: ls -l ~/nexbuy_backups/" \
    "Depois: bash deploy/pythonanywhere/restaurar.sh ~/nexbuy_backups/NOME-DO-ARQUIVO.sqlite3"
[[ -f "$ORIGEM" ]] || falhar "Arquivo não encontrado: $ORIGEM" "Veja a lista com: ls -l ~/nexbuy_backups/"
BANCO="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
ORIGEM_ABS="$(cd "$(dirname "$ORIGEM")" && pwd)/$(basename "$ORIGEM")"
BANCO_ABS="$BANCO"
if [[ -f "$BANCO" ]]; then
    BANCO_ABS="$(cd "$(dirname "$BANCO")" && pwd)/$(basename "$BANCO")"
fi
[[ "$ORIGEM_ABS" != "$BANCO_ABS" ]] || falhar "Esse arquivo É o banco do site — escolha um backup de ~/nexbuy_backups/."

conferir_banco_do_nexbuy "$ORIGEM" || falhar "O arquivo não serve: não é um banco íntegro do NEXBUY (mensagem acima)." "Nada foi alterado."
ok "Backup íntegro: $ORIGEM ($(du -h "$ORIGEM" | cut -f1))"

# Cópia particular do backup escolhido: o backup de segurança (etapa 3) pode
# apagar a cópia manual mais antiga — e ela pode ser justamente a escolhida.
COPIA_ORIGEM="$(dirname "$BANCO")/.restaurar.$$.sqlite3"
mkdir -p "$(dirname "$BANCO")"
trap 'rm -f "$COPIA_ORIGEM" "$COPIA_ORIGEM-journal"' EXIT
cp "$ORIGEM" "$COPIA_ORIGEM" || falhar "Não consegui ler o backup $ORIGEM." "Nada foi alterado."
chmod 600 "$COPIA_ORIGEM" 2>/dev/null || true

estado_do_banco "$COPIA_ORIGEM"
B_EMPRESAS="$QTD_EMPRESAS"; B_REAIS="$QTD_EMPRESAS_REAIS"; B_ATIVOS="$QTD_ATIVOS"
B_NOMES_REAIS="$NOMES_EMPRESAS_REAIS"; B_NOMES_DEMO="$NOMES_EMPRESAS_DEMO"
# Backup "de uso real": empresa de verdade ou Primeiro Acesso feito (a
# empresa do Primeiro Acesso pode ter qualquer CNPJ).
B_USO_REAL=0
if (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
    B_USO_REAL=1
fi
estado_do_banco "$BANCO"

info "No backup ....... empresas: $B_EMPRESAS (reais: $B_REAIS) — usuários ativos: $B_ATIVOS"
if [[ -n "$B_NOMES_REAIS" ]]; then
    info "                  ${B_NOMES_REAIS}"
elif [[ -n "$B_NOMES_DEMO" ]]; then
    info "                  ${B_NOMES_DEMO} (demonstração)"
fi
if [[ "$BANCO_SITUACAO" == "ok" ]]; then
    info "No site agora ... empresas: $QTD_EMPRESAS (reais: $QTD_EMPRESAS_REAIS) — usuários ativos: $QTD_ATIVOS"
    if [[ -n "$NOMES_EMPRESAS_REAIS" ]]; then
        info "                  $NOMES_EMPRESAS_REAIS"
    fi
else
    info "No site agora ... (sem banco)"
fi

if [[ "$B_USO_REAL" == "0" ]]; then
    if (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
        falhar "Recusado: o site tem dados REAIS e este backup não tem empresa real (é da demonstração ou vazio)." \
            "Restaurar apagaria os dados reais. Nada foi alterado. Escolha um backup do uso real" \
            "(ex.: o diario_*.sqlite3 mais recente)."
    fi
    if uso_real_no_env && (( B_EMPRESAS > 0 )); then
        falhar "Recusado: o site está em USO REAL e este backup é da DEMONSTRAÇÃO. Nada foi alterado." \
            "Para voltar à demonstração (só antes do Primeiro Acesso), use o script próprio, que confere" \
            "tudo antes de mexer: bash deploy/pythonanywhere/voltar_demonstracao.sh" \
            "(guia docs/PYTHONANYWHERE_USO_REAL.md, parte \"Voltar para a demonstração\")."
    fi
fi

# ---------------------------------------------------------------------------
etapa "2/5" "Confirmação"
# ---------------------------------------------------------------------------
printf '\n%s' "$_COR_VERMELHA"
printf '%s\n' "  ATENÇÃO: o banco do site volta a ser EXATAMENTE o do backup:"
printf '%s\n' "    $(basename "$ORIGEM")"
printf '%s\n' "  Tudo o que foi lançado DEPOIS desse backup deixa de aparecer no sistema"
printf '%s\n' "  (compras, aprovações, receitas, usuários e senhas trocadas depois dele)."
printf '%s\n' "  Antes, uma cópia do banco atual vai para ~/nexbuy_backups/ (dá para desfazer)."
printf '%s\n' "  Peça para ninguém usar o site nos próximos minutos."
printf '%s\n' "$_COR_FIM"
if [[ "$CONFIRMADO" == "1" ]]; then
    info "Confirmado por --sim."
else
    [[ -t 0 ]] || falhar "Sem terminal para confirmar. Nada foi alterado." "Rode no console Bash ou acrescente --sim."
    RESPOSTA=""
    read -r -p "    Para restaurar, digite RESTAURAR (em maiúsculas) e tecle Enter: " RESPOSTA
    [[ "$RESPOSTA" == "RESTAURAR" ]] || falhar "Cancelado: nada foi alterado." \
        "Para restaurar, rode de novo e digite RESTAURAR."
fi

# ---------------------------------------------------------------------------
etapa "3/5" "Backup de segurança do banco atual"
# ---------------------------------------------------------------------------
if [[ -f "$BANCO" ]]; then
    bash "$SCRIPT_DIR/backup.sh" || falhar "O backup de segurança falhou — nada foi alterado." \
        "Confira o espaço em disco (aba Files) e rode de novo."
else
    aviso "Não há banco atual — nada para guardar."
fi

# ---------------------------------------------------------------------------
etapa "4/5" "Restaurando"
# ---------------------------------------------------------------------------
copiar_banco_por_cima "$COPIA_ORIGEM" "$BANCO" || falhar "A restauração falhou (mensagem acima)." \
    "O backup de segurança do banco anterior está em $BACKUP_DIR."
chmod 600 "$BANCO" 2>/dev/null || true
ok "Banco restaurado a partir de $(basename "$ORIGEM")."
manage migrate --noinput || falhar "O migrate falhou depois da restauração (veja acima)." \
    "O backup de segurança do banco anterior está em $BACKUP_DIR."
ok "Migrações conferidas (backup de versão anterior fica no formato atual)."
estado_do_banco "$BANCO"
if uso_real_no_env; then
    conferir_token_primeiro_acesso
fi

# ---------------------------------------------------------------------------
etapa "5/5" "Recarregando o site"
# ---------------------------------------------------------------------------
if [[ "$SEM_WSGI" == "1" ]]; then
    info "Pulado (--sem-wsgi). No PythonAnywhere: botão Reload na aba Web."
elif recarregar_site; then
    if command -v curl >/dev/null 2>&1; then
        aguardar_site_no_ar || true
    fi
fi
printf '\n%s\n' "=========================================================================="
printf '%s\n' " Restauração concluída. Site: https://$DOMINIO/"
printf '%s\n' " Avise a equipe: quem estava conectado precisa entrar de novo, e o que foi"
printf '%s\n' " lançado depois do backup precisa ser lançado outra vez."
printf '%s\n' "=========================================================================="
