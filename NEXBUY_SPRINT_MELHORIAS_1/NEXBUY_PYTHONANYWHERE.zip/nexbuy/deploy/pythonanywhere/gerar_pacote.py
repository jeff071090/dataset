"""Gera o NEXBUY_PYTHONANYWHERE.zip — o pacote que sobe para o PythonAnywhere
pela aba Files (limite de 100 MB por arquivo).

Roda no Windows (ou em qualquer sistema) com o Python do venv do projeto:

    venv\\Scripts\\python.exe deploy\\pythonanywhere\\gerar_pacote.py
    venv\\Scripts\\python.exe deploy\\pythonanywhere\\gerar_pacote.py D:\\pasta\\destino
    venv\\Scripts\\python.exe deploy\\pythonanywhere\\gerar_pacote.py D:\\pasta\\meu_pacote.zip

- Destino padrão: a pasta-MÃE da raiz do projeto (o zip nunca fica dentro
  da árvore do código). Um destino dentro da árvore é recusado.
- Dentro do zip tudo fica em "nexbuy/" — no console do PythonAnywhere,
  `cd ~ ; unzip -o NEXBUY_PYTHONANYWHERE.zip` cria/atualiza ~/nexbuy.
- Só entra o que iria para o GitHub: com `.git`, a lista do `git ls-files`;
  sem `.git`, a árvore inteira menos as mesmas exclusões do .gitignore
  (venv, __pycache__, bancos, mídia, staticfiles, .env, chaves, capturas e
  logs de QA, zips).
- Recusa (e não gera nada) se ainda assim aparecer .env, banco SQLite ou
  chave privada na lista.
- Recusa também se faltar na lista algum arquivo que o servidor precisa e
  que existe na pasta: tudo de deploy/pythonanywhere/ (preparar.sh,
  atualizar.sh, ativar_uso_real.sh, backup.sh, restaurar.sh...) e os guias
  que os scripts citam. Com git, é o arquivo novo esquecido fora do
  "git add" — ele ficaria fora do zip sem ninguém perceber.
- Os .sh vão marcados como executáveis e todos os caminhos usam "/" (o
  Compress-Archive do PowerShell 5.1 grava "\\" e quebra o unzip do Linux).
- No fim mostra a quantidade de arquivos, o tamanho e o SHA-256 do zip.
"""
import argparse
import fnmatch
import hashlib
import subprocess
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath

NOME_DO_ZIP = "NEXBUY_PYTHONANYWHERE.zip"
PASTA_NO_ZIP = "nexbuy"
LIMITE_UPLOAD = 100 * 1024 * 1024  # aba Files do PythonAnywhere: até 100 MiB por arquivo

# Pastas que nunca entram (em qualquer nível).
PASTAS_EXCLUIDAS = {
    "venv", ".venv", "env", "__pycache__", ".git", ".pytest_cache", "htmlcov",
    "media", "media_demo_cliente", "staticfiles", "playwright-report", "test-results",
    ".idea", ".vscode", ".claude",
}
PADROES_DE_PASTA_EXCLUIDOS = ("qa_*_screenshots", "*.egg-info")

# Arquivos que nunca entram (pelo nome).
PADROES_DE_ARQUIVO_EXCLUIDOS = (
    "*.pyc", "*.pyo", "*.pyd",
    ".env", ".env.*", "nexbuy.env", "*.pem", "*.key",
    "*.sqlite3", "*.sqlite3-*", "*.sqlite3.*", "*.db",
    "test_run_*.txt", "cookies.txt", "*.log", "*.zip",
    ".coverage", "Thumbs.db", "desktop.ini", ".DS_Store", "*.swp", "*~",
)
EXCECOES_PERMITIDAS = {".env.example"}

# Última barreira: nada disto pode estar na lista final, venha de onde vier.
PADROES_PROIBIDOS = (".env", ".env.*", "nexbuy.env", "*.sqlite3", "*.sqlite3-*", "*.sqlite3.*", "*.db",
                     "*.pem", "*.key")

# O que o servidor precisa e que, existindo na pasta, tem de estar no zip.
ESSENCIAIS_DO_SERVIDOR = (
    "deploy/pythonanywhere",
    "docs/DEPLOY_PYTHONANYWHERE_DEMO.md",
    "docs/PYTHONANYWHERE_USO_REAL.md",
)


class PacoteRecusado(Exception):
    pass


def raiz_padrao() -> Path:
    return Path(__file__).resolve().parents[2]


def _casa(nome: str, padroes) -> bool:
    return any(fnmatch.fnmatchcase(nome, padrao) for padrao in padroes)


def arquivo_excluido(relativo: PurePosixPath) -> bool:
    for parte in relativo.parts[:-1]:
        if parte in PASTAS_EXCLUIDAS or _casa(parte, PADROES_DE_PASTA_EXCLUIDOS):
            return True
    nome = relativo.name
    if nome in EXCECOES_PERMITIDAS:
        return False
    return _casa(nome, PADROES_DE_ARQUIVO_EXCLUIDOS)


def listar_pelo_git(raiz: Path):
    resultado = subprocess.run(
        ["git", "ls-files", "-z"], cwd=raiz, capture_output=True, check=True,
    )
    return sorted(
        PurePosixPath(item.decode("utf-8"))
        for item in resultado.stdout.split(b"\0")
        if item
    )


def listar_pela_arvore(raiz: Path):
    arquivos = []
    for caminho in raiz.rglob("*"):
        if not caminho.is_file() or caminho.is_symlink():
            continue
        relativo = PurePosixPath(caminho.relative_to(raiz).as_posix())
        if not arquivo_excluido(relativo):
            arquivos.append(relativo)
    return sorted(arquivos)


def verificar_conteudo(arquivos) -> None:
    """Recusa o pacote se aparecer segredo ou banco (ex.: um .env que foi
    parar no git por engano)."""
    proibidos = [
        str(arquivo) for arquivo in arquivos
        if arquivo.name not in EXCECOES_PERMITIDAS and _casa(arquivo.name, PADROES_PROIBIDOS)
    ]
    if proibidos:
        raise PacoteRecusado(
            "Pacote recusado: estes arquivos nunca podem ir para o servidor: " + ", ".join(proibidos)
        )
    if not any(str(arquivo) == "manage.py" for arquivo in arquivos):
        raise PacoteRecusado("Pacote recusado: manage.py não está na lista (raiz errada?).")


def verificar_essenciais(raiz: Path, arquivos) -> None:
    """Recusa o pacote se um arquivo de deploy/pythonanywhere/ (ou um guia
    que os scripts citam) existe na pasta mas ficou fora da lista — com
    git, um script novo sem "git add" sumiria do servidor sem aviso."""
    lista = {str(arquivo) for arquivo in arquivos}
    faltando = []
    for item in ESSENCIAIS_DO_SERVIDOR:
        caminho = raiz / item
        if caminho.is_dir():
            candidatos = [
                PurePosixPath(achado.relative_to(raiz).as_posix())
                for achado in caminho.rglob("*") if achado.is_file() and not achado.is_symlink()
            ]
        elif caminho.is_file():
            candidatos = [PurePosixPath(item)]
        else:
            continue
        faltando += [str(c) for c in candidatos if not arquivo_excluido(c) and str(c) not in lista]
    if faltando:
        raise PacoteRecusado(
            "Pacote recusado: estes arquivos do servidor existem na pasta, mas ficaram fora da lista "
            "(com git: falta \"git add\" e commit): " + ", ".join(sorted(faltando))
        )


def destino_do_zip(raiz: Path, argumento) -> Path:
    if argumento:
        destino = Path(argumento).expanduser()
        if destino.suffix.lower() != ".zip":
            destino = destino / NOME_DO_ZIP
    else:
        destino = raiz.parent / NOME_DO_ZIP
    destino = destino.resolve()
    if destino.is_relative_to(raiz.resolve()):
        raise PacoteRecusado(
            f"O zip não pode ficar dentro da pasta do projeto ({raiz}). Escolha outra pasta."
        )
    return destino


def gerar(raiz: Path, destino: Path, usar_git=None):
    raiz = raiz.resolve()
    if usar_git is None:
        usar_git = (raiz / ".git").exists()
    arquivos = listar_pelo_git(raiz) if usar_git else listar_pela_arvore(raiz)
    verificar_conteudo(arquivos)
    verificar_essenciais(raiz, arquivos)

    destino.parent.mkdir(parents=True, exist_ok=True)
    parcial = destino.with_name(destino.name + ".parcial")
    with zipfile.ZipFile(parcial, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as pacote:
        for relativo in arquivos:
            origem = raiz / Path(*relativo.parts)
            data = time.localtime(max(origem.stat().st_mtime, 315543600))[:6]  # zip não aceita antes de 1980
            info = zipfile.ZipInfo(f"{PASTA_NO_ZIP}/{relativo.as_posix()}", date_time=data)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3  # Unix: o unzip do Linux respeita as permissões abaixo
            modo = 0o100755 if relativo.suffix == ".sh" else 0o100644
            info.external_attr = modo << 16
            pacote.writestr(info, origem.read_bytes())
    parcial.replace(destino)

    tamanho = destino.stat().st_size
    sha256 = hashlib.sha256(destino.read_bytes()).hexdigest()
    return {"arquivos": len(arquivos), "tamanho": tamanho, "sha256": sha256, "origem": "git ls-files" if usar_git else "árvore"}


def main(argv=None):
    parser = argparse.ArgumentParser(description="Gera o NEXBUY_PYTHONANYWHERE.zip (fora da pasta do projeto).")
    parser.add_argument("destino", nargs="?", help="Pasta (ou arquivo .zip) de destino. Padrão: pasta-mãe do projeto.")
    parser.add_argument("--raiz", help="Raiz do projeto (padrão: a deste script). Usado pelos testes.")
    args = parser.parse_args(argv)

    raiz = Path(args.raiz).resolve() if args.raiz else raiz_padrao()
    try:
        destino = destino_do_zip(raiz, args.destino)
        resultado = gerar(raiz, destino)
    except PacoteRecusado as erro:
        print(f"ERRO: {erro}", file=sys.stderr)
        return 2
    except subprocess.CalledProcessError as erro:
        print(f"ERRO: git ls-files falhou: {erro}", file=sys.stderr)
        return 2

    print(f"Pacote gerado: {destino}")
    print(f"  Arquivos: {resultado['arquivos']} (lista por {resultado['origem']})")
    print(f"  Tamanho:  {resultado['tamanho']:,} bytes ({resultado['tamanho'] / 1024 / 1024:.1f} MB)".replace(",", "."))
    print(f"  SHA-256:  {resultado['sha256']}")
    if resultado["tamanho"] > LIMITE_UPLOAD:
        print("AVISO: passou de 100 MB — a aba Files do PythonAnywhere não aceita. Veja o guia.", file=sys.stderr)
        return 1
    print("Próximo passo: aba Files do PythonAnywhere > envie este zip para /home/<seu-usuario>/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
