#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — nome antigo do backup no PythonAnywhere. Continua funcionando:
# faz exatamente o mesmo que deploy/pythonanywhere/backup.sh (use aquele).
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/backup.sh" "$@"
