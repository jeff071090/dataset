#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — prepara a DEMONSTRAÇÃO no PythonAnywhere (conta grátis)
#
# Rode no console Bash do PythonAnywhere, de dentro da pasta ~/nexbuy:
#
#     cd ~/nexbuy
#     bash deploy/pythonanywhere/preparar.sh
#
# Opções:
#   --gerar-senha       gera uma senha forte para os 6 usuários (mostrada UMA vez)
#   --senha-individual  uma senha por usuário (com --gerar-senha: gera todas)
#   --trocar-senha      TROCA senhas já definidas (pede SIM; a cliente precisa da nova)
#   --eu                conta na região EU (<usuario>.eu.pythonanywhere.com)
#   --recriar-cenario   recria o cenário fictício mesmo que ele já exista
#                       (APAGA o que foi lançado na empresa de demonstração)
#   --sim               não pergunta antes de recriar o cenário / trocar senhas
#   --sem-wsgi          não mexe no arquivo WSGI (testes fora do PythonAnywhere)
#
# Pode rodar quantas vezes precisar (idempotente): o que já está pronto é
# mantido — o .env só muda de endereço com --eu/PA_DOMINIO, o cenário só é
# criado se ainda não existir e a senha só é pedida para usuário que ainda
# não tem senha. Senhas já definidas NUNCA mudam sem --trocar-senha (repetir
# o comando com --gerar-senha não invalida a senha que a cliente recebeu).
#
# USO REAL (NEXBUY_USO_REAL=True no .env, depois do ativar_uso_real.sh):
# refaz virtualenv, dependências, banco, estáticos e WSGI, mas pula TUDO o
# que é da demonstração (cenário fictício e senhas de demonstração) e recusa
# --gerar-senha, --senha-individual, --trocar-senha e --recriar-cenario.
# Mesmo sem o marcador, o cenário nunca roda num banco com empresa real ou
# com o Primeiro Acesso feito — e, nesse banco, o marcador volta ao .env
# (ex.: .env antigo da demonstração trazido por engano).
#
# Passo a passo completo (para leigo): docs/DEPLOY_PYTHONANYWHERE_DEMO.md
# (demonstração) e docs/PYTHONANYWHERE_USO_REAL.md (uso real)
# ===========================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum_pa.sh"

REGIAO=""
GERAR_SENHA=0
SENHA_INDIVIDUAL=0
TROCAR_SENHA=0
RECRIAR_CENARIO=0
CONFIRMADO=0
SEM_WSGI=0

ajuda() {
    mostrar_ajuda "${BASH_SOURCE[0]}"
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --gerar-senha) GERAR_SENHA=1 ;;
        --senha-individual) SENHA_INDIVIDUAL=1 ;;
        --trocar-senha) TROCAR_SENHA=1 ;;
        --eu) REGIAO="eu" ;;
        --recriar-cenario) RECRIAR_CENARIO=1 ;;
        --sim) CONFIRMADO=1 ;;
        --sem-wsgi) SEM_WSGI=1 ;;
        -h|--ajuda|--help) ajuda; exit 0 ;;
        *) falhar "Opção desconhecida: $1" "Opções válidas: --gerar-senha --senha-individual --trocar-senha --eu --recriar-cenario --sim --sem-wsgi" ;;
    esac
    shift
done

# ---------------------------------------------------------------------------
etapa "1/9" "Conferindo a pasta do NEXBUY"
# ---------------------------------------------------------------------------
[[ -f "$APP_DIR/manage.py" && -f "$APP_DIR/nexbuy/settings.py" ]] || falhar \
    "Não achei o código do NEXBUY em $APP_DIR." \
    "Na aba Consoles > Bash: cd ~ ; unzip -o NEXBUY_PYTHONANYWHERE.zip ; cd ~/nexbuy"
[[ -f "$REQUISITOS" ]] || falhar "Arquivo $REQUISITOS não encontrado." \
    "O zip está incompleto. Gere de novo com deploy/pythonanywhere/gerar_pacote.py."
if [[ "$APP_DIR" == *"|"* || "$APP_DIR" == *"&"* || "$APP_DIR" == *'"'* ]]; then
    falhar "O caminho da pasta ($APP_DIR) tem caractere especial (| & \")." "Descompacte o zip direto na sua pasta pessoal (cd ~)."
fi
if [[ -z "${NEXBUY_HOME:-}" && "$APP_DIR" != "$HOME_BASE/nexbuy" ]]; then
    aviso "O código está em $APP_DIR (o esperado era $HOME_BASE/nexbuy). Vou usar $APP_DIR mesmo."
fi
definir_dominio "$REGIAO"
ok "Código em $APP_DIR"
ok "Endereço do site: https://$DOMINIO/"
# Uso real (marcador no .env): as opções da demonstração são recusadas
# ANTES de qualquer mudança.
USO_REAL=0
if uso_real_no_env; then
    USO_REAL=1
    ok "Modo: USO REAL (NEXBUY_USO_REAL=True no .env) — nada de cenário fictício nem de senha de demonstração."
    for opcao_pedida in "GERAR_SENHA:--gerar-senha" "SENHA_INDIVIDUAL:--senha-individual" \
        "TROCAR_SENHA:--trocar-senha" "RECRIAR_CENARIO:--recriar-cenario"; do
        variavel_da_opcao="${opcao_pedida%%:*}"
        if [[ "${!variavel_da_opcao}" == "1" ]]; then
            recusar_opcao_de_demonstracao "${opcao_pedida#*:}" "preparar.sh"
        fi
    done
fi

# ---------------------------------------------------------------------------
etapa "2/9" "Procurando o Python (3.13, ou 3.12)"
# ---------------------------------------------------------------------------
PYTHON_BASE=""
if [[ -n "${NEXBUY_PYTHON:-}" ]]; then
    PYTHON_BASE="$NEXBUY_PYTHON"
else
    for candidato in python3.13 python3.12; do
        if command -v "$candidato" >/dev/null 2>&1; then
            PYTHON_BASE="$candidato"
            break
        fi
    done
fi
[[ -n "$PYTHON_BASE" ]] || falhar "Não achei o Python 3.13 nem o 3.12 nesta conta." \
    "Sua conta pode estar numa imagem de sistema antiga. Na página Account, troque a" \
    "'system image' para a mais nova (ajuda: help.pythonanywhere.com/pages/ChangingSystemImage/)" \
    "e rode este script de novo."
"$PYTHON_BASE" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)' || falhar \
    "O Python encontrado ($PYTHON_BASE) é mais antigo que 3.12 — o Django 6 não roda nele." \
    "Use uma conta com Python 3.13 (imagem de sistema 'innit')."
"$PYTHON_BASE" -c 'import sqlite3, sys; sys.exit(0 if sqlite3.sqlite_version_info >= (3, 31) else 1)' || falhar \
    "O SQLite deste Python é mais antigo que 3.31 (exigido pelo Django 6)." \
    "Troque a imagem de sistema da conta para a mais nova (página Account)."
ok "Python: $("$PYTHON_BASE" -c 'import sys; print(sys.version.split()[0])') (SQLite $("$PYTHON_BASE" -c 'import sqlite3; print(sqlite3.sqlite_version)'))"

# ---------------------------------------------------------------------------
etapa "3/9" "Ambiente Python (virtualenv) em $VENV_DIR"
# ---------------------------------------------------------------------------
if localizar_venv_python; then
    ok "Virtualenv já existe — mantido."
else
    venv_existia=0
    [[ -e "$VENV_DIR" ]] && venv_existia=1
    mkdir -p "$(dirname "$VENV_DIR")"
    info "Criando o virtualenv (leva uns segundos)..."
    if ! "$PYTHON_BASE" -m venv "$VENV_DIR"; then
        aviso "'python -m venv' falhou; tentando com o virtualenv."
        [[ "$venv_existia" == "0" ]] && rm -rf "$VENV_DIR"
        virtualenv -p "$PYTHON_BASE" "$VENV_DIR" || falhar "Não consegui criar o virtualenv em $VENV_DIR." \
            "Confira o espaço em disco (aba Files) e rode de novo."
    fi
    localizar_venv_python || falhar "O virtualenv foi criado, mas não achei o Python dentro de $VENV_DIR."
    ok "Virtualenv criado."
fi
VERSAO_VENV="$("$VENV_PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
carregar_env
ok "Python do virtualenv: $VERSAO_VENV — o web app (aba Web) precisa usar este MESMO Python."

# ---------------------------------------------------------------------------
etapa "4/9" "Instalando as dependências (Django, WhiteNoise, python-dotenv, Pillow)"
# ---------------------------------------------------------------------------
info "Pode levar 1 a 3 minutos na primeira vez..."
instalar_dependencias
ok "Dependências instaladas."

# ---------------------------------------------------------------------------
etapa "5/9" "Arquivo de configuração $ENV_FILE"
# ---------------------------------------------------------------------------
criar_env() {
    local chave admin temporario
    chave="$("$VENV_PY" -c 'import secrets; print(secrets.token_urlsafe(50))')"
    admin="suporte-$("$VENV_PY" -c 'import secrets; print(secrets.token_hex(6))')/"
    temporario="$ENV_FILE.novo.$$"
    (
        umask 077
        cat > "$temporario" <<EOF
# NEXBUY — demonstração no PythonAnywhere. Gerado por
# deploy/pythonanywhere/preparar.sh em $(date '+%d/%m/%Y %H:%M').
# Lido pelo nexbuy/settings.py: vale para o site E para o console.
# NUNCA envie este arquivo a ninguém. Modelo comentado de cada linha:
# deploy/pythonanywhere/nexbuy.env.pythonanywhere.exemplo
SECRET_KEY=${chave}
DEBUG=False
DEMO_MODE=True
DEMO_EXIBIR_SENHA=False
ALLOWED_HOSTS=${DOMINIO}
CSRF_TRUSTED_ORIGINS=https://${DOMINIO}
SECURE_SSL_REDIRECT=False
USA_PROXY_HTTPS=True
SQLITE_WAL=False
SQLITE_PATH=${DADOS_DIR_PADRAO}/db.sqlite3
MEDIA_ROOT=${DADOS_DIR_PADRAO}/media
STATIC_ROOT=${STATIC_DIR_PADRAO}
ADMIN_URL=${admin}
INITIAL_SETUP_TOKEN=
FEATURE_DDA=False
LOG_LEVEL=INFO
DB_ENGINE=sqlite3
EOF
    )
    chmod 600 "$temporario"
    mv -f "$temporario" "$ENV_FILE"
    chave=""
}

if [[ -f "$ENV_FILE" ]]; then
    if [[ "$USO_REAL" == "1" ]]; then
        ok "O .env já existe — mantido (a SECRET_KEY continua a mesma). No uso real, só o token já"
        info "usado do Primeiro Acesso e linhas do backup diário que faltarem são ajustados (etapa 7)."
    else
        ok "O .env já existe — mantido sem nenhuma alteração (a SECRET_KEY continua a mesma)."
    fi
    if env_ligado DEBUG; then
        falhar "O $ENV_FILE está com DEBUG ligado — proibido num site na internet." \
            "Edite o arquivo (aba Files) e deixe a linha DEBUG=False; depois rode de novo."
    fi
    if env_ligado ALLOW_SEED_IN_PRODUCTION; then
        falhar "O $ENV_FILE tem ALLOW_SEED_IN_PRODUCTION ligado — isso vale para o site inteiro." \
            "Apague essa linha do .env (os scripts passam a autorização só no comando do seed)."
    fi
    if [[ "$USO_REAL" == "0" ]]; then
        env_ligado DEMO_MODE || aviso "DEMO_MODE não está True no .env: sem selo, guia e troca de perfil."
    fi
    if env_ligado SQLITE_WAL || [[ -z "$(valor_env SQLITE_WAL)" ]]; then
        aviso "SQLITE_WAL não está False no .env (o WAL não funciona no disco de rede do PythonAnywhere)."
    fi
    HOSTS_ENV="$(valor_env ALLOWED_HOSTS)"
    case ",${HOSTS_ENV// /}," in
        *",$DOMINIO,"*) ;;
        *)
            if [[ "$REGIAO" == "eu" || -n "${PA_DOMINIO:-}" ]]; then
                # Endereço escolhido de propósito (ex.: o script rodou antes
                # como conta US numa conta EU): corrige só essas 2 linhas.
                gravar_dominio_no_env
                ok "Endereço do .env corrigido: ALLOWED_HOSTS=$DOMINIO e CSRF_TRUSTED_ORIGINS=https://$DOMINIO"
                info "(antes: '${HOSTS_ENV:-vazio}'; o resto do .env, inclusive a SECRET_KEY, ficou igual)"
            else
                aviso "ALLOWED_HOSTS do .env ('${HOSTS_ENV:-vazio}') não tem $DOMINIO — o site responderia 400 (Bad Request)."
                aviso "Conta EU? Rode de novo com --eu (o script corrige o .env)."
            fi
            ;;
    esac
else
    # Sem .env, mas o banco já tem empresa de verdade: o .env se perdeu (ex.:
    # faltou o "cp" na atualização). Nunca nasce um .env de DEMONSTRAÇÃO aqui.
    ENV_DE_USO_REAL=0
    estado_do_banco "$DADOS_DIR_PADRAO/db.sqlite3"
    if (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
        if [[ -f "$HOME_BASE/nexbuy_antigo/.env" ]]; then
            falhar "Não achei o $ENV_FILE, e o banco já tem dados reais ($(resumo_dados_reais))." \
                "Faltou trazer o .env da pasta antiga. Cole estas duas linhas:" \
                "cp ~/nexbuy_antigo/.env ~/nexbuy/.env" \
                "chmod 600 ~/nexbuy/.env" \
                "e rode este script de novo. Nada foi alterado."
        fi
        # Banco misto (demonstração com empresa cadastrada nela): o .env
        # nasce como demonstração e a etapa 6 age como USO REAL sem gravar o
        # marcador (a troca é com o ativar_uso_real.sh).
        if ! banco_misto; then
            ENV_DE_USO_REAL=1
        fi
    fi
    criar_env
    if [[ "$ENV_DE_USO_REAL" == "1" ]]; then
        gravar_no_env DEMO_MODE=False DEMO_EXIBIR_SENHA=False NEXBUY_USO_REAL=True \
            BACKUP_DIARIO=True "BACKUP_DIARIO_DIR=$BACKUP_DIR" BACKUP_DIARIO_MANTER=14
        USO_REAL=1
        aviso ".env recriado em modo USO REAL: o banco tem dados reais ($(resumo_dados_reais)) e o .env tinha sumido."
        aviso "A chave secreta é NOVA: todos precisam entrar de novo (os dados e as senhas continuam)."
    else
        ok ".env criado (permissão 600) com uma SECRET_KEY nova — ela não é mostrada em lugar nenhum."
        ok "Primeiro Acesso fechado (INITIAL_SETUP_TOKEN vazio); Admin técnico num endereço sorteado."
    fi
fi
chmod 600 "$ENV_FILE" 2>/dev/null || true
carregar_env

BANCO="$(valor_env SQLITE_PATH "$DADOS_DIR_PADRAO/db.sqlite3")"
MIDIA="$(valor_env MEDIA_ROOT "$DADOS_DIR_PADRAO/media")"
ESTATICOS="$(valor_env STATIC_ROOT "$STATIC_DIR_PADRAO")"
mkdir -p "$(dirname "$BANCO")" "$MIDIA" "$ESTATICOS" "$BACKUP_DIR"
chmod 700 "$(dirname "$BANCO")" "$BACKUP_DIR" 2>/dev/null || true
ok "Pastas: banco em $BANCO, uploads em $MIDIA, estáticos em $ESTATICOS"

# ---------------------------------------------------------------------------
etapa "6/9" "Banco de dados e arquivos estáticos"
# ---------------------------------------------------------------------------
manage migrate --noinput || falhar "O migrate falhou (veja a mensagem acima)." \
    "Confira o espaço em disco e o SQLITE_PATH do .env."
ok "Banco atualizado (migrate)."
manage collectstatic --noinput -v 0 || falhar "O collectstatic falhou (veja a mensagem acima)."
ok "Arquivos estáticos copiados para $ESTATICOS."
info "Conferência de segurança (check --deploy) — só informativa:"
if ! manage check --deploy; then
    aviso "O check --deploy apontou problema (acima). O script continua; confira depois."
fi
explicar_aviso_w008

# Defesa extra: mesmo sem o marcador no .env, banco com empresa de verdade
# (ou com o Primeiro Acesso feito) é tratado como USO REAL — o cenário
# fictício nunca roda sobre dados reais.
estado_do_banco "$BANCO"
MISTO=0
GRAVAR_MARCADOR=0
if banco_misto; then
    MISTO=1
fi
if [[ "$USO_REAL" == "0" ]] && (( QTD_EMPRESAS_REAIS > 0 || INSTALACAO_CONCLUIDA == 1 )); then
    USO_REAL=1
    aviso "O banco tem dados de verdade ($(resumo_dados_reais)), mas o .env não tem NEXBUY_USO_REAL=True."
    aviso "Por segurança, este script age como USO REAL: nada de cenário fictício nem de senha de demonstração."
    if [[ "$MISTO" == "0" ]]; then
        GRAVAR_MARCADOR=1
    fi
fi
if [[ "$USO_REAL" == "1" ]]; then
    for opcao_pedida in "GERAR_SENHA:--gerar-senha" "SENHA_INDIVIDUAL:--senha-individual" \
        "TROCAR_SENHA:--trocar-senha" "RECRIAR_CENARIO:--recriar-cenario"; do
        variavel_da_opcao="${opcao_pedida%%:*}"
        if [[ "${!variavel_da_opcao}" == "1" ]]; then
            recusar_opcao_de_demonstracao "${opcao_pedida#*:}" "preparar.sh"
        fi
    done
fi
if [[ "$GRAVAR_MARCADOR" == "1" ]]; then
    gravar_marcador_uso_real
fi

if [[ "$USO_REAL" == "0" ]]; then
# ---------------------------------------------------------------------------
etapa "7/9" "Cenário fictício (Farmácia Vida Plena) e usuários de demonstração"
# ---------------------------------------------------------------------------
USUARIOS_DEMO="$( { manage shell -c "from core.senha_demo import usernames_demo, usuarios_da_empresa_demo; print(usuarios_da_empresa_demo().filter(username__in=usernames_demo()).count())" || true; } | tail -n 1 | tr -d '\r[:space:]')"
[[ "$USUARIOS_DEMO" =~ ^[0-9]+$ ]] || falhar "Não consegui contar os usuários de demonstração no banco." \
    "Veja a mensagem acima; rode o script de novo."
SEED_RODOU=0
if [[ "$USUARIOS_DEMO" == "0" ]]; then
    info "Criando o cenário pela primeira vez (1 a 3 minutos; usa CPU do console)..."
    manage_seed seed_demo || falhar "O seed_demo falhou (veja a mensagem acima)."
    SEED_RODOU=1
    ok "Cenário criado."
    info "O aviso de SENHA PÚBLICA logo acima é esperado: a próxima etapa troca as senhas."
elif [[ "$RECRIAR_CENARIO" == "1" ]]; then
    confirmar_apagar_cenario "$CONFIRMADO"
    bash "$SCRIPT_DIR/backup.sh" || falhar "O backup do banco falhou — nada foi apagado."
    info "Recriando o cenário (as senhas atuais são mantidas)..."
    manage_seed seed_demo --manter-senhas || falhar "O seed_demo falhou (veja a mensagem acima)."
    SEED_RODOU=1
    ok "Cenário recriado com datas a partir de hoje."
else
    ok "Cenário já existe ($USUARIOS_DEMO usuários de demonstração) — mantido."
    info "(Para recriar: bash deploy/pythonanywhere/atualizar.sh --renovar-cenario)"
fi

# ---------------------------------------------------------------------------
etapa "8/9" "Senhas dos usuários de demonstração"
# ---------------------------------------------------------------------------
# Falha FECHADA: quem ainda tem a senha pública (ex.: acabou de ser criado
# pelo seed) fica SEM senha agora mesmo — se o site já estiver no ar, ele
# nunca aceita a senha pública, nem se a digitação abaixo não terminar.
manage definir_senha_demo --bloquear || falhar "Não consegui desativar a senha pública (veja acima)." \
    "Rode o script de novo; se repetir, veja o Error log na aba Web."
SEM_SENHA="$(listar_demo_sem_senha)"

ARGS_SENHA=()
[[ "$GERAR_SENHA" == "1" ]] && ARGS_SENHA+=(--gerar)
[[ "$SENHA_INDIVIDUAL" == "1" ]] && ARGS_SENHA+=(--individual)
PRECISA_SENHA=0
if [[ "$TROCAR_SENHA" == "1" ]]; then
    confirmar_troca_de_senha "$CONFIRMADO"
    PRECISA_SENHA=1
elif [[ -n "$SEM_SENHA" ]]; then
    PRECISA_SENHA=1
    # Só quem está sem senha — quem já tem continua com a senha atual.
    ARGS_SENHA+=(--usuarios "$SEM_SENHA")
    info "Usuários sem senha: ${SEM_SENHA//,/, }."
fi
if [[ "$PRECISA_SENHA" == "1" ]]; then
    if [[ "$GERAR_SENHA" != "1" ]]; then
        info "Agora escolha a senha. ATENÇÃO: nada aparece enquanto você digita — é normal."
    fi
    if ! manage definir_senha_demo ${ARGS_SENHA[@]+"${ARGS_SENHA[@]}"}; then
        if [[ -n "$SEM_SENHA" ]]; then
            falhar "As senhas NÃO foram definidas. Os usuários ${SEM_SENHA//,/, } continuam SEM senha" \
                "(a senha pública está desativada: ninguém entra com eles, o site está seguro)." \
                "Rode de novo: bash deploy/pythonanywhere/preparar.sh --gerar-senha"
        fi
        falhar "Nenhuma senha foi trocada — continuam as de antes (veja a mensagem acima)." \
            "Para tentar de novo: bash deploy/pythonanywhere/preparar.sh --trocar-senha"
    fi
elif [[ "$GERAR_SENHA" == "1" || "$SENHA_INDIVIDUAL" == "1" ]]; then
    ok "As senhas já tinham sido definidas antes — MANTIDAS (a cliente continua entrando com elas)."
    info "Para TROCAR mesmo assim: rode de novo acrescentando --trocar-senha (pede SIM)."
else
    ok "Todos os usuários de demonstração já têm senha própria — mantidas."
    info "(Para trocar: rode de novo com --trocar-senha, junto com --gerar-senha se quiser gerar)"
fi
manage definir_senha_demo --verificar || falhar \
    "Ainda há usuário com a senha pública ou sem senha (lista acima)." \
    "Siga a instrução acima; depois rode este script de novo."
if [[ "$GERAR_SENHA" == "1" && "$PRECISA_SENHA" == "1" ]]; then
    info "Copie a senha mostrada acima e depois digite clear (e Enter) para limpar a tela."
fi

else
# ---------------------------------------------------------------------------
etapa "7/9" "Uso real: Primeiro Acesso e backup diário"
# ---------------------------------------------------------------------------
ok "Nenhum cenário fictício: os dados são os que a equipe lança no sistema."
conferir_token_primeiro_acesso
conferir_backup_diario
if [[ "$MISTO" == "1" ]]; then
    aviso_banco_misto
else
    conferir_modo_demonstracao_desligado
fi

# ---------------------------------------------------------------------------
etapa "8/9" "Senhas"
# ---------------------------------------------------------------------------
ok "Nada a fazer no uso real: cada pessoa da equipe entra com a própria senha."
info "(Quem esqueceu a senha: a proprietária gera uma senha provisória em Usuários e Permissões.)"
fi

# ---------------------------------------------------------------------------
etapa "9/9" "Arquivo WSGI do web app"
# ---------------------------------------------------------------------------
WSGI_PENDENTE=0
if [[ "$SEM_WSGI" == "1" ]]; then
    info "Pulado (--sem-wsgi)."
    WSGI_PENDENTE=1
elif [[ -f "$WSGI_FILE" ]]; then
    if ! grep -q "NEXBUY_WSGI_PYTHONANYWHERE" "$WSGI_FILE" && [[ ! -e "$WSGI_ORIGINAL_BACKUP" ]]; then
        cp "$WSGI_FILE" "$WSGI_ORIGINAL_BACKUP"
        ok "Cópia do WSGI original do PythonAnywhere: $WSGI_ORIGINAL_BACKUP"
    fi
    WSGI_NOVO="$HOME_BASE/.nexbuy_wsgi.$$"
    sed "s|/home/SEU_USUARIO/nexbuy|$APP_DIR|" "$SCRIPT_DIR/wsgi_pythonanywhere.py" > "$WSGI_NOVO"
    grep -qF "CAMINHO_DO_PROJETO = \"$APP_DIR\"" "$WSGI_NOVO" || { rm -f "$WSGI_NOVO"; falhar "Não consegui montar o arquivo WSGI."; }
    cat "$WSGI_NOVO" > "$WSGI_FILE"
    rm -f "$WSGI_NOVO"
    ok "WSGI gravado em $WSGI_FILE (aponta para $APP_DIR, settings nexbuy.settings)."
    recarregar_site || true
    conferir_force_https || info "(Na primeira instalação é normal: a parte 5 do guia liga o Force HTTPS.)"
else
    WSGI_PENDENTE=1
    aviso "O arquivo WSGI $WSGI_FILE não existe: o web app ainda não foi criado."
    shopt -s nullglob
    outros=("$WSGI_DIR"/*_wsgi.py)
    shopt -u nullglob
    if (( ${#outros[@]} > 0 )); then
        aviso "Arquivos WSGI encontrados: ${outros[*]}"
        aviso "Se a sua conta é da região EU, rode de novo com --eu."
    fi
    info "Faça assim: aba Web > 'Add a new web app' > Next > 'Manual configuration'"
    info "> 'Python $VERSAO_VENV' > Next. Depois rode este script de novo (é rápido: o que"
    info "já está pronto é mantido e as senhas NÃO mudam)."
fi

mostrar_uso_do_disco

# ---------------------------------------------------------------------------
# RESUMO
# ---------------------------------------------------------------------------
ADMIN_ATUAL="$(valor_env ADMIN_URL admin/)"
printf '\n%s%s%s\n' "$_COR_VERDE" "==========================================================================" "$_COR_FIM"
printf '%s%s%s\n' "$_COR_NEGRITO" " RESUMO — valores para a aba Web do PythonAnywhere" "$_COR_FIM"
printf '%s\n' "=========================================================================="
printf '  %s\n' "Endereço do site ........... https://$DOMINIO/"
if [[ "$USO_REAL" == "1" ]]; then
    printf '  %s\n' "Modo ....................... USO REAL (dados de verdade; sem Modo Demonstração)"
    if primeiro_acesso_pendente; then
        printf '  %s\n' "Primeiro Acesso ............ https://$DOMINIO/primeiro-acesso/ (AINDA NÃO FEITO)"
    fi
else
    printf '  %s\n' "Abertura da apresentação ... https://$DOMINIO/demo/apresentacao/"
fi
printf '  %s\n' "Python do web app .......... $VERSAO_VENV (igual ao do virtualenv)"
printf '  %s\n' "Virtualenv ................. $VENV_DIR"
printf '  %s\n' "Code > Source code ......... $APP_DIR"
printf '  %s\n' "Code > Working directory ... $APP_DIR"
printf '  %s\n' "Static files (2 linhas):"
printf '  %s\n' "    URL /static/   Directory $ESTATICOS"
printf '  %s\n' "    URL /media/    Directory $MIDIA"
printf '  %s\n' "Security > Force HTTPS ..... LIGADO (Enabled)"
printf '  %s\n' "Depois de tudo ............. botão verde Reload, no topo da aba Web"
printf '  %s\n' "Admin técnico (suporte) .... https://$DOMINIO/$ADMIN_ATUAL (uso técnico — pode ignorar)"
printf '  %s\n' "Log de erros ............... /var/log/$DOMINIO.error.log (link 'Error log' na aba Web)"
printf '%s\n' "=========================================================================="
if [[ "$WSGI_PENDENTE" == "1" && "$SEM_WSGI" != "1" ]]; then
    printf '%s%s%s\n' "$_COR_AMARELA" " FALTA: criar o web app na aba Web e rodar este script de novo." "$_COR_FIM"
fi
printf '%s\n' " Lembrete: o site grátis expira em 1 mês. A cada 3 semanas, abra a aba Web e"
printf '%s\n' " clique em 'Run until 1 month from today'."
if [[ "$USO_REAL" == "1" ]]; then
    printf '%s\n' " Toda semana, baixe o backup mais recente para o computador (aba Files >"
    printf '%s\n' " nexbuy_backups). Guia: docs/PYTHONANYWHERE_USO_REAL.md"
fi
printf '%s\n' " Para liberar espaço: rm ~/NEXBUY_PYTHONANYWHERE.zip"
printf '%s\n' "=========================================================================="
