#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — ZERAR O BANCO (caso extremo): voltar ao sistema recém-instalado
#
#   sudo bash /opt/nexbuy/app/deploy/zerar_banco.sh
#
# Apaga TUDO do sistema — empresas, filiais, usuários, cadastros,
# movimentações, configurações e a Central de Auditoria — e deixa o banco
# vazio, como no dia da instalação. O Primeiro Acesso
# (https://SEU-DOMINIO/primeiro-acesso/) volta a ficar disponível, com o
# MESMO token (INITIAL_SETUP_TOKEN do /etc/nexbuy/nexbuy.env).
#
# Use só quando a limpeza normal não resolve (ex.: dados de demonstração
# gravados por engano, ou recomeçar a implantação inteira). Para apagar só as
# movimentações fictícias e MANTER os cadastros, use
# deploy/limpar_dados_de_teste.sh. (CNPJ digitado errado no Primeiro Acesso
# não exige zerar: o suporte corrige pelo Django Admin.)
#
# O que acontece, nesta ordem:
#   1. mostra o que existe hoje no banco e pede para digitar ZERAR;
#   2. para o serviço (ninguém grava durante a troca);
#   3. backup completo (deploy/backup.sh -> /var/backups/nexbuy/);
#   4. guarda o banco atual ao lado, com o sufixo .antes-de-zerar-DATA
#      (nunca é apagado) e cria o banco novo e vazio (migrate);
#   5. religa o serviço, confere o /healthz/ e mostra o endereço e o token
#      do Primeiro Acesso.
# Se algo falhar antes do banco novo ficar pronto, o banco anterior volta
# para o lugar e o serviço é religado.
#
# Todos os usuários são desconectados. Os arquivos enviados (logo/favicon em
# /var/lib/nexbuy/media/) ficam no disco; o novo cadastro envia os seus.
# Desfazer: restaurar o backup do passo 3 (deploy/restaurar_backup.sh).
# Para rodar sem pergunta: CONFIRMAR=ZERAR
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

# Estado global (lido pela armadilha de saída, mesmo se main() cair no meio).
ZB_BANCO=""
ZB_GUARDADO=""
ZB_PARADO=0
ZB_MOVIDO=0
ZB_PRONTO=0

contar() {
    sqlite3 -readonly "$ZB_BANCO" "SELECT COUNT(*) FROM $1;" 2>/dev/null || printf '?'
}

# Falhou depois de parar o serviço e antes de o banco novo ficar pronto:
# devolve o banco anterior e religa — o sistema volta a ser o que era.
desfazer_se_preciso() {
    local status=$?
    if [[ "$ZB_PRONTO" == "1" || "$ZB_PARADO" != "1" ]]; then
        return "$status"
    fi
    aviso "Falhou no meio. Voltando o banco anterior e religando o serviço."
    if [[ "$ZB_MOVIDO" == "1" && -f "$ZB_GUARDADO" ]]; then
        if [[ -f "$ZB_BANCO" ]]; then
            mv "$ZB_BANCO" "$ZB_BANCO.incompleto-$(date +%Y-%m-%d_%H%M%S)" || true
        fi
        rm -f "$ZB_BANCO-wal" "$ZB_BANCO-shm" "$ZB_BANCO-journal" || true
        mv "$ZB_GUARDADO" "$ZB_BANCO" && aviso "Banco anterior de volta em $ZB_BANCO."
    fi
    systemctl start "$SERVICO" || aviso "Não consegui religar: systemctl start $SERVICO"
    return "$status"
}

main() {
    if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
        sed -n '3,/^# =\{10,\}/{/^# =\{10,\}/d;s/^# \{0,1\}//;p}' "$0"
        exit 0
    fi
    exigir_root
    exigir_env
    command -v sqlite3 >/dev/null 2>&1 || falhar "sqlite3 não instalado (apt-get install -y sqlite3)."
    if [[ "$(valor_env DB_ENGINE)" == "postgresql" ]]; then
        falhar "DB_ENGINE=postgresql: este script cobre só o SQLite."
    fi

    local carimbo token dominio
    ZB_BANCO="$(valor_env SQLITE_PATH "$DATA_DIR/db.sqlite3")"
    carimbo="$(date +%Y-%m-%d_%H%M%S)"
    ZB_GUARDADO="$ZB_BANCO.antes-de-zerar-$carimbo"
    dominio="$(dominio_principal)"

    info "1/5 O que existe hoje"
    if [[ -f "$ZB_BANCO" ]]; then
        printf '  Banco: %s\n' "$ZB_BANCO"
        printf '  Empresas: %s · Usuários: %s · Compras: %s · Provisões: %s · Receitas: %s\n' \
            "$(contar empresas_empresa)" "$(contar usuarios_usuario)" "$(contar compras_compra)" \
            "$(contar gestao_compras_provisao)" "$(contar financeiro_receita)"
    else
        aviso "Não há banco em $ZB_BANCO — será criado um vazio."
    fi
    printf '\n  TUDO será apagado do sistema (empresas, usuários, cadastros, lançamentos e a\n'
    printf '  Central de Auditoria). O banco atual fica guardado em:\n    %s\n' "$ZB_GUARDADO"
    printf '  e um backup completo vai para %s.\n\n' "$BACKUP_DIR"
    local resposta="${CONFIRMAR:-}"
    if [[ "$resposta" != "ZERAR" ]]; then
        read -r -p "  Digite ZERAR (maiúsculas) para continuar: " resposta
    fi
    [[ "$resposta" == "ZERAR" ]] || falhar "Cancelado. Nada foi alterado."

    trap desfazer_se_preciso EXIT

    info "2/5 Parando o serviço"
    systemctl stop "$SERVICO"
    ZB_PARADO=1

    info "3/5 Backup completo"
    if [[ -f "$ZB_BANCO" ]]; then
        bash "$SCRIPT_DIR/backup.sh"
    else
        aviso "Sem banco atual — nada para guardar."
    fi

    info "4/5 Banco novo e vazio"
    if [[ -f "$ZB_BANCO" ]]; then
        # Serviço parado: junta o -wal no arquivo principal antes de guardá-lo.
        sqlite3 "$ZB_BANCO" "PRAGMA wal_checkpoint(TRUNCATE);" >/dev/null
        mv "$ZB_BANCO" "$ZB_GUARDADO"
        ZB_MOVIDO=1
        rm -f "$ZB_BANCO-wal" "$ZB_BANCO-shm" "$ZB_BANCO-journal"
        ok "Banco anterior guardado em $ZB_GUARDADO"
    fi

    token="$(valor_env INITIAL_SETUP_TOKEN)"
    if [[ -z "$token" ]]; then
        # O token foi apagado por higiene depois do primeiro Primeiro Acesso:
        # sem ele a tela não abre. Gera um novo, forte, só nesta linha.
        token="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
        if grep -qE '^[[:space:]]*INITIAL_SETUP_TOKEN=' "$ENV_FILE"; then
            sed -i "s|^[[:space:]]*INITIAL_SETUP_TOKEN=.*|INITIAL_SETUP_TOKEN=$token|" "$ENV_FILE"
        else
            printf 'INITIAL_SETUP_TOKEN=%s\n' "$token" >> "$ENV_FILE"
        fi
        chown root:"$APP_USER" "$ENV_FILE"
        chmod 600 "$ENV_FILE"
        aviso "INITIAL_SETUP_TOKEN estava vazio em $ENV_FILE: foi gerado um token novo (mostrado no fim)."
    fi

    nexbuy_manage migrate --noinput
    chown "$APP_USER:$APP_USER" "$ZB_BANCO"
    chmod 600 "$ZB_BANCO"
    ZB_PRONTO=1
    ok "Banco vazio criado em $ZB_BANCO"

    info "5/5 Religando o serviço"
    systemctl start "$SERVICO"
    if ! aguardar_healthz_socket "$dominio" 40; then
        falhar "O serviço não respondeu depois de zerar. Veja: journalctl -u $SERVICO -n 100 --no-pager"
    fi
    ok "Sistema no ar, com o banco vazio — /healthz/ respondeu ok."

    printf '\n  PRIMEIRO ACESSO (criar de novo a empresa e o administrador):\n'
    printf '    1. Abra:  https://%s/primeiro-acesso/\n' "$dominio"
    printf '    2. Digite o token:  %s\n' "$token"
    printf '    (guardado em %s, linha INITIAL_SETUP_TOKEN — não o compartilhe)\n' "$ENV_FILE"
    printf '\n  Banco anterior: %s\n' "$ZB_GUARDADO"
    printf '  Quando tiver certeza de que está tudo certo, ele pode ser apagado para liberar espaço.\n\n'
}

main "$@"
exit $?
