#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — restaurar um backup feito por deploy/backup.sh
#
#   sudo bash /opt/nexbuy/app/deploy/restaurar_backup.sh \
#        /var/backups/nexbuy/nexbuy_db_AAAA-MM-DD_HHMMSS.sqlite3.gz \
#        [/var/backups/nexbuy/nexbuy_media_AAAA-MM-DD_HHMMSS.tar.gz]
#
# Listar os backups disponíveis:  ls -lh /var/backups/nexbuy/
#
# O que acontece, nesta ordem:
#   1. confere os arquivos (gzip íntegro + PRAGMA integrity_check);
#   2. faz um backup de SEGURANÇA do estado atual (dá para voltar atrás);
#   3. para o serviço (ninguém grava durante a troca);
#   4. troca o banco (e a mídia, se informada) — o banco atual e a mídia
#      atual ficam guardados ao lado, com o sufixo .antes-da-restauracao-*;
#   5. aplica migrações pendentes (backup de uma versão mais antiga);
#   6. sobe o serviço e confere /healthz/.
#
# Pede confirmação digitada. Para rodar sem pergunta: CONFIRMAR=RESTAURAR
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

main() {
    exigir_root
    exigir_env

    local arquivo_db="${1:-}" arquivo_midia="${2:-}"
    [[ -n "$arquivo_db" ]] || falhar "Informe o arquivo do banco. Ex.: bash $0 $BACKUP_DIR/nexbuy_db_2026-09-26_033000.sqlite3.gz  (lista: ls -lh $BACKUP_DIR)"
    [[ -f "$arquivo_db" ]] || falhar "Arquivo não encontrado: $arquivo_db"
    [[ -z "$arquivo_midia" || -f "$arquivo_midia" ]] || falhar "Arquivo de mídia não encontrado: $arquivo_midia"

    local banco midia carimbo tmp
    banco="$(valor_env SQLITE_PATH "$DATA_DIR/db.sqlite3")"
    midia="$(valor_env MEDIA_ROOT "$DATA_DIR/media")"
    carimbo="$(date +%Y-%m-%d_%H%M%S)"

    info "1/6 Conferindo o backup"
    tmp="$(mktemp -d)"
    # shellcheck disable=SC2064
    trap "rm -rf '$tmp'" EXIT
    case "$arquivo_db" in
        *.gz) gzip -t "$arquivo_db" && gzip -dc "$arquivo_db" > "$tmp/db.sqlite3" ;;
        *)    cp "$arquivo_db" "$tmp/db.sqlite3" ;;
    esac
    local integridade
    integridade="$(sqlite3 "$tmp/db.sqlite3" "PRAGMA integrity_check;")"
    [[ "$integridade" == "ok" ]] || falhar "O arquivo de backup não passou no integrity_check: $integridade"
    if [[ -n "$arquivo_midia" ]]; then
        tar -tzf "$arquivo_midia" >/dev/null || falhar "O arquivo de mídia está corrompido: $arquivo_midia"
    fi
    ok "Backup íntegro"

    printf '\n  Banco atual:    %s\n  Será trocado por: %s\n' "$banco" "$arquivo_db"
    [[ -n "$arquivo_midia" ]] && printf '  Mídia atual:    %s\n  Será trocada por: %s\n' "$midia" "$arquivo_midia"
    printf '\n  Tudo o que foi lançado DEPOIS desse backup deixa de aparecer no sistema.\n\n'
    local resposta="${CONFIRMAR:-}"
    if [[ "$resposta" != "RESTAURAR" ]]; then
        read -r -p "  Digite RESTAURAR (maiúsculas) para continuar: " resposta
    fi
    [[ "$resposta" == "RESTAURAR" ]] || falhar "Cancelado. Nada foi alterado."

    info "2/6 Backup de segurança do estado atual"
    if [[ -f "$banco" ]]; then
        bash "$SCRIPT_DIR/backup.sh"
    else
        aviso "Não há banco atual em $banco — nada para guardar."
    fi

    info "3/6 Parando o serviço"
    systemctl stop "$SERVICO"

    info "4/6 Trocando os arquivos"
    if [[ -f "$banco" ]]; then
        mv "$banco" "$banco.antes-da-restauracao-$carimbo"
    fi
    # Um -wal/-shm antigo seria reaplicado sobre o banco restaurado
    # (corrupção) — o serviço já parou, então eles podem ir embora.
    rm -f "$banco-wal" "$banco-shm" "$banco-journal"
    install -o "$APP_USER" -g "$APP_USER" -m 600 "$tmp/db.sqlite3" "$banco"
    ok "Banco restaurado em $banco (o anterior ficou em $banco.antes-da-restauracao-$carimbo)"
    if [[ -n "$arquivo_midia" ]]; then
        if [[ -d "$midia" ]]; then
            mv "$midia" "$midia.antes-da-restauracao-$carimbo"
        fi
        tar -C "$(dirname "$midia")" -xzf "$arquivo_midia"
        chown -R "$APP_USER:$APP_USER" "$midia"
        ok "Mídia restaurada em $midia"
    fi

    info "5/6 Migrações pendentes (se o backup for de uma versão anterior)"
    nexbuy_manage migrate --noinput

    info "6/6 Subindo o serviço"
    systemctl start "$SERVICO"
    if aguardar_healthz_socket "$(dominio_principal)" 40; then
        ok "Restauração concluída — /healthz/ respondeu ok."
    else
        falhar "O serviço não respondeu depois da restauração. Veja: journalctl -u $SERVICO -n 100"
    fi
    printf '\n  Quando tiver certeza de que está tudo certo, os arquivos *.antes-da-restauracao-%s\n  podem ser apagados para liberar espaço.\n\n' "$carimbo"
}

main "$@"
exit $?
