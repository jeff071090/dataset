#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — criar o SUPERUSUÁRIO TÉCNICO (opcional; acesso ao Django Admin)
#
#   sudo bash /opt/nexbuy/app/deploy/criar_suporte_tecnico.sh
#
# Pergunta usuário, e-mail e senha (a senha não aparece na tela). Para
# rodar sem perguntas, defina DJANGO_SUPERUSER_USERNAME,
# DJANGO_SUPERUSER_EMAIL e DJANGO_SUPERUSER_PASSWORD no ambiente e passe
# --noinput.
#
# IMPORTANTE — só DEPOIS do Primeiro Acesso: a tela /primeiro-acesso/ fecha
# para sempre assim que existe QUALQUER usuário ativo no banco
# (core/views_primeiro_acesso.py::_primeiro_acesso_disponivel). Criar este
# superusuário antes impediria a criação da empresa e do administrador pela
# tela. Por isso o script recusa rodar enquanto o Primeiro Acesso não tiver
# sido feito (use --forcar só se souber exatamente o que está fazendo).
#
# Este usuário é do SUPORTE (Django Admin, em https://DOMINIO/<ADMIN_URL>).
# Quem cria os usuários do dia a dia da farmácia é o administrador que nasce
# no Primeiro Acesso, pela tela "Usuários e Permissões".
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

main() {
    exigir_root
    exigir_env

    local forcar=0 argumentos=() arg
    for arg in "$@"; do
        if [[ "$arg" == "--forcar" ]]; then forcar=1; else argumentos+=("$arg"); fi
    done

    if [[ "$forcar" != "1" ]]; then
        local estado
        estado="$(nexbuy_manage shell -c 'from core.models import EstadoInstalacao; from usuarios.models import Usuario; e = EstadoInstalacao.objects.first(); print("PRONTO" if (e and e.concluido) or Usuario.objects.filter(is_active=True).exists() else "PENDENTE")' | tail -n 1)"
        if [[ "$estado" != "PRONTO" ]]; then
            falhar "O Primeiro Acesso ainda não foi feito. Abra https://$(dominio_principal)/primeiro-acesso/, crie a empresa e o administrador, e só depois rode este script."
        fi
    fi

    info "Criando o superusuário técnico (Django Admin)"
    # DJANGO_SUPERUSER_* (se existirem no ambiente de quem chamou) seguem
    # para o createsuperuser: runuser preserva as variáveis exportadas.
    nexbuy_manage createsuperuser "${argumentos[@]}"
    ok "Pronto. Django Admin: https://$(dominio_principal)/$(valor_env ADMIN_URL admin/)"
}

main "$@"
exit $?
