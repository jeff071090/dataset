#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — backup do banco (SQLite) + mídia (uploads)
#
#   sudo bash /opt/nexbuy/app/deploy/backup.sh
#
# - Banco: API de backup online do SQLite (".backup") — cópia consistente
#   com o sistema RODANDO (nunca copie o arquivo .sqlite3 com cp: no modo WAL
#   parte dos dados ainda pode estar no arquivo -wal). A cópia é conferida
#   com "PRAGMA integrity_check" antes de ser guardada.
# - Mídia: tar.gz da pasta de uploads (logo/favicon).
# - Destino: /var/backups/nexbuy/ (só root lê). Retenção: 14 dias
#   (RETENCAO_DIAS=N para mudar).
# - O instalador agenda este script todo dia às 03:30 (/etc/cron.d/nexbuy-backup);
#   log: journalctl -t nexbuy-backup
#
# RESTAURAR: sudo bash /opt/nexbuy/app/deploy/restaurar_backup.sh ARQUIVO_DB [ARQUIVO_MIDIA]
# (passo a passo em docs/OPERACAO_BACKUP_E_ATUALIZACAO.md)
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

main() {
    exigir_root
    exigir_env
    command -v sqlite3 >/dev/null 2>&1 || falhar "sqlite3 não instalado (apt-get install -y sqlite3)."

    local retencao="${RETENCAO_DIAS:-14}"
    [[ "$retencao" =~ ^[0-9]+$ && "$retencao" -ge 1 ]] || falhar "RETENCAO_DIAS inválido: $retencao"

    if [[ "$(valor_env DB_ENGINE)" == "postgresql" ]]; then
        falhar "DB_ENGINE=postgresql: este script cobre só o SQLite. Use pg_dump (ver docs/OPERACAO_BACKUP_E_ATUALIZACAO.md)."
    fi

    local banco midia carimbo tmp destino_db destino_midia
    banco="$(valor_env SQLITE_PATH "$DATA_DIR/db.sqlite3")"
    midia="$(valor_env MEDIA_ROOT "$DATA_DIR/media")"
    carimbo="$(date +%Y-%m-%d_%H%M%S)"
    [[ -f "$banco" ]] || falhar "Banco não encontrado em $banco."

    install -d -o root -g root -m 700 "$BACKUP_DIR"
    tmp="$(mktemp -d "$BACKUP_DIR/.parcial.XXXXXX")"
    # shellcheck disable=SC2064
    trap "rm -rf '$tmp'" EXIT

    info "Copiando o banco ($banco) com o sistema no ar"
    sqlite3 -cmd ".timeout 30000" "$banco" ".backup '$tmp/db.sqlite3'"
    local integridade
    integridade="$(sqlite3 "$tmp/db.sqlite3" "PRAGMA integrity_check;")"
    [[ "$integridade" == "ok" ]] || falhar "A cópia do banco não passou no integrity_check: $integridade"

    destino_db="nexbuy_db_${carimbo}.sqlite3.gz"
    gzip -9 -c "$tmp/db.sqlite3" > "$tmp/$destino_db"
    rm -f "$tmp/db.sqlite3"

    destino_midia="nexbuy_media_${carimbo}.tar.gz"
    if [[ -d "$midia" ]]; then
        tar -C "$(dirname "$midia")" -czf "$tmp/$destino_midia" "$(basename "$midia")"
    else
        aviso "Pasta de mídia $midia não existe — backup só do banco."
        destino_midia=""
    fi

    chmod 600 "$tmp"/nexbuy_*
    mv "$tmp"/nexbuy_* "$BACKUP_DIR"/

    # Retenção: apaga só os arquivos de backup do próprio NEXBUY mais velhos
    # que RETENCAO_DIAS dias (nunca outra coisa da pasta).
    find "$BACKUP_DIR" -maxdepth 1 -type f \
        \( -name 'nexbuy_db_*.sqlite3.gz' -o -name 'nexbuy_media_*.tar.gz' \) \
        -mtime +"$((retencao - 1))" -print -delete | sed 's/^/    removido (mais de '"$retencao"' dias): /'

    date '+%Y-%m-%d %H:%M:%S' > "$BACKUP_DIR/ULTIMO_BACKUP_OK"
    ok "Backup concluído: $BACKUP_DIR/$destino_db${destino_midia:+ e $BACKUP_DIR/$destino_midia}"
    ok "Backups guardados: $(find "$BACKUP_DIR" -maxdepth 1 -type f -name 'nexbuy_db_*' | wc -l) do banco, ocupando $(du -sh "$BACKUP_DIR" | cut -f1)"
}

main "$@"
exit $?
