#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — sair da "fase de teste": apagar as movimentações fictícias de UMA
# empresa e manter todos os cadastros
#
#   sudo bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh [CNPJ] [--incluir-planejamento]
#
# Para quando a equipe fez uma "análise fictícia" no sistema de produção e
# agora vai começar o uso real. Compras e provisões gravadas não podem ser
# apagadas pela tela (isso protege o histórico) — este script faz isso pelo
# comando "manage.py limpar_movimentacoes", nesta ordem:
#
#   1. SIMULAÇÃO: mostra quantos registros de cada tipo seriam apagados
#      (nada é alterado) e pede para DIGITAR DE NOVO o CNPJ, para confirmar;
#   2. backup completo (deploy/backup.sh -> /var/backups/nexbuy/);
#   3. limpeza de verdade, numa transação só — o próprio comando ainda grava
#      uma cópia do banco com data e hora ao lado dele (/var/lib/nexbuy/) e
#      registra o evento na Central de Auditoria.
#
# APAGA (só da empresa do CNPJ): compras, parcelas, provisões e itens,
# solicitações de aprovação, históricos de compra/provisão e notificações.
# Com --incluir-planejamento, também receitas mensais, receitas extras,
# custos fixos, custos variáveis e os dias do calendário operacional.
#
# MANTÉM SEMPRE: empresa, filiais, usuários (com limites/bloqueios), perfis e
# permissões, fornecedores, categorias, centros de custo, configuração
# financeira e da plataforma, fluxos de aprovação, identidade visual e a
# Central de Auditoria. Nunca toca em outra empresa.
#
# O sistema continua no ar; peça para ninguém lançar nada durante a limpeza.
# Desfazer: restaurar o backup completo do passo 2 (deploy/restaurar_backup.sh).
# Passo a passo: docs/OPERACAO_BACKUP_E_ATUALIZACAO.md, seção 8 ("Fase de teste").
# ===========================================================================
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/_comum.sh"

so_digitos() {
    printf '%s' "${1//[^0-9]/}"
}

main() {
    local cnpj="" extras=() arg
    for arg in "$@"; do
        case "$arg" in
            --incluir-planejamento) extras+=("--incluir-planejamento") ;;
            -h|--help)
                sed -n '3,/^# =\{10,\}/{/^# =\{10,\}/d;s/^# \{0,1\}//;p}' "$0"
                exit 0
                ;;
            -*) falhar "Opção desconhecida: $arg (use --incluir-planejamento ou --help)" ;;
            *)  cnpj="$arg" ;;
        esac
    done

    exigir_root
    exigir_env

    if [[ -z "$cnpj" ]]; then
        read -r -p "  CNPJ da empresa (com ou sem pontuação): " cnpj
    fi
    [[ "$(so_digitos "$cnpj")" =~ ^[0-9]{14}$ ]] || falhar "CNPJ inválido: '$cnpj' (precisa ter 14 dígitos)."

    info "1/3 Simulação (nada é apagado)"
    nexbuy_manage limpar_movimentacoes --empresa "$cnpj" "${extras[@]}"

    printf '\n  Os registros listados acima serão APAGADOS DE VERDADE.\n'
    printf '  Antes, é feito um backup completo (dá para voltar com restaurar_backup.sh).\n\n'
    local confirmacao=""
    read -r -p "  Para confirmar, digite de novo o CNPJ da empresa: " confirmacao
    [[ "$(so_digitos "$confirmacao")" == "$(so_digitos "$cnpj")" ]] \
        || falhar "O CNPJ digitado não confere. Cancelado — nada foi apagado."

    local responsavel=""
    read -r -p "  Seu nome (fica registrado na Central de Auditoria) [${SUDO_USER:-root}]: " responsavel
    responsavel="${responsavel:-${SUDO_USER:-root}}"

    info "2/3 Backup completo antes de apagar"
    bash "$SCRIPT_DIR/backup.sh"

    info "3/3 Limpando as movimentações"
    nexbuy_manage limpar_movimentacoes --empresa "$cnpj" --confirmar "${extras[@]}" \
        --responsavel "$responsavel (servidor $(hostname))"

    ok "Limpeza concluída. Backup completo em $BACKUP_DIR (o mais recente: $(ls -t "$BACKUP_DIR"/nexbuy_db_*.gz 2>/dev/null | head -n 1))."
    printf '\n  Próximo passo, no sistema: Configurações › Checklist de Implantação (/ncc/checklist/)\n'
    printf '  e lançar os números REAIS (receita do mês, custos) — ver docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md.\n'
    printf '  A cópia feita pelo comando (nexbuy_antes_da_limpeza_*.sqlite3, em %s) pode ser\n' "$(dirname "$(valor_env SQLITE_PATH "$DATA_DIR/db.sqlite3")")"
    printf '  apagada depois que o uso real estiver conferido.\n\n'
}

main "$@"
exit $?
