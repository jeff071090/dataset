#!/usr/bin/env bash
# ===========================================================================
# NEXBUY — instalação completa numa VPS Ubuntu 24.04 LTS (Hostinger KVM 1/2)
#
# Rode como root, na VPS, com o código já clonado em /opt/nexbuy/app
# (recomendado — ver docs/DEPLOY_HOSTINGER_GITHUB.md):
#
#   bash /opt/nexbuy/app/deploy/instalar_servidor.sh DOMINIO EMAIL [REPO]
#
# ou por variáveis de ambiente:
#
#   DOMINIO=nexbuy.com.br EMAIL=ti@empresa.com.br \
#   REPO=git@github.com:SUA-CONTA/nexbuy.git bash instalar_servidor.sh
#
#   DOMINIO  domínio já apontado (registro A) para o IP desta VPS
#   EMAIL    e-mail para avisos do Let's Encrypt (vencimento do certificado)
#   REPO     URL do repositório no GitHub — só é usada se /opt/nexbuy/app
#            ainda não existir (aí o instalador faz o git clone)
#
# Opcionais: BRANCH=main  INCLUIR_WWW=1  FUSO_HORARIO=America/Cuiaba
#            PULAR_CERTBOT=1 (instala tudo, deixa o HTTPS para depois)
#            ATUALIZAR_NGINX=1 (regrava o site do nginx mesmo já com HTTPS)
#
# Pode rodar de novo sem estragar nada: nunca sobrescreve
# /etc/nexbuy/nexbuy.env nem o banco; não mexe no código já clonado (para
# atualizar o código use deploy/atualizar.sh).
# ===========================================================================
set -Eeuo pipefail

APP_USER="nexbuy"
NEXBUY_HOME="/opt/nexbuy"
APP_DIR="$NEXBUY_HOME/app"
VENV_DIR="$NEXBUY_HOME/venv"
DATA_DIR="/var/lib/nexbuy"
ENV_DIR="/etc/nexbuy"
ENV_FILE="$ENV_DIR/nexbuy.env"
BACKUP_DIR="/var/backups/nexbuy"
NGINX_SITE="/etc/nginx/sites-available/nexbuy"
CRON_BACKUP="/etc/cron.d/nexbuy-backup"
# Impressão digital oficial da chave ed25519 do github.com (publicada em
# docs.github.com > "GitHub's SSH key fingerprints").
GITHUB_ED25519_FP="SHA256:+DiY3wvvV6TuJJhbpZisF/zLDA0zPMSvHdkr4UvCOqU"

info()   { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
ok()     { printf '\033[1;32m[ OK ]\033[0m %s\n' "$*"; }
aviso()  { printf '\033[1;33m[AVISO]\033[0m %s\n' "$*" >&2; }
falhar() { printf '\033[1;31m[ERRO]\033[0m %s\n' "$*" >&2; exit 1; }
trap 'aviso "O instalador parou na linha $LINENO. Corrija o problema indicado acima e rode de novo — é seguro repetir."' ERR

main() {
    # ------------------------------------------------------------------
    # 0. Parâmetros e pré-requisitos
    # ------------------------------------------------------------------
    [[ "$(id -u)" -eq 0 ]] || falhar "Rode como root: sudo bash $0 DOMINIO EMAIL [REPO]"
    # Permissões previsíveis para código e venv (o usuário nexbuy precisa ler).
    umask 022

    DOMINIO="${1:-${DOMINIO:-}}"
    EMAIL="${2:-${EMAIL:-}}"
    REPO="${3:-${REPO:-}}"
    BRANCH="${BRANCH:-main}"
    INCLUIR_WWW="${INCLUIR_WWW:-1}"
    FUSO_HORARIO="${FUSO_HORARIO:-America/Cuiaba}"
    PULAR_CERTBOT="${PULAR_CERTBOT:-0}"
    ATUALIZAR_NGINX="${ATUALIZAR_NGINX:-0}"

    # Aceita "https://www.dominio.com.br/" e normaliza para "dominio.com.br".
    DOMINIO="$(printf '%s' "$DOMINIO" | tr '[:upper:]' '[:lower:]' | sed -E 's#^https?://##; s#/.*$##; s#^www\.##')"
    [[ -n "$DOMINIO" ]] || falhar "Informe o DOMINIO. Ex.: bash $0 nexbuy.com.br ti@empresa.com.br"
    [[ "$DOMINIO" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]] \
        || falhar "DOMINIO inválido: '$DOMINIO' (use só o nome, ex.: nexbuy.com.br)."
    if [[ "$PULAR_CERTBOT" != "1" ]]; then
        [[ "$EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]] \
            || falhar "Informe um EMAIL válido (avisos do Let's Encrypt). Ex.: bash $0 $DOMINIO ti@empresa.com.br"
    fi

    NOMES=("$DOMINIO")
    [[ "$INCLUIR_WWW" == "1" ]] && NOMES+=("www.$DOMINIO")

    if [[ -r /etc/os-release ]]; then
        # shellcheck disable=SC1091
        . /etc/os-release
        if [[ "${ID:-}" != "ubuntu" || "${VERSION_ID:-}" != "24.04" ]]; then
            aviso "Este instalador foi feito para Ubuntu 24.04 LTS (detectado: ${PRETTY_NAME:-desconhecido}). Continuando mesmo assim."
        fi
    fi

    info "Instalando o NEXBUY para: ${NOMES[*]}"

    # ------------------------------------------------------------------
    # 1. Pacotes do sistema
    # ------------------------------------------------------------------
    info "1/12 Pacotes do sistema (apt)"
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y --no-install-recommends \
        python3 python3-venv python3-dev build-essential \
        nginx certbot python3-certbot-nginx \
        git sqlite3 ufw curl ca-certificates cron openssh-client
    python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)' \
        || falhar "O NEXBUY exige Python 3.12 ou superior (Ubuntu 24.04 já traz o 3.12)."
    ok "Pacotes instalados ($(python3 --version))"

    # Alguns modelos de VPS já vêm com Apache ocupando a porta 80.
    if systemctl is-active --quiet apache2 2>/dev/null; then
        aviso "Apache (apache2) estava ativo na porta 80 — desligado para o nginx assumir."
        systemctl disable --now apache2 >/dev/null 2>&1 || true
    fi

    if command -v timedatectl >/dev/null 2>&1; then
        timedatectl set-timezone "$FUSO_HORARIO" 2>/dev/null \
            && ok "Fuso horário do servidor: $FUSO_HORARIO" \
            || aviso "Não consegui ajustar o fuso horário para $FUSO_HORARIO (o sistema usa America/Cuiaba internamente de qualquer forma)."
    fi

    # ------------------------------------------------------------------
    # 2. Usuário de sistema e pastas
    # ------------------------------------------------------------------
    info "2/12 Usuário de sistema '$APP_USER' e pastas"
    if ! id -u "$APP_USER" >/dev/null 2>&1; then
        useradd --system --user-group --home-dir "$DATA_DIR" --no-create-home \
            --shell /usr/sbin/nologin "$APP_USER"
        ok "Usuário $APP_USER criado"
    fi
    # O nginx (www-data) precisa ler o socket do gunicorn, /static e /media.
    usermod -aG "$APP_USER" www-data

    install -d -o root -g root -m 755 "$NEXBUY_HOME"
    install -d -o "$APP_USER" -g "$APP_USER" -m 750 "$DATA_DIR" "$DATA_DIR/media" "$DATA_DIR/staticfiles"
    install -d -o root -g "$APP_USER" -m 750 "$ENV_DIR"
    install -d -o root -g root -m 700 "$BACKUP_DIR"
    ok "Pastas prontas ($DATA_DIR, $ENV_DIR, $BACKUP_DIR)"

    # ------------------------------------------------------------------
    # 3. Código
    # ------------------------------------------------------------------
    info "3/12 Código em $APP_DIR"
    if [[ -f "$APP_DIR/manage.py" ]]; then
        ok "Código já presente — não foi alterado (para atualizar: bash $APP_DIR/deploy/atualizar.sh)"
    else
        [[ -n "$REPO" ]] || falhar "Não encontrei $APP_DIR/manage.py. Informe o REPO (URL do GitHub) como 3º argumento ou clone antes (ver docs/DEPLOY_HOSTINGER_GITHUB.md)."
        if [[ -e "$APP_DIR" ]] && [[ -n "$(ls -A "$APP_DIR" 2>/dev/null)" ]]; then
            falhar "$APP_DIR existe, não está vazio e não tem manage.py. Confira o conteúdo antes de continuar."
        fi
        if [[ "$REPO" == git@github.com:* || "$REPO" == ssh://git@github.com/* ]]; then
            confiar_no_github_ssh
        fi
        git clone --branch "$BRANCH" "$REPO" "$APP_DIR" \
            || falhar "git clone falhou. Repositório privado? Configure a deploy key ou o token (docs/DEPLOY_HOSTINGER_GITHUB.md, parte A)."
        ok "Repositório clonado (branch $BRANCH)"
    fi
    chown -R root:root "$APP_DIR"
    [[ -f "$APP_DIR/requirements.txt" ]] || falhar "requirements.txt não encontrado em $APP_DIR."
    # shellcheck disable=SC1091
    . "$APP_DIR/deploy/_comum.sh"

    # ------------------------------------------------------------------
    # 4. Ambiente Python
    # ------------------------------------------------------------------
    info "4/12 Ambiente Python em $VENV_DIR"
    [[ -x "$VENV_DIR/bin/python" ]] || python3 -m venv "$VENV_DIR"
    "$VENV_DIR/bin/python" -m pip install --upgrade --quiet pip wheel
    "$VENV_DIR/bin/python" -m pip install --quiet -r "$APP_DIR/requirements.txt"
    ok "Dependências instaladas"

    # ------------------------------------------------------------------
    # 5. Variáveis de produção (/etc/nexbuy/nexbuy.env)
    # ------------------------------------------------------------------
    info "5/12 Variáveis de produção em $ENV_FILE"
    if [[ -f "$ENV_FILE" ]]; then
        ok "$ENV_FILE já existe — mantido sem nenhuma alteração"
        if [[ ",$(valor_env ALLOWED_HOSTS)," != *",$DOMINIO,"* ]]; then
            aviso "ALLOWED_HOSTS em $ENV_FILE não contém '$DOMINIO'. Se o domínio mudou, edite o arquivo e rode de novo."
        fi
    else
        criar_env
        ok "$ENV_FILE criado com SECRET_KEY e INITIAL_SETUP_TOKEN novos (permissão 600)"
    fi
    chown root:"$APP_USER" "$ENV_FILE"
    chmod 600 "$ENV_FILE"
    verificar_variaveis_novas

    # ------------------------------------------------------------------
    # 6. Banco de dados e arquivos estáticos
    # ------------------------------------------------------------------
    info "6/12 Verificação de segurança do Django (check --deploy)"
    nexbuy_manage check --deploy

    info "7/12 Banco de dados (migrate) e arquivos estáticos (collectstatic)"
    local banco
    banco="$(valor_env SQLITE_PATH "$DATA_DIR/db.sqlite3")"
    if [[ -f "$banco" ]]; then
        ok "Banco existente preservado: $banco (só migrações pendentes serão aplicadas)"
    fi
    nexbuy_manage migrate --noinput
    if [[ -f "$banco" ]]; then
        chown "$APP_USER:$APP_USER" "$banco"
        chmod 600 "$banco"
    fi
    nexbuy_manage collectstatic --noinput
    "$VENV_DIR/bin/python" -m compileall -q "$APP_DIR" >/dev/null 2>&1 || true
    ok "Banco em $banco e estáticos em $(valor_env STATIC_ROOT "$DATA_DIR/staticfiles")"

    # Atalho: "sudo nexbuy-manage <comando>" = manage.py com o ambiente de produção.
    printf '#!/bin/sh\nexec bash %s/deploy/nexbuy-manage.sh "$@"\n' "$APP_DIR" > /usr/local/bin/nexbuy-manage
    chmod 755 /usr/local/bin/nexbuy-manage

    # ------------------------------------------------------------------
    # 7. Serviço systemd (gunicorn)
    # ------------------------------------------------------------------
    info "8/12 Serviço systemd 'nexbuy' (gunicorn)"
    install -m 644 "$APP_DIR/deploy/nexbuy.service" /etc/systemd/system/nexbuy.service
    systemctl daemon-reload
    systemctl enable nexbuy >/dev/null 2>&1
    systemctl restart nexbuy
    if aguardar_healthz_socket "$(dominio_principal)" 40; then
        ok "gunicorn no ar — /healthz/ respondeu {\"status\": \"ok\"}"
    else
        journalctl -u nexbuy -n 60 --no-pager >&2 || true
        falhar "O serviço nexbuy não respondeu em /healthz/. Veja o log acima (journalctl -u nexbuy)."
    fi

    # ------------------------------------------------------------------
    # 8. nginx
    # ------------------------------------------------------------------
    info "9/12 nginx"
    rm -f /etc/nginx/sites-enabled/default
    if [[ -f "$NGINX_SITE" ]] && grep -q "managed by Certbot" "$NGINX_SITE" && [[ "$ATUALIZAR_NGINX" != "1" ]]; then
        ok "$NGINX_SITE já tem HTTPS do certbot — mantido (ATUALIZAR_NGINX=1 para regravar)"
    else
        sed "s/__SERVER_NAMES__/${NOMES[*]}/" "$APP_DIR/deploy/nginx_nexbuy.conf" > "$NGINX_SITE"
        chmod 644 "$NGINX_SITE"
        ok "Site gravado em $NGINX_SITE"
    fi
    ln -sf "$NGINX_SITE" /etc/nginx/sites-enabled/nexbuy
    nginx -t
    systemctl enable nginx >/dev/null 2>&1
    # restart (não só reload): o www-data acabou de entrar no grupo nexbuy.
    systemctl restart nginx
    ok "nginx no ar"

    # ------------------------------------------------------------------
    # 9. Firewall
    # ------------------------------------------------------------------
    info "10/12 Firewall (ufw): SSH + HTTP/HTTPS"
    # Nunca trancar o próprio acesso: além do perfil OpenSSH (porta 22),
    # libera a porta que o sshd realmente usa, se tiver sido trocada.
    local porta_ssh
    ufw allow OpenSSH >/dev/null
    for porta_ssh in $(sshd -T 2>/dev/null | awk '/^port /{print $2}' | sort -u); do
        if [[ "$porta_ssh" =~ ^[0-9]+$ && "$porta_ssh" != "22" ]]; then
            ufw allow "${porta_ssh}/tcp" >/dev/null
            ok "SSH configurado na porta $porta_ssh — liberada também"
        fi
    done
    ufw allow 'Nginx Full' >/dev/null
    ufw --force enable >/dev/null
    ok "Firewall ativo (ufw): OpenSSH + Nginx Full (80/443) — confira com: ufw status"

    # ------------------------------------------------------------------
    # 10. Backup diário
    # ------------------------------------------------------------------
    info "11/12 Backup diário (03:30) em $BACKUP_DIR, retenção de 14 dias"
    cat > "$CRON_BACKUP" <<EOF
# NEXBUY — backup diário do banco + mídia (deploy/backup.sh). Log: journalctl -t nexbuy-backup
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
30 3 * * * root bash $APP_DIR/deploy/backup.sh 2>&1 | logger -t nexbuy-backup
EOF
    chmod 644 "$CRON_BACKUP"
    systemctl enable --now cron >/dev/null 2>&1 || true
    bash "$APP_DIR/deploy/backup.sh" >/dev/null && ok "Primeiro backup feito agora em $BACKUP_DIR" \
        || aviso "O backup de teste falhou — rode 'bash $APP_DIR/deploy/backup.sh' para ver o erro."

    # ------------------------------------------------------------------
    # 11. HTTPS (Let's Encrypt)
    # ------------------------------------------------------------------
    info "12/12 HTTPS (Let's Encrypt / certbot)"
    local https_ok=0
    if [[ "$PULAR_CERTBOT" == "1" ]]; then
        aviso "PULAR_CERTBOT=1 — HTTPS não configurado agora."
    else
        local nomes_validos=() nome
        for nome in "${NOMES[@]}"; do
            if dns_aponta_para_este_servidor "$nome"; then
                nomes_validos+=("$nome")
            else
                aviso "O DNS de '$nome' ainda não aponta para esta VPS — ficou fora do certificado por enquanto."
            fi
        done
        if [[ ${#nomes_validos[@]} -eq 0 ]]; then
            aviso "Nenhum nome aponta para esta VPS ainda (DNS propagando?). O certbot NÃO foi chamado para não gastar tentativas do Let's Encrypt."
            aviso "Quando 'nslookup $DOMINIO' mostrar o IP desta VPS, rode este instalador de novo (é seguro)."
        else
            local args_certbot=() n
            for n in "${nomes_validos[@]}"; do args_certbot+=(-d "$n"); done
            if certbot --nginx --non-interactive --agree-tos -m "$EMAIL" --redirect \
                --keep-until-expiring --expand "${args_certbot[@]}"; then
                ok "Certificado instalado para: ${nomes_validos[*]} (renovação automática: certbot.timer)"
                if aguardar_healthz_https "$DOMINIO" 15; then
                    https_ok=1
                    ok "https://$DOMINIO/healthz/ respondeu {\"status\": \"ok\"}"
                else
                    aviso "O certificado foi instalado, mas https://$DOMINIO/healthz/ não respondeu. Veja /var/log/nginx/nexbuy.error.log."
                fi
            else
                aviso "O certbot falhou (veja a mensagem acima). Causas comuns: DNS ainda propagando, porta 80 bloqueada no firewall da Hostinger. Corrija e rode o instalador de novo."
            fi
        fi
    fi

    resumo_final "$https_ok"
}

confiar_no_github_ssh() {
    install -d -m 700 /root/.ssh
    if ssh-keygen -F github.com -f /root/.ssh/known_hosts >/dev/null 2>&1; then
        return 0
    fi
    local chave fp
    chave="$(ssh-keyscan -t ed25519 github.com 2>/dev/null || true)"
    [[ -n "$chave" ]] || falhar "Não consegui falar com github.com pela porta 22 (ssh-keyscan). Confira a internet da VPS ou use o endereço HTTPS do repositório."
    fp="$(printf '%s\n' "$chave" | ssh-keygen -lf - 2>/dev/null | awk '{print $2}' || true)"
    if [[ "$fp" != "$GITHUB_ED25519_FP" ]]; then
        falhar "A chave SSH recebida de github.com ($fp) não confere com a oficial ($GITHUB_ED25519_FP). Confira em docs.github.com (\"GitHub's SSH key fingerprints\") antes de continuar."
    fi
    printf '%s\n' "$chave" >> /root/.ssh/known_hosts
    chmod 600 /root/.ssh/known_hosts
    ok "Chave do github.com conferida e registrada em /root/.ssh/known_hosts"
}

criar_env() {
    local secret token sufixo_admin nomes_csv
    secret="$(python3 -c 'import secrets; print(secrets.token_urlsafe(50))')"
    token="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
    sufixo_admin="$(python3 -c 'import secrets; print(secrets.token_hex(4))')"
    nomes_csv="$(IFS=,; printf '%s' "${NOMES[*]}")"
    umask 077
    cat > "$ENV_FILE" <<EOF
# NEXBUY — variáveis de produção. Gerado por deploy/instalar_servidor.sh em $(date '+%d/%m/%Y %H:%M').
# Explicação de cada linha: $APP_DIR/deploy/env.producao.exemplo
# NUNCA copie este arquivo para o GitHub nem o envie por e-mail/WhatsApp.
# Depois de editar: systemctl restart nexbuy
SECRET_KEY=$secret
DEBUG=False
ALLOWED_HOSTS=$nomes_csv
CSRF_TRUSTED_ORIGINS=
INITIAL_SETUP_TOKEN=$token
DEMO_MODE=False
ALLOW_SEED_IN_PRODUCTION=False
USA_PROXY_HTTPS=True
SECURE_SSL_REDIRECT=True
SECURE_HSTS_SECONDS=3600
SECURE_HSTS_INCLUDE_SUBDOMAINS=True
SECURE_HSTS_PRELOAD=False
SQLITE_PATH=$DATA_DIR/db.sqlite3
SQLITE_WAL=True
MEDIA_ROOT=$DATA_DIR/media
STATIC_ROOT=$DATA_DIR/staticfiles
ADMIN_URL=suporte-$sufixo_admin/
LOG_LEVEL=INFO
FEATURE_DDA=False
EOF
    umask 022
}

# Avisa (sem alterar nada) quando uma versão nova do NEXBUY documenta uma
# variável que o nexbuy.env existente ainda não tem.
verificar_variaveis_novas() {
    local exemplo="$APP_DIR/deploy/env.producao.exemplo" nome faltando=()
    [[ -f "$exemplo" ]] || return 0
    while IFS= read -r nome; do
        grep -qE "^[[:space:]]*${nome}=" "$ENV_FILE" || faltando+=("$nome")
    done < <(grep -oE '^[A-Z][A-Z0-9_]*=' "$exemplo" | tr -d '=' | sort -u)
    if [[ ${#faltando[@]} -gt 0 ]]; then
        aviso "Variáveis documentadas em deploy/env.producao.exemplo que não estão em $ENV_FILE: ${faltando[*]} (o padrão do sistema será usado)."
    fi
}

# Confere se http://NOME chega NESTA VPS: publica um arquivo com conteúdo
# aleatório em /static/ e tenta baixá-lo pelo domínio. Funciona mesmo se o
# IP público não aparecer nas interfaces de rede (NAT).
dns_aponta_para_este_servidor() {
    local nome="$1" segredo arquivo recebido
    getent ahosts "$nome" >/dev/null 2>&1 || return 1
    segredo="$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
    arquivo="nexbuy-verificacao-dns-$segredo.txt"
    printf '%s' "$segredo" > "$(valor_env STATIC_ROOT "$DATA_DIR/staticfiles")/$arquivo"
    chmod 644 "$(valor_env STATIC_ROOT "$DATA_DIR/staticfiles")/$arquivo"
    recebido="$(curl -fsSL --max-time 10 "http://$nome/static/$arquivo" 2>/dev/null || true)"
    rm -f "$(valor_env STATIC_ROOT "$DATA_DIR/staticfiles")/$arquivo"
    [[ "$recebido" == "$segredo" ]]
}

resumo_final() {
    local https_ok="$1" disponivel token admin_url
    disponivel="$(nexbuy_manage shell -c 'from core.views_primeiro_acesso import _primeiro_acesso_disponivel as d; print("SIM" if d() else "NAO")' 2>/dev/null | tail -n 1 || true)"
    token="$(valor_env INITIAL_SETUP_TOKEN)"
    admin_url="$(valor_env ADMIN_URL admin/)"

    printf '\n'
    printf '\033[1;32m%s\033[0m\n' "==========================================================================="
    printf '\033[1;32m  NEXBUY instalado.\033[0m\n'
    printf '\033[1;32m%s\033[0m\n' "==========================================================================="
    if [[ "$https_ok" == "1" ]]; then
        printf '  Endereço:        https://%s/\n' "$DOMINIO"
    else
        printf '  Endereço:        https://%s/  (HTTPS ainda NÃO ativo — veja os avisos acima)\n' "$DOMINIO"
    fi
    if [[ "$disponivel" == "SIM" ]]; then
        printf '\n  PRIMEIRO ACESSO (criar a empresa e o administrador):\n'
        printf '    1. Abra:  \033[1mhttps://%s/primeiro-acesso/\033[0m\n' "$DOMINIO"
        printf '    2. Digite o token:  \033[1m%s\033[0m\n' "$token"
        printf '    (o token fica guardado em %s, linha INITIAL_SETUP_TOKEN;\n' "$ENV_FILE"
        printf '     ele só vale enquanto o sistema estiver vazio — não o compartilhe)\n'
    else
        printf '\n  Primeiro Acesso: já concluído (ou token vazio). Entre em https://%s/accounts/login/\n' "$DOMINIO"
    fi
    printf '\n  Django Admin (só suporte técnico):  https://%s/%s\n' "$DOMINIO" "$admin_url"
    printf '  Saúde do sistema:   https://%s/healthz/\n' "$DOMINIO"
    printf '  Logs da aplicação:  journalctl -u nexbuy -f\n'
    printf '  Atualizar:          bash %s/deploy/atualizar.sh\n' "$APP_DIR"
    printf '  Backup manual:      bash %s/deploy/backup.sh   (automático todo dia 03:30)\n' "$APP_DIR"
    printf '  Fim da fase teste:  bash %s/deploy/limpar_dados_de_teste.sh CNPJ   (apaga os lançamentos fictícios)\n' "$APP_DIR"
    printf '  manage.py:          nexbuy-manage <comando>\n'
    printf '\033[1;32m%s\033[0m\n\n' "==========================================================================="
}

main "$@"
exit $?
