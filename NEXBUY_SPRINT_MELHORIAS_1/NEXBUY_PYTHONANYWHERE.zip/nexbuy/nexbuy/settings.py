"""
Configurações do projeto NEXBUY.

Organização preparada para evolução: hoje roda em SQLite (zero configuração),
mas basta definir DB_ENGINE=postgresql no .env para migrar para PostgreSQL
sem alterar código.

Produção (VPS Hostinger + GitHub): tudo vem de variáveis de ambiente, lidas
de /etc/nexbuy/nexbuy.env pelo systemd — ver deploy/env.producao.exemplo e
docs/DEPLOY_HOSTINGER_GITHUB.md.
"""
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent

# O test runner do Django força DEBUG=False durante "manage.py test" (para
# que 404.html/500.html se comportem como em produção nos testes) — por
# isso DEBUG sozinho não serve como sinal de "isto é produção de verdade"
# para código que roda durante os testes (ex.: o guard de seed em
# core/utils.py::abortar_seed_em_producao). TESTING é esse sinal à parte.
TESTING = len(sys.argv) > 1 and sys.argv[1] == "test"

load_dotenv(BASE_DIR / ".env")


def env_bool(nome, padrao=False):
    valor = os.environ.get(nome)
    if valor is None:
        return padrao
    return valor.strip().lower() in ("1", "true", "sim", "yes")


SECRET_KEY = os.environ.get(
    "SECRET_KEY", "django-insecure-nexbuy-dev-key-troque-em-producao"
)

# Prompt 2 (pré-Etapa 02), Gate G (item 18): default seguro é DEBUG=False —
# um ambiente de demonstração/produção que esqueça de setar a variável não
# pode subir com a página de debug exposta. Para rodar localmente com DEBUG
# ligado sem depender de lembrar a flag toda vez, exporte DEBUG=True (ou
# copie `.env.example`, que já documenta isso).
DEBUG = env_bool("DEBUG", False)

# Modo Demonstração (Demo Experience 1.0, item 1) — só liga um indicador
# visual e a exibição do tour guiado; a população de dados fictícios em si
# é feita explicitamente via `python manage.py seed_demo` (ver DEMO_MODE.md).
# Nunca altera nenhuma regra de negócio nem é lido fora de templates.
DEMO_MODE = env_bool("DEMO_MODE", False)

# Demonstração publicada na internet (PythonAnywhere — ver
# docs/DEPLOY_PYTHONANYWHERE_DEMO.md): a dica "usuários de demonstração +
# senha pública" da tela de login só pode aparecer na demonstração LOCAL do
# PC do apresentador. Por padrão segue o DEBUG — na demo local (DEBUG=True)
# a dica continua exatamente como sempre; num servidor (DEBUG=False) o
# login mostra só um aviso neutro, sem usuário nem senha, e as senhas dos
# usuários de demonstração são trocadas com `manage.py definir_senha_demo`.
DEMO_EXIBIR_SENHA = env_bool("DEMO_EXIBIR_SENHA", DEBUG)

# Uso real: o servidor deixou de ser demonstração e passou a guardar os
# dados DE VERDADE da farmácia (compras lançadas pelos compradores,
# receitas e custos lançados pelo financeiro) — ver
# docs/DEPLOY_PYTHONANYWHERE_DEMO.md. Os scripts de deploy/pythonanywhere/
# leem a mesma variável no .env. Com ela ligada:
# - `seed_demo`/`seed_dados` recusam rodar SEMPRE, mesmo com
#   ALLOW_SEED_IN_PRODUCTION na linha do comando — a farmácia fictícia e os
#   usuários com senha pública nunca se misturam aos dados reais
#   (core/utils.py::abortar_seed_em_producao);
# - o Modo Demonstração e a dica de senha da demonstração ficam desligados
#   mesmo que o .env ainda traga DEMO_MODE=True do tempo em que o site era a
#   demonstração: selo "Modo Demonstração", tour e o atalho "Trocar perfil
#   de demonstração" (usuários demo_*) não fazem sentido com dados reais.
# Desligado por padrão (a demonstração local do PC continua igual).
USO_REAL = env_bool("NEXBUY_USO_REAL", False)
if USO_REAL:
    DEMO_MODE = False
    DEMO_EXIBIR_SENHA = False

ALLOWED_HOSTS = [
    h.strip() for h in os.environ.get("ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if h.strip()
]

CSRF_TRUSTED_ORIGINS = [
    o.strip() for o in os.environ.get("CSRF_TRUSTED_ORIGINS", "").split(",") if o.strip()
]


def origens_https_dos_hosts(hosts):
    """Pronto para a Nuvem: deriva as origens confiáveis do CSRF a partir
    de ALLOWED_HOSTS ("nexbuy.com.br" -> "https://nexbuy.com.br";
    ".nexbuy.com.br" -> "https://*.nexbuy.com.br"). O curinga "*" nunca vira
    origem confiável — liberar qualquer origem anularia a proteção."""
    origens = []
    for host in hosts:
        if not host or host == "*":
            continue
        origens.append(f"https://*{host}" if host.startswith(".") else f"https://{host}")
    return origens


# Em produção (DEBUG=False) atrás do nginx, a VPS só precisa declarar o
# domínio uma vez (ALLOWED_HOSTS): sem CSRF_TRUSTED_ORIGINS explícito, as
# origens HTTPS desses mesmos hosts são aceitas — nenhum formulário (login,
# Primeiro Acesso, cadastros) quebra com "CSRF verification failed" por
# esquecimento de uma segunda variável.
if not CSRF_TRUSTED_ORIGINS and not DEBUG:
    CSRF_TRUSTED_ORIGINS = origens_https_dos_hosts(ALLOWED_HOSTS)

# Página amigável ("sua sessão expirou, recarregue a página") no lugar da
# tela técnica do Django quando um formulário chega sem token CSRF válido.
CSRF_FAILURE_VIEW = "core.views_healthcheck.falha_csrf"

# Endereço do Django Admin (uso técnico/suporte, nunca do dia a dia da
# farmácia). Em produção pode ser trocado por um caminho menos óbvio que
# "admin/" — reduz ruído de robôs que varrem /admin/. Sempre termina em "/".
ADMIN_URL = (os.environ.get("ADMIN_URL", "admin/").strip().strip("/") or "admin") + "/"

# Etapa 02 (Cliente-Ready) — Primeiro Acesso Seguro: só habilita a rota
# /primeiro-acesso/ quando esta variável está definida (além de exigir que
# não exista nenhum usuário/Empresa ativa ainda — ver core/views_primeiro_
# acesso.py). Nunca tem um valor real aqui nem em .env.example — cada
# implantação gera o próprio segredo antes de colocar o cliente para usar.
INITIAL_SETUP_TOKEN = os.environ.get("INITIAL_SETUP_TOKEN", "")

# DDA: integração futura prevista (não conectada). Sempre False: não existe
# implementação; a flag só muda o rótulo da tela /ncc/integracoes/ e nunca
# liga automação nenhuma. (O escopo não tem integração com ERP nem IA — as
# antigas FEATURE_INOVAFARMA/FEATURE_IA saíram; se ainda estiverem num .env,
# são ignoradas.)
FEATURE_DDA = env_bool("FEATURE_DDA", False)

# Atrás de um proxy confiável (o nginx da VPS, único que fala com o socket
# unix do gunicorn — deploy/instalar_servidor.sh liga USA_PROXY_HTTPS=True):
# o IP de origem da requisição só existe no cabeçalho X-Real-IP que o próprio
# nginx grava (`proxy_set_header X-Real-IP $remote_addr`, que SOBRESCREVE
# qualquer valor mandado pelo cliente). Pelo socket unix o gunicorn entrega
# REMOTE_ADDR vazio — sem isto, toda a trilha de auditoria (login_falho,
# login_sucesso, primeiro acesso...) gravaria ip=NULL em produção. Lido por
# `auditoria.services.ip_do_request`. Fora do proxy (runserver, testes) o
# cabeçalho é ignorado: nunca se confia num X-Real-IP mandado pelo cliente.
PROXY_CONFIAVEL = env_bool("USA_PROXY_HTTPS", False)


# --------------------------------------------------------------------------
# Segurança em produção (Sprint de Consolidação, Gate 2A, Parte 10)
#
# Nada neste bloco se aplica em desenvolvimento (DEBUG=True). Com
# DEBUG=False, falha alto e imediato (na subida do processo, não no meio de
# uma requisição) se a SECRET_KEY ainda for a chave insegura de
# desenvolvimento — nunca um servidor "no ar" com uma chave pública do
# repositório. O resto liga HTTPS/cookies seguros/HSTS, que só fazem
# sentido atrás de um domínio real com certificado.
# --------------------------------------------------------------------------

# A chave de exemplo do .env.example é tão pública quanto a chave de
# desenvolvimento — também nunca serve para produção. Vazia (como em
# deploy/env.producao.exemplo, que não traz valor) também é recusada.
_SECRET_KEYS_DE_EXEMPLO = {
    "django-insecure-nexbuy-dev-key-troque-em-producao",
    "troque-esta-chave-por-uma-chave-secreta-e-unica-em-producao",
}

if not DEBUG:
    if SECRET_KEY in _SECRET_KEYS_DE_EXEMPLO or not SECRET_KEY.strip():
        raise ImproperlyConfigured(
            "SECRET_KEY não configurada para produção. Defina uma chave real e única na "
            "variável de ambiente SECRET_KEY (gere uma com: python -c \"from "
            "django.core.management.utils import get_random_secret_key as g; print(g())\")."
        )

    SECURE_SSL_REDIRECT = env_bool("SECURE_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_REFERRER_POLICY = "same-origin"

    # HSTS começa conservador (1h) por padrão: um valor alto (o "1 ano"
    # normalmente recomendado) é perigoso enquanto o domínio/certificado de
    # produção ainda não está validado em uso real — um HTTPS mal configurado
    # com HSTS de 1 ano pode deixar o site inacessível para quem já visitou.
    # Suba SECURE_HSTS_SECONDS no .env conforme a confiança no ambiente aumenta.
    SECURE_HSTS_SECONDS = int(os.environ.get("SECURE_HSTS_SECONDS", "3600"))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = env_bool("SECURE_HSTS_INCLUDE_SUBDOMAINS", True)
    SECURE_HSTS_PRELOAD = env_bool("SECURE_HSTS_PRELOAD", False)

    # Pronto para a Nuvem: `check --deploy` avisa (security.W021) enquanto o
    # preload do HSTS estiver desligado. Desligado é decisão consciente, não
    # esquecimento: com a diretiva "preload" no cabeçalho, QUALQUER pessoa
    # pode inscrever o domínio na lista embutida dos navegadores, e sair
    # dela leva meses — o domínio inteiro (inclusive subdomínios futuros)
    # fica preso a HTTPS. Só se liga (SECURE_HSTS_PRELOAD=True) depois de o
    # HTTPS de produção estar estável — ligado, o próprio aviso deixa de existir.
    if not SECURE_HSTS_PRELOAD:
        SILENCED_SYSTEM_CHECKS = ["security.W021"]

    # SECURE_PROXY_SSL_HEADER só é seguro por trás de um proxy/load balancer
    # que o próprio ambiente controla (nginx, ALB etc.) — confiar cegamente
    # em X-Forwarded-Proto sem um proxy real na frente permite falsificar
    # "https" e furar o SECURE_SSL_REDIRECT acima. Por isso é opt-in,
    # documentado no .env.example, nunca ligado por padrão. Na VPS
    # (deploy/instalar_servidor.sh) o nginx é o único que fala com o
    # gunicorn (socket unix local) e sempre reescreve X-Forwarded-Proto —
    # por isso o instalador liga USA_PROXY_HTTPS=True lá.
    if env_bool("USA_PROXY_HTTPS", False):
        SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")


# --------------------------------------------------------------------------
# Apps
# --------------------------------------------------------------------------

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Apps do NEXBUY
    "core",
    "usuarios",
    "empresas",
    "filiais",
    "cadastros",
    "finance_engine",
    "financeiro",
    "compras",
    "dashboard",
    "gestao_compras",
    "notificacoes",
    "auditoria",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    # Backup diário automático (BACKUP_DIARIO, abaixo). Desligado, sai da
    # cadeia na subida do processo (MiddlewareNotUsed) — custo zero. Depois
    # do SecurityMiddleware/WhiteNoise e antes de sessão/CSRF/autenticação:
    # não lê nem altera nada do request; só agenda a cópia para DEPOIS de a
    # resposta ser entregue (core/backup_diario.py).
    "core.backup_diario.BackupDiarioMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "nexbuy.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "core.context_processors.identidade_visual_login",
                "core.context_processors.demo_mode",
                "core.context_processors.contexto_core",
                "core.context_processors.navegacao",
            ],
        },
    },
]

WSGI_APPLICATION = "nexbuy.wsgi.application"
ASGI_APPLICATION = "nexbuy.asgi.application"


# --------------------------------------------------------------------------
# Banco de dados
#
# Padrão: SQLite (não requer instalação de servidor). É também o banco da
# produção na VPS (arquivo em /var/lib/nexbuy/db.sqlite3 via SQLITE_PATH,
# modo WAL, backup diário por deploy/backup.sh) — o mesmo motor coberto pela
# suíte de testes inteira.
# Opção futura: defina DB_ENGINE=postgresql e preencha DB_NAME, DB_USER,
# DB_PASSWORD, DB_HOST, DB_PORT.
# --------------------------------------------------------------------------

if os.environ.get("DB_ENGINE") == "postgresql":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ.get("DB_NAME", "nexbuy"),
            "USER": os.environ.get("DB_USER", "nexbuy"),
            "PASSWORD": os.environ.get("DB_PASSWORD", ""),
            "HOST": os.environ.get("DB_HOST", "localhost"),
            "PORT": os.environ.get("DB_PORT", "5432"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            # SQLITE_PATH (opcional): caminho do arquivo do banco. Em produção
            # na VPS aponta para fora da pasta do código (ex.:
            # /var/lib/nexbuy/db.sqlite3), para que `git pull` nunca encoste
            # no banco e o backup fique num lugar só. Sem a variável, mantém o
            # comportamento de sempre (db.sqlite3 na raiz do projeto).
            "NAME": os.environ.get("SQLITE_PATH") or (BASE_DIR / "db.sqlite3"),
            # Fechamento Final (Prompt 1, Seção 8) — revisão de fechamento do
            # motor financeiro encontrou que `select_for_update()` (usado em
            # criar_provisao/efetivar_provisao/aprovar_compra_pendente etc.,
            # gestao_compras/services.py e compras/services.py) é um NO-OP
            # silencioso no SQLite: `has_select_for_update = False` nesse
            # backend, então o Django nunca emite `FOR UPDATE`, e duas
            # transações concorrentes liam o mesmo saldo/status "antes" sem
            # nenhum bloqueio real — reabrindo exatamente as corridas que a
            # Sprint de Correções Críticas (Seções 12/14) documentou como
            # fechadas.
            #
            # `transaction_mode: "IMMEDIATE"` corrige isso na raiz, sem tocar
            # em nenhuma regra de negócio: cada `transaction.atomic()` passa
            # a emitir `BEGIN IMMEDIATE` (em vez do `BEGIN` deferred padrão),
            # que adquire o lock de ESCRITA do SQLite já no início da
            # transação — uma segunda transação concorrente bloqueia (até o
            # `timeout` abaixo) esperando a primeira commitar, e só então lê
            # o estado já atualizado. É exatamente a semântica "lock +
            # revalidar" que todo esse código já pressupõe — só que agora
            # ela realmente acontece. `timeout` maior que o padrão do driver
            # (5s) dá margem para essa espera sem estourar "database is
            # locked" em picos de uso.
            "OPTIONS": {"transaction_mode": "IMMEDIATE", "timeout": 20},
        }
    }

    # Pronto para a Nuvem: na VPS, o gunicorn roda VÁRIOS processos contra o
    # mesmo arquivo. No modo WAL do SQLite, leitores não esperam o escritor
    # (e o escritor não espera os leitores) — só escrita x escrita continua
    # serializada pelo BEGIN IMMEDIATE acima. O modo fica gravado no próprio
    # arquivo; repetir o PRAGMA a cada conexão é instantâneo.
    #
    # Ligado por padrão só com DEBUG=False (produção). Em desenvolvimento e
    # na demonstração local fica desligado de propósito: os scripts .bat de
    # reset da demo apagam apenas o arquivo .sqlite3, e um "-wal" órfão
    # deixado por um servidor encerrado à força seria reaplicado sobre o
    # banco novo (corrupção documentada pelo próprio SQLite). SQLITE_WAL no
    # ambiente força a escolha nos dois sentidos (vazio = padrão).
    _SQLITE_WAL_ENV = os.environ.get("SQLITE_WAL", "").strip()
    if env_bool("SQLITE_WAL") if _SQLITE_WAL_ENV else not DEBUG:
        DATABASES["default"]["OPTIONS"]["init_command"] = "PRAGMA journal_mode=WAL;"


# --------------------------------------------------------------------------
# Backup diário automático feito pelo próprio site
#
# Para servidor SEM agendador de tarefas: a conta grátis do PythonAnywhere
# criada depois de 15/01/2026 não tem "scheduled tasks" (na VPS quem faz o
# backup diário é o cron, com deploy/backup.sh — lá isto fica desligado).
# Com BACKUP_DIARIO=True, o primeiro acesso de cada dia (data de Cuiabá,
# TIME_ZONE abaixo) copia o banco SQLite para
# <BACKUP_DIARIO_DIR>/diario_AAAA-MM-DD.sqlite3 — API de backup do SQLite,
# conferida com PRAGMA integrity_check — e guarda só as BACKUP_DIARIO_MANTER
# cópias "diario_*" mais recentes. Nunca encosta nos backups feitos à mão
# (nexbuy_*.sqlite3) nem em outro arquivo da pasta. A cópia roda depois de a
# página já ter sido entregue, e um erro nela nunca derruba nem trava o
# site: vira aviso no log e nova tentativa mais tarde (core/backup_diario.py).
# Para rodar à mão: python manage.py backup_diario
#
# Desligado por padrão. Com PostgreSQL, sem pasta ou com caminho relativo,
# não faz nada além de um aviso no log. Cada cópia ocupa o tamanho do banco:
# no plano grátis (512 MB de disco) confira o espaço antes de subir o MANTER.
# --------------------------------------------------------------------------

BACKUP_DIARIO = env_bool("BACKUP_DIARIO", False)
BACKUP_DIARIO_DIR = os.environ.get("BACKUP_DIARIO_DIR", "").strip()


def env_inteiro(nome, padrao, minimo):
    """Inteiro do ambiente que nunca derruba a subida do site: valor vazio
    ou inválido vira o padrão; abaixo do mínimo, o mínimo."""
    try:
        valor = int((os.environ.get(nome) or "").strip() or padrao)
    except ValueError:
        valor = padrao
    return max(minimo, valor)


# Mínimo 2: a cópia de hoje nunca é a única (se ela sair ruim, a de ontem
# ainda está lá).
BACKUP_DIARIO_MANTER = env_inteiro("BACKUP_DIARIO_MANTER", 14, 2)


# --------------------------------------------------------------------------
# Autenticação
# --------------------------------------------------------------------------

AUTH_USER_MODEL = "usuarios.Usuario"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
    # A senha pública da demonstração local (DEMO_MODE.md) e as variações
    # dela (Nexbuy123, nexbuy123!...) nunca valem como senha escolhida —
    # na demo publicada na internet seriam a primeira tentativa de qualquer
    # visitante. O seed_demo grava a senha pública direto, sem validador.
    {"NAME": "core.senha_demo.SenhaPublicaDemoValidator"},
]

LOGIN_URL = "login"

# Sprint de Melhorias 1 (segurança): limite de tentativas de login
# (core/limite_login.py). Falhas contadas na Central de Auditoria.
LOGIN_JANELA_MINUTOS = env_inteiro("LOGIN_JANELA_MINUTOS", 15, 1)
LOGIN_MAX_FALHAS_USUARIO = env_inteiro("LOGIN_MAX_FALHAS_USUARIO", 5, 3)
LOGIN_MAX_FALHAS_IP = env_inteiro("LOGIN_MAX_FALHAS_IP", 20, 5)
LOGIN_REDIRECT_URL = "dashboard:home"
LOGOUT_REDIRECT_URL = "login"


# --------------------------------------------------------------------------
# Internacionalização
# --------------------------------------------------------------------------

LANGUAGE_CODE = "pt-br"
TIME_ZONE = "America/Cuiaba"
USE_I18N = True
USE_TZ = True

# Formata todo número exibido via template (`{{ valor|floatformat:2 }}` e
# `{{ valor }}` puro) com separador de milhar do locale ativo — com
# LANGUAGE_CODE=pt-br, gera "1.234,56" em vez de "1234,56" em toda a
# aplicação (Dashboard, Calendário, cards, relatórios, histórico) sem
# precisar alterar nenhum template (Sprint 6, item 1 — padronização
# monetária). Mensagens (`django.contrib.messages`) e outros textos
# montados em Python puro usam `core.utils.formatar_moeda`, que aplica a
# mesma formatação fora do motor de templates.
USE_THOUSAND_SEPARATOR = True


# --------------------------------------------------------------------------
# Arquivos estáticos
# --------------------------------------------------------------------------

STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
# Pronto para a Nuvem: STATIC_ROOT e MEDIA_ROOT aceitam caminho absoluto por
# variável de ambiente — na VPS ficam em /var/lib/nexbuy/ (fora da pasta do
# código, que o `git pull` atualiza), servidos direto pelo nginx. Sem a
# variável, o comportamento de sempre (pastas na raiz do projeto).
STATIC_ROOT = Path(os.environ["STATIC_ROOT"]) if os.environ.get("STATIC_ROOT") else BASE_DIR / "staticfiles"

# Uploads do usuário (logo/favicon da Identidade Visual — Sprint 6, item 3).
# Servidos pelo Django só em desenvolvimento (`nexbuy/urls.py`); em produção
# o nginx serve este caminho (deploy/nginx_nexbuy.conf, location /media/) —
# o WhiteNoise não cobre MEDIA.
MEDIA_URL = "media/"
MEDIA_ROOT = Path(os.environ["MEDIA_ROOT"]) if os.environ.get("MEDIA_ROOT") else BASE_DIR / "media"

# Em desenvolvimento/testes (DEBUG=True), usa o storage simples (sem hash),
# já que `collectstatic` normalmente não foi rodado — a tag {% static %}
# sempre consulta o storage configurado aqui, mesmo que o `runserver` sirva
# os arquivos direto de STATICFILES_DIRS por fora disso. Em produção
# (DEBUG=False), usa o storage do WhiteNoise (compressão + cache-busting por
# hash), que exige `collectstatic` — sempre rodado antes do deploy.
_STATICFILES_BACKEND = (
    "django.contrib.staticfiles.storage.StaticFilesStorage"
    if DEBUG
    else "nexbuy.storage.NexbuyStaticFilesStorage"
)

STORAGES = {
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
    },
    "staticfiles": {
        "BACKEND": _STATICFILES_BACKEND,
    },
}

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

MESSAGE_TAGS = {}


# --------------------------------------------------------------------------
# Logging (Sprint de Consolidação, Gate 2A, Parte 10)
#
# Só biblioteca padrão (nenhum serviço externo) — todo log vai para o
# console (stdout/stderr), que é o padrão esperado por qualquer plataforma
# de deploy (Docker, systemd, PaaS) para coletar/agregar logs por fora da
# aplicação. Django funde este dicionário com o próprio logging padrão dele
# (não substitui): o log de acesso do runserver e o "Internal Server Error"
# de exceções não tratadas continuam funcionando como sempre.
# --------------------------------------------------------------------------

# Nível do log da aplicação (root). Em produção o systemd coleta tudo o que
# sai no console: `journalctl -u nexbuy`. Erros de requisição (HTTP 500, com
# traceback) saem SEMPRE, pelo logger django.request abaixo, e avisos de
# segurança (DisallowedHost, falha de CSRF) pelo django.security.
LOG_LEVEL = (os.environ.get("LOG_LEVEL", "INFO").strip().upper() or "INFO")

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "nexbuy": {
            "format": "{asctime} {levelname} {name} {message}",
            "style": "{",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "nexbuy",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": LOG_LEVEL,
    },
    "loggers": {
        "django.request": {
            "handlers": ["console"],
            "level": "ERROR",
            "propagate": False,
        },
        "django.security": {
            "handlers": ["console"],
            "level": "WARNING",
            "propagate": False,
        },
    },
}
