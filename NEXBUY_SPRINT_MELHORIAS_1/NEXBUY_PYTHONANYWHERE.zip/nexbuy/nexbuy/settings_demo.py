"""Configurações do NEXBUY para a DEMONSTRAÇÃO COMERCIAL isolada (Pacote B —
Etapa 02).

Herda TUDO de `nexbuy/settings.py` (SECURE_*, LOGGING, apps, middleware,
autenticação etc. continuam idênticos) e sobrescreve só o que precisa ser
diferente para nunca tocar no banco/mídia principal (`db.sqlite3`/`media/`):

- banco de dados próprio (`db_demo_cliente.sqlite3`, nunca `db.sqlite3`);
- pasta de mídia própria (`media_demo_cliente/`, nunca `media/`);
- `ALLOWED_HOSTS` restrito a loopback — esta demo nunca é exposta fora da
  máquina do apresentador.

`DEMO_MODE` NÃO é forçado aqui — quem decide é o LAUNCHER, via variável de
ambiente: `iniciar_demo_cliente_limpa.bat` define `DEMO_MODE=False` (o
cenário vazio/guiado reproduz a experiência cliente-ready, sem badge) e
`iniciar_demo_cenario_pronto.bat` define `DEMO_MODE=True` (dados fictícios
do seed_demo, badge "Modo Demonstração" visível). Sem a variável, o padrão
é False (o cenário mais conservador).

Uso: qualquer comando de `manage.py` (migrate, seed_demo, runserver, shell,
test) que passe `--settings=nexbuy.settings_demo` opera 100% isolado do
banco/mídia principal. Nenhum outro arquivo do projeto precisa saber que
este settings existe — é opt-in, por flag explícita em cada comando.
"""
import copy

from .settings import *  # noqa: F401,F403

# --------------------------------------------------------------------------
# Isolamento de banco de dados
#
# `DATABASES` já foi montado por `settings.py` (SQLite por padrão, ou
# PostgreSQL se DB_ENGINE=postgresql estiver no .env) — aqui só o "NAME" é
# trocado, preservando qualquer outra chave já definida (ex.: `OPTIONS` com
# `transaction_mode: IMMEDIATE`, usado pelo SQLite para locking real).
#
# `from .settings import *` faz `DATABASES` apontar para o MESMO objeto
# dict de `nexbuy.settings` (star-import não copia objetos mutáveis) —
# mutar `DATABASES["default"]["NAME"]" diretamente corrompia, em memória,
# a configuração ATIVA do processo principal (`django.conf.settings`)
# sempre que este módulo fosse importado por qualquer motivo (ex.:
# `core/tests_pacote_demo.py` importa este módulo para verificar o
# isolamento) — sintoma real observado: testes concorrentes de
# `core/tests_primeiro_acesso.py`, ao abrir uma conexão nova depois desse
# import, tentavam usar `db_demo_cliente.sqlite3` em vez do banco de teste
# real, e falhavam com "no such table". `copy.deepcopy` garante que este
# módulo tenha seu PRÓPRIO dict, nunca o mesmo objeto do settings
# principal.
# --------------------------------------------------------------------------

DATABASES = copy.deepcopy(DATABASES)

if DATABASES["default"]["ENGINE"] == "django.db.backends.sqlite3":
    DATABASES["default"]["NAME"] = BASE_DIR / "db_demo_cliente.sqlite3"
else:
    # Demonstração comercial sempre roda em SQLite local (launchers .bat) —
    # se o .env do ambiente de demo apontar para PostgreSQL por engano,
    # falha alto e cedo em vez de arriscar escrever no banco de produção.
    raise ImproperlyConfigured(
        "nexbuy.settings_demo espera DB_ENGINE=sqlite3 (ou variável ausente) — "
        "a demonstração comercial nunca deve apontar para um banco PostgreSQL "
        "compartilhado. Ajuste o .env usado pelos launchers de demo."
    )

# --------------------------------------------------------------------------
# Isolamento de mídia (uploads de logo/favicon da Identidade Visual)
# --------------------------------------------------------------------------

MEDIA_ROOT = BASE_DIR / "media_demo_cliente"

# --------------------------------------------------------------------------
# Modo Demonstração — controlado pelo LAUNCHER, não forçado aqui
# (Gate Final V2, Bloqueador P1): o cenário LIMPO/guiado deve reproduzir a
# experiência cliente-ready de verdade, SEM o badge "Modo Demonstração"
# (não há dado fictício nenhum nele); só o cenário PRONTO (seed_demo, dados
# fictícios) deve exibir o badge. Cada launcher define a variável de
# ambiente DEMO_MODE explicitamente (`set DEMO_MODE=False` no limpo,
# `set DEMO_MODE=True` no pronto) — a variável de ambiente do processo tem
# precedência sobre o .env (o `load_dotenv` de settings.py não sobrescreve
# variáveis já definidas). `settings.py` já lê `DEMO_MODE` do ambiente via
# `env_bool` e o star-import acima propaga esse valor — este comentário
# registra a decisão; nenhum override é necessário aqui.
# --------------------------------------------------------------------------

# --------------------------------------------------------------------------
# Esta demo roda só na máquina do apresentador (127.0.0.1) — nunca exposta
# publicamente, então nunca precisa de um ALLOWED_HOSTS mais amplo.
# --------------------------------------------------------------------------

ALLOWED_HOSTS = ["127.0.0.1", "localhost"]
