from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

from core import views as core_views
from core.limite_login import AdminLoginComLimiteForm, LoginComLimiteForm
from core import views_ajuda, views_apresentacao, views_healthcheck, views_primeiro_acesso

# Sprint de Melhorias 1 (segurança): limite de tentativas também no /admin.
admin.site.login_form = AdminLoginComLimiteForm

urlpatterns = [
    # Django Admin — uso técnico/suporte. O caminho vem de ADMIN_URL
    # (padrão "admin/"; em produção pode ser trocado no nexbuy.env).
    path(settings.ADMIN_URL, admin.site.urls),
    # Pronto para a Nuvem: verificação de saúde (sem login) usada pelo
    # instalador/atualizador da VPS e por monitores externos.
    path("healthz/", views_healthcheck.healthz, name="healthz"),
    # Nada para buscadores indexarem (mesmo texto do nginx da VPS; aqui
    # vale para hospedagens sem nginx próprio, como o PythonAnywhere).
    path("robots.txt", views_healthcheck.robots_txt, name="robots_txt"),
    # Primeiro Acesso Seguro (Etapa 02 — Cliente-Ready): único jeito de
    # colocar o NEXBUY de pé num banco vazio sem /admin, shell ou senha
    # publicada. Só fica disponível sem nenhum usuário/Empresa ativa.
    path("primeiro-acesso/", views_primeiro_acesso.primeiro_acesso, name="primeiro_acesso"),
    # Correção Final (Bloqueador 1): URL separada para o formulário de
    # cadastro — o token nunca chega perto desta rota, só a autorização
    # temporária concedida pela rota acima, guardada na sessão.
    path(
        "primeiro-acesso/cadastro/",
        views_primeiro_acesso.primeiro_acesso_cadastro,
        name="primeiro_acesso_cadastro",
    ),
    # Tela de apresentação do NEXBUY (Demo Experience 1.0, item 14) — no
    # nível raiz porque não pertence a nenhum app de domínio específico.
    path("bem-vindo/", core_views.bem_vindo, name="bem_vindo"),
    # Contexto por Empresa (Épico 9 — CORE 1.0): troca da empresa ativa
    # sem novo login.
    path("trocar-empresa/", core_views.trocar_empresa, name="trocar_empresa"),
    # Demo Comercial Showcase (Seção 7): logout real + login pré-preenchido.
    # A view devolve 404 fora do modo demo — a rota nunca "existe" no
    # ambiente cliente-ready.
    path("demo/trocar-perfil/", core_views.demo_trocar_perfil, name="demo_trocar_perfil"),
    # Sprint de Apresentação Comercial (Seções 5 e 9): abertura (com mapa
    # de valor) e encerramento — também 404 fora do modo demo.
    path("demo/apresentacao/", views_apresentacao.demo_apresentacao, name="demo_apresentacao"),
    path("demo/encerramento/", views_apresentacao.demo_encerramento, name="demo_encerramento"),
    path(
        "accounts/login/",
        auth_views.LoginView.as_view(
            template_name="registration/login.html", redirect_authenticated_user=True,
            authentication_form=LoginComLimiteForm,
        ),
        name="login",
    ),
    path("accounts/logout/", auth_views.LogoutView.as_view(next_page="login"), name="logout"),
    # Épico 2A (Etapas 01 e 08) — páginas transversais da nova navegação.
    path("perfil/", core_views.meu_perfil, name="meu_perfil"),
    path("buscar/", core_views.busca_global, name="busca_global"),
    path("relatorios/", core_views.relatorios_home, name="relatorios"),
    # Central de Ajuda: manual do sistema por perfil (login obrigatório).
    path("ajuda/", views_ajuda.central_ajuda, name="ajuda"),
    path("", include("dashboard.urls")),
    path("financeiro/", include("financeiro.urls")),
    path("compras/", include("compras.urls")),
    path("cadastros/", include("cadastros.urls")),
    path("gestao-compras/", include("gestao_compras.urls")),
    path("empresas/", include("empresas.urls")),
    path("notificacoes/", include("notificacoes.urls")),
    # NEXBUY Control Center (Épico 12 — CORE 1.0) e Assistente de
    # Implantação (Épico 13) — painel mestre e onboarding guiado.
    path("ncc/", include("empresas.ncc_urls")),
    # Épico 2A (Etapa 02): o Centro de Configurações é ÚNICO (/ncc/). A
    # landing antiga /configuracoes/ vira redirecionamento por perfil —
    # URL preservada, tela duplicada eliminada.
    path("configuracoes/", core_views.configuracoes_redirect, name="configuracoes_home"),
]

if settings.DEBUG:
    # Em produção, MEDIA_URL deve ser servido por um servidor de arquivos
    # dedicado (nginx, S3 etc.) — o Django nunca serve uploads em produção.
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Pronto para a Nuvem: páginas de erro próprias, renderizadas SEM request —
# nenhuma consulta ao banco (o 500 aparece mesmo com o banco fora do ar).
# Ver core/views_healthcheck.py.
handler400 = "core.views_healthcheck.erro_400"
handler403 = "core.views_healthcheck.erro_403"
handler404 = "core.views_healthcheck.erro_404"
handler500 = "core.views_healthcheck.erro_500"
