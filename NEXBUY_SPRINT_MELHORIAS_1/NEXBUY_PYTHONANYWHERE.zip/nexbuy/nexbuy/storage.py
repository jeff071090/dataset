"""Armazenamento de estáticos usado em produção (WhiteNoise + hashing).

`manifest_strict = False` evita que o site quebre com `ValueError` quando o
manifesto de estáticos (gerado por `collectstatic`) ainda não existe ou não
contém uma entrada específica — por exemplo, ao rodar `python manage.py
test` num checkout novo, antes de qualquer `collectstatic`. Nesse caso, a
tag `{% static %}` simplesmente serve o nome original (sem hash) em vez de
derrubar a requisição inteira — um site em produção de verdade sempre roda
`collectstatic` antes do deploy, então isso não afeta o comportamento real.
"""
from whitenoise.storage import CompressedManifestStaticFilesStorage


class NexbuyStaticFilesStorage(CompressedManifestStaticFilesStorage):
    manifest_strict = False
