# NEXBUY — Checklist 30 minutos antes da reunião

Marque na ordem. Se qualquer item falhar, a solução está no
`GUIA_RAPIDO_DEMO_NEXBUY.md` (Seção 6).

- [ ] **Reset** — rode `RESETAR_DEMO_NEXBUY.bat` e digite `SIM`
      (cenário volta ao estado inicial, com datas relativas a HOJE).
      Faça no DIA da reunião e, se puder, marque a reunião em dia útil:
      em sábado, domingo ou feriado o limite do dia é zero (regra do
      Calendário Operacional) — o Comprador abre em "Hoje não é dia de
      compra" e uma provisão para hoje vai direto para aprovação. (O reset
      num dia desses já não gera alerta de "Capacidade de hoje excedida":
      os pedidos "de hoje" do cenário ficam no último dia útil.)
- [ ] **Iniciar** — rode `INICIAR_DEMO_NEXBUY.bat`; aguarde o navegador
      abrir sozinho na tela de login.
- [ ] **Porta/URL** — anote o endereço mostrado na janela
      (ex.: `http://127.0.0.1:8000/`); deixe a janela de logs ABERTA e
      minimizada.
- [ ] **Login 1** — entre como `demo_proprietario` / `nexbuy123`;
      o Dashboard Executivo abre com KPIs preenchidos. No quadro
      "Resultado do mês", o mês corrente aparece com o selo **parcial**
      ("compras lançadas até DD/MM; lucro e margem provisórios") e, ao
      lado, o **Mês fechado** com alguns % de margem — é esse o número
      para comentar (fala de apoio na Cena 1 do roteiro). Se o "Tour guiado"
      abrir, clique **Pular** — o navegador lembra e ele não cobre as
      telas durante a reunião (para reapresentar: menu do nome →
      "Reiniciar tour").
- [ ] **Troca de perfil** — menu do nome → "Trocar perfil de demonstração"
      → Comprador; login volta preenchido; entre com `nexbuy123`.
- [ ] **Dados principais** — no Comprador: saldo do dia visível e
      Calendário de Compras com dias verdes + um dia cinza (bloqueado; perto
      do fim do mês ele fica no mês seguinte — use « Próximo mês »).
- [ ] **Análise Financeira** — troque para o Financeiro e abra o menu
      **Análise Financeira**: a DRE mostra receita, compras (em torno de
      60% da receita), margens e a curva de 12 meses com um mês no
      prejuízo; a aba **Saúde Financeira** tem indicadores em "Atenção" e
      recomendações. Antes do dia 25, confira o « mês anterior » — é o mês
      fechado que o Guia abre na Cena 6.
- [ ] **Volte ao Proprietário** (mesmo caminho de troca).
- [ ] **Integrações** — Configurações → Integrações mostra só o DDA, como
      "Não conectado — integração prevista" (é a Cena 8: receitas, custos e
      compras são lançamento manual). Depois SAIA (menu do nome → Sair).
- [ ] **Tela de abertura** — deixe `http://127.0.0.1:<porta>/demo/apresentacao/`
      na tela: é por ela que a apresentação começa ("Iniciar demonstração").
- [ ] **Tela cheia** — F11 no navegador; feche abas e notificações do
      Windows (Assistente de Foco ligado).
- [ ] **Resolução** — 1366×768 ou superior; zoom do navegador em 100%
      (Ctrl+0). Para a cena mobile: Ctrl+Shift+M no Chrome/Edge ou
      estreite a janela.
- [ ] **Roteiro na mão** — `ROTEIRO_DEMO_COMERCIAL_NEXBUY.md` aberto no
      celular ou impresso (decida antes: 5, 15 ou 30 minutos).

**Plano alternativo** — se a máquina falhar na hora:
1. Feche a janela do servidor e rode `INICIAR_DEMO_NEXBUY.bat` de novo
   (ele acha outra porta sozinho).
2. Persistindo, rode `PREPARAR_DEMO_NEXBUY.bat` e depois o INICIAR.
3. Último recurso: apresente pelas capturas do golden path ATUAL em
   `qa_showcase_screenshots\` (18 telas, numeradas pela cena do Guia:
   abertura, Dashboard com o Resultado do mês parcial + mês fechado,
   Comprador, aprovações, Agenda e Contas a Pagar, Análise Financeira —
   DRE, Créditos × Débitos e Saúde —, relatório por filial, Central de
   Auditoria, Integrações só com o DDA, celular e encerramento) e agende
   uma nova sessão ao vivo. As capturas foram feitas com o cenário do
   `seed_demo` (datas de fim de setembro/2026); use SÓ essa pasta — cópias
   antigas em outras pastas (`nexbuy_showcase\`, `nexbuy_apresentacao\`)
   mostram integrações que saíram do escopo.
