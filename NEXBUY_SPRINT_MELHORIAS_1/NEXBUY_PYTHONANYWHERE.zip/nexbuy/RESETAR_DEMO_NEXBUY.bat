@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ==================================================
echo   NEXBUY - RESETAR demonstracao comercial
echo ==================================================
echo.
echo Isto apaga SOMENTE os arquivos de demonstracao abaixo e recria o
echo cenario ficticio inicial da apresentacao:
echo   - db_demo_cliente.sqlite3
echo   - media_demo_cliente\
echo.
echo O banco principal (db.sqlite3) e a pasta media\ NUNCA sao tocados.
echo.

set "DB_DEMO=%cd%\db_demo_cliente.sqlite3"
set "MEDIA_DEMO=%cd%\media_demo_cliente"

REM --- Validacao defensiva: só os nomes exatos de demo podem ser apagados ---
echo %DB_DEMO%| findstr /e /i /c:"db_demo_cliente.sqlite3" >nul
if errorlevel 1 (
    echo [ERRO] Caminho do banco de demo nao confere com o esperado. Abortando por seguranca.
    pause
    exit /b 1
)
echo %MEDIA_DEMO%| findstr /e /i /c:"media_demo_cliente" >nul
if errorlevel 1 (
    echo [ERRO] Caminho da pasta de midia de demo nao confere com o esperado. Abortando por seguranca.
    pause
    exit /b 1
)

REM --- Confirmacao explicita -------------------------------------------------
set "CONFIRMA="
set /p CONFIRMA="Digite SIM (maiusculas) para confirmar o reset da demonstracao: "
if /I not "%CONFIRMA%"=="SIM" (
    echo.
    echo Operacao cancelada. Nada foi apagado.
    pause
    exit /b 0
)

if not exist "venv\Scripts\python.exe" (
    echo [ERRO] Ambiente virtual nao encontrado.
    echo Solucao: rode PREPARAR_DEMO_NEXBUY.bat primeiro.
    pause
    exit /b 1
)

echo.
if exist "%DB_DEMO%" (
    echo Apagando %DB_DEMO% ...
    del /f /q "%DB_DEMO%"
) else (
    echo Banco de demo nao existia [%DB_DEMO%] - nada a apagar.
)
if exist "%MEDIA_DEMO%" (
    echo Apagando %MEDIA_DEMO% ...
    rmdir /s /q "%MEDIA_DEMO%"
) else (
    echo Pasta de midia de demo nao existia [%MEDIA_DEMO%] - nada a apagar.
)

REM DEBUG=True somente para o processo deste terminal (nunca gravado em .env).
set DEBUG=True
set DEMO_MODE=True

echo.
echo Recriando o banco de demo e o cenario inicial da apresentacao...
venv\Scripts\python.exe manage.py migrate --noinput --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao recriar o banco de demo - veja a causa acima.
    pause
    exit /b 1
)
venv\Scripts\python.exe manage.py seed_demo --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao recriar o cenario ficticio - veja a causa acima.
    pause
    exit /b 1
)

echo.
echo ==================================================
echo   RESET CONCLUIDO: cenario inicial da apresentacao restaurado.
echo   (Idempotente: rodar de novo recria exatamente o mesmo cenario.)
echo   Proximo passo: INICIAR_DEMO_NEXBUY.bat
echo ==================================================
pause
