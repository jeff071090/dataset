@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo   NEXBUY - Resetar banco de Demonstracao
echo ============================================
echo.
echo Isto apaga SOMENTE os arquivos de demo abaixo (nunca o banco/midia
echo principal do NEXBUY):
echo   - db_demo_cliente.sqlite3
echo   - media_demo_cliente\
echo.
echo O banco principal (db.sqlite3) e a pasta media\ NUNCA sao tocados por
echo este script.
echo.

set "DB_DEMO=%cd%\db_demo_cliente.sqlite3"
set "MEDIA_DEMO=%cd%\media_demo_cliente"

REM --- Validacao defensiva ----------------------------------------------------
REM Confere que os caminhos que vamos apagar realmente terminam nos nomes
REM exatos de demo, antes de qualquer exclusao. Nunca um "del *.sqlite3" ou
REM glob amplo - sempre o nome exato do arquivo/pasta de demo.
echo %DB_DEMO%| findstr /e /i /c:"db_demo_cliente.sqlite3" >nul
if errorlevel 1 (
    echo [ERRO] Caminho do banco de demo nao confere com o esperado. Abortando por seguranca.
    pause
    exit /b 1
)
echo %MEDIA_DEMO%| findstr /e /i /c:"media_demo_cliente" >nul
if errorlevel 1 (
    echo [ERRO] Caminho da pasta de midia de demo nao confere com o esperado. Abortando por seguranca.
    pause
    exit /b 1
)

REM --- Confirmacao explicita ---------------------------------------------------
set "CONFIRMA="
set /p CONFIRMA="Digite SIM (maiusculas) para confirmar a exclusao do banco de demo: "
if /I not "%CONFIRMA%"=="SIM" (
    echo.
    echo Operacao cancelada. Nada foi apagado.
    pause
    exit /b 0
)

echo.
REM Gate Final V2: parenteses NUNCA podem aparecer sem escape dentro de um
REM bloco if/else do cmd - a versao anterior tinha "(%DB_DEMO%)" no echo do
REM else, o que quebrava o PARSE do bloco inteiro ("- foi inesperado neste
REM momento") e abortava o script sem apagar nada. Bug real, encontrado
REM executando o .bat de verdade no Windows 11. Corrigido com colchetes.
if exist "%DB_DEMO%" (
    echo Apagando %DB_DEMO% ...
    del /f /q "%DB_DEMO%"
) else (
    echo Banco de demo nao existia [%DB_DEMO%] - nada a apagar.
)

if exist "%MEDIA_DEMO%" (
    echo Apagando %MEDIA_DEMO% ...
    rmdir /s /q "%MEDIA_DEMO%"
) else (
    echo Pasta de midia de demo nao existia [%MEDIA_DEMO%] - nada a apagar.
)

echo.
echo Recriando o banco de demo vazio...
set DEBUG=True
if not exist "venv\Scripts\python.exe" (
    echo [ERRO] venv\Scripts\python.exe nao encontrado. Rode iniciar_demo_cliente_limpa.bat
    echo ou iniciar_demo_cenario_pronto.bat pelo menos uma vez antes de resetar.
    pause
    exit /b 1
)
venv\Scripts\python.exe manage.py migrate --noinput --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao recriar o banco de demo.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Banco de demo resetado (vazio) com sucesso.
echo   Use iniciar_demo_cliente_limpa.bat para o cenario guiado, ou
echo   iniciar_demo_cenario_pronto.bat para recriar o cenario pronto.
echo ============================================
pause
