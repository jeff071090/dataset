from django.urls import path

from . import views

app_name = "cadastros"

urlpatterns = [
    path("categorias/", views.CategoriaListView.as_view(), name="categoria_list"),
    path("categorias/nova/", views.CategoriaCreateView.as_view(), name="categoria_create"),
    path("categorias/<int:pk>/editar/", views.CategoriaUpdateView.as_view(), name="categoria_update"),
    path("categorias/<int:pk>/excluir/", views.categoria_excluir, name="categoria_excluir"),
    path("categorias/<int:pk>/reativar/", views.categoria_reativar, name="categoria_reativar"),
    path("centros-custo/", views.CentroCustoListView.as_view(), name="centrocusto_list"),
    path("centros-custo/novo/", views.CentroCustoCreateView.as_view(), name="centrocusto_create"),
    path("centros-custo/<int:pk>/editar/", views.CentroCustoUpdateView.as_view(), name="centrocusto_update"),
    path("centros-custo/<int:pk>/excluir/", views.centrocusto_excluir, name="centrocusto_excluir"),
    path("centros-custo/<int:pk>/reativar/", views.centrocusto_reativar, name="centrocusto_reativar"),
]
