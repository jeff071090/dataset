from django.contrib import admin

from .models import CentroCusto, Categoria


@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ("nome", "empresa", "ativo")
    list_filter = ("empresa", "ativo")
    search_fields = ("nome",)


@admin.register(CentroCusto)
class CentroCustoAdmin(admin.ModelAdmin):
    list_display = ("nome", "empresa", "ativo")
    list_filter = ("empresa", "ativo")
    search_fields = ("nome",)
