"""Cadastros administrativos compartilhados: Categoria e Centro de Custo.

Ambos são escopados por empresa (assim como Fornecedor e Filial), para que
cada empresa do NEXBUY possa manter sua própria lista sem interferir nas
demais — mesmo padrão multiempresa já usado no restante do sistema.
"""
from django.db import models

from core.models import ModeloAtivavel, TimeStampedModel
from empresas.models import Empresa


class Categoria(TimeStampedModel, ModeloAtivavel):
    """`ativo` (herdado de `ModeloAtivavel`) já cobre o "Status" pedido pela
    Sprint 6 (item 8) — não foi criado um segundo campo para a mesma coisa."""

    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="categorias", verbose_name="Empresa"
    )
    nome = models.CharField("Nome", max_length=100)
    categoria_pai = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="subcategorias", verbose_name="Categoria pai",
        help_text="Deixe em branco para uma categoria de nível superior; preencha para torná-la uma subcategoria.",
    )
    icone = models.CharField(
        "Ícone", max_length=40, blank=True,
        help_text='Classe do Bootstrap Icons, ex.: "bi-tags-fill".',
    )
    cor = models.CharField("Cor", max_length=7, blank=True)

    class Meta:
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"
        ordering = ["nome"]
        constraints = [
            models.UniqueConstraint(fields=["empresa", "nome"], name="categoria_unica_por_empresa")
        ]

    def __str__(self):
        return self.nome


class CentroCusto(TimeStampedModel, ModeloAtivavel):
    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="centros_custo", verbose_name="Empresa"
    )
    nome = models.CharField("Nome", max_length=100)

    class Meta:
        verbose_name = "Centro de Custo"
        verbose_name_plural = "Centros de Custo"
        ordering = ["nome"]
        constraints = [
            models.UniqueConstraint(fields=["empresa", "nome"], name="centro_custo_unico_por_empresa")
        ]

    def __str__(self):
        return self.nome
