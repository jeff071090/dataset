from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView

from core.contexto import empresa_ativa
from core.mixins import EmpresaScopedFormMixin, EmpresaScopedListMixin
from core.permissions import PERFIS_GESTORES_FINANCEIROS, PerfilRequiredMixin, perfil_required

from .forms import CategoriaForm, CentroCustoForm
from .models import CentroCusto, Categoria

PERFIS_GESTAO_CADASTROS = PERFIS_GESTORES_FINANCEIROS


# --------------------------------------------------------------------------
# Categorias
# --------------------------------------------------------------------------


class CategoriaListView(PerfilRequiredMixin, EmpresaScopedListMixin, ListView):
    model = Categoria
    template_name = "cadastros/categoria_list.html"
    context_object_name = "categorias"
    perfis_permitidos = PERFIS_GESTAO_CADASTROS


class CategoriaCreateView(PerfilRequiredMixin, EmpresaScopedFormMixin, CreateView):
    model = Categoria
    form_class = CategoriaForm
    template_name = "cadastros/categoria_form.html"
    success_url = reverse_lazy("cadastros:categoria_list")
    perfis_permitidos = PERFIS_GESTAO_CADASTROS
    extra_context = {"titulo": "Nova Categoria"}

    def form_valid(self, form):
        messages.success(self.request, "Categoria cadastrada com sucesso.")
        return super().form_valid(form)


class CategoriaUpdateView(PerfilRequiredMixin, EmpresaScopedFormMixin, UpdateView):
    model = Categoria
    form_class = CategoriaForm
    template_name = "cadastros/categoria_form.html"
    success_url = reverse_lazy("cadastros:categoria_list")
    perfis_permitidos = PERFIS_GESTAO_CADASTROS
    extra_context = {"titulo": "Editar Categoria"}

    def get_queryset(self):
        # Sprint de Consolidação (Gate 2A, P0-5): empresa ATIVA do
        # contexto, não a "de casa" do usuário — ver mesma correção em
        # FornecedorUpdateView (compras/views.py).
        return Categoria.objects.filter(empresa=empresa_ativa(self.request))

    def form_valid(self, form):
        messages.success(self.request, "Categoria atualizada com sucesso.")
        return super().form_valid(form)


@perfil_required(*PERFIS_GESTAO_CADASTROS)
def categoria_excluir(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk, empresa=empresa_ativa(request))
    if request.method == "POST":
        categoria.ativo = False
        categoria.save(update_fields=["ativo", "atualizado_em"])
        messages.success(request, f'Categoria "{categoria.nome}" desativada.')
    return redirect("cadastros:categoria_list")


@perfil_required(*PERFIS_GESTAO_CADASTROS)
def categoria_reativar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk, empresa=empresa_ativa(request))
    if request.method == "POST":
        categoria.ativo = True
        categoria.save(update_fields=["ativo", "atualizado_em"])
        messages.success(request, f'Categoria "{categoria.nome}" reativada.')
    return redirect("cadastros:categoria_list")


# --------------------------------------------------------------------------
# Centros de Custo
# --------------------------------------------------------------------------


class CentroCustoListView(PerfilRequiredMixin, EmpresaScopedListMixin, ListView):
    model = CentroCusto
    template_name = "cadastros/centrocusto_list.html"
    context_object_name = "centros_custo"
    perfis_permitidos = PERFIS_GESTAO_CADASTROS


class CentroCustoCreateView(PerfilRequiredMixin, EmpresaScopedFormMixin, CreateView):
    model = CentroCusto
    form_class = CentroCustoForm
    template_name = "cadastros/centrocusto_form.html"
    success_url = reverse_lazy("cadastros:centrocusto_list")
    perfis_permitidos = PERFIS_GESTAO_CADASTROS
    extra_context = {"titulo": "Novo Centro de Custo"}

    def form_valid(self, form):
        messages.success(self.request, "Centro de custo cadastrado com sucesso.")
        return super().form_valid(form)


class CentroCustoUpdateView(PerfilRequiredMixin, EmpresaScopedFormMixin, UpdateView):
    model = CentroCusto
    form_class = CentroCustoForm
    template_name = "cadastros/centrocusto_form.html"
    success_url = reverse_lazy("cadastros:centrocusto_list")
    perfis_permitidos = PERFIS_GESTAO_CADASTROS
    extra_context = {"titulo": "Editar Centro de Custo"}

    def get_queryset(self):
        # Sprint de Consolidação (Gate 2A, P0-5): empresa ATIVA do
        # contexto, não a "de casa" do usuário — ver mesma correção em
        # FornecedorUpdateView (compras/views.py).
        return CentroCusto.objects.filter(empresa=empresa_ativa(self.request))

    def form_valid(self, form):
        messages.success(self.request, "Centro de custo atualizado com sucesso.")
        return super().form_valid(form)


@perfil_required(*PERFIS_GESTAO_CADASTROS)
def centrocusto_excluir(request, pk):
    centro = get_object_or_404(CentroCusto, pk=pk, empresa=empresa_ativa(request))
    if request.method == "POST":
        centro.ativo = False
        centro.save(update_fields=["ativo", "atualizado_em"])
        messages.success(request, f'Centro de custo "{centro.nome}" desativado.')
    return redirect("cadastros:centrocusto_list")


@perfil_required(*PERFIS_GESTAO_CADASTROS)
def centrocusto_reativar(request, pk):
    centro = get_object_or_404(CentroCusto, pk=pk, empresa=empresa_ativa(request))
    if request.method == "POST":
        centro.ativo = True
        centro.save(update_fields=["ativo", "atualizado_em"])
        messages.success(request, f'Centro de custo "{centro.nome}" reativado.')
    return redirect("cadastros:centrocusto_list")
