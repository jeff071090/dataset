from django import forms

from core.forms import BootstrapFormMixin

from .models import CentroCusto, Categoria


class EmpresaScopedForm(BootstrapFormMixin, forms.ModelForm):
    """Form base que valida nome único dentro da empresa do contexto.

    CORE 1.0 (Épico 9): aceita a empresa ativa explícita (`empresa`);
    sem ela, cai na empresa principal do usuário — o comportamento de
    sempre para chamadores antigos."""

    def __init__(self, *args, user=None, empresa=None, **kwargs):
        self.user = user
        self.empresa = empresa or (user.empresa if user is not None else None)
        super().__init__(*args, **kwargs)

    def clean_nome(self):
        nome = self.cleaned_data["nome"].strip()
        if self.empresa is not None:
            duplicado = (
                self._meta.model.objects.filter(empresa=self.empresa, nome__iexact=nome)
                .exclude(pk=self.instance.pk)
                .exists()
            )
            if duplicado:
                raise forms.ValidationError("Já existe um registro com este nome nesta empresa.")
        return nome

    def save(self, commit=True):
        instance = super().save(commit=False)
        if self.empresa is not None:
            instance.empresa = self.empresa
        if commit:
            instance.save()
        return instance


class CategoriaForm(EmpresaScopedForm):
    class Meta:
        model = Categoria
        fields = ["nome", "categoria_pai", "icone", "cor", "ativo"]
        widgets = {
            "cor": forms.TextInput(attrs={"type": "color", "class": "form-control form-control-color"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["categoria_pai"].required = False
        qs = Categoria.objects.none()
        if self.empresa is not None:
            qs = Categoria.objects.filter(empresa=self.empresa, ativo=True)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
        self.fields["categoria_pai"].queryset = qs


class CentroCustoForm(EmpresaScopedForm):
    class Meta:
        model = CentroCusto
        fields = ["nome", "ativo"]
