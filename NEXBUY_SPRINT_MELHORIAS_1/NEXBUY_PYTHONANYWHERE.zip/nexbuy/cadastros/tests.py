"""Testes do app `cadastros` (Sprint 6 — Categoria com subcategoria/ícone/cor).

Este app ainda não tinha nenhum teste automatizado.

Rode com: python manage.py test cadastros
"""
from django.test import Client, TestCase
from django.test.utils import override_settings

from core.contexto import CHAVE_SESSAO_EMPRESA
from empresas.models import Empresa, GrupoEmpresarial
from usuarios.models import Usuario, UsuarioEmpresa

from .models import CentroCusto, Categoria


class CategoriaSubcategoriaTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Cadastros", cnpj="55.111.000/0001-55")
        self.financeiro = Usuario.objects.create_user(
            username="fin_cad", password="x", perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa,
        )
        self.medicamentos = Categoria.objects.create(empresa=self.empresa, nome="Medicamentos")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_criar_subcategoria_com_icone_e_cor(self):
        client = Client()
        client.force_login(self.financeiro)
        response = client.post("/cadastros/categorias/nova/", {
            "nome": "Genéricos",
            "categoria_pai": self.medicamentos.pk,
            "icone": "bi-capsule",
            "cor": "#1CA971",
            "ativo": "on",
        })
        self.assertEqual(response.status_code, 302)

        subcategoria = Categoria.objects.get(nome="Genéricos")
        self.assertEqual(subcategoria.categoria_pai, self.medicamentos)
        self.assertEqual(subcategoria.icone, "bi-capsule")
        self.assertEqual(subcategoria.cor, "#1CA971")

    def test_categoria_sem_pai_e_permitida(self):
        subcategoria = Categoria.objects.create(empresa=self.empresa, nome="Higiene")
        self.assertIsNone(subcategoria.categoria_pai)

    def test_subcategorias_related_name(self):
        sub = Categoria.objects.create(
            empresa=self.empresa, nome="Genéricos B", categoria_pai=self.medicamentos,
        )
        self.assertIn(sub, self.medicamentos.subcategorias.all())


class CoerenciaMultiempresaCadastrosTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, P0-5): editar/excluir/reativar
    Categoria e Centro de Custo precisam respeitar a EMPRESA ATIVA do
    contexto — nunca `request.user.empresa` fixo. Mesma correção e mesmo
    motivo de `CoerenciaMultiempresaFornecedorTestCase` (compras/tests.py):
    a listagem já usava a empresa ativa, mas editar/excluir um registro
    que ela mesma mostrava devolvia 404 quando o contexto ativo não era a
    empresa "de casa" do usuário."""

    def setUp(self):
        self.empresa_a = Empresa.objects.create(nome="Empresa A", cnpj="10.000.001/0001-10")
        self.empresa_b = Empresa.objects.create(nome="Empresa B", cnpj="20.000.001/0001-20")
        self.empresa_intrusa = Empresa.objects.create(nome="Intrusa", cnpj="30.000.001/0001-30")

        self.categoria_b = Categoria.objects.create(empresa=self.empresa_b, nome="Categoria B")
        self.categoria_intrusa = Categoria.objects.create(empresa=self.empresa_intrusa, nome="Categoria Intrusa")
        self.centro_b = CentroCusto.objects.create(empresa=self.empresa_b, nome="Centro B")

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_multiempresa_cad", password="x",
            perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa_a,
        )
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def _trocar_para_empresa_b(self):
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_categoria_da_empresa_ativa_autorizada_funciona(self):
        self._trocar_para_empresa_b()
        resposta = self.client.get(f"/cadastros/categorias/{self.categoria_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 200)

        resposta = self.client.post(
            f"/cadastros/categorias/{self.categoria_b.pk}/editar/", {"nome": "Categoria B Renomeada"}
        )
        self.assertEqual(resposta.status_code, 302)
        self.categoria_b.refresh_from_db()
        self.assertEqual(self.categoria_b.nome, "Categoria B Renomeada")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_e_reativar_categoria_da_empresa_ativa_funciona(self):
        self._trocar_para_empresa_b()
        resposta = self.client.post(f"/cadastros/categorias/{self.categoria_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 302)
        self.categoria_b.refresh_from_db()
        self.assertFalse(self.categoria_b.ativo)

        resposta = self.client.post(f"/cadastros/categorias/{self.categoria_b.pk}/reativar/")
        self.assertEqual(resposta.status_code, 302)
        self.categoria_b.refresh_from_db()
        self.assertTrue(self.categoria_b.ativo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_categoria_de_empresa_nao_ativa_continua_inacessivel(self):
        resposta = self.client.get(f"/cadastros/categorias/{self.categoria_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_categoria_de_empresa_nao_autorizada_nunca_e_acessivel(self):
        self._trocar_para_empresa_b()
        resposta = self.client.get(f"/cadastros/categorias/{self.categoria_intrusa.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_centro_de_custo_da_empresa_ativa_autorizada_funciona(self):
        self._trocar_para_empresa_b()
        resposta = self.client.get(f"/cadastros/centros-custo/{self.centro_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 200)

        resposta = self.client.post(
            f"/cadastros/centros-custo/{self.centro_b.pk}/editar/", {"nome": "Centro B Renomeado"}
        )
        self.assertEqual(resposta.status_code, 302)
        self.centro_b.refresh_from_db()
        self.assertEqual(self.centro_b.nome, "Centro B Renomeado")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_centro_de_custo_de_empresa_nao_ativa_continua_inacessivel(self):
        resposta = self.client.post(f"/cadastros/centros-custo/{self.centro_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)


class CategoriaCrossGrupoTestCase(TestCase):
    """Fechamento Final, Seção 4.3: variante cross-GRUPO (não só
    cross-empresa) de `CoerenciaMultiempresaCadastrosTestCase`. Duas
    `GrupoEmpresarial` distintas, cada uma com sua Empresa, e uma
    autorização `UsuarioEmpresa` ATIVA cruzando os dois Grupos (simulando
    dado legado/inconsistente). Mesma lógica já provada em
    `usuarios/tests.py::ContextoPorEmpresaTestCase::
    test_empresas_disponiveis_nunca_inclui_autorizacao_de_outro_grupo`,
    agora provada na URL real da tela de Categoria: a autorização sozinha
    não basta — o Grupo diferente bloqueia por cima, tanto na troca de
    contexto quanto no acesso direto à Categoria."""

    def setUp(self):
        self.grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo 1")
        self.grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo 2")

        self.empresa_a = Empresa.objects.create(
            nome="Empresa A do Grupo 1", cnpj="40.000.001/0001-40", grupo=self.grupo_1,
        )
        self.empresa_b = Empresa.objects.create(
            nome="Empresa B do Grupo 2", cnpj="50.000.001/0001-50", grupo=self.grupo_2,
        )
        self.categoria_b = Categoria.objects.create(empresa=self.empresa_b, nome="Categoria Cross Grupo")

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_cross_grupo_cad", password="x",
            perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa_a,
        )
        # Autorização ATIVA cruzando os dois Grupos — simula dado
        # legado/inconsistente: o registro existe e está ativo, mas a
        # Empresa autorizada pertence a um Grupo comprovadamente diferente
        # do Grupo da empresa principal do usuário.
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_trocar_para_empresa_de_outro_grupo_nao_e_efetivado(self):
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)
        self.assertNotEqual(self.client.session.get(CHAVE_SESSAO_EMPRESA), self.empresa_b.pk)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_categoria_de_outro_grupo_continua_404_mesmo_com_autorizacao_ativa(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})

        resposta = self.client.get(f"/cadastros/categorias/{self.categoria_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)

        resposta = self.client.post(
            f"/cadastros/categorias/{self.categoria_b.pk}/editar/", {"nome": "Categoria Cross Grupo Renomeada"}
        )
        self.assertEqual(resposta.status_code, 404)
        self.categoria_b.refresh_from_db()
        self.assertEqual(self.categoria_b.nome, "Categoria Cross Grupo")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_categoria_de_outro_grupo_continua_404_mesmo_com_autorizacao_ativa(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})

        resposta = self.client.post(f"/cadastros/categorias/{self.categoria_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)
        self.categoria_b.refresh_from_db()
        self.assertTrue(self.categoria_b.ativo)
