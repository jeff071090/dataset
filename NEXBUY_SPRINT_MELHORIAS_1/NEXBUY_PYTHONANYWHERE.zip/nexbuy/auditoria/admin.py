from django.contrib import admin

from .models import RegistroAuditoria


@admin.register(RegistroAuditoria)
class RegistroAuditoriaAdmin(admin.ModelAdmin):
    """Gate pré-Etapa 10 (S1-3, item 4): "Proíba edição/exclusão pela
    interface e deixe eventual Admin somente leitura" — `readonly_fields`
    sozinho não bastava (só trava os CAMPOS; a tela de "adicionar" e o
    botão "excluir" continuavam disponíveis). As três permissões abaixo
    fecham isso: sem view de criação, sem salvar edição, sem excluir —
    só listar e abrir para leitura, mesmo espírito append-only do model."""

    list_display = (
        "criado_em", "categoria", "modulo", "acao", "resultado", "empresa", "filial",
        "usuario", "descricao", "autoaprovacao", "ip",
    )
    list_filter = ("categoria", "modulo", "resultado", "origem_decisao", "autoaprovacao", "empresa")
    search_fields = ("descricao", "correlation_id", "tipo_objeto")
    readonly_fields = [campo.name for campo in RegistroAuditoria._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
