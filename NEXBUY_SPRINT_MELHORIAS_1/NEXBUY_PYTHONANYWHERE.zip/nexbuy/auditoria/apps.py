from django.apps import AppConfig


class AuditoriaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "auditoria"
    verbose_name = "Central de Auditoria"

    def ready(self):
        from . import signals  # noqa: F401
