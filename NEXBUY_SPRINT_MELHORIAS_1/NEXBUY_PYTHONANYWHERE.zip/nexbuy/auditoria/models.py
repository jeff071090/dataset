from django.conf import settings
from django.db import models

from core.models import TimeStampedModel


class RegistroAuditoria(TimeStampedModel):
    """Central de Auditoria (Fechamento Final, Seção 8): trilha append-only
    de eventos que hoje NÃO têm nenhum registro em `HistoricoCompra`,
    `HistoricoProvisao` ou `LogConfiguracao` — o gap mais evidente é
    login/logout/tentativa de login, que hoje não fica registrado em lugar
    nenhum do sistema. ADITIVO: os três mecanismos existentes continuam
    intactos, cada um cobrindo o próprio domínio de negócio; este modelo
    cobre eventos transversais de segurança/acesso, e a tela da Central de
    Auditoria (NCC) une os quatro numa única visão com filtro e paginação.

    Gate pré-Etapa 10 (S1-3): o contrato original do Prompt 1 pedia mais do
    que login/logout — `filial`, `modulo`/`acao`/`resultado`,
    `tipo_objeto`/`id_objeto`, `estado_antes`/`estado_depois`,
    `justificativa`, `origem_decisao`, `correlation_id` e `autoaprovacao`.
    `categoria` continua existindo (login/logout, já usada por todo o
    código e testes existentes) — os campos novos são a classificação
    estruturada e genérica para QUALQUER evento crítico, não só segurança.

    Nunca é editado nem apagado pela aplicação depois de criado (mesmo
    espírito append-only de `LogConfiguracao`, reforçado aqui via admin
    read-only) — é sempre `usuario` (não `request.user` direto) porque
    tentativas de login falho não têm um usuário autenticado."""

    class Categoria(models.TextChoices):
        LOGIN_SUCESSO = "login_sucesso", "Login realizado"
        LOGIN_FALHO = "login_falho", "Tentativa de login falhou"
        LOGOUT = "logout", "Logout realizado"
        PROVISAO_CRIADA = "provisao_criada", "Provisão criada"
        PROVISAO_APROVADA = "provisao_aprovada", "Provisão aprovada"
        PROVISAO_REJEITADA = "provisao_rejeitada", "Provisão rejeitada"
        PROVISAO_AJUSTES = "provisao_ajustes", "Provisão — ajustes solicitados"
        PROVISAO_EFETIVADA = "provisao_efetivada", "Provisão efetivada em Compra"
        COMPRA_LANCADA = "compra_lancada", "Compra lançada"
        COMPRA_BLOQUEADA = "compra_bloqueada", "Compra bloqueada na origem"
        FILIAL_CRIADA = "filial_criada", "Filial criada"
        FILIAL_EDITADA = "filial_editada", "Filial editada"
        # Prompt 2 (pré-Etapa 02), Gate D (Seção 9) — usuários e acesso.
        USUARIO_CRIADO = "usuario_criado", "Usuário criado"
        USUARIO_EDITADO = "usuario_editado", "Usuário editado"
        USUARIO_STATUS_ALTERADO = "usuario_status_alterado", "Usuário ativado/desativado"
        USUARIO_PERFIL_ALTERADO = "usuario_perfil_alterado", "Perfil do usuário alterado"
        USUARIO_PERMISSOES_ALTERADAS = "usuario_permissoes_alteradas", "Permissões/perfis de acesso do usuário alterados"
        USUARIO_EMPRESA_ALTERADA = "usuario_empresa_alterada", "Autorização de Empresa do usuário alterada"
        USUARIO_FILIAL_ALTERADA = "usuario_filial_alterada", "Vínculos de Filial do usuário alterados"
        USUARIO_FILIAL_PRINCIPAL_ALTERADA = "usuario_filial_principal_alterada", "Filial principal do usuário alterada"
        LIMITE_COMPRADOR_ALTERADO = "limite_comprador_alterado", "Limite individual do comprador alterado"
        COMPRADOR_BLOQUEADO = "comprador_bloqueado", "Comprador bloqueado"
        COMPRADOR_LIBERADO = "comprador_liberado", "Comprador liberado"
        # Empresa, Filial e configuração.
        EMPRESA_CRIADA = "empresa_criada", "Empresa criada"
        EMPRESA_EDITADA = "empresa_editada", "Empresa editada"
        CONFIGURACAO_PLATAFORMA_ALTERADA = "configuracao_plataforma_alterada", "Configuração da plataforma alterada"
        AUTOAPROVACAO_ALTERADA = "autoaprovacao_alterada", "Autoaprovação controlada ligada/desligada"
        CONFIGURACAO_FINANCEIRA_ALTERADA = "configuracao_financeira_alterada", "Configuração financeira alterada"
        WORKFLOW_ALTERADO = "workflow_alterado", "Fluxo de aprovação/etapas alterado"
        DIA_OPERACIONAL_ALTERADO = "dia_operacional_alterado", "Dia bloqueado/especial do calendário alterado"
        # Financeiro.
        RECEITA_ALTERADA = "receita_alterada", "Receita criada/editada/excluída"
        CUSTO_FIXO_ALTERADO = "custo_fixo_alterado", "Custo Fixo criado/editado/ativado/desativado"
        CUSTO_VARIAVEL_ALTERADO = "custo_variavel_alterado", "Custo Variável criado/editado/excluído"
        PARCELA_BAIXADA = "parcela_baixada", "Parcela marcada como paga"
        PARCELA_ESTORNADA = "parcela_estornada", "Parcela estornada (baixa revertida)"
        # Etapa 02 (Cliente-Ready) — bootstrap do ambiente sem admin/shell.
        PRIMEIRO_ACESSO_CONCLUIDO = "primeiro_acesso_concluido", "Primeiro acesso concluído (implantação inicial)"
        # Sprint de Correção do Checklist Guiado: 2 dos 13 itens do
        # checklist (empresas/services_checklist.py) nunca conseguiam ficar
        # concluídos por desenho — estas duas categorias novas são os sinais
        # reais, no banco, que corrigem isso (itens 10 e 13).
        CALENDARIO_OPERACIONAL_REVISADO = (
            "calendario_operacional_revisado",
            "Calendário operacional revisado e confirmado pelo Proprietário",
        )
        RELATORIO_VISUALIZADO = "relatorio_visualizado", "Relatório visualizado pela primeira vez"

    class Resultado(models.TextChoices):
        SUCESSO = "sucesso", "Sucesso"
        FALHA = "falha", "Falha"
        BLOQUEADO = "bloqueado", "Bloqueado"
        PENDENTE = "pendente", "Pendente"

    class OrigemDecisao(models.TextChoices):
        MANUAL = "manual", "Decisão manual"
        AUTOMATICA = "automatica", "Autoaprovação (automática)"
        SISTEMA = "sistema", "Processo do sistema"

    empresa = models.ForeignKey(
        "empresas.Empresa",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="registros_auditoria",
        verbose_name="Empresa",
    )
    filial = models.ForeignKey(
        "filiais.Filial",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="registros_auditoria",
        verbose_name="Filial",
    )
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name="Usuário",
    )
    # Prompt 2 (pré-Etapa 02), Gate D (Seção 8): snapshot do usuário NO
    # MOMENTO do evento — o FK acima é `SET_NULL` (some se o usuário for
    # excluído), e mesmo sem exclusão, renomear ou trocar o perfil de um
    # usuário não pode reescrever silenciosamente a história de eventos
    # passados. Preenchidos automaticamente por `registrar_evento()`,
    # nunca editados depois.
    usuario_nome = models.CharField(
        "Nome do usuário (no momento do evento)", max_length=150, blank=True,
    )
    usuario_perfil = models.CharField(
        "Perfil do usuário (no momento do evento)", max_length=20, blank=True,
    )
    categoria = models.CharField("Categoria", max_length=40, choices=Categoria.choices)
    descricao = models.CharField("Descrição", max_length=255)
    ip = models.GenericIPAddressField("Endereço IP", null=True, blank=True)

    # --- Contrato completo do Prompt 1 (Gate pré-Etapa 10, S1-3) --------
    modulo = models.CharField(
        "Módulo", max_length=30, blank=True,
        help_text="Área de negócio do evento (ex.: seguranca, provisoes, compras, filiais).",
    )
    acao = models.CharField(
        "Ação", max_length=40, blank=True,
        help_text="Ação executada (ex.: criar, aprovar, rejeitar, efetivar, editar).",
    )
    resultado = models.CharField(
        "Resultado", max_length=20, choices=Resultado.choices, default=Resultado.SUCESSO,
    )
    tipo_objeto = models.CharField(
        "Tipo do objeto", max_length=40, blank=True,
        help_text="Nome do model afetado (ex.: Provisao, Compra, Filial).",
    )
    id_objeto = models.PositiveIntegerField("ID do objeto", null=True, blank=True)
    estado_antes = models.JSONField(
        "Estado antes", null=True, blank=True,
        help_text="Apenas campos de negócio relevantes — nunca senha, token, cookie ou payload bruto.",
    )
    estado_depois = models.JSONField(
        "Estado depois", null=True, blank=True,
        help_text="Apenas campos de negócio relevantes — nunca senha, token, cookie ou payload bruto.",
    )
    justificativa = models.TextField("Justificativa", blank=True)
    origem_decisao = models.CharField(
        "Origem da decisão", max_length=20, choices=OrigemDecisao.choices, default=OrigemDecisao.MANUAL,
    )
    correlation_id = models.CharField(
        "ID de correlação", max_length=36, blank=True,
        help_text="Liga eventos do mesmo fluxo de negócio (ex.: Provisão → Compra → Parcelas).",
    )
    autoaprovacao = models.BooleanField(
        "Autoaprovação", default=False,
        help_text="True quando a decisão foi tomada automaticamente pela regra de autoaprovação, sem humano no meio.",
    )

    class Meta:
        verbose_name = "Registro de Auditoria"
        verbose_name_plural = "Registros de Auditoria"
        ordering = ["-criado_em"]
        indexes = [
            models.Index(fields=["empresa", "criado_em"], name="auditoria_empresa_criado_idx"),
            models.Index(fields=["categoria", "criado_em"], name="auditoria_categoria_criado_idx"),
            models.Index(fields=["filial", "criado_em"], name="auditoria_filial_criado_idx"),
            models.Index(fields=["correlation_id"], name="auditoria_correlation_idx"),
            models.Index(fields=["modulo", "criado_em"], name="auditoria_modulo_criado_idx"),
        ]

    def __str__(self):
        return f"{self.get_categoria_display()} — {self.descricao}"
