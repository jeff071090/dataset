"""Central de Auditoria (Fechamento Final, Seção 8; Gate pré-Etapa 10,
S1-3: contrato completo do Prompt 1).

`registrar_evento` é a única forma de criar um `RegistroAuditoria` — mesmo
padrão de `registrar_historico`/`registrar_historico_compra` (uma função
central, sem lógica de negócio fora dela). `listar_eventos_auditoria` une
os QUATRO mecanismos de auditoria do sistema (os três já existentes mais
este novo) numa lista só, ordenada e paginável, para a tela do NCC — sem
alterar em nada os três originais.
"""
import ipaddress
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from django.conf import settings
from django.core.paginator import Paginator

from .models import RegistroAuditoria


def novo_correlation_id() -> str:
    """Gera um identificador de correlação novo — chamado uma vez no
    início de um fluxo de negócio (ex.: criação de uma Provisão) e
    repassado a todos os eventos subsequentes do MESMO fluxo (aprovação,
    efetivação, geração de Compra e Parcelas), para que a Central de
    Auditoria consiga reconstruir a cadeia completa."""
    return str(uuid.uuid4())


def registrar_evento(
    *, categoria, descricao, empresa=None, usuario=None, ip=None,
    filial=None, modulo="", acao="", resultado=None, tipo_objeto="", id_objeto=None,
    estado_antes=None, estado_depois=None, justificativa="", origem_decisao=None,
    correlation_id="", autoaprovacao=False,
):
    """Prompt 2 (pré-Etapa 02), Gate D (Seção 8): `usuario_nome`/
    `usuario_perfil` são um SNAPSHOT tirado agora, no momento do evento —
    nunca recalculados depois. Isso é o que garante que o evento continue
    legível mesmo que o usuário seja renomeado, tenha o perfil trocado, ou
    seja desativado/excluído (o FK em si é `SET_NULL`)."""
    return RegistroAuditoria.objects.create(
        categoria=categoria, descricao=descricao, empresa=empresa, usuario=usuario, ip=ip,
        usuario_nome=(usuario.get_full_name() or usuario.username) if usuario is not None else "",
        usuario_perfil=usuario.perfil if usuario is not None else "",
        filial=filial, modulo=modulo, acao=acao,
        resultado=resultado or RegistroAuditoria.Resultado.SUCESSO,
        tipo_objeto=tipo_objeto, id_objeto=id_objeto,
        estado_antes=estado_antes, estado_depois=estado_depois,
        justificativa=justificativa, origem_decisao=origem_decisao or RegistroAuditoria.OrigemDecisao.MANUAL,
        correlation_id=correlation_id, autoaprovacao=autoaprovacao,
    )


def _ip_valido(valor) -> Optional[str]:
    """O texto como IP normalizado, ou None se não for um IPv4/IPv6 válido
    (o campo `RegistroAuditoria.ip` é GenericIPAddressField)."""
    try:
        return str(ipaddress.ip_address((valor or "").strip()))
    except ValueError:
        return None


def ip_do_request(request):
    """IP de origem da requisição — ÚNICA fonte para toda a auditoria.

    Críticos (rodada 2): em produção o gunicorn escuta num socket unix atrás
    do nginx; `accept()` num AF_UNIX não tem endereço, e o gunicorn repassa
    REMOTE_ADDR vazio. Só REMOTE_ADDR era lido, então todo RegistroAuditoria
    de produção (login_falho inclusive) gravava ip=NULL. Agora:

    1. REMOTE_ADDR, quando é um IP válido (runserver, gunicorn por TCP);
    2. senão, e SÓ atrás do proxy confiável (`settings.PROXY_CONFIAVEL`, que
       vem de USA_PROXY_HTTPS=True): o X-Real-IP que o nginx grava — ele
       sobrescreve o que o cliente mandar; na falta dele, o ÚLTIMO item do
       X-Forwarded-For (o que o nginx acrescentou; os anteriores vêm do
       cliente e podem ser forjados).
    Fora do proxy confiável, cabeçalho nenhum é aceito."""
    if request is None:
        return None
    meta = request.META
    remoto = _ip_valido(meta.get("REMOTE_ADDR"))
    if remoto:
        return remoto
    if not getattr(settings, "PROXY_CONFIAVEL", False):
        return None
    real_ip = _ip_valido(meta.get("HTTP_X_REAL_IP"))
    if real_ip:
        return real_ip
    encaminhado = [parte for parte in (meta.get("HTTP_X_FORWARDED_FOR") or "").split(",") if parte.strip()]
    return _ip_valido(encaminhado[-1]) if encaminhado else None


@dataclass(frozen=True)
class EventoAuditoria:
    """Forma normalizada de um evento, comum aos 4 mecanismos — só para
    exibição na Central de Auditoria; nenhum dos 4 models é alterado.

    Gate pré-Etapa 10 (S1-3): `filial_nome`, `correlation_id` e
    `autoaprovacao` só existem de verdade em `RegistroAuditoria` — os
    outros 3 mecanismos (`LogConfiguracao`/`HistoricoCompra`/
    `HistoricoProvisao`) sempre devolvem `None`/`False` nesses campos,
    então a tela precisa tratar a ausência sem quebrar."""

    quando: datetime
    usuario_nome: str
    origem: str
    categoria_label: str
    descricao: str
    filial_nome: Optional[str] = None
    correlation_id: str = ""
    autoaprovacao: bool = False
    resultado: str = ""
    estado_antes: Optional[dict] = None
    estado_depois: Optional[dict] = None
    justificativa: str = ""
    # Gate D (Prompt 2, Seção 8): perfil do usuário NO MOMENTO do evento —
    # só `RegistroAuditoria` tem esse snapshot; os outros 3 mecanismos
    # ficam com "" (o template trata a ausência sem quebrar).
    usuario_perfil: str = ""


def _nome_usuario(usuario):
    if usuario is None:
        return "Sistema"
    return usuario.get_full_name() or usuario.username


# Gate 3 (Sprint de Encerramento Definitivo): valores REAIS de `modulo`
# gravados por `registrar_evento()` em todo o projeto — confirmados via
# `grep -rn "modulo=" --include=*.py` em `auditoria/signals.py` (login/
# logout/login falho), `compras/services.py`, `gestao_compras/services.py`,
# `empresas/views_ncc.py`, `empresas/views.py`, `financeiro/views.py` e
# `core/management/commands/seed_demo.py`. Sem acento em "provisoes" e em
# "seguranca" — é assim que os chamadores gravam de verdade.
_ORIGEM_POR_MODULO = {
    "seguranca": "Segurança",
    "compras": "Compras",
    "provisoes": "Provisões",
    "financeiro": "Financeiro",
    "usuarios": "Usuários e Acesso",
    "empresas": "Empresas e Filiais",
    "filiais": "Empresas e Filiais",
    "implantacao": "Implantação",
}


def _origem_do_registro(registro) -> str:
    """Gate 3 (Sprint de Encerramento Definitivo): origem de exibição a
    partir do módulo REAL gravado — antes, todo `RegistroAuditoria`
    aparecia fixo como "Segurança", mesmo Provisão/Compra/Usuário/
    Financeiro. Não altera a categoria histórica do banco, só a
    normalização de leitura."""
    if registro.modulo in _ORIGEM_POR_MODULO:
        return _ORIGEM_POR_MODULO[registro.modulo]
    # Fallback honesto para modulo vazio/desconhecido (registros legados) —
    # nunca mais cai em "Segurança" por default.
    return "Outros" if not registro.modulo else registro.modulo.capitalize()


def _filtrar_por_periodo(qs, data_inicio, data_fim):
    # Comparação por DATA (não datetime): evita construir um datetime cru
    # (naive) num projeto com `USE_TZ=True` — o ORM já lida com o fuso ao
    # comparar `criado_em__date`.
    if data_inicio:
        qs = qs.filter(criado_em__date__gte=data_inicio)
    if data_fim:
        qs = qs.filter(criado_em__date__lte=data_fim)
    return qs


def listar_eventos_auditoria(
    empresa, *, categoria=None, usuario_id=None, filial_id=None, correlation_id=None,
    data_inicio=None, data_fim=None, modulo=None, acao=None, tipo_objeto=None,
    origem_decisao=None, resultado=None, autoaprovacao=None, usuario_perfil=None,
    pagina=1, por_pagina=25,
):
    """Une `RegistroAuditoria`, `LogConfiguracao`, `HistoricoCompra` e
    `HistoricoProvisao` da `empresa`, filtra e pagina. Import tardio dos
    outros 3 models de propósito — evita import circular (`empresas` e
    `compras`/`gestao_compras` não podem importar `auditoria` no topo, e
    vice-versa).

    Gate pré-Etapa 10 (S1-3): filtros `filial_id` e `correlation_id` só se
    aplicam a `RegistroAuditoria` (os outros 3 mecanismos não têm esses
    campos; ficam de fora quando o filtro está ativo, em vez de devolver
    tudo sem filtrar de verdade).

    Prompt 2 (pré-Etapa 02), Gate D (Seção 11): mesma regra vale para os
    filtros novos (`modulo`/`acao`/`tipo_objeto`/`origem_decisao`/
    `resultado`/`autoaprovacao`/`usuario_perfil`) — todos exclusivos do
    contrato completo do Prompt 1, que só `RegistroAuditoria` implementa."""
    from compras.models import HistoricoCompra
    from empresas.models import LogConfiguracao
    from gestao_compras.models import HistoricoProvisao

    eventos = []
    usar_apenas_registro = bool(
        filial_id or correlation_id or modulo or acao or tipo_objeto or origem_decisao
        or resultado or autoaprovacao or usuario_perfil
    )

    if categoria in (None, "", "registro"):
        qs = _filtrar_por_periodo(RegistroAuditoria.objects.filter(empresa=empresa), data_inicio, data_fim)
        if usuario_id:
            qs = qs.filter(usuario_id=usuario_id)
        if filial_id:
            qs = qs.filter(filial_id=filial_id)
        if correlation_id:
            qs = qs.filter(correlation_id=correlation_id)
        if modulo:
            qs = qs.filter(modulo=modulo)
        if acao:
            qs = qs.filter(acao=acao)
        if tipo_objeto:
            qs = qs.filter(tipo_objeto=tipo_objeto)
        if origem_decisao:
            qs = qs.filter(origem_decisao=origem_decisao)
        if resultado:
            qs = qs.filter(resultado=resultado)
        if autoaprovacao:
            qs = qs.filter(autoaprovacao=True)
        if usuario_perfil:
            qs = qs.filter(usuario_perfil=usuario_perfil)
        eventos += [
            EventoAuditoria(
                r.criado_em, r.usuario_nome or _nome_usuario(r.usuario), _origem_do_registro(r), r.get_categoria_display(), r.descricao,
                filial_nome=r.filial.nome if r.filial_id else None,
                correlation_id=r.correlation_id, autoaprovacao=r.autoaprovacao,
                resultado=r.get_resultado_display(), estado_antes=r.estado_antes, estado_depois=r.estado_depois,
                justificativa=r.justificativa, usuario_perfil=r.usuario_perfil,
            )
            for r in qs.select_related("usuario", "filial")
        ]

    if not usar_apenas_registro and categoria in (None, "", "configuracao"):
        qs = _filtrar_por_periodo(LogConfiguracao.objects.filter(empresa=empresa), data_inicio, data_fim)
        if usuario_id:
            qs = qs.filter(usuario_id=usuario_id)
        eventos += [
            EventoAuditoria(r.criado_em, _nome_usuario(r.usuario), "Configuração", r.area, r.descricao)
            for r in qs.select_related("usuario")
        ]

    if not usar_apenas_registro and categoria in (None, "", "compra"):
        qs = _filtrar_por_periodo(HistoricoCompra.objects.filter(compra__empresa=empresa), data_inicio, data_fim)
        if usuario_id:
            qs = qs.filter(usuario_id=usuario_id)
        eventos += [
            EventoAuditoria(
                r.criado_em, _nome_usuario(r.usuario), "Compra",
                r.get_acao_display(), f"{r.compra.fornecedor.nome} — {r.detalhe}" if r.detalhe else r.compra.fornecedor.nome,
            )
            for r in qs.select_related("usuario", "compra")
        ]

    if not usar_apenas_registro and categoria in (None, "", "provisao"):
        qs = _filtrar_por_periodo(HistoricoProvisao.objects.filter(provisao__empresa=empresa), data_inicio, data_fim)
        if usuario_id:
            qs = qs.filter(usuario_id=usuario_id)
        eventos += [
            EventoAuditoria(
                r.criado_em, _nome_usuario(r.usuario), "Provisão",
                r.get_acao_display(), f"{r.provisao.fornecedor.nome} — {r.detalhe}" if r.detalhe else r.provisao.fornecedor.nome,
            )
            for r in qs.select_related("usuario", "provisao")
        ]

    eventos.sort(key=lambda e: e.quando, reverse=True)
    paginator = Paginator(eventos, por_pagina)
    return paginator.get_page(pagina)
