"""Central de Auditoria (Fechamento Final, Seção 8): login/logout/tentativa
de login falha não tinham NENHUM registro em lugar nenhum do sistema antes
desta app — os sinais padrão do Django (`django.contrib.auth.signals`)
disparam com a `LoginView`/`LogoutView` de estoque já usadas em
`nexbuy/urls.py`, sem precisar de view customizada."""
from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.dispatch import receiver

from .models import RegistroAuditoria
from .services import ip_do_request, registrar_evento


@receiver(user_logged_in)
def _registrar_login(sender, request, user, **kwargs):
    registrar_evento(
        categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO,
        descricao=f"Login realizado por {user.get_username()}.",
        empresa=getattr(user, "empresa", None),
        filial=getattr(user, "filial", None),
        usuario=user,
        ip=ip_do_request(request),
        modulo="seguranca", acao="login", resultado=RegistroAuditoria.Resultado.SUCESSO,
    )


@receiver(user_logged_out)
def _registrar_logout(sender, request, user, **kwargs):
    # `user` pode vir None (ex.: sessão já expirada antes do logout) — sem
    # identidade nenhuma para registrar, o evento não agrega nada.
    if user is None:
        return
    registrar_evento(
        categoria=RegistroAuditoria.Categoria.LOGOUT,
        descricao=f"Logout realizado por {user.get_username()}.",
        empresa=getattr(user, "empresa", None),
        filial=getattr(user, "filial", None),
        usuario=user,
        ip=ip_do_request(request),
        modulo="seguranca", acao="logout", resultado=RegistroAuditoria.Resultado.SUCESSO,
    )


@receiver(user_login_failed)
def _registrar_login_falho(sender, credentials, request=None, **kwargs):
    # `credentials` já vem sem a senha (o backend de autenticação do Django
    # remove campos sensíveis antes de disparar o sinal) — nunca tentamos
    # resolver isso a um Usuario real (evita enumeração de contas e
    # qualquer ambiguidade sobre "quem" tentou entrar).
    usuario_tentado = credentials.get("username", "desconhecido")
    registrar_evento(
        categoria=RegistroAuditoria.Categoria.LOGIN_FALHO,
        descricao=f"Tentativa de login falhou para o usuário '{usuario_tentado}'.",
        empresa=None,
        usuario=None,
        ip=ip_do_request(request),
        modulo="seguranca", acao="login", resultado=RegistroAuditoria.Resultado.FALHA,
    )
