"""Testes da Central de Auditoria (Fechamento Final, Prompt 1, Seção 8).

Cobre o model append-only, o service que centraliza a criação
(`registrar_evento`), os sinais de autenticação (login/logout/tentativa
falha — o gap real que motivou esta app) e a união filtrada dos 4
mecanismos de auditoria (`listar_eventos_auditoria`).
"""
from datetime import date, timedelta

from django.test import Client, TestCase, override_settings
from django.utils import timezone

from empresas.models import Empresa, LogConfiguracao
from filiais.models import Filial
from usuarios.models import Permissao, Usuario

from .admin import RegistroAuditoriaAdmin
from .models import RegistroAuditoria
from .services import listar_eventos_auditoria, novo_correlation_id, registrar_evento


class RegistroAuditoriaModelTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Auditoria", cnpj="95.000.000/0001-95")
        self.usuario = Usuario.objects.create_user(
            username="user_auditoria", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def test_criacao_basica_e_str(self):
        registro = RegistroAuditoria.objects.create(
            empresa=self.empresa, usuario=self.usuario,
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login realizado por user_auditoria.",
        )
        self.assertIn("Login realizado", str(registro))

    def test_empresa_e_usuario_sobrevivem_a_exclusao(self):
        """`on_delete=SET_NULL` — apagar a Empresa/Usuário nunca apaga o
        registro (append-only de verdade, mesmo espírito de LogConfiguracao)."""
        registro = RegistroAuditoria.objects.create(
            empresa=self.empresa, usuario=self.usuario,
            categoria=RegistroAuditoria.Categoria.LOGOUT, descricao="Logout de teste.",
        )
        self.usuario.delete()
        self.empresa.delete()
        registro.refresh_from_db()
        self.assertIsNone(registro.usuario)
        self.assertIsNone(registro.empresa)
        self.assertEqual(registro.descricao, "Logout de teste.")


class RegistrarEventoServiceTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Registrar Evento", cnpj="96.000.000/0001-96")
        self.usuario = Usuario.objects.create_user(
            username="user_registrar_evento", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def test_registrar_evento_cria_registro_com_os_campos_informados(self):
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_FALHO, descricao="Tentativa falhou.",
            empresa=self.empresa, usuario=self.usuario, ip="203.0.113.10",
        )
        self.assertEqual(RegistroAuditoria.objects.count(), 1)
        self.assertEqual(registro.ip, "203.0.113.10")
        self.assertEqual(registro.categoria, RegistroAuditoria.Categoria.LOGIN_FALHO)

    def test_registrar_evento_aceita_empresa_e_usuario_none(self):
        """Tentativa de login com usuário inexistente — sem identidade nem
        empresa para associar."""
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_FALHO, descricao="Tentativa para usuário desconhecido.",
        )
        self.assertIsNone(registro.empresa)
        self.assertIsNone(registro.usuario)

    def test_registrar_evento_grava_snapshot_de_nome_e_perfil(self):
        """Prompt 2, Gate D (Seção 8): `usuario_nome`/`usuario_perfil` são
        tirados NO MOMENTO do evento."""
        self.usuario.first_name, self.usuario.last_name = "Nome", "Original"
        self.usuario.save()
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login.",
            empresa=self.empresa, usuario=self.usuario,
        )
        self.assertEqual(registro.usuario_nome, "Nome Original")
        self.assertEqual(registro.usuario_perfil, Usuario.Perfil.PROPRIETARIO)

    def test_snapshot_nao_muda_quando_usuario_e_renomeado_depois(self):
        """O evento continua legível com o nome/perfil de QUANDO ACONTECEU
        — renomear ou trocar o perfil do usuário depois não reescreve a
        história."""
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login.",
            empresa=self.empresa, usuario=self.usuario,
        )
        self.usuario.first_name, self.usuario.last_name = "Novo", "Nome"
        self.usuario.perfil = Usuario.Perfil.GERENTE
        self.usuario.save()

        registro.refresh_from_db()
        self.assertEqual(registro.usuario_nome, "user_registrar_evento")  # sem first/last_name na época
        self.assertEqual(registro.usuario_perfil, Usuario.Perfil.PROPRIETARIO)

    def test_snapshot_permanece_apos_usuario_ser_excluido(self):
        """O FK é SET_NULL — mas o snapshot sobrevive à exclusão."""
        usuario_temp = Usuario.objects.create_user(
            username="user_sera_excluido", password="x", first_name="Vai", last_name="Sumir",
            perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa,
        )
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login.",
            empresa=self.empresa, usuario=usuario_temp,
        )
        usuario_temp.delete()
        registro.refresh_from_db()
        self.assertIsNone(registro.usuario_id)
        self.assertEqual(registro.usuario_nome, "Vai Sumir")
        self.assertEqual(registro.usuario_perfil, Usuario.Perfil.COMPRADOR)


class SinaisDeAutenticacaoTestCase(TestCase):
    """O gap real que motivou esta app: login/logout/tentativa de login
    falha não tinham NENHUM registro em lugar nenhum do sistema antes
    desta app — os sinais padrão do Django, conectados em
    `auditoria/signals.py`, agora capturam os três."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Sinais Auth", cnpj="97.000.000/0001-97")
        self.usuario = Usuario.objects.create_user(
            username="user_sinais_auth", password="senha-correta-123",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        self.client = Client()

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_login_bem_sucedido_gera_registro(self):
        resposta = self.client.post("/accounts/login/", {"username": "user_sinais_auth", "password": "senha-correta-123"})
        self.assertEqual(resposta.status_code, 302)
        registro = RegistroAuditoria.objects.get(categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO)
        self.assertEqual(registro.usuario, self.usuario)
        self.assertEqual(registro.empresa, self.empresa)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_login_com_senha_errada_gera_registro_sem_usuario(self):
        resposta = self.client.post("/accounts/login/", {"username": "user_sinais_auth", "password": "senha-errada"})
        self.assertEqual(resposta.status_code, 200)  # form re-renderizado com erro
        registro = RegistroAuditoria.objects.get(categoria=RegistroAuditoria.Categoria.LOGIN_FALHO)
        self.assertIsNone(registro.usuario)
        self.assertIn("user_sinais_auth", registro.descricao)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_login_com_usuario_inexistente_nao_vaza_qual_username_existe(self):
        """Não afirma que a resposta é diferente para usuário existente vs.
        inexistente (não é o objeto deste teste) — só confirma que a
        tentativa falha registra normalmente, sem tentar resolver a um
        Usuario real (`usuario=None`), mesmo comportamento do teste acima."""
        resposta = self.client.post("/accounts/login/", {"username": "ninguem_aqui", "password": "qualquer"})
        self.assertEqual(resposta.status_code, 200)
        registro = RegistroAuditoria.objects.get(categoria=RegistroAuditoria.Categoria.LOGIN_FALHO)
        self.assertIsNone(registro.usuario)
        self.assertIsNone(registro.empresa)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_logout_gera_registro(self):
        self.client.force_login(self.usuario)
        resposta = self.client.post("/accounts/logout/")
        self.assertEqual(resposta.status_code, 302)
        registro = RegistroAuditoria.objects.get(categoria=RegistroAuditoria.Categoria.LOGOUT)
        self.assertEqual(registro.usuario, self.usuario)


class IpAtrasDoProxyTestCase(TestCase):
    """Críticos (rodada 2): em produção o gunicorn escuta num socket unix
    atrás do nginx e entrega REMOTE_ADDR VAZIO — só REMOTE_ADDR era lido,
    então toda a trilha de auditoria gravava ip=NULL (login_falho
    inclusive). O IP vem do X-Real-IP que o nginx grava, e SÓ atrás do
    proxy confiável (USA_PROXY_HTTPS=True → settings.PROXY_CONFIAVEL)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa IP Proxy", cnpj="96.100.000/0001-96")
        self.usuario = Usuario.objects.create_user(
            username="user_ip_proxy", password="senha-correta-123",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def _request(self, **meta):
        from django.test import RequestFactory

        request = RequestFactory().get("/")
        request.META.update(meta)
        return request

    def test_remote_addr_valido_continua_sendo_a_fonte(self):
        from .services import ip_do_request

        with self.settings(PROXY_CONFIAVEL=True):
            self.assertEqual(
                ip_do_request(self._request(REMOTE_ADDR="10.0.0.7", HTTP_X_REAL_IP="200.1.2.3")), "10.0.0.7",
            )

    def test_socket_unix_usa_x_real_ip_do_nginx(self):
        from .services import ip_do_request

        with self.settings(PROXY_CONFIAVEL=True):
            self.assertEqual(ip_do_request(self._request(REMOTE_ADDR="", HTTP_X_REAL_IP="200.1.2.3")), "200.1.2.3")
            # Sem X-Real-IP: o ÚLTIMO item do X-Forwarded-For (o que o nginx
            # acrescentou); o primeiro veio do cliente e pode ser forjado.
            self.assertEqual(
                ip_do_request(self._request(REMOTE_ADDR="", HTTP_X_FORWARDED_FOR="6.6.6.6, 200.1.2.3")), "200.1.2.3",
            )
            self.assertIsNone(ip_do_request(self._request(REMOTE_ADDR="", HTTP_X_REAL_IP="nao-e-ip")))

    def test_fora_do_proxy_confiavel_cabecalho_do_cliente_e_ignorado(self):
        from .services import ip_do_request

        with self.settings(PROXY_CONFIAVEL=False):
            self.assertIsNone(ip_do_request(self._request(REMOTE_ADDR="", HTTP_X_REAL_IP="200.1.2.3")))

    @override_settings(ALLOWED_HOSTS=["*"], PROXY_CONFIAVEL=True)
    def test_login_certo_e_errado_atras_do_nginx_gravam_o_ip(self):
        cliente = Client(REMOTE_ADDR="", HTTP_X_REAL_IP="200.1.2.3", HTTP_X_FORWARDED_FOR="200.1.2.3")
        cliente.post("/accounts/login/", {"username": "user_ip_proxy", "password": "errada"})
        cliente.post("/accounts/login/", {"username": "user_ip_proxy", "password": "senha-correta-123"})
        ips = dict(
            RegistroAuditoria.objects.filter(
                categoria__in=[RegistroAuditoria.Categoria.LOGIN_FALHO, RegistroAuditoria.Categoria.LOGIN_SUCESSO]
            ).values_list("categoria", "ip")
        )
        self.assertEqual(
            ips,
            {RegistroAuditoria.Categoria.LOGIN_FALHO: "200.1.2.3", RegistroAuditoria.Categoria.LOGIN_SUCESSO: "200.1.2.3"},
        )


class ListarEventosAuditoriaTestCase(TestCase):
    """`listar_eventos_auditoria` une os 4 mecanismos (RegistroAuditoria +
    LogConfiguracao + HistoricoCompra + HistoricoProvisao) — cobre a
    junção, o filtro por categoria/usuário/data e, principalmente, o
    isolamento entre empresas (tema recorrente desta Sprint: um evento de
    outra empresa nunca pode aparecer na lista)."""

    def setUp(self):
        self.empresa_a = Empresa.objects.create(nome="Empresa Auditoria A", cnpj="98.100.000/0001-98")
        self.empresa_b = Empresa.objects.create(nome="Empresa Auditoria B", cnpj="98.200.000/0001-98")
        self.usuario_a = Usuario.objects.create_user(
            username="user_auditoria_a", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa_a,
        )
        self.usuario_b = Usuario.objects.create_user(
            username="user_auditoria_b", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa_b,
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login A",
            empresa=self.empresa_a, usuario=self.usuario_a,
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login B",
            empresa=self.empresa_b, usuario=self.usuario_b,
        )
        LogConfiguracao.objects.create(empresa=self.empresa_a, usuario=self.usuario_a, area="Sistema", descricao="Config A")
        LogConfiguracao.objects.create(empresa=self.empresa_b, usuario=self.usuario_b, area="Sistema", descricao="Config B")

    def test_lista_apenas_eventos_da_empresa_pedida(self):
        pagina = listar_eventos_auditoria(self.empresa_a)
        descricoes = {e.descricao for e in pagina}
        self.assertEqual(descricoes, {"Login A", "Config A"})
        self.assertNotIn("Login B", descricoes)
        self.assertNotIn("Config B", descricoes)

    def test_filtro_por_categoria_registro_traz_so_seguranca(self):
        pagina = listar_eventos_auditoria(self.empresa_a, categoria="registro")
        self.assertEqual([e.descricao for e in pagina], ["Login A"])

    def test_filtro_por_categoria_configuracao_traz_so_logconfiguracao(self):
        pagina = listar_eventos_auditoria(self.empresa_a, categoria="configuracao")
        self.assertEqual([e.descricao for e in pagina], ["Config A"])

    def test_filtro_por_usuario(self):
        outro_usuario_a = Usuario.objects.create_user(
            username="outro_user_auditoria_a", password="x", perfil=Usuario.Perfil.GERENTE, empresa=self.empresa_a,
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGOUT, descricao="Logout outro usuário",
            empresa=self.empresa_a, usuario=outro_usuario_a,
        )
        pagina = listar_eventos_auditoria(self.empresa_a, usuario_id=self.usuario_a.pk)
        descricoes = {e.descricao for e in pagina}
        self.assertIn("Login A", descricoes)
        self.assertIn("Config A", descricoes)
        self.assertNotIn("Logout outro usuário", descricoes)

    def test_filtro_por_intervalo_de_datas_exclui_eventos_fora_do_range(self):
        registro_antigo = RegistroAuditoria.objects.create(
            empresa=self.empresa_a, usuario=self.usuario_a,
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login antigo",
        )
        RegistroAuditoria.objects.filter(pk=registro_antigo.pk).update(
            criado_em=timezone.now() - timedelta(days=30)
        )
        pagina = listar_eventos_auditoria(self.empresa_a, data_inicio=date.today() - timedelta(days=1))
        descricoes = {e.descricao for e in pagina}
        self.assertNotIn("Login antigo", descricoes)
        self.assertIn("Login A", descricoes)

    def test_paginacao(self):
        for i in range(30):
            registrar_evento(
                categoria=RegistroAuditoria.Categoria.LOGOUT, descricao=f"Evento extra {i}",
                empresa=self.empresa_a, usuario=self.usuario_a,
            )
        pagina_1 = listar_eventos_auditoria(self.empresa_a, pagina=1, por_pagina=10)
        self.assertEqual(len(pagina_1.object_list), 10)
        self.assertTrue(pagina_1.has_next())
        self.assertEqual(pagina_1.paginator.count, 32)  # 30 extras + Login A + Config A


class RegistroAuditoriaContratoCompletoTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-3): os campos exigidos pelo Prompt 1 —
    Filial, módulo/ação/resultado, tipo/ID do objeto, estado antes/depois,
    justificativa, origem da decisão, correlação e autoaprovação — de
    verdade existem e persistem, sem quebrar `categoria` (login/logout)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Contrato Auditoria", cnpj="99.000.000/0001-99")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Filial Contrato Auditoria")
        self.usuario = Usuario.objects.create_user(
            username="user_contrato_auditoria", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )

    def test_todos_os_campos_novos_persistem(self):
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.PROVISAO_APROVADA, descricao="Provisão aprovada — teste.",
            empresa=self.empresa, filial=self.filial, usuario=self.usuario,
            modulo="provisoes", acao="aprovar", resultado=RegistroAuditoria.Resultado.SUCESSO,
            tipo_objeto="Provisao", id_objeto=42,
            estado_antes={"status": "aguardando_aprovacao"}, estado_depois={"status": "aprovada"},
            justificativa="Dentro do orçamento.", origem_decisao=RegistroAuditoria.OrigemDecisao.MANUAL,
            correlation_id="provisao-42", autoaprovacao=False,
        )
        registro.refresh_from_db()
        self.assertEqual(registro.filial, self.filial)
        self.assertEqual(registro.modulo, "provisoes")
        self.assertEqual(registro.acao, "aprovar")
        self.assertEqual(registro.resultado, RegistroAuditoria.Resultado.SUCESSO)
        self.assertEqual(registro.tipo_objeto, "Provisao")
        self.assertEqual(registro.id_objeto, 42)
        self.assertEqual(registro.estado_antes, {"status": "aguardando_aprovacao"})
        self.assertEqual(registro.estado_depois, {"status": "aprovada"})
        self.assertEqual(registro.justificativa, "Dentro do orçamento.")
        self.assertEqual(registro.origem_decisao, RegistroAuditoria.OrigemDecisao.MANUAL)
        self.assertEqual(registro.correlation_id, "provisao-42")
        self.assertFalse(registro.autoaprovacao)

    def test_campos_novos_tem_default_seguro_quando_omitidos(self):
        """Chamada "antiga" (só categoria/descricao/empresa/usuario) — mesmo
        contrato usado por login/logout — continua funcionando sem quebrar,
        com defaults previsíveis para os campos novos."""
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.LOGIN_SUCESSO, descricao="Login simples.",
            empresa=self.empresa, usuario=self.usuario,
        )
        self.assertIsNone(registro.filial)
        self.assertEqual(registro.modulo, "")
        self.assertEqual(registro.acao, "")
        self.assertEqual(registro.resultado, RegistroAuditoria.Resultado.SUCESSO)
        self.assertEqual(registro.tipo_objeto, "")
        self.assertIsNone(registro.id_objeto)
        self.assertIsNone(registro.estado_antes)
        self.assertIsNone(registro.estado_depois)
        self.assertEqual(registro.justificativa, "")
        self.assertEqual(registro.origem_decisao, RegistroAuditoria.OrigemDecisao.MANUAL)
        self.assertEqual(registro.correlation_id, "")
        self.assertFalse(registro.autoaprovacao)

    def test_filial_sobrevive_a_exclusao_da_filial(self):
        registro = registrar_evento(
            categoria=RegistroAuditoria.Categoria.FILIAL_EDITADA, descricao="Filial editada.",
            empresa=self.empresa, filial=self.filial, usuario=self.usuario,
        )
        self.filial.delete()
        registro.refresh_from_db()
        self.assertIsNone(registro.filial)

    def test_novo_correlation_id_gera_valores_diferentes(self):
        self.assertNotEqual(novo_correlation_id(), novo_correlation_id())


class RegistroAuditoriaAdminSomenteLeituraTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-3, item 4): "Proíba edição/exclusão pela
    interface e deixe eventual Admin somente leitura" — cobre as 3
    permissões do ModelAdmin diretamente (mais confiável do que só
    inspecionar `readonly_fields`, que trava campo por campo mas não a
    view de criação nem a exclusão)."""

    def setUp(self):
        self.admin = RegistroAuditoriaAdmin(RegistroAuditoria, None)

    def test_nao_permite_adicionar(self):
        self.assertFalse(self.admin.has_add_permission(request=None))

    def test_nao_permite_editar(self):
        self.assertFalse(self.admin.has_change_permission(request=None))

    def test_nao_permite_excluir(self):
        self.assertFalse(self.admin.has_delete_permission(request=None))

    def test_todos_os_campos_do_model_estao_em_readonly_fields(self):
        nomes_dos_campos = {campo.name for campo in RegistroAuditoria._meta.fields}
        self.assertEqual(set(self.admin.readonly_fields), nomes_dos_campos)


class RenomearPermissaoAuditoriaVerTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-3, item 7): "Padronize a permissão como
    auditoria.ver, conforme o Prompt 1. Migre preservando qualquer
    atribuição feita ao código atual auditoria.visualizar." — a migration
    já rodou na criação do banco de teste; aqui confirma-se o resultado:
    existe exatamente UM registro de catálogo para a Central de
    Auditoria, com o código novo, sem duplicar nem deixar o antigo para trás."""

    def test_catalogo_tem_auditoria_ver_e_nao_tem_mais_o_codigo_antigo(self):
        self.assertTrue(Permissao.objects.filter(codigo="auditoria.ver").exists())
        self.assertFalse(Permissao.objects.filter(codigo="auditoria.visualizar").exists())

    def test_nao_existe_duplicidade_de_permissao_da_central_de_auditoria(self):
        self.assertEqual(Permissao.objects.filter(codigo__in=["auditoria.ver", "auditoria.visualizar"]).count(), 1)

    def test_perfil_de_acesso_pode_usar_o_codigo_novo_normalmente(self):
        """Simula o que a migration preservou: um `PerfilAcesso` associado
        à Permissao continua funcionando após a renomeação (o vínculo M2M
        é por chave primária, não por `codigo`)."""
        from usuarios.models import PerfilAcesso

        empresa = Empresa.objects.create(nome="Empresa Perm Auditoria", cnpj="94.000.000/0001-94")
        perfil = PerfilAcesso.objects.create(empresa=empresa, nome="Auditor")
        permissao_auditoria = Permissao.objects.get(codigo="auditoria.ver")
        perfil.permissoes.add(permissao_auditoria)
        self.assertIn(permissao_auditoria, perfil.permissoes.all())


class ListarEventosAuditoriaFiltroFilialCorrelacaoTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-3, item 6): "comprove... isolamento, Filial,
    correlação Provisão → Compra → Parcelas". Cobre os dois filtros
    NOVOS de `listar_eventos_auditoria` — sozinhos e combinados com o
    isolamento por empresa já coberto acima."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Filtro Correlacao", cnpj="93.000.000/0001-93")
        self.filial_a = Filial.objects.create(empresa=self.empresa, nome="Filial Correlacao A")
        self.filial_b = Filial.objects.create(empresa=self.empresa, nome="Filial Correlacao B")
        self.usuario = Usuario.objects.create_user(
            username="user_filtro_correlacao", password="x", perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.PROVISAO_CRIADA, descricao="Provisão 7 criada",
            empresa=self.empresa, filial=self.filial_a, usuario=self.usuario, correlation_id="provisao-7",
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.PROVISAO_EFETIVADA, descricao="Provisão 7 efetivada em Compra #3",
            empresa=self.empresa, filial=self.filial_a, usuario=self.usuario, correlation_id="provisao-7",
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.PROVISAO_CRIADA, descricao="Provisão 8 criada (outra filial)",
            empresa=self.empresa, filial=self.filial_b, usuario=self.usuario, correlation_id="provisao-8",
        )

    def test_filtro_por_filial_traz_so_eventos_daquela_filial(self):
        pagina = listar_eventos_auditoria(self.empresa, filial_id=self.filial_a.pk)
        descricoes = {e.descricao for e in pagina}
        self.assertEqual(descricoes, {"Provisão 7 criada", "Provisão 7 efetivada em Compra #3"})

    def test_filtro_por_correlation_id_reconstroi_a_cadeia_do_fluxo(self):
        pagina = listar_eventos_auditoria(self.empresa, correlation_id="provisao-7")
        descricoes = {e.descricao for e in pagina}
        self.assertEqual(descricoes, {"Provisão 7 criada", "Provisão 7 efetivada em Compra #3"})
        self.assertNotIn("Provisão 8 criada (outra filial)", descricoes)

    def test_filtro_por_correlation_id_nao_traz_os_outros_3_mecanismos(self):
        """Filtrar por correlação só faz sentido para `RegistroAuditoria`
        (os outros 3 mecanismos não têm esse campo) — confirma que a
        junção não devolve tudo sem filtrar de verdade quando o filtro
        está ativo."""
        LogConfiguracao.objects.create(
            empresa=self.empresa, usuario=self.usuario, area="Sistema", descricao="Config que não deveria aparecer",
        )
        pagina = listar_eventos_auditoria(self.empresa, correlation_id="provisao-7")
        descricoes = {e.descricao for e in pagina}
        self.assertNotIn("Config que não deveria aparecer", descricoes)
