from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import PerfilAcesso, Permissao, UsuarioEmpresa, UsuarioFilial


@admin.register(Permissao)
class PermissaoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nome")
    search_fields = ("codigo", "nome")


@admin.register(PerfilAcesso)
class PerfilAcessoAdmin(admin.ModelAdmin):
    list_display = ("nome", "empresa", "descricao")
    list_filter = ("empresa",)
    filter_horizontal = ("permissoes",)


@admin.register(UsuarioEmpresa)
class UsuarioEmpresaAdmin(admin.ModelAdmin):
    list_display = ("usuario", "empresa", "limite_compra", "ativo")
    list_filter = ("empresa", "ativo")
    search_fields = ("usuario__username", "empresa__nome")


@admin.register(UsuarioFilial)
class UsuarioFilialAdmin(admin.ModelAdmin):
    list_display = ("usuario", "filial", "ativo")
    list_filter = ("filial__empresa", "ativo")
    search_fields = ("usuario__username", "filial__nome")

from .models import Usuario


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    list_display = ("username", "get_full_name", "perfil", "empresa", "filial", "is_active")
    list_filter = ("perfil", "empresa", "filial", "is_active")
    fieldsets = UserAdmin.fieldsets + (
        ("NEXBUY", {"fields": ("perfil", "empresa", "filial")}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("NEXBUY", {"fields": ("perfil", "empresa", "filial")}),
    )
