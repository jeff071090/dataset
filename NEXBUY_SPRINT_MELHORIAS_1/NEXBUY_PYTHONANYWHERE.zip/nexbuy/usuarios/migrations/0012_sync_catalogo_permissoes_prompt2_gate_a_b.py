# Migration de dados (Prompt 2, pré-Etapa 02 — Gates A e B):
# `core.permissions.CATALOGO_PERMISSOES` ganhou `relatorios.ver` (estava
# totalmente ausente do catálogo — Gate B, Seção 5) e o Proprietário foi
# acrescentado aos perfis legados de `compras.lancar`, `compras.aprovar`,
# `provisoes.criar`, `calendario.ver` e `financeiro.cadastrar` (Gate A,
# Seção 4). Nenhuma dessas mudanças de PERFIS altera o banco (o motor de
# permissões resolve perfil legado em memória, via `_PERMISSOES_POR_PERFIL`
# — só o `nome`/existência de cada `codigo` é persistido); esta migration
# só precisa mesmo criar `relatorios.ver`. Mesmo padrão idempotente de
# 0003/0005/0008/0010: sincroniza o catálogo COMPLETO com `update_or_create`,
# nunca duplica nem apaga atribuições granulares já feitas.
from django.db import migrations

CODIGOS_FECHADOS_NESTA_MIGRATION = ("relatorios.ver",)


def sincronizar_catalogo_completo(apps, schema_editor):
    from core.permissions import CATALOGO_PERMISSOES

    Permissao = apps.get_model("usuarios", "Permissao")
    for codigo, nome, _perfis in CATALOGO_PERMISSOES:
        Permissao.objects.update_or_create(codigo=codigo, defaults={"nome": nome})


def remover_codigos_fechados_nesta_migration(apps, schema_editor):
    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo__in=CODIGOS_FECHADOS_NESTA_MIGRATION).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0011_renomear_permissao_auditoria_ver"),
    ]

    operations = [
        migrations.RunPython(sincronizar_catalogo_completo, remover_codigos_fechados_nesta_migration),
    ]
