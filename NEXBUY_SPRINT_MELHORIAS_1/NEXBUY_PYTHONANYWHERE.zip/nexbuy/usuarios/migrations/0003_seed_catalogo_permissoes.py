# Migration de dados (Épico 7 — CORE 1.0): semeia o catálogo de permissões
# do RBAC a partir da fonte única em `core.permissions.CATALOGO_PERMISSOES`.
# Idempotente (update_or_create) e reversível (remove só os códigos do
# catálogo, nunca permissões criadas por fora).
from django.db import migrations


def semear_catalogo(apps, schema_editor):
    from core.permissions import CATALOGO_PERMISSOES

    Permissao = apps.get_model("usuarios", "Permissao")
    for codigo, nome, _perfis in CATALOGO_PERMISSOES:
        Permissao.objects.update_or_create(codigo=codigo, defaults={"nome": nome})


def remover_catalogo(apps, schema_editor):
    from core.permissions import CATALOGO_PERMISSOES

    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo__in=[codigo for codigo, _, _ in CATALOGO_PERMISSOES]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0002_permissao_perfilacesso_usuario_perfis_acesso_and_more"),
    ]

    operations = [
        migrations.RunPython(semear_catalogo, remover_catalogo),
    ]
