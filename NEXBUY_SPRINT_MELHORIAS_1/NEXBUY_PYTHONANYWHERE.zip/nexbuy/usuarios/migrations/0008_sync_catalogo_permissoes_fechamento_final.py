# Migration de dados (Fechamento Final — Prompt 1, Seção 5): `filiais.
# gerenciar` (Sprint de Correções Críticas, Seção 6) e `provisoes.efetivar`
# (Sprint de Correções Críticas, Seção 12) foram acrescentadas a
# `core.permissions.CATALOGO_PERMISSOES` sem nenhuma migration de dados
# correspondente — diferente de `timeline.ver`/`capacidade.gerenciar`
# (0005), que ganharam a sua. Consequência: essas duas permissões nunca
# foram persistidas em `usuarios_permissao`, embora já estivessem em uso
# no `@permissao_required` das views (o RBAC aditivo por perfil LEGADO
# continuava funcionando via `permissoes_do_perfil_legado`, que não
# depende do banco — só o painel visual de atribuição granular e a
# atribuição individual/por PerfilAcesso dessas duas permissões ficavam
# impossíveis).
#
# Esta migration sincroniza o catálogo COMPLETO (não só os 2 códigos
# novos) — mesmo padrão idempotente de 0003/0005, mas iterando tudo, para
# que qualquer divergência futura entre o catálogo em memória e o banco
# feche numa única passada. Ver também o comando `sincronizar_permissoes`
# para sincronizar sem precisar escrever uma nova migration a cada
# permissão nova.
from django.db import migrations

CODIGOS_FECHADOS_NESTA_MIGRATION = ("filiais.gerenciar", "provisoes.efetivar")


def sincronizar_catalogo_completo(apps, schema_editor):
    from core.permissions import CATALOGO_PERMISSOES

    Permissao = apps.get_model("usuarios", "Permissao")
    for codigo, nome, _perfis in CATALOGO_PERMISSOES:
        Permissao.objects.update_or_create(codigo=codigo, defaults={"nome": nome})


def remover_codigos_fechados_nesta_migration(apps, schema_editor):
    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo__in=CODIGOS_FECHADOS_NESTA_MIGRATION).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0007_usuariofilial"),
    ]

    operations = [
        migrations.RunPython(sincronizar_catalogo_completo, remover_codigos_fechados_nesta_migration),
    ]
