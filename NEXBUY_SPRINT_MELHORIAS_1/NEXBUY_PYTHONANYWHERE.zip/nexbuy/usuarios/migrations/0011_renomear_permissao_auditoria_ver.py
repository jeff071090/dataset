"""Gate pré-Etapa 10 (S1-3, item 7): padroniza a permissão da Central de
Auditoria como `auditoria.ver` (nome usado pelo Prompt 1 original) — o
código anterior (`auditoria.visualizar`) foi uma escolha desta
implementação, não do contrato pedido.

Renomeia o `codigo` NO MESMO registro de `Permissao` (não apaga e
recria) — assim qualquer atribuição já feita a `PerfilAcesso.permissoes`
(vínculo M2M por chave primária, não por código) é preservada
automaticamente, mesmo para perfis customizados criados pelo cliente."""
from django.db import migrations

CODIGO_ANTIGO = "auditoria.visualizar"
CODIGO_NOVO = "auditoria.ver"


def renomear_para_novo(apps, schema_editor):
    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo=CODIGO_ANTIGO).update(codigo=CODIGO_NOVO, nome="Ver a Central de Auditoria")


def renomear_para_antigo(apps, schema_editor):
    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo=CODIGO_NOVO).update(codigo=CODIGO_ANTIGO, nome="Ver a Central de Auditoria")


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0010_sync_catalogo_permissoes_central_auditoria"),
    ]

    operations = [
        migrations.RunPython(renomear_para_novo, renomear_para_antigo),
    ]
