# Migration de dados (RC do Épico 01 — Correções 01 e 03): re-sincroniza o
# catálogo de permissões com a fonte única `core.permissions.CATALOGO_PERMISSOES`,
# que ganhou `timeline.ver` (Timeline Financeira restrita aos perfis
# gestores) e `capacidade.gerenciar` (Motor de Capacidade do Financeiro).
# Mesmo mecanismo idempotente da 0003; o reverso remove apenas os códigos
# novos desta RC.
from django.db import migrations

CODIGOS_NOVOS_RC = ("timeline.ver", "capacidade.gerenciar")


def sincronizar_catalogo(apps, schema_editor):
    from core.permissions import CATALOGO_PERMISSOES

    Permissao = apps.get_model("usuarios", "Permissao")
    for codigo, nome, _perfis in CATALOGO_PERMISSOES:
        Permissao.objects.update_or_create(codigo=codigo, defaults={"nome": nome})


def remover_codigos_novos(apps, schema_editor):
    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo__in=CODIGOS_NOVOS_RC).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0004_usuarioempresa_bloqueado"),
    ]

    operations = [
        migrations.RunPython(sincronizar_catalogo, remover_codigos_novos),
    ]
