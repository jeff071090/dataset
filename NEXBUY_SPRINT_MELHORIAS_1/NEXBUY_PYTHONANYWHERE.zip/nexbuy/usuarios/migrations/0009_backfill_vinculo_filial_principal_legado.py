# Migration de dados (Fechamento Final — Prompt 1, Seção 4.2): gera o
# vínculo `UsuarioFilial` ATIVO da filial principal para todo usuário
# legado elegível — não-Proprietário, com `filial` preenchida, que ainda
# não tem NENHUM `UsuarioFilial` (nem ativo, nem inativo).
#
# Até esta migration, esses usuários dependiam do fallback de
# compatibilidade em `filiais_autorizadas_para()` (que resolve a mesma
# coisa em memória, sem tocar o banco). Esta migration não muda o
# resultado de `filiais_autorizadas_para()` para ninguém — só torna
# EXPLÍCITO no banco um acesso que já era concedido implicitamente,
# preparando o terreno para a Seção 4.1 (gestão de vínculos pela
# interface do NCC, que precisa de linhas reais para editar) e reduzindo
# a dependência do fallback ao mínimo necessário.
#
# Idempotente (`get_or_create`) — rodar de novo não duplica. Proprietário
# nunca precisa de vínculo (already vê tudo automaticamente); usuário sem
# `filial` não tem de onde herdar o vínculo (fica de fora, sem erro).
#
# Reversão: não há uma forma segura de distinguir, depois do fato, um
# vínculo criado por esta migration de um criado manualmente em seguida
# (ex.: pela gestão de vínculos do NCC, Seção 4.1) — por isso o reverso é
# um no-op documentado, e não uma remoção potencialmente destrutiva de
# dado legítimo.
from django.db import migrations

PERFIL_PROPRIETARIO = "proprietario"


def gerar_vinculos_legados(apps, schema_editor):
    Usuario = apps.get_model("usuarios", "Usuario")
    UsuarioFilial = apps.get_model("usuarios", "UsuarioFilial")

    # `filter(vinculos_filial__isnull=True)` — não `.exclude(...isnull=False)` —
    # de propósito: em relação reversa multi-valorada, `exclude()` não é o
    # espelho seguro de `filter(isnull=True)` (a tradução SQL não é a mesma
    # anti-join); só o `filter` com os dois `isnull` juntos garante "não
    # tem NENHUM UsuarioFilial" sem duplicar linhas por causa do JOIN.
    usuarios_elegiveis = (
        Usuario.objects.filter(filial__isnull=False, vinculos_filial__isnull=True)
        .exclude(perfil=PERFIL_PROPRIETARIO)
        .distinct()
    )
    for usuario in usuarios_elegiveis:
        UsuarioFilial.objects.get_or_create(
            usuario=usuario, filial_id=usuario.filial_id, defaults={"ativo": True},
        )


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0008_sync_catalogo_permissoes_fechamento_final"),
    ]

    operations = [
        migrations.RunPython(gerar_vinculos_legados, migrations.RunPython.noop),
    ]
