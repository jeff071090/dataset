# Migration de dados (Fechamento Final — Prompt 1, Seção 8): a Central de
# Auditoria acrescentou o código `auditoria.visualizar` a
# `core.permissions.CATALOGO_PERMISSOES` — mesmo padrão idempotente de
# 0003/0005/0008, sincronizando o catálogo COMPLETO (não só o código novo).
from django.db import migrations

CODIGOS_FECHADOS_NESTA_MIGRATION = ("auditoria.visualizar",)


def sincronizar_catalogo_completo(apps, schema_editor):
    from core.permissions import CATALOGO_PERMISSOES

    Permissao = apps.get_model("usuarios", "Permissao")
    for codigo, nome, _perfis in CATALOGO_PERMISSOES:
        Permissao.objects.update_or_create(codigo=codigo, defaults={"nome": nome})


def remover_codigos_fechados_nesta_migration(apps, schema_editor):
    Permissao = apps.get_model("usuarios", "Permissao")
    Permissao.objects.filter(codigo__in=CODIGOS_FECHADOS_NESTA_MIGRATION).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("usuarios", "0009_backfill_vinculo_filial_principal_legado"),
    ]

    operations = [
        migrations.RunPython(sincronizar_catalogo_completo, remover_codigos_fechados_nesta_migration),
    ]
