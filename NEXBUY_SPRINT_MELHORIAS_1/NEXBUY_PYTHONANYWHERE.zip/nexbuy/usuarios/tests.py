"""Testes de `usuarios` (Épicos 7, 9 e 16 — CORE 1.0).

Fecha a lacuna histórica apontada por todas as auditorias: o mecanismo
central de isolamento multi-tenant (`filiais_visiveis`) nunca tinha teste
próprio. Cobre também o Motor de Permissões (RBAC) e o Contexto por
Empresa (empresas autorizadas + troca sem novo login).
"""
from django.db import IntegrityError, transaction
from django.test import Client, TestCase
from django.test.utils import override_settings

from core.contexto import CHAVE_SESSAO_EMPRESA
from core.permissions import permissoes_do_perfil_legado, usuario_tem_permissao
from empresas.models import Empresa, GrupoEmpresarial
from filiais.models import Filial
from usuarios.models import (
    PerfilAcesso,
    Permissao,
    Usuario,
    UsuarioEmpresa,
    UsuarioFilial,
    filiais_autorizadas_para,
)


class BaseUsuariosTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        grupo = GrupoEmpresarial.objects.create(nome="Grupo Teste")
        cls.empresa_a = Empresa.objects.create(nome="Empresa A", cnpj="11.111.111/0001-11", grupo=grupo)
        cls.empresa_b = Empresa.objects.create(nome="Empresa B", cnpj="22.222.222/0001-22", grupo=grupo)
        cls.filial_a1 = Filial.objects.create(empresa=cls.empresa_a, nome="A1")
        cls.filial_a2 = Filial.objects.create(empresa=cls.empresa_a, nome="A2")
        cls.filial_a3_inativa = Filial.objects.create(empresa=cls.empresa_a, nome="A3", ativo=False)
        cls.filial_b1 = Filial.objects.create(empresa=cls.empresa_b, nome="B1")


class FiliaisVisiveisTestCase(BaseUsuariosTestCase):
    """O isolamento multi-tenant do sistema, testado diretamente."""

    def test_proprietario_ve_todas_as_filiais_ativas_da_propria_empresa(self):
        dono = Usuario.objects.create_user("dono_a", password="x")
        dono.perfil = Usuario.Perfil.PROPRIETARIO
        dono.empresa = self.empresa_a
        dono.save()

        visiveis = set(dono.filiais_visiveis())
        self.assertEqual(visiveis, {self.filial_a1, self.filial_a2})
        self.assertNotIn(self.filial_a3_inativa, visiveis)
        self.assertNotIn(self.filial_b1, visiveis)

    def test_operacional_ve_somente_a_propria_filial(self):
        comprador = Usuario.objects.create_user("comprador_a1", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()

        self.assertEqual(list(comprador.filiais_visiveis()), [self.filial_a1])

    def test_usuario_sem_filial_e_sem_perfil_proprietario_nao_ve_nada(self):
        solto = Usuario.objects.create_user("solto", password="x")
        solto.perfil = Usuario.Perfil.GERENTE
        solto.save()

        self.assertEqual(list(solto.filiais_visiveis()), [])

    def test_com_contexto_proprietario_ve_filiais_da_empresa_ativa(self):
        """Fechamento Final (Seção 4.2, último item): `empresa` só devolve
        filiais quando está em `empresas_disponiveis()` — por isso o
        Proprietário precisa de autorização explícita para B aqui, mesmo
        sendo do mesmo Grupo de A (a Sprint anterior já deixou a CRIAÇÃO de
        autorização restrita ao Grupo; não concede acesso automático)."""
        dono = Usuario.objects.create_user("dono_ctx", password="x")
        dono.perfil = Usuario.Perfil.PROPRIETARIO
        dono.empresa = self.empresa_a
        dono.save()
        UsuarioEmpresa.objects.create(usuario=dono, empresa=self.empresa_b, ativo=True)

        self.assertEqual(list(dono.filiais_visiveis(empresa=self.empresa_b)), [self.filial_b1])

    def test_operacional_nao_autorizado_nao_ve_nada_em_outra_empresa(self):
        financeiro = Usuario.objects.create_user("fin_a1", password="x")
        financeiro.perfil = Usuario.Perfil.FINANCEIRO
        financeiro.empresa = self.empresa_a
        financeiro.filial = self.filial_a1
        financeiro.save()

        self.assertEqual(list(financeiro.filiais_visiveis(empresa=self.empresa_b)), [])

    def test_operacional_autorizado_ve_filiais_ativas_da_empresa_autorizada(self):
        """`UsuarioEmpresa` autoriza a EMPRESA; `UsuarioFilial` autoriza a
        FILIAL dentro dela (Seção 7) — os dois vínculos são necessários."""
        financeiro = Usuario.objects.create_user("fin_autorizado", password="x")
        financeiro.perfil = Usuario.Perfil.FINANCEIRO
        financeiro.empresa = self.empresa_a
        financeiro.filial = self.filial_a1
        financeiro.save()
        UsuarioEmpresa.objects.create(usuario=financeiro, empresa=self.empresa_b, ativo=True)
        UsuarioFilial.objects.create(usuario=financeiro, filial=self.filial_b1, ativo=True)

        self.assertEqual(list(financeiro.filiais_visiveis(empresa=self.empresa_b)), [self.filial_b1])


class MotorPermissoesTestCase(BaseUsuariosTestCase):
    """RBAC (Épico 7): perfil legado + perfis de acesso + individuais."""

    def test_perfil_legado_mantem_os_acessos_de_sempre(self):
        gerente = Usuario.objects.create_user("gerente_rbac", password="x")
        gerente.perfil = Usuario.Perfil.GERENTE
        gerente.save()

        self.assertTrue(usuario_tem_permissao(gerente, "compras.aprovar"))
        self.assertFalse(usuario_tem_permissao(gerente, "compras.lancar"))
        self.assertFalse(usuario_tem_permissao(gerente, "ncc.acessar"))
        self.assertIn("compras.aprovar", permissoes_do_perfil_legado(Usuario.Perfil.GERENTE))

    def test_permissao_individual_soma_ao_perfil_legado(self):
        comprador = Usuario.objects.create_user("comprador_rbac", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.save()
        self.assertFalse(usuario_tem_permissao(comprador, "agenda.ver"))

        comprador.permissoes_individuais.add(Permissao.objects.get(codigo="agenda.ver"))
        self.assertTrue(usuario_tem_permissao(comprador, "agenda.ver"))

    def test_perfil_de_acesso_reutilizavel_concede_permissoes(self):
        aprovador = PerfilAcesso.objects.create(nome="Aprovador Extra", empresa=self.empresa_a)
        aprovador.permissoes.add(Permissao.objects.get(codigo="provisoes.aprovar"))

        comprador = Usuario.objects.create_user("comprador_perfilacesso", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.save()
        comprador.perfis_acesso.add(aprovador)

        self.assertTrue(usuario_tem_permissao(comprador, "provisoes.aprovar"))

    def test_superusuario_tem_todas_as_permissoes(self):
        root = Usuario.objects.create_superuser("root_rbac", password="x")
        self.assertTrue(usuario_tem_permissao(root, "ncc.acessar"))


class ContextoPorEmpresaTestCase(BaseUsuariosTestCase):
    """Épico 9: empresas disponíveis + troca de contexto sem novo login."""

    def setUp(self):
        self.dono = Usuario.objects.create_user("dono_troca", password="nexbuy123")
        self.dono.perfil = Usuario.Perfil.PROPRIETARIO
        self.dono.empresa = self.empresa_a
        self.dono.save()
        UsuarioEmpresa.objects.create(usuario=self.dono, empresa=self.empresa_b, ativo=True)
        self.client = Client()
        self.client.login(username="dono_troca", password="nexbuy123")

    def test_empresas_disponiveis_inclui_principal_e_autorizadas(self):
        self.assertEqual(set(self.dono.empresas_disponiveis()), {self.empresa_a, self.empresa_b})

    def test_empresas_disponiveis_nunca_inclui_autorizacao_de_outro_grupo(self):
        """Fechamento Final (Seção 4.3): mesmo com um `UsuarioEmpresa`
        ativo apontando pra ela, uma Empresa de outro Grupo nunca entra em
        `empresas_disponiveis()` — a fronteira de Grupo é reaplicada na
        leitura, não só bloqueada na criação pelo formulário (que a Sprint
        de Correções Críticas já restringira)."""
        outro_grupo = GrupoEmpresarial.objects.create(nome="Outro Grupo")
        empresa_outro_grupo = Empresa.objects.create(
            nome="Empresa Outro Grupo", cnpj="44.444.444/0001-44", grupo=outro_grupo,
        )
        UsuarioEmpresa.objects.create(usuario=self.dono, empresa=empresa_outro_grupo, ativo=True)

        self.assertNotIn(empresa_outro_grupo, self.dono.empresas_disponiveis())
        self.assertEqual(set(self.dono.empresas_disponiveis()), {self.empresa_a, self.empresa_b})

    def test_trocar_para_empresa_autorizada_grava_na_sessao(self):
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)
        self.assertEqual(self.client.session.get(CHAVE_SESSAO_EMPRESA), self.empresa_b.pk)

    def test_trocar_para_empresa_nao_autorizada_e_recusado(self):
        intrusa = Empresa.objects.create(nome="Intrusa", cnpj="33.333.333/0001-33")
        self.client.post("/trocar-empresa/", {"empresa_id": intrusa.pk})
        self.assertNotEqual(self.client.session.get(CHAVE_SESSAO_EMPRESA), intrusa.pk)

    def test_autorizacao_revogada_volta_para_a_empresa_principal(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        UsuarioEmpresa.objects.filter(usuario=self.dono, empresa=self.empresa_b).update(ativo=False)
        resposta = self.client.get("/")
        self.assertEqual(resposta.status_code, 200)
        # A sessão inválida é limpa e o contexto cai com segurança na principal.
        self.assertIsNone(self.client.session.get(CHAVE_SESSAO_EMPRESA))


class FiliaisAutorizadasParaTestCase(BaseUsuariosTestCase):
    """`filiais_autorizadas_para` (Sprint de Correções Críticas — Seção 9)
    é a fonte central usada por Compra, Provisão, Receita, Custo Fixo/
    Variável e relatórios — cobertura direta e minuciosa aqui vale mais
    do que espalhada pelas views que só a chamam."""

    def test_proprietario_sempre_ve_todas_as_filiais_ativas_da_empresa(self):
        dono = Usuario.objects.create_user("dono_far", password="x")
        dono.perfil = Usuario.Perfil.PROPRIETARIO
        dono.empresa = self.empresa_a
        dono.save()

        self.assertEqual(
            set(filiais_autorizadas_para(dono, self.empresa_a)),
            {self.filial_a1, self.filial_a2},
        )

    def test_usuario_ou_empresa_none_devolve_queryset_vazio(self):
        comprador = Usuario.objects.create_user("comprador_far_none", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.save()

        self.assertEqual(list(filiais_autorizadas_para(comprador, None)), [])
        self.assertEqual(list(filiais_autorizadas_para(None, self.empresa_a)), [])

    def test_sem_vinculo_explicito_cai_na_filial_principal_da_propria_empresa(self):
        """Compatibilidade: usuário criado antes desta Sprint, sem nenhum
        `UsuarioFilial`, continua vendo a própria filial principal."""
        comprador = Usuario.objects.create_user("comprador_far_legado", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()

        self.assertEqual(list(filiais_autorizadas_para(comprador, self.empresa_a)), [self.filial_a1])

    def test_sem_vinculo_explicito_nunca_vaza_filial_principal_para_outra_empresa(self):
        """A mesma compatibilidade não pode virar brecha: se a filial
        principal é de A, pedir o contexto de B devolve vazio — nunca a
        filial errada."""
        comprador = Usuario.objects.create_user("comprador_far_legado_b", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()

        self.assertEqual(list(filiais_autorizadas_para(comprador, self.empresa_b)), [])

    def test_com_vinculo_explicito_vale_exclusivamente_a_lista_do_vinculo(self):
        """Usuário migrado (já tem ao menos 1 `UsuarioFilial`) não recebe
        mais a filial principal de brinde — só o que está explicitamente
        vinculado, mesmo que seja diferente da principal."""
        financeiro = Usuario.objects.create_user("fin_far_migrado", password="x")
        financeiro.perfil = Usuario.Perfil.FINANCEIRO
        financeiro.empresa = self.empresa_a
        financeiro.filial = self.filial_a1
        financeiro.save()
        UsuarioFilial.objects.create(usuario=financeiro, filial=self.filial_a2, ativo=True)

        self.assertEqual(list(filiais_autorizadas_para(financeiro, self.empresa_a)), [self.filial_a2])

    def test_ter_tido_qualquer_vinculo_mesmo_inativo_fecha_o_fallback_para_sempre(self):
        """Fechamento Final (Seção 4.2): diferente do usuário que NUNCA
        teve vínculo (esse sim cai no fallback), um usuário que já teve
        algum `UsuarioFilial` — mesmo que hoje esteja todo inativo — nunca
        mais reabre a filial principal por fallback. O acesso foi
        explicitamente revogado; reabri-lo silenciosamente seria a mesma
        falha que a Seção 4.2 pede para fechar."""
        comprador = Usuario.objects.create_user("comprador_far_vinculo_inativo", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a2, ativo=False)

        self.assertEqual(list(filiais_autorizadas_para(comprador, self.empresa_a)), [])

    def test_filial_inativa_nunca_aparece_mesmo_com_vinculo_ativo(self):
        comprador = Usuario.objects.create_user("comprador_far_filial_inativa", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a3_inativa, ativo=True)

        self.assertEqual(list(filiais_autorizadas_para(comprador, self.empresa_a)), [])

    def test_todos_os_vinculos_inativos_resultado_vazio_mesmo_com_varios(self):
        comprador = Usuario.objects.create_user("comprador_far_todos_inativos", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a1, ativo=False)
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a2, ativo=False)

        self.assertEqual(list(filiais_autorizadas_para(comprador, self.empresa_a)), [])

    def test_outro_grupo_mesmo_com_usuarioempresa_ativo_nunca_devolve_filial(self):
        """Fechamento Final (Seção 4.2, defesa em profundidade / Seção 4.3):
        `filiais_autorizadas_para` barra pela raiz — via
        `empresas_disponiveis()` — mesmo quando existe um `UsuarioEmpresa`
        E um `UsuarioFilial` ativos cruzando Grupos (dado histórico
        inconsistente que o comando de diagnóstico da Seção 4.3 também
        deve encontrar)."""
        outro_grupo = GrupoEmpresarial.objects.create(nome="Outro Grupo FAP")
        empresa_outro_grupo = Empresa.objects.create(
            nome="Empresa Outro Grupo FAP", cnpj="45.444.444/0001-45", grupo=outro_grupo,
        )
        filial_outro_grupo = Filial.objects.create(empresa=empresa_outro_grupo, nome="Filial Outro Grupo")

        comprador = Usuario.objects.create_user("comprador_far_outro_grupo", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()
        UsuarioEmpresa.objects.create(usuario=comprador, empresa=empresa_outro_grupo, ativo=True)
        UsuarioFilial.objects.create(usuario=comprador, filial=filial_outro_grupo, ativo=True)

        self.assertEqual(list(filiais_autorizadas_para(comprador, empresa_outro_grupo)), [])

    def test_com_vinculo_explicito_apenas_na_propria_empresa_nao_vaza_para_outra_empresa_autorizada(self):
        """Revisão adversarial (Fechamento Final, Seção 4.2): distinto do
        caso "sem vínculo nenhum" (que cai no fallback da principal) — aqui
        o usuário TEM vínculo explícito, só que nenhum na Empresa B, mesmo
        B sendo do mesmo Grupo e estando em `empresas_disponiveis()`. O
        join por `empresa=` já exclui corretamente, mas esse caminho nunca
        tinha sido exercitado por um teste."""
        financeiro = Usuario.objects.create_user("fin_far_vinculo_so_empresa_a", password="x")
        financeiro.perfil = Usuario.Perfil.FINANCEIRO
        financeiro.empresa = self.empresa_a
        financeiro.filial = self.filial_a1
        financeiro.save()
        UsuarioEmpresa.objects.create(usuario=financeiro, empresa=self.empresa_b, ativo=True)
        UsuarioFilial.objects.create(usuario=financeiro, filial=self.filial_a1, ativo=True)

        self.assertIn(self.empresa_b, financeiro.empresas_disponiveis())
        self.assertEqual(list(filiais_autorizadas_para(financeiro, self.empresa_b)), [])
        self.assertEqual(list(filiais_autorizadas_para(financeiro, self.empresa_a)), [self.filial_a1])


class UsuarioFilialConstraintTestCase(BaseUsuariosTestCase):
    """Seção 7: o vínculo é único por (usuário, filial) — o banco garante
    isso, não só a camada de aplicação."""

    def test_vinculo_duplicado_para_o_mesmo_usuario_e_filial_e_rejeitado(self):
        comprador = Usuario.objects.create_user("comprador_far_dup", password="x")
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a1, ativo=True)

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a1, ativo=False)


class BackfillVinculoFilialPrincipalLegadoTestCase(BaseUsuariosTestCase):
    """Fechamento Final (Prompt 1, Seção 4.2): a migration
    `0009_backfill_vinculo_filial_principal_legado` torna explícito no
    banco o vínculo que antes só existia via fallback em memória — sem
    mudar o resultado de `filiais_autorizadas_para` para ninguém."""

    def _rodar_migration(self):
        import importlib

        from django.apps import apps as django_apps

        modulo = importlib.import_module(
            "usuarios.migrations.0009_backfill_vinculo_filial_principal_legado"
        )
        modulo.gerar_vinculos_legados(django_apps, None)

    def test_usuario_legado_sem_nenhum_vinculo_ganha_vinculo_da_principal(self):
        comprador = Usuario.objects.create_user("comprador_backfill_legado", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()

        self._rodar_migration()

        vinculo = UsuarioFilial.objects.get(usuario=comprador)
        self.assertEqual(vinculo.filial, self.filial_a1)
        self.assertTrue(vinculo.ativo)

    def test_proprietario_nunca_ganha_vinculo(self):
        dono = Usuario.objects.create_user("dono_backfill_legado", password="x")
        dono.perfil = Usuario.Perfil.PROPRIETARIO
        dono.empresa = self.empresa_a
        dono.filial = self.filial_a1
        dono.save()

        self._rodar_migration()

        self.assertFalse(UsuarioFilial.objects.filter(usuario=dono).exists())

    def test_usuario_com_vinculo_inativo_nao_e_duplicado_nem_reativado(self):
        comprador = Usuario.objects.create_user("comprador_backfill_ja_migrado", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()
        UsuarioFilial.objects.create(usuario=comprador, filial=self.filial_a2, ativo=False)

        self._rodar_migration()

        vinculos = list(UsuarioFilial.objects.filter(usuario=comprador))
        self.assertEqual(len(vinculos), 1)
        self.assertEqual(vinculos[0].filial, self.filial_a2)
        self.assertFalse(vinculos[0].ativo)

    def test_usuario_sem_filial_e_ignorado_sem_erro(self):
        solto = Usuario.objects.create_user("solto_backfill_legado", password="x")
        solto.perfil = Usuario.Perfil.GERENTE
        solto.empresa = self.empresa_a
        solto.save()

        self._rodar_migration()

        self.assertFalse(UsuarioFilial.objects.filter(usuario=solto).exists())

    def test_rodar_a_migration_duas_vezes_nao_duplica(self):
        comprador = Usuario.objects.create_user("comprador_backfill_dupla_execucao", password="x")
        comprador.perfil = Usuario.Perfil.COMPRADOR
        comprador.empresa = self.empresa_a
        comprador.filial = self.filial_a1
        comprador.save()

        self._rodar_migration()
        self._rodar_migration()

        self.assertEqual(UsuarioFilial.objects.filter(usuario=comprador).count(), 1)


class SincronizacaoCatalogoPermissoesTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 5: `filiais.gerenciar` e
    `provisoes.efetivar` foram acrescentadas a `CATALOGO_PERMISSOES` sem
    nenhuma migration de dados correspondente — ficaram funcionando via
    perfil legado (que não depende do banco), mas nunca apareciam no
    painel de atribuição granular. A migration
    `0008_sync_catalogo_permissoes_fechamento_final` fecha isso; o comando
    `sincronizar_permissoes` cobre o dia a dia daqui pra frente."""

    def test_todo_codigo_do_catalogo_em_memoria_existe_no_banco(self):
        from core.permissions import CATALOGO_PERMISSOES

        codigos_memoria = {codigo for codigo, _, _ in CATALOGO_PERMISSOES}
        codigos_banco = set(Permissao.objects.values_list("codigo", flat=True))
        self.assertEqual(codigos_memoria - codigos_banco, set())

    def test_filiais_gerenciar_e_provisoes_efetivar_persistidas(self):
        """A regressão específica que motivou a correção."""
        self.assertTrue(Permissao.objects.filter(codigo="filiais.gerenciar").exists())
        self.assertTrue(Permissao.objects.filter(codigo="provisoes.efetivar").exists())

    def test_comando_sincronizar_permissoes_e_idempotente(self):
        from io import StringIO

        from django.core.management import call_command

        total_antes = Permissao.objects.count()
        call_command("sincronizar_permissoes", stdout=StringIO())
        call_command("sincronizar_permissoes", stdout=StringIO())
        self.assertEqual(Permissao.objects.count(), total_antes)

    def test_sincronizacao_preserva_atribuicao_granular_existente(self):
        """Rodar o sincronizador de novo nunca desfaz uma atribuição já
        feita a um PerfilAcesso — só garante que o catálogo em si exista."""
        from io import StringIO

        from django.core.management import call_command
        from empresas.models import Empresa

        empresa = Empresa.objects.create(nome="Empresa Sync Permissoes", cnpj="97.000.000/0001-97")
        perfil = PerfilAcesso.objects.create(empresa=empresa, nome="Efetivador de Provisões")
        perfil.permissoes.add(Permissao.objects.get(codigo="provisoes.efetivar"))

        call_command("sincronizar_permissoes", stdout=StringIO())

        perfil.refresh_from_db()
        self.assertIn("provisoes.efetivar", perfil.permissoes.values_list("codigo", flat=True))

    def test_sincronizacao_corrige_nome_desatualizado_de_codigo_existente(self):
        """Revisão adversarial (Fechamento Final): a metade 'nome
        atualizado' do contrato do comando (docstring, linha 10: 'todo
        código do catálogo exista no banco com o nome atualizado') não
        tinha nenhum teste — só a presença do código era verificada."""
        from io import StringIO

        from django.core.management import call_command

        permissao = Permissao.objects.get(codigo="provisoes.efetivar")
        nome_correto = permissao.nome
        permissao.nome = "Nome Desatualizado De Propósito"
        permissao.save(update_fields=["nome"])

        call_command("sincronizar_permissoes", stdout=StringIO())

        permissao.refresh_from_db()
        self.assertEqual(permissao.nome, nome_correto)


class GateBCatalogoRelatoriosVerTestCase(TestCase):
    """Prompt 2, Gate B: `relatorios.ver` estava totalmente ausente do
    catálogo (nem em memória, nem no banco) — a Central de Relatórios não
    tinha nenhum gate de permissão. Agora o catálogo tem pelo menos 25
    códigos, e `relatorios.ver` é persistido e usado pela view."""

    def test_catalogo_tem_pelo_menos_25_permissoes(self):
        from core.permissions import CATALOGO_PERMISSOES

        self.assertGreaterEqual(len(CATALOGO_PERMISSOES), 25)
        codigos = {codigo for codigo, _, _ in CATALOGO_PERMISSOES}
        self.assertEqual(len(codigos), len(CATALOGO_PERMISSOES), "há código duplicado no catálogo")

    def test_relatorios_ver_persistida_no_banco(self):
        self.assertTrue(Permissao.objects.filter(codigo="relatorios.ver").exists())

    def test_catalogo_em_memoria_igual_ao_persistido(self):
        from core.permissions import CATALOGO_PERMISSOES

        codigos_memoria = {codigo for codigo, _, _ in CATALOGO_PERMISSOES}
        codigos_banco = set(Permissao.objects.values_list("codigo", flat=True))
        self.assertEqual(codigos_memoria, codigos_banco)

    def test_migration_de_relatorios_ver_e_idempotente(self):
        from io import StringIO

        from django.core.management import call_command

        total_antes = Permissao.objects.count()
        call_command("sincronizar_permissoes", stdout=StringIO())
        call_command("sincronizar_permissoes", stdout=StringIO())
        self.assertEqual(Permissao.objects.count(), total_antes)

    def test_perfil_customizado_pode_receber_relatorios_ver(self):
        from empresas.models import Empresa

        empresa = Empresa.objects.create(nome="Empresa Gate B", cnpj="96.111.222/0001-96")
        perfil = PerfilAcesso.objects.create(empresa=empresa, nome="Só Relatórios")
        perfil.permissoes.add(Permissao.objects.get(codigo="relatorios.ver"))
        self.assertIn("relatorios.ver", perfil.permissoes.values_list("codigo", flat=True))

    def test_todos_os_perfis_oficiais_acessam_relatorios_por_padrao(self):
        from core.permissions import usuario_tem_permissao
        from empresas.models import Empresa

        empresa = Empresa.objects.create(nome="Empresa Gate B Perfis", cnpj="96.222.333/0001-96")
        for perfil in (
            Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.GERENTE,
            Usuario.Perfil.FINANCEIRO, Usuario.Perfil.COMPRADOR,
        ):
            usuario = Usuario.objects.create_user(
                username=f"relver_{perfil}", password="x", perfil=perfil, empresa=empresa,
            )
            self.assertTrue(usuario_tem_permissao(usuario, "relatorios.ver"), f"perfil {perfil} sem relatorios.ver")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorios_home_esta_protegida_por_permissao_ver(self):
        """A view em si (`core.views.relatorios_home`) exige login (via
        `permissao_required`) — cobertura de que a rota não é mais um
        `@login_required` "solto" sem checagem de permissão nenhuma."""
        response = Client().get("/relatorios/")
        self.assertEqual(response.status_code, 302)  # redireciona para login
