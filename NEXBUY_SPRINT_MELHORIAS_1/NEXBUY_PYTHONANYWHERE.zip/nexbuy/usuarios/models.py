from django.contrib.auth.models import AbstractUser
from django.db import models

from core.models import TimeStampedModel


class Permissao(models.Model):
    """Uma permissão do catálogo do NEXBUY (Épico 7 — CORE 1.0), no formato
    "modulo.acao" (ex.: "compras.aprovar"). O catálogo é semeado por
    migration de dados a partir de `core.permissions.CATALOGO_PERMISSOES` —
    a fonte única, onde também está o mapeamento dos 4 perfis legados."""

    codigo = models.CharField("Código", max_length=60, unique=True)
    nome = models.CharField("Nome", max_length=120)

    class Meta:
        verbose_name = "Permissão"
        verbose_name_plural = "Permissões"
        ordering = ["codigo"]

    def __str__(self):
        return f"{self.nome} ({self.codigo})"


class PerfilAcesso(TimeStampedModel):
    """Perfil de acesso reutilizável (RBAC — Épico 7): um conjunto nomeado
    de permissões que pode ser atribuído a vários usuários. `empresa` vazia
    = perfil global (modelo/template reaproveitável por qualquer empresa)."""

    empresa = models.ForeignKey(
        "empresas.Empresa",
        on_delete=models.CASCADE,
        related_name="perfis_acesso",
        null=True,
        blank=True,
        verbose_name="Empresa",
        help_text="Deixe em branco para um perfil global, reutilizável por todas as empresas.",
    )
    nome = models.CharField("Nome do perfil", max_length=100)
    descricao = models.CharField("Descrição", max_length=200, blank=True)
    permissoes = models.ManyToManyField(Permissao, blank=True, related_name="perfis", verbose_name="Permissões")

    class Meta:
        verbose_name = "Perfil de Acesso"
        verbose_name_plural = "Perfis de Acesso"
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class Usuario(AbstractUser):
    """Usuário do NEXBUY. Estende o usuário padrão do Django com perfil e vínculo
    de empresa/filial, base do controle de permissões do sistema."""

    class Perfil(models.TextChoices):
        PROPRIETARIO = "proprietario", "Proprietário"
        GERENTE = "gerente", "Gerente"
        FINANCEIRO = "financeiro", "Financeiro"
        COMPRADOR = "comprador", "Comprador"

    perfil = models.CharField("Perfil", max_length=20, choices=Perfil.choices, default=Perfil.COMPRADOR)
    empresa = models.ForeignKey(
        "empresas.Empresa",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="usuarios",
        verbose_name="Empresa",
    )
    filial = models.ForeignKey(
        "filiais.Filial",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="usuarios",
        verbose_name="Filial",
        help_text="Obrigatório para Gerente, Financeiro e Comprador. Proprietário visualiza todas as filiais da empresa.",
    )
    # Épico 2A (UX): foto de apresentação do usuário — avatar na topbar e
    # na gestão de usuários. Campo puramente visual, sem efeito de negócio.
    foto = models.ImageField("Foto", upload_to="usuarios/fotos/", null=True, blank=True)

    # ------------------------------------------------------------------
    # RBAC e multiempresa (Épicos 7 e 9 — CORE 1.0). Tudo opcional e
    # aditivo: um usuário sem nada disso preenchido se comporta exatamente
    # como antes (só o perfil legado acima decide o acesso).
    # ------------------------------------------------------------------
    perfis_acesso = models.ManyToManyField(
        PerfilAcesso, blank=True, related_name="usuarios", verbose_name="Perfis de acesso"
    )
    permissoes_individuais = models.ManyToManyField(
        Permissao, blank=True, related_name="usuarios_diretos", verbose_name="Permissões individuais"
    )
    empresas_autorizadas = models.ManyToManyField(
        "empresas.Empresa",
        through="usuarios.UsuarioEmpresa",
        blank=True,
        related_name="usuarios_autorizados",
        verbose_name="Empresas autorizadas",
    )

    class Meta:
        verbose_name = "Usuário"
        verbose_name_plural = "Usuários"

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.get_perfil_display()})"

    @property
    def is_proprietario(self):
        return self.perfil == self.Perfil.PROPRIETARIO

    @property
    def is_gerente(self):
        return self.perfil == self.Perfil.GERENTE

    @property
    def is_financeiro(self):
        return self.perfil == self.Perfil.FINANCEIRO

    @property
    def is_comprador(self):
        return self.perfil == self.Perfil.COMPRADOR

    def filiais_visiveis(self, empresa=None):
        """Retorna o queryset de filiais que este usuário pode enxergar.

        Sem `empresa` (todos os chamadores históricos): comportamento
        idêntico ao de sempre — Proprietário vê todas as filiais ativas da
        própria empresa; os demais perfis, só a própria filial.

        Com `empresa` (Épico 9 — Contexto por Empresa): Sprint de Correções
        Críticas — passa a delegar para `filiais_autorizadas_para`, a nova
        fonte central de verdade (baseada em `UsuarioFilial`), em vez de
        reimplementar a regra aqui. Mantido como método por compatibilidade
        com todos os chamadores existentes (não removido nesta Sprint).
        """
        from filiais.models import Filial

        if empresa is None:
            if self.is_proprietario and self.empresa_id:
                return Filial.objects.filter(empresa=self.empresa, ativo=True)
            if self.filial_id:
                return Filial.objects.filter(pk=self.filial_id)
            return Filial.objects.none()

        return filiais_autorizadas_para(self, empresa)

    def empresas_do_grupo(self):
        """Empresas do MESMO Grupo Empresarial da empresa principal deste
        usuário (Sprint de Correções Críticas — Seção 5): fronteira usada
        para restringir a quem um Proprietário pode conceder autorização,
        evitando que `empresas_autorizadas` alcance empresas de outro
        cliente. Sem empresa principal ou sem grupo, devolve só a própria
        empresa principal (nunca o banco inteiro)."""
        from empresas.models import Empresa

        if not self.empresa_id:
            return Empresa.objects.none()
        if self.empresa.grupo_id is None:
            return Empresa.objects.filter(pk=self.empresa_id)
        return Empresa.objects.filter(grupo_id=self.empresa.grupo_id, ativo=True)

    def empresas_disponiveis(self):
        """Empresas em que este usuário pode trabalhar (Épico 9): a empresa
        principal + as autorizações explícitas ativas, sem duplicar.

        Fechamento Final (Prompt 1, Seção 4.3): uma autorização
        `UsuarioEmpresa` histórica para uma Empresa de OUTRO Grupo nunca
        concede acesso, mesmo que o registro continue `ativo=True` no
        banco. "Outro Grupo" só é barrado quando dá pra PROVAR que são
        grupos diferentes — as duas empresas têm `grupo_id` não-nulo e ele
        diverge. Quando qualquer um dos dois lados não tem Grupo definido
        (`None`), o comportamento histórico é preservado: `Empresa.grupo`
        é opcional, e uma autorização direta entre duas empresas sem Grupo
        cadastrado sempre foi válida (era o único jeito de fazer isso antes
        do conceito de Grupo existir). Por isso este método NÃO reaproveita
        `empresas_do_grupo()` — aquele método é deliberadamente mais
        conservador, pensado para a tela que OFERECE novas autorizações
        (Sprint de Correções Críticas, Seção 5), não para revalidar as que
        já existem."""
        from empresas.models import Empresa

        ids = set()
        grupo_principal = None
        if self.empresa_id:
            ids.add(self.empresa_id)
            grupo_principal = self.empresa.grupo_id

        for autorizacao in self.autorizacoes_empresa.filter(
            ativo=True, empresa__ativo=True
        ).select_related("empresa"):
            grupo_autorizada = autorizacao.empresa.grupo_id
            grupos_provadamente_diferentes = (
                grupo_principal is not None and grupo_autorizada is not None and grupo_autorizada != grupo_principal
            )
            if not grupos_provadamente_diferentes:
                ids.add(autorizacao.empresa_id)

        return Empresa.objects.filter(pk__in=ids, ativo=True).order_by("nome")


class UsuarioEmpresa(TimeStampedModel):
    """Autorização explícita de um usuário em uma empresa (Épicos 7 e 9):
    dá acesso àquela empresa no seletor de contexto e carrega o limite de
    compra individual do usuário nela (quando definido)."""

    usuario = models.ForeignKey(
        Usuario, on_delete=models.CASCADE, related_name="autorizacoes_empresa", verbose_name="Usuário"
    )
    empresa = models.ForeignKey(
        "empresas.Empresa", on_delete=models.CASCADE, related_name="autorizacoes_usuario", verbose_name="Empresa"
    )
    limite_compra = models.DecimalField(
        "Limite de compra individual",
        max_digits=14,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Compras acima deste valor sempre exigem aprovação. Deixe em branco para não limitar.",
    )
    ativo = models.BooleanField("Ativa", default=True)
    # RC do Épico 01 (Correção 03 — Motor de Capacidade): o Financeiro pode
    # bloquear temporariamente um comprador; toda compra dele passa a ser
    # bloqueada na origem (status Bloqueada), até ser liberado de novo.
    bloqueado = models.BooleanField(
        "Comprador bloqueado",
        default=False,
        help_text="Bloqueia novas compras deste usuário nesta empresa até ser liberado pelo Financeiro.",
    )

    class Meta:
        verbose_name = "Autorização de Empresa"
        verbose_name_plural = "Autorizações de Empresa"
        constraints = [
            models.UniqueConstraint(fields=["usuario", "empresa"], name="autorizacao_unica_usuario_empresa")
        ]

    def __str__(self):
        return f"{self.usuario.username} → {self.empresa.nome}"


class UsuarioFilial(TimeStampedModel):
    """Vínculo operacional explícito entre um usuário e uma Filial (Sprint
    de Correções Críticas — Seção 7).

    `UsuarioEmpresa` autoriza a EMPRESA inteira (todas as filiais dela);
    este model dá a granularidade que faltava — quais filiais, dentro de
    uma empresa autorizada, o usuário de fato opera. É a fonte usada por
    `filiais_autorizadas_para` (e, por consequência, por
    `Usuario.filiais_visiveis`) para todo perfil não-Proprietário.

    Compatibilidade: `Usuario.empresa`/`Usuario.filial` (principais) e
    `UsuarioEmpresa` (autorização + limite por empresa) são preservados
    sem alteração nesta Sprint — este model só ACRESCENTA granularidade,
    nunca substitui os outros vínculos."""

    usuario = models.ForeignKey(
        Usuario, on_delete=models.CASCADE, related_name="vinculos_filial", verbose_name="Usuário"
    )
    filial = models.ForeignKey(
        "filiais.Filial", on_delete=models.CASCADE, related_name="vinculos_usuario", verbose_name="Filial"
    )
    ativo = models.BooleanField("Ativo", default=True)

    class Meta:
        verbose_name = "Vínculo Usuário-Filial"
        verbose_name_plural = "Vínculos Usuário-Filial"
        constraints = [
            models.UniqueConstraint(fields=["usuario", "filial"], name="vinculo_unico_usuario_filial")
        ]

    def __str__(self):
        return f"{self.usuario.username} → {self.filial.nome}"


def filiais_autorizadas_para(usuario, empresa):
    """Fonte central de verdade para quais Filiais de uma Empresa um
    usuário pode operar (Sprint de Correções Críticas — Seção 9; Fechamento
    Final — Prompt 1, Seção 4.2).

    Proprietário: todas as filiais ativas da empresa (como sempre).
    Demais perfis: apenas as filiais com `UsuarioFilial` ativo — nunca
    mais "toda a empresa só por estar autorizado nela". Todos os módulos
    (Compra, Provisão, Receita, Custo Fixo/Variável, relatórios, busca
    global) devem chamar esta função em vez de duplicar a regra.

    Defesa em profundidade (Fechamento Final, Seção 4.2, último item):
    `empresa` fora de `usuario.empresas_disponiveis()` nunca devolve
    filial nenhuma, mesmo que o chamador esqueça de validar isso antes —
    toda tela de verdade já valida via `empresa_ativa(request)`, mas esta
    função não pode depender só disso.

    Compatibilidade: `UsuarioFilial` só passou a ser criado a partir da
    Sprint de Correções Críticas (Assistente de Implantação, etapas 3/4).
    Usuário que NUNCA teve nenhum registro `UsuarioFilial` (nem ativo, nem
    inativo) cai no comportamento histórico de uma única filial (a
    principal), escopada pela empresa pedida — nunca "vaza" para outra
    empresa só por ausência de vínculo. A partir do momento em que o
    usuário ganha QUALQUER vínculo `UsuarioFilial` — mesmo que ele próprio
    seja desativado depois — o fallback para a principal fecha para
    sempre: o resultado passa a valer exclusivamente os vínculos ATIVOS, e
    se todos estiverem inativos o resultado é vazio. Reabrir a principal
    nesse caso seria reconceder um acesso que já foi explicitamente
    revogado — por isso o teste aqui é `.exists()` (teve algum, ativo ou
    não), não `.filter(ativo=True).exists()` (tem algum ativo agora)."""
    from filiais.models import Filial

    if usuario is None or empresa is None:
        return Filial.objects.none()
    if not usuario.empresas_disponiveis().filter(pk=empresa.pk).exists():
        return Filial.objects.none()
    if usuario.is_proprietario:
        return Filial.objects.filter(empresa=empresa, ativo=True)
    if not usuario.vinculos_filial.exists():
        return Filial.objects.filter(pk=usuario.filial_id, empresa=empresa, ativo=True)
    return Filial.objects.filter(
        empresa=empresa,
        ativo=True,
        vinculos_usuario__usuario=usuario,
        vinculos_usuario__ativo=True,
    ).distinct()
