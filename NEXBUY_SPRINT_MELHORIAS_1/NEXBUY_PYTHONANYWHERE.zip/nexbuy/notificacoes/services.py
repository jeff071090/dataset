"""Serviços da Central de Notificações (Épico 11 — CORE 1.0).

`notificar` é o ponto único de emissão — os services de negócio
(`compras`, `gestao_compras`) chamam estas funções explicitamente nos
eventos relevantes. Nenhum signal, nenhuma emissão implícita.
"""
from typing import Iterable, Optional

from usuarios.models import Usuario

from .canais import CANAIS_ATIVOS
from .models import Notificacao


def notificar(usuario, tipo: str, titulo: str, mensagem: str = "", link: str = "",
              empresa=None, chave: str = "") -> Optional[Notificacao]:
    """Cria (e entrega pelos canais ativos) uma notificação para UM usuário.

    `chave` (opcional) deduplica notificações derivadas de estado — se o
    usuário já tem uma notificação com a mesma chave, nada é criado.
    """
    if usuario is None or not getattr(usuario, "pk", None):
        return None
    if chave and Notificacao.objects.filter(usuario=usuario, chave=chave).exists():
        return None

    notificacao = Notificacao.objects.create(
        usuario=usuario, empresa=empresa, tipo=tipo, titulo=titulo,
        mensagem=mensagem, link=link, chave=chave,
    )
    for canal in CANAIS_ATIVOS:
        canal.enviar(notificacao)
    return notificacao


def notificar_varios(usuarios: Iterable, tipo: str, titulo: str, mensagem: str = "",
                     link: str = "", empresa=None, chave_prefixo: str = "") -> int:
    """Notifica uma coleção de usuários; devolve quantas foram criadas."""
    criadas = 0
    for usuario in usuarios:
        chave = f"{chave_prefixo}:{usuario.pk}" if chave_prefixo else ""
        if notificar(usuario, tipo, titulo, mensagem, link, empresa, chave):
            criadas += 1
    return criadas


def notificar_perfis(empresa, perfis, tipo: str, titulo: str, mensagem: str = "",
                     link: str = "", excluir_usuario=None, chave_prefixo: str = "") -> int:
    """Notifica todos os usuários ativos de certos perfis de uma empresa —
    o padrão dos eventos de aprovação (avisar quem pode decidir)."""
    usuarios = Usuario.objects.filter(empresa=empresa, perfil__in=perfis, is_active=True)
    if excluir_usuario is not None and getattr(excluir_usuario, "pk", None):
        usuarios = usuarios.exclude(pk=excluir_usuario.pk)
    return notificar_varios(usuarios, tipo, titulo, mensagem, link, empresa, chave_prefixo)


def gerar_notificacoes_de_vencimento(usuario, filial, data_referencia) -> int:
    """Evento "Conta vencendo" (Épico 11): deriva da Agenda Financeira os
    compromissos pendentes de HOJE e notifica o usuário, com chave de
    deduplicação por item+dia (pode ser chamado a cada visita ao Dashboard
    sem nunca duplicar). Import tardio da agenda para manter o app de
    notificações sem dependência de módulo no finance_engine."""
    from finance_engine.agenda import agenda_do_dia

    from core.utils import formatar_moeda

    criadas = 0
    for item in agenda_do_dia(filial, data_referencia):
        if not item.pendente:
            continue
        chave = f"venc:{item.origem}:{item.referencia_id}:{data_referencia:%Y%m%d}"
        criada = notificar(
            usuario,
            Notificacao.Tipo.CONTA_VENCENDO,
            "Compromisso vence hoje",
            f"{item.tipo}: {item.descricao} — {formatar_moeda(item.valor, incluir_prefixo=True)}.",
            "/financeiro/agenda/",
            filial.empresa,
            chave=chave,
        )
        if criada:
            criadas += 1
    return criadas


def contar_nao_lidas(usuario) -> int:
    if usuario is None or not getattr(usuario, "pk", None):
        return 0
    return Notificacao.objects.filter(usuario=usuario, lida=False).count()


def marcar_todas_lidas(usuario) -> int:
    return Notificacao.objects.filter(usuario=usuario, lida=False).update(lida=True)
