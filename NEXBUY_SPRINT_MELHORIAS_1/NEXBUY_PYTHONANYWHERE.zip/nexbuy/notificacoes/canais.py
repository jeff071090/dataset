"""Canais de entrega da Central de Notificações (Épico 11 — CORE 1.0).

O canal "Sistema" (a notificação persistida, exibida no sino do topo) é o
único implementado. Push, WhatsApp e E-mail são CONTRATOS preparatórios —
o mesmo padrão consciente de `finance_engine/interfaces.py`: a arquitetura
fica pronta para plugar um provedor real no futuro, sem nenhuma
implementação especulativa agora (fora do escopo do CORE 1.0).
"""
from abc import ABC, abstractmethod

from .models import Notificacao


class CanalNotificacaoBase(ABC):
    """Contrato de um canal de entrega: recebe uma Notificação já
    persistida e a entrega pelo meio específico do canal."""

    nome: str = "base"

    @abstractmethod
    def enviar(self, notificacao: Notificacao) -> bool:
        """Entrega a notificação. Devolve True em sucesso."""


class CanalSistema(CanalNotificacaoBase):
    """Canal padrão: a própria persistência da Notificação já é a entrega
    (aparece no sino do topo e na Central de Notificações)."""

    nome = "sistema"

    def enviar(self, notificacao: Notificacao) -> bool:
        return notificacao.pk is not None


class CanalPushBase(CanalNotificacaoBase):
    """Contrato para push notifications (navegador/celular). Não
    implementado no CORE 1.0 — apenas o ponto de extensão."""

    nome = "push"


class CanalWhatsAppBase(CanalNotificacaoBase):
    """Contrato para envio via WhatsApp. Não implementado no CORE 1.0."""

    nome = "whatsapp"


class CanalEmailBase(CanalNotificacaoBase):
    """Contrato para envio por e-mail. Não implementado no CORE 1.0."""

    nome = "email"


# Canais efetivamente ativos hoje. Para ativar um canal novo no futuro:
# implementar a classe concreta e adicioná-la aqui — nenhum outro ponto
# do sistema precisa mudar (o service percorre esta lista).
CANAIS_ATIVOS: tuple[CanalNotificacaoBase, ...] = (CanalSistema(),)
