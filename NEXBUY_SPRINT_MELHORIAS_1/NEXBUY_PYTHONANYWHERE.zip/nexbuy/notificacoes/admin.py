from django.contrib import admin

from .models import Notificacao


@admin.register(Notificacao)
class NotificacaoAdmin(admin.ModelAdmin):
    list_display = ("usuario", "tipo", "titulo", "empresa", "lida", "criado_em")
    list_filter = ("tipo", "lida", "empresa")
    search_fields = ("titulo", "mensagem", "usuario__username")
