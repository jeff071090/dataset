"""Testes da Central de Notificações (Épicos 11 e 16 — CORE 1.0)."""
from datetime import date
from decimal import Decimal

from django.test import TestCase

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from compras.services import avaliar_e_criar_compra
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, Receita
from notificacoes.models import Notificacao
from notificacoes.services import contar_nao_lidas, marcar_todas_lidas, notificar
from usuarios.models import Usuario


class NotificacoesTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.empresa = Empresa.objects.create(nome="Notif Ltda", cnpj="44.444.444/0001-44")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=cls.empresa,
            regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
        )
        Receita.objects.create(filial=cls.filial, mes=date.today().replace(day=1), faturamento=Decimal("100000"))
        cls.fornecedor = Fornecedor.objects.create(empresa=cls.empresa, nome="Fornecedor N")
        cls.categoria = Categoria.objects.create(empresa=cls.empresa, nome="Categoria N")

        cls.comprador = Usuario.objects.create_user("nt_comprador", password="x")
        cls.comprador.perfil = Usuario.Perfil.COMPRADOR
        cls.comprador.empresa = cls.empresa
        cls.comprador.filial = cls.filial
        cls.comprador.save()

        cls.gerente = Usuario.objects.create_user("nt_gerente", password="x")
        cls.gerente.perfil = Usuario.Perfil.GERENTE
        cls.gerente.empresa = cls.empresa
        cls.gerente.filial = cls.filial
        cls.gerente.save()

    def test_chave_de_deduplicacao_impede_notificacao_repetida(self):
        primeira = notificar(self.gerente, Notificacao.Tipo.CONTA_VENCENDO, "Vence hoje", chave="venc:x:1")
        repetida = notificar(self.gerente, Notificacao.Tipo.CONTA_VENCENDO, "Vence hoje", chave="venc:x:1")
        self.assertIsNotNone(primeira)
        self.assertIsNone(repetida)
        self.assertEqual(self.gerente.notificacoes.count(), 1)

    def test_compra_acima_do_limite_notifica_o_gerente(self):
        avaliar_e_criar_compra(
            filial=self.filial,
            fornecedor=self.fornecedor,
            valor=Decimal("999999"),
            categoria=self.categoria,
            data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None,
            usuario=self.comprador,
        )
        tipos = set(self.gerente.notificacoes.values_list("tipo", flat=True))
        self.assertIn(Notificacao.Tipo.SOLICITACAO_LIMITE, tipos)
        # O próprio comprador (autor) não é notificado da própria solicitação.
        self.assertFalse(
            self.comprador.notificacoes.filter(tipo=Notificacao.Tipo.SOLICITACAO_LIMITE).exists()
        )

    def test_contar_e_marcar_todas_lidas(self):
        notificar(self.gerente, Notificacao.Tipo.MUDANCA_STATUS, "Uma")
        notificar(self.gerente, Notificacao.Tipo.MUDANCA_STATUS, "Outra")
        self.assertEqual(contar_nao_lidas(self.gerente), 2)
        marcar_todas_lidas(self.gerente)
        self.assertEqual(contar_nao_lidas(self.gerente), 0)
