from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from .models import Notificacao
from .services import marcar_todas_lidas


@login_required
def lista_notificacoes(request):
    """Central de Notificações do usuário logado — as 50 mais recentes."""
    notificacoes = request.user.notificacoes.select_related("empresa")[:50]
    return render(request, "notificacoes/lista.html", {"notificacoes": notificacoes})


@login_required
def marcar_lidas(request):
    if request.method == "POST":
        marcar_todas_lidas(request.user)
    return redirect("notificacoes:lista")


@login_required
def abrir_notificacao(request, pk):
    """Marca UMA notificação como lida e segue para o link dela (ou volta
    para a lista quando a notificação não tem link)."""
    notificacao = request.user.notificacoes.filter(pk=pk).first()
    if notificacao is None:
        return redirect("notificacoes:lista")
    if not notificacao.lida:
        notificacao.lida = True
        notificacao.save(update_fields=["lida", "atualizado_em"])
    return redirect(notificacao.link or "notificacoes:lista")
