from django.urls import path

from . import views

app_name = "notificacoes"

urlpatterns = [
    path("", views.lista_notificacoes, name="lista"),
    path("marcar-lidas/", views.marcar_lidas, name="marcar_lidas"),
    path("<int:pk>/abrir/", views.abrir_notificacao, name="abrir"),
]
