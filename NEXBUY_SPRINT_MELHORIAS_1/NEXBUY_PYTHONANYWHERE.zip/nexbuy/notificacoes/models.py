"""Central de Notificações (Épico 11 — CORE 1.0).

Uma Notificação é sempre dirigida a UM usuário (quem deve agir/saber) e
nasce de um evento de negócio real (compra criada/aprovada/rejeitada,
solicitação pendente, conta vencendo, capacidade excedida, parcelamento
criado, mudança de status). A emissão acontece nos services que provocam
o evento — nunca via signal implícito, seguindo a decisão arquitetural
do projeto de manter efeitos colaterais sempre explícitos e rastreáveis.
"""
from django.conf import settings
from django.db import models

from core.models import TimeStampedModel


class Notificacao(TimeStampedModel):
    class Tipo(models.TextChoices):
        COMPRA_CRIADA = "compra_criada", "Compra criada"
        COMPRA_APROVADA = "compra_aprovada", "Compra aprovada"
        COMPRA_REJEITADA = "compra_rejeitada", "Compra rejeitada"
        SOLICITACAO_LIMITE = "solicitacao_limite", "Solicitação de limite/aprovação"
        CONTA_VENCENDO = "conta_vencendo", "Conta vencendo"
        CAPACIDADE_EXCEDIDA = "capacidade_excedida", "Capacidade excedida"
        PARCELAMENTO_CRIADO = "parcelamento_criado", "Parcelamento criado"
        MUDANCA_STATUS = "mudanca_status", "Mudança de status"

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notificacoes", verbose_name="Usuário"
    )
    empresa = models.ForeignKey(
        "empresas.Empresa",
        on_delete=models.CASCADE,
        related_name="notificacoes",
        null=True,
        blank=True,
        verbose_name="Empresa",
    )
    tipo = models.CharField("Tipo", max_length=25, choices=Tipo.choices)
    titulo = models.CharField("Título", max_length=120)
    mensagem = models.CharField("Mensagem", max_length=255, blank=True)
    link = models.CharField("Link", max_length=200, blank=True)
    lida = models.BooleanField("Lida", default=False)
    # Chave de deduplicação para notificações derivadas de estado (ex.:
    # "conta vencendo hoje") — permite gerar sob demanda sem duplicar.
    chave = models.CharField("Chave de deduplicação", max_length=120, blank=True, default="")

    class Meta:
        verbose_name = "Notificação"
        verbose_name_plural = "Notificações"
        ordering = ["-criado_em"]
        indexes = [models.Index(fields=["usuario", "lida"], name="notif_usuario_lida_idx")]
        constraints = [
            models.UniqueConstraint(
                fields=["usuario", "chave"],
                condition=~models.Q(chave=""),
                name="notif_chave_unica_por_usuario",
            )
        ]

    def __str__(self):
        return f"{self.get_tipo_display()} — {self.titulo} ({self.usuario.username})"
