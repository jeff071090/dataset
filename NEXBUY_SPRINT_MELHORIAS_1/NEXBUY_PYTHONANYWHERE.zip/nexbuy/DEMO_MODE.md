# DEMO_MODE.md — Modo Demonstração do NEXBUY

Este documento explica como ativar, desativar, atualizar e usar a experiência de demonstração do NEXBUY em uma apresentação comercial. A base de demonstração cobre todas as novidades da plataforma (ver as seções "Novidades ... na demonstração", abaixo).

> **No pacote de demonstração comercial (Etapa 02), a demo roda 100% isolada**:
> os launchers `.bat` da raiz usam `--settings=nexbuy.settings_demo` em toda
> chamada de `manage.py`, o que aponta tudo para `db_demo_cliente.sqlite3` e
> `media_demo_cliente\` — nunca o banco/mídia principal (`db.sqlite3`/`media\`).
> O `DEMO_MODE` é decidido pelo **launcher**, não por arquivo de configuração:
> `iniciar_demo_cliente_limpa.bat` define `DEMO_MODE=False` (cenário **limpo**:
> banco vazio, sem badge, sem `seed_demo` — reproduz a experiência
> cliente-ready) e `iniciar_demo_cenario_pronto.bat` define `DEMO_MODE=True`
> (cenário **pronto**: dados fictícios do `seed_demo`, badge "Modo
> Demonstração" visível). Operação completa dos launchers em
> [NEXBUY_GUIA_DEMO_CLIENTE.md](NEXBUY_GUIA_DEMO_CLIENTE.md).

> **Escopo atual do produto (vale também para a demo):** o NEXBUY é 100%
> web e não se integra a ERP. **Receitas, custos, compras: lançamento
> manual** — receita mensal, receitas extras, custos fixos e custos
> variáveis alimentam a projeção de compra e os limites dos compradores.
> A **Análise Financeira** (DRE, créditos × débitos, saúde financeira)
> é vista por Proprietário, Gerente e Financeiro; o Comprador continua com
> a visão sintética, sem dado financeiro sensível. **DDA: integração
> futura prevista (não conectada).** Não há controle de estoque.

---

## O que é o Modo Demonstração

O Modo Demonstração é a combinação de duas coisas independentes, que juntas produzem uma experiência pronta para apresentar a um cliente:

1. **Uma empresa fictícia completa** — "Farmácia Vida Plena" — com fornecedores, categorias, provisões e compras em estados variados, gerada pelo comando `python manage.py seed_demo --settings=nexbuy.settings_demo`. Essa empresa é **inteiramente separada** da empresa de desenvolvimento ("Farmácia Modelo") criada pelo comando `seed_dados` já existente desde a Etapa 1 — os dois comandos nunca colidem, porque usam CNPJ, filial e nomes de usuário diferentes.
2. **Um indicador visual de configuração** (`DEMO_MODE=True`) — mostra um badge "Modo Demonstração" no topo de toda tela, para que ninguém confunda um ambiente de demonstração com produção.

Nenhuma regra de negócio, banco de dados (schema) ou arquitetura foi alterada para isso — o Modo Demonstração usa exatamente os mesmos models, services e views do restante do sistema. A "mágica" está inteiramente nos dados que o `seed_demo` cria, chamando os mesmos services reais (`avaliar_e_criar_compra`, `criar_provisao`, `motor_aprovacao_provisao`) que qualquer uso real do NEXBUY chamaria.

## Como ativar

**No pacote de demonstração comercial**, basta rodar
`iniciar_demo_cenario_pronto.bat` (duplo clique). Ele faz tudo em sequência,
sempre no banco isolado de demo: aplica as migrações, roda `seed_demo`,
liga `DEMO_MODE=True` (badge visível) e abre a tela de login com as
credenciais impressas no terminal. Nada precisa ser editado em `.env`.

Se preferir os passos manuais (ex.: inspecionar algo no meio do caminho),
**toda chamada de `manage.py` da demo precisa da flag
`--settings=nexbuy.settings_demo`** — sem ela, o comando opera no
banco/mídia principal:

```bash
python manage.py migrate --settings=nexbuy.settings_demo
python manage.py seed_demo --settings=nexbuy.settings_demo
python manage.py runserver --settings=nexbuy.settings_demo
```

(no modo manual, defina também a variável de ambiente `DEMO_MODE=True`
antes de `runserver` para exibir o badge — é exatamente o que o launcher
faz).

`DEMO_MODE=True` por si só **não cria nenhum dado** — ele só liga o badge visual e a disponibilidade do tour guiado. Quem efetivamente popula o sistema com a "Farmácia Vida Plena" é o comando `seed_demo`, executado à parte (o mesmo padrão já usado por `seed_dados` desde a Etapa 1 — nenhum comando de gestão do Django roda sozinho ao subir o servidor, por design, para nunca escrever no banco sem uma ação explícita).

## Como desativar

O badge some sozinho quando a demo não está no cenário pronto: o launcher
do cenário limpo (`iniciar_demo_cliente_limpa.bat`) define `DEMO_MODE=False`,
e sem a variável de ambiente o padrão também é `False`.

Os dados da "Farmácia Vida Plena" continuam no banco **de demo** depois de desligar o indicador — o `DEMO_MODE` só controla o badge visual, não apaga nada. Para remover completamente os dados de demonstração, rode `resetar_demo_cliente_limpa.bat` (pede confirmação digitada e apaga **só** `db_demo_cliente.sqlite3` e `media_demo_cliente\`, nunca o banco principal).

## Como atualizar os dados fictícios

Basta rodar novamente `iniciar_demo_cenario_pronto.bat` (ele reexecuta o
`seed_demo`), ou manualmente:
```bash
python manage.py seed_demo --settings=nexbuy.settings_demo
```
O comando é **idempotente**: a Empresa, as Filiais, os usuários, os vínculos, os fornecedores e as categorias são atualizados no lugar (nunca duplicados); as Compras e Provisões de demonstração são **recriadas do zero** a cada execução, para que a "história" do mês (dias verdes/laranjas/vermelhos no calendário, aprovações pendentes, etc.) sempre faça sentido em relação à data em que o comando foi executado. Rode-o no dia da apresentação (ou na véspera) para garantir que o calendário e os prazos mostrem sempre o mês corrente.

## Como utilizar durante apresentações

### Credenciais de demonstração

| Usuário | Senha | Perfil | Nome |
|---|---|---|---|
| `demo_proprietario` | `nexbuy123` | Proprietário | Roberto Almeida |
| `demo_gerente` | `nexbuy123` | Gerente | Fernanda Costa |
| `demo_financeiro` | `nexbuy123` | Financeiro | Marcos Vinícius |
| `demo_comprador` | `nexbuy123` | Comprador | Juliana Ramos |
| `demo_comprador2` | `nexbuy123` | Comprador | Pedro Henrique |
| `demo_comprador3` | `nexbuy123` | Comprador (BLOQUEADA) | Carla Menezes |

Estas credenciais são **diferentes** das credenciais de desenvolvimento (`proprietario`/`gerente`/`financeiro`/`comprador`, documentadas no `README.md`) — evita que os dois conjuntos de dados (dev e demo) se misturem na cabeça de quem está testando.

A senha pública acima vale **só na demonstração local** (PC do
apresentador). O menu **Trocar perfil de demonstração** (clique no nome, no
canto superior direito) lista os **6** usuários — inclusive o Pedro (limite
individual de R$ 2.000 **por dia**, somando as compras do dia) e a Carla
(bloqueada).

## Demonstração publicada na internet (PythonAnywhere)

Para a cliente testar do computador dela, a mesma demonstração pode subir
de graça no PythonAnywhere — passo a passo completo em
[docs/DEPLOY_PYTHONANYWHERE_DEMO.md](docs/DEPLOY_PYTHONANYWHERE_DEMO.md)
(scripts em `deploy/pythonanywhere/`). Três peças garantem que ninguém
entre com a senha pública num site aberto:

- **`DEMO_EXIBIR_SENHA`** (settings/`.env`): decide se a tela de login mostra
  a dica "Usuários de demonstração (senha: ...)". Por padrão **segue o
  `DEBUG`** — na demo local (`DEBUG=True`) a dica continua exatamente como
  sempre; num servidor (`DEBUG=False`) a tela mostra só o aviso neutro
  "Ambiente de demonstração com dados fictícios. Entre com o usuário e a
  senha que você recebeu.", sem usuário nem senha.
- **`python manage.py definir_senha_demo`**: troca a senha dos 6 usuários de
  demonstração (só da empresa fictícia, CNPJ 98765432...; nunca usuários de
  outra empresa nem superusuários) e deixa inutilizável a senha pública de
  qualquer outro usuário dessa empresa (ex.: `vp_atendente_beatriz`, do
  histórico da auditoria). A senha é digitada escondida (duas vezes) ou
  gerada: `--gerar` (uma senha forte, mostrada uma vez), `--individual`
  (uma por usuário), `--usuarios demo_gerente,demo_comprador` (subconjunto)
  e `--verificar` (só confere, e só lendo: sai com código 3 se QUALQUER
  usuário ativo — inclusive superusuário ou de outra empresa, que ele não
  troca — entra com a senha pública, e com código 4 se algum dos 6 está sem
  senha; avisa, sem falhar, de usuário dos 6 desativado). `--bloquear`
  desativa a senha pública de quem ainda a usa na empresa fictícia
  (ninguém entra até receber senha nova) — os scripts do PythonAnywhere
  rodam isso logo depois do seed, para o site nunca aceitar a senha
  pública nem se a digitação da senha nova não terminar. A senha digitada
  precisa de **12 caracteres** ou mais e não pode conter "nexbuy" nem
  lembrar a senha pública (Nexbuy123, nexbuy123!, nexbuy2026... são
  recusadas). Nunca aceita a senha por argumento nem por variável de
  ambiente; funciona com `DEBUG=False`.
- **Regra de senha do projeto** (`core.senha_demo.SenhaPublicaDemoValidator`,
  em `AUTH_PASSWORD_VALIDATORS`): Meu Perfil, Primeiro Acesso e a senha
  inicial do cadastro de usuário (NCC) recusam a senha pública e as
  variações dela. O `seed_demo` grava a senha pública direto, sem
  validador — a demo local continua igual.
- **`python manage.py seed_demo --manter-senhas`**: renova o cenário (datas
  de hoje) sem trocar a senha de quem já existe — só usuários criados agora
  recebem a senha pública. Os 6 usuários de login sempre saem **ativos**
  (se a cliente desativar um deles, renovar o cenário devolve o acesso).
  Com `DEBUG=False` o seed termina com um aviso
  destacado se algum usuário da demonstração ainda estiver com a senha
  pública. (No servidor o seed continua bloqueado: os scripts passam
  `ALLOW_SEED_IN_PRODUCTION=True` só na linha do comando, nunca no `.env`.)

Com `DEMO_MODE=True`, as páginas também saem com
`<meta name="robots" content="noindex, nofollow">`, e o `/robots.txt`
(servido pelo Django) pede aos buscadores para não indexar nada.

## Análise Financeira na demonstração (12 meses de histórico)

Para a DRE, os Créditos × Débitos e a Saúde Financeira parecerem de uma
farmácia de verdade, o `seed_demo` cria nas **duas lojas** da Farmácia Vida
Plena (Loja Centro e Loja Bairro) 12 meses de histórico até o mês corrente
(mais 1 mês de "aquecimento" para as parcelas), sempre com datas
**relativas a hoje**:

- **Receita mensal com sazonalidade** — Loja Centro entre ~R$ 257 mil e
  ~R$ 311 mil, Loja Bairro entre ~R$ 143 mil e ~R$ 173 mil; pico de vendas
  3 meses atrás e queda até o mês corrente (a Saúde Financeira acusa a
  tendência).
- **Receitas extras todo mês** — convênios/PBM (Farmácia Popular),
  serviços farmacêuticos e, na Loja Centro, rendimento de aplicação.
- **Custos fixos** (~20% a 22% da receita: folha, aluguel, energia e água,
  contabilidade, sistema) e **custos variáveis** todo mês (~8%: impostos
  sobre vendas, taxas de cartão, comissões, entregas).
- **Compras aprovadas** em torno de 60% a 66% da receita, com parcelas
  30/60/90 geradas pelas funções reais do sistema (parcela vencida = paga;
  a partir de hoje = pendente): pedido mensal do laboratório, perfumaria e
  higiene acima do limite do dia (já aprovados) e reposição diária com as
  distribuidoras. O mês corrente é preenchido até ONTEM, no ritmo dos dias
  úteis já vividos, sem mudar as cores do roteiro do calendário.
- **Um mês ruim** (5 meses atrás): compras muito acima do normal, mês
  fechado no **prejuízo** e, no mês seguinte, o **caixa no vermelho** em
  Créditos × Débitos.
- **Capacidade Financeira** com 90% da disponibilidade destinada a compras
  — o limite diário dos compradores fica coerente com o peso de compras de
  uma farmácia (~63% da receita).

Onde ver: menu **Análise Financeira** (Proprietário: Financeiro → Análise
Financeira) com `demo_financeiro`, `demo_proprietario` (as duas lojas) ou
`demo_gerente` (só a Loja Centro, em R$). O Comprador não tem o menu nem
acesso. A DRE do mês corrente compara as compras feitas até hoje com a
receita do mês inteiro (só fica representativa no fim do mês): o link do
Guia abre o último mês fechado até o dia 24 e o mês corrente do dia 25 em
diante; pelo menu, use « mês anterior ». É a **Cena 6** do
`ROTEIRO_DEMO_COMERCIAL_NEXBUY.md` e do Guia da apresentação.

O histórico entra pelo ORM (é passado já decidido): não gera notificação
nem auditoria, e o seed continua idempotente — rodar 2x dá as mesmas
contagens (compras, parcelas, auditoria). A cada execução os limites
individuais e bloqueios dos compradores de demonstração voltam ao estado
inicial antes do roteiro e são definidos de novo no fim.

## Novidades do CORE 1.0 na demonstração

O `seed_demo` agora também cria, prontos para mostrar:

- **Compras parceladas** — pedidos em 30/60, 30/60/90 e um personalizado em 4× de 15 dias, alimentando a **Agenda Financeira** (`/financeiro/agenda/`) com "Pagamentos de hoje" e "Próximos vencimentos" reais.
- **Calendário Operacional** (`/financeiro/calendario-operacional/`) — um **feriado**, um dia **bloqueado** (inventário) e um **sábado especial** de exemplo; quando não cabem com folga no mês corrente, são criados no mês seguinte (navegue com as setas na tela) — sem alterar o limite do mês atual.
- **2ª empresa "Drogaria Vida Plena Norte"** (CNPJ `98.765.432/0002-00`) — o `demo_proprietario` está autorizado nela: use o **seletor de empresa no topo** para trocar de contexto sem novo login, e o botão "Ver consolidado" no Dashboard para a visão multiempresa.
- **Fluxo de Aprovação de exemplo** na empresa **principal** (Gerente com alçada de R$ 2.000 → Financeiro) — visível em **NCC → Workflow** e demonstrável AO VIVO: uma provisão acima de R$ 2.000 lançada por qualquer comprador passa primeiro pela `demo_gerente` e, se ainda acima da alçada dela, segue para a `demo_financeiro`.
- **RBAC de exemplo** — o perfil de acesso reutilizável "Consulta Financeira" foi atribuído à `demo_gerente`: ela abre a **Agenda Financeira** (acesso que o perfil Gerente sozinho não dá), e o link aparece no menu dela. Veja em **NCC → Usuários e Permissões**.
- **Limite individual** — `demo_comprador2` tem limite de compra de **R$ 2.000,00**: lance uma compra acima disso ao vivo e ela vai automaticamente para aprovação do Gerente.
- **Notificações** — o sino no topo já acumula notificações reais geradas durante o próprio seed (solicitações de aprovação, mudanças de status, parcelamentos).
- **NCC — NEXBUY Control Center** (`/ncc/`, com o `demo_proprietario`) — Configurações Gerais preenchidas (horário 08h–18h, política de 12 parcelas), Estrutura, Usuários/Perfis, Motor, Workflow, Notificações (canais), Integrações (só o DDA, "Não conectado — integração prevista") e Auditoria com os logs da própria implantação da demo.

### Roteiro sugerido de apresentação

1. **Login como `demo_comprador`** — o tour guiado abre automaticamente na primeira vez (ou clique em "Iniciar Demonstração", no topo direito, a qualquer momento). Mostra em sequência: Dashboard, Calendário Inteligente, Central de Decisão, Compras, Aprovações, Empresa e Configurações.
2. **Dashboard do Comprador** — o card-herói já responde "posso comprar hoje? quanto?"; a Central de Decisão mostra mensagens reais geradas a partir dos dados do seed (incluindo "Fornecedor X possui pedido acima do histórico" e "Há compras previstas para amanhã").
3. **Calendário Inteligente** (`/gestao-compras/`) — o mês já vem com dias tranquilos, um dia de atenção e um dia crítico.
4. **Lançar uma compra parcelada ao vivo** (`/compras/nova/`) — escolha o prazo "30/60/90 dias (3x)" e mostre, em seguida, as 3 parcelas na Agenda Financeira do Financeiro. Com o `demo_comprador2`, lance uma compra acima de R$ 2.000 para mostrar o **limite individual** mandando para aprovação.
5. **Login como `demo_financeiro`** — o novo **Centro de Controle Financeiro** (Dashboard) mostra pagamentos de hoje, próximos vencimentos, dias críticos e alertas; abra a **Agenda Financeira** e dê baixa numa parcela.
6. **Login como `demo_gerente`** — a Central de Aprovação (`/gestao-compras/aprovacao/`) tem uma solicitação pendente com histórico completo; repare que a gerente também abre a **Agenda Financeira** (acesso concedido via RBAC — mostre em NCC → Usuários por que).
7. **Login como `demo_proprietario`** — Ranking de Fornecedores + KPIs; **troque de empresa no seletor do topo** (Drogaria Vida Plena Norte) e volte; clique em "Ver consolidado"; abra o **NCC** (`/ncc/`) e passeie por Workflow, Usuários e Permissões, Calendário Operacional (Motor) e Auditoria; mostre o **sino de notificações**.
8. **`/bem-vindo/`** — tela de apresentação institucional do produto, útil como abertura da reunião antes de entrar no sistema propriamente dito.

## Novidades da Sprint de Correções Críticas na demonstração

O `seed_demo` agora também demonstra o que a Sprint de Correções Críticas
corrigiu — isolamento multiempresa/multifilial de verdade e o fluxo
completo de Provisão até virar Compra:

- **2ª Filial "Loja Bairro" na MESMA empresa principal** — diferente da
  "Drogaria Vida Plena Norte" (uma empresa/tenant à parte, já existente),
  esta é uma segunda Filial dentro de "Farmácia Vida Plena". `demo_financeiro`
  (Marcos) e `demo_comprador2` (Pedro) ficam explicitamente vinculados às
  DUAS filiais (`UsuarioFilial`) — demo_comprador3 e os demais continuam de
  uma filial só, para mostrar os dois cenários lado a lado.
- **Seletor de filial em ação** — login como `demo_comprador2` e abra
  **Nova Compra** (`/compras/nova/`): o campo Filial mostra as duas opções
  (Loja Centro e Loja Bairro), com uma Compra de exemplo já lançada na Loja
  Bairro. Login como `demo_financeiro` e abra o **Dashboard Financeiro**: o
  card "Capacidade Financeira por filial" mostra as duas linhas lado a lado,
  e **Contas a Pagar** (`/financeiro/contas-a-pagar/`) ganha a coluna Filial
  automaticamente (só aparece quando o usuário tem mais de uma autorizada).
- **Provisão efetivada em Compra real** — a demonstração ganhou um 6º
  desfecho de Provisão: uma que é aprovada e depois **efetivada** de
  verdade. Abra a timeline dela (Central de Provisões, fornecedor "MedForte
  Distribuidora", categoria "Material de Escritório") para ver o badge
  **"Efetivada"**, o histórico completo (criação → solicitação → aprovação
  do Gerente → aprovação do Financeiro → efetivação) e a Compra vinculada
  com sua parcela real gerada — o fluxo Provisão→Compra que antes desta
  Sprint nunca era alcançado por nenhum caminho do sistema.
- **Contas a Pagar segmentado** (`/financeiro/contas-a-pagar/`, login
  `demo_financeiro` ou `demo_gerente`) — os compromissos aparecem em 3
  blocos separados (Obrigações Constituídas, Previsões, Provisões), cada um
  com seu próprio subtotal — nunca mais um único número somando tudo.

## Novidades da Release Candidate (1.0-rc1) na demonstração

O `seed_demo` também deixa prontas as correções da RC — e há uma usuária nova:

- **`demo_comprador3` — Carla Menezes (Compradora, BLOQUEADA)** — a
  compradora chega bloqueada pelo Financeiro: o Dashboard dela abre com o
  herói **"Bloqueado"** e qualquer compra que ela tentar lançar sai **barrada
  na origem** (status Bloqueada, com o motivo no histórico). Use para
  demonstrar o Motor de Capacidade "do lado de quem sofre a regra".
- **Motor de Capacidade** (`/financeiro/capacidade-compradores/`, login
  `demo_financeiro`) — a tela mostra os 3 estados lado a lado: **Juliana**
  com limite individual de **R$ 3.500,00** (definido pelo próprio Financeiro
  via service — a ação ficou auditada no NCC e notificada no sino dela),
  **Pedro** com limite de **R$ 2.000,00** e **Carla bloqueada**. Ao vivo:
  altere um limite (formato brasileiro, ex. `2.500,00`), bloqueie/libere um
  comprador e mostre a notificação chegando para ele.
- **Calendário Inteligente do Financeiro** (`/financeiro/calendario/`) —
  visões **mensal, semanal e diária**; clique em um dia com compromissos
  para o detalhe completo (compras, parcelamentos, contas fixas — folha,
  aluguel, impostos —, variáveis, provisões, total comprometido, saldo,
  capacidade, status e observações); filtre por origem, pesquise por
  "folha" e use o atalho **"Simular compra"** com a data já preenchida.
- **Dashboard do Comprador reprojetado** (login `demo_comprador`) — a tela
  agora responde só "Posso comprar hoje?": capacidade disponível, **"Meu
  dotação do dia"** (R$ 3.500,00 — limite individual por DIA e por loja:
  soma das compras do dia naquela loja, não teto por compra), status do dia, Central de Decisão,
  calendário e SOMENTE as próprias compras/provisões/solicitações. Repare no
  que **não** aparece mais: folha, aluguel, contas, meta mensal — a
  restrição é do backend (ViewModel), não um esconde-mostra de tela.
- **"Minhas Compras"** — o menu do comprador mudou de rótulo e de escopo: a
  lista traz apenas as compras DELE (compare com o mesmo menu no
  `demo_gerente`, que segue vendo a filial inteira).
- **Timeline Financeira restrita** — o item de menu "Timeline Financeira"
  não aparece mais para compradores (permissão `timeline.ver`, dos perfis
  gestores); mostre pelo `demo_gerente` ou `demo_financeiro`.
- **Dashboard do Financeiro ampliado** — seções novas **"Compradores hoje"**
  (com o status de bloqueio ao vivo) e **"Parcelamentos em aberto"**, além
  dos atalhos para Calendário Financeiro e Capacidade dos Compradores.

## Novidades do Épico 2A.5 (Design Premium) na demonstração

Sem mudança de dados — o sistema inteiro ganhou o visual SaaS premium:
login e sidebar em **navy profundo** com marca em gradiente, **KPIs sólidos
coloridos** (roxo = aprovações, teal = capacidade) nos 4 dashboards, hero com
**saudação personalizada + 👋**, card **"Capacidade do dia"** na lateral
(perfis com filial), vencimentos com **chips de data**, estados vazios
ilustrados ("Nada vence hoje. Ótimo!") e microinterações suaves. Basta
recarregar a página — tudo é CSS/template.

## Novidades do Épico 2A (UX Overhaul) na demonstração

O 2A não mudou dados — mudou a EXPERIÊNCIA. Com a mesma base demo:

- **Menus por perfil**: entre com cada usuário e repare que o menu lateral é
  outro — Comprador (Dashboard · Nova Compra · Calendário · Histórico ·
  Simulador · Perfil), Financeiro (9 itens do dia a dia), Gerente (Dashboard ·
  Aprovações · Indicadores · Relatórios · Perfil), Proprietário (Dashboard
  Executivo · Empresas · Usuários · Centro de Configurações · Auditoria ·
  Relatórios · Perfil).
- **Topbar nova (todos)**: campo de **Pesquisa Global** (digite "farma" ou
  "capacidade"), menu **? Ajuda** (Bem-vindo/Tour — o botão "Iniciar
  Demonstração" mudou para cá) e o **menu da conta** no avatar (Meu Perfil /
  Sair).
- **Meu Perfil** (`/perfil/`, qualquer usuário): foto, dados e troca de senha.
- **`demo_gerente` → Aprovações**: as DUAS filas (compras acima do limite +
  provisões) numa tela só; aprove uma compra com 1 clique ali mesmo.
- **`demo_gerente` → Indicadores**: operação por filial + fornecedores do mês.
- **`demo_financeiro` → Planejamento Financeiro**: o hub com TODAS as áreas do
  módulo (11 cards); repare no alerta de parcelas vencidas no topo, quando
  houver. **Parcelamentos** no menu lista as parcelas em aberto com filtro
  "Só vencidas".
- **`demo_financeiro` → Dashboard**: barra de Ações Rápidas (Nova Conta /
  Liberar limite / Bloquear Dia / Simular) + badge "aguardando limite" no card
  Compradores.
- **`demo_proprietario` → Dashboard Executivo**: Receita do mês, Alertas
  Estratégicos consolidados e Ações Rápidas (Novo Usuário / Empresas /
  Auditoria / Relatórios).
- **`demo_proprietario` → Usuários → Novo Usuário**: crie um usuário SEM sair
  do produto (dados, perfil, senha inicial, foto) e caia direto no **painel
  visual de permissões** — grupos por área, descrição do que cada permissão
  faz, busca ("aprovar") e filtro por grupo.
- **Centro de Configurações** (`/ncc/`): o hub único, agora por categorias
  (Organização / Motor Financeiro / Plataforma / Governança). A antiga
  `/configuracoes/` redireciona sozinha.

### Roteiro sugerido da RC (5 minutos)

1. `demo_financeiro` → **Capacidade dos Compradores**: mostre os 3 estados,
   reduza o limite da Juliana para `1.000,00` e salve.
2. `demo_comprador` (Juliana) → Dashboard: "Minha dotação do dia" já
   mostra R$ 1.000,00 e o sino tem a notificação; lance uma compra de
   R$ 1.500 → vai para aprovação por exceder o limite individual do dia
   (a conta soma o que ela já comprou hoje com a compra nova).
3. `demo_comprador3` (Carla) → Dashboard "Bloqueado"; tente lançar uma
   compra → barrada na origem.
4. `demo_financeiro` → **Calendário Financeiro**: navegue mensal → clique
   num dia com parcelas → visão diária; filtre "Contas Fixas" e pesquise
   "folha".
5. Volte ao Dashboard do Financeiro e mostre "Compradores hoje" refletindo
   tudo o que acabou de fazer. (Para restaurar o estado, rode o
   `iniciar_demo_cenario_pronto.bat` de novo — ou, manualmente,
   `python manage.py seed_demo --settings=nexbuy.settings_demo`.)

### Coisas para evitar durante uma demonstração ao vivo

- **Não edite nem apague os usuários de demonstração** durante a apresentação — se precisar "resetar" o estado, rode o `iniciar_demo_cenario_pronto.bat` de novo entre uma demonstração e outra (ele reexecuta o `seed_demo`, sempre no banco isolado).
- **Não rode `manage.py` sem `--settings=nexbuy.settings_demo` durante uma demo** — sem a flag, o comando opera no banco/mídia principal (`db.sqlite3`/`media\`), exatamente o que o pacote de demonstração existe para evitar. Os launchers já passam a flag em toda chamada; a regra vale para qualquer comando manual (`shell`, `seed_demo`, `runserver`...).

## Limitações conhecidas

- **Não existe integração com ERP** (decisão da cliente): receitas, custos e compras são lançados manualmente. A única integração prevista é o DDA, ainda não conectada (só o contrato abstrato existe em `finance_engine/interfaces.py`).
- **Não existe cadastro de produtos nem controle de estoque real no NEXBUY** (decisão mantida desde o MVP inicial — `ItemProvisao.produto` é texto livre, sem model próprio). As seções do brief desta Sprint que pediam "estoque alto/crítico/sem estoque" refletido no Dashboard **não foram implementadas como indicador real**, por decisão explícita: criar um model de Produto/Estoque seria uma mudança de arquitetura (nova tabela, nova migration), que esta Sprint proibiu alterar. Os nomes de produtos aparecem apenas como texto realista nos itens de Provisão do `seed_demo`, para dar contexto visual sem simular uma funcionalidade que não existe de verdade — evita que um cliente peça para "ver o alerta de estoque crítico" e a resposta seja "na verdade isso não existe ainda".
- **"Pedidos" (item 9 do brief) foram implementados como `Compra`** — o NEXBUY não tem uma entidade separada chamada "Pedido"; o conceito mais próximo já existente é a Compra efetivada, usada para representar essa parte da demonstração.
- O Ranking de Fornecedores (novo nesta Sprint) é uma agregação somente-leitura sobre `Compra` — não é um novo cadastro nem uma nova regra de negócio, só uma forma nova de exibir dado que já existia.

## Testes

`python manage.py test --settings=nexbuy.settings_demo --verbosity=2` roda a suíte completa deste pacote — **738 testes**, todos passando, sem falhas, erros ou skips (resultado real registrado em `test_run_APRESENTACAO.txt`, na raiz do pacote). O Modo Demonstração não interfere no funcionamento normal do sistema (`makemigrations --check --dry-run` limpo).
