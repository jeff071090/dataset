"""Views dos dashboards por perfil.

Nenhum cálculo acontece aqui — toda a lógica de agregação vive em
`dashboard/services.py`, que por sua vez delega os cálculos financeiros ao
Motor Financeiro (`finance_engine`). As views apenas coletam o contexto e
escolhem o template certo para o perfil do usuário logado.
"""
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from compras.services import ranking_fornecedores_do_mes
from core.contexto import empresa_ativa, filiais_do_contexto
from core.permissions import permissao_required
from django.utils import timezone
from finance_engine.timeline import historico_financeiro
from notificacoes.services import gerar_notificacoes_de_vencimento
from usuarios.models import Usuario

from .services import (
    alertas_estrategicos,
    obter_kpis_administrativos,
    obter_painel_financeiro,
    obter_resultado_do_mes,
    obter_resumo_filiais,
    resolver_filial_para_relatorios,
)
from .viewmodels import viewmodel_comprador, viewmodel_gerente


@login_required
def dashboard_home(request):
    user = request.user
    hoje = date.today()

    if user.perfil == Usuario.Perfil.PROPRIETARIO:
        return _dashboard_proprietario(request, hoje)
    if user.perfil == Usuario.Perfil.GERENTE:
        return _dashboard_gerente(request, hoje)
    if user.perfil == Usuario.Perfil.FINANCEIRO:
        return _dashboard_financeiro(request, hoje)
    return _dashboard_comprador(request, hoje)


def _dashboard_comprador(request, hoje):
    """RC do Épico 01 (Correções 01 e 05): o contexto vem inteiro do
    viewmodel do perfil — a view não monta mais payload nem repassa o
    painel completo; o Comprador recebe apenas o que pode ver."""
    filial = request.user.filial
    contexto = {"hoje": hoje, "sem_filial": filial is None}
    if filial is None:
        return render(request, "dashboard/comprador.html", contexto)

    contexto.update(viewmodel_comprador(request.user, hoje, timezone.localtime().hour))
    return render(request, "dashboard/comprador.html", contexto)


def _dashboard_gerente(request, hoje):
    """RC do Épico 01 (Correção 01): indicadores consolidados via
    viewmodel — sem faturamento/custos/disponibilidade no payload do
    viewmodel (contrato `CHAVES_PROIBIDAS_GERENTE`)."""
    filial = request.user.filial
    contexto = {"hoje": hoje, "sem_filial": filial is None}
    if filial is None:
        return render(request, "dashboard/gerente.html", contexto)

    contexto.update(viewmodel_gerente(request.user, hoje))
    # Análise Financeira (mudança de escopo): widget "Resultado do mês" —
    # num contexto SEPARADO do viewmodel (que segue o contrato de chaves do
    # Gerente). Decisão explícita do usuário (Correções de Produção): "a
    # parte analítica fica para o Financeiro, o Gerente e o Proprietário" —
    # o widget do Gerente mostra receita total, despesas e resultado em R$,
    # igual ao do Proprietário/Financeiro (mesma fonte da DRE, que o Gerente
    # já abre). O Comprador segue sem nada disso (nem chama esta função).
    contexto["resultado_mes"] = obter_resultado_do_mes(
        request.user, filiais_do_contexto(request), hoje, detalhar_valores=True
    )
    return render(request, "dashboard/gerente.html", contexto)


def _dashboard_financeiro(request, hoje):
    """Centro de Controle Financeiro (Épico 5 — CORE 1.0). Toda a
    agregação vive em `dashboard.services.obter_painel_financeiro`; a view
    só resolve o contexto (empresa ativa) e dispara as notificações
    derivadas de vencimento do dia (Épico 11)."""
    filiais = list(filiais_do_contexto(request))
    contexto = {"hoje": hoje, "sem_filial": not filiais}
    if not filiais:
        return render(request, "dashboard/financeiro.html", contexto)

    # Mesmo recorte da Agenda e dos "Pagamentos de hoje" do painel: todas as
    # filiais do contexto (antes só a 1ª — um vencimento da outra filial
    # nunca virava notificação).
    for filial in filiais:
        gerar_notificacoes_de_vencimento(request.user, filial, hoje)
    contexto.update(obter_painel_financeiro(request.user, filiais, hoje, timezone.localtime().hour))
    # Análise Financeira: widget "Resultado do mês" (mesma fonte da DRE).
    contexto["resultado_mes"] = obter_resultado_do_mes(request.user, filiais, hoje)
    return render(request, "dashboard/financeiro.html", contexto)


def _dashboard_proprietario(request, hoje):
    """Dashboard do Proprietário — empresa ativa do contexto (Épico 9);
    com `?consolidado=1`, um gestor com mais de uma empresa autorizada vê
    o resumo de todas elas lado a lado (visão consolidada)."""
    user = request.user
    empresa = empresa_ativa(request)
    empresas_disponiveis = list(user.empresas_disponiveis())
    consolidado = request.GET.get("consolidado") == "1" and len(empresas_disponiveis) > 1
    empresas = empresas_disponiveis if consolidado else ([empresa] if empresa else [])

    resumo_empresas = []
    kpis_administrativos = None
    ranking_fornecedores = []
    for empresa_atual in empresas:
        if kpis_administrativos is None:
            kpis_administrativos = obter_kpis_administrativos(empresa_atual, hoje)
            ranking_fornecedores = ranking_fornecedores_do_mes(empresa_atual, hoje.year, hoje.month)
        resumo_empresas.append({"empresa": empresa_atual, "filiais": obter_resumo_filiais(empresa_atual, hoje)})

    # Microsprint de Navegação V4 (Seção 8.2): a ação primária do Dashboard
    # é contextual — decidida SÓ com dados que o dashboard já calcula
    # (aprovações pendentes dos KPIs) mais o resumo do Checklist de
    # Implantação já existente (empresas.services_checklist) — nenhuma
    # regra de negócio nova, nenhuma pendência inventada.
    implantacao_incompleta = False
    if empresa is not None:
        from empresas.services_checklist import calcular_checklist, resumo_checklist

        resumo = resumo_checklist(calcular_checklist(empresa))
        implantacao_incompleta = resumo["concluidos"] < resumo["total"]

    aprovacoes_pendentes_total = 0
    if kpis_administrativos:
        aprovacoes_pendentes_total = (
            (kpis_administrativos.get("compras_pendentes") or 0)
            + (kpis_administrativos.get("provisoes_aguardando_aprovacao") or 0)
        )

    contexto = {
        "hoje": hoje,
        "resumo_empresas": resumo_empresas,
        "sem_empresa": empresa is None,
        "kpis": kpis_administrativos,
        "ranking_fornecedores": ranking_fornecedores,
        "consolidado": consolidado,
        "pode_consolidar": len(empresas_disponiveis) > 1,
        # Épico 2A (Etapa 06): Alertas Estratégicos da empresa ativa.
        "alertas_estrategicos": alertas_estrategicos(empresa, hoje) if empresa else [],
        "implantacao_incompleta": implantacao_incompleta,
        "aprovacoes_pendentes_total": aprovacoes_pendentes_total,
        # Análise Financeira: widget "Resultado do mês" da empresa ativa
        # (todas as filiais do contexto — o mesmo recorte dos KPIs acima).
        "resultado_mes": (
            obter_resultado_do_mes(user, filiais_do_contexto(request), hoje) if empresa is not None else None
        ),
    }
    return render(request, "dashboard/proprietario.html", contexto)


@login_required
def central_aprovacoes(request):
    """Central de Aprovações unificada (Épico 2A — Etapa 01, Gerente).

    A pergunta do perfil é "o que precisa da minha decisão?" — antes a
    resposta estava dividida em duas telas (compras × provisões). Esta view
    é AGREGAÇÃO puras das filas existentes: as ações continuam nas rotas
    das telas originais (nenhuma regra nova)."""
    from django.core.exceptions import PermissionDenied

    from compras.services import obter_compras_pendentes
    from gestao_compras.models import SolicitacaoAprovacao

    user = request.user
    if user.perfil not in (Usuario.Perfil.GERENTE, Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO):
        raise PermissionDenied("Você não tem permissão para acessar esta página.")

    # Sprint de Correções Críticas (Seção 16): filiais da empresa ATIVA,
    # não da principal — um Proprietário que trocou de empresa continuava
    # vendo a fila de aprovação da empresa errada aqui.
    filiais = list(filiais_do_contexto(request))
    compras_pendentes = []
    if user.perfil == Usuario.Perfil.GERENTE:
        for filial in filiais:
            compras_pendentes.extend(obter_compras_pendentes(filial))

    from gestao_compras.services import marcar_decidiveis

    # Crítico funcional (rodada 1): cada solicitação sabe se ESTE usuário
    # decide a etapa atual; só essas entram no "N decisões aguardando" e
    # ganham o botão "Decidir" — as demais mostram de quem é a vez.
    solicitacoes = marcar_decidiveis(
        SolicitacaoAprovacao.objects.filter(
            status=SolicitacaoAprovacao.Status.PENDENTE, provisao__filial__in=filiais
        )
        .select_related(
            "provisao", "provisao__fornecedor", "provisao__comprador", "etapa_atual", "etapa_atual__aprovador"
        )
        .order_by("criado_em"),
        user,
    )
    solicitacoes_decidiveis = sum(1 for s in solicitacoes if s.pode_decidir)

    from gestao_compras.services import provisoes_aguardando_efetivacao

    contexto = {
        # Rodada final: provisões aprovadas (ou dentro do saldo) que ainda
        # precisam ser efetivadas — só para quem tem provisoes.efetivar.
        "aguardando_efetivacao": provisoes_aguardando_efetivacao(user, filiais),
        "hoje": date.today(),
        "compras_pendentes": compras_pendentes,
        "solicitacoes": solicitacoes,
        "solicitacoes_decidiveis": solicitacoes_decidiveis,
        "total_pendente": len(compras_pendentes) + solicitacoes_decidiveis,
        "mostra_compras": user.perfil == Usuario.Perfil.GERENTE,
    }
    return render(request, "dashboard/aprovacoes.html", contexto)


@login_required
def indicadores(request):
    """Indicadores Consolidados (Épico 2A — Etapa 01): números finais do
    mês para Gerente/Financeiro/Proprietário — apenas indicadores já
    autorizados a esses perfis (nenhum insumo bruto de planejamento para o
    Gerente, mesma regra da RC)."""
    from django.core.exceptions import PermissionDenied

    from compras.services import ranking_fornecedores_do_mes as ranking
    from finance_engine.calendario_operacional import rotulo_do_tipo
    from financeiro.services import capacidade_configurada
    from gestao_compras.services import obter_calendario_mensal

    user = request.user
    if user.perfil not in (Usuario.Perfil.GERENTE, Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO):
        raise PermissionDenied("Você não tem permissão para acessar esta página.")

    hoje = date.today()
    empresa = empresa_ativa(request)
    filiais = list(filiais_do_contexto(request))

    zero = Decimal("0")
    por_filial = []
    for filial in filiais:
        dias = obter_calendario_mensal(filial, hoje.year, hoje.month)
        posicao_hoje = next((d for d in dias if d["data"] == hoje), None)
        saldo_hoje = posicao_hoje["saldo_disponivel"] if posicao_hoje else zero
        por_filial.append(
            {
                "filial": filial,
                "comprado_mes": sum((d["comprado"] for d in dias), zero),
                "comprado_hoje": posicao_hoje["comprado"] if posicao_hoje else zero,
                "saldo_hoje": saldo_hoje,
                # Negativo vira "excedido em R$ X" (padrão do Comprador).
                "excedido_hoje": -saldo_hoje if saldo_hoje < zero else zero,
                "cor_hoje": posicao_hoje["cor"] if posicao_hoje else "verde",
                # Críticos (rodada 2): sem receita no mês o limite é zero e a
                # cor "verde" de `classificar_consumo(0, 0)` virava "Liberada"
                # — o painel executivo dizia "Sem configuração" para a mesma
                # filial. Mesmo estado neutro aqui.
                "configurada": capacidade_configurada(filial, hoje.year, hoje.month),
                "sem_limite_hoje": bool(posicao_hoje and posicao_hoje["sem_limite_proprio"]),
                "tipo_dia_hoje": rotulo_do_tipo(posicao_hoje["tipo_dia"]) if posicao_hoje else "",
                "dias_criticos": sum(1 for d in dias if d["cor"] == "vermelho"),
            }
        )

    contexto = {
        "hoje": hoje,
        "empresa": empresa,
        "por_filial": por_filial,
        "ranking_fornecedores": ranking(empresa, hoje.year, hoje.month) if empresa else [],
    }
    return render(request, "dashboard/indicadores.html", contexto)


@permissao_required("timeline.ver")
def timeline_financeira(request):
    """Histórico cronológico do Motor Financeiro (Sprint 3, item 6) —
    compra, saldo, transferência, redistribuição e novo saldo de cada dia.

    RC do Épico 01 (Correção 01): a timeline expõe o day-walk completo do
    Motor (limites, redistribuições) — restrita por permissão do catálogo
    aos perfis gestores; um Comprador só a acessa se receber `timeline.ver`
    explicitamente pelo RBAC."""
    hoje = date.today()
    filial = resolver_filial_para_relatorios(request.user)

    contexto = {"hoje": hoje, "filial": filial, "sem_filial": filial is None}
    if filial is None:
        return render(request, "dashboard/timeline.html", contexto)

    # Defesa contra querystring malformada (mesmo padrão de
    # `gestao_compras.views.calendario`) — sem isso, qualquer "ano"/"mes" que
    # não seja um inteiro puro (ex.: o próprio número já formatado com
    # separador de milhar do locale pt-br, "2.026", como os links "Mês
    # anterior"/"Próximo mês" geravam) derruba a tela com HTTP 500 em vez de
    # simplesmente cair no mês atual.
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
    except (TypeError, ValueError):
        ano, mes = hoje.year, hoje.month
    ate_dia = hoje.day if (ano, mes) == (hoje.year, hoje.month) else None

    eventos = historico_financeiro.gerar_timeline(filial, ano, mes, ate_dia=ate_dia)

    mes_anterior = date(ano, mes, 1) - timedelta(days=1)
    proximo_mes = date(ano, mes, 28) + timedelta(days=7)

    contexto.update(
        {
            "ano": ano,
            "mes": mes,
            "data_referencia": date(ano, mes, 1),
            "eventos": eventos,
            "mes_anterior": mes_anterior,
            "proximo_mes": proximo_mes.replace(day=1),
        }
    )
    return render(request, "dashboard/timeline.html", contexto)
