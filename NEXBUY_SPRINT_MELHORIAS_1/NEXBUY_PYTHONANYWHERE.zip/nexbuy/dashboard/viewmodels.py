"""ViewModels por perfil (RC do Épico 01 — Correção 01).

A camada REAL de apresentação baseada em perfil: cada função monta, por
whitelist explícita, exatamente o que aquele perfil está autorizado a
receber — o backend entrega apenas dados autorizados e o frontend nunca
recebe o que o usuário não pode ver (nada de esconder via template/CSS).

Contratos:

- `CHAVES_PROIBIDAS_COMPRADOR` — chaves que NUNCA podem existir no payload
  do Comprador (folha/aluguel/contas/fornecedores financeiros/faturamento/
  planejamento). O teste de segurança da RC valida este contrato.
- `CHAVES_PROIBIDAS_GERENTE` — o Gerente recebe indicadores consolidados
  (limite, capacidade mensal, comprado), nunca os componentes brutos do
  planejamento financeiro (faturamento, custos, disponibilidade).

Os services de domínio continuam completos (nenhum foi mutilado — outros
consumidores autorizados seguem usando tudo); o que muda é que as VIEWS
dos perfis restritos passam a consumir estes viewmodels, não os services
brutos.
"""
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional

from compras.services import (
    obter_autorizacao_comprador,
    obter_compras_do_usuario,
    obter_compras_pendentes,
    reservado_no_dia_pelo_usuario,
    total_comprado_no_dia_pelo_usuario,
)
from core.utils import formatar_moeda
from financeiro.services import capacidade_configurada, contar_compromissos_em
from gestao_compras.models import Provisao, SolicitacaoAprovacao
from gestao_compras.services import (
    contar_solicitacoes_pendentes,
    obter_calendario_mensal,
    obter_fornecedor_provisao_acima_do_historico,
    contar_provisoes_previstas_para,
)

from .insights import ContextoDecisao, central_de_decisao, gerar_cabecalho
from .services import obter_resumo_comprador

ZERO = Decimal("0")
DIAS_TENDENCIA = 5
DIAS_PREVIEW_CALENDARIO = 7

# Contrato de segurança do Comprador: nenhuma destas chaves pode aparecer
# no payload dele (nem, por consequência, no template renderizado).
CHAVES_PROIBIDAS_COMPRADOR = frozenset(
    {
        "meta_mensal",
        "proximos_compromissos",
        "pagamentos_hoje",
        "proximos_vencimentos",
        "faturamento",
        # Receita decomposta (receita mensal + receitas extras) — mesmos
        # insumos brutos que `faturamento`, nunca chegam ao Comprador.
        "receita_mensal",
        "receitas_extras",
        "receita_total",
        "faturamento_mes",
        "custos_fixos",
        "custos_variaveis",
        "disponibilidade",
        "capacidade",
        "capacidade_mensal",
        "capacidade_mensal_ajustada",
        "resumo_filiais",
        "kpis",
    }
)

# O Gerente vê indicadores consolidados — nunca os insumos brutos do
# planejamento financeiro.
CHAVES_PROIBIDAS_GERENTE = frozenset(
    {"faturamento", "receita_mensal", "receitas_extras", "receita_total", "faturamento_mes",
     "custos_fixos", "custos_variaveis", "disponibilidade", "capacidade",
     "proximos_compromissos", "pagamentos_hoje", "meta_mensal"}
)


def capacidade_do_comprador_hoje(usuario, filial, hoje: date, resumo: Optional[dict] = None) -> dict:
    """Resposta ÚNICA de "quanto ainda posso comprar hoje?" do Comprador —
    fonte do cabeçalho, do card-herói, do KPI "% utilizado do dia" e do
    card "Capacidade do dia" da barra lateral (antes cada um usava uma base
    diferente: o cabeçalho, o saldo da FILIAL; o card, a DOTAÇÃO; a %, uma
    terceira conta; e a barra travava em 100%).

    Regra (a mesma que `compras.services.avaliar_e_criar_compra` aplica na
    próxima compra): o disponível é o MENOR entre o que ainda cabe na
    filial hoje e o que sobra da dotação diária do comprador. A % usa a
    MESMA base que limitou o disponível — a dotação (gasto pessoal ÷
    dotação) ou o limite do dia da filial (comprado na filial ÷ limite) —,
    então sempre vale: disponível = base − utilizado. Negativo nunca é
    "capacidade": vira `capacidade_excedida_em` (quanto passou da base)."""
    from finance_engine.calculations import calcular_percentual_utilizado, classificar_por_percentual

    resumo = resumo if resumo is not None else obter_resumo_comprador(filial, hoje)
    autorizacao = obter_autorizacao_comprador(usuario, filial.empresa if filial else None)
    limite_pessoal = autorizacao.limite_compra if autorizacao else None
    bloqueado = bool(autorizacao and autorizacao.bloqueado)

    # Mesma conta que `avaliar_e_criar_compra` usa para decidir se uma
    # compra nova vai para aprovação (`total_comprado_no_dia_pelo_usuario`).
    gasto_hoje_pessoal = total_comprado_no_dia_pelo_usuario(usuario, filial, hoje) if filial else ZERO
    # Visual QA & Demo Polish: "quanto está reservado?" (pendente de decisão).
    reservado_hoje_pessoal = reservado_no_dia_pelo_usuario(usuario, filial, hoje) if filial else ZERO
    dotacao_pessoal_restante = (limite_pessoal - gasto_hoje_pessoal) if limite_pessoal is not None else None
    capacidade_filial_restante = resumo["saldo_restante"]

    if dotacao_pessoal_restante is not None and dotacao_pessoal_restante <= capacidade_filial_restante:
        disponivel, limitada_por = dotacao_pessoal_restante, "dotacao_pessoal"
        base, utilizado = limite_pessoal, gasto_hoje_pessoal
    else:
        disponivel, limitada_por = capacidade_filial_restante, "filial"
        base, utilizado = resumo["limite_diario"], resumo["comprado_hoje"]
    if bloqueado:
        disponivel, limitada_por = ZERO, "bloqueio"

    percentual = calcular_percentual_utilizado(utilizado, base)
    return {
        "limite_pessoal": limite_pessoal,
        "bloqueado": bloqueado,
        "gasto_hoje_pessoal": gasto_hoje_pessoal,
        "reservado_hoje_pessoal": reservado_hoje_pessoal,
        "utilizado_hoje_pessoal": gasto_hoje_pessoal - reservado_hoje_pessoal,
        "dotacao_pessoal_restante": dotacao_pessoal_restante,
        "capacidade_disponivel": disponivel,
        "capacidade_limitada_por": limitada_por,
        "capacidade_excedida_em": -disponivel if disponivel < ZERO else ZERO,
        "base_do_percentual": base,
        "utilizado_na_base": utilizado,
        "percentual_utilizado": percentual,
        "cor_do_dia": classificar_por_percentual(percentual),
        "pode_comprar_hoje": disponivel > ZERO and not bloqueado,
    }


def viewmodel_comprador(usuario, hoje: Optional[date] = None, hora: int = 12) -> dict:
    """Payload do Dashboard do Comprador (RC-C01/C05). Responde apenas
    "posso comprar hoje?": capacidade disponível, limite pessoal, status do
    dia, calendário operacional, PRÓPRIAS compras e solicitações.

    Por construção, nunca consulta contas/planejamento: o único dado
    derivado de contas é `contar_compromissos_em` — um inteiro agregado
    usado pela Central de Decisão, sem descrição nem valor."""
    filial = usuario.filial
    hoje = hoje or date.today()
    amanha = hoje + timedelta(days=1)

    resumo = obter_resumo_comprador(filial, hoje)
    # Etapa 02 (Cliente-Ready): sinal aditivo puramente informativo — não é
    # um dado financeiro bruto (não expõe faturamento/custos), só "já existe
    # receita (mensal ou extra) cadastrada este mês?"; por isso não entra em
    # CHAVES_PROIBIDAS_COMPRADOR.
    configurada = capacidade_configurada(filial, hoje.year, hoje.month)
    dias_mes = obter_calendario_mensal(filial, hoje.year, hoje.month)
    dias_por_data = {dia["data"]: dia for dia in dias_mes}
    hoje_info = dias_por_data.get(hoje)
    amanha_info = dias_por_data.get(amanha)

    minhas_compras = obter_compras_do_usuario(usuario, filial, limite=8)
    minhas_compras_pendentes = [c for c in minhas_compras if c.status == c.Status.PENDENTE]
    minhas_provisoes = (
        Provisao.objects.filter(filial=filial, comprador=usuario)
        .select_related("fornecedor", "categoria")
        .order_by("-criado_em")[:5]
    )
    minhas_solicitacoes = (
        SolicitacaoAprovacao.objects.filter(
            provisao__comprador=usuario, status=SolicitacaoAprovacao.Status.PENDENTE
        )
        .select_related("provisao", "provisao__fornecedor")
        .order_by("-criado_em")[:5]
    )

    # Sprint de Consolidação (Gate 2A, Parte 4) + crítico funcional (rodada
    # 1): "quanto posso comprar hoje" tem UMA resposta só — o menor entre o
    # que cabe na filial e o que sobra da dotação — e o cabeçalho, o card,
    # a % do dia e a barra lateral leem todos daqui (antes o cabeçalho usava
    # o saldo da filial e o card a dotação: R$ 1.284,54 x R$ 1.200,00 na
    # mesma tela).
    capacidade = capacidade_do_comprador_hoje(usuario, filial, hoje, resumo)
    bloqueado = capacidade["bloqueado"]
    # Crítico funcional (rodada 1): sábado/domingo (regra padrão), feriado
    # ou bloqueio sem saldo herdado e sem compra = dia sem compra prevista.
    from finance_engine.calendario_operacional import rotulo_do_tipo

    hoje_sem_limite_proprio = bool(
        configurada and resumo["hoje_sem_limite_proprio"] and resumo["comprado_hoje"] <= ZERO and not bloqueado
    )
    # Críticos (rodada 2): o dia não conta capacidade (fim de semana,
    # feriado, bloqueio) mesmo que já exista compra lançada nele — a
    # dotação individual não vale hoje (toda compra vai para aprovação), e
    # o card "Minha dotação do dia" precisa dizer isso em vez de "acima
    # disso vai para aprovação" ao lado de "Hoje não é dia de compra".
    dotacao_nao_vale_hoje = bool(configurada and resumo["hoje_sem_limite_proprio"] and not bloqueado)
    rotulo_dia_hoje = rotulo_do_tipo(resumo["tipo_dia_hoje"])

    contexto_decisao = ContextoDecisao(
        hoje=hoje,
        pode_comprar_hoje=capacidade["pode_comprar_hoje"],
        cor_hoje=capacidade["cor_do_dia"],
        percentual_utilizado_hoje=capacidade["percentual_utilizado"],
        saldo_disponivel_hoje=capacidade["capacidade_disponivel"],
        provisoes_aguardando_aprovacao=contar_solicitacoes_pendentes(usuario.filiais_visiveis()),
        compras_aguardando_aprovacao=len(minhas_compras_pendentes),
        cor_amanha=amanha_info["cor"] if amanha_info else None,
        compromissos_amanha=contar_compromissos_em(filial, amanha),
        fornecedor_acima_historico=obter_fornecedor_provisao_acima_do_historico(filial),
        provisoes_previstas_amanha=contar_provisoes_previstas_para(filial, amanha),
        capacidade_configurada=configurada,
        bloqueado=bloqueado,
        hoje_sem_limite_proprio=hoje_sem_limite_proprio,
        rotulo_dia_hoje=rotulo_dia_hoje,
    )

    tendencia = [
        {
            "data": dia["data"],
            "cor": dia["cor"],
            "saldo_disponivel": dia["saldo_disponivel"],
            "excedido_em": dia.get("excedido_em", ZERO),
            "sem_limite_proprio": dia.get("sem_limite_proprio", False),
            # Críticos (rodada 2): sem receita no mês o limite é zero e
            # `classificar_consumo(0, 0)` devolve "verde" — o preview pintava
            # "Compra liberada" enquanto o calendário completo mostrava tudo
            # neutro ("Sem configuração"). O estado é o mesmo do calendário.
            "sem_configuracao": not configurada,
            "altura_pct": _altura_pct(dia["saldo_disponivel"], dia["limite_efetivo"]) if configurada else ZERO,
        }
        for dia in dias_mes
        if dia["data"] > hoje
    ][:DIAS_TENDENCIA]

    calendario_preview = [
        {
            "dia": dia["dia"],
            "data": dia["data"],
            "hoje": dia["hoje"],
            "cor": dia["cor"],
            "saldo_disponivel": dia["saldo_disponivel"],
            "excedido_em": dia.get("excedido_em", ZERO),
            "quantidade_provisoes": dia["quantidade_provisoes"],
            "tipo_dia": dia.get("tipo_dia", "util"),
            "sem_limite_proprio": dia.get("sem_limite_proprio", False),
            "sem_configuracao": not configurada,
        }
        for dia in dias_mes
        if dia["data"] >= hoje
    ][:DIAS_PREVIEW_CALENDARIO]

    return {
        "perfil_viewmodel": "comprador",
        "cabecalho": gerar_cabecalho(usuario, contexto_decisao, hora),
        "pode_comprar_hoje": contexto_decisao.pode_comprar_hoje,
        "capacidade_configurada": configurada,
        "capacidade_disponivel": capacidade["capacidade_disponivel"],
        "capacidade_excedida_em": capacidade["capacidade_excedida_em"],
        "limite_diario": resumo["limite_diario"],
        "status_do_dia": capacidade["cor_do_dia"],
        "percentual_utilizado": capacidade["percentual_utilizado"],
        "base_do_percentual": capacidade["base_do_percentual"],
        "saldo_acumulado": resumo["saldo_acumulado"],
        "limite_pessoal": capacidade["limite_pessoal"],
        "gasto_hoje_pessoal": capacidade["gasto_hoje_pessoal"],
        "utilizado_hoje_pessoal": capacidade["utilizado_hoje_pessoal"],
        "reservado_hoje_pessoal": capacidade["reservado_hoje_pessoal"],
        "dotacao_pessoal_restante": capacidade["dotacao_pessoal_restante"],
        "capacidade_limitada_por": capacidade["capacidade_limitada_por"],
        "hoje_sem_limite_proprio": hoje_sem_limite_proprio,
        "dotacao_nao_vale_hoje": dotacao_nao_vale_hoje,
        "rotulo_dia_hoje": rotulo_dia_hoje,
        "bloqueado": bloqueado,
        "insights": central_de_decisao.gerar_insights(contexto_decisao),
        "calendario_preview": calendario_preview,
        "tendencia_proximos_dias": tendencia,
        "provisoes_do_dia": hoje_info["quantidade_provisoes"] if hoje_info else 0,
        "valor_provisionado_hoje": hoje_info["provisionado"] if hoje_info else ZERO,
        "minhas_compras": minhas_compras,
        "minhas_compras_pendentes": minhas_compras_pendentes,
        "minhas_provisoes": minhas_provisoes,
        "minhas_solicitacoes": minhas_solicitacoes,
    }


def viewmodel_gerente(usuario, hoje: Optional[date] = None) -> dict:
    """Payload do Dashboard do Gerente (RC-C01): indicadores consolidados e
    fila de decisão — sem os insumos brutos do planejamento financeiro.

    RC também unifica aqui os dois calendários do sistema: o Gerente passa
    a usar o MESMO day-walk do Motor Financeiro que o Comprador
    (`obter_calendario_mensal`), eliminando a divergência histórica de
    cores/limites quando saldo acumulado/redistribuição estão ativos."""
    from compras.models import Compra
    from finance_engine.services import motor_financeiro

    filial = usuario.filial
    hoje = hoje or date.today()

    dias_mes = obter_calendario_mensal(filial, hoje.year, hoje.month)
    posicao_hoje = next((dia for dia in dias_mes if dia["data"] == hoje), None)
    resumo = obter_resumo_comprador(filial, hoje)
    # Indicadores consolidados (números finais apenas — nunca faturamento,
    # custos ou disponibilidade, que são exclusivos do Financeiro).
    capacidade_mes = motor_financeiro.capacidade_do_mes(filial, hoje.year, hoje.month)

    pendentes = obter_compras_pendentes(filial)
    recentes = (
        Compra.objects.filter(filial=filial)
        .exclude(status=Compra.Status.PENDENTE)
        .select_related("fornecedor", "usuario")[:8]
    )
    saldo_hoje = posicao_hoje["saldo_disponivel"] if posicao_hoje else ZERO

    return {
        "perfil_viewmodel": "gerente",
        "filial": filial,
        "limite_diario": resumo["limite_diario"],
        "comprado_hoje": posicao_hoje["comprado"] if posicao_hoje else ZERO,
        "saldo_hoje": saldo_hoje,
        # Críticos (rodada 2): negativo nunca aparece como "sobram R$ -920,22":
        # vira "excedido em R$ 920,22" (mesmo padrão do Comprador/barra lateral).
        "excedido_hoje": -saldo_hoje if saldo_hoje < ZERO else ZERO,
        "status_do_dia": resumo["cor_hoje"],
        "hoje_sem_limite_proprio": resumo["hoje_sem_limite_proprio"] and resumo["comprado_hoje"] <= ZERO,
        # Dia sem limite pelo Calendário Operacional MESMO com compra lançada
        # (o card "Limite de hoje" explica o R$ 0 em vez de só mostrar a filial).
        "dia_sem_limite_hoje": resumo["hoje_sem_limite_proprio"],
        "rotulo_dia_hoje": _rotulo_dia(resumo["tipo_dia_hoje"]),
        "capacidade_mensal": capacidade_mes.capacidade_mensal_ajustada,
        "dias_uteis": capacidade_mes.dias_uteis,
        "dias": dias_mes,
        "pendentes": pendentes,
        "recentes": recentes,
        # Só as que o Gerente decide na etapa atual (fluxo por alçada) — a
        # que já subiu para o Financeiro não é mais pendência dele.
        "provisoes_aguardando_aprovacao": contar_solicitacoes_pendentes([filial.pk], usuario=usuario),
        # Etapa 02 (Cliente-Ready): mesmo sinal aditivo do Comprador — só diz
        # "já existe Receita cadastrada este mês?", nunca o valor em si.
        "capacidade_configurada": capacidade_configurada(filial, hoje.year, hoje.month),
    }


def _rotulo_dia(tipo):
    from finance_engine.calendario_operacional import rotulo_do_tipo

    return rotulo_do_tipo(tipo)


def _altura_pct(saldo, limite):
    from finance_engine.calculations import calcular_percentual_utilizado

    # Sprint de Consolidação (Gate 2A, P0-2): limite negativo agora resulta
    # em percentual > 100 (semáforo vermelho honesto) — a altura da barra
    # visual precisa continuar limitada ao próprio contêiner.
    return min(calcular_percentual_utilizado(saldo, limite), Decimal("100"))
