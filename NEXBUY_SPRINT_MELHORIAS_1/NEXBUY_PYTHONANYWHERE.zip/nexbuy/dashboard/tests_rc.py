"""Testes da RC do Épico 01 — contrato de segurança por perfil.

Validam as correções da Release Candidate na ARQUITETURA (não na
apresentação): o payload dos perfis restritos é montado por whitelist
(ViewModels), o escopo do Comprador é o próprio usuário, o bloqueio de
comprador barra a compra na origem, a validação monetária vale no model e
a separação multiempresa segue total.

Rode com: python manage.py test dashboard.tests_rc
"""
from datetime import date, timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.test import Client, TestCase

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from compras.services import (
    avaliar_e_criar_compra,
    bloquear_comprador,
    compras_visiveis_para,
    definir_limite_comprador,
    liberar_comprador,
)
from dashboard.viewmodels import (
    CHAVES_PROIBIDAS_COMPRADOR,
    CHAVES_PROIBIDAS_GERENTE,
    viewmodel_comprador,
    viewmodel_gerente,
)
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, Receita
from gestao_compras.models import Provisao
from gestao_compras.services import provisoes_visiveis_para
from usuarios.models import Usuario
from core.utils_testes import garantir_capacidade_no_dia


class BaseRCTestCase(TestCase):
    """Cenário comum: empresa com Financeiro/Gerente/2 Compradores, contas
    fixas com nomes sensíveis ("Folha de Pagamento", "Aluguel") e uma
    SEGUNDA empresa para os testes de separação multiempresa."""

    @classmethod
    def setUpTestData(cls):
        cls.empresa = Empresa.objects.create(nome="Empresa RC", cnpj="90.000.000/0001-90")
        cls.filial = Filial.objects.create(empresa=cls.empresa, nome="Matriz RC")
        ConfiguracaoFinanceira.objects.create(empresa=cls.empresa, percentual_compras=Decimal("30"))
        Receita.objects.create(filial=cls.filial, mes=date.today().replace(day=1), faturamento=Decimal("300000"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(cls.empresa)
        # Sprint de Consolidação (Gate 2A, P0-3): dia_vencimento FIXO (ex.: 5)
        # é frágil — o dashboard só lista "Próximos vencimentos" numa janela
        # de 14 dias, então o teste passava ou falhava dependendo do dia do
        # mês em que a suíte rodava. Calculado relativo a hoje: a próxima
        # ocorrência sempre cai a poucos dias de distância (nunca no mesmo
        # dia, nunca fora da janela), qualquer que seja a data de execução —
        # verificado por simulação em financeiro/tests.py para 800+ dias
        # consecutivos (nenhuma falha).
        dia_vencimento_proximo = min((date.today() + timedelta(days=6)).day, 28)
        CustoFixo.objects.create(
            filial=cls.filial, descricao="Folha de Pagamento", valor=Decimal("45000"),
            dia_vencimento=dia_vencimento_proximo,
        )
        CustoFixo.objects.create(filial=cls.filial, descricao="Aluguel", valor=Decimal("8000"), dia_vencimento=10)
        cls.categoria = Categoria.objects.create(empresa=cls.empresa, nome="Insumos RC")
        cls.fornecedor = Fornecedor.objects.create(empresa=cls.empresa, nome="Fornecedor RC")

        def criar(username, perfil):
            return Usuario.objects.create_user(
                username=username, password="x", perfil=perfil, empresa=cls.empresa, filial=cls.filial
            )

        cls.comprador_a = criar("rc_comprador_a", Usuario.Perfil.COMPRADOR)
        cls.comprador_b = criar("rc_comprador_b", Usuario.Perfil.COMPRADOR)
        cls.gerente = criar("rc_gerente", Usuario.Perfil.GERENTE)
        cls.financeiro = criar("rc_financeiro", Usuario.Perfil.FINANCEIRO)

        # Segunda empresa, totalmente separada (Correção 09).
        cls.empresa2 = Empresa.objects.create(nome="Outra Empresa RC", cnpj="91.000.000/0001-91")
        cls.filial2 = Filial.objects.create(empresa=cls.empresa2, nome="Matriz 2")
        cls.comprador_outro = Usuario.objects.create_user(
            username="rc_comprador_outra_empresa", password="x",
            perfil=Usuario.Perfil.COMPRADOR, empresa=cls.empresa2, filial=cls.filial2,
        )

    def _compra_de(self, usuario, valor="100.00"):
        return avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal(valor),
            categoria=self.categoria, centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            numero_parcelas=1, usuario=usuario, observacao="",
        ).compra

    def _client_de(self, usuario):
        client = Client(SERVER_NAME="127.0.0.1")
        client.force_login(usuario)
        return client


class ViewModelContratoSegurancaTest(BaseRCTestCase):
    """Correções 01 e 05 — o backend entrega apenas dados autorizados."""

    def test_payload_do_comprador_nao_contem_nenhuma_chave_proibida(self):
        payload = viewmodel_comprador(self.comprador_a)
        vazamentos = set(payload) & CHAVES_PROIBIDAS_COMPRADOR
        self.assertEqual(vazamentos, set())

    def test_payload_do_gerente_nao_contem_nenhuma_chave_proibida(self):
        payload = viewmodel_gerente(self.gerente)
        vazamentos = set(payload) & CHAVES_PROIBIDAS_GERENTE
        self.assertEqual(vazamentos, set())

    def test_html_do_comprador_nao_expoe_contas_nem_planejamento(self):
        """Nada de esconder via CSS: os termos não podem sequer chegar ao
        HTML — as contas com estes nomes EXISTEM na filial (setUp)."""
        resposta = self._client_de(self.comprador_a).get("/")
        self.assertEqual(resposta.status_code, 200)
        html = resposta.content.decode("utf-8")
        for termo in ("Folha de Pagamento", "Aluguel", "Meta Mensal", "Capacidade mensal", "Faturamento"):
            self.assertNotIn(termo, html)
        self.assertIn("Posso comprar hoje?", html)

    def test_html_do_financeiro_continua_vendo_as_contas(self):
        resposta = self._client_de(self.financeiro).get("/")
        self.assertEqual(resposta.status_code, 200)
        html = resposta.content.decode("utf-8")
        self.assertIn("Folha de Pagamento", html)

    def test_payload_do_comprador_traz_o_essencial_do_perfil(self):
        payload = viewmodel_comprador(self.comprador_a)
        for chave in (
            "pode_comprar_hoje", "capacidade_disponivel", "limite_diario", "status_do_dia",
            "limite_pessoal", "bloqueado", "calendario_preview", "minhas_compras", "minhas_solicitacoes",
        ):
            self.assertIn(chave, payload)


class EscopoCompradorTest(BaseRCTestCase):
    """Correção 01 — o Comprador enxerga apenas o que é dele."""

    def test_lista_de_compras_do_comprador_traz_apenas_as_proprias(self):
        minha = self._compra_de(self.comprador_a)
        do_outro = self._compra_de(self.comprador_b)
        visiveis = list(compras_visiveis_para(self.comprador_a))
        self.assertIn(minha, visiveis)
        self.assertNotIn(do_outro, visiveis)

        resposta = self._client_de(self.comprador_a).get("/compras/lista/")
        compras_da_tela = list(resposta.context["compras"])
        self.assertIn(minha, compras_da_tela)
        self.assertNotIn(do_outro, compras_da_tela)

    def test_gestores_seguem_vendo_as_compras_da_filial(self):
        minha = self._compra_de(self.comprador_a)
        do_outro = self._compra_de(self.comprador_b)
        visiveis = list(compras_visiveis_para(self.gerente))
        self.assertIn(minha, visiveis)
        self.assertIn(do_outro, visiveis)

    def test_timeline_de_provisao_de_outro_comprador_retorna_404(self):
        provisao_do_b = Provisao.objects.create(
            empresa=self.empresa, filial=self.filial, comprador=self.comprador_b,
            fornecedor=self.fornecedor, categoria=self.categoria, data=date.today(),
            valor_total=Decimal("500.00"), status=Provisao.Status.PROVISIONADA,
        )
        cliente_a = self._client_de(self.comprador_a)
        resposta = cliente_a.get(f"/gestao-compras/provisao/{provisao_do_b.pk}/timeline/")
        self.assertEqual(resposta.status_code, 404)
        # O gerente da filial segue acessando normalmente.
        resposta_gerente = self._client_de(self.gerente).get(
            f"/gestao-compras/provisao/{provisao_do_b.pk}/timeline/"
        )
        self.assertEqual(resposta_gerente.status_code, 200)

    def test_timeline_financeira_restrita_por_permissao(self):
        self.assertEqual(self._client_de(self.comprador_a).get("/timeline/").status_code, 403)
        self.assertEqual(self._client_de(self.gerente).get("/timeline/").status_code, 200)
        self.assertEqual(self._client_de(self.financeiro).get("/timeline/").status_code, 200)


class MotorCapacidadeTest(BaseRCTestCase):
    """Correção 03 — bloqueio na origem e limite individual do Financeiro."""

    def test_comprador_bloqueado_tem_compra_barrada_na_origem(self):
        bloquear_comprador(self.comprador_a, self.empresa, self.financeiro)
        compra = self._compra_de(self.comprador_a, "50.00")
        self.assertEqual(compra.status, Compra.Status.BLOQUEADA)

        payload = viewmodel_comprador(self.comprador_a)
        self.assertTrue(payload["bloqueado"])
        self.assertFalse(payload["pode_comprar_hoje"])

        liberar_comprador(self.comprador_a, self.empresa, self.financeiro)
        compra2 = self._compra_de(self.comprador_a, "50.00")
        self.assertNotEqual(compra2.status, Compra.Status.BLOQUEADA)

    def test_bloquear_e_liberar_comprador_geram_eventos_na_central_de_auditoria(self):
        """Prompt 2, Gate D (Seção 9): categorias próprias
        `COMPRADOR_BLOQUEADO`/`COMPRADOR_LIBERADO`."""
        from auditoria.models import RegistroAuditoria

        bloquear_comprador(self.comprador_a, self.empresa, self.financeiro)
        bloqueado = RegistroAuditoria.objects.filter(
            categoria=RegistroAuditoria.Categoria.COMPRADOR_BLOQUEADO,
        ).latest("criado_em")
        self.assertEqual(bloqueado.estado_depois, {"bloqueado": True})
        self.assertEqual(bloqueado.usuario_id, self.financeiro.pk)
        self.assertEqual(bloqueado.resultado, RegistroAuditoria.Resultado.BLOQUEADO)

        liberar_comprador(self.comprador_a, self.empresa, self.financeiro)
        liberado = RegistroAuditoria.objects.filter(
            categoria=RegistroAuditoria.Categoria.COMPRADOR_LIBERADO,
        ).latest("criado_em")
        self.assertEqual(liberado.estado_depois, {"bloqueado": False})

    def test_definir_limite_comprador_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        definir_limite_comprador(self.comprador_a, self.empresa, Decimal("200.00"), self.financeiro)
        registro = RegistroAuditoria.objects.filter(
            categoria=RegistroAuditoria.Categoria.LIMITE_COMPRADOR_ALTERADO,
        ).latest("criado_em")
        self.assertEqual(registro.usuario_id, self.financeiro.pk)

    def test_limite_individual_definido_pelo_financeiro_envia_para_aprovacao(self):
        definir_limite_comprador(self.comprador_a, self.empresa, Decimal("200.00"), self.financeiro)
        compra = self._compra_de(self.comprador_a, "350.00")
        self.assertEqual(compra.status, Compra.Status.PENDENTE)
        payload = viewmodel_comprador(self.comprador_a)
        self.assertEqual(payload["limite_pessoal"], Decimal("200.00"))

    def test_capacidade_disponivel_e_a_dotacao_pessoal_quando_menor_que_a_da_filial(self):
        """Sprint de Consolidação (Gate 2A, Parte 4): antes o dashboard
        mostrava dois números lado a lado sem relação entre si
        ("Capacidade disponível agora" da filial e "Meu limite por
        compra" pessoal). Agora existe UM indicador só, sempre o MENOR
        entre a capacidade da filial e a dotação pessoal restante."""
        definir_limite_comprador(self.comprador_a, self.empresa, Decimal("500.00"), self.financeiro)
        payload = viewmodel_comprador(self.comprador_a)
        self.assertEqual(payload["capacidade_disponivel"], Decimal("500.00"))
        self.assertEqual(payload["capacidade_limitada_por"], "dotacao_pessoal")

    def test_capacidade_disponivel_usa_a_da_filial_quando_a_dotacao_pessoal_e_maior(self):
        definir_limite_comprador(self.comprador_a, self.empresa, Decimal("999999.00"), self.financeiro)
        payload = viewmodel_comprador(self.comprador_a)
        self.assertEqual(payload["capacidade_limitada_por"], "filial")
        self.assertLess(payload["capacidade_disponivel"], Decimal("999999.00"))

    def test_capacidade_disponivel_desconta_compras_do_proprio_dia(self):
        definir_limite_comprador(self.comprador_a, self.empresa, Decimal("500.00"), self.financeiro)
        self._compra_de(self.comprador_a, "150.00")
        payload = viewmodel_comprador(self.comprador_a)
        self.assertEqual(payload["gasto_hoje_pessoal"], Decimal("150.00"))
        self.assertEqual(payload["capacidade_disponivel"], Decimal("350.00"))

    def test_pode_comprar_hoje_fica_falso_quando_dotacao_pessoal_esgota(self):
        definir_limite_comprador(self.comprador_a, self.empresa, Decimal("100.00"), self.financeiro)
        self._compra_de(self.comprador_a, "100.00")
        payload = viewmodel_comprador(self.comprador_a)
        self.assertFalse(payload["pode_comprar_hoje"])
        self.assertEqual(payload["capacidade_disponivel"], Decimal("0.00"))

    def test_telas_do_motor_de_capacidade_sao_exclusivas_dos_gestores(self):
        cliente_fin = self._client_de(self.financeiro)
        self.assertEqual(cliente_fin.get("/financeiro/capacidade-compradores/").status_code, 200)
        self.assertEqual(cliente_fin.get("/financeiro/calendario/").status_code, 200)
        cliente_comp = self._client_de(self.comprador_a)
        self.assertEqual(cliente_comp.get("/financeiro/capacidade-compradores/").status_code, 403)
        self.assertEqual(cliente_comp.get("/financeiro/calendario/").status_code, 403)


class ValidacaoMonetariaTest(BaseRCTestCase):
    """Correção da inconsistência nº 1 do Baseline: valores monetários
    validados no model (e no banco, via CheckConstraint)."""

    def test_compra_com_valor_negativo_ou_zero_e_invalida(self):
        for valor in (Decimal("-10.00"), Decimal("0")):
            compra = Compra(
                empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor,
                categoria=self.categoria, usuario=self.comprador_a,
                valor=valor, data_compra=date.today(),
            )
            with self.assertRaises(ValidationError):
                compra.full_clean()

    def test_receita_negativa_e_dia_de_vencimento_invalido_sao_rejeitados(self):
        receita = Receita(filial=self.filial, empresa=self.empresa, mes=date.today(), faturamento=Decimal("-1"))
        with self.assertRaises(ValidationError):
            receita.full_clean()
        custo = CustoFixo(
            filial=self.filial, empresa=self.empresa, descricao="Teste", valor=Decimal("10"), dia_vencimento=45
        )
        with self.assertRaises(ValidationError):
            custo.full_clean()


class MultiempresaTest(BaseRCTestCase):
    """Correção 09 — separação total entre CNPJs."""

    def test_escopos_nao_atravessam_empresas(self):
        compra_outra_empresa = avaliar_e_criar_compra(
            filial=self.filial2,
            fornecedor=Fornecedor.objects.create(empresa=self.empresa2, nome="Forn 2"),
            valor=Decimal("80.00"),
            categoria=Categoria.objects.create(empresa=self.empresa2, nome="Cat 2"),
            centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            numero_parcelas=1, usuario=self.comprador_outro, observacao="",
        ).compra
        self.assertNotIn(compra_outra_empresa, list(compras_visiveis_para(self.gerente)))
        self.assertNotIn(compra_outra_empresa, list(compras_visiveis_para(self.comprador_a)))
        self.assertEqual(
            list(provisoes_visiveis_para(self.comprador_outro).values_list("empresa_id", flat=True).distinct()),
            [],
        )

    def test_financeiro_nao_gerencia_comprador_de_outra_empresa(self):
        cliente_fin = self._client_de(self.financeiro)
        resposta = cliente_fin.post(f"/financeiro/capacidade-compradores/{self.comprador_outro.pk}/bloquear/")
        self.assertEqual(resposta.status_code, 404)
        self.comprador_outro.refresh_from_db()
        situacao = cliente_fin.get("/financeiro/capacidade-compradores/")
        nomes = [c["usuario"].username for c in situacao.context["situacao"]]
        self.assertNotIn("rc_comprador_outra_empresa", nomes)


class DashboardExecutivoTest(BaseRCTestCase):
    """Épico 2A/2A.5 — o Dashboard Executivo precisa renderizar COM alertas
    estratégicos reais (regressão: `gerar_alertas` devolve dataclasses, não
    dicts — o consolidado quebrava só quando existia alerta)."""

    def test_dashboard_do_proprietario_renderiza_com_alertas_reais(self):
        from dashboard.services import alertas_estrategicos

        # Compra muito acima do limite diário (regra padrão ALERTA aprova e
        # conta no limite) — garante ao menos um alerta do Motor hoje.
        self._compra_de(self.comprador_a, "999999.00")

        proprietario = Usuario.objects.create_user(
            username="rc_proprietario", password="x",
            perfil=Usuario.Perfil.PROPRIETARIO, empresa=self.empresa,
        )
        resposta = self._client_de(proprietario).get("/")
        self.assertEqual(resposta.status_code, 200)

        alertas = alertas_estrategicos(self.empresa, date.today())
        self.assertTrue(alertas, "o cenário deveria produzir ao menos um alerta")
        self.assertIn("filial", alertas[0])
        self.assertIn(alertas[0]["nivel"], ("critico", "atencao"))
