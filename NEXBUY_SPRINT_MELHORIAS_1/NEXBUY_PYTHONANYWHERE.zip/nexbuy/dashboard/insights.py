"""Central de Decisão do Dashboard (Sprint 5).

Gera, a partir de dados já calculados pelo restante do sistema (nunca
recalcula regra financeira aqui — apenas lê números prontos vindos do Motor
Financeiro e da Gestão de Compras), uma lista curta de mensagens que
respondem "o que eu preciso saber agora?" para o Comprador.

Arquitetura pensada para o item 10 da Sprint 5 ("preparação para futuros
insights"): cada mensagem vem de uma `RegraInsight` independente e testável
isoladamente. Hoje todas as regras são determinísticas (comparam números já
calculados); no futuro, uma regra pode ser substituída ou somada por um
serviço de recomendação mais elaborado (ex.: `RegraRecomendacaoIA`) sem
mudar `CentralDeDecisaoService` nem quem o consome — a interface
`RegraInsight.avaliar(contexto) -> Insight | None` é o único ponto de
contato, e nenhuma Inteligência Artificial foi implementada nesta Sprint.
"""
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Optional

from core.utils import formatar_moeda


@dataclass(frozen=True)
class ContextoDecisao:
    """Retrato do dia do Comprador — tudo que as regras precisam para
    decidir o que mostrar. Montado uma única vez por
    `dashboard.services.obter_painel_comprador`, a partir de dados que a
    própria view já buscou (nenhuma consulta nova é feita aqui)."""

    hoje: date
    pode_comprar_hoje: bool
    cor_hoje: str  # "verde" | "laranja" | "vermelho" (mesmo limiar do Sprint 4.1)
    percentual_utilizado_hoje: Decimal
    saldo_disponivel_hoje: Decimal
    provisoes_aguardando_aprovacao: int
    compras_aguardando_aprovacao: int
    cor_amanha: Optional[str]
    compromissos_amanha: int
    # Demo Experience 1.0, item 12 — dois novos sinais, ambos opcionais e
    # sem nenhum efeito sobre aprovação/bloqueio: apenas texto informativo.
    fornecedor_acima_historico: Optional[str] = None
    provisoes_previstas_amanha: int = 0
    # Etapa 02 (Cliente-Ready): True quando já existe Faturamento (Receita)
    # cadastrado no mês — default True preserva o comportamento de todo
    # chamador existente (inclusive os testes, que não passam este campo).
    # Só fica False no cenário real de "acabei de fazer o Primeiro Acesso e
    # ainda não configurei nada" — usado para não tratar "sem configuração"
    # como se fosse "capacidade positiva calculada".
    capacidade_configurada: bool = True
    # Auditoria pré-apresentação: sem este campo, a saudação de
    # `gerar_cabecalho` mostrava "Hoje sua capacidade de compra é de R$ X"
    # mesmo com o comprador bloqueado pelo Financeiro — número real da
    # filial, mas enganoso, já que ele não pode comprar nada. O resto do
    # dashboard (card-herói, KPI de dotação) já tratava `bloqueado`
    # corretamente; só a saudação ficava de fora. Default False preserva
    # todo chamador existente.
    bloqueado: bool = False
    # Crítico funcional (rodada 1): hoje não conta capacidade pelo
    # Calendário Operacional (sábado/domingo da regra padrão, feriado,
    # bloqueio), não herdou saldo e nada foi lançado — "dia sem compra",
    # não "limite atingido". `rotulo_dia_hoje`: "sábado", "feriado"...
    hoje_sem_limite_proprio: bool = False
    rotulo_dia_hoje: str = ""


# Mensagem da Central de Decisão para o comprador bloqueado pelo Financeiro.
MENSAGEM_BLOQUEADO = (
    "Suas compras estão suspensas pelo Financeiro — toda compra nova fica barrada até a liberação."
)


@dataclass(frozen=True)
class Insight:
    nivel: str  # "ok" | "atencao" — controla o ícone (✓/⚠) e a cor na tela
    mensagem: str


class RegraInsight:
    """Interface de uma regra da Central de Decisão. Ponto de extensão para
    Sprints futuras — ver docstring do módulo."""

    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        raise NotImplementedError


class RegraLimiteDisponivel(RegraInsight):
    """A regra mais básica: reaproveita a MESMA classificação de cor
    (verde/laranja/vermelho) usada no Calendário Inteligente e no Motor
    Financeiro — não inventa um novo limiar."""

    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        # Comprador bloqueado pelo Financeiro: nada de "pode comprar
        # normalmente" — a cor do dia é da filial/dotação, mas qualquer
        # compra dele é barrada na origem (`avaliar_e_criar_compra`). Vem
        # antes de tudo: o bloqueio vale mesmo sem receita no mês ou em dia
        # sem limite próprio. (Simulação da demo publicada: a Carla via
        # "Bloqueado" no destaque e "pode comprar normalmente" logo abaixo.)
        if contexto.bloqueado:
            return Insight("atencao", MENSAGEM_BLOQUEADO)
        # Etapa 02 (Cliente-Ready): sem Receita cadastrada, "verde" é neutro
        # (zero comprado, zero limite) — não é o mesmo que "pode comprar
        # normalmente". Mensagem própria, sem inventar cor nova.
        if not contexto.capacidade_configurada:
            return Insight(
                "neutro",
                # Críticos (rodada 2): a Central de Decisão é do Comprador, que
                # não lança receita — a mensagem diz quem precisa agir.
                "Capacidade financeira ainda não configurada — o Financeiro ainda não lançou a receita do mês.",
            )
        if contexto.hoje_sem_limite_proprio:
            return Insight(
                "neutro",
                f"Hoje ({contexto.rotulo_dia_hoje or 'dia não útil'}) não é dia de compra pela regra do "
                "Calendário Operacional — o limite volta no próximo dia útil.",
            )
        if contexto.cor_hoje == "vermelho":
            return Insight("atencao", "Seu limite disponível está esgotado hoje.")
        if contexto.cor_hoje == "laranja":
            return Insight("atencao", "Seu limite disponível está baixo — atenção ao restante do dia.")
        return Insight("ok", "Hoje você pode comprar normalmente.")


class RegraSaldoConfortavel(RegraInsight):
    LIMIAR_PERCENTUAL_CONFORTAVEL = Decimal("50")

    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        if contexto.bloqueado or not contexto.capacidade_configurada or contexto.hoje_sem_limite_proprio:
            return None
        if contexto.cor_hoje == "verde" and contexto.percentual_utilizado_hoje < self.LIMIAR_PERCENTUAL_CONFORTAVEL:
            return Insight("ok", "O saldo disponível está confortável.")
        return None


class RegraProvisoesAguardandoAprovacao(RegraInsight):
    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        n = contexto.provisoes_aguardando_aprovacao
        if n == 1:
            return Insight("atencao", "Existe 1 provisão aguardando aprovação.")
        if n > 1:
            return Insight("atencao", f"Existem {n} provisões aguardando aprovação.")
        return None


class RegraComprasAguardandoAprovacao(RegraInsight):
    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        n = contexto.compras_aguardando_aprovacao
        if n == 1:
            return Insight("atencao", "Existe 1 compra aguardando aprovação do Gerente.")
        if n > 1:
            return Insight("atencao", f"Existem {n} compras aguardando aprovação do Gerente.")
        return None


class RegraCompromissosAmanha(RegraInsight):
    LIMIAR_MUITOS_COMPROMISSOS = 2

    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        if contexto.compromissos_amanha >= self.LIMIAR_MUITOS_COMPROMISSOS:
            return Insight("atencao", "Amanhã existem muitos compromissos financeiros.")
        if contexto.cor_amanha == "vermelho":
            return Insight("atencao", "Amanhã o limite disponível já nasce comprometido.")
        return None


class RegraFornecedorAcimaDoHistorico(RegraInsight):
    """Demo Experience 1.0, item 12 — reaproveita a mesma arquitetura de
    regras plugáveis desenhada na Sprint 5; nenhuma alteração ao contrato
    de `RegraInsight` foi necessária."""

    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        if contexto.fornecedor_acima_historico:
            return Insight("atencao", f"Fornecedor {contexto.fornecedor_acima_historico} possui pedido acima do histórico.")
        return None


class RegraComprasPrevistasAmanha(RegraInsight):
    def avaliar(self, contexto: ContextoDecisao) -> Optional[Insight]:
        if contexto.provisoes_previstas_amanha:
            return Insight("ok", "Há compras previstas para amanhã.")
        return None


REGRAS_PADRAO = (
    RegraLimiteDisponivel(),
    RegraSaldoConfortavel(),
    RegraProvisoesAguardandoAprovacao(),
    RegraComprasAguardandoAprovacao(),
    RegraCompromissosAmanha(),
    RegraFornecedorAcimaDoHistorico(),
    RegraComprasPrevistasAmanha(),
)


class CentralDeDecisaoService:
    """Fachada única da Central de Decisão — percorre as regras registradas
    e devolve só as mensagens que se aplicam ao contexto do dia."""

    def __init__(self, regras=REGRAS_PADRAO):
        self.regras = regras

    def gerar_insights(self, contexto: ContextoDecisao) -> list[Insight]:
        insights = []
        for regra in self.regras:
            insight = regra.avaliar(contexto)
            if insight is not None:
                insights.append(insight)
        return insights


central_de_decisao = CentralDeDecisaoService()


def saudacao_do_momento(hora: int) -> str:
    """'Bom dia' / 'Boa tarde' / 'Boa noite', conforme a hora local (0-23).
    Função pura (recebe a hora em vez de lê-la) para ser testável sem mockar
    tempo — quem chama passa `timezone.localtime().hour`."""
    if hora < 12:
        return "Bom dia"
    if hora < 18:
        return "Boa tarde"
    return "Boa noite"


def gerar_cabecalho(usuario, contexto: ContextoDecisao, hora: int) -> dict:
    """Saudação dinâmica do cabeçalho do Dashboard (Sprint 5, item 2). As
    linhas variam conforme o cenário do dia — não é um texto fixo."""
    # Etapa 02 (Cliente-Ready): sem Receita cadastrada, "capacidade de
    # compra é de R$ 0,00" seria um número técnico correto mas enganoso —
    # lê como "seu limite é zero", não como "ainda não configurado".
    if contexto.bloqueado:
        linhas = ["Suas compras estão temporariamente suspensas pelo Financeiro. Procure o responsável para liberação."]
    elif contexto.capacidade_configurada:
        # Crítico funcional (rodada 1): o valor é o MESMO "quanto ainda
        # posso comprar hoje" do card-herói (o menor entre dotação e filial,
        # montado em `viewmodel_comprador`) — e negativo nunca aparece como
        # "capacidade de R$ -415,45": vira "excedido em R$ X".
        saldo = contexto.saldo_disponivel_hoje
        if contexto.hoje_sem_limite_proprio:
            linhas = [
                f"Hoje ({contexto.rotulo_dia_hoje or 'dia não útil'}) não tem limite de compra pela regra do "
                "Calendário Operacional."
            ]
        elif saldo > 0:
            linhas = [f"Hoje você ainda pode comprar {formatar_moeda(saldo, incluir_prefixo=True)}."]
        elif saldo == 0:
            linhas = ["Hoje você já usou todo o seu limite de compra."]
        else:
            linhas = [f"Hoje seu limite de compra foi excedido em {formatar_moeda(-saldo, incluir_prefixo=True)}."]
    else:
        # Críticos (rodada 2): o cabeçalho é do Comprador, que não pode lançar
        # receita — antes mandava ele "cadastrar o faturamento" (a tela Nova
        # Compra já acertava: "peça ao Proprietário ou ao Financeiro").
        linhas = [
            "O Financeiro ainda não lançou a receita do mês — até lá não há limite de compra calculado. "
            "Se precisar comprar, fale com o Financeiro ou o Proprietário."
        ]

    n_provisoes = contexto.provisoes_aguardando_aprovacao
    if n_provisoes == 1:
        linhas.append("Existe 1 provisão aberta aguardando aprovação.")
    elif n_provisoes > 1:
        linhas.append(f"Existem {n_provisoes} provisões abertas aguardando aprovação.")
    if contexto.compras_aguardando_aprovacao:
        linhas.append("Existem compras suas aguardando aprovação.")
    # Bloqueado: a situação do limite do dia não se aplica a ele (a linha de
    # suspensão já diz tudo — "limite saudável" ao lado dela se contradiz).
    if (
        contexto.capacidade_configurada
        and not contexto.bloqueado
        and not contexto.hoje_sem_limite_proprio
        and not contexto.provisoes_aguardando_aprovacao
        and not contexto.compras_aguardando_aprovacao
    ):
        if contexto.cor_hoje == "verde":
            linhas.append("Seu limite diário está saudável.")
        elif contexto.cor_hoje == "laranja":
            linhas.append("Seu limite diário está próximo do fim.")
        else:
            linhas.append("Seu limite diário já foi atingido.")

    return {
        "saudacao": saudacao_do_momento(hora),
        "nome": usuario.first_name or usuario.username,
        "linhas": linhas,
    }
