from django.urls import path

from . import views

app_name = "dashboard"

urlpatterns = [
    path("", views.dashboard_home, name="home"),
    path("timeline/", views.timeline_financeira, name="timeline"),
    # Épico 2A (Etapa 01) — páginas de contexto da nova navegação
    path("aprovacoes/", views.central_aprovacoes, name="aprovacoes"),
    path("indicadores/", views.indicadores, name="indicadores"),
]
