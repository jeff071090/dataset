"""Regras de agregação dos dashboards.

Extraído das views (Sprint 3, regra 8 — "toda regra de negócio deve estar em
Services, nunca diretamente nas Views") a partir de uma violação identificada
na revisão pré-Sprint 3: `_kpis_administrativos` e o resumo por filial do
Dashboard do Proprietário viviam antes em `dashboard/views.py`. O
comportamento é idêntico ao de antes — apenas a localização mudou.

Os indicadores "por dia" (capacidade disponível hoje, saldo acumulado, dias
comprometidos, limite restante, percentual utilizado) são novos da Sprint 3
e vêm diretamente do Motor Financeiro (`finance_engine.services`).
"""
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional

from django.db.models import Sum
from django.utils import timezone

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor, ParcelaCompra
from compras.services import (
    STATUS_CONSIDERADOS_NO_TOTAL_DIARIO,
    STATUS_REALIZADO,
    obter_compras_efetivadas_no_dia,
    obter_compras_pendentes,
    obter_situacao_compradores,
)
from finance_engine.calculations import calcular_percentual_utilizado
from finance_engine.services import motor_financeiro
from financeiro.models import CustoFixo, CustoVariavel
from financeiro.services import calcular_capacidade_compra, obter_proximos_compromissos
from gestao_compras.services import (
    contar_provisoes_previstas_para,
    contar_solicitacoes_pendentes,
    obter_calendario_mensal,
    obter_fornecedor_provisao_acima_do_historico,
    obter_ultimas_decisoes,
    obter_ultimas_provisoes,
)

from finance_engine.agenda import pagamentos_do_dia, proximos_vencimentos
from core.permissions import usuario_tem_permissao
from finance_engine.alertas import gerar_alertas
from finance_engine.calendario_operacional import rotulo_do_tipo
from finance_engine.services import motor_financeiro as _motor

from .insights import ContextoDecisao, central_de_decisao, gerar_cabecalho, saudacao_do_momento

ZERO = Decimal("0")
DIAS_TENDENCIA = 5
DIAS_PREVIEW_CALENDARIO = 7


def filial_em_foco(usuario, filiais):
    """A filial cujos números DIÁRIOS (capacidade de hoje, próximos dias,
    compradores) o painel mostra: a filial do próprio usuário quando ela
    está no contexto — a MESMA que o cabeçalho e o card "Capacidade do dia"
    da barra lateral (`core.context_processors`) leem —, senão a primeira
    filial do contexto."""
    filiais = list(filiais)
    filial_usuario_id = getattr(usuario, "filial_id", None)
    for filial in filiais:
        if filial.pk == filial_usuario_id:
            return filial
    return filiais[0] if filiais else None


def _lancamento_com_filial(item, filial, mostrar_filial: bool) -> dict:
    """Lançamento da Agenda + o nome da filial (quando há mais de uma)."""
    return {
        "descricao": item.descricao,
        "tipo": item.tipo,
        "data": item.data,
        "valor": item.valor,
        "status": item.status,
        "pendente": item.pendente,
        "filial_nome": filial.nome if mostrar_filial else "",
    }


def obter_painel_financeiro(usuario, filiais, hoje: Optional[date] = None, hora: int = 12) -> dict:
    """Centro de Controle Financeiro (Épico 5 — CORE 1.0): resumo do dia,
    pagamentos de hoje, próximos vencimentos, dias críticos, alertas,
    solicitações pendentes, prévia de calendário e capacidade — tudo por
    agregação dos services existentes (nenhuma regra nova aqui).

    Críticos (rodada 2): antes TUDO vinha só da 1ª filial do contexto
    (`filiais[0]`) — com o Financeiro autorizado em duas filiais, o painel
    dizia "Nenhum pagamento previsto para hoje" enquanto a Agenda (que soma
    todas as filiais do contexto) mostrava a parcela vencendo hoje, e o
    alerta falava de uma filial enquanto o cabeçalho e a barra lateral
    falavam de outra. Agora:

    - dinheiro (pagamentos de hoje, próximos vencimentos, alertas,
      parcelamentos) soma TODAS as filiais do contexto, igual à Agenda, e
      cada linha diz de qual filial é;
    - números do DIA (capacidade de hoje, próximos dias, compradores) são
      da filial em foco (`filial_em_foco`: a do usuário, a mesma do
      cabeçalho e da barra lateral), com o nome dela escrito no card."""
    hoje = hoje or date.today()
    filiais = list(filiais)
    primeira_filial = filial_em_foco(usuario, filiais)
    mostrar_filial = len(filiais) > 1

    pagamentos_hoje = {"itens": [], "quantidade": 0, "total": ZERO, "total_pendente": ZERO}
    vencimentos = []
    alertas = []
    dias_criticos = []
    calendario_preview = []
    capacidade = None
    # Visual QA & Demo Polish: o card "Capacidade de hoje" mostrava sempre a
    # mesma cor (verde), independente do valor — `posicoes` já traz a
    # classificação correta do dia (mesmo semáforo do calendário/P0-2, nunca
    # duplicado aqui), só faltava expor a posição de hoje para o template.
    cor_capacidade_hoje = "verde"
    limite_hoje = None
    hoje_sem_limite_proprio = False
    # O dia não conta capacidade pelo Calendário Operacional (fim de semana,
    # feriado, bloqueio) — MESMO que já exista compra lançada nele (aí o
    # card fica vermelho, "excedido", mas o texto explica o porquê).
    dia_sem_limite_hoje = False
    tipo_dia_hoje = ""
    if primeira_filial is not None:
        vencimentos_brutos = []
        for filial in filiais:
            do_dia = pagamentos_do_dia(filial, hoje)
            pagamentos_hoje["itens"].extend(
                _lancamento_com_filial(item, filial, mostrar_filial) for item in do_dia["itens"]
            )
            pagamentos_hoje["quantidade"] += do_dia["quantidade"]
            pagamentos_hoje["total"] += do_dia["total"]
            pagamentos_hoje["total_pendente"] += do_dia["total_pendente"]
            vencimentos_brutos.extend(
                (item, filial) for item in proximos_vencimentos(filial, hoje, dias_janela=14, limite=8)
            )
            for alerta in gerar_alertas(filial, hoje):
                alertas.append(
                    {
                        "nivel": alerta.nivel, "titulo": alerta.titulo, "mensagem": alerta.mensagem,
                        "filial_nome": filial.nome if mostrar_filial else "",
                    }
                )
        vencimentos_brutos.sort(key=lambda par: (par[0].data, par[0].descricao))
        vencimentos = [_lancamento_com_filial(item, filial, mostrar_filial) for item, filial in vencimentos_brutos[:8]]
        alertas.sort(key=lambda a: 0 if a["nivel"] == "critico" else 1)
        posicoes = _motor.calcular_posicoes_do_mes(primeira_filial, hoje.year, hoje.month)
        dias_criticos = [p for p in posicoes if p.data >= hoje and p.cor == "vermelho"][:5]
        capacidade = calcular_capacidade_compra(primeira_filial, hoje.year, hoje.month)
        # Críticos (rodada 2): o chip mostrava o saldo cru ("Hoje R$ -675")
        # como se fosse capacidade. Negativo vira "excedido em R$ X"; dia sem
        # limite próprio (fim de semana/feriado) e mês sem receita ficam
        # neutros — o mesmo padrão do Comprador e da barra lateral.
        calendario_preview = [
            {
                "data": p.data,
                "cor": p.cor,
                "saldo": p.saldo_do_dia,
                "excedido_em": -p.saldo_do_dia if p.saldo_do_dia < ZERO else ZERO,
                "sem_limite_proprio": p.sem_limite_proprio and p.comprado <= ZERO,
                "rotulo_dia": rotulo_do_tipo(p.tipo_dia),
            }
            for p in posicoes
            if p.data >= hoje
        ][:DIAS_PREVIEW_CALENDARIO]
        posicao_hoje = next((p for p in posicoes if p.data == hoje), None)
        if posicao_hoje is not None:
            cor_capacidade_hoje = posicao_hoje.cor
            # Crítico funcional (rodada 1): o card "Capacidade de hoje"
            # mostrava o limite BASE do mês mesmo num sábado/feriado, em que
            # o day-walk não dá limite — agora mostra o limite de HOJE.
            limite_hoje = posicao_hoje.limite_efetivo
            hoje_sem_limite_proprio = posicao_hoje.sem_limite_proprio and posicao_hoje.comprado <= ZERO
            dia_sem_limite_hoje = posicao_hoje.sem_limite_proprio
            tipo_dia_hoje = rotulo_do_tipo(posicao_hoje.tipo_dia)

    resumo_filiais = [
        {"filial": filial, **calcular_capacidade_compra(filial, hoje.year, hoje.month)} for filial in filiais
    ]

    # RC do Épico 01 (Correção 06): situação dos compradores (Motor de
    # Capacidade) e parcelamentos em aberto, direto no Centro de Controle.
    situacao_compradores = (
        obter_situacao_compradores(primeira_filial.empresa, primeira_filial, hoje)
        if primeira_filial is not None
        else []
    )
    parcelas_abertas = (
        ParcelaCompra.objects.filter(
            compra__filial__in=filiais, status=ParcelaCompra.Status.PENDENTE
        )
        .select_related("compra", "compra__fornecedor")
        .order_by("data_vencimento")
    )
    parcelamentos = {
        "quantidade": parcelas_abertas.count(),
        "total": parcelas_abertas.aggregate(total=Sum("valor"))["total"] or ZERO,
        "vencidas": sum(1 for p in parcelas_abertas if p.data_vencimento < hoje),
        "proximas": list(parcelas_abertas[:6]),
    }
    # Épico 2A (Etapa 06): "Compradores aguardando limite" — quantos ainda
    # não têm limite individual definido pelo Financeiro.
    compradores_sem_limite = sum(1 for c in situacao_compradores if c["limite"] is None and not c["bloqueado"])

    return {
        "saudacao": saudacao_do_momento(hora),
        # Filial dos números do dia (a do cabeçalho/barra lateral) e se o
        # painel precisa escrever o nome da filial em cada linha.
        "filial_foco": primeira_filial,
        "mostrar_filial": mostrar_filial,
        "pagamentos_hoje": pagamentos_hoje,
        "proximos_vencimentos": vencimentos,
        "alertas": alertas,
        "dias_criticos": dias_criticos,
        "calendario_preview": calendario_preview,
        "capacidade": capacidade,
        "cor_capacidade_hoje": cor_capacidade_hoje,
        "limite_hoje": limite_hoje,
        "hoje_sem_limite_proprio": hoje_sem_limite_proprio,
        "dia_sem_limite_hoje": dia_sem_limite_hoje,
        "tipo_dia_hoje": tipo_dia_hoje,
        "resumo_filiais": resumo_filiais,
        "situacao_compradores": situacao_compradores,
        "compradores_sem_limite": compradores_sem_limite,
        "parcelamentos": parcelamentos,
        # Só as que ESTE usuário decide na etapa atual (fluxo por alçada).
        "provisoes_aguardando_aprovacao": contar_solicitacoes_pendentes([f.pk for f in filiais], usuario=usuario),
        "compras_pendentes_qtd": Compra.objects.filter(
            filial__in=filiais, status=Compra.Status.PENDENTE
        ).count(),
        # Compra acima do limite é decisão de quem tem `compras.aprovar`
        # (Gerente/Proprietário por padrão) — a linha "aguardando a sua
        # decisão" só conta compras para quem de fato decide.
        "pode_aprovar_compras": usuario_tem_permissao(usuario, "compras.aprovar"),
    }


def obter_resumo_comprador(filial, hoje: Optional[date] = None) -> dict:
    """Indicadores do Dashboard do Comprador (Sprint 3, item 7): capacidade
    disponível hoje, saldo acumulado, dias comprometidos, limite restante e
    percentual utilizado.

    Até a Sprint 4, esta função também montava o calendário visual do mês
    (via `compras.services.calendario_mensal`, uma consulta agregada à
    parte). Na Sprint 5 o Dashboard do Comprador passou a reaproveitar o
    calendário mais completo de `gestao_compras.services.obter_calendario_mensal`
    (que já considera Provisões, não só Compras) — então essa consulta
    redundante foi removida daqui; `dashboard.services.obter_painel_comprador`
    é quem monta a tela inteira agora."""
    hoje = hoje or date.today()
    resumo = motor_financeiro.resumo_dashboard(filial, hoje)
    posicao_hoje = resumo["posicao_hoje"]

    return {
        "limite_diario": posicao_hoje.limite_efetivo,
        "limite_diario_base": posicao_hoje.limite_base,
        "saldo_acumulado": resumo["saldo_acumulado"],
        "comprado_hoje": posicao_hoje.comprado,
        "saldo_restante": resumo["limite_restante"],
        "dias_comprometidos": resumo["dias_comprometidos"],
        "percentual_utilizado": resumo["percentual_utilizado"],
        "cor_hoje": posicao_hoje.cor,
        "pode_comprar_hoje": resumo["limite_restante"] > ZERO,
        # Hoje não conta capacidade (sábado/domingo pela regra padrão,
        # feriado, bloqueio) e não herdou saldo: não é "limite atingido", é
        # dia sem compra prevista — as telas explicam em vez de alarmar.
        "hoje_sem_limite_proprio": posicao_hoje.sem_limite_proprio,
        "tipo_dia_hoje": posicao_hoje.tipo_dia,
    }


def obter_kpis_administrativos(empresa, hoje: date) -> dict:
    """Indicadores administrativos agregados da empresa, exibidos no
    Dashboard do Proprietário (Módulo 5 — Etapa 2)."""
    compras_mes = (
        Compra.objects.filter(
            empresa=empresa,
            data_compra__year=hoje.year,
            data_compra__month=hoje.month,
            status__in=STATUS_CONSIDERADOS_NO_TOTAL_DIARIO,
        ).aggregate(total=Sum("valor"))["total"]
        or ZERO
    )
    custos_fixos_total = (
        CustoFixo.objects.filter(empresa=empresa, ativo=True).aggregate(total=Sum("valor"))["total"] or ZERO
    )
    custos_variaveis_mes = (
        CustoVariavel.objects.filter(
            empresa=empresa, data_prevista__year=hoje.year, data_prevista__month=hoje.month
        ).aggregate(total=Sum("valor"))["total"]
        or ZERO
    )
    filiais_ativas = list(empresa.filiais.filter(ativo=True))
    saldo_disponivel = sum(
        (calcular_capacidade_compra(filial, hoje.year, hoje.month)["disponibilidade"] for filial in filiais_ativas),
        ZERO,
    )
    # Crítico funcional (rodada 1): o card se chamava "Fluxo — saldo
    # disponível" mas é a DISPONIBILIDADE do mês (receita − custos, antes das
    # compras) — não mudava quando se comprava e não batia com a DRE. Agora
    # o rótulo diz o que o número é, e o card mostra também o saldo DEPOIS
    # das compras aprovadas do mês: exatamente o resultado da DRE gerencial
    # (receita − compras aprovadas − custos variáveis − custos fixos).
    compras_aprovadas_mes = (
        Compra.objects.filter(
            filial__in=filiais_ativas,
            data_compra__year=hoje.year,
            data_compra__month=hoje.month,
            status__in=STATUS_REALIZADO,
        ).aggregate(total=Sum("valor"))["total"]
        or ZERO
    )
    compras_pendentes = Compra.objects.filter(empresa=empresa, status=Compra.Status.PENDENTE).count()
    # Antes da Sprint 6, esta chave era um duplicado literal de
    # `compras_pendentes` (mesma consulta, nome diferente) — o Dashboard do
    # Proprietário mostrava o mesmo número duas vezes e nunca surfaceava as
    # Provisões aguardando aprovação (Sprint 4). Corrigido para mostrar uma
    # informação nova de verdade (item 9 — eliminar excesso de informação).
    filiais_ids = empresa.filiais.values_list("pk", flat=True)
    provisoes_aguardando_aprovacao = contar_solicitacoes_pendentes(filiais_ids)

    # Épico 2A (Etapa 06): "Receita" no Dashboard Executivo. Desde a
    # mudança de escopo (lançamento 100% manual), a receita do mês é a
    # receita mensal (faturamento) + as receitas extras do mês — lida da
    # MESMA fonte do Motor (`finance_engine.services.obter_receita_do_mes`),
    # somando as filiais ATIVAS: o mesmo recorte da "disponibilidade"
    # acima e do resumo por filial, para os números fecharem entre si.
    from financeiro.services import receita_da_empresa_no_mes

    receita_mes = receita_da_empresa_no_mes(empresa, hoje.year, hoje.month)
    faturamento_mes = receita_mes["total"]
    # Etapa 02 (Cliente-Ready): "Disponibilidade do mês" (abaixo) é uma
    # capacidade CALCULADA, não um fato bruto como faturamento/custos — sem
    # nenhuma receita (mensal ou extra) cadastrada ainda em nenhuma filial,
    # o zero não é uma disponibilidade real, é ausência de dado.
    capacidade_configurada = receita_mes["configurada"]

    return {
        "fornecedores_total": Fornecedor.objects.filter(empresa=empresa, ativo=True).count(),
        "categorias_total": Categoria.objects.filter(empresa=empresa, ativo=True).count(),
        "compras_mes": compras_mes,
        "faturamento_mes": faturamento_mes,
        "receita_mensal_mes": receita_mes["receita_mensal"],
        "receitas_extras_mes": receita_mes["receitas_extras"],
        "custos_fixos_total": custos_fixos_total,
        "custos_variaveis_mes": custos_variaveis_mes,
        "saldo_disponivel": saldo_disponivel,
        "compras_aprovadas_mes": compras_aprovadas_mes,
        "saldo_apos_compras": saldo_disponivel - compras_aprovadas_mes,
        "capacidade_configurada": capacidade_configurada,
        "compras_pendentes": compras_pendentes,
        "provisoes_aguardando_aprovacao": provisoes_aguardando_aprovacao,
    }


def alertas_estrategicos(empresa, hoje: date, limite: int = 5) -> list:
    """Épico 2A (Etapa 06): Alertas Estratégicos do Dashboard Executivo —
    agregação dos alertas do Motor (`finance_engine.alertas.gerar_alertas`)
    de todas as filiais ativas da empresa. Nenhuma regra nova: só reúne e
    identifica a filial de cada alerta."""
    consolidados = []
    for filial in empresa.filiais.filter(ativo=True):
        for alerta in gerar_alertas(filial, hoje):
            # `gerar_alertas` devolve dataclasses `Alerta` — o consolidado
            # vira dict para carregar a filial junto.
            consolidados.append(
                {"nivel": alerta.nivel, "titulo": alerta.titulo, "mensagem": alerta.mensagem, "filial": filial}
            )
    criticos_primeiro = sorted(consolidados, key=lambda a: 0 if a["nivel"] == "critico" else 1)
    return criticos_primeiro[:limite]


def resolver_filial_para_relatorios(user):
    """Filial usada pelos relatórios (Timeline Financeira): a do próprio
    usuário, ou — para o Proprietário, que não tem filial fixa — a primeira
    filial ativa da empresa."""
    if user.filial_id:
        return user.filial
    if user.empresa_id:
        return user.empresa.filiais.filter(ativo=True).first()
    return None


def obter_resumo_filiais(empresa, hoje: date) -> list:
    """Resumo por filial (status hoje, comprado, capacidade), usado no
    Dashboard do Proprietário."""
    filiais_resumo = []
    for filial in empresa.filiais.filter(ativo=True):
        capacidade = calcular_capacidade_compra(filial, hoje.year, hoje.month)
        # Crítico funcional (rodada 1): o status de HOJE vem do day-walk do
        # Motor (o mesmo do Comprador/Gerente/calendários) — antes comparava
        # com o limite BASE do mês, e um sábado sem limite aparecia
        # "Disponível" aqui e "sem limite" no resto do sistema.
        posicao = motor_financeiro.posicao_do_dia(filial, hoje)
        filiais_resumo.append(
            {
                "filial": filial,
                "capacidade": capacidade,
                "comprado_hoje": posicao.comprado,
                # Críticos (rodada 2): o status "Excedido" é calculado contra o
                # limite de HOJE, então a tabela mostra esse limite (num sábado,
                # R$ 0) — antes mostrava o limite-base de dia útil ao lado de
                # "Excedido" com o comprado abaixo dele.
                "limite_hoje": posicao.limite_efetivo,
                "excedido_hoje": -posicao.saldo_do_dia if posicao.saldo_do_dia < ZERO else ZERO,
                "cor": posicao.cor,
                "sem_limite_hoje": posicao.sem_limite_proprio and posicao.comprado <= ZERO,
                "dia_sem_limite_proprio": posicao.sem_limite_proprio,
                "tipo_dia_hoje": rotulo_do_tipo(posicao.tipo_dia),
            }
        )
    return filiais_resumo


def _obter_meta_mensal(filial, hoje: date, dias_mes: list) -> dict:
    """Capacidade mensal ajustada ("meta") vs. o que já foi comprado no mês
    até hoje — novo indicador do Motor Financeiro (Sprint 5, item 4).
    Reaproveita `dias_mes` (já buscado por `obter_painel_comprador`) em vez
    de fazer uma nova consulta ao banco."""
    capacidade = motor_financeiro.capacidade_do_mes(filial, hoje.year, hoje.month)
    comprado_no_mes = sum((dia["comprado"] for dia in dias_mes if dia["data"] <= hoje), ZERO)
    return {
        "meta_mensal": capacidade.capacidade_mensal_ajustada,
        "comprado_no_mes": comprado_no_mes,
        "percentual_da_meta": calcular_percentual_utilizado(comprado_no_mes, capacidade.capacidade_mensal_ajustada),
    }


def obter_painel_comprador(usuario, hoje: Optional[date] = None) -> dict:
    """Monta o Dashboard do Comprador — o "Centro de Decisão" da Sprint 5.

    Ponto único que agrega tudo que a tela precisa, buscando o calendário do
    mês (`gestao_compras.obter_calendario_mensal`) UMA vez só e reaproveitando
    esse mesmo resultado para: o card de hoje, a previsão de amanhã, a
    tendência dos próximos dias e a prévia de 7 dias do calendário — em vez
    de uma consulta separada para cada um (item 11 — performance)."""
    filial = usuario.filial
    hoje = hoje or date.today()
    amanha = hoje + timedelta(days=1)

    resumo = obter_resumo_comprador(filial, hoje)
    dias_mes = obter_calendario_mensal(filial, hoje.year, hoje.month)

    dias_por_data = {dia["data"]: dia for dia in dias_mes}
    hoje_info = dias_por_data.get(hoje)
    amanha_info = dias_por_data.get(amanha)  # None se amanhã cair no mês seguinte

    compras_pendentes_qs = obter_compras_pendentes(filial)
    proximos_compromissos = obter_proximos_compromissos(filial, hoje, limite=5)
    compromissos_amanha = sum(1 for c in proximos_compromissos if c["data"] == amanha)

    # Altura da barra de tendência = % de capacidade que AINDA RESTA no dia
    # (saldo_disponivel / limite_efetivo) — reaproveita a mesma função de
    # proporção 0-100 usada para "% utilizado", só que com saldo em vez de
    # comprado. Desde a Sprint de Consolidação (Gate 2A, P0-2), limite
    # negativo faz a função devolver >100 (semáforo vermelho honesto) — o
    # `min(...)` aqui é só para a ALTURA da barra nunca estourar o
    # contêiner visual; a cor do dia (calculada à parte) continua vermelha.
    tendencia = [
        {
            **dia,
            "altura_pct": min(
                calcular_percentual_utilizado(dia["saldo_disponivel"], dia["limite_efetivo"]), Decimal("100")
            ),
        }
        for dia in dias_mes
        if dia["data"] > hoje
    ][:DIAS_TENDENCIA]

    contexto_decisao = ContextoDecisao(
        hoje=hoje,
        pode_comprar_hoje=resumo["pode_comprar_hoje"],
        cor_hoje=resumo["cor_hoje"],
        percentual_utilizado_hoje=resumo["percentual_utilizado"],
        saldo_disponivel_hoje=resumo["saldo_restante"],
        provisoes_aguardando_aprovacao=contar_solicitacoes_pendentes(usuario.filiais_visiveis()),
        compras_aguardando_aprovacao=compras_pendentes_qs.count(),
        cor_amanha=amanha_info["cor"] if amanha_info else None,
        compromissos_amanha=compromissos_amanha,
        fornecedor_acima_historico=obter_fornecedor_provisao_acima_do_historico(filial),
        provisoes_previstas_amanha=contar_provisoes_previstas_para(filial, amanha),
    )

    return {
        **resumo,
        "cabecalho": gerar_cabecalho(usuario, contexto_decisao, timezone.localtime().hour),
        "insights": central_de_decisao.gerar_insights(contexto_decisao),
        "provisoes_do_dia": hoje_info["quantidade_provisoes"] if hoje_info else 0,
        "valor_provisionado_hoje": hoje_info["provisionado"] if hoje_info else ZERO,
        "compras_aguardando_aprovacao": contexto_decisao.compras_aguardando_aprovacao,
        "compras_efetivadas_hoje": obter_compras_efetivadas_no_dia(filial, hoje),
        "proximos_compromissos": proximos_compromissos,
        "meta_mensal": _obter_meta_mensal(filial, hoje, dias_mes),
        "previsao_amanha": amanha_info,
        "tendencia_proximos_dias": tendencia,
        "calendario_preview": [d for d in dias_mes if d["data"] >= hoje][:DIAS_PREVIEW_CALENDARIO],
        "painel_lateral": {
            "ultimas_provisoes": obter_ultimas_provisoes(filial, limite=5),
            "ultimas_decisoes": obter_ultimas_decisoes(filial, limite=5),
            "compras_pendentes": compras_pendentes_qs[:5],
        },
    }


def obter_resultado_do_mes(usuario, filiais, hoje: Optional[date] = None, *, detalhar_valores: bool = True):
    """Widget "Resultado do mês" (Análise Financeira) dos dashboards do
    Proprietário, do Financeiro e do Gerente: receita total, despesas,
    resultado e margem do mês + mini-curva de 6 meses. Mesma fonte da DRE
    (Motor Financeiro). NUNCA monta nada para o Comprador (devolve None) —
    o viewmodel do Comprador nem chama esta função.

    Os três perfis recebem os valores em R$ (decisão explícita do usuário
    nas Correções de Produção: o Gerente VÊ os valores da análise). O
    modo `detalhar_valores=False` (só lucro/prejuízo, margem e curva da
    margem) continua disponível para um painel que não deva mostrar R$,
    mas nenhum dashboard o usa hoje."""
    from core.permissions import PERFIS_ANALISE_FINANCEIRA
    from financeiro.services_analise import resumo_resultado_do_mes

    if getattr(usuario, "perfil", None) not in PERFIS_ANALISE_FINANCEIRA:
        return None
    return resumo_resultado_do_mes(list(filiais), usuario, hoje, somente_percentuais=not detalhar_valores)
