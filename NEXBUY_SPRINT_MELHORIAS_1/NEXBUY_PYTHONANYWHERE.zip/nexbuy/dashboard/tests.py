"""Testes do app `dashboard` (Sprint 5 — Dashboard Inteligente).

Este app ainda não tinha nenhum teste automatizado. Cobre aqui, sobretudo,
o que a Sprint 5 introduziu: as regras da Central de Decisão
(`dashboard.insights`) e a agregação do Centro de Decisão do Comprador
(`dashboard.services.obter_painel_comprador`).

Rode com: python manage.py test dashboard
"""
from datetime import date
from decimal import Decimal

from django.test import Client, TestCase
from django.test.utils import override_settings

from cadastros.models import Categoria
from compras.models import Fornecedor
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, Receita
from gestao_compras.services import criar_provisao
from usuarios.models import Usuario

from .insights import (
    ContextoDecisao,
    central_de_decisao,
    gerar_cabecalho,
    saudacao_do_momento,
)
from .services import obter_painel_comprador
from core.utils_testes import garantir_capacidade_no_dia

ANO, MES = 2026, 6
DIAS_UTEIS_FIXO = 20


class SaudacaoDoMomentoTestCase(TestCase):
    def test_madrugada_e_manha_sao_bom_dia(self):
        self.assertEqual(saudacao_do_momento(0), "Bom dia")
        self.assertEqual(saudacao_do_momento(11), "Bom dia")

    def test_tarde_e_boa_tarde(self):
        self.assertEqual(saudacao_do_momento(12), "Boa tarde")
        self.assertEqual(saudacao_do_momento(17), "Boa tarde")

    def test_noite_e_boa_noite(self):
        self.assertEqual(saudacao_do_momento(18), "Boa noite")
        self.assertEqual(saudacao_do_momento(23), "Boa noite")


def _contexto(**overrides):
    base = dict(
        hoje=date(ANO, MES, 10),
        pode_comprar_hoje=True,
        cor_hoje="verde",
        percentual_utilizado_hoje=Decimal("10"),
        saldo_disponivel_hoje=Decimal("1000"),
        provisoes_aguardando_aprovacao=0,
        compras_aguardando_aprovacao=0,
        cor_amanha="verde",
        compromissos_amanha=0,
    )
    base.update(overrides)
    return ContextoDecisao(**base)


class CentralDeDecisaoTestCase(TestCase):
    """Cada cenário da especificação da Sprint 5 (item 5) como um teste
    isolado — a Central de Decisão é pura, não depende do banco."""

    def test_dia_tranquilo_gera_duas_mensagens_positivas(self):
        insights = central_de_decisao.gerar_insights(_contexto())
        niveis = [i.nivel for i in insights]
        self.assertEqual(niveis, ["ok", "ok"])

    def test_cor_laranja_gera_alerta_de_limite_baixo(self):
        insights = central_de_decisao.gerar_insights(
            _contexto(cor_hoje="laranja", percentual_utilizado_hoje=Decimal("85"))
        )
        self.assertEqual(insights[0].nivel, "atencao")
        self.assertIn("baixo", insights[0].mensagem)

    def test_cor_vermelha_gera_alerta_de_limite_esgotado(self):
        insights = central_de_decisao.gerar_insights(_contexto(cor_hoje="vermelho"))
        self.assertEqual(insights[0].nivel, "atencao")
        self.assertIn("esgotado", insights[0].mensagem)

    def test_uma_provisao_aguardando_aprovacao_usa_singular(self):
        insights = central_de_decisao.gerar_insights(_contexto(provisoes_aguardando_aprovacao=1))
        mensagens = [i.mensagem for i in insights]
        self.assertIn("Existe 1 provisão aguardando aprovação.", mensagens)

    def test_duas_provisoes_aguardando_aprovacao_usa_plural(self):
        insights = central_de_decisao.gerar_insights(_contexto(provisoes_aguardando_aprovacao=2))
        mensagens = [i.mensagem for i in insights]
        self.assertIn("Existem 2 provisões aguardando aprovação.", mensagens)

    def test_compras_aguardando_aprovacao_gera_alerta(self):
        insights = central_de_decisao.gerar_insights(_contexto(compras_aguardando_aprovacao=3))
        mensagens = [i.mensagem for i in insights]
        self.assertIn("Existem 3 compras aguardando aprovação do Gerente.", mensagens)

    def test_muitos_compromissos_amanha_gera_alerta(self):
        insights = central_de_decisao.gerar_insights(_contexto(compromissos_amanha=2))
        mensagens = [i.mensagem for i in insights]
        self.assertIn("Amanhã existem muitos compromissos financeiros.", mensagens)

    def test_saldo_confortavel_so_aparece_com_pouco_uso(self):
        # 60% utilizado ainda é "verde" (< 80%), mas não é mais "confortável" (< 50%)
        insights = central_de_decisao.gerar_insights(
            _contexto(cor_hoje="verde", percentual_utilizado_hoje=Decimal("60"))
        )
        mensagens = [i.mensagem for i in insights]
        self.assertNotIn("O saldo disponível está confortável.", mensagens)


class GerarCabecalhoTestCase(TestCase):
    def test_cabecalho_menciona_provisoes_quando_existem(self):
        usuario = Usuario(username="teste", first_name="Ana")
        cabecalho = gerar_cabecalho(usuario, _contexto(provisoes_aguardando_aprovacao=1), hora=9)
        self.assertEqual(cabecalho["nome"], "Ana")
        self.assertEqual(cabecalho["saudacao"], "Bom dia")
        self.assertTrue(any("provisão" in linha for linha in cabecalho["linhas"]))

    def test_cabecalho_sem_pendencias_descreve_situacao_do_limite(self):
        usuario = Usuario(username="teste", first_name="Ana")
        cabecalho = gerar_cabecalho(usuario, _contexto(cor_hoje="vermelho"), hora=20)
        self.assertTrue(any("já foi atingido" in linha for linha in cabecalho["linhas"]))


class PainelCompradorTestCase(TestCase):
    """Integração: `obter_painel_comprador` monta o Centro de Decisão a
    partir de dados reais do banco (Motor Financeiro + Gestão de Compras)."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Dashboard", cnpj="55.000.000/0001-55")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 2500
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Teste")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Teste")
        self.comprador = Usuario.objects.create_user(
            username="comprador_dash", password="x", perfil=Usuario.Perfil.COMPRADOR,
            first_name="Diego", empresa=self.empresa, filial=self.filial,
        )

    def test_painel_sem_provisoes_fica_tranquilo(self):
        painel = obter_painel_comprador(self.comprador, hoje=date(ANO, MES, 10))
        self.assertEqual(painel["provisoes_do_dia"], 0)
        self.assertEqual(painel["valor_provisionado_hoje"], Decimal("0"))
        self.assertEqual([i.nivel for i in painel["insights"]], ["ok", "ok"])
        self.assertEqual(len(painel["calendario_preview"]), 7)
        self.assertEqual(len(painel["tendencia_proximos_dias"]), 5)

    def test_painel_com_provisao_acima_do_limite_alerta_aprovacao(self):
        criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date(ANO, MES, 10), observacoes="", itens_dados=[
                {"produto": "Item", "quantidade": 1, "valor_unitario": 4000}
            ],
        )
        painel = obter_painel_comprador(self.comprador, hoje=date(ANO, MES, 10))
        self.assertEqual(painel["provisoes_do_dia"], 1)
        self.assertEqual(painel["valor_provisionado_hoje"], Decimal("4000"))
        self.assertEqual(painel["compras_aguardando_aprovacao"], 0)
        niveis_e_mensagens = [(i.nivel, i.mensagem) for i in painel["insights"]]
        self.assertIn(("atencao", "Existe 1 provisão aguardando aprovação."), niveis_e_mensagens)


class DashboardCompradorViewTestCase(TestCase):
    """Fumaça: a tela renderiza sem erro e usa a nova nomenclatura da
    Sprint 5 (CTA "Nova Provisão" em vez de "Lançar Compra")."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste View", cnpj="66.000.000/0001-66")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, dias_uteis_manual=DIAS_UTEIS_FIXO)
        self.comprador = Usuario.objects.create_user(
            username="comprador_view", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_dashboard_comprador_renderiza_com_nova_provisao(self):
        client = Client()
        client.force_login(self.comprador)
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        conteudo = response.content.decode()
        self.assertIn("Nova Provisão", conteudo)
        self.assertIn("Central de Decisão", conteudo)


class DashboardFinanceiroCorSemanticaTestCase(TestCase):
    """Visual QA & Demo Polish: o card "Capacidade de hoje" do Dashboard
    Financeiro aparecia sempre verde, mesmo com capacidade negativa (custos
    do mês maiores que o faturamento) — bug real encontrado numa
    demonstração. Reproduz o cenário fim a fim (Receita pequena + Custo
    Fixo grande no mês corrente) e confere que o card renderiza vermelho,
    nunca verde. Não altera nenhum cálculo — só a cor exibida."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Capacidade Negativa", cnpj="88.000.000/0001-88")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(empresa=self.empresa, dias_uteis_manual=DIAS_UTEIS_FIXO)
        mes_atual = date.today().replace(day=1)
        Receita.objects.create(filial=self.filial, mes=mes_atual, faturamento=Decimal("1000.00"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(self.empresa)
        from financeiro.models import CustoFixo

        CustoFixo.objects.create(
            filial=self.filial, descricao="Aluguel", valor=Decimal("50000.00"), dia_vencimento=5,
        )
        self.financeiro = Usuario.objects.create_user(
            username="financeiro_cor_view", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_capacidade_negativa_renderiza_card_vermelho_nunca_verde(self):
        client = Client()
        client.force_login(self.financeiro)
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["cor_capacidade_hoje"], "vermelho")
        self.assertLess(response.context["capacidade"]["limite_diario"], Decimal("0"))
        conteudo = response.content.decode()
        capacidade_card = conteudo[conteudo.index("Capacidade de hoje") - 200 : conteudo.index("Capacidade de hoje") + 50]
        self.assertIn("nx-kpi-tint-red", capacidade_card)
        self.assertNotIn("nx-kpi-tint-green", capacidade_card)


class CompradorBloqueadoNaCentralDeDecisaoTestCase(TestCase):
    """Simulação da demo publicada: a Carla (bloqueada pelo Financeiro) via
    "Bloqueado" no destaque e, na mesma tela, "Hoje você pode comprar
    normalmente." / "O saldo disponível está confortável." — as duas regras
    ignoravam `ContextoDecisao.bloqueado` (só o cabeçalho o usava)."""

    POSITIVAS = (
        "Hoje você pode comprar normalmente.",
        "O saldo disponível está confortável.",
    )

    def test_bloqueado_nunca_gera_mensagem_de_compra_liberada(self):
        from .insights import MENSAGEM_BLOQUEADO

        for extras in (
            {},
            {"capacidade_configurada": False},
            {"hoje_sem_limite_proprio": True, "rotulo_dia_hoje": "sábado"},
            {"cor_hoje": "laranja", "percentual_utilizado_hoje": Decimal("85")},
        ):
            with self.subTest(extras=extras):
                insights = central_de_decisao.gerar_insights(
                    _contexto(bloqueado=True, pode_comprar_hoje=False, saldo_disponivel_hoje=Decimal("0"), **extras)
                )
                mensagens = [i.mensagem for i in insights]
                for positiva in self.POSITIVAS:
                    self.assertNotIn(positiva, mensagens)
                self.assertEqual(mensagens[0], MENSAGEM_BLOQUEADO)
                self.assertEqual(insights[0].nivel, "atencao")

    def test_sem_bloqueio_continua_igual(self):
        mensagens = [i.mensagem for i in central_de_decisao.gerar_insights(_contexto())]
        self.assertEqual(list(self.POSITIVAS), mensagens)

    def test_cabecalho_do_bloqueado_nao_diz_limite_saudavel(self):
        usuario = Usuario(username="carla", first_name="Carla")
        cabecalho = gerar_cabecalho(usuario, _contexto(bloqueado=True, cor_hoje="verde"), hora=10)
        self.assertTrue(any("suspensas" in linha for linha in cabecalho["linhas"]))
        self.assertFalse(any("saudável" in linha for linha in cabecalho["linhas"]))
