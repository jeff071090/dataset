# NEXBUY — Mapa de Capacidades (o que é demonstrável HOJE × o que é futuro)

Regra de ouro da apresentação: **tudo na coluna "Disponível agora" roda ao
vivo nesta demo; o DDA é a única evolução prevista e DEVE ser apresentado
como tal** (a tela de Integrações diz "Não conectado — integração prevista").

Escopo atual, em uma frase: o NEXBUY é **100% web**; **receitas, custos e
compras são lançados manualmente** e alimentam a projeção de compra e os
limites dos compradores; o **DDA é integração futura prevista (não
conectada)**.

## 1. Disponível e funcional AGORA (demonstrável ao vivo)

| Capacidade | Perfil que demonstra | Onde (menu/tela) |
|---|---|---|
| Dashboard executivo consolidado do grupo | Proprietário | Início |
| Contexto multiempresa (troca de CNPJ ativo) | Proprietário | Seletor no topo |
| Matriz + filiais com cadastro fiscal completo | Proprietário | Gestão → Empresas e Filiais |
| Usuários com 4 perfis + permissões extras (RBAC aditivo) | Proprietário | Configurações → Usuários e Permissões |
| Lançamento manual de receita mensal, receitas extras, custos fixos e custos variáveis | Financeiro | Financeiro → Planejamento |
| Motor financeiro: capacidade mensal → limite diário (alimentado pelos lançamentos manuais) | Financeiro | Início · Planejamento |
| Análise Financeira: DRE gerencial, créditos × débitos (balancete do mês) e saúde financeira com semáforo, referências de mercado e recomendações em reais; curvas de 12 meses | Proprietário, Gerente (a própria loja, em R$) e Financeiro | Menu Análise Financeira (Proprietário: Financeiro → Análise Financeira) — Cena 6 do roteiro |
| Limites individuais por comprador + bloqueio na origem | Financeiro | Compradores e Limites |
| Compra × Provisão (registro × planejamento) | Comprador | Início · Nova Compra · Nova Provisão |
| Aprovação automática dentro do limite do dia | Comprador | Nova Provisão (valor pequeno) |
| Fluxo de aprovação multi-etapa com alçadas (Gerente→Financeiro) | Gerente + Financeiro | Aprovações |
| Autoaprovação controlada (com justificativa obrigatória) | Proprietário | Configurações Gerais |
| Calendário de Compras (verde/laranja/vermelho + dias bloqueados) | Comprador | Planejamento de Compras |
| Calendário Financeiro + Agenda de 30 dias | Financeiro | Início · Calendário Financeiro |
| Contas a Pagar segmentado por origem (parcelas/custos/provisões) | Financeiro | Planejamento → Contas a Pagar |
| Compras parceladas (30/60/90 e personalizado) com baixa/estorno manual | Financeiro | Agenda Financeira |
| Simulador de compra ("cabe ou não cabe?") | Comprador | Simulador |
| Relatórios por filial com impressão e CSV | Proprietário | Relatórios |
| Central de Auditoria (quem, quando, o quê, antes/depois) | Proprietário | Configurações → Central de Auditoria |
| Notificações internas (sino) | Todos | Topo |
| Tour guiado por perfil + troca de perfil de demonstração | Todos | Ajuda · Menu de conta (só na demo) |
| Navegação por perfil, breadcrumbs e barra mobile | Todos | Toda a interface |
| Isolamento por empresa/filial (dados nunca vazam entre CNPJs) | — | Comprovado por suíte de testes |
| Comprador sem acesso a dados financeiros sensíveis (visão sintética) | Comprador | Comprovado por suíte de testes |

## 2. Integração futura prevista — **DDA** (não conectada)

| Capacidade futura | Situação hoje |
|---|---|
| Trazer para a Agenda/Contas a Pagar os boletos/títulos apresentados ao CNPJ | Tela Integrações: **"Não conectado — integração prevista"**. Só existe o contrato abstrato no código (`finance_engine/interfaces.py`); nenhuma conexão existe. Hoje os boletos são lançados manualmente. |
| Sugerir o vínculo do título com a compra/provisão correspondente | Idem — hoje a baixa e o estorno de parcela são manuais (e auditados). Mesmo quando conectado, o DDA **nunca paga nada sozinho** nem cria custo/baixa automaticamente: toda confirmação é do Financeiro. |

## Fora do escopo do produto (não prometer)

Por decisão da cliente, **não haverá integração com ERP** — receitas,
custos e compras continuam sendo lançados manualmente. Também não fazem
parte do produto: controle de estoque e cadastro de produtos · conexão
bancária automática · recomendação automatizada de compra · emissão fiscal
· app nativo · pagamento dentro do sistema. Se o cliente pedir, anote como
requisito de roadmap — não improvise promessa na reunião.
