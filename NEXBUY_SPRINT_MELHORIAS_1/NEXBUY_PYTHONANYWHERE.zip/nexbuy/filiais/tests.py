"""Testes do app `filiais` (Fechamento Final — Prompt 1, Seção 4.4/4.5:
Filial vira Estabelecimento fiscal completo).

Rode com: python manage.py test filiais
"""
from datetime import date
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase

from empresas.models import Empresa
from financeiro.models import ReceitaExtra
from usuarios.models import Usuario, UsuarioFilial

from .forms import FilialForm, filial_possui_movimentacao
from .models import Filial


class FilialCadastroCompletoTestCase(TestCase):
    """`Filial.cadastro_completo` só é usada pela UI (badge) — nunca
    bloqueia nada — mas precisa refletir de verdade o que falta.

    Gate pré-Etapa 10 (S1-1): passou a exigir também razão social e um
    responsável identificado — testes atualizados para incluir esses
    campos nos casos "completos" e cobrir os novos casos de ausência."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Cadastro Completo", cnpj="50.000.000/0001-50")

    def test_filial_recem_criada_so_com_nome_e_incompleta(self):
        filial = Filial.objects.create(empresa=self.empresa, nome="Filial Nova")
        self.assertFalse(filial.cadastro_completo)

    def test_filial_com_todos_os_dados_fiscais_e_completa(self):
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Completa", cnpj="11222333000181",
            razao_social="Filial Completa Comércio Ltda",
            inscricao_estadual="123456789", endereco="Rua X", numero="100", bairro="Centro",
            cidade="Cuiabá", estado="MT", cep="78000-000", telefone="(65) 3333-0000",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertTrue(filial.cadastro_completo)

    def test_isento_de_ie_conta_como_resolvido(self):
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Isenta", cnpj="11222333000181",
            razao_social="Filial Isenta Comércio Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", numero="100", bairro="Centro",
            cidade="Cuiabá", estado="MT", cep="78000-000", telefone="(65) 3333-0000",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertTrue(filial.cadastro_completo)

    def test_faltando_apenas_cep_ainda_e_incompleta(self):
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Sem Cep", cnpj="11222333000181",
            razao_social="Filial Sem Cep Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", numero="100", cidade="Cuiabá", estado="MT",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertFalse(filial.cadastro_completo)

    def test_faltando_razao_social_ainda_e_incompleta(self):
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Sem Razao", cnpj="11222333000181",
            isento_inscricao_estadual=True, endereco="Rua X", numero="100",
            cidade="Cuiabá", estado="MT", cep="78000-000",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertFalse(filial.cadastro_completo)

    def test_faltando_telefone_ainda_e_incompleta(self):
        """Prompt 2, Gate A/C (Seção 6): a auditoria encontrou uma Filial
        ativa ("Loja Norte") sem telefone considerada "completa" por
        engano — telefone da Filial (distinto do telefone do responsável)
        agora é exigido."""
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Sem Telefone", cnpj="11222333000181",
            razao_social="Filial Sem Telefone Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", numero="100", bairro="Centro",
            cidade="Cuiabá", estado="MT", cep="78000-000",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertFalse(filial.cadastro_completo)

    def test_faltando_numero_ou_bairro_ainda_e_incompleta(self):
        """`endereco` livre preenchido não bastava — `numero`/`bairro` têm
        campos próprios no model e agora são checados isoladamente."""
        sem_numero = Filial.objects.create(
            empresa=self.empresa, nome="Filial Sem Numero", cnpj="11222333000181",
            razao_social="Filial Sem Numero Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", bairro="Centro",
            cidade="Cuiabá", estado="MT", cep="78000-000", telefone="(65) 3333-0000",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertFalse(sem_numero.cadastro_completo)

        sem_bairro = Filial.objects.create(
            empresa=self.empresa, nome="Filial Sem Bairro", cnpj="22333444000162",
            razao_social="Filial Sem Bairro Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", numero="100",
            cidade="Cuiabá", estado="MT", cep="78000-000", telefone="(65) 3333-0000",
            responsavel_nome="Maria Souza", responsavel_telefone="(65) 99999-0000",
        )
        self.assertFalse(sem_bairro.cadastro_completo)

    def test_faltando_responsavel_ainda_e_incompleta(self):
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Sem Responsavel", cnpj="11222333000181",
            razao_social="Filial Sem Responsavel Ltda",
            isento_inscricao_estadual=True, endereco="Rua X", numero="100",
            cidade="Cuiabá", estado="MT", cep="78000-000",
        )
        self.assertFalse(filial.cadastro_completo)

    def test_responsavel_nome_sem_nenhum_contato_nao_conta_como_identificado(self):
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Responsavel Sem Contato", cnpj="11222333000181",
            razao_social="Filial Ltda", isento_inscricao_estadual=True, endereco="Rua X", numero="100",
            cidade="Cuiabá", estado="MT", cep="78000-000", responsavel_nome="Maria Souza",
        )
        self.assertFalse(filial.cadastro_completo)

    def test_responsavel_usuario_sozinho_ja_conta_como_identificado(self):
        usuario = Usuario.objects.create_user(
            username="resp.cadastro", password="senha-forte-123", empresa=self.empresa,
        )
        filial = Filial.objects.create(
            empresa=self.empresa, nome="Filial Resp Usuario", cnpj="11222333000181",
            razao_social="Filial Ltda", isento_inscricao_estadual=True, endereco="Rua X", numero="100",
            bairro="Centro", cidade="Cuiabá", estado="MT", cep="78000-000", telefone="(65) 3333-1000",
            responsavel_usuario=usuario,
        )
        self.assertTrue(filial.cadastro_completo)


class FilialIntegridadeBancoTestCase(TestCase):
    """Fechamento Final (Seção 4.5): as regras de unicidade valem no
    BANCO, não só no form — mesmo criando direto via `.objects.create`
    (contornando qualquer validação de formulário), a constraint barra."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Integridade Filial", cnpj="51.000.000/0001-51")
        self.empresa_b = Empresa.objects.create(nome="Empresa B Integridade Filial", cnpj="52.000.000/0001-52")

    def test_nome_duplicado_na_mesma_empresa_e_rejeitado_pelo_banco(self):
        Filial.objects.create(empresa=self.empresa, nome="Matriz")
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Filial.objects.create(empresa=self.empresa, nome="Matriz")

    def test_mesmo_nome_em_empresas_diferentes_e_permitido(self):
        Filial.objects.create(empresa=self.empresa, nome="Centro")
        Filial.objects.create(empresa=self.empresa_b, nome="Centro")  # não levanta

    def test_cnpj_duplicado_globalmente_e_rejeitado(self):
        Filial.objects.create(empresa=self.empresa, nome="F1", cnpj="11222333000181")
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Filial.objects.create(empresa=self.empresa_b, nome="F2", cnpj="11222333000181")

    def test_varias_filiais_sem_cnpj_e_permitido(self):
        Filial.objects.create(empresa=self.empresa, nome="F1")
        Filial.objects.create(empresa=self.empresa, nome="F2")  # ambas cnpj=None, não colide

    def test_codigo_interno_duplicado_na_mesma_empresa_e_rejeitado(self):
        Filial.objects.create(empresa=self.empresa, nome="F1", codigo_interno="001")
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Filial.objects.create(empresa=self.empresa, nome="F2", codigo_interno="001")

    def test_mesmo_codigo_interno_em_empresas_diferentes_e_permitido(self):
        Filial.objects.create(empresa=self.empresa, nome="F1", codigo_interno="001")
        Filial.objects.create(empresa=self.empresa_b, nome="F1", codigo_interno="001")  # não levanta

    def test_varias_filiais_sem_codigo_interno_e_permitido(self):
        Filial.objects.create(empresa=self.empresa, nome="F1")
        Filial.objects.create(empresa=self.empresa, nome="F2")  # ambas codigo_interno=None

    def test_segunda_matriz_na_mesma_empresa_e_rejeitada_pelo_banco(self):
        Filial.objects.create(
            empresa=self.empresa, nome="F1", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Filial.objects.create(
                    empresa=self.empresa, nome="F2", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
                )

    def test_matriz_em_empresas_diferentes_e_permitido(self):
        Filial.objects.create(empresa=self.empresa, nome="F1", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ)
        Filial.objects.create(
            empresa=self.empresa_b, nome="F1", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ
        )  # não levanta

    def test_cnpj_invalido_e_rejeitado_pelo_full_clean(self):
        filial = Filial(empresa=self.empresa, nome="F Invalida", cnpj="11.111.111/1111-11")
        with self.assertRaises(ValidationError):
            filial.full_clean()

    def test_nome_com_diferenca_de_caixa_e_espaco_e_rejeitado_pelo_banco(self):
        """Gate pré-Etapa 10 (S1-1): a unicidade de nome não resistia a
        diferenças de caixa/espaço — a constraint agora usa
        `nome_normalizado`, então "Loja  Centro" colide com "loja centro"."""
        Filial.objects.create(empresa=self.empresa, nome="Loja Centro")
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                Filial.objects.create(empresa=self.empresa, nome="  loja   CENTRO  ")

    def test_nome_normalizado_e_preenchido_automaticamente_no_save(self):
        filial = Filial.objects.create(empresa=self.empresa, nome="  Loja   Norte  ")
        filial.refresh_from_db()
        self.assertEqual(filial.nome_normalizado, "loja norte")


class FilialResponsavelUsuarioTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-1): `responsavel_usuario` precisa ser um
    usuário de verdade — ativo, da mesma Empresa e autorizado na Filial
    (quando a Filial já existe) — validado em `Filial.clean()`."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Resp Filial", cnpj="54.000.000/0001-54")
        self.empresa_b = Empresa.objects.create(nome="Empresa B Resp Filial", cnpj="55.000.000/0001-55")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Filial Resp")

    def test_responsavel_inativo_e_rejeitado(self):
        usuario = Usuario.objects.create_user(
            username="resp.inativo", password="senha-forte-123", empresa=self.empresa, is_active=False,
        )
        self.filial.responsavel_usuario = usuario
        with self.assertRaises(ValidationError):
            self.filial.full_clean()

    def test_responsavel_de_outra_empresa_e_rejeitado(self):
        usuario = Usuario.objects.create_user(
            username="resp.outraempresa", password="senha-forte-123", empresa=self.empresa_b,
        )
        self.filial.responsavel_usuario = usuario
        with self.assertRaises(ValidationError):
            self.filial.full_clean()

    def test_responsavel_nao_autorizado_na_filial_e_rejeitado(self):
        usuario = Usuario.objects.create_user(
            username="resp.naoautorizado", password="senha-forte-123", empresa=self.empresa,
            perfil=Usuario.Perfil.COMPRADOR,
        )
        outra_filial = Filial.objects.create(empresa=self.empresa, nome="Outra Filial")
        UsuarioFilial.objects.create(usuario=usuario, filial=outra_filial, ativo=True)
        self.filial.responsavel_usuario = usuario
        with self.assertRaises(ValidationError):
            self.filial.full_clean()

    def test_responsavel_autorizado_e_aceito(self):
        usuario = Usuario.objects.create_user(
            username="resp.autorizado", password="senha-forte-123", empresa=self.empresa,
            perfil=Usuario.Perfil.COMPRADOR,
        )
        UsuarioFilial.objects.create(usuario=usuario, filial=self.filial, ativo=True)
        self.filial.responsavel_usuario = usuario
        self.filial.full_clean()  # não levanta

    def test_save_concede_usuariofilial_automaticamente_ao_responsavel(self):
        """Prompt 2, Gate C (Seção 6): quem é designado responsável por
        uma Filial precisa estar autorizado a ela — senão a própria pessoa
        não enxergaria a Filial que gerencia. `save()` concede o vínculo
        automaticamente no caminho feliz (cadastro/edição pela tela)."""
        usuario = Usuario.objects.create_user(
            username="resp.autoconcede", password="senha-forte-123", empresa=self.empresa,
            perfil=Usuario.Perfil.COMPRADOR,
        )
        self.assertFalse(UsuarioFilial.objects.filter(usuario=usuario, filial=self.filial).exists())
        self.filial.responsavel_usuario = usuario
        self.filial.save()
        vinculo = UsuarioFilial.objects.get(usuario=usuario, filial=self.filial)
        self.assertTrue(vinculo.ativo)

    def test_save_nao_cria_vinculo_redundante_para_proprietario_responsavel(self):
        """Proprietário já é autorizado a todas as Filiais ativas da
        Empresa por regra própria — não precisa (nem deve) ganhar um
        `UsuarioFilial` avulso quando é o responsável."""
        usuario = Usuario.objects.create_user(
            username="resp.propria.autoconcede", password="senha-forte-123", empresa=self.empresa,
            perfil=Usuario.Perfil.PROPRIETARIO,
        )
        self.filial.responsavel_usuario = usuario
        self.filial.save()
        self.assertFalse(UsuarioFilial.objects.filter(usuario=usuario, filial=self.filial).exists())

    def test_proprietario_como_responsavel_e_aceito_sem_vinculo_explicito(self):
        """Proprietário tem acesso a todas as filiais ativas da empresa
        (`filiais_autorizadas_para`) mesmo sem `UsuarioFilial` — então pode
        ser responsável de qualquer Filial da própria empresa."""
        usuario = Usuario.objects.create_user(
            username="resp.proprietario", password="senha-forte-123", empresa=self.empresa,
            perfil=Usuario.Perfil.PROPRIETARIO,
        )
        self.filial.responsavel_usuario = usuario
        self.filial.full_clean()  # não levanta

    def test_filial_nova_ainda_sem_pk_nao_exige_autorizacao_previa(self):
        """Uma Filial ainda não salva não tem histórico de `UsuarioFilial`
        possível — a checagem de autorização só se aplica a edições."""
        usuario = Usuario.objects.create_user(
            username="resp.filialnova", password="senha-forte-123", empresa=self.empresa,
            perfil=Usuario.Perfil.COMPRADOR,
        )
        filial_nova = Filial(empresa=self.empresa, nome="Filial Recém-Criada", responsavel_usuario=usuario)
        filial_nova.full_clean()  # não levanta


class FilialFormTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Form Filial", cnpj="53.000.000/0001-53")

    def _dados_minimos(self, **overrides):
        base = {"nome": "Filial Form"}
        base.update(overrides)
        return base

    def test_form_valido_so_com_nome(self):
        form = FilialForm(data=self._dados_minimos(), empresa=self.empresa)
        self.assertTrue(form.is_valid(), form.errors)

    def test_cnpj_com_mascara_e_normalizado_para_so_digitos(self):
        form = FilialForm(data=self._dados_minimos(cnpj="11.222.333/0001-81"), empresa=self.empresa)
        self.assertTrue(form.is_valid(), form.errors)
        filial = form.save()
        self.assertEqual(filial.cnpj, "11222333000181")

    def test_cnpj_invalido_e_rejeitado(self):
        form = FilialForm(data=self._dados_minimos(cnpj="11.111.111/1111-11"), empresa=self.empresa)
        self.assertFalse(form.is_valid())
        self.assertIn("cnpj", form.errors)

    def test_isento_e_inscricao_estadual_juntos_e_erro(self):
        form = FilialForm(
            data=self._dados_minimos(isento_inscricao_estadual=True, inscricao_estadual="123456789"),
            empresa=self.empresa,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("inscricao_estadual", form.errors)

    def test_segunda_matriz_e_rejeitada_pelo_form(self):
        Filial.objects.create(empresa=self.empresa, nome="Já Matriz", tipo_estabelecimento="matriz")
        form = FilialForm(
            data=self._dados_minimos(nome="Nova Matriz", tipo_estabelecimento="matriz"), empresa=self.empresa,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("tipo_estabelecimento", form.errors)

    def test_editar_a_propria_matriz_nao_dispara_o_erro_de_matriz_duplicada(self):
        matriz = Filial.objects.create(empresa=self.empresa, nome="Matriz Única", tipo_estabelecimento="matriz")
        form = FilialForm(
            data=self._dados_minimos(nome="Matriz Única", tipo_estabelecimento="matriz"),
            instance=matriz, empresa=self.empresa,
        )
        self.assertTrue(form.is_valid(), form.errors)

    def test_queryset_de_responsavel_usuario_so_traz_ativos_da_mesma_empresa(self):
        """Gate pré-Etapa 10 (S1-1): o form restringe as OPÇÕES exibidas
        (usuário ativo desta Empresa) — a validação de autorização na
        Filial em si é uma segunda camada em `Filial.clean()`."""
        outra_empresa = Empresa.objects.create(nome="Empresa Form Filial B", cnpj="56.000.000/0001-56")
        ativo_desta_empresa = Usuario.objects.create_user(
            username="resp.form.ativo", password="senha-forte-123", empresa=self.empresa,
        )
        inativo_desta_empresa = Usuario.objects.create_user(
            username="resp.form.inativo", password="senha-forte-123", empresa=self.empresa, is_active=False,
        )
        de_outra_empresa = Usuario.objects.create_user(
            username="resp.form.outraempresa", password="senha-forte-123", empresa=outra_empresa,
        )
        form = FilialForm(data=self._dados_minimos(), empresa=self.empresa)
        queryset = form.fields["responsavel_usuario"].queryset
        self.assertIn(ativo_desta_empresa, queryset)
        self.assertNotIn(inativo_desta_empresa, queryset)
        self.assertNotIn(de_outra_empresa, queryset)

    def test_form_sem_empresa_tem_queryset_de_responsavel_vazio(self):
        form = FilialForm(data=self._dados_minimos(), empresa=None)
        self.assertEqual(form.fields["responsavel_usuario"].queryset.count(), 0)

    def test_form_aceita_responsavel_usuario_valido_e_salva(self):
        usuario = Usuario.objects.create_user(
            username="resp.form.valido", password="senha-forte-123", empresa=self.empresa,
        )
        form = FilialForm(
            data=self._dados_minimos(razao_social="Filial Form Ltda", responsavel_usuario=usuario.pk),
            empresa=self.empresa,
        )
        self.assertTrue(form.is_valid(), form.errors)
        filial = form.save()
        self.assertEqual(filial.responsavel_usuario_id, usuario.pk)


class FilialIsolamentoMultiempresaTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-1): os novos campos de responsável precisam
    respeitar o isolamento entre Empresas — mesmo contornando o form."""

    def setUp(self):
        self.empresa_a = Empresa.objects.create(nome="Empresa Isolamento A", cnpj="57.000.000/0001-57")
        self.empresa_b = Empresa.objects.create(nome="Empresa Isolamento B", cnpj="58.000.000/0001-58")

    def test_responsavel_de_empresa_b_nao_pode_ser_salvo_direto_em_filial_de_empresa_a(self):
        usuario_b = Usuario.objects.create_user(
            username="resp.isolamento.b", password="senha-forte-123", empresa=self.empresa_b,
        )
        filial_a = Filial(empresa=self.empresa_a, nome="Filial A", responsavel_usuario=usuario_b)
        with self.assertRaises(ValidationError):
            filial_a.full_clean()

    def test_nome_normalizado_e_isolado_por_empresa_mesmo_com_mesmo_nome(self):
        Filial.objects.create(empresa=self.empresa_a, nome="Loja Principal")
        Filial.objects.create(empresa=self.empresa_b, nome="loja   PRINCIPAL")  # não levanta — empresas diferentes


class FilialPossuiMovimentacaoTestCase(TestCase):
    """Correções de Produção: `filial_possui_movimentacao` bloqueia a
    exclusão de toda Filial que tenha registro ligado por CASCADE — antes
    uma filial só com receitas extras era excluída e o CASCADE apagava as
    receitas junto."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Movimentação", cnpj="59.000.000/0001-59")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Filial Movimentação")

    def test_filial_vazia_pode_ser_excluida(self):
        self.assertFalse(filial_possui_movimentacao(self.filial))

    def test_so_receita_extra_bloqueia(self):
        ReceitaExtra.objects.create(
            filial=self.filial, data=date.today(), descricao="Convênio", valor=Decimal("10.00"),
            categoria=ReceitaExtra.Categoria.CONVENIOS,
        )
        self.assertTrue(filial_possui_movimentacao(self.filial))

    def test_so_vinculo_de_usuario_bloqueia(self):
        usuario = Usuario.objects.create_user(username="vinc.mov", password="senha-forte-123", empresa=self.empresa)
        UsuarioFilial.objects.create(usuario=usuario, filial=self.filial)
        self.assertTrue(filial_possui_movimentacao(self.filial))
