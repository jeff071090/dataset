# Gate pré-Etapa 10 (S1-1): cadastro de Filial completo — razão social,
# responsável ligado a um Usuario de verdade (com telefone/e-mail próprios)
# e unicidade de nome robusta a diferença de caixa/espaço.
#
# `nome_normalizado` é preenchido por um RunPython ANTES da constraint de
# unicidade ser criada — sem isso, várias Filiais existentes com
# `nome_normalizado=""` (valor default do AddField) colidiriam entre si na
# hora de criar a constraint, e a migration falharia no meio de uma base
# real.
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


def preencher_nome_normalizado(apps, schema_editor):
    Filial = apps.get_model("filiais", "Filial")
    for filial in Filial.objects.all().iterator():
        normalizado = " ".join((filial.nome or "").split()).casefold()
        if filial.nome_normalizado != normalizado:
            Filial.objects.filter(pk=filial.pk).update(nome_normalizado=normalizado)


def reverter_noop(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('empresas', '0005_alter_empresa_cnpj'),
        ('filiais', '0002_filial_vira_estabelecimento_fiscal_completo'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.RemoveConstraint(
            model_name='filial',
            name='filial_nome_unico_por_empresa',
        ),
        migrations.AddField(
            model_name='filial',
            name='nome_normalizado',
            field=models.CharField(blank=True, default='', editable=False, max_length=150),
        ),
        migrations.AddField(
            model_name='filial',
            name='razao_social',
            field=models.CharField(blank=True, help_text='Nome legal do estabelecimento — opcional quando igual ao da Empresa.', max_length=200, verbose_name='Razão Social'),
        ),
        migrations.AddField(
            model_name='filial',
            name='responsavel_email',
            field=models.EmailField(blank=True, max_length=254, verbose_name='E-mail do responsável'),
        ),
        migrations.AddField(
            model_name='filial',
            name='responsavel_telefone',
            field=models.CharField(blank=True, max_length=20, verbose_name='Telefone do responsável'),
        ),
        migrations.AddField(
            model_name='filial',
            name='responsavel_usuario',
            field=models.ForeignKey(blank=True, help_text='Precisa ser um usuário ativo desta Empresa e autorizado nesta Filial.', null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='filiais_sob_responsabilidade', to=settings.AUTH_USER_MODEL, verbose_name='Responsável (usuário do sistema)'),
        ),
        migrations.AlterField(
            model_name='filial',
            name='responsavel_nome',
            field=models.CharField(blank=True, max_length=150, verbose_name='Nome do responsável (se não for um usuário do sistema)'),
        ),
        migrations.RunPython(preencher_nome_normalizado, reverter_noop),
        migrations.AddConstraint(
            model_name='filial',
            constraint=models.UniqueConstraint(fields=('empresa', 'nome_normalizado'), name='filial_nome_normalizado_unico_por_empresa'),
        ),
    ]
