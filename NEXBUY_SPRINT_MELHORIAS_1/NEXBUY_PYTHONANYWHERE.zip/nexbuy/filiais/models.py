from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from core.choices import UF_CHOICES
from core.models import ModeloAtivavel, TimeStampedModel
from core.validators import normalizar_cnpj, validar_cnpj
from empresas.models import Empresa


class Filial(TimeStampedModel, ModeloAtivavel):
    """Fechamento Final (Prompt 1, Seção 4.4): a Filial deixou de ser só um
    "nome + cidade" e virou um Estabelecimento fiscal completo — cada uma
    pode ter seu próprio CNPJ (a raiz de 8 dígitos normalmente é a mesma
    entre Matriz e Filiais da mesma Empresa, só o sufixo/dígitos
    verificadores mudam), Inscrição Estadual, endereço e contato próprios.
    Tudo opcional (`blank=True`): uma Filial pode nascer só com o nome e
    ser completada depois — `cadastro_completo` sinaliza isso para a UI
    (badge "cadastro incompleto"), nunca bloqueia o cadastro em si.

    Gate pré-Etapa 10 (S1-1): auditoria externa encontrou o cadastro ainda
    incompleto em relação ao Prompt 1 original — faltavam `razao_social` e
    um responsável ligado a um Usuario de verdade (só existia texto livre),
    e a unicidade de nome não resistia a diferenças de caixa/espaço."""

    class TipoEstabelecimento(models.TextChoices):
        MATRIZ = "matriz", "Matriz (CNPJ raiz)"
        FILIAL = "filial", "Filial"

    empresa = models.ForeignKey(
        Empresa, on_delete=models.CASCADE, related_name="filiais", verbose_name="Empresa"
    )
    nome = models.CharField("Nome da filial", max_length=150)
    # Auto-preenchido em `save()` — nunca editado diretamente (por isso não
    # entra em nenhum form). Fonte única da unicidade robusta de nome:
    # diferenças só de maiúscula/minúscula ou espaçamento duplicado não
    # criam duas Filiais "diferentes" na mesma Empresa (S1-1).
    nome_normalizado = models.CharField(max_length=150, editable=False, blank=True, default="")
    razao_social = models.CharField(
        "Razão Social", max_length=200, blank=True,
        help_text="Nome legal do estabelecimento — opcional quando igual ao da Empresa.",
    )
    tipo_estabelecimento = models.CharField(
        "Tipo de estabelecimento", max_length=10,
        choices=TipoEstabelecimento.choices, default=TipoEstabelecimento.FILIAL,
        help_text="Só uma Filial por Empresa pode ser marcada como Matriz.",
    )
    codigo_interno = models.CharField(
        "Código interno", max_length=30, blank=True, null=True,
        help_text="Código próprio da empresa para identificar esta unidade (opcional, único por Empresa).",
    )

    # --- Dados fiscais -----------------------------------------------
    cnpj = models.CharField(
        "CNPJ", max_length=18, blank=True, null=True, unique=True, validators=[validar_cnpj],
        help_text="Opcional — preencha quando este estabelecimento tiver CNPJ próprio.",
    )
    inscricao_estadual = models.CharField("Inscrição Estadual", max_length=20, blank=True)
    isento_inscricao_estadual = models.BooleanField("Isento de Inscrição Estadual", default=False)

    # --- Endereço ------------------------------------------------------
    endereco = models.CharField("Endereço", max_length=255, blank=True)
    numero = models.CharField("Número", max_length=20, blank=True)
    complemento = models.CharField("Complemento", max_length=100, blank=True)
    bairro = models.CharField("Bairro", max_length=100, blank=True)
    cidade = models.CharField("Cidade", max_length=100, blank=True)
    estado = models.CharField("Estado", max_length=2, choices=UF_CHOICES, blank=True)
    cep = models.CharField("CEP", max_length=9, blank=True)

    # --- Contato / responsável ------------------------------------------
    telefone = models.CharField("Telefone", max_length=20, blank=True)
    email = models.EmailField("E-mail", blank=True)
    # `responsavel_nome` fica para quando o responsável NÃO é um usuário do
    # sistema (ex.: um gerente local sem login no NEXBUY) — `responsavel_
    # usuario`, quando preenchido, é a fonte de verdade preferida e os dois
    # nunca são obrigatórios ao mesmo tempo.
    responsavel_nome = models.CharField("Nome do responsável (se não for um usuário do sistema)", max_length=150, blank=True)
    responsavel_usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="filiais_sob_responsabilidade", verbose_name="Responsável (usuário do sistema)",
        help_text="Precisa ser um usuário ativo desta Empresa e autorizado nesta Filial.",
    )
    responsavel_telefone = models.CharField("Telefone do responsável", max_length=20, blank=True)
    responsavel_email = models.EmailField("E-mail do responsável", blank=True)

    class Meta:
        verbose_name = "Filial"
        verbose_name_plural = "Filiais"
        ordering = ["empresa__nome", "nome"]
        constraints = [
            models.UniqueConstraint(
                fields=["empresa", "nome_normalizado"], name="filial_nome_normalizado_unico_por_empresa",
            ),
            models.UniqueConstraint(
                fields=["empresa", "codigo_interno"], name="filial_codigo_interno_unico_por_empresa",
            ),
            models.UniqueConstraint(
                fields=["empresa"],
                # Nomes de classe aninhada (TipoEstabelecimento) não são
                # visíveis aqui dentro de `Meta` — escopo de classe do
                # Python não é herdado por classes aninhadas — por isso o
                # valor literal ("matriz", igual a TipoEstabelecimento.MATRIZ).
                condition=models.Q(tipo_estabelecimento="matriz"),
                name="filial_matriz_unica_por_empresa",
            ),
        ]

    def __str__(self):
        return f"{self.nome} - {self.empresa.nome}"

    def clean(self):
        """Defesa em profundidade (Gate pré-Etapa 10, S1-1): o form já
        restringe o queryset de `responsavel_usuario` a quem pode ser
        escolhido, mas o model nunca pode confiar cegamente num POST
        manipulado enviando o `pk` de um usuário de outra Empresa, inativo
        ou sem vínculo com esta Filial."""
        super().clean()
        if self.responsavel_usuario_id and self.empresa_id:
            from usuarios.models import filiais_autorizadas_para

            usuario = self.responsavel_usuario
            if not usuario.is_active:
                raise ValidationError({"responsavel_usuario": "O responsável precisa ser um usuário ativo."})
            if usuario.empresa_id != self.empresa_id:
                raise ValidationError({"responsavel_usuario": "O responsável precisa ser um usuário desta Empresa."})
            if self.pk and self.pk not in filiais_autorizadas_para(usuario, self.empresa).values_list("pk", flat=True):
                raise ValidationError(
                    {"responsavel_usuario": "O responsável precisa estar autorizado nesta Filial."}
                )

        # Gate pré-Etapa 10 (S1-1, item 4): uma Filial nunca pode reivindicar
        # o CNPJ de uma Empresa DIFERENTE — a única coincidência legítima é
        # a Matriz reaproveitando o CNPJ raiz da própria Empresa (regra já
        # definida no cadastro: a Matriz É o estabelecimento raiz).
        if self.cnpj and self.empresa_id:
            conflito = (
                Empresa.objects.filter(cnpj=normalizar_cnpj(self.cnpj))
                .exclude(pk=self.empresa_id)
                .exists()
            )
            if conflito:
                raise ValidationError(
                    {"cnpj": "Este CNPJ já pertence a outra Empresa cadastrada no NEXBUY."}
                )

    def save(self, *args, **kwargs):
        self.nome_normalizado = " ".join((self.nome or "").split()).casefold()
        self.cnpj = normalizar_cnpj(self.cnpj) or None
        super().save(*args, **kwargs)
        # Gate C (Prompt 2, Seção 6): quem é designado responsável por uma
        # Filial precisa estar AUTORIZADO a ela — senão a própria pessoa
        # não enxergaria a Filial que é responsável por gerir. `clean()`
        # já bloqueia reatribuir o responsável para alguém não autorizado
        # numa Filial EXISTENTE (POST manipulado); aqui, no caminho feliz
        # (cadastro/edição normal pela tela), o vínculo é concedido
        # automaticamente — nunca revogado aqui, só concedido.
        if self.responsavel_usuario_id and self.responsavel_usuario.perfil != "proprietario":
            from usuarios.models import UsuarioFilial

            UsuarioFilial.objects.update_or_create(
                usuario_id=self.responsavel_usuario_id, filial=self, defaults={"ativo": True}
            )

    @property
    def cadastro_completo(self) -> bool:
        """Fechamento Final (Seção 4.4): usado pela UI para o badge
        "cadastro incompleto" — nunca bloqueia nenhuma operação, é só um
        lembrete visual de que faltam dados fiscais/endereço.

        Gate pré-Etapa 10 (S1-1): passou a exigir também razão social e um
        responsável identificado (usuário do sistema OU nome + telefone/e-mail
        de contato) — sem isso a Filial não é um estabelecimento fiscal
        utilizável de verdade, mesmo com CNPJ/endereço preenchidos.

        Gate A/Prompt 2 (Seção 6): a auditoria encontrou uma Filial ativa
        ("Loja Norte") sem telefone considerada "completa" — endereço
        também não checava `numero`/`bairro` isoladamente (só `endereco`
        livre). Telefone da Filial passa a ser exigido, junto com
        número/bairro do endereço."""
        ie_resolvida = self.isento_inscricao_estadual or bool(self.inscricao_estadual)
        endereco_completo = bool(
            self.endereco and self.numero and self.bairro and self.cidade and self.estado and self.cep
        )
        responsavel_identificado = bool(
            self.responsavel_usuario_id or (self.responsavel_nome and (self.responsavel_telefone or self.responsavel_email))
        )
        return (
            bool(self.cnpj) and ie_resolvida and endereco_completo and bool(self.razao_social)
            and bool(self.telefone) and responsavel_identificado
        )
