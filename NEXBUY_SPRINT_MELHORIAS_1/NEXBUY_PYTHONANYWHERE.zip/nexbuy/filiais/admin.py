from django.contrib import admin

from core.utils import formatar_cnpj

from .models import Filial


@admin.register(Filial)
class FilialAdmin(admin.ModelAdmin):
    list_display = (
        "nome", "razao_social", "empresa", "tipo_estabelecimento", "cnpj_formatado",
        "responsavel_usuario", "cidade", "ativo",
    )
    list_filter = ("ativo", "empresa", "tipo_estabelecimento")
    # Gate pré-Etapa 10 (S1-1, item 3): `cnpj` agora é persistido só com
    # dígitos — busca com máscara não bate mais (mesmo comportamento aceito
    # em `EmpresaAdmin`).
    search_fields = ("nome", "razao_social", "cidade", "cnpj", "codigo_interno")
    autocomplete_fields = ("responsavel_usuario",)
    readonly_fields = ("nome_normalizado",)

    @admin.display(description="CNPJ", ordering="cnpj")
    def cnpj_formatado(self, filial):
        return formatar_cnpj(filial.cnpj) if filial.cnpj else "—"
