"""Formulário de Filial (Sprint de Correções Críticas — Seção 6;
Fechamento Final — Prompt 1, Seção 4.4: Filial vira Estabelecimento fiscal
completo).

A Empresa NUNCA é um campo do formulário — vem sempre do contexto (a
empresa ativa da sessão), passada explicitamente pela view. Isso evita
por construção o risco de alguém manipular a Empresa via POST."""
import re

from django import forms

from core.forms import BootstrapFormMixin
from core.validators import inscricao_estadual_estruturalmente_plausivel

from .models import Filial


class FilialForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Filial
        fields = [
            "nome", "razao_social", "tipo_estabelecimento", "codigo_interno",
            "cnpj", "inscricao_estadual", "isento_inscricao_estadual",
            "endereco", "numero", "complemento", "bairro", "cidade", "estado", "cep",
            "telefone", "email", "responsavel_nome",
            "responsavel_usuario", "responsavel_telefone", "responsavel_email",
            "ativo",
        ]

    def __init__(self, *args, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.empresa = empresa
        if self.instance.pk is None:
            # Filial NOVA nasce sempre ativa (default do ModelAtivavel): o
            # checkbox "Ativo" só aparece na EDIÇÃO (filial_form.html), e um
            # checkbox ausente no POST vira False — sem isto, toda filial
            # criada pela tela nascia inativa, sem aparecer em lugar nenhum.
            del self.fields["ativo"]
        else:
            self.fields["ativo"].required = False
        self.fields["tipo_estabelecimento"].required = False
        self.fields["isento_inscricao_estadual"].required = False
        for campo in (
            "razao_social", "codigo_interno", "cnpj", "inscricao_estadual", "endereco", "numero",
            "complemento", "bairro", "cidade", "estado", "cep", "telefone", "email", "responsavel_nome",
            "responsavel_usuario", "responsavel_telefone", "responsavel_email",
        ):
            self.fields[campo].required = False
        # Gate pré-Etapa 10 (S1-1): o queryset já restringe quem PODE ser
        # escolhido (usuário ativo desta Empresa) — o model.clean() faz a
        # segunda camada de defesa contra POST manipulado.
        from usuarios.models import Usuario

        if self.empresa is not None:
            self.fields["responsavel_usuario"].queryset = Usuario.objects.filter(
                empresa=self.empresa, is_active=True
            ).order_by("first_name", "username")
        else:
            self.fields["responsavel_usuario"].queryset = Usuario.objects.none()

    def clean_nome(self):
        nome = self.cleaned_data["nome"].strip()
        if self.empresa is not None:
            duplicado = (
                Filial.objects.filter(empresa=self.empresa, nome__iexact=nome)
                .exclude(pk=self.instance.pk)
                .exists()
            )
            if duplicado:
                raise forms.ValidationError("Já existe uma filial com este nome nesta empresa.")
        return nome

    def clean_cnpj(self):
        """Normaliza para só dígitos antes de validar/gravar — aceita
        qualquer máscara digitada (com ou sem pontuação)."""
        cnpj = (self.cleaned_data.get("cnpj") or "").strip()
        if not cnpj:
            return None
        return re.sub(r"\D", "", cnpj) or None

    def clean_inscricao_estadual(self):
        """Checagem estrutural mínima (Seção 4.4) — nunca valida dígito
        verificador por UF, só descarta digitação obviamente errada."""
        ie = (self.cleaned_data.get("inscricao_estadual") or "").strip()
        if ie and not inscricao_estadual_estruturalmente_plausivel(ie):
            raise forms.ValidationError("Inscrição Estadual não parece válida — confira os dígitos.")
        return ie

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("isento_inscricao_estadual") and cleaned.get("inscricao_estadual"):
            self.add_error(
                "inscricao_estadual",
                "Não é possível marcar Isento e preencher a Inscrição Estadual ao mesmo tempo.",
            )
        if self.empresa is not None and cleaned.get("tipo_estabelecimento") == Filial.TipoEstabelecimento.MATRIZ:
            outra_matriz = (
                Filial.objects.filter(empresa=self.empresa, tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ)
                .exclude(pk=self.instance.pk)
                .exists()
            )
            if outra_matriz:
                self.add_error(
                    "tipo_estabelecimento",
                    "Esta Empresa já tem outra filial marcada como Matriz — só pode haver uma.",
                )
        return cleaned

    def save(self, commit=True):
        filial = super().save(commit=False)
        if self.empresa is not None:
            filial.empresa = self.empresa
        if commit:
            filial.save()
        return filial


def filial_possui_movimentacao(filial) -> bool:
    """True se a Filial tem qualquer registro financeiro/operacional
    vinculado — usada para bloquear exclusão (Seção 6: "Filial com
    movimentação financeira não pode ser excluída"). Verifica só
    existência (não conta tudo), então é barata mesmo em filiais antigas.

    Toda relação com `on_delete=CASCADE` para a Filial precisa estar aqui —
    senão a exclusão apaga os registros em silêncio. Correções de Produção:
    faltavam as receitas extras (`ReceitaExtra.filial`, CASCADE — uma filial
    só com receitas extras era excluída e levava as receitas junto) e os
    vínculos operacionais de usuário (`UsuarioFilial.filial`, CASCADE — a
    exclusão tirava em silêncio o acesso de quem opera a filial; a mensagem
    da tela já prometia "usuários vinculados"). `RegistroAuditoria.filial`
    é SET_NULL (o histórico sobrevive), então não bloqueia."""
    if filial.usuarios.exists() or filial.vinculos_usuario.exists():
        return True
    if filial.compras.exists():
        return True
    if filial.provisoes.exists():
        return True
    if filial.receitas.exists() or filial.receitas_extras.exists():
        return True
    if filial.custos_fixos.exists() or filial.custos_variaveis.exists():
        return True
    return False
