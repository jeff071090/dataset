@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ==================================================
echo   NEXBUY - INICIAR demonstracao comercial
echo ==================================================
echo.

REM --- 1. Validar que a preparacao foi concluida -----------------------------
if not exist "venv\Scripts\python.exe" (
    echo [ERRO] Ambiente virtual nao encontrado.
    echo Solucao: rode PREPARAR_DEMO_NEXBUY.bat primeiro.
    pause
    exit /b 1
)
venv\Scripts\python.exe -c "import django" >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Dependencias nao instaladas.
    echo Solucao: rode PREPARAR_DEMO_NEXBUY.bat primeiro.
    pause
    exit /b 1
)
if not exist "db_demo_cliente.sqlite3" (
    echo [ERRO] Banco de demonstracao nao encontrado.
    echo Solucao: rode PREPARAR_DEMO_NEXBUY.bat primeiro.
    pause
    exit /b 1
)

REM --- 2. Modo demonstracao garantido ---------------------------------------
REM DEBUG=True somente para o processo deste terminal (nunca gravado em .env).
set DEBUG=True
set DEMO_MODE=True

REM --- 3. Verificacao rapida antes de subir o servidor -----------------------
REM Um "check" barato aqui mostra QUALQUER erro de configuracao com a causa
REM completa nesta janela - nunca uma pagina generica de erro no navegador.
venv\Scripts\python.exe manage.py check --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] O Django encontrou problemas de configuracao - veja a causa acima.
    echo Solucao: rode PREPARAR_DEMO_NEXBUY.bat; se persistir, veja o erro exibido.
    pause
    exit /b 1
)

REM --- 4. Detectar porta livre ------------------------------------------------
set "PORT="
for %%p in (8000 8001 8002 8010 8080) do call :verificar_porta %%p
if not defined PORT (
    echo [ERRO] Nenhuma porta livre entre 8000, 8001, 8002, 8010 e 8080.
    echo Solucao: feche outros servidores locais - janelas de demo antigas
    echo ou outros projetos Django - e rode este launcher de novo.
    pause
    exit /b 1
)
echo Porta escolhida: %PORT%

echo.
echo ==================================================
echo   Credenciais de demonstracao (senha: nexbuy123):
echo     demo_proprietario  - Roberto Almeida    (Proprietario)
echo     demo_gerente       - Fernanda Costa     (Gerente)
echo     demo_financeiro    - Marcos Vinicius    (Financeiro)
echo     demo_comprador     - Juliana Ramos      (Comprador)
echo.
echo   Endereco: http://127.0.0.1:%PORT%/
echo   O navegador abre sozinho quando a aplicacao responder.
echo   NAO FECHE ESTA JANELA durante a apresentacao (logs do servidor).
echo   Para encerrar: Ctrl+C ou feche esta janela.
echo ==================================================
echo.

REM --- 5. Abrir o navegador quando a aplicacao responder ---------------------
REM O helper roda em segundo plano neste mesmo console: testa a URL ate
REM receber HTTP 200 e so entao abre o navegador (nunca uma pagina de erro).
start "" /b venv\Scripts\python.exe demo_abrir_navegador.py %PORT%

REM --- 6. Servidor (isolado: nunca toca db.sqlite3 / media\) -----------------
venv\Scripts\python.exe manage.py runserver 127.0.0.1:%PORT% --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo.
    echo [ERRO] O servidor terminou com erro - a causa esta nas linhas acima.
    echo Solucao: rode PREPARAR_DEMO_NEXBUY.bat e tente de novo; se persistir,
    echo use RESETAR_DEMO_NEXBUY.bat para recriar o cenario do zero.
)
pause
exit /b 0

:verificar_porta
if defined PORT goto :eof
netstat -ano | findstr /c:":%1 " | findstr /i "LISTENING" >nul 2>&1
if errorlevel 1 set "PORT=%1"
goto :eof
