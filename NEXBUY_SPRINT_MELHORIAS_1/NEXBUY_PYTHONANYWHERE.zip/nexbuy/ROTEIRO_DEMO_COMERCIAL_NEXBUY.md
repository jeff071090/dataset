# NEXBUY — Roteiro Comercial (8 cenas · versões de 5, 15 e 30 minutos)

A apresentação conta UMA história: **o comprador planeja, o sistema aplica
regras, o gestor decide, o Financeiro antecipa o compromisso, a Análise
Financeira mostra se a farmácia está saudável e o proprietário acompanha
tudo com rastreabilidade.**

Apoios em tela: abra a demonstração por `/demo/apresentacao/` (tela de
abertura) e use o **Guia da apresentação** (canto inferior direito, só na
demo) — ele mostra a cena atual e a próxima sem executar nada por você.
Troca de perfil: **nome no canto superior direito → Trocar perfil de
demonstração → senha `nexbuy123`**. Antes de começar:
`CHECKLIST_ANTES_DA_REUNIAO.md`.

**Escopo atual, para não errar na fala:** o NEXBUY é 100% web; receitas,
custos e compras são **lançamento manual** (receita mensal, receitas
extras, custos fixos e variáveis alimentam a projeção de compra e os
limites dos compradores); a **Análise Financeira** (DRE, créditos ×
débitos, saúde financeira) é vista por Proprietário, Gerente e Financeiro;
o **DDA é integração futura prevista (não conectada)**. Não há integração
com ERP nem controle de estoque.

---

## As 8 cenas (roteiro COMERCIAL — 15 minutos)

Abertura: `/demo/apresentacao/` na tela. Fale a mensagem central e clique
**Iniciar demonstração** (login real de `demo_proprietario`).

### Cena 1 — "Uma visão para toda a operação"
- **Objetivo comercial:** posicionar o NEXBUY como central de decisão, não como cadastro.
- **Perfil:** Proprietário.
- **Caminho exato:** Início (Dashboard Executivo) → seletor de empresa no topo.
- **Ação:** mostrar KPIs do grupo, "Revisar Aprovações (N)", trocar o contexto para "Drogaria Vida Plena Norte" e voltar.
- **Resultado esperado:** números preenchidos mudando com o contexto; pendências reais no botão primário.
- **Quadro "Resultado do mês":** o mês corrente vem com o selo **parcial** e o aviso "compras lançadas até DD/MM; lucro e margem provisórios" — a receita já é a do mês inteiro, mas as compras só vão até hoje, então no começo do mês o lucro parece alto demais. Comente o número do **"Mês fechado"** ao lado (alguns % da receita) e a mini-curva, que mostra só os meses fechados.
- **Fala de apoio (se perguntarem da margem alta do mês):** "Este mês ainda está em andamento: a receita já está lançada inteira e as compras entram dia a dia. Por isso o sistema marca como parcial e mostra o mês fechado ao lado — é ele que diz se sobrou dinheiro."
- **Frase sugerida:** "Em vez de buscar informações em várias planilhas e pessoas, o proprietário começa o dia sabendo onde precisa agir."
- **Pergunta ao cliente:** "Hoje, qual informação mais demora para chegar até vocês?"
- **Não prometer:** consolidação automática vinda de outro sistema (a origem é o próprio NEXBUY — receitas, custos e compras são lançados manualmente).
- **Plano alternativo:** se não houver pendência no botão, use o sino de notificações ou os KPIs como gancho.

### Cena 2 — "Autonomia sem perder o controle"
- **Objetivo comercial:** primeira interação do cliente; valor sentido na mão.
- **Perfil:** Comprador (trocar perfil).
- **Caminho exato:** Início → Planejamento de Compras → Nova Provisão.
- **Ação:** mostrar saldo do dia e a explicação Compra × Provisão; **pedir ao cliente um valor PEQUENO** (ex.: abaixo de R$ 300) e registrar a provisão ao vivo.
- **Resultado esperado:** mensagem de sucesso; provisão nasce Provisionada, sem pedir aprovação.
- **Frase sugerida:** "O comprador consegue planejar e agir sem depender de autorização para tudo, desde que permaneça dentro das regras definidas."
- **Pergunta ao cliente:** "Quem define hoje quanto cada comprador pode gastar por dia?"
- **Não prometer:** cadastro de produtos ou controle de estoque (o item é texto livre por decisão de escopo).
- **Plano alternativo:** se o valor sugerido estourar o limite (dia muito comprometido), celebre: "melhor ainda — acabaram de ver o controle em ação" e siga direto à Cena 3.

### Cena 3 — "O controle aparece somente quando é necessário"
- **Objetivo comercial:** governança sem fricção — a exceção vira fluxo, não erro.
- **Perfil:** Comprador.
- **Caminho exato:** Planejamento de Compras → Nova Provisão.
- **Ação:** **pedir ao cliente um valor propositalmente MAIOR que o limite** (ex.: R$ 25.000) e registrar.
- **Resultado esperado:** aviso claro de estouro; status "Aguardando aprovação"; nenhuma mensagem técnica ou bloqueio confuso.
- **Frase sugerida:** "O sistema não impede a operação silenciosamente. Ele identifica a exceção, registra o contexto e encaminha para a alçada correta."
- **Pergunta ao cliente:** "Como uma compra acima do limite é aprovada hoje na operação de vocês?"
- **Não prometer:** notificação por WhatsApp/e-mail externo (o sino é interno).
- **Plano alternativo:** se já existir uma solicitação pendente do ensaio, use-a na Cena 4 e registre a nova mesmo assim (a fila mostra as duas).

### Cena 4 — "A decisão chega à pessoa certa"
- **Objetivo comercial:** alçadas configuráveis funcionando de verdade.
- **Perfil:** Gerente → Financeiro (duas trocas de perfil).
- **Caminho exato:** Aprovações → botão "Decidir" na linha → Aprovar (com justificativa).
- **Ação:** como Gerente, mostrar valor, filial, comprador e itens; aprovar. Como o valor excede a alçada de R$ 2.000, trocar para o Financeiro e concluir a 2ª etapa.
- **Resultado esperado:** solicitação some da fila do Gerente e aparece para o Financeiro; ao final, provisão Aprovada.
- **Frase sugerida:** "A equipe não precisa descobrir quem deve aprovar. O fluxo já conhece a responsabilidade e a alçada de cada perfil."
- **Pergunta ao cliente:** "Esses valores de alçada fazem sentido para vocês? Eles são configuráveis."
- **Não prometer:** aprovação por delegação/fora do fluxo configurado.
- **Plano alternativo:** se a solicitação já tiver sido aprovada num ensaio, rejeite a segunda com justificativa — mostra o desfecho negativo auditado, que também convence.

### Cena 5 — "A compra deixa de ser surpresa para o Financeiro"
- **Objetivo comercial:** a cena de maior impacto — antecipação de caixa.
- **Perfil:** Financeiro.
- **Caminho exato:** Início → Agenda Financeira; depois Planejamento → Contas a Pagar.
- **Ação:** mostrar a provisão recém-aprovada na régua dos 30 dias, junto de custos fixos, variáveis e parcelas; o limite diário de compras no painel.
- **Resultado esperado:** o compromisso da Cena 3/4 visível ANTES de existir boleto; números batendo com o dashboard.
- **Frase sugerida:** "O Financeiro deixa de descobrir a compra quando o boleto chega. A intenção já aparece no planejamento antes do compromisso efetivo."
- **Pergunta ao cliente:** "Hoje, quando o Financeiro de vocês descobre os compromissos futuros?"
- **Não prometer:** baixa automática ou conciliação bancária (a baixa é manual; o DDA, integração futura, só vai trazer os boletos para conferência do Financeiro).
- **Plano alternativo:** se a provisão aprovada estiver fora da janela visível, use os filtros de período da própria agenda.

### Cena 6 — "A farmácia está saudável?"
- **Objetivo comercial:** responder à pergunta da própria cliente — "um DRE e um tipo de balancete: o que entrou, o que saiu, qual foi a curva, o que foi maior e o que fazer para o negócio ficar mais saudável".
- **Perfil:** Financeiro (continua da Cena 5). O Proprietário vê a mesma tela com as duas lojas; o Gerente vê a da própria loja, também em R$.
- **Caminho exato:** menu **Análise Financeira** (no Proprietário: Financeiro → Análise Financeira) → abas **DRE Gerencial**, **Créditos × Débitos** e **Saúde Financeira** (`/financeiro/analise/`).
- **O que mostrar (dados de exemplo com 12 meses de histórico das duas lojas):**
  - **DRE Gerencial:** receita (mensal + convênios/PBM, serviços e rendimentos), compras aprovadas em torno de 60% a 65% da receita nos meses fechados, custos variáveis (~8%: impostos, cartão, comissões, entregas), custos fixos (~20% a 22%) e o resultado; na curva de 12 meses, aponte o **mês que fechou no prejuízo** (compras muito acima do normal) e a queda da receita nos últimos meses.
  - **Créditos × Débitos:** o "balancete" do mês — o que entrou e o que saiu por vencimento, a maior entrada e a maior saída; mostre o **mês em que o caixa ficou no vermelho** (as parcelas do mês ruim vencendo).
  - **Saúde Financeira:** semáforo dos indicadores com a referência de mercado de cada um, ponto de equilíbrio e as **recomendações em reais** — hoje aparecem pelo menos "receita em queda" e "custos fixos acima da referência", cada uma com o link para a tela onde se age.
- **Resultado esperado:** a cliente reconhece uma farmácia de verdade nos números (margem bruta de 35% a 40%, resultado de alguns % da receita) e vê o sistema apontar o que fazer, não só o que aconteceu.
- **Frase sugerida:** "Com o que vocês já lançam no dia a dia — receita, custos e compras —, o NEXBUY fecha o mês sozinho: mostra se sobrou dinheiro, onde ele foi parar e o que ajustar antes que vire problema."
- **Pergunta à cliente:** "Hoje, no fim do mês, vocês sabem quanto sobrou e qual despesa mais pesou? Quanto tempo leva para ter essa resposta?"
- **Não prometer:** DRE contábil/fiscal (é uma DRE gerencial, para decisão), conciliação bancária ou números puxados de outro sistema — tudo vem do que é lançado no NEXBUY.
- **Atenção ao mês corrente:** a DRE do mês corrente compara as compras feitas ATÉ HOJE com a receita do mês inteiro — nas primeiras semanas ela ainda parece boa demais. A tela avisa ("Mês em andamento: resultado parcial…", resultado "provisório") e tem o botão **Ver <mês anterior>**; o link do Guia abre o **último mês fechado até o dia 24** e o mês corrente do dia 25 em diante. Entrando pelo menu, use esse botão ou **« mês anterior »** no começo do mês.
- **Plano alternativo:** se a cliente perguntar por que o mês corrente tem margem tão alta, é exatamente isso: o mês ainda não terminou — as compras do resto do mês ainda vão entrar. A curva de 12 meses e a Saúde do mês fechado contam a história completa.

### Cena 7 — "Toda decisão deixa uma história"
- **Objetivo comercial:** confiança e maturidade — rastreabilidade de ponta a ponta.
- **Perfil:** Proprietário (trocar perfil).
- **Caminho exato:** Relatórios → Compras por Filial; depois Configurações → Central de Auditoria.
- **Ação:** mostrar o comparativo matriz × filial; na Auditoria, filtrar os eventos de HOJE e apontar as aprovações feitas na própria reunião (quem, quando, justificativa).
- **Resultado esperado:** o pedido criado ao vivo aparece auditado com os atores reais.
- **Frase sugerida:** "O NEXBUY não mostra apenas o resultado. Ele explica como a decisão aconteceu."
- **Pergunta ao cliente:** "Se o contador ou um sócio pedir o histórico de uma compra, quanto tempo isso leva hoje?"
- **Não prometer:** exportação de auditoria assinada digitalmente/certificada.
- **Plano alternativo:** abrir a timeline da própria provisão (Planejamento de Compras → dia no calendário) — mesma história em outro formato.

### Cena 8 — "O que está pronto e para onde podemos evoluir"
- **Objetivo comercial:** honestidade que vende — fechar pedindo próximo passo.
- **Perfil:** Proprietário.
- **Caminho exato:** Configurações → Integrações; depois `/demo/encerramento/`.
- **Ação:** mostrar que só o DDA aparece, como "Não conectado — integração prevista", e o texto de apoio "todos os lançamentos são manuais"; abrir a tela de Encerramento.
- **Resultado esperado:** cliente enxerga sem confusão o que está pronto (tudo o que viu, por lançamento manual) e o que é futuro (só o DDA).
- **Frase sugerida:** "O núcleo de decisão já está funcionando, com tudo lançado pela própria tela. O DDA, quando conectado, vai trazer os boletos para a Agenda — para o Financeiro conferir, nunca para pagar sozinho."
- **Perguntas de fechamento (na ordem):** "Qual dessas etapas mais se aproxima do problema que vocês vivem hoje?" e "Faz sentido realizarmos a próxima demonstração usando uma estrutura parecida com as filiais e limites de vocês?"
- **Não prometer:** data, preço ou prazo do DDA; nem integração com ERP (não haverá — ver `NEXBUY_RESPOSTAS_PERGUNTAS_DIFICEIS.md`).
- **Plano alternativo:** se o tempo acabar, pule direto para `/demo/encerramento/` — o resumo visual conta a história sozinho.

---

## Versão EXECUTIVA — 5 minutos

Cenas **1 → 2 → 3 → 6 → 8** (pule as decisões e a agenda; na Cena 6 mostre
só a DRE e a Saúde Financeira; na Cena 8, mencione que a aprovação e a
agenda existem e ofereça a demonstração completa como próximo passo).
Abertura e encerramento sempre.

## Versão COMPLETA — 30 minutos

As 8 cenas na ordem, acrescentando entre as cenas 6 e 7:

- **Simulador** (Comprador): simular um valor alto — "cabe ou não cabe" antes de pedir;
- **Compradora bloqueada** (`demo_comprador3`): dashboard abre em "Bloqueado" — bloqueio na origem;
- **Capacidade dos Compradores** (Financeiro): Juliana R$ 3.500 · Pedro R$ 2.000 · Carla bloqueada;
- **Usuários e Permissões** (Proprietário): RBAC aditivo (Gerente com "Consulta Financeira");
- **Fluxos de Aprovação + Configurações Gerais** (Proprietário): a alçada de R$ 2.000 configurável e a autoaprovação controlada;
- **Mobile** (qualquer perfil): estreite a janela — barra inferior e aprovação possível fora do computador.

**Nunca prometa na reunião:** DDA conectado, integração com ERP (não
haverá), sugestão automática de compra, controle de estoque/produtos, app
nativo, preço, prazo — ver `MAPA_CAPACIDADES_NEXBUY.md` e
`NEXBUY_RESPOSTAS_PERGUNTAS_DIFICEIS.md`.
