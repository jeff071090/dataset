@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo   NEXBUY - Demo Comercial (cenario vazio/guiado)
echo ============================================
echo.
echo Este launcher NUNCA toca no banco principal (db.sqlite3) nem na pasta
echo media\ principal. Ele usa SOMENTE db_demo_cliente.sqlite3 e a pasta
echo media_demo_cliente\, isoladas do ambiente real (nexbuy.settings_demo).
echo.

REM --- 0. Isolamento extra so para esta sessao -----------------------------
REM DEBUG=True so para o processo deste terminal (nunca gravado em .env):
REM a demo roda em http local (127.0.0.1), sem HTTPS/dominio real, entao
REM DEBUG=False quebraria o servidor (SECURE_SSL_REDIRECT e a checagem de
REM SECRET_KEY de producao). Isso tambem garante que o launcher funciona
REM mesmo que o .env da pasta esteja configurado como producao.
set DEBUG=True
REM Gate Final V2 (Bloqueador P1): o cenario VAZIO/guiado reproduz a
REM experiencia cliente-ready de verdade - sem NENHUM dado ficticio, entao
REM sem badge "Modo Demonstracao". DEMO_MODE=False explicito aqui; so o
REM cenario PRONTO (iniciar_demo_cenario_pronto.bat) liga o badge.
set DEMO_MODE=False

REM --- 1. Verificar Python 3.12+ no PATH ------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado no PATH.
    echo Instale o Python 3.12 ou mais recente e tente novamente.
    pause
    exit /b 1
)

python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Versao do Python incompativel. E necessario Python 3.12 ou mais recente.
    python --version
    pause
    exit /b 1
)

REM --- 2. Ambiente virtual ---------------------------------------------------
REM Reaproveita o venv\ do projeto (ja tem Django/gunicorn/whitenoise/Pillow
REM instalados) em vez de criar um venv de demo separado. Decisao: a demo usa
REM o MESMO codigo-fonte do projeto, so um banco/midia diferentes (cuidado
REM por nexbuy/settings_demo.py) - nao ha motivo para duplicar o ambiente.
if not exist "venv\Scripts\python.exe" (
    echo Criando ambiente virtual...
    python -m venv venv
    if errorlevel 1 (
        echo [ERRO] Falha ao criar o ambiente virtual.
        pause
        exit /b 1
    )
)

REM --- 3. Dependencias ---------------------------------------------------------
venv\Scripts\python.exe -c "import django" >nul 2>&1
if errorlevel 1 (
    echo Instalando dependencias...
    venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERRO] Falha ao instalar as dependencias.
        pause
        exit /b 1
    )
)

REM --- 4. Token temporario de Primeiro Acesso (so nesta sessao) ---------------
REM Gerado a cada execucao e definido SOMENTE como variavel de ambiente do
REM processo do servidor - nunca gravado em nenhum arquivo .env permanente.
REM Some assim que esta janela for fechada.
for /f "delims=" %%T in ('venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(32))"') do set INITIAL_SETUP_TOKEN=%%T

echo.
echo ============================================
echo   TOKEN de Primeiro Acesso (valido so nesta sessao)
echo.
echo   %INITIAL_SETUP_TOKEN%
echo.
echo   Digite este token no formulario que abrir em /primeiro-acesso/.
echo   NUNCA cole o token na URL do navegador - o formulario e a unica
echo   forma aceita de informar o token.
echo ============================================
echo.

REM --- 5. Banco de dados de demo (isolado, nunca db.sqlite3) ------------------
echo Aplicando migracoes no banco de demo (db_demo_cliente.sqlite3)...
venv\Scripts\python.exe manage.py migrate --noinput --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao aplicar as migracoes no banco de demo.
    pause
    exit /b 1
)
REM Se o banco de demo ja existir com dados de uma sessao anterior, este
REM launcher NAO apaga nada - so segue usando o que ja existe. Use
REM resetar_demo_cliente_limpa.bat se quiser comecar do zero.
REM Este launcher NUNCA roda seed_demo - o objetivo aqui e o cenario VAZIO,
REM cadastrado ao vivo pelo apresentador em /primeiro-acesso/.

echo.
echo Abrindo o navegador em /primeiro-acesso/...
start http://127.0.0.1:8000/primeiro-acesso/

echo.
echo ============================================
echo   NAO FECHE ESTA JANELA durante a apresentacao.
echo   Para encerrar, feche esta janela ou pressione Ctrl+C.
echo   Endereco: http://127.0.0.1:8000/
echo   Banco isolado: db_demo_cliente.sqlite3
echo   Midia isolada: media_demo_cliente\
echo ============================================
echo.

venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000 --settings=nexbuy.settings_demo
pause
