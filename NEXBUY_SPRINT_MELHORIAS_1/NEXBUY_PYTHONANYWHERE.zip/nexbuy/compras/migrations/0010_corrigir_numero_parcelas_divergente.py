# Migration de dados (Gate pré-Etapa 10, S1-4): `numero_parcelas` só era
# preenchido de verdade para o prazo Personalizado — para 30/60 e 30/60/90
# ficava no valor padrão 1 mesmo a Compra gerando 2 e 3 parcelas reais.
# Auditoria externa independente encontrou essa divergência num banco de
# demonstração real (Compra #402 prazo 30_60 com numero_parcelas=1 e 2
# parcelas reais; Compra #404 prazo 30_60_90 com numero_parcelas=1 e 3
# parcelas reais). `compras/services.py` já foi corrigido para nunca mais
# gravar esse valor errado — esta migration corrige o que já existia.
#
# Idempotente: para cada Compra, se já tem parcelas materializadas, usa a
# contagem REAL; senão (Pendente/Bloqueada, nunca aprovada), recalcula
# estruturalmente a partir do prazo — mesma regra de
# `compras.services.calcular_numero_parcelas`, reimplementada aqui sem
# importar o app (migrations não devem depender do código "vivo", que pode
# mudar; o cálculo é só aritmética sobre `prazo_pagamento`).
from django.db import migrations

_QUANTIDADE_POR_PRAZO_COMPOSTO = {"30_60": 2, "30_60_90": 3}


def corrigir_numero_parcelas(apps, schema_editor):
    Compra = apps.get_model("compras", "Compra")
    ParcelaCompra = apps.get_model("compras", "ParcelaCompra")

    for compra in Compra.objects.all().iterator():
        contagem_real = ParcelaCompra.objects.filter(compra=compra).count()
        if contagem_real:
            correto = contagem_real
        elif compra.prazo_pagamento in _QUANTIDADE_POR_PRAZO_COMPOSTO:
            correto = _QUANTIDADE_POR_PRAZO_COMPOSTO[compra.prazo_pagamento]
        elif compra.prazo_pagamento == "personalizado":
            correto = max(compra.numero_parcelas or 1, 1)
        else:
            correto = 1

        if compra.numero_parcelas != correto:
            Compra.objects.filter(pk=compra.pk).update(numero_parcelas=correto)


def reverter_noop(apps, schema_editor):
    # Não há como reverter com segurança (o valor errado original não é
    # recuperável) — e não há motivo de negócio para querer reverter uma
    # correção de dados. RunPython exige um reverse_code explícito.
    pass


class Migration(migrations.Migration):

    dependencies = [
        ("compras", "0009_compra_provisao_origem"),
    ]

    operations = [
        migrations.RunPython(corrigir_numero_parcelas, reverter_noop),
    ]
