import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cadastros', '0001_initial'),
        ('compras', '0002_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='fornecedor',
            name='nome',
            field=models.CharField(max_length=200, verbose_name='Nome Fantasia'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='razao_social',
            field=models.CharField(blank=True, max_length=200, verbose_name='Razão Social'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='inscricao_estadual',
            field=models.CharField(blank=True, max_length=20, verbose_name='Inscrição Estadual'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='telefone',
            field=models.CharField(blank=True, max_length=20, verbose_name='Telefone'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='whatsapp',
            field=models.CharField(blank=True, max_length=20, verbose_name='WhatsApp'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='email',
            field=models.EmailField(blank=True, max_length=254, verbose_name='E-mail'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='cidade',
            field=models.CharField(blank=True, max_length=100, verbose_name='Cidade'),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='estado',
            field=models.CharField(
                blank=True,
                choices=[
                    ('', '---------'), ('AC', 'AC'), ('AL', 'AL'), ('AP', 'AP'), ('AM', 'AM'),
                    ('BA', 'BA'), ('CE', 'CE'), ('DF', 'DF'), ('ES', 'ES'), ('GO', 'GO'),
                    ('MA', 'MA'), ('MT', 'MT'), ('MS', 'MS'), ('MG', 'MG'), ('PA', 'PA'),
                    ('PB', 'PB'), ('PR', 'PR'), ('PE', 'PE'), ('PI', 'PI'), ('RJ', 'RJ'),
                    ('RN', 'RN'), ('RS', 'RS'), ('RO', 'RO'), ('RR', 'RR'), ('SC', 'SC'),
                    ('SP', 'SP'), ('SE', 'SE'), ('TO', 'TO'),
                ],
                max_length=2,
                verbose_name='Estado',
            ),
        ),
        migrations.AddField(
            model_name='fornecedor',
            name='observacoes',
            field=models.TextField(blank=True, verbose_name='Observações'),
        ),
        migrations.AddField(
            model_name='compra',
            name='categoria_fk',
            field=models.ForeignKey(
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name='compras',
                to='cadastros.categoria',
                verbose_name='Categoria',
            ),
        ),
        migrations.AddField(
            model_name='compra',
            name='centro_custo',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='compras',
                to='cadastros.centrocusto',
                verbose_name='Centro de Custo',
            ),
        ),
    ]
