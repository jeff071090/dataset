from django.db import migrations

LABELS_ANTIGOS = {
    'medicamentos': 'Medicamentos',
    'higiene': 'Higiene',
    'perfumaria': 'Perfumaria',
    'servicos': 'Serviços',
    'outros': 'Outros',
}
CODIGOS_ANTIGOS = {v: k for k, v in LABELS_ANTIGOS.items()}


def migrar_para_fk(apps, schema_editor):
    Compra = apps.get_model('compras', 'Compra')
    Categoria = apps.get_model('cadastros', 'Categoria')

    for compra in Compra.objects.all():
        nome = LABELS_ANTIGOS.get(compra.categoria, 'Outros')
        categoria, _ = Categoria.objects.get_or_create(
            empresa_id=compra.empresa_id, nome=nome, defaults={'ativo': True}
        )
        compra.categoria_fk_id = categoria.id
        compra.save(update_fields=['categoria_fk'])


def reverter_para_texto(apps, schema_editor):
    Compra = apps.get_model('compras', 'Compra')

    for compra in Compra.objects.all():
        if compra.categoria_fk_id:
            nome = compra.categoria_fk.nome
            compra.categoria = CODIGOS_ANTIGOS.get(nome, 'outros')
            compra.save(update_fields=['categoria'])


class Migration(migrations.Migration):

    dependencies = [
        ('compras', '0003_fornecedor_campos_categoria_fk_centro_custo'),
    ]

    operations = [
        migrations.RunPython(migrar_para_fk, reverter_para_texto),
    ]
