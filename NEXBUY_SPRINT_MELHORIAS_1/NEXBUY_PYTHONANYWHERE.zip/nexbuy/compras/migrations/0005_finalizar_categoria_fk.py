import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('compras', '0004_migrar_dados_categoria'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='compra',
            name='categoria',
        ),
        migrations.RenameField(
            model_name='compra',
            old_name='categoria_fk',
            new_name='categoria',
        ),
        migrations.AlterField(
            model_name='compra',
            name='categoria',
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name='compras',
                to='cadastros.categoria',
                verbose_name='Categoria',
            ),
        ),
    ]
