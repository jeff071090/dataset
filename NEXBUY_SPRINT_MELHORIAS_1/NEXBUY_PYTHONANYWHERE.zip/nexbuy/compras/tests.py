"""Testes do app `compras` (Sprint 4.1 — auditoria técnica, item 7).

Este app ainda não tinha nenhum teste automatizado antes da Sprint 4.1,
apesar de concentrar a regra de negócio mais sensível do sistema (a Regra de
Excesso de Limite). Cobre aqui, prioritariamente, o que foi adicionado ou
alterado nesta Sprint:

- `HistoricoCompra` — novo log de auditoria (criação, aprovação, rejeição).
- `classificar_dia` — refatorado para reaproveitar
  `finance_engine.calculations.classificar_por_percentual`; os testes de
  borda garantem que o comportamento não mudou.
- Controle de acesso por perfil nas telas de aprovação.

Rode com: python manage.py test compras
"""
from datetime import date
from decimal import Decimal

from django.test import Client, TestCase
from django.test.utils import override_settings

from cadastros.models import Categoria
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, Receita
from usuarios.models import Usuario

from .forms import CompraForm
from .models import Compra, Fornecedor, HistoricoCompra
from .services import (
    CompraJaDecididaError,
    aprovar_compra_pendente,
    avaliar_e_criar_compra,
    classificar_dia,
    rejeitar_compra_pendente,
)
from core.utils_testes import garantir_capacidade_no_dia

ANO, MES = 2026, 6
DIAS_UTEIS_FIXO = 20


class HistoricoCompraTestCase(TestCase):
    """Auditoria da Compra (Sprint 4.1, item 5): toda criação, aprovação e
    rejeição deve deixar um rastro em `HistoricoCompra`."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Compras", cnpj="33.000.000/0001-33")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa,
            percentual_compras=Decimal("50"),
            dias_uteis_manual=DIAS_UTEIS_FIXO,
            regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 100000 * 0.5 / 20 = 2500
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Teste")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Teste")
        self.comprador = Usuario.objects.create_user(
            username="comprador_hist", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_hist", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )

    def _criar_compra(self, valor):
        return avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal(valor), categoria=self.categoria,
            data_compra=date(ANO, MES, 5), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, usuario=self.comprador,
        )

    def test_criar_compra_registra_historico_de_criacao(self):
        avaliacao = self._criar_compra("1000")
        self.assertTrue(
            HistoricoCompra.objects.filter(compra=avaliacao.compra, acao=HistoricoCompra.Acao.CRIACAO).exists()
        )

    def test_aprovar_compra_pendente_registra_historico_com_usuario(self):
        avaliacao = self._criar_compra("3000")  # acima do limite -> pendente
        self.assertEqual(avaliacao.compra.status, Compra.Status.PENDENTE)

        aprovar_compra_pendente(avaliacao.compra, self.gerente)

        historico = HistoricoCompra.objects.get(compra=avaliacao.compra, acao=HistoricoCompra.Acao.APROVACAO)
        self.assertEqual(historico.usuario, self.gerente)

    def test_rejeitar_compra_pendente_registra_historico_com_usuario(self):
        avaliacao = self._criar_compra("3000")

        rejeitar_compra_pendente(avaliacao.compra, self.gerente)

        historico = HistoricoCompra.objects.get(compra=avaliacao.compra, acao=HistoricoCompra.Acao.REJEICAO)
        self.assertEqual(historico.usuario, self.gerente)

    def test_aprovar_compra_pendente_gera_evento_na_central_de_auditoria(self):
        """Gate pré-Etapa 10 (S1-3): decisões sobre Compra pendente também
        são "ações críticas" — não só o lançamento inicial."""
        from auditoria.models import RegistroAuditoria

        avaliacao = self._criar_compra("3000")
        aprovar_compra_pendente(avaliacao.compra, self.gerente)
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.COMPRA_LANCADA, acao="aprovar_pendente",
            id_objeto=avaliacao.compra.pk,
        )
        self.assertEqual(registro.usuario, self.gerente)
        self.assertFalse(registro.autoaprovacao)
        self.assertEqual(registro.correlation_id, f"compra-{avaliacao.compra.pk}")

    def test_rejeitar_compra_pendente_gera_evento_na_central_de_auditoria(self):
        from auditoria.models import RegistroAuditoria

        avaliacao = self._criar_compra("3000")
        rejeitar_compra_pendente(avaliacao.compra, self.gerente)
        registro = RegistroAuditoria.objects.get(
            categoria=RegistroAuditoria.Categoria.COMPRA_BLOQUEADA, acao="rejeitar_pendente",
            id_objeto=avaliacao.compra.pk,
        )
        # Gate D (Prompt 2, Seção 10): rejeição CONCLUÍDA é SUCESSO do
        # evento de auditoria, não FALHA — a decisão de negócio foi tomada
        # e registrada corretamente; "falha" é para operação que não se
        # completou (ex.: CompraJaDecididaError).
        self.assertEqual(registro.resultado, RegistroAuditoria.Resultado.SUCESSO)


class ClassificarDiaTestCase(TestCase):
    """`classificar_dia` (compras) e `classificar_consumo` (finance_engine)
    passaram a reaproveitar o mesmo limiar (Sprint 4.1, item 3 — status
    centralizado). Estes casos de borda garantem que nenhum dos dois
    comportamentos históricos mudou."""

    def test_limite_zero_sem_compra_fica_verde(self):
        cor, proporcao = classificar_dia(Decimal("0"), Decimal("0"))
        self.assertEqual(cor, "verde")
        self.assertEqual(proporcao, Decimal("0"))

    def test_limite_zero_com_compra_fica_vermelho(self):
        cor, proporcao = classificar_dia(Decimal("100"), Decimal("0"))
        self.assertEqual(cor, "vermelho")
        self.assertEqual(proporcao, Decimal("2"))

    def test_exatamente_no_limite_fica_laranja(self):
        cor, _ = classificar_dia(Decimal("800"), Decimal("1000"))
        self.assertEqual(cor, "laranja")  # 80% exatos

    def test_acima_do_limite_fica_vermelho(self):
        cor, _ = classificar_dia(Decimal("1001"), Decimal("1000"))
        self.assertEqual(cor, "vermelho")

    def test_abaixo_de_80_por_cento_fica_verde(self):
        cor, _ = classificar_dia(Decimal("799"), Decimal("1000"))
        self.assertEqual(cor, "verde")


class PermissaoAprovacaoCompraTestCase(TestCase):
    """Controle de acesso da tela de aprovação de Compra (Sprint 4.1, item
    4): só o Gerente pode ver e decidir; Comprador é sempre bloqueado."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste Permissao", cnpj="44.000.000/0001-44")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        self.comprador = Usuario.objects.create_user(
            username="comprador_perm", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_nao_acessa_tela_de_aprovacao_de_compra(self):
        client = Client()
        client.force_login(self.comprador)
        response = client.get("/compras/aprovacao/")
        self.assertEqual(response.status_code, 403)


class GateAProprietarioOperacionalTestCase(TestCase):
    """Prompt 2 (pré-Etapa 02), Gate A: o Proprietário Operacional é ator
    real da operação (lança Compra, decide Compra acima do limite) — o QA
    anterior registrou incorretamente como esperado que ele recebesse 403
    nessas rotas. `demo_proprietario`-like fixture: perfil PROPRIETARIO,
    is_staff=False, is_superuser=False."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Gate A", cnpj="55.000.000/0001-55")
        self.filial = Filial.objects.create(
            empresa=self.empresa, nome="Matriz", tipo_estabelecimento=Filial.TipoEstabelecimento.MATRIZ,
        )
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
        )
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(self.empresa)
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Gate A")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Gate A")
        self.proprietario = Usuario.objects.create_user(
            username="prop_gate_a", password="x", perfil=Usuario.Perfil.PROPRIETARIO,
            empresa=self.empresa, is_staff=False, is_superuser=False,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_gate_a", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        self.client = Client()

    def test_proprietario_nao_e_staff_nem_superuser(self):
        self.assertFalse(self.proprietario.is_staff)
        self.assertFalse(self.proprietario.is_superuser)

    def test_proprietario_acessa_get_de_nova_compra(self):
        self.client.force_login(self.proprietario)
        response = self.client.get("/compras/nova/")
        self.assertEqual(response.status_code, 200)

    def test_proprietario_lanca_compra_dentro_do_limite(self):
        self.client.force_login(self.proprietario)
        response = self.client.post(
            "/compras/nova/",
            {
                "filial": self.filial.pk, "fornecedor": self.fornecedor.pk, "valor": "50,00",
                "categoria": self.categoria.pk, "data_compra": date.today().isoformat(),
                "prazo_pagamento": Compra.PrazoPagamento.AVISTA,
            },
        )
        self.assertEqual(response.status_code, 302)
        compra = Compra.objects.get(fornecedor=self.fornecedor, filial=self.filial)
        self.assertEqual(compra.usuario_id, self.proprietario.pk)
        self.assertEqual(compra.status, Compra.Status.APROVADA)

    def test_proprietario_acessa_central_de_aprovacao_de_compra(self):
        self.client.force_login(self.proprietario)
        response = self.client.get("/compras/aprovacao/")
        self.assertEqual(response.status_code, 200)

    def test_proprietario_decide_compra_acima_do_limite(self):
        from .services import avaliar_e_criar_compra

        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("99999999"),
            categoria=self.categoria, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None, usuario=self.gerente,
        )
        compra = avaliacao.compra
        self.assertEqual(compra.status, Compra.Status.PENDENTE)
        self.client.force_login(self.proprietario)
        response = self.client.post(f"/compras/aprovacao/{compra.pk}/aprovar/")
        self.assertEqual(response.status_code, 302)
        compra.refresh_from_db()
        self.assertEqual(compra.status, Compra.Status.APROVADA)

    def test_proprietario_nao_aprova_a_propria_compra_pendente_por_padrao(self):
        """Autoaprovação continua bloqueada por padrão mesmo para quem
        agora PODE decidir Compra — separação de funções (Gate A, Seção
        "Autoaprovação")."""
        from .services import AutoaprovacaoBloqueadaError, avaliar_e_criar_compra

        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("99999999"),
            categoria=self.categoria, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None, usuario=self.proprietario,
        )
        compra = avaliacao.compra
        self.client.force_login(self.proprietario)
        response = self.client.post(f"/compras/aprovacao/{compra.pk}/aprovar/", follow=True)
        self.assertEqual(response.status_code, 200)
        compra.refresh_from_db()
        self.assertEqual(compra.status, Compra.Status.PENDENTE)
        from .services import aprovar_compra_pendente

        with self.assertRaises(AutoaprovacaoBloqueadaError):
            aprovar_compra_pendente(compra, self.proprietario)


class ParcelasCompraTestCase(TestCase):
    """Epico 4 (CORE 1.0): geracao de parcelas por prazo, divisao exata do
    valor e o vinculo com o ciclo de aprovacao da Compra."""

    def setUp(self):
        from empresas.models import Empresa
        from filiais.models import Filial
        from financeiro.models import ConfiguracaoFinanceira, Receita
        from cadastros.models import Categoria

        self.empresa = Empresa.objects.create(nome="Empresa Parcelas", cnpj="80.000.000/0001-80")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        # Regra "Solicitar Aprovação" desde o início: os valores pequenos dos
        # testes de parcela ficam bem abaixo do limite diário (aprovados
        # direto) e o teste de compra pendente usa um valor estourado.
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO
        )
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(self.empresa)
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor P")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria P")
        self.comprador = Usuario.objects.create_user("pc_comprador", password="x")
        self.comprador.perfil = Usuario.Perfil.COMPRADOR
        self.comprador.empresa = self.empresa
        self.comprador.filial = self.filial
        self.comprador.save()
        # Fechamento Final (Seção 6): aprovação usa um usuário DIFERENTE de
        # quem lançou a compra — autoaprovação é bloqueada por padrão, e
        # este teste é sobre geração de parcelas, não sobre quem aprova.
        self.gerente = Usuario.objects.create_user("pc_gerente", password="x")
        self.gerente.perfil = Usuario.Perfil.GERENTE
        self.gerente.empresa = self.empresa
        self.gerente.filial = self.filial
        self.gerente.save()

    def _criar(self, valor, prazo, dias=None, parcelas=1):
        from .services import avaliar_e_criar_compra

        return avaliar_e_criar_compra(
            filial=self.filial,
            fornecedor=self.fornecedor,
            valor=valor,
            categoria=self.categoria,
            data_compra=date.today(),
            prazo_pagamento=prazo,
            prazo_personalizado_dias=dias,
            numero_parcelas=parcelas,
            usuario=self.comprador,
        ).compra

    def test_30_60_90_gera_tres_parcelas_com_soma_exata(self):
        from datetime import timedelta

        compra = self._criar(Decimal("100.00"), Compra.PrazoPagamento.D30_60_90)
        parcelas = list(compra.parcelas.order_by("numero"))
        self.assertEqual(len(parcelas), 3)
        self.assertEqual(sum(p.valor for p in parcelas), Decimal("100.00"))
        self.assertEqual(parcelas[0].data_vencimento, compra.data_compra + timedelta(days=30))
        self.assertEqual(parcelas[2].data_vencimento, compra.data_compra + timedelta(days=90))
        # 100/3 = 33,33 + 33,33 + 33,34 (a ultima absorve o arredondamento)
        self.assertEqual(parcelas[2].valor, Decimal("33.34"))

    def test_avista_gera_uma_parcela_no_dia_da_compra(self):
        compra = self._criar(Decimal("50.00"), Compra.PrazoPagamento.AVISTA)
        parcelas = list(compra.parcelas.all())
        self.assertEqual(len(parcelas), 1)
        self.assertEqual(parcelas[0].data_vencimento, compra.data_compra)

    def test_personalizado_gera_n_parcelas_com_intervalo(self):
        from datetime import timedelta

        compra = self._criar(Decimal("400.00"), Compra.PrazoPagamento.PERSONALIZADO, dias=15, parcelas=4)
        parcelas = list(compra.parcelas.order_by("numero"))
        self.assertEqual(len(parcelas), 4)
        self.assertEqual(parcelas[0].data_vencimento, compra.data_compra + timedelta(days=15))
        self.assertEqual(parcelas[3].data_vencimento, compra.data_compra + timedelta(days=60))

    def test_compra_pendente_so_gera_parcelas_na_aprovacao(self):
        compra = self._criar(Decimal("9999999.00"), Compra.PrazoPagamento.D30)
        self.assertEqual(compra.status, Compra.Status.PENDENTE)
        self.assertEqual(compra.parcelas.count(), 0)

        from .services import aprovar_compra_pendente

        aprovar_compra_pendente(compra, self.gerente)
        self.assertEqual(compra.parcelas.count(), 1)

    def test_limite_individual_forca_aprovacao(self):
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("100.00"), ativo=True
        )
        compra = self._criar(Decimal("150.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(compra.status, Compra.Status.PENDENTE)

        # Sprint de Consolidação (Gate 2A, Parte 2 — decisão de negócio): o
        # limite individual é uma DOTAÇÃO DIÁRIA ACUMULADA. A primeira
        # compra (150,00) ficou PENDENTE mas já está "reservando" dotação
        # (mesma convenção de STATUS_CONSIDERADOS_NO_TOTAL_DIARIO usada em
        # toda a capacidade do sistema) — uma segunda compra no MESMO dia
        # soma-se a ela, então mesmo 90,00 (que sozinho caberia nos 100,00)
        # também vai para aprovação: 150 + 90 = 240 > 100.
        segunda_no_mesmo_dia = self._criar(Decimal("90.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(segunda_no_mesmo_dia.status, Compra.Status.PENDENTE)

    def test_dotacao_diaria_acumulada_exemplo_oficial_5000(self):
        """Exemplo literal do Gate 2A / decisão de negócio: dotação de
        R$ 5.000/dia. Uma compra de R$ 3.000 cabe (aprovada, saldo 2.000).
        Uma SEGUNDA compra de R$ 3.000 no mesmo dia NÃO pode passar
        automaticamente (3.000 + 3.000 = 6.000 > 5.000 de dotação)."""
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("5000.00"), ativo=True
        )
        primeira = self._criar(Decimal("3000.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(primeira.status, Compra.Status.APROVADA)

        segunda = self._criar(Decimal("3000.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(segunda.status, Compra.Status.PENDENTE)
        historico = HistoricoCompra.objects.get(compra=segunda, acao=HistoricoCompra.Acao.CRIACAO)
        self.assertIn("Dotação diária", historico.detalhe)

    def test_dotacao_diaria_com_saldo_exato_ainda_aprova(self):
        """Limite positivo, uso exatamente no limite: 5.000 de dotação,
        3.000 já gastos, tentativa de mais 2.000 — soma bate EXATAMENTE no
        limite (não o excede) e deve aprovar."""
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("5000.00"), ativo=True
        )
        self._criar(Decimal("3000.00"), Compra.PrazoPagamento.AVISTA)
        no_limite_exato = self._criar(Decimal("2000.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(no_limite_exato.status, Compra.Status.APROVADA)

    def test_dotacao_diaria_zero_manda_qualquer_compra_para_aprovacao(self):
        """Limite individual ZERO (Financeiro reduziu a dotação a zero sem
        bloquear o comprador) — qualquer valor > 0 já excede."""
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("0.00"), ativo=True
        )
        compra = self._criar(Decimal("10.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(compra.status, Compra.Status.PENDENTE)

    def test_dotacao_diaria_negativa_manda_qualquer_compra_para_aprovacao(self):
        """Limite individual NEGATIVO (dado inconsistente — nunca deveria
        surgir pela UI, mas o motor precisa se comportar com segurança se
        acontecer): gasto_hoje (>= 0) + valor (> 0) é sempre maior que um
        limite negativo, então cai em aprovação — nunca aprova sozinho."""
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("-100.00"), ativo=True
        )
        compra = self._criar(Decimal("10.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(compra.status, Compra.Status.PENDENTE)

    def test_comprador_sem_limite_individual_nao_e_afetado(self):
        """Sem UsuarioEmpresa/limite configurado — comportamento histórico
        preservado: só a capacidade da empresa decide o status."""
        compra = self._criar(Decimal("50.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(compra.status, Compra.Status.APROVADA)

    def test_comprador_bloqueado_barra_mesmo_com_dotacao_disponivel(self):
        """Bloqueio (RC-C03) continua tendo prioridade absoluta sobre a
        dotação diária — mesmo com saldo de dotação disponível."""
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("5000.00"),
            bloqueado=True, ativo=True,
        )
        compra = self._criar(Decimal("10.00"), Compra.PrazoPagamento.AVISTA)
        self.assertEqual(compra.status, Compra.Status.BLOQUEADA)


class NumeroParcelasCorretoTestCase(TestCase):
    """Gate pré-Etapa 10 (S1-4): auditoria externa encontrou Compras com
    `numero_parcelas` divergente da contagem real de `ParcelaCompra` — o
    campo só era preenchido de verdade para o prazo Personalizado, ficando
    1 por padrão para 30/60 e 30/60/90 mesmo com 2 e 3 parcelas reais.
    Cobre todos os prazos, a efetivação de Provisão e o comando de
    diagnóstico novo."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Numero Parcelas", cnpj="93.100.000/0001-93")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=20,
        )
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("1000000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Numero Parcelas")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Numero Parcelas")
        self.comprador = Usuario.objects.create_user(
            "np_comprador", password="x", perfil=Usuario.Perfil.COMPRADOR, empresa=self.empresa, filial=self.filial,
        )

    def _criar(self, prazo, dias=None, parcelas=1):
        from .services import avaliar_e_criar_compra

        return avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("300.00"), categoria=self.categoria,
            data_compra=date.today(), prazo_pagamento=prazo, prazo_personalizado_dias=dias,
            numero_parcelas=parcelas, usuario=self.comprador,
        ).compra

    def test_avista_numero_parcelas_e_um(self):
        compra = self._criar(Compra.PrazoPagamento.AVISTA)
        self.assertEqual(compra.numero_parcelas, 1)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_30_dias_numero_parcelas_e_um(self):
        compra = self._criar(Compra.PrazoPagamento.D30)
        self.assertEqual(compra.numero_parcelas, 1)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_30_60_numero_parcelas_e_dois(self):
        """A regressão exata que a auditoria externa encontrou: prazo 30/60
        gerando 2 parcelas reais mas numero_parcelas ficando 1."""
        compra = self._criar(Compra.PrazoPagamento.D30_60)
        self.assertEqual(compra.numero_parcelas, 2)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_30_60_90_numero_parcelas_e_tres(self):
        compra = self._criar(Compra.PrazoPagamento.D30_60_90)
        self.assertEqual(compra.numero_parcelas, 3)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_personalizado_numero_parcelas_bate_com_o_configurado(self):
        compra = self._criar(Compra.PrazoPagamento.PERSONALIZADO, dias=10, parcelas=5)
        self.assertEqual(compra.numero_parcelas, 5)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_numero_parcelas_correto_mesmo_antes_da_aprovacao(self):
        """Compra Pendente (sem parcelas materializadas ainda) já nasce com
        `numero_parcelas` correto — não precisa esperar a aprovação."""
        gerente = Usuario.objects.create_user(
            "np_gerente", password="x", perfil=Usuario.Perfil.GERENTE, empresa=self.empresa, filial=self.filial,
        )
        # Força Pendente via limite individual bem baixo.
        from usuarios.models import UsuarioEmpresa

        UsuarioEmpresa.objects.create(
            usuario=self.comprador, empresa=self.empresa, limite_compra=Decimal("1.00"), ativo=True,
        )
        compra = self._criar(Compra.PrazoPagamento.D30_60)
        self.assertEqual(compra.status, Compra.Status.PENDENTE)
        self.assertEqual(compra.parcelas.count(), 0)
        self.assertEqual(compra.numero_parcelas, 2)  # correto mesmo sem parcela materializada

        from .services import aprovar_compra_pendente

        aprovar_compra_pendente(compra, gerente)
        compra.refresh_from_db()
        self.assertEqual(compra.numero_parcelas, 2)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_efetivacao_de_provisao_gera_numero_parcelas_correto(self):
        """Mesma regra também na Compra que nasce da efetivação de uma
        Provisão (gestao_compras.services.efetivar_provisao) — segundo
        ponto de criação de Compra que tinha o mesmo bug."""
        from gestao_compras.services import criar_provisao, efetivar_provisao, motor_aprovacao_provisao

        provisao, solicitacao, _ = criar_provisao(
            filial=self.filial, comprador=self.comprador, fornecedor=self.fornecedor, categoria=self.categoria,
            data_provisao=date.today(), observacoes="",
            itens_dados=[{"produto": "Item", "quantidade": 1, "valor_unitario": 300}],
        )
        if solicitacao is not None:
            gerente = Usuario.objects.create_user(
                "np_gerente_efetivacao", password="x", perfil=Usuario.Perfil.GERENTE,
                empresa=self.empresa, filial=self.filial,
            )
            motor_aprovacao_provisao.aprovar(solicitacao, gerente, "Aprovado no teste")
        else:
            provisao.status = provisao.Status.APROVADA
            provisao.save(update_fields=["status", "atualizado_em"])

        compra, _ = efetivar_provisao(
            provisao_id=provisao.pk, usuario=self.comprador, prazo_pagamento=Compra.PrazoPagamento.D30_60_90,
        )
        self.assertEqual(compra.numero_parcelas, 3)
        self.assertEqual(compra.numero_parcelas, compra.parcelas.count())

    def test_diagnostico_nao_encontra_divergencia_apos_criacao_correta(self):
        from io import StringIO

        from django.core.management import call_command

        self._criar(Compra.PrazoPagamento.D30_60)
        self._criar(Compra.PrazoPagamento.D30_60_90)
        saida = StringIO()
        call_command("diagnosticar_numero_parcelas", stdout=saida)
        self.assertIn("Nenhuma divergência", saida.getvalue())

    def test_diagnostico_falha_quando_ha_divergencia_manual(self):
        """Simula um dado corrompido manualmente (bypassando o service) para
        provar que o comando de diagnóstico realmente detecta e falha."""
        from django.core.management import call_command
        from django.core.management.base import CommandError

        compra = self._criar(Compra.PrazoPagamento.D30_60)
        Compra.objects.filter(pk=compra.pk).update(numero_parcelas=1)
        with self.assertRaises(CommandError):
            call_command("diagnosticar_numero_parcelas")


class CoerenciaMultiempresaFornecedorTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, P0-5): editar/excluir/reativar um
    Fornecedor precisa respeitar a EMPRESA ATIVA do contexto (que pode ser
    diferente da empresa "de casa" do usuário quando ele tem autorização
    para outra empresa do grupo) — nunca `request.user.empresa` fixo.
    Antes da correção, a listagem já usava a empresa ativa mas a
    edição/exclusão continuavam presas à empresa de casa: um 404
    incoerente ao tentar agir sobre um registro que a própria tela
    acabou de mostrar."""

    def setUp(self):
        from usuarios.models import UsuarioEmpresa

        self.empresa_a = Empresa.objects.create(nome="Empresa A", cnpj="10.000.000/0001-10")
        self.empresa_b = Empresa.objects.create(nome="Empresa B", cnpj="20.000.000/0001-20")
        self.empresa_intrusa = Empresa.objects.create(nome="Intrusa", cnpj="30.000.000/0001-30")

        self.fornecedor_b = Fornecedor.objects.create(
            empresa=self.empresa_b, nome="Fornecedor B", razao_social="Fornecedor B Ltda",
            cnpj="20.000.000/0002-20",
        )
        self.fornecedor_intrusa = Fornecedor.objects.create(
            empresa=self.empresa_intrusa, nome="Fornecedor Intrusa", razao_social="Intrusa Ltda",
            cnpj="30.000.000/0002-30",
        )

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_multiempresa", password="x",
            perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa_a,
        )
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def _trocar_para_empresa_b(self):
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_fornecedor_da_empresa_ativa_autorizada_funciona(self):
        self._trocar_para_empresa_b()
        resposta = self.client.get(f"/compras/fornecedores/{self.fornecedor_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 200)

        resposta = self.client.post(
            f"/compras/fornecedores/{self.fornecedor_b.pk}/editar/",
            {"nome": "Fornecedor B Renomeado", "razao_social": "Fornecedor B Ltda", "cnpj": "20.000.000/0002-20"},
        )
        self.assertEqual(resposta.status_code, 302)
        self.fornecedor_b.refresh_from_db()
        self.assertEqual(self.fornecedor_b.nome, "Fornecedor B Renomeado")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_e_reativar_fornecedor_da_empresa_ativa_funciona(self):
        self._trocar_para_empresa_b()
        resposta = self.client.post(f"/compras/fornecedores/{self.fornecedor_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 302)
        self.fornecedor_b.refresh_from_db()
        self.assertFalse(self.fornecedor_b.ativo)

        resposta = self.client.post(f"/compras/fornecedores/{self.fornecedor_b.pk}/reativar/")
        self.assertEqual(resposta.status_code, 302)
        self.fornecedor_b.refresh_from_db()
        self.assertTrue(self.fornecedor_b.ativo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_fornecedor_de_empresa_nao_ativa_continua_inacessivel(self):
        """Sem trocar de contexto, a empresa ativa continua sendo a "de
        casa" (A) — o fornecedor da empresa B, mesmo autorizada, não pode
        ser editado/excluído só porque o usuário conhece o pk."""
        resposta = self.client.get(f"/compras/fornecedores/{self.fornecedor_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)

        resposta = self.client.post(f"/compras/fornecedores/{self.fornecedor_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_fornecedor_de_empresa_nao_autorizada_nunca_e_acessivel(self):
        """Isolamento de tenant continua absoluto: trocar para B não abre
        acesso à empresa Intrusa, para a qual não existe autorização."""
        self._trocar_para_empresa_b()
        resposta = self.client.get(f"/compras/fornecedores/{self.fornecedor_intrusa.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)


class RelatoriosCSVTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, P1-6, testes obrigatórios): a
    exportação CSV nunca pode mostrar mais do que a tela já mostra — nem
    de outra empresa (CNPJ), nem de outro perfil."""

    def setUp(self):
        from usuarios.models import UsuarioEmpresa, UsuarioFilial

        self.empresa_a = Empresa.objects.create(nome="Empresa A CSV", cnpj="40.000.000/0001-40")
        self.empresa_b = Empresa.objects.create(nome="Empresa B CSV", cnpj="50.000.000/0001-50")
        self.filial_a = Filial.objects.create(empresa=self.empresa_a, nome="Filial A")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial B")

        for empresa in (self.empresa_a, self.empresa_b):
            ConfiguracaoFinanceira.objects.create(
                empresa=empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO
            )
        Receita.objects.create(filial=self.filial_a, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        Receita.objects.create(filial=self.filial_b, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(self.empresa_a)
        garantir_capacidade_no_dia(self.empresa_b)

        self.fornecedor_a = Fornecedor.objects.create(empresa=self.empresa_a, nome="Fornecedor CSV A")
        self.fornecedor_b = Fornecedor.objects.create(empresa=self.empresa_b, nome="Fornecedor CSV B")
        self.categoria_a = Categoria.objects.create(empresa=self.empresa_a, nome="Categoria CSV A")
        self.categoria_b = Categoria.objects.create(empresa=self.empresa_b, nome="Categoria CSV B")

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_csv", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)
        # `UsuarioEmpresa` autoriza a EMPRESA; `UsuarioFilial` autoriza a
        # FILIAL dentro dela (Seção 7) — o Financeiro deste teste precisa
        # dos dois vínculos nas DUAS empresas (inclusive a própria, A, já
        # que ganhar qualquer vínculo explícito tira o usuário do modo de
        # compatibilidade que cai automaticamente na filial principal).
        UsuarioFilial.objects.create(usuario=self.financeiro, filial=self.filial_a, ativo=True)
        UsuarioFilial.objects.create(usuario=self.financeiro, filial=self.filial_b, ativo=True)

        self.comprador1 = Usuario.objects.create_user(
            username="comprador_csv1", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        self.comprador2 = Usuario.objects.create_user(
            username="comprador_csv2", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        # Comprador nativo da empresa B — só para gerar a compra "intrusa"
        # abaixo (Seção 11 do Sprint de Correções Críticas: o service agora
        # revalida que o comprador está autorizado na filial da compra;
        # `comprador1` pertence à empresa A e não deve ganhar autorização
        # cruzada só para essa massa de teste).
        self.comprador_b = Usuario.objects.create_user(
            username="comprador_csv_b", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_b, filial=self.filial_b,
        )

        avaliar_e_criar_compra(
            filial=self.filial_a, fornecedor=self.fornecedor_a, valor=Decimal("100.00"),
            categoria=self.categoria_a, centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            usuario=self.comprador1, observacao="Compra do comprador 1 [CSV1]",
        )
        avaliar_e_criar_compra(
            filial=self.filial_a, fornecedor=self.fornecedor_a, valor=Decimal("50.00"),
            categoria=self.categoria_a, centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            usuario=self.comprador2, observacao="Compra do comprador 2 [CSV2]",
        )
        avaliar_e_criar_compra(
            filial=self.filial_b, fornecedor=self.fornecedor_b, valor=Decimal("999.00"),
            categoria=self.categoria_b, centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            usuario=self.comprador_b, observacao="Compra da empresa B [CSVB]",
        )

        self.client = Client()

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_csv_de_historico_respeita_a_empresa_ativa_cnpj(self):
        self.client.force_login(self.financeiro)
        conteudo = self.client.get("/compras/lista/?formato=csv").content.decode("utf-8-sig")
        self.assertIn("Fornecedor CSV A", conteudo)
        self.assertNotIn("Fornecedor CSV B", conteudo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_csv_de_historico_respeita_o_perfil_do_comprador(self):
        """O Comprador exporta só as PRÓPRIAS compras — nunca as de outro
        comprador da mesma empresa."""
        self.client.force_login(self.comprador1)
        conteudo = self.client.get("/compras/lista/?formato=csv").content.decode("utf-8-sig")
        self.assertIn("comprador_csv1", conteudo)
        self.assertNotIn("comprador_csv2", conteudo)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorios_agregados_bloqueados_para_comprador(self):
        self.client.force_login(self.comprador1)
        self.assertEqual(self.client.get("/compras/relatorios/por-comprador/").status_code, 403)
        self.assertEqual(self.client.get("/compras/relatorios/por-filial/").status_code, 403)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_csv_por_filial_respeita_a_empresa_ativa_cnpj(self):
        """Financeiro autorizado nas duas empresas: sem trocar de contexto,
        só a filial da empresa A aparece; depois de trocar, só a de B."""
        self.client.force_login(self.financeiro)

        conteudo_a = self.client.get("/compras/relatorios/por-filial/?formato=csv").content.decode("utf-8-sig")
        self.assertIn("Filial A", conteudo_a)
        self.assertNotIn("Filial B", conteudo_a)

        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)

        conteudo_b = self.client.get("/compras/relatorios/por-filial/?formato=csv").content.decode("utf-8-sig")
        self.assertIn("Filial B", conteudo_b)
        self.assertNotIn("Filial A", conteudo_b)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_csv_por_comprador_soma_os_valores_certos(self):
        self.client.force_login(self.financeiro)
        conteudo = self.client.get("/compras/relatorios/por-comprador/?formato=csv").content.decode("utf-8-sig")
        linhas = [linha for linha in conteudo.splitlines() if linha]
        self.assertIn("Comprador;Qtd. Compras;Total (R$)", linhas[0])
        self.assertTrue(any("100,00" in linha for linha in linhas))
        self.assertTrue(any("50,00" in linha for linha in linhas))


class CompraFormMultifilialTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 11): o Comprador (e qualquer
    perfil operacional) pode lançar Compra em qualquer filial autorizada —
    1, várias ou nenhuma — nunca mais travado na filial principal fixa."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Multifilial", cnpj="60.000.000/0001-60")
        self.filial1 = Filial.objects.create(empresa=self.empresa, nome="Filial 1")
        self.filial2 = Filial.objects.create(empresa=self.empresa, nome="Filial 2")
        self.comprador = Usuario.objects.create_user(
            username="comprador_multi", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial1,
        )

    def test_comprador_com_uma_filial_autorizada_ve_so_ela_e_ja_vem_preenchida(self):
        from usuarios.models import UsuarioFilial

        UsuarioFilial.objects.create(usuario=self.comprador, filial=self.filial1, ativo=True)
        form = CompraForm(user=self.comprador, empresa=self.empresa)
        self.assertEqual(list(form.fields["filial"].queryset), [self.filial1])
        self.assertEqual(form.fields["filial"].initial, self.filial1)

    def test_comprador_com_duas_filiais_autorizadas_ve_as_duas(self):
        from usuarios.models import UsuarioFilial

        UsuarioFilial.objects.create(usuario=self.comprador, filial=self.filial1, ativo=True)
        UsuarioFilial.objects.create(usuario=self.comprador, filial=self.filial2, ativo=True)
        form = CompraForm(user=self.comprador, empresa=self.empresa)
        self.assertEqual(set(form.fields["filial"].queryset), {self.filial1, self.filial2})

    def test_comprador_sem_nenhuma_filial_autorizada_nunca_consegue_submeter_uma(self):
        """Vínculo explícito só em OUTRA empresa tira o comprador do modo de
        compatibilidade (que cairia na filial principal) — dentro desta
        empresa ele não vê, e não consegue submeter, nenhuma filial."""
        from usuarios.models import UsuarioFilial

        outra_empresa = Empresa.objects.create(nome="Outra Empresa Multifilial", cnpj="61.000.000/0001-61")
        outra_filial = Filial.objects.create(empresa=outra_empresa, nome="Filial Outra")
        UsuarioFilial.objects.create(usuario=self.comprador, filial=outra_filial, ativo=True)

        form = CompraForm(user=self.comprador, empresa=self.empresa)
        self.assertEqual(list(form.fields["filial"].queryset), [])

        form_submetido = CompraForm({"filial": self.filial1.pk}, user=self.comprador, empresa=self.empresa)
        self.assertFalse(form_submetido.is_valid())
        self.assertIn("filial", form_submetido.errors)


class ConcorrenciaCompraTestCase(TestCase):
    """Sprint de Correções Críticas (Seção 14): duas decisões sobre a MESMA
    Compra pendente (duplo clique, ou dois Gerentes decidindo ao mesmo
    tempo em abas diferentes) — a segunda tentativa encontra o status já
    mudado dentro da transação travada e é rejeitada com um erro de
    domínio, nunca aprova/rejeita duas vezes nem duplica parcelas."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Concorrencia Compra", cnpj="70.000.000/0001-70")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO
        )
        Receita.objects.create(filial=self.filial, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Concorrencia")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Concorrencia")
        self.comprador = Usuario.objects.create_user(
            username="comprador_concorrencia", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.gerente = Usuario.objects.create_user(
            username="gerente_concorrencia", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        # Valor bem acima do limite diário (baseado num faturamento de
        # 500.000) — garante PENDENTE de forma determinística, no mesmo
        # padrão já usado por `ParcelasCompraTestCase`.
        self.compra = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("9999999.00"), categoria=self.categoria,
            data_compra=date.today(), prazo_pagamento=Compra.PrazoPagamento.D30,
            prazo_personalizado_dias=None, usuario=self.comprador,
        ).compra
        self.assertEqual(self.compra.status, Compra.Status.PENDENTE)

    def test_segunda_aprovacao_da_mesma_compra_e_rejeitada_com_erro_de_dominio(self):
        aprovar_compra_pendente(self.compra, self.gerente)
        with self.assertRaises(CompraJaDecididaError):
            aprovar_compra_pendente(self.compra, self.gerente)

    def test_aprovar_e_depois_rejeitar_a_mesma_compra_e_rejeitado_com_erro_de_dominio(self):
        aprovar_compra_pendente(self.compra, self.gerente)
        with self.assertRaises(CompraJaDecididaError):
            rejeitar_compra_pendente(self.compra, self.gerente)

    def test_dupla_aprovacao_nao_duplica_parcelas(self):
        aprovar_compra_pendente(self.compra, self.gerente)
        try:
            aprovar_compra_pendente(self.compra, self.gerente)
        except CompraJaDecididaError:
            pass
        self.compra.refresh_from_db()
        self.assertEqual(self.compra.parcelas.count(), 1)


class FornecedorCrossGrupoTestCase(TestCase):
    """Fechamento Final (Seção 4.3): variante cross-GRUPO do teste de
    coerência multiempresa de Fornecedor já existente acima
    (`CoerenciaMultiempresaFornecedorTestCase`), que só cobria cross-empresa
    dentro do mesmo Grupo (ou sem Grupo cadastrado). Aqui as duas empresas
    pertencem a `GrupoEmpresarial` DIFERENTES e comprovadamente não-nulos —
    a semântica de `Usuario.empresas_disponiveis()`. Mesmo com uma
    autorização `UsuarioEmpresa` ATIVA cruzando os dois grupos, o acesso ao
    Fornecedor da empresa do outro Grupo continua bloqueado: o Grupo
    diferente barra por cima da autorização explícita."""

    def setUp(self):
        from empresas.models import GrupoEmpresarial
        from usuarios.models import UsuarioEmpresa

        self.grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo Fornecedor 1")
        self.grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo Fornecedor 2")

        self.empresa_a = Empresa.objects.create(
            nome="Empresa A Cross Grupo", cnpj="90.000.000/0001-90", grupo=self.grupo_1,
        )
        self.empresa_b = Empresa.objects.create(
            nome="Empresa B Cross Grupo", cnpj="91.000.000/0001-91", grupo=self.grupo_2,
        )

        self.fornecedor_b = Fornecedor.objects.create(
            empresa=self.empresa_b, nome="Fornecedor B Cross Grupo",
            razao_social="Fornecedor B Cross Grupo Ltda", cnpj="91.000.000/0002-91",
        )

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_cross_grupo", password="x",
            perfil=Usuario.Perfil.FINANCEIRO, empresa=self.empresa_a,
        )
        # Autorização ATIVA cruzando os dois Grupos — não deve bastar para
        # abrir acesso ao Fornecedor da empresa B.
        UsuarioEmpresa.objects.create(usuario=self.financeiro, empresa=self.empresa_b, ativo=True)

        self.client = Client()
        self.client.force_login(self.financeiro)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_trocar_para_empresa_de_outro_grupo_nao_e_aplicado_mesmo_com_autorizacao_ativa(self):
        """`empresas_disponiveis()` não deve incluir a empresa de outro
        Grupo, então a troca de contexto para ela precisa falhar (a empresa
        ativa continua sendo a "de casa", A)."""
        resposta = self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})
        self.assertEqual(resposta.status_code, 302)

        # Efeito de negócio: se a troca tivesse (indevidamente) sido
        # aplicada, a listagem de fornecedores passaria a mostrar o da
        # empresa B; como o Grupo diverge, ela continua vazia.
        resposta = self.client.get("/compras/fornecedores/")
        self.assertNotContains(resposta, "Fornecedor B Cross Grupo")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_editar_fornecedor_de_outro_grupo_continua_404_mesmo_com_autorizacao_ativa(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})

        resposta = self.client.get(f"/compras/fornecedores/{self.fornecedor_b.pk}/editar/")
        self.assertEqual(resposta.status_code, 404)

        resposta = self.client.post(
            f"/compras/fornecedores/{self.fornecedor_b.pk}/editar/",
            {"nome": "Tentativa Cross Grupo", "razao_social": "X", "cnpj": "91.000.000/0002-91"},
        )
        self.assertEqual(resposta.status_code, 404)
        self.fornecedor_b.refresh_from_db()
        self.assertEqual(self.fornecedor_b.nome, "Fornecedor B Cross Grupo")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_excluir_fornecedor_de_outro_grupo_continua_404_mesmo_com_autorizacao_ativa(self):
        self.client.post("/trocar-empresa/", {"empresa_id": self.empresa_b.pk})

        resposta = self.client.post(f"/compras/fornecedores/{self.fornecedor_b.pk}/excluir/")
        self.assertEqual(resposta.status_code, 404)
        self.fornecedor_b.refresh_from_db()
        self.assertTrue(self.fornecedor_b.ativo)


class RelatoriosCrossGrupoTestCase(TestCase):
    """Fechamento Final (Seção 4.3): prova end-to-end de que
    `relatorio_compras_por_comprador` e `relatorio_compras_por_filial`
    (Gate 2A, P1-6) NUNCA agregam compras de uma empresa de outro Grupo
    Empresarial — hoje não existe nenhum teste de URL para essas duas
    rotas. Duas `GrupoEmpresarial` distintas, uma Empresa em cada, sem
    nenhuma autorização cruzada: os dois relatórios são escopados por
    `filiais_do_contexto(request)` (`_compras_do_periodo_no_contexto`, em
    `compras/views.py`), então só a empresa ativa (A, a "de casa" do
    Gerente) pode aparecer."""

    def setUp(self):
        from empresas.models import GrupoEmpresarial

        self.grupo_1 = GrupoEmpresarial.objects.create(nome="Grupo Relatorios 1")
        self.grupo_2 = GrupoEmpresarial.objects.create(nome="Grupo Relatorios 2")

        self.empresa_a = Empresa.objects.create(
            nome="Empresa Relatorios A", cnpj="92.000.000/0001-92", grupo=self.grupo_1,
        )
        self.empresa_b = Empresa.objects.create(
            nome="Empresa Relatorios B", cnpj="93.000.000/0001-93", grupo=self.grupo_2,
        )
        self.filial_a = Filial.objects.create(empresa=self.empresa_a, nome="Filial Relatorios A")
        self.filial_b = Filial.objects.create(empresa=self.empresa_b, nome="Filial Relatorios B")

        for empresa in (self.empresa_a, self.empresa_b):
            ConfiguracaoFinanceira.objects.create(
                empresa=empresa, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO
            )
        Receita.objects.create(filial=self.filial_a, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        Receita.objects.create(filial=self.filial_b, mes=date.today().replace(day=1), faturamento=Decimal("500000"))
        # Regra do Calendário Operacional (rodada 1): fim de semana não tem limite
        # próprio. A premissa deste cenário é "hoje é dia de compra" — explícita,
        # para a suíte passar em qualquer dia da semana (ver core/utils_testes.py).
        garantir_capacidade_no_dia(self.empresa_a)
        garantir_capacidade_no_dia(self.empresa_b)

        self.fornecedor_a = Fornecedor.objects.create(empresa=self.empresa_a, nome="Fornecedor So Grupo 1")
        self.fornecedor_b = Fornecedor.objects.create(empresa=self.empresa_b, nome="Fornecedor So Grupo 2")
        self.categoria_a = Categoria.objects.create(empresa=self.empresa_a, nome="Categoria Relatorios A")
        self.categoria_b = Categoria.objects.create(empresa=self.empresa_b, nome="Categoria Relatorios B")

        self.gerente = Usuario.objects.create_user(
            username="gerente_cross_grupo", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        self.comprador_a = Usuario.objects.create_user(
            username="comprador_so_grupo_1", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_a, filial=self.filial_a,
        )
        self.comprador_b = Usuario.objects.create_user(
            username="comprador_so_grupo_2", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_b, filial=self.filial_b,
        )

        avaliar_e_criar_compra(
            filial=self.filial_a, fornecedor=self.fornecedor_a, valor=Decimal("100.00"),
            categoria=self.categoria_a, centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            usuario=self.comprador_a, observacao="Compra do Grupo 1",
        )
        avaliar_e_criar_compra(
            filial=self.filial_b, fornecedor=self.fornecedor_b, valor=Decimal("999.00"),
            categoria=self.categoria_b, centro_custo=None, data_compra=date.today(),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA, prazo_personalizado_dias=None,
            usuario=self.comprador_b, observacao="Compra do Grupo 2",
        )

        self.client = Client()
        self.client.force_login(self.gerente)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorio_por_comprador_nunca_mostra_dados_de_empresa_de_outro_grupo(self):
        resposta = self.client.get("/compras/relatorios/por-comprador/")
        self.assertEqual(resposta.status_code, 200)
        self.assertNotContains(resposta, "Fornecedor So Grupo 2")
        self.assertNotContains(resposta, "comprador_so_grupo_2")
        # Confirma que o relatório de fato renderizou dados (do Grupo 1) —
        # não é só uma resposta vazia que passaria os asserts acima à toa.
        self.assertContains(resposta, "comprador_so_grupo_1")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorio_por_filial_nunca_mostra_dados_de_empresa_de_outro_grupo(self):
        resposta = self.client.get("/compras/relatorios/por-filial/")
        self.assertEqual(resposta.status_code, 200)
        self.assertNotContains(resposta, "Fornecedor So Grupo 2")
        self.assertNotContains(resposta, "Filial Relatorios B")
        self.assertNotContains(resposta, "Empresa Relatorios B")
        self.assertNotContains(resposta, "93.000.000/0001-93")
        self.assertContains(resposta, "Filial Relatorios A")


class AutoaprovacaoControladaCompraTestCase(TestCase):
    """Fechamento Final (Prompt 1) — Seção 6: "autoaprovação controlada"
    aplicada à Compra. Por padrão, quem LANÇOU a compra nunca pode ser
    quem a APROVA — nem sendo o próprio Gerente — a menos que a empresa
    ligue `ConfiguracaoPlataforma.permitir_autoaprovacao` explicitamente."""

    def setUp(self):
        from empresas.models import ConfiguracaoPlataforma

        self.ConfiguracaoPlataforma = ConfiguracaoPlataforma
        self.empresa = Empresa.objects.create(nome="Empresa Autoaprovacao Compra", cnpj="61.000.000/0001-61")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=DIAS_UTEIS_FIXO,
            regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO,
        )
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 100000 * 0.5 / 20 = 2500
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Autoaprovacao")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Autoaprovacao")

        # O Gerente também lança a compra — simula o negócio pequeno onde a
        # mesma pessoa lança e aprovaria.
        self.gerente = Usuario.objects.create_user(
            username="gerente_autoaprovacao_compra", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        self.outro_gerente = Usuario.objects.create_user(
            username="outro_gerente_autoaprovacao_compra", password="x", perfil=Usuario.Perfil.GERENTE,
            empresa=self.empresa, filial=self.filial,
        )
        avaliacao = avaliar_e_criar_compra(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("3000"), categoria=self.categoria,
            data_compra=date(ANO, MES, 5), prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None, usuario=self.gerente,
        )
        self.compra = avaliacao.compra
        self.assertEqual(self.compra.status, Compra.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_gerente_nao_pode_aprovar_a_propria_compra_por_padrao(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.post(f"/compras/aprovacao/{self.compra.pk}/aprovar/")
        self.assertEqual(response.status_code, 302)
        self.compra.refresh_from_db()
        self.assertEqual(self.compra.status, Compra.Status.PENDENTE)

    def test_service_aprovar_compra_bloqueia_autoaprovacao_mesmo_chamado_diretamente(self):
        from .services import AutoaprovacaoBloqueadaError

        with self.assertRaises(AutoaprovacaoBloqueadaError):
            aprovar_compra_pendente(self.compra, self.gerente)
        self.compra.refresh_from_db()
        self.assertEqual(self.compra.status, Compra.Status.PENDENTE)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_outro_gerente_ainda_pode_aprovar(self):
        client = Client()
        client.force_login(self.outro_gerente)
        response = client.post(f"/compras/aprovacao/{self.compra.pk}/aprovar/")
        self.assertEqual(response.status_code, 302)
        self.compra.refresh_from_db()
        self.assertEqual(self.compra.status, Compra.Status.APROVADA)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_rejeitar_a_propria_compra_continua_permitido(self):
        client = Client()
        client.force_login(self.gerente)
        response = client.post(f"/compras/aprovacao/{self.compra.pk}/rejeitar/")
        self.assertEqual(response.status_code, 302)
        self.compra.refresh_from_db()
        self.assertEqual(self.compra.status, Compra.Status.REJEITADA)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_ligar_autoaprovacao_controlada_permite_aprovar_a_propria_compra(self):
        self.ConfiguracaoPlataforma.objects.create(
            empresa=self.empresa, permitir_autoaprovacao=True,
            justificativa_autoaprovacao="Negócio pequeno, sem mais ninguém disponível.",
        )
        client = Client()
        client.force_login(self.gerente)
        response = client.post(f"/compras/aprovacao/{self.compra.pk}/aprovar/")
        self.assertEqual(response.status_code, 302)
        self.compra.refresh_from_db()
        self.assertEqual(self.compra.status, Compra.Status.APROVADA)


class VerdadeFinanceiraRelatoriosTestCase(TestCase):
    """Gate 2 (Sprint de Encerramento Definitivo) — teste de aceite
    obrigatório da correção de verdade financeira.

    Antes desta correção, `_compras_do_periodo_no_contexto` (usada por
    `relatorio_compras_por_comprador`/`relatorio_compras_por_filial`, em
    HTML, CSV e impressão, que reaproveitam o mesmo contexto) filtrava
    Compra por filial/data mas NÃO por status — então Compra REJEITADA e
    BLOQUEADA eram somadas junto com APROVADA e PENDENTE como se fossem
    "quanto se comprou" (achado real: 8 aprovadas R$13.117,27 + 2
    rejeitadas R$600.000,00 exibidas juntas como R$613.117,27). O mesmo
    valia para o "Total" do rodapé de `lista_compras`.

    Só `Compra.Status.APROVADA` é valor realizado (`STATUS_REALIZADO`, em
    `compras/services.py`) — a fixture abaixo é a exigida pelo Gate 2: uma
    Compra de cada status na mesma Filial/mês (aprovada R$100, pendente
    R$200, rejeitada R$300, bloqueada R$400). O total "realizado" precisa
    ser EXATAMENTE 1 compra / R$100,00."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Verdade Financeira", cnpj="10.100.000/0001-10")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Filial Verdade Financeira")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria VF")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor VF")

        # Segunda Empresa/Filial só para o teste de isolamento — sem
        # nenhuma autorização cruzada com a primeira.
        self.empresa_outra = Empresa.objects.create(nome="Empresa Outra VF", cnpj="10.200.000/0001-20")
        self.filial_outra = Filial.objects.create(empresa=self.empresa_outra, nome="Filial Outra VF")
        self.categoria_outra = Categoria.objects.create(empresa=self.empresa_outra, nome="Categoria Outra VF")
        self.fornecedor_outra = Fornecedor.objects.create(empresa=self.empresa_outra, nome="Fornecedor Outra VF")

        self.financeiro = Usuario.objects.create_user(
            username="financeiro_vf", password="x", perfil=Usuario.Perfil.FINANCEIRO,
            empresa=self.empresa, filial=self.filial,
        )
        self.comprador1 = Usuario.objects.create_user(
            username="comprador_vf1", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.comprador2 = Usuario.objects.create_user(
            username="comprador_vf2", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )
        self.comprador_outra = Usuario.objects.create_user(
            username="comprador_vf_outra", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa_outra, filial=self.filial_outra,
        )

        hoje = date.today()
        # Fixture EXATA exigida pelo Gate 2: uma Compra de cada status na
        # mesma Filial/mês. Criadas via `Compra.objects.create` direto (não
        # `avaliar_e_criar_compra`) porque o teste precisa fixar o status
        # exato de cada uma, não deixar o motor financeiro decidir.
        self.compra_aprovada = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, usuario=self.comprador1,
            valor=Decimal("100.00"), categoria=self.categoria, data_compra=hoje, status=Compra.Status.APROVADA,
        )
        self.compra_pendente = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, usuario=self.comprador1,
            valor=Decimal("200.00"), categoria=self.categoria, data_compra=hoje, status=Compra.Status.PENDENTE,
        )
        self.compra_rejeitada = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, usuario=self.comprador1,
            valor=Decimal("300.00"), categoria=self.categoria, data_compra=hoje, status=Compra.Status.REJEITADA,
        )
        self.compra_bloqueada = Compra.objects.create(
            empresa=self.empresa, filial=self.filial, fornecedor=self.fornecedor, usuario=self.comprador1,
            valor=Decimal("400.00"), categoria=self.categoria, data_compra=hoje, status=Compra.Status.BLOQUEADA,
        )

        # Compra APROVADA de OUTRA Filial/Empresa — mesmo sendo aprovada,
        # nunca pode entrar no total desta Empresa (isolamento multiempresa).
        Compra.objects.create(
            empresa=self.empresa_outra, filial=self.filial_outra, fornecedor=self.fornecedor_outra,
            usuario=self.comprador_outra, valor=Decimal("999999.00"), categoria=self.categoria_outra,
            data_compra=hoje, status=Compra.Status.APROVADA,
        )

        self.client = Client()

    # -- relatório por Filial (HTML e CSV) ---------------------------------

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorio_por_filial_html_mostra_so_o_total_aprovado(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.get("/compras/relatorios/por-filial/")
        self.assertEqual(resposta.status_code, 200)
        agregados = resposta.context["agregados"]
        self.assertEqual(len(agregados), 1)
        self.assertEqual(agregados[0]["quantidade"], 1)
        self.assertEqual(agregados[0]["total"], Decimal("100.00"))
        self.assertEqual(resposta.context["total_geral"], Decimal("100.00"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorio_por_filial_csv_mostra_so_o_total_aprovado(self):
        self.client.force_login(self.financeiro)
        conteudo = self.client.get("/compras/relatorios/por-filial/?formato=csv").content.decode("utf-8-sig")
        self.assertIn("100,00", conteudo)
        self.assertNotIn("200,00", conteudo)
        self.assertNotIn("300,00", conteudo)
        self.assertNotIn("400,00", conteudo)
        self.assertNotIn("999999,00", conteudo)

    # -- relatório por Comprador (HTML e CSV) ------------------------------

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorio_por_comprador_html_mostra_so_o_total_aprovado(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.get("/compras/relatorios/por-comprador/")
        self.assertEqual(resposta.status_code, 200)
        agregados = resposta.context["agregados"]
        self.assertEqual(len(agregados), 1)
        self.assertEqual(agregados[0]["quantidade"], 1)
        self.assertEqual(agregados[0]["total"], Decimal("100.00"))
        self.assertEqual(resposta.context["total_geral"], Decimal("100.00"))

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_relatorio_por_comprador_csv_mostra_so_o_total_aprovado(self):
        self.client.force_login(self.financeiro)
        conteudo = self.client.get("/compras/relatorios/por-comprador/?formato=csv").content.decode("utf-8-sig")
        self.assertIn("100,00", conteudo)
        self.assertNotIn("200,00", conteudo)
        self.assertNotIn("300,00", conteudo)
        self.assertNotIn("400,00", conteudo)

    # -- lista_compras: histórico completo (todos os status), total só aprovada

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_lista_compras_mostra_todos_os_status_mas_total_e_so_aprovada(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.get("/compras/lista/")
        self.assertEqual(resposta.status_code, 200)
        compras_no_contexto = list(resposta.context["compras"])
        self.assertEqual(len(compras_no_contexto), 4)
        self.assertIn(self.compra_aprovada, compras_no_contexto)
        self.assertIn(self.compra_pendente, compras_no_contexto)
        self.assertIn(self.compra_rejeitada, compras_no_contexto)
        self.assertIn(self.compra_bloqueada, compras_no_contexto)
        self.assertEqual(resposta.context["total_valor"], Decimal("100.00"))

    # -- isolamento por Empresa/Filial -------------------------------------

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_compra_aprovada_de_outra_filial_nunca_entra_no_total(self):
        self.client.force_login(self.financeiro)
        resposta = self.client.get("/compras/relatorios/por-filial/")
        self.assertNotContains(resposta, "Filial Outra VF")
        self.assertNotContains(resposta, "Empresa Outra VF")
        self.assertEqual(resposta.context["total_geral"], Decimal("100.00"))

    # -- Comprador não vê dados/total de outro Comprador -------------------

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_nao_ve_compras_nem_total_de_outro_comprador_na_lista(self):
        """`comprador2` não lançou nenhuma compra — não pode ver nenhuma
        das 4 compras (nem o total) lançadas por `comprador1` na mesma
        filial."""
        self.client.force_login(self.comprador2)
        resposta = self.client.get("/compras/lista/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(list(resposta.context["compras"]), [])
        self.assertEqual(resposta.context["total_valor"], 0)

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_comprador_nao_acessa_relatorios_agregados_de_outros_compradores(self):
        self.client.force_login(self.comprador1)
        self.assertEqual(self.client.get("/compras/relatorios/por-comprador/").status_code, 403)
        self.assertEqual(self.client.get("/compras/relatorios/por-filial/").status_code, 403)
