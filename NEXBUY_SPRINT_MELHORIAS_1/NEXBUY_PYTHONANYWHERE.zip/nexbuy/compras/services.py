"""Regra de negócio do lançamento de compra: aplica a Regra de Excesso de
Limite configurada pela empresa (bloquear / enviar para aprovação / permitir
com alerta).

A partir da Sprint 3, os cálculos de capacidade, saldo acumulado e
redistribuição são delegados ao Motor Financeiro (`finance_engine`) — este
módulo mantém as mesmas funções e assinaturas das Sprints anteriores por
compatibilidade com quem já as importava (`dashboard/views.py`,
`core/management/commands/seed_dados.py`). Ver `Arquitetura.md` para o
detalhamento da migração.
"""
import calendar as calendar_module
from datetime import date, timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db.models import Case, Count, DecimalField, Sum, Value, When

from auditoria.models import RegistroAuditoria
from auditoria.services import registrar_evento
from core.utils import formatar_moeda
from finance_engine.calculations import calcular_percentual_utilizado, classificar_por_percentual
from finance_engine.services import STATUS_CONSIDERADOS_NO_LIMITE, motor_financeiro
from financeiro.models import ConfiguracaoFinanceira
from financeiro.services import calcular_capacidade_compra
from notificacoes.models import Notificacao
from notificacoes.services import notificar, notificar_perfis
from usuarios.models import Usuario

from .models import Compra, HistoricoCompra, ParcelaCompra

ZERO = Decimal("0")

# Épico 4 (CORE 1.0) — prazos simples: um único pagamento N dias após a
# compra (comportamento histórico, inalterado).
_DIAS_POR_PRAZO_SIMPLES = {
    Compra.PrazoPagamento.AVISTA: 0,
    Compra.PrazoPagamento.D7: 7,
    Compra.PrazoPagamento.D14: 14,
    Compra.PrazoPagamento.D30: 30,
    Compra.PrazoPagamento.D60: 60,
}

# Prazos compostos: lista de offsets (em dias) — uma parcela por offset.
_OFFSETS_POR_PRAZO_COMPOSTO = {
    Compra.PrazoPagamento.D30_60: (30, 60),
    Compra.PrazoPagamento.D30_60_90: (30, 60, 90),
}


def calcular_numero_parcelas(prazo_pagamento: str, numero_parcelas_personalizado: int = 1) -> int:
    """Quantidade REAL de parcelas que este prazo gera (Gate pré-Etapa 10,
    S1-4) — fonte única, usada tanto para calcular os vencimentos quanto
    para o que fica persistido em `Compra.numero_parcelas`. Antes desta
    correção, `numero_parcelas` só era preenchido de verdade para o prazo
    Personalizado (ficava 1 por padrão para 30/60 e 30/60/90, mesmo essas
    compras gerando 2 e 3 parcelas reais) — auditoria externa encontrou a
    divergência num banco de demonstração real."""
    if prazo_pagamento in _OFFSETS_POR_PRAZO_COMPOSTO:
        return len(_OFFSETS_POR_PRAZO_COMPOSTO[prazo_pagamento])
    if prazo_pagamento == Compra.PrazoPagamento.PERSONALIZADO:
        return max(numero_parcelas_personalizado or 1, 1)
    return 1


def calcular_vencimentos_da_compra(compra: Compra) -> list[date]:
    """Datas de vencimento das parcelas de uma Compra, conforme o prazo.

    Personalizado: `numero_parcelas` parcelas com intervalo de
    `prazo_personalizado_dias` entre elas (1 parcela = comportamento
    histórico de um único pagamento no prazo informado).
    """
    if compra.prazo_pagamento in _OFFSETS_POR_PRAZO_COMPOSTO:
        return [compra.data_compra + timedelta(days=d) for d in _OFFSETS_POR_PRAZO_COMPOSTO[compra.prazo_pagamento]]
    if compra.prazo_pagamento == Compra.PrazoPagamento.PERSONALIZADO:
        intervalo = compra.prazo_personalizado_dias or 0
        total = calcular_numero_parcelas(compra.prazo_pagamento, compra.numero_parcelas)
        return [compra.data_compra + timedelta(days=intervalo * n) for n in range(1, total + 1)]
    dias = _DIAS_POR_PRAZO_SIMPLES.get(compra.prazo_pagamento, 0)
    return [compra.data_compra + timedelta(days=dias)]


def dividir_valor_em_parcelas(valor_total: Decimal, quantidade: int) -> list[Decimal]:
    """Divide um valor em N parcelas de 2 casas decimais; a última parcela
    absorve a diferença de arredondamento (a soma é sempre exata)."""
    quantidade = max(quantidade, 1)
    base = (valor_total / quantidade).quantize(Decimal("0.01"))
    valores = [base] * quantidade
    valores[-1] = valor_total - base * (quantidade - 1)
    return valores


def _sincronizar_numero_parcelas(compra: Compra, quantidade: int) -> None:
    """Único ponto de gravação de `Compra.numero_parcelas` a partir da
    quantidade REAL de parcelas (Gate pré-Etapa 10, S1-4) — chamado tanto
    quando as parcelas acabaram de ser criadas quanto quando já existiam
    (auto-cura dados antigos gravados antes desta correção, sem precisar
    esperar a migration de dados rodar)."""
    if compra.numero_parcelas != quantidade:
        compra.numero_parcelas = quantidade
        compra.save(update_fields=["numero_parcelas", "atualizado_em"])


def gerar_parcelas_da_compra(compra: Compra) -> list[ParcelaCompra]:
    """Cria as parcelas (compromissos futuros) de uma Compra aprovada.

    Idempotente por construção: se a compra já tem parcelas, devolve as
    existentes sem duplicar — permite chamar tanto na criação (compra
    aprovada direto) quanto na aprovação posterior de uma pendente.
    """
    existentes = list(compra.parcelas.all())
    if existentes:
        _sincronizar_numero_parcelas(compra, len(existentes))
        return existentes

    vencimentos = calcular_vencimentos_da_compra(compra)
    valores = dividir_valor_em_parcelas(compra.valor, len(vencimentos))
    parcelas = [
        ParcelaCompra(compra=compra, numero=indice, data_vencimento=vencimento, valor=valor)
        for indice, (vencimento, valor) in enumerate(zip(vencimentos, valores), start=1)
    ]
    parcelas = ParcelaCompra.objects.bulk_create(parcelas)
    _sincronizar_numero_parcelas(compra, len(parcelas))
    return parcelas


def marcar_parcela_paga(parcela: ParcelaCompra, usuario=None) -> ParcelaCompra:
    """Baixa manual de uma parcela (Agenda Financeira). Registra no
    histórico da Compra para manter a trilha de auditoria completa."""
    parcela.status = ParcelaCompra.Status.PAGA
    parcela.save(update_fields=["status", "atualizado_em"])
    registrar_historico_compra(
        parcela.compra,
        usuario,
        HistoricoCompra.Acao.PAGAMENTO,
        f"Parcela {parcela.numero} marcada como paga "
        f"({formatar_moeda(parcela.valor, incluir_prefixo=True)}, venc. {parcela.data_vencimento:%d/%m/%Y}).",
    )
    return parcela


def estornar_parcela(parcela: ParcelaCompra, usuario=None, justificativa: str = "") -> ParcelaCompra:
    """Prompt 2 (pré-Etapa 02), Gates A/D/E/F: reverte uma baixa feita por
    engano — devolve a parcela ao estado PENDENTE, exatamente como estava
    antes de `marcar_parcela_paga`. Nunca cria parcela nova, nunca duplica
    valor: é a mesma linha, só o `status` muda de volta. Só pode reverter
    uma parcela que está PAGA (uma parcela PENDENTE não tem o que
    estornar; CANCELADA é um estado terminal diferente)."""
    if parcela.status != ParcelaCompra.Status.PAGA:
        raise ValidationError("Só é possível estornar uma parcela que está paga.")
    parcela.status = ParcelaCompra.Status.PENDENTE
    parcela.save(update_fields=["status", "atualizado_em"])
    registrar_historico_compra(
        parcela.compra,
        usuario,
        HistoricoCompra.Acao.ESTORNO,
        f"Parcela {parcela.numero} estornada — volta a pendente "
        f"({formatar_moeda(parcela.valor, incluir_prefixo=True)}, venc. {parcela.data_vencimento:%d/%m/%Y})."
        + (f" Justificativa: {justificativa}" if justificativa else ""),
    )
    return parcela

# Mantida pelo nome usado desde a Etapa 1 — aponta para a mesma tupla que o
# Motor Financeiro usa como fonte única (evita duas definições divergentes).
STATUS_CONSIDERADOS_NO_TOTAL_DIARIO = STATUS_CONSIDERADOS_NO_LIMITE

# Gate 2 (Sprint de Encerramento Definitivo): "quanto se comprou de
# verdade" — só Compra efetivamente aprovada. Rejeitada/Bloqueada/Pendente
# NUNCA entram aqui (diferente de STATUS_CONSIDERADOS_NO_TOTAL_DIARIO, que é
# sobre CAPACIDADE/comprometido, não sobre valor realizado).
STATUS_REALIZADO = (Compra.Status.APROVADA,)


def total_comprado_no_dia(filial, data_compra, excluir_pk=None):
    qs = Compra.objects.filter(
        filial=filial, data_compra=data_compra, status__in=STATUS_CONSIDERADOS_NO_TOTAL_DIARIO
    )
    if excluir_pk:
        qs = qs.exclude(pk=excluir_pk)
    return qs.aggregate(total=Sum("valor"))["total"] or ZERO


def total_comprado_no_dia_pelo_usuario(usuario, filial, data_compra, excluir_pk=None):
    """Quanto ESTE comprador já gastou nesta filial, neste dia (Sprint de
    Consolidação — decisão de negócio do Gate 2A): a base da dotação diária
    acumulada — mesma janela/status de `total_comprado_no_dia`
    (`STATUS_CONSIDERADOS_NO_TOTAL_DIARIO`), só que escopada ao usuário, para
    que este número seja sempre idêntico ao `gasto_hoje` que
    `obter_situacao_compradores` mostra na tela Capacidade dos Compradores —
    uma única fonte de verdade para os dois lugares."""
    qs = Compra.objects.filter(
        filial=filial, usuario=usuario, data_compra=data_compra, status__in=STATUS_CONSIDERADOS_NO_TOTAL_DIARIO
    )
    if excluir_pk:
        qs = qs.exclude(pk=excluir_pk)
    return qs.aggregate(total=Sum("valor"))["total"] or ZERO


def reservado_no_dia_pelo_usuario(usuario, filial, data_compra):
    """Visual QA & Demo Polish: recorte PENDENTE (ainda não decidido, mas já
    reservando a dotação) de `total_comprado_no_dia_pelo_usuario` — mesmo
    conceito de "reservado" que `obter_situacao_compradores` já mostra ao
    Financeiro por comprador, aqui só para o próprio comprador ver no seu
    dashboard (pergunta "quanto está reservado?" antes sem resposta)."""
    return (
        Compra.objects.filter(
            filial=filial, usuario=usuario, data_compra=data_compra, status=Compra.Status.PENDENTE
        ).aggregate(total=Sum("valor"))["total"]
        or ZERO
    )


class AvaliacaoCompra:
    def __init__(self, compra, excedeu_limite, limite_diario, ja_comprado_no_dia, saldo_acumulado=ZERO):
        self.compra = compra
        self.excedeu_limite = excedeu_limite
        self.limite_diario = limite_diario  # limite efetivo do dia (já soma saldo acumulado/redistribuição)
        self.ja_comprado_no_dia = ja_comprado_no_dia
        self.saldo_acumulado = saldo_acumulado


def calcular_saldo_acumulado(filial, data_referencia, limite_diario_base=None):
    """Mantida por compatibilidade (Etapa 2). `limite_diario_base` é aceito
    mas ignorado — o Motor Financeiro recalcula a capacidade do mês
    internamente para garantir que o resultado seja sempre consistente com
    `finance_engine.services.MotorFinanceiro`."""
    if data_referencia.day <= 1:
        return ZERO
    dia_anterior = data_referencia.replace(day=data_referencia.day - 1)
    return motor_financeiro.posicao_do_dia(filial, dia_anterior).carry_out


def calcular_limite_efetivo(filial, data_referencia):
    """Retorna (limite_efetivo, saldo_transferido, capacidade). Delegado ao
    Motor Financeiro — quando saldo acumulado e redistribuição estão
    desligados (padrão), limite_efetivo == capacidade['limite_diario'] e
    saldo_transferido == 0, idêntico ao comportamento da Etapa 1/2."""
    posicao = motor_financeiro.posicao_do_dia(filial, data_referencia)
    capacidade = calcular_capacidade_compra(filial, data_referencia.year, data_referencia.month)
    return posicao.limite_efetivo, posicao.saldo_transferido, capacidade


def registrar_historico_compra(compra: Compra, usuario, acao: str, detalhe: str = "") -> HistoricoCompra:
    """Grava um evento de auditoria da Compra (Sprint 4.1, item 5) — mesmo
    padrão de `gestao_compras.services.registrar_historico`."""
    return HistoricoCompra.objects.create(compra=compra, usuario=usuario, acao=acao, detalhe=detalhe)


def avaliar_e_criar_compra(*, filial, fornecedor, valor, categoria, data_compra, prazo_pagamento,
                            prazo_personalizado_dias, usuario, observacao="", centro_custo=None,
                            numero_parcelas=1):
    """Aplica a regra de excesso de limite e cria o registro de compra já com o
    status correto (aprovada, pendente de aprovação ou bloqueada).

    CORE 1.0: também aplica o limite individual do comprador (Épico 7 — se
    configurado, uma compra acima do limite pessoal sempre vai para
    aprovação) e gera as parcelas do prazo escolhido (Épico 4).

    Sprint de Correções Críticas (Seção 11): revalida no SERVICE que a
    filial pertence ao conjunto de filiais autorizadas do usuário — o form
    já restringe a queryset, mas o service não pode confiar cegamente no
    que foi submetido (defesa em profundidade).

    Sprint de Correções Críticas (Seção 14): toda a avaliação roda dentro
    de uma transação com a Filial bloqueada (`select_for_update`) — sem
    isso, duas compras concorrentes na MESMA filial poderiam ler "quanto já
    foi comprado hoje" com o mesmo valor desatualizado e ser aprovadas
    juntas mesmo que, somadas, ultrapassem o limite diário (nenhuma delas
    sozinha excede)."""
    from django.core.exceptions import PermissionDenied
    from django.db import transaction

    from filiais.models import Filial
    from usuarios.models import filiais_autorizadas_para

    if filial not in filiais_autorizadas_para(usuario, filial.empresa):
        raise PermissionDenied("Você não está autorizado a lançar compras nesta filial.")

    with transaction.atomic():
        Filial.objects.select_for_update().get(pk=filial.pk)

        limite_efetivo, saldo_acumulado, capacidade = calcular_limite_efetivo(filial, data_compra)

        ja_comprado = total_comprado_no_dia(filial, data_compra)
        total_com_nova = ja_comprado + valor
        excedeu_limite = limite_efetivo <= ZERO or total_com_nova > limite_efetivo

        regra = capacidade["regra_excesso"]

        status = Compra.Status.APROVADA
        alerta = False

        if excedeu_limite:
            if regra == ConfiguracaoFinanceira.RegraExcesso.BLOQUEAR:
                status = Compra.Status.BLOQUEADA
            elif regra == ConfiguracaoFinanceira.RegraExcesso.APROVACAO:
                status = Compra.Status.PENDENTE
            else:  # alerta
                status = Compra.Status.APROVADA
                alerta = True

        # Épico 7 (CORE 1.0) — limite individual do comprador nesta empresa.
        # Sem limite configurado (todo o histórico existente), nada muda.
        #
        # Sprint de Consolidação (decisão de negócio — Gate 2A, Parte 2): o
        # limite individual é uma DOTAÇÃO DIÁRIA ACUMULADA, não um teto por
        # operação isolada. Antes, `valor > limite_individual` comparava só
        # esta compra; um comprador com dotação de R$ 5.000 podia gastar
        # R$ 3.000 e depois mais R$ 3.000 no mesmo dia sem cair em aprovação,
        # porque nenhuma das duas operações sozinha excedia o limite. Agora
        # soma-se o que ele JÁ gastou hoje (mesma fonte que a tela Capacidade
        # dos Compradores exibe) com o valor desta compra.
        excedeu_limite_individual = False
        autorizacao = _autorizacao_do_usuario(usuario, filial.empresa)
        limite_individual = autorizacao.limite_compra if autorizacao else None
        gasto_hoje_comprador = ZERO

        # RC do Épico 01 (Correção 03) — comprador bloqueado pelo Financeiro:
        # a compra é barrada na ORIGEM (status Bloqueada), independentemente de
        # limite ou regra de excesso. Regra do Motor de Capacidade: a capacidade
        # pertence ao Financeiro; um comprador bloqueado não a consome.
        comprador_bloqueado = bool(autorizacao and autorizacao.bloqueado)
        if comprador_bloqueado:
            status = Compra.Status.BLOQUEADA
        elif limite_individual is not None and status != Compra.Status.BLOQUEADA:
            gasto_hoje_comprador = total_comprado_no_dia_pelo_usuario(usuario, filial, data_compra)
            if (gasto_hoje_comprador + valor) > limite_individual:
                excedeu_limite_individual = True
                status = Compra.Status.PENDENTE

        compra = Compra.objects.create(
            empresa=filial.empresa,
            filial=filial,
            fornecedor=fornecedor,
            usuario=usuario,
            valor=valor,
            categoria=categoria,
            centro_custo=centro_custo,
            data_compra=data_compra,
            prazo_pagamento=prazo_pagamento,
            prazo_personalizado_dias=prazo_personalizado_dias,
            numero_parcelas=calcular_numero_parcelas(prazo_pagamento, numero_parcelas),
            status=status,
            alerta_excesso=alerta,
            observacao=observacao,
        )
        detalhe_criacao = (
            f"Compra lançada com status '{compra.get_status_display()}' "
            f"(valor {formatar_moeda(compra.valor, incluir_prefixo=True)})."
        )
        if comprador_bloqueado:
            detalhe_criacao += " Comprador bloqueado pelo Financeiro — compra barrada na origem."
        elif excedeu_limite_individual:
            detalhe_criacao += (
                f" Dotação diária do comprador excedida: já gasto "
                f"{formatar_moeda(gasto_hoje_comprador, incluir_prefixo=True)} + esta compra "
                f"ultrapassa a dotação de {formatar_moeda(limite_individual, incluir_prefixo=True)} — "
                f"enviada para aprovação."
            )
        registrar_historico_compra(compra, usuario, HistoricoCompra.Acao.CRIACAO, detalhe_criacao)
        # Gate pré-Etapa 10 (S1-3): `correlation_id` derivado do PK da
        # Compra (sem coluna nova) — liga este evento a qualquer futuro
        # evento sobre a MESMA compra (aprovação/rejeição manual, baixa).
        if compra.status == Compra.Status.BLOQUEADA:
            categoria_auditoria = RegistroAuditoria.Categoria.COMPRA_BLOQUEADA
            resultado_auditoria = RegistroAuditoria.Resultado.BLOQUEADO
        else:
            categoria_auditoria = RegistroAuditoria.Categoria.COMPRA_LANCADA
            resultado_auditoria = (
                RegistroAuditoria.Resultado.SUCESSO if compra.status == Compra.Status.APROVADA
                else RegistroAuditoria.Resultado.PENDENTE
            )
        registrar_evento(
            categoria=categoria_auditoria, descricao=detalhe_criacao,
            empresa=filial.empresa, filial=filial, usuario=usuario,
            modulo="compras", acao="lancar", resultado=resultado_auditoria,
            tipo_objeto="Compra", id_objeto=compra.pk,
            estado_depois={"status": compra.status, "valor": str(compra.valor)},
            correlation_id=f"compra-{compra.pk}",
        )

        # Épico 4 (CORE 1.0) — compromissos futuros só existem para compra que
        # de fato vai acontecer: aprovada (com ou sem alerta) gera parcelas já;
        # pendente gera na aprovação; bloqueada nunca gera.
        if compra.status == Compra.Status.APROVADA:
            parcelas = gerar_parcelas_da_compra(compra)
            if len(parcelas) > 1:
                notificar_perfis(
                    filial.empresa, (Usuario.Perfil.FINANCEIRO,), Notificacao.Tipo.PARCELAMENTO_CRIADO,
                    "Parcelamento criado",
                    f"{fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)} em {len(parcelas)}x.",
                    "/financeiro/agenda/",
                )

        # Épico 11 (CORE 1.0) — eventos de notificação da compra.
        if compra.status == Compra.Status.PENDENTE:
            notificar_perfis(
                filial.empresa, (Usuario.Perfil.GERENTE,), Notificacao.Tipo.SOLICITACAO_LIMITE,
                "Compra aguardando aprovação",
                f"{fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)} ({data_compra:%d/%m/%Y}).",
                "/compras/aprovacao/",
                excluir_usuario=usuario,
            )
        else:
            notificar_perfis(
                filial.empresa, (Usuario.Perfil.GERENTE,), Notificacao.Tipo.COMPRA_CRIADA,
                "Compra criada",
                f"{fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)} ({data_compra:%d/%m/%Y}).",
                "/compras/lista/",
                excluir_usuario=usuario,
            )
        if alerta:
            notificar_perfis(
                filial.empresa, (Usuario.Perfil.FINANCEIRO, Usuario.Perfil.PROPRIETARIO), Notificacao.Tipo.CAPACIDADE_EXCEDIDA,
                "Capacidade do dia excedida",
                f"Compra de {formatar_moeda(compra.valor, incluir_prefixo=True)} ultrapassou o limite de "
                f"{data_compra:%d/%m/%Y} na filial {filial.nome}.",
                "/timeline/",
            )

    return AvaliacaoCompra(compra, excedeu_limite, limite_efetivo, ja_comprado, saldo_acumulado)


def _autorizacao_do_usuario(usuario, empresa):
    """Autorização/limite/bloqueio do usuário nesta empresa (Épicos 7 e
    RC-C03), ou None quando não configurado. Import local para não criar
    dependência de módulo em quem só usa as funções de cálculo."""
    if usuario is None or empresa is None or not getattr(usuario, "pk", None):
        return None
    from usuarios.models import UsuarioEmpresa

    return UsuarioEmpresa.objects.filter(usuario=usuario, empresa=empresa, ativo=True).first()


# ---------------------------------------------------------------------------
# Motor de Capacidade — distribuição por comprador (RC do Épico 01, C03)
#
# A capacidade pertence ao FINANCEIRO: ele define a capacidade diária (via
# Configuração Financeira + Calendário Operacional), distribui entre os
# compradores (limites individuais), pode bloquear/liberar compradores e
# redistribuir durante o dia. Como todo indicador do NEXBUY é derivado (day-
# walk sob demanda), qualquer mudança aqui recalcula automaticamente
# capacidade restante, saldo, indicadores e dashboards na próxima leitura.
# ---------------------------------------------------------------------------


def obter_autorizacao_comprador(usuario, empresa):
    """Autorização (limite individual + bloqueio) do comprador na empresa —
    API pública do Motor de Capacidade para os ViewModels (RC-C01/C03)."""
    return _autorizacao_do_usuario(usuario, empresa)


def obter_situacao_compradores(empresa, filial, data_referencia: date) -> list[dict]:
    """Situação de cada comprador da empresa no dia: dotação individual,
    bloqueio, consumo de hoje (separado em Utilizado/Reservado) e
    participação no total — a base da tela "Capacidade dos Compradores"
    do Financeiro (Sprint de Consolidação, Gate 2A, Parte 2).

    Utilizado = já aprovado (compromisso firme). Reservado = pendente de
    aprovação (ainda reserva a dotação, para não permitir gastar a mesma
    capacidade duas vezes enquanto a decisão está em aberto — mesma
    convenção de `avaliar_e_criar_compra`/STATUS_CONSIDERADOS_NO_TOTAL_DIARIO).
    """
    from usuarios.models import Usuario, UsuarioEmpresa

    compradores = Usuario.objects.filter(
        empresa=empresa, perfil=Usuario.Perfil.COMPRADOR, is_active=True
    ).order_by("first_name", "username")
    autorizacoes = {
        a.usuario_id: a for a in UsuarioEmpresa.objects.filter(empresa=empresa, usuario__in=compradores)
    }
    consumo = {
        linha["usuario_id"]: linha
        for linha in Compra.objects.filter(
            filial=filial, data_compra=data_referencia, status__in=STATUS_CONSIDERADOS_NO_TOTAL_DIARIO
        )
        .values("usuario_id")
        .annotate(
            utilizado=Sum(
                Case(
                    When(status=Compra.Status.APROVADA, then="valor"),
                    default=Value(ZERO),
                    output_field=DecimalField(max_digits=12, decimal_places=2),
                )
            ),
            reservado=Sum(
                Case(
                    When(status=Compra.Status.PENDENTE, then="valor"),
                    default=Value(ZERO),
                    output_field=DecimalField(max_digits=12, decimal_places=2),
                )
            ),
        )
    }

    situacao = []
    for comprador in compradores:
        autorizacao = autorizacoes.get(comprador.pk)
        linha_consumo = consumo.get(comprador.pk)
        utilizado = linha_consumo["utilizado"] if linha_consumo else ZERO
        reservado = linha_consumo["reservado"] if linha_consumo else ZERO
        gasto = utilizado + reservado
        limite = autorizacao.limite_compra if autorizacao else None
        percentual = calcular_percentual_utilizado(gasto, limite) if limite is not None else None
        situacao.append(
            {
                "usuario": comprador,
                "limite": limite,
                "bloqueado": bool(autorizacao and autorizacao.bloqueado),
                "utilizado": utilizado,
                "reservado": reservado,
                "gasto_hoje": gasto,
                "disponivel_individual": (limite - gasto) if limite is not None else None,
                # Negativo nunca aparece como "disponível R$ -X": as telas
                # mostram "excedido em R$ X" (mesmo padrão do Comprador).
                "excedido_individual": (gasto - limite) if limite is not None and gasto > limite else ZERO,
                "percentual": percentual,
                "cor": classificar_por_percentual(percentual) if percentual is not None else None,
            }
        )
    return situacao


def _registrar_gestao_capacidade(empresa, usuario_gestor, descricao: str) -> None:
    from empresas.models import LogConfiguracao

    LogConfiguracao.objects.create(
        empresa=empresa, usuario=usuario_gestor, area="Capacidade dos Compradores", descricao=descricao
    )


def definir_limite_comprador(comprador, empresa, limite, usuario_gestor) -> None:
    """Distribuição/redistribuição de capacidade (RC-C03): define (ou
    remove, com None) o limite individual do comprador. Auditado em
    LogConfiguracao e notificado ao comprador.

    Sprint de Correções Críticas (Seção 14): a mudança de limite e o
    registro de auditoria são uma unidade só — sem a transação, uma falha
    ao gravar o LogConfiguracao deixaria o limite alterado sem nenhuma
    trilha de quem/quando mudou."""
    from django.db import transaction

    from usuarios.models import UsuarioEmpresa

    with transaction.atomic():
        autorizacao, _ = UsuarioEmpresa.objects.get_or_create(
            usuario=comprador, empresa=empresa, defaults={"ativo": True}
        )
        limite_antes = autorizacao.limite_compra
        autorizacao.limite_compra = limite
        autorizacao.save(update_fields=["limite_compra", "atualizado_em"])
        texto_limite = formatar_moeda(limite, incluir_prefixo=True) if limite is not None else "sem limite individual"
        _registrar_gestao_capacidade(
            empresa, usuario_gestor,
            f"Limite de {comprador.get_full_name() or comprador.username} definido para {texto_limite}.",
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.LIMITE_COMPRADOR_ALTERADO,
            descricao=f"Limite de {comprador.get_full_name() or comprador.username} definido para {texto_limite}.",
            empresa=empresa, usuario=usuario_gestor, modulo="financeiro", acao="limite_comprador",
            tipo_objeto="UsuarioEmpresa", id_objeto=autorizacao.pk,
            estado_antes={"limite_compra": str(limite_antes) if limite_antes is not None else None},
            estado_depois={"limite_compra": str(limite) if limite is not None else None},
        )

    notificar(
        comprador, Notificacao.Tipo.MUDANCA_STATUS, "Seu limite de compra foi atualizado",
        f"Novo limite individual: {texto_limite}.", "/", empresa,
    )


def bloquear_comprador(comprador, empresa, usuario_gestor) -> None:
    """Bloqueio operacional (RC-C03): novas compras do comprador passam a
    ser barradas na origem até a liberação. Ver nota de transação em
    `definir_limite_comprador` (Seção 14)."""
    from django.db import transaction

    from usuarios.models import UsuarioEmpresa

    with transaction.atomic():
        autorizacao, _ = UsuarioEmpresa.objects.get_or_create(
            usuario=comprador, empresa=empresa, defaults={"ativo": True}
        )
        autorizacao.bloqueado = True
        autorizacao.save(update_fields=["bloqueado", "atualizado_em"])
        _registrar_gestao_capacidade(
            empresa, usuario_gestor, f"Comprador {comprador.get_full_name() or comprador.username} bloqueado."
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.COMPRADOR_BLOQUEADO,
            descricao=f"Comprador {comprador.get_full_name() or comprador.username} bloqueado.",
            empresa=empresa, usuario=usuario_gestor, modulo="financeiro", acao="bloquear_comprador",
            tipo_objeto="UsuarioEmpresa", id_objeto=autorizacao.pk,
            estado_antes={"bloqueado": False}, estado_depois={"bloqueado": True},
            resultado=RegistroAuditoria.Resultado.BLOQUEADO,
        )

    notificar(
        comprador, Notificacao.Tipo.MUDANCA_STATUS, "Suas compras foram bloqueadas",
        "O Financeiro bloqueou temporariamente novas compras suas nesta empresa.", "/", empresa,
    )


def liberar_comprador(comprador, empresa, usuario_gestor) -> None:
    """Ver nota de transação em `definir_limite_comprador` (Seção 14)."""
    from django.db import transaction

    from usuarios.models import UsuarioEmpresa

    with transaction.atomic():
        autorizacao = UsuarioEmpresa.objects.filter(usuario=comprador, empresa=empresa).first()
        UsuarioEmpresa.objects.filter(usuario=comprador, empresa=empresa).update(bloqueado=False)
        _registrar_gestao_capacidade(
            empresa, usuario_gestor, f"Comprador {comprador.get_full_name() or comprador.username} liberado."
        )
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.COMPRADOR_LIBERADO,
            descricao=f"Comprador {comprador.get_full_name() or comprador.username} liberado.",
            empresa=empresa, usuario=usuario_gestor, modulo="financeiro", acao="liberar_comprador",
            tipo_objeto="UsuarioEmpresa", id_objeto=autorizacao.pk if autorizacao else None,
            estado_antes={"bloqueado": True}, estado_depois={"bloqueado": False},
        )

    notificar(
        comprador, Notificacao.Tipo.MUDANCA_STATUS, "Suas compras foram liberadas",
        "O Financeiro liberou novas compras suas nesta empresa.", "/", empresa,
    )


class CompraJaDecididaError(Exception):
    """A Compra não está mais Pendente — já foi aprovada/rejeitada (por
    outra requisição, possivelmente um duplo clique)."""


class AutoaprovacaoBloqueadaError(Exception):
    """Fechamento Final (Prompt 1, Seção 6) — "autoaprovação controlada":
    quem lançou a Compra tentou aprovar a própria solicitação, e a empresa
    não ligou `ConfiguracaoPlataforma.permitir_autoaprovacao`."""


def aprovar_compra_pendente(compra: Compra, usuario=None) -> Compra:
    """Move uma compra pendente para o status Aprovada (fluxo de aprovação
    do Gerente). Regra de negócio extraída da view (Sprint 3 — regra 8).
    CORE 1.0 (Épico 4): a aprovação também materializa as parcelas.

    Sprint de Correções Críticas (Seção 14): recarrega a Compra com
    `select_for_update` e revalida o status DENTRO da transação — a view já
    filtra por `status=PENDENTE` antes de chamar esta função, mas entre
    esse filtro e a gravação existe uma janela onde um duplo clique (ou o
    Gerente decidindo duas vezes em abas diferentes) poderia aprovar a
    mesma compra duas vezes e gerar parcelas duplicadas.

    Fechamento Final (Seção 6): quem LANÇOU a compra (`compra.usuario`)
    nunca pode ser quem a APROVA — checado dentro do lock, defesa em
    profundidade além da checagem já feita na view."""
    from django.db import transaction

    from core.permissions import autoaprovacao_controlada_permitida

    with transaction.atomic():
        compra = Compra.objects.select_for_update().select_related("fornecedor", "usuario", "empresa").get(
            pk=compra.pk
        )
        if compra.status != Compra.Status.PENDENTE:
            raise CompraJaDecididaError(
                f"Esta compra já foi decidida — está \"{compra.get_status_display()}\"."
            )
        if usuario is not None and compra.usuario_id == usuario.pk and not autoaprovacao_controlada_permitida(
            compra.empresa
        ):
            raise AutoaprovacaoBloqueadaError(
                "Você não pode aprovar a própria compra — peça para outra pessoa aprovar, ou habilite "
                "a autoaprovação controlada em Configurações Gerais (com justificativa)."
            )
        eh_autoaprovacao = usuario is not None and compra.usuario_id == usuario.pk
        compra.status = Compra.Status.APROVADA
        compra.save(update_fields=["status", "atualizado_em"])
        registrar_historico_compra(compra, usuario, HistoricoCompra.Acao.APROVACAO)
        gerar_parcelas_da_compra(compra)
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.COMPRA_LANCADA,
            descricao=f"Compra pendente aprovada — {compra.fornecedor.nome} ({formatar_moeda(compra.valor, incluir_prefixo=True)}).",
            empresa=compra.empresa, filial=compra.filial, usuario=usuario,
            modulo="compras", acao="aprovar_pendente", resultado=RegistroAuditoria.Resultado.SUCESSO,
            tipo_objeto="Compra", id_objeto=compra.pk, estado_depois={"status": compra.status},
            origem_decisao=(
                RegistroAuditoria.OrigemDecisao.AUTOMATICA if eh_autoaprovacao
                else RegistroAuditoria.OrigemDecisao.MANUAL
            ),
            autoaprovacao=eh_autoaprovacao, correlation_id=f"compra-{compra.pk}",
        )

    notificar(
        compra.usuario, Notificacao.Tipo.COMPRA_APROVADA, "Compra aprovada",
        f"{compra.fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)} foi aprovada.",
        "/compras/lista/", compra.empresa,
    )
    return compra


def rejeitar_compra_pendente(compra: Compra, usuario=None) -> Compra:
    """Move uma compra pendente para o status Rejeitada (fluxo de aprovação
    do Gerente). Regra de negócio extraída da view (Sprint 3 — regra 8).

    Sprint de Correções Críticas (Seção 14): mesma proteção de
    `aprovar_compra_pendente` — lock + revalidação de status dentro da
    transação, para nunca rejeitar uma compra que outra requisição já
    aprovou (ou vice-versa) na mesma janela de tempo."""
    from django.db import transaction

    with transaction.atomic():
        compra = Compra.objects.select_for_update().select_related("fornecedor", "usuario", "empresa").get(
            pk=compra.pk
        )
        if compra.status != Compra.Status.PENDENTE:
            raise CompraJaDecididaError(
                f"Esta compra já foi decidida — está \"{compra.get_status_display()}\"."
            )
        compra.status = Compra.Status.REJEITADA
        compra.save(update_fields=["status", "atualizado_em"])
        registrar_historico_compra(compra, usuario, HistoricoCompra.Acao.REJEICAO)
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.COMPRA_BLOQUEADA,
            descricao=f"Compra pendente rejeitada — {compra.fornecedor.nome} ({formatar_moeda(compra.valor, incluir_prefixo=True)}).",
            empresa=compra.empresa, filial=compra.filial, usuario=usuario,
            # Gate D (Prompt 2, Seção 10): a rejeição CONCLUÍDA com sucesso é
            # um resultado SUCESSO do evento de auditoria — "falha" fica
            # reservada para quando a operação em si não se completa (ex.:
            # `CompraJaDecididaError`). Rejeitar uma Compra é uma decisão de
            # negócio válida, não um erro do sistema.
            modulo="compras", acao="rejeitar_pendente", resultado=RegistroAuditoria.Resultado.SUCESSO,
            tipo_objeto="Compra", id_objeto=compra.pk, estado_depois={"status": compra.status},
            correlation_id=f"compra-{compra.pk}",
        )

    notificar(
        compra.usuario, Notificacao.Tipo.COMPRA_REJEITADA, "Compra rejeitada",
        f"{compra.fornecedor.nome} — {formatar_moeda(compra.valor, incluir_prefixo=True)} foi rejeitada.",
        "/compras/lista/", compra.empresa,
    )
    return compra


def classificar_dia(comprado, limite_diario):
    """Classifica o consumo de um dia em verde (disponível) / laranja (atenção) /
    vermelho (limite excedido/esgotado), conforme a proporção comprado / limite diário.

    Mantida com a assinatura original (proporção 0-1, não percentual 0-100)
    por compatibilidade. O limiar E a regra de borda "limite <= 0" vêm de
    `finance_engine.calculations.calcular_percentual_utilizado` — a mesma
    fonte única usada por `classificar_consumo` (Sprint 4.1; unificado na
    Sprint de Consolidação/Gate 2A P0-2 — as duas funções tinham
    comportamentos diferentes nesse caso de borda, documentado como dívida
    técnica desde então)."""
    proporcao = ZERO if limite_diario <= ZERO else comprado / limite_diario
    if limite_diario <= ZERO and comprado > ZERO:
        proporcao = Decimal("2")  # preserva o valor histórico da proporção retornada

    cor = classificar_por_percentual(calcular_percentual_utilizado(comprado, limite_diario))
    return cor, proporcao


def status_do_dia(filial, data_compra):
    """Classifica um dia em disponível / atenção / excedido, para o calendário visual."""
    posicao = motor_financeiro.posicao_do_dia(filial, data_compra)
    cor, proporcao = classificar_dia(posicao.comprado, posicao.limite_base)
    return {
        "comprado": posicao.comprado,
        "limite_diario": posicao.limite_base,
        "proporcao": proporcao,
        "cor": cor,
    }


def mapa_comprado_no_mes(filial, ano, mes):
    """Retorna {dia_do_mes: total_comprado} em uma única consulta agregada."""
    compras = (
        Compra.objects.filter(
            filial=filial,
            data_compra__year=ano,
            data_compra__month=mes,
            status__in=STATUS_CONSIDERADOS_NO_TOTAL_DIARIO,
        )
        .values("data_compra")
        .annotate(total=Sum("valor"))
    )
    return {registro["data_compra"].day: registro["total"] for registro in compras}


def calendario_mensal(filial, ano, mes, limite_diario):
    """Monta a lista de dias do mês já classificados por cor, para o calendário visual."""
    total_dias = calendar_module.monthrange(ano, mes)[1]
    mapa = mapa_comprado_no_mes(filial, ano, mes)
    hoje = date.today()

    dias = []
    for dia_num in range(1, total_dias + 1):
        comprado = mapa.get(dia_num, ZERO)
        cor, proporcao = classificar_dia(comprado, limite_diario)
        dias.append(
            {
                "dia": dia_num,
                "data": date(ano, mes, dia_num),
                "comprado": comprado,
                "cor": cor,
                "proporcao": proporcao,
                "hoje": date(ano, mes, dia_num) == hoje,
            }
        )
    return dias


def obter_compras_do_usuario(usuario, filial, limite=None):
    """RC do Épico 01 (Correção 01): histórico das PRÓPRIAS compras do
    comprador — o escopo correto do perfil (antes ele via as compras de
    toda a filial). Gestores continuam usando as consultas por filial."""
    qs = (
        Compra.objects.filter(filial=filial, usuario=usuario)
        .select_related("fornecedor", "categoria", "centro_custo")
        .order_by("-data_compra", "-criado_em")
    )
    return qs[:limite] if limite else qs


def compras_visiveis_para(usuario, empresa=None):
    """Escopo de visualização de compras por perfil (RC do Épico 01 —
    Correção 01): o COMPRADOR enxerga somente as próprias compras; os
    perfis gestores seguem vendo todas as compras das filiais que já
    enxergavam. A restrição vive aqui (backend), não no template.

    Sprint de Correções Críticas (Seção 16) — aceita `empresa` (a empresa
    ATIVA do contexto) para resolver as filiais corretamente quando o
    usuário trocou de empresa; sem ela, cai no comportamento antigo
    (`usuario.filiais_visiveis()`, sempre a empresa principal) só por
    compatibilidade com chamadores que ainda não passam o contexto."""
    from usuarios.models import filiais_autorizadas_para

    filiais = filiais_autorizadas_para(usuario, empresa) if empresa is not None else usuario.filiais_visiveis()
    qs = Compra.objects.filter(filial__in=filiais).select_related(
        "filial", "fornecedor", "usuario", "categoria", "centro_custo"
    )
    if usuario.perfil == Usuario.Perfil.COMPRADOR:
        qs = qs.filter(usuario=usuario)
    return qs


def obter_compras_pendentes(filial, limite=None):
    """Compras aguardando aprovação do Gerente na filial (Sprint 5 — Central
    de Decisão e painel lateral do Comprador; também reaproveitada pelo
    Dashboard do Gerente, que antes montava esta mesma consulta na view)."""
    qs = (
        Compra.objects.filter(filial=filial, status=Compra.Status.PENDENTE)
        .select_related("fornecedor", "usuario")
        .order_by("-data_compra", "-criado_em")
    )
    return qs[:limite] if limite else qs


def ranking_fornecedores_do_mes(empresa, ano: int, mes: int, limite: int = 5) -> list[dict]:
    """Top fornecedores por valor comprado no mês, para o Dashboard do
    Proprietário (Demo Experience 1.0, item 11 — Ranking). Agregação
    somente leitura sobre `Compra`; não introduz nenhum model novo nem
    altera qualquer regra de aprovação/bloqueio."""
    registros = (
        Compra.objects.filter(
            empresa=empresa,
            data_compra__year=ano,
            data_compra__month=mes,
            status__in=STATUS_CONSIDERADOS_NO_TOTAL_DIARIO,
        )
        .values("fornecedor__nome")
        .annotate(total=Sum("valor"), quantidade=Count("id"))
        .order_by("-total")[:limite]
    )
    return [
        {"fornecedor": registro["fornecedor__nome"], "total": registro["total"] or ZERO, "quantidade": registro["quantidade"]}
        for registro in registros
    ]


def obter_compras_efetivadas_no_dia(filial, data_referencia: date) -> dict:
    """Quantidade e valor total das compras efetivadas (aprovadas) na
    filial num dia — novo card "Compras Efetivadas Hoje" (Sprint 5)."""
    agregado = Compra.objects.filter(
        filial=filial, data_compra=data_referencia, status=Compra.Status.APROVADA
    ).aggregate(quantidade=Count("id"), valor_total=Sum("valor"))
    return {
        "quantidade": agregado["quantidade"] or 0,
        "valor_total": agregado["valor_total"] or ZERO,
    }
