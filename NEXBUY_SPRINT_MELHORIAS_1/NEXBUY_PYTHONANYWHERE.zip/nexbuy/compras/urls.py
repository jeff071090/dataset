from django.urls import path

from . import views

app_name = "compras"

urlpatterns = [
    path("nova/", views.nova_compra, name="nova"),
    path("lista/", views.lista_compras, name="lista"),
    path("relatorios/por-comprador/", views.relatorio_compras_por_comprador, name="relatorio_por_comprador"),
    path("relatorios/por-filial/", views.relatorio_compras_por_filial, name="relatorio_por_filial"),
    path("aprovacao/", views.aprovacao_compras, name="aprovacao"),
    path("aprovacao/<int:pk>/aprovar/", views.aprovar_compra, name="aprovar"),
    path("aprovacao/<int:pk>/rejeitar/", views.rejeitar_compra, name="rejeitar"),
    path("fornecedores/", views.FornecedorListView.as_view(), name="fornecedor_list"),
    path("fornecedores/novo/", views.FornecedorCreateView.as_view(), name="fornecedor_create"),
    path("fornecedores/<int:pk>/editar/", views.FornecedorUpdateView.as_view(), name="fornecedor_update"),
    path("fornecedores/<int:pk>/excluir/", views.fornecedor_excluir, name="fornecedor_excluir"),
    path("fornecedores/<int:pk>/reativar/", views.fornecedor_reativar, name="fornecedor_reativar"),
    path("simulacao/", views.simular_compra, name="simulacao"),
]
