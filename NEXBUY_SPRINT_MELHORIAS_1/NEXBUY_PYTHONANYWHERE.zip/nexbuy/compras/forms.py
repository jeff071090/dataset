from decimal import Decimal

from django import forms

from cadastros.models import CentroCusto, Categoria
from core.forms import BootstrapFormMixin, MoedaFormMixin

from .models import Compra, Fornecedor


class CompraForm(MoedaFormMixin, BootstrapFormMixin, forms.ModelForm):
    campos_moeda = ("valor",)

    class Meta:
        model = Compra
        fields = [
            "filial",
            "fornecedor",
            "valor",
            "categoria",
            "centro_custo",
            "data_compra",
            "prazo_pagamento",
            "prazo_personalizado_dias",
            "numero_parcelas",
            "observacao",
        ]
        widgets = {"data_compra": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}

    def __init__(self, *args, user=None, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["prazo_personalizado_dias"].required = False
        self.fields["numero_parcelas"].required = False
        self.fields["observacao"].required = False
        self.fields["centro_custo"].required = False
        self.empresa_form = None

        if user is None:
            return

        # Sprint de Correções Críticas (Seção 11): filiais AUTORIZADAS na
        # empresa ATIVA — antes usava sempre `user.filiais_visiveis()` sem
        # contexto (resolve para a empresa principal), então um Comprador
        # com filial autorizada em outra empresa do grupo nunca conseguia
        # lançar compra lá, e a troca de empresa no seletor não tinha efeito
        # nesta tela.
        from usuarios.models import filiais_autorizadas_para

        empresa = empresa or user.empresa
        filiais = filiais_autorizadas_para(user, empresa) if empresa is not None else user.filiais_visiveis()
        self.fields["filial"].queryset = filiais

        if filiais.count() == 1:
            filial = filiais.first()
            self.fields["filial"].initial = filial
            empresa = filial.empresa
        self.empresa_form = empresa

        if empresa is not None:
            self.fields["fornecedor"].queryset = Fornecedor.objects.filter(empresa=empresa, ativo=True)
            self.fields["categoria"].queryset = Categoria.objects.filter(empresa=empresa, ativo=True)
            self.fields["centro_custo"].queryset = CentroCusto.objects.filter(empresa=empresa, ativo=True)
        else:
            self.fields["fornecedor"].queryset = Fornecedor.objects.none()
            self.fields["categoria"].queryset = Categoria.objects.none()
            self.fields["centro_custo"].queryset = CentroCusto.objects.none()

    def clean(self):
        cleaned_data = super().clean()
        prazo = cleaned_data.get("prazo_pagamento")
        dias = cleaned_data.get("prazo_personalizado_dias")
        parcelas = cleaned_data.get("numero_parcelas") or 1
        cleaned_data["numero_parcelas"] = parcelas
        if prazo == Compra.PrazoPagamento.PERSONALIZADO:
            if not dias:
                self.add_error("prazo_personalizado_dias", "Informe a quantidade de dias para o prazo personalizado.")
            # Política de parcelamento (Épico 12 — NCC): teto de parcelas da
            # empresa. Sem configuração cadastrada, vale o padrão do model
            # (12), que não muda nenhum comportamento existente.
            if parcelas < 1:
                self.add_error("numero_parcelas", "O número de parcelas deve ser 1 ou maior.")
            elif self.empresa_form is not None:
                from empresas.models import ConfiguracaoPlataforma

                maximo = (
                    ConfiguracaoPlataforma.objects.filter(empresa=self.empresa_form)
                    .values_list("parcelas_maximas", flat=True)
                    .first()
                    or 12
                )
                if parcelas > maximo:
                    self.add_error(
                        "numero_parcelas",
                        f"A política de parcelamento da empresa permite no máximo {maximo} parcelas.",
                    )
        return cleaned_data


class FornecedorForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Fornecedor
        fields = [
            "nome",
            "razao_social",
            "cnpj",
            "inscricao_estadual",
            "telefone",
            "whatsapp",
            "email",
            "cidade",
            "estado",
            "observacoes",
            "ativo",
        ]
        widgets = {"observacoes": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *args, user=None, empresa=None, **kwargs):
        self.user = user
        # CORE 1.0 (Épico 9): a empresa do contexto ativo, quando informada,
        # tem precedência sobre a empresa principal do usuário.
        self.empresa = empresa or (user.empresa if user is not None else None)
        super().__init__(*args, **kwargs)
        self.fields["razao_social"].required = True
        self.fields["cnpj"].required = True

    def clean_cnpj(self):
        cnpj = self.cleaned_data["cnpj"].strip()
        if self.empresa is not None:
            duplicado = (
                Fornecedor.objects.filter(empresa=self.empresa, cnpj=cnpj)
                .exclude(pk=self.instance.pk)
                .exists()
            )
            if duplicado:
                raise forms.ValidationError("Já existe um fornecedor cadastrado com este CNPJ.")
        return cnpj

    def save(self, commit=True):
        instance = super().save(commit=False)
        if self.empresa is not None:
            instance.empresa = self.empresa
        if commit:
            instance.save()
        return instance


class SimulacaoCompraForm(MoedaFormMixin, BootstrapFormMixin, forms.Form):
    """Formulário do Simulador de Compra (Sprint 3, item 5). Só os 4 campos
    pedidos pela especificação — a filial é resolvida a partir do usuário
    logado, como o restante do sistema já faz."""

    campos_moeda = ("valor",)

    fornecedor = forms.ModelChoiceField(queryset=Fornecedor.objects.none(), label="Fornecedor")
    valor = forms.DecimalField(label="Valor", max_digits=14, decimal_places=2, min_value=Decimal("0.01"))
    data_compra = forms.DateField(
        label="Data da compra", widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")
    )
    categoria = forms.ModelChoiceField(queryset=Categoria.objects.none(), label="Categoria")

    def __init__(self, *args, user=None, empresa=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user
        self.filial = None

        if user is None:
            return

        from usuarios.models import filiais_autorizadas_para

        empresa = empresa or user.empresa
        filiais = filiais_autorizadas_para(user, empresa) if empresa is not None else user.filiais_visiveis()
        if filiais.count() == 1:
            self.filial = filiais.first()

        empresa = self.filial.empresa if self.filial else empresa
        if empresa is not None:
            self.fields["fornecedor"].queryset = Fornecedor.objects.filter(empresa=empresa, ativo=True)
            self.fields["categoria"].queryset = Categoria.objects.filter(empresa=empresa, ativo=True)
