from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

from cadastros.models import CentroCusto, Categoria
from core.choices import UF_CHOICES
from core.models import ModeloAtivavel, TimeStampedModel
from empresas.models import Empresa
from filiais.models import Filial


class Fornecedor(TimeStampedModel, ModeloAtivavel):
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="fornecedores", verbose_name="Empresa")
    nome = models.CharField("Nome Fantasia", max_length=200)
    razao_social = models.CharField("Razão Social", max_length=200, blank=True)
    cnpj = models.CharField("CNPJ", max_length=18, blank=True)
    inscricao_estadual = models.CharField("Inscrição Estadual", max_length=20, blank=True)
    telefone = models.CharField("Telefone", max_length=20, blank=True)
    whatsapp = models.CharField("WhatsApp", max_length=20, blank=True)
    email = models.EmailField("E-mail", blank=True)
    cidade = models.CharField("Cidade", max_length=100, blank=True)
    estado = models.CharField("Estado", max_length=2, choices=UF_CHOICES, blank=True)
    observacoes = models.TextField("Observações", blank=True)

    class Meta:
        verbose_name = "Fornecedor"
        verbose_name_plural = "Fornecedores"
        ordering = ["nome"]
        constraints = [
            # RC do Épico 01: a unicidade de CNPJ por empresa era validada
            # só no formulário — agora também no banco (registros com CNPJ
            # em branco ficam de fora da restrição).
            models.UniqueConstraint(
                fields=["empresa", "cnpj"],
                condition=~models.Q(cnpj=""),
                name="fornecedor_cnpj_unico_por_empresa",
            ),
        ]

    def __str__(self):
        return self.nome


class Compra(TimeStampedModel):
    class PrazoPagamento(models.TextChoices):
        AVISTA = "avista", "À vista"
        D7 = "7dias", "7 dias"
        D14 = "14dias", "14 dias"
        D30 = "30dias", "30 dias"
        D60 = "60dias", "60 dias"
        # Épico 4 (CORE 1.0) — parcelamentos compostos. Os valores antigos
        # continuam significando o que sempre significaram (um único
        # pagamento no prazo indicado); os novos geram múltiplas parcelas.
        D30_60 = "30_60", "30/60 dias (2x)"
        D30_60_90 = "30_60_90", "30/60/90 dias (3x)"
        PERSONALIZADO = "personalizado", "Personalizado"

    class Status(models.TextChoices):
        APROVADA = "aprovada", "Aprovada"
        PENDENTE = "pendente", "Pendente de aprovação"
        BLOQUEADA = "bloqueada", "Bloqueada"
        REJEITADA = "rejeitada", "Rejeitada"

    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE, related_name="compras", verbose_name="Empresa")
    filial = models.ForeignKey(Filial, on_delete=models.CASCADE, related_name="compras", verbose_name="Filial")
    fornecedor = models.ForeignKey(
        Fornecedor, on_delete=models.PROTECT, related_name="compras", verbose_name="Fornecedor"
    )
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="compras", verbose_name="Lançado por"
    )
    # RC do Épico 01 (segurança por design): valor monetário validado em
    # DUAS camadas — no form/model (`MinValueValidator`) e no próprio banco
    # (`CheckConstraint` abaixo). Antes, um valor negativo gravado por fora
    # do formulário reduziria o total comprado do dia e contornaria a
    # Regra de Excesso de Limite — a dívida técnica nº 1 do Baseline.
    valor = models.DecimalField(
        "Valor", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))]
    )
    categoria = models.ForeignKey(
        Categoria, on_delete=models.PROTECT, related_name="compras", verbose_name="Categoria"
    )
    centro_custo = models.ForeignKey(
        CentroCusto,
        on_delete=models.SET_NULL,
        related_name="compras",
        verbose_name="Centro de Custo",
        null=True,
        blank=True,
    )
    data_compra = models.DateField("Data da compra", default=timezone.localdate)
    prazo_pagamento = models.CharField(
        "Prazo de pagamento", max_length=20, choices=PrazoPagamento.choices, default=PrazoPagamento.AVISTA
    )
    prazo_personalizado_dias = models.PositiveIntegerField("Prazo personalizado (dias)", null=True, blank=True)
    # Épico 4 (CORE 1.0) — só usado com prazo Personalizado: N parcelas com
    # intervalo de `prazo_personalizado_dias` entre elas. Default 1 preserva
    # o comportamento histórico (um único pagamento no prazo informado).
    numero_parcelas = models.PositiveSmallIntegerField(
        "Número de parcelas (personalizado)",
        default=1,
        help_text="Usado apenas com o prazo Personalizado: quantidade de parcelas com o intervalo de dias informado.",
    )
    status = models.CharField("Status", max_length=20, choices=Status.choices, default=Status.APROVADA)
    alerta_excesso = models.BooleanField("Ultrapassou o limite (alerta)", default=False)
    observacao = models.CharField("Observação", max_length=255, blank=True)
    # Sprint de Correções Críticas (Seção 12) — presente somente quando esta
    # Compra nasceu da EFETIVAÇÃO de uma Provisão (`gestao_compras.services.
    # efetivar_provisao`). `OneToOneField` garante as duas regras pedidas de
    # uma vez: opcional (NULL permitido) e, quando preenchido, único — nunca
    # duas Compras para a mesma Provisão. `PROTECT` porque uma Provisão já
    # efetivada não pode ser excluída sem primeiro decidir o destino da
    # Compra gerada por ela (ela é o registro fonte do compromisso real).
    provisao_origem = models.OneToOneField(
        "gestao_compras.Provisao",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="compra_efetivada",
        verbose_name="Provisão de origem",
    )

    class Meta:
        verbose_name = "Compra"
        verbose_name_plural = "Compras"
        ordering = ["-data_compra", "-criado_em"]
        indexes = [
            # Cobre as consultas mais frequentes do sistema: total comprado
            # no dia/mês de uma filial (`compras.services`, `finance_engine`,
            # `dashboard`) e a fila de compras pendentes por status
            # (Sprint 4.1, auditoria de performance).
            models.Index(fields=["filial", "data_compra"], name="compra_filial_data_idx"),
            models.Index(fields=["status"], name="compra_status_idx"),
        ]
        constraints = [
            models.CheckConstraint(condition=models.Q(valor__gt=0), name="compra_valor_positivo"),
        ]

    def __str__(self):
        return f"{self.fornecedor} - R$ {self.valor} ({self.data_compra:%d/%m/%Y})"

    @property
    def total_parcelas(self) -> int:
        """Quantidade REAL de parcelas desta Compra — fonte única para
        exibir "Parcela X/Y" (Sprint de Correções Críticas, Seção 15).

        Gate pré-Etapa 10 (S1-4): `numero_parcelas` passou a ser calculado
        corretamente para TODOS os prazos (antes só era preenchido de
        verdade para o Personalizado — auditoria externa encontrou compras
        30/60 e 30/60/90 com `numero_parcelas=1` apesar de 2 e 3 parcelas
        reais). Ainda assim, prioriza contar as parcelas materializadas de
        verdade (`gerar_parcelas_da_compra`) quando existem — é a fonte
        mais autoritativa possível e cobre até dados antigos que uma
        eventual falha na migration de correção não tenha alcançado."""
        contagem = self.parcelas.count()
        return contagem or self.numero_parcelas


class ParcelaCompra(TimeStampedModel):
    """Parcela (compromisso futuro de pagamento) de uma Compra (Épico 4 —
    CORE 1.0). Gerada automaticamente pelo service ao criar/aprovar uma
    Compra, conforme o prazo de pagamento escolhido; alimenta a Agenda
    Financeira e os cards de "Pagamentos de hoje"/"Próximos vencimentos".

    Parcelas nunca são editadas diretamente pelo usuário — apenas o status
    muda (Pendente → Paga), e o cancelamento acompanha o destino da Compra
    (uma compra rejeitada nunca chega a ter parcelas).
    """

    class Status(models.TextChoices):
        PENDENTE = "pendente", "Pendente"
        PAGA = "paga", "Paga"
        CANCELADA = "cancelada", "Cancelada"

    compra = models.ForeignKey(Compra, on_delete=models.CASCADE, related_name="parcelas", verbose_name="Compra")
    numero = models.PositiveSmallIntegerField("Número da parcela")
    data_vencimento = models.DateField("Vencimento")
    valor = models.DecimalField("Valor", max_digits=14, decimal_places=2)
    status = models.CharField("Status", max_length=15, choices=Status.choices, default=Status.PENDENTE)

    class Meta:
        verbose_name = "Parcela da Compra"
        verbose_name_plural = "Parcelas das Compras"
        ordering = ["data_vencimento", "numero"]
        constraints = [
            models.UniqueConstraint(fields=["compra", "numero"], name="parcela_unica_por_compra")
        ]
        indexes = [
            # A Agenda Financeira sempre consulta por vencimento + status
            # (pagamentos de hoje, próximos vencimentos, parcelas vencidas).
            models.Index(fields=["data_vencimento", "status"], name="parcela_venc_status_idx"),
        ]

    def __str__(self):
        return f"Parcela {self.numero} — {self.compra} (venc. {self.data_vencimento:%d/%m/%Y})"


class HistoricoCompra(TimeStampedModel):
    """Log de auditoria simples e append-only de uma Compra: quem criou,
    aprovou ou rejeitou e quando (Sprint 4.1 — item 5, auditoria).

    Mesma finalidade e formato de `gestao_compras.HistoricoProvisao`, mas
    mantido em `compras` (e não em `core`) porque, assim como esse outro
    histórico, só faz sentido junto do model que audita — evita uma
    dependência genérica (`GenericForeignKey`) que a Sprint não pediu."""

    class Acao(models.TextChoices):
        CRIACAO = "criacao", "Criação"
        APROVACAO = "aprovacao", "Aprovação"
        REJEICAO = "rejeicao", "Rejeição"
        # Épico 4 (CORE 1.0) — baixa manual de parcela na Agenda Financeira.
        PAGAMENTO = "pagamento", "Pagamento de parcela"
        # Prompt 2 (pré-Etapa 02), Gate A/D/E/F: reversão de uma baixa feita
        # por engano — devolve a parcela a PENDENTE (nunca cria uma parcela
        # nova nem duplica valor).
        ESTORNO = "estorno", "Estorno de pagamento"

    compra = models.ForeignKey(Compra, on_delete=models.CASCADE, related_name="historico", verbose_name="Compra")
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="+", verbose_name="Usuário"
    )
    acao = models.CharField("Ação", max_length=15, choices=Acao.choices)
    detalhe = models.TextField("Detalhe", blank=True)

    class Meta:
        verbose_name = "Histórico da Compra"
        verbose_name_plural = "Histórico das Compras"
        ordering = ["criado_em"]

    def __str__(self):
        return f"{self.get_acao_display()} — {self.compra} ({self.criado_em:%d/%m/%Y %H:%M})"
