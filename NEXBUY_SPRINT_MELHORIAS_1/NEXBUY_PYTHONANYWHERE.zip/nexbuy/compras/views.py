from calendar import monthrange
from datetime import date
from decimal import Decimal

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Count, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.views.generic import CreateView, ListView, UpdateView

from auditoria.models import RegistroAuditoria
from auditoria.services import ip_do_request, registrar_evento
from core.contexto import empresa_ativa, filiais_do_contexto
from core.mixins import EmpresaScopedFormMixin, EmpresaScopedListMixin
from core.permissions import (
    PERFIS_GESTORES_FINANCEIROS,
    TODOS_OS_PERFIS,
    PerfilRequiredMixin,
    perfil_required,
    permissao_required,
)
from core.relatorios import resposta_csv
from core.utils import formatar_cnpj, formatar_moeda
from finance_engine.simulations import simulador_compra
from finance_engine.validators import SimulacaoInvalidaError
from usuarios.models import Usuario

from .forms import CompraForm, FornecedorForm, SimulacaoCompraForm
from .models import Compra, Fornecedor
from .services import (
    STATUS_REALIZADO,
    AutoaprovacaoBloqueadaError,
    CompraJaDecididaError,
    aprovar_compra_pendente,
    avaliar_e_criar_compra,
    compras_visiveis_para,
    rejeitar_compra_pendente,
)

PERFIS_VISUALIZACAO_COMPRAS = TODOS_OS_PERFIS
PERFIS_GESTAO_FORNECEDORES = PERFIS_GESTORES_FINANCEIROS
PERFIS_SIMULACAO = (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.FINANCEIRO, Usuario.Perfil.COMPRADOR)


def cadastros_de_apoio_faltando(usuario, empresa) -> list:
    """Crítico de UX (rodada 1) — estado vazio de Nova Compra / Nova
    Provisão: num sistema recém-implantado os selects Fornecedor e
    Categoria só tinham "---------", sem nenhuma orientação — e o
    Comprador, que não pode cadastrar fornecedores, ficava num beco sem
    saída. Devolve o que falta (fornecedor/categoria ATIVOS da empresa, o
    mesmo filtro dos selects dos forms) e, para cada item, o link de
    cadastro SÓ para quem a view de cadastro aceita (gate do link = gate
    da view); para os demais, quem procurar."""
    from cadastros.models import Categoria
    from cadastros.views import PERFIS_GESTAO_CADASTROS

    if empresa is None:
        return []
    faltando = []
    if not Fornecedor.objects.filter(empresa=empresa, ativo=True).exists():
        faltando.append({
            "texto": "Nenhum fornecedor ativo cadastrado.",
            "url": reverse("compras:fornecedor_create") if usuario.perfil in PERFIS_GESTAO_FORNECEDORES else "",
            "rotulo_link": "Cadastrar fornecedor",
        })
    if not Categoria.objects.filter(empresa=empresa, ativo=True).exists():
        faltando.append({
            "texto": "Nenhuma categoria de compra ativa cadastrada.",
            "url": reverse("cadastros:categoria_create") if usuario.perfil in PERFIS_GESTAO_CADASTROS else "",
            "rotulo_link": "Cadastrar categoria",
        })
    return faltando


@permissao_required("compras.lancar")
def nova_compra(request):
    # Sprint de Correções Críticas (Seções 11/16): empresa ATIVA do
    # contexto — o form só oferece as filiais autorizadas do Comprador
    # NESSA empresa (pode ser mais de uma), nunca a lista da empresa
    # principal fixa.
    empresa = empresa_ativa(request)
    if request.method == "POST":
        form = CompraForm(request.POST, user=request.user, empresa=empresa)
        if form.is_valid():
            dados = form.cleaned_data
            avaliacao = avaliar_e_criar_compra(
                filial=dados["filial"],
                fornecedor=dados["fornecedor"],
                valor=dados["valor"],
                categoria=dados["categoria"],
                centro_custo=dados.get("centro_custo"),
                data_compra=dados["data_compra"],
                prazo_pagamento=dados["prazo_pagamento"],
                prazo_personalizado_dias=dados.get("prazo_personalizado_dias"),
                numero_parcelas=dados.get("numero_parcelas") or 1,
                usuario=request.user,
                observacao=dados.get("observacao", ""),
            )
            compra = avaliacao.compra
            nota_saldo = ""
            if avaliacao.saldo_acumulado:
                nota_saldo = (
                    f" (inclui saldo acumulado de dias anteriores de {formatar_moeda(avaliacao.saldo_acumulado, incluir_prefixo=True)})"
                )

            # Crítico funcional (rodada 1): num dia sem limite próprio (fim de
            # semana pela regra padrão, feriado, bloqueio) a mensagem explica
            # o porquê em vez de só dizer "limite de R$ 0,00 ultrapassado".
            nota_dia = ""
            if avaliacao.limite_diario <= 0:
                from finance_engine.calendario_operacional import dia_conta_capacidade, rotulo_do_tipo, tipo_do_dia

                from finance_engine.services import receita_configurada

                tipo = tipo_do_dia(compra.empresa, compra.data_compra)
                if not dia_conta_capacidade(tipo):
                    nota_dia = (
                        f" {compra.data_compra:%d/%m/%Y} é {rotulo_do_tipo(tipo)}: pela regra do Calendário "
                        "Operacional, este dia não tem limite de compra próprio."
                    )
                elif not receita_configurada(compra.filial, compra.data_compra.year, compra.data_compra.month):
                    # Sprint de Melhorias 1: sem receita lançada no mês não
                    # existe limite — a mensagem diz o motivo e o que fazer,
                    # em vez de um "limite ultrapassado" sem explicação.
                    nota_dia = (
                        f" A receita de {compra.data_compra:%m/%Y} da filial {compra.filial.nome} ainda não foi "
                        "lançada — sem ela o NEXBUY não sabe quanto pode ser comprado. Peça ao Financeiro "
                        "para lançar em Financeiro → Receitas."
                    )

            if compra.status == Compra.Status.BLOQUEADA:
                messages.error(
                    request,
                    f"Compra BLOQUEADA: o limite diário de {formatar_moeda(avaliacao.limite_diario, incluir_prefixo=True)}{nota_saldo} da filial "
                    f"{compra.filial.nome} foi ultrapassado.{nota_dia}",
                )
            elif compra.status == Compra.Status.PENDENTE:
                messages.warning(
                    request,
                    f"Limite diário ultrapassado: a compra foi enviada para aprovação do gerente.{nota_dia}",
                )
            elif compra.alerta_excesso:
                messages.warning(
                    request,
                    f"Compra registrada, mas o limite diário de {formatar_moeda(avaliacao.limite_diario, incluir_prefixo=True)}{nota_saldo} foi "
                    f"ultrapassado. Fique atento à sua capacidade financeira.{nota_dia}",
                )
            else:
                messages.success(request, "Compra lançada com sucesso.")
            return redirect("compras:lista")
    else:
        form = CompraForm(user=request.user, empresa=empresa, initial={"data_compra": timezone.localdate()})

    return render(
        request,
        "compras/compra_form.html",
        {"form": form, "cadastros_faltando": cadastros_de_apoio_faltando(request.user, empresa)},
    )


COMPRAS_POR_PAGINA = 50


@perfil_required(*PERFIS_VISUALIZACAO_COMPRAS)
def lista_compras(request):
    """RC do Épico 01 (Correção 01): o escopo por perfil vem do service —
    o Comprador recebe apenas as PRÓPRIAS compras; gestores, as da filial.

    Sprint de Consolidação (Gate 2A, P1-6): `?formato=csv` exporta a MESMA
    consulta já escopada por perfil — a exportação nunca pode mostrar mais
    do que a tela já mostra.

    Sprint de Correções Críticas (Seção 16): passa a empresa ATIVA do
    contexto — antes usava sempre a empresa principal do usuário, então um
    Proprietário que trocasse de empresa continuava vendo o histórico da
    empresa errada aqui (achado da auditoria funcional)."""
    compras = compras_visiveis_para(request.user, empresa_ativa(request)).select_related(
        "fornecedor", "filial", "categoria", "centro_custo", "usuario"
    )

    if request.GET.get("formato") == "csv":
        linhas = [
            [
                compra.data_compra.strftime("%d/%m/%Y"),
                compra.fornecedor.nome,
                compra.filial.nome,
                compra.categoria.nome,
                compra.centro_custo.nome if compra.centro_custo else "",
                str(compra.valor).replace(".", ","),
                compra.get_prazo_pagamento_display(),
                compra.usuario.get_full_name() or compra.usuario.username,
                compra.get_status_display(),
            ]
            for compra in compras
        ]
        return resposta_csv(
            "historico_de_compras.csv",
            ["Data", "Fornecedor", "Filial", "Categoria", "Centro de Custo", "Valor (R$)", "Prazo", "Lançado por", "Status"],
            linhas,
        )

    # Gate 2 (Sprint de Encerramento Definitivo): a listagem continua
    # mostrando TODOS os status (histórico completo, comportamento
    # preservado), mas o "Total" do rodapé é só o que foi de fato
    # comprado (`STATUS_REALIZADO` = Aprovada) — Rejeitada/Bloqueada/
    # Pendente não são valor comprado e não podem inflar esse número.
    total_valor = compras.filter(status__in=STATUS_REALIZADO).aggregate(total=Sum("valor"))["total"] or 0
    # Sprint de Melhorias 1 (usabilidade): 50 compras por página — com um ano
    # de uso a lista inteira passava de 600 linhas numa página só. O total do
    # rodapé e o CSV continuam sobre TODAS as compras, não só a página.
    page_obj = Paginator(compras, COMPRAS_POR_PAGINA).get_page(request.GET.get("page"))
    return render(
        request, "compras/compra_list.html",
        {"compras": page_obj, "page_obj": page_obj, "total_valor": total_valor},
    )


# --------------------------------------------------------------------------
# Relatórios agregados (Sprint de Consolidação — Gate 2A, P1-6)
# --------------------------------------------------------------------------

PERFIS_GESTORES = (Usuario.Perfil.PROPRIETARIO, Usuario.Perfil.GERENTE, Usuario.Perfil.FINANCEIRO)


def _periodo_do_mes(request):
    hoje = timezone.localdate()
    try:
        ano = int(request.GET.get("ano", hoje.year))
        mes = int(request.GET.get("mes", hoje.month))
        inicio = date(ano, mes, 1)
    except (TypeError, ValueError):
        ano, mes, inicio = hoje.year, hoje.month, hoje.replace(day=1)
    fim = date(ano, mes, monthrange(ano, mes)[1])
    return ano, mes, inicio, fim


def _compras_do_periodo_no_contexto(request, inicio, fim):
    """Recorte "realizado" do período, dentro do contexto de EMPRESA ATIVA
    (Sprint de Consolidação — mesma coerência multiempresa da Parte 3/P0-5,
    aplicada aqui: os relatórios agregados novos nunca podem misturar
    dados de uma empresa que não é a ativa no seletor de contexto).

    Gate 2 (Sprint de Encerramento Definitivo): NÃO é "todas as compras do
    período" — só `STATUS_REALIZADO` (Aprovada) entra aqui. Antes desta
    correção, esta função não filtrava por status, então os relatórios que
    a usam (por Comprador, por Filial — HTML, CSV e impressão) somavam
    Compra REJEITADA e BLOQUEADA junto com APROVADA/PENDENTE como se
    fossem "quanto se comprou", um erro de verdade financeira grave
    (achado real: 8 aprovadas R$13.117,27 + 2 rejeitadas R$600.000,00
    exibidas juntas como R$613.117,27)."""
    filiais = filiais_do_contexto(request)
    qs = Compra.objects.filter(
        filial__in=filiais, data_compra__gte=inicio, data_compra__lte=fim, status__in=STATUS_REALIZADO
    ).select_related("filial", "filial__empresa", "usuario")
    if request.user.perfil == Usuario.Perfil.COMPRADOR:
        qs = qs.filter(usuario=request.user)
    return qs


@perfil_required(*PERFIS_GESTORES)
def relatorio_compras_por_comprador(request):
    """Quanto cada comprador gastou no mês — relatório de gestão, não
    disponível para o próprio Comprador (veria o gasto dos colegas)."""
    ano, mes, inicio, fim = _periodo_do_mes(request)
    compras = _compras_do_periodo_no_contexto(request, inicio, fim)

    agregados = list(
        compras.values("usuario_id", "usuario__first_name", "usuario__last_name", "usuario__username")
        .annotate(quantidade=Count("id"), total=Sum("valor"))
        .order_by("-total")
    )
    for linha in agregados:
        linha["nome"] = (
            f"{linha['usuario__first_name']} {linha['usuario__last_name']}".strip() or linha["usuario__username"]
        )

    if request.GET.get("formato") == "csv":
        # Sum() agregado pode devolver Decimal sem as 2 casas do campo (ex.:
        # "100" em vez de "100.00") — formata explicitamente, sem depender
        # da escala que o banco devolveu.
        linhas = [
            [linha["nome"], linha["quantidade"], "{:.2f}".format(linha["total"]).replace(".", ",")]
            for linha in agregados
        ]
        return resposta_csv("compras_por_comprador.csv", ["Comprador", "Qtd. Compras", "Total (R$)"], linhas)

    total_geral = sum((linha["total"] for linha in agregados), Decimal("0"))
    return render(
        request,
        "compras/relatorio_por_comprador.html",
        {
            "agregados": agregados, "total_geral": total_geral, "ano": ano, "mes": mes,
            "mes_referencia": inicio, "periodo": f"{inicio:%d/%m/%Y} a {fim:%d/%m/%Y}",
            "mes_anterior": (ano, mes - 1) if mes > 1 else (ano - 1, 12),
            "mes_seguinte": (ano, mes + 1) if mes < 12 else (ano + 1, 1),
        },
    )


@perfil_required(*PERFIS_GESTORES)
def relatorio_compras_por_filial(request):
    """Quanto se comprou em cada filial/CNPJ da empresa ativa no mês —
    útil ao Proprietário para comparar filiais (e, trocando o seletor de
    empresa, comparar CNPJs diferentes do grupo)."""
    empresa = empresa_ativa(request)
    # Item 13 do Checklist Guiado de Implantação
    # (empresas/services_checklist.py): antes, "visualizar uma tela" não
    # deixava nenhum rastro no banco, então o item ficava SEMPRE pendente,
    # mesmo depois de o usuário genuinamente abrir este relatório. Agora a
    # PRIMEIRA visita da Empresa grava um evento real na auditoria — só a
    # primeira (checagem de existência antes de criar): a Central de
    # Auditoria existe para registrar decisões/mudanças de configuração,
    # não tráfego de página, então visitas repetidas ao mesmo relatório não
    # deveriam empilhar eventos idênticos. Isso abre uma janela de corrida
    # pequena e inofensiva sob concorrência (duas primeiras visitas
    # simultâneas podem gravar 2 eventos idênticos) — aceitável para um
    # marcador de "já visitei", não um registro financeiro. Nenhum estado
    # de sessão entra aqui: o sinal mora no banco, escopado pela Empresa.
    if empresa is not None and not RegistroAuditoria.objects.filter(
        empresa=empresa, categoria=RegistroAuditoria.Categoria.RELATORIO_VISUALIZADO,
    ).exists():
        registrar_evento(
            categoria=RegistroAuditoria.Categoria.RELATORIO_VISUALIZADO,
            descricao="Relatório de Compras por Filial visualizado pela primeira vez.",
            empresa=empresa, usuario=request.user, ip=ip_do_request(request),
            modulo="compras", acao="visualizar_relatorio",
        )
    ano, mes, inicio, fim = _periodo_do_mes(request)
    compras = _compras_do_periodo_no_contexto(request, inicio, fim)

    agregados = list(
        compras.values("filial_id", "filial__nome", "filial__empresa__nome", "filial__empresa__cnpj")
        .annotate(quantidade=Count("id"), total=Sum("valor"))
        .order_by("-total")
    )

    if request.GET.get("formato") == "csv":
        linhas = [
            [
                linha["filial__empresa__nome"], formatar_cnpj(linha["filial__empresa__cnpj"]), linha["filial__nome"],
                linha["quantidade"], "{:.2f}".format(linha["total"]).replace(".", ","),
            ]
            for linha in agregados
        ]
        return resposta_csv(
            "compras_por_filial.csv", ["Empresa", "CNPJ", "Filial", "Qtd. Compras", "Total (R$)"], linhas,
        )

    total_geral = sum((linha["total"] for linha in agregados), Decimal("0"))
    return render(
        request,
        "compras/relatorio_por_filial.html",
        {
            "agregados": agregados, "total_geral": total_geral, "ano": ano, "mes": mes,
            "mes_referencia": inicio, "periodo": f"{inicio:%d/%m/%Y} a {fim:%d/%m/%Y}",
            "mes_anterior": (ano, mes - 1) if mes > 1 else (ano - 1, 12),
            "mes_seguinte": (ano, mes + 1) if mes < 12 else (ano + 1, 1),
        },
    )


@permissao_required("compras.aprovar")
def aprovacao_compras(request):
    # Sprint de Correções Críticas (Seção 16): filiais da empresa ATIVA —
    # antes usava a empresa principal do usuário (mesmo bug já corrigido na
    # Central de Aprovações e na Aprovação de Provisões).
    compras_pendentes = (
        Compra.objects.filter(filial__in=filiais_do_contexto(request), status=Compra.Status.PENDENTE)
        .select_related("filial", "fornecedor", "usuario", "categoria", "centro_custo")
    )
    return render(request, "compras/aprovacao_list.html", {"compras": compras_pendentes})


@permissao_required("compras.aprovar")
def aprovar_compra(request, pk):
    compra = get_object_or_404(
        Compra, pk=pk, filial__in=filiais_do_contexto(request), status=Compra.Status.PENDENTE
    )
    if request.method == "POST":
        try:
            aprovar_compra_pendente(compra, request.user)
        except (CompraJaDecididaError, AutoaprovacaoBloqueadaError) as exc:
            messages.error(request, str(exc))
        else:
            messages.success(request, f"Compra de {compra.fornecedor} aprovada.")
    return redirect("compras:aprovacao")


@permissao_required("compras.aprovar")
def rejeitar_compra(request, pk):
    compra = get_object_or_404(
        Compra, pk=pk, filial__in=filiais_do_contexto(request), status=Compra.Status.PENDENTE
    )
    if request.method == "POST":
        try:
            rejeitar_compra_pendente(compra, request.user)
        except CompraJaDecididaError as exc:
            messages.error(request, str(exc))
        else:
            messages.info(request, f"Compra de {compra.fornecedor} rejeitada.")
    return redirect("compras:aprovacao")


# --------------------------------------------------------------------------
# Fornecedores (Módulo 1 — Etapa 2)
# --------------------------------------------------------------------------


class FornecedorListView(PerfilRequiredMixin, EmpresaScopedListMixin, ListView):
    model = Fornecedor
    template_name = "compras/fornecedor_list.html"
    context_object_name = "fornecedores"
    perfis_permitidos = PERFIS_GESTAO_FORNECEDORES
    search_fields = ("nome", "razao_social", "cnpj")


class FornecedorCreateView(PerfilRequiredMixin, EmpresaScopedFormMixin, CreateView):
    model = Fornecedor
    form_class = FornecedorForm
    template_name = "compras/fornecedor_form.html"
    success_url = reverse_lazy("compras:fornecedor_list")
    perfis_permitidos = PERFIS_GESTAO_FORNECEDORES
    extra_context = {"titulo": "Novo Fornecedor"}

    def form_valid(self, form):
        messages.success(self.request, "Fornecedor cadastrado com sucesso.")
        return super().form_valid(form)


class FornecedorUpdateView(PerfilRequiredMixin, EmpresaScopedFormMixin, UpdateView):
    model = Fornecedor
    form_class = FornecedorForm
    template_name = "compras/fornecedor_form.html"
    success_url = reverse_lazy("compras:fornecedor_list")
    perfis_permitidos = PERFIS_GESTAO_FORNECEDORES
    extra_context = {"titulo": "Editar Fornecedor"}

    def get_queryset(self):
        # Sprint de Consolidação (Gate 2A, P0-5): escopo pela EMPRESA ATIVA
        # do contexto, não pela empresa "de casa" do usuário — senão editar
        # um fornecedor de uma empresa que não é a principal do usuário
        # (mas está ativa no seletor de contexto) devolvia 404, apesar de o
        # fornecedor aparecer normalmente na listagem (que já usa o
        # contexto certo via EmpresaScopedListMixin).
        return Fornecedor.objects.filter(empresa=empresa_ativa(self.request))

    def form_valid(self, form):
        messages.success(self.request, "Fornecedor atualizado com sucesso.")
        return super().form_valid(form)


@perfil_required(*PERFIS_GESTAO_FORNECEDORES)
def fornecedor_excluir(request, pk):
    """Exclusão lógica: mantém o histórico de compras, apenas desativa o fornecedor."""
    fornecedor = get_object_or_404(Fornecedor, pk=pk, empresa=empresa_ativa(request))
    if request.method == "POST":
        fornecedor.ativo = False
        fornecedor.save(update_fields=["ativo", "atualizado_em"])
        messages.success(request, f'Fornecedor "{fornecedor.nome}" desativado.')
    return redirect("compras:fornecedor_list")


@perfil_required(*PERFIS_GESTAO_FORNECEDORES)
def fornecedor_reativar(request, pk):
    fornecedor = get_object_or_404(Fornecedor, pk=pk, empresa=empresa_ativa(request))
    if request.method == "POST":
        fornecedor.ativo = True
        fornecedor.save(update_fields=["ativo", "atualizado_em"])
        messages.success(request, f'Fornecedor "{fornecedor.nome}" reativado.')
    return redirect("compras:fornecedor_list")


# --------------------------------------------------------------------------
# Simulador de Compra (Sprint 3, item 5 — Motor Financeiro)
# --------------------------------------------------------------------------


@perfil_required(*PERFIS_SIMULACAO)
def simular_compra(request):
    """Simula o efeito de uma compra hipotética sem gravar nada no banco.
    A regra em si vive em `finance_engine.simulations.SimuladorCompraService`
    — esta view só coleta o formulário e mostra o resultado."""
    # RC do Épico 01 (Correção 02): o Calendário Financeiro encaminha o dia
    # clicado por querystring — pré-preenche a data da simulação.
    initial = {}
    data_sugerida = request.GET.get("data", "")
    if data_sugerida:
        initial["data_compra"] = data_sugerida
    form = SimulacaoCompraForm(
        request.POST or None, user=request.user, empresa=empresa_ativa(request), initial=initial
    )
    resultado = None
    erro = None

    if request.method == "POST" and form.is_valid():
        if form.filial is None:
            erro = "Seu usuário não está vinculado a uma única filial — a simulação precisa de uma filial definida."
        else:
            try:
                resultado = simulador_compra.simular(
                    filial=form.filial,
                    fornecedor=form.cleaned_data["fornecedor"],
                    valor=form.cleaned_data["valor"],
                    data_compra=form.cleaned_data["data_compra"],
                    categoria=form.cleaned_data["categoria"],
                )
            except SimulacaoInvalidaError as exc:
                erro = str(exc)

    return render(request, "compras/simulacao_form.html", {"form": form, "resultado": resultado, "erro": erro})
