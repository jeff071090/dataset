from django.contrib import admin

from .models import Compra, Fornecedor, HistoricoCompra, ParcelaCompra


class ParcelaCompraInline(admin.TabularInline):
    model = ParcelaCompra
    extra = 0
    readonly_fields = ("numero", "data_vencimento", "valor")


@admin.register(Fornecedor)
class FornecedorAdmin(admin.ModelAdmin):
    list_display = ("nome", "razao_social", "empresa", "cnpj", "cidade", "estado", "ativo")
    list_filter = ("empresa", "ativo", "estado")
    search_fields = ("nome", "razao_social", "cnpj")


class HistoricoCompraInline(admin.TabularInline):
    model = HistoricoCompra
    extra = 0
    readonly_fields = ("usuario", "acao", "detalhe", "criado_em")
    can_delete = False


@admin.register(Compra)
class CompraAdmin(admin.ModelAdmin):
    list_display = (
        "fornecedor", "filial", "valor", "categoria", "centro_custo", "data_compra", "status", "alerta_excesso"
    )
    list_filter = ("status", "categoria", "centro_custo", "filial", "alerta_excesso")
    date_hierarchy = "data_compra"
    search_fields = ("fornecedor__nome", "observacao")
    inlines = [ParcelaCompraInline, HistoricoCompraInline]
