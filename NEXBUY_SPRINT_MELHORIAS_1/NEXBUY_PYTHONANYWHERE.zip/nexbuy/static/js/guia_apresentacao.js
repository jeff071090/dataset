/* Guia da apresentação (Sprint de Apresentação Comercial, Seção 5.3).
 *
 * Microsprint corretiva (gate do relatório consolidado):
 * 1. EXTERNALIZADO — nenhum script inline no HTML das telas reais (o
 *    inline anterior usava um identificador cujo nome contém um literal
 *    que as varreduras de tela legitimamente proíbem no HTML renderizado);
 *    este arquivo NÃO usa esse identificador (parse defensivo abaixo).
 * 2. Inicia SEMPRE RECOLHIDO — nunca cobre Agenda, Auditoria ou qualquer
 *    conteúdo ao abrir uma tela; o apresentador expande pela pílula e a
 *    preferência fica na sessão da aba.
 *
 * O guia orienta as 8 cenas e NUNCA executa ações pelo apresentador nem
 * altera o banco: só navegação/estado local (sessionStorage).
 */
(function () {
  "use strict";
  var raiz = document.getElementById("nxGuia");
  if (!raiz) { return; }

  var CENAS = [
    { titulo: "1. Uma visão para toda a operação", perfil: "Proprietário",
      acao: "Mostre o Dashboard Executivo: KPIs do grupo, aprovações pendentes e o seletor de empresa (matriz e filiais). No quadro Resultado do mês, o mês corrente vem marcado como parcial (compras só até hoje); o número para comentar é o do mês fechado, ao lado.",
      href: "/" },
    { titulo: "2. Autonomia sem perder o controle", perfil: "Comprador",
      acao: "Troque para o Comprador (menu do nome). Mostre saldo do dia e Compra × Provisão; peça ao cliente um VALOR PEQUENO e crie uma provisão — aprova na hora.",
      href: "/gestao-compras/nova/" },
    { titulo: "3. O controle aparece quando é necessário", perfil: "Comprador",
      acao: "Peça um valor MAIOR que o limite e crie outra provisão: aviso claro de estouro e status aguardando aprovação — sem erro confuso.",
      href: "/gestao-compras/nova/" },
    { titulo: "4. A decisão chega à pessoa certa", perfil: "Gerente → Financeiro",
      acao: "Troque para o Gerente: fila de aprovação, Decidir → Aprovar. Acima de R$ 2.000 avança para o Financeiro — troque e conclua a 2ª etapa.",
      href: "/gestao-compras/aprovacao/" },
    { titulo: "5. A compra deixa de ser surpresa", perfil: "Financeiro",
      acao: "Mostre a Agenda de 30 dias com a provisão aprovada entre custos fixos e parcelas; depois Contas a Pagar. O compromisso aparece ANTES do boleto.",
      href: "/financeiro/agenda/" },
    { titulo: "6. A farmácia está saudável?", perfil: "Financeiro ou Proprietário",
      acao: "Abra a Análise Financeira. DRE Gerencial: receita, compras (em torno de 60% a 65% da receita nos meses fechados), margens e resultado, com a curva de 12 meses — aponte o mês que fechou no prejuízo. Créditos × Débitos: o que entrou e saiu por vencimento e o mês em que o caixa ficou no vermelho. Saúde Financeira: semáforo dos indicadores e recomendações em reais (receita em queda, custos fixos acima da referência). Pergunte: hoje vocês sabem, no fim do mês, se sobrou dinheiro? Até o dia 24 o link abre o último mês fechado; do dia 25 em diante, o mês corrente.",
      href: "/financeiro/analise/" },
    { titulo: "7. Toda decisão deixa uma história", perfil: "Proprietário",
      acao: "Troque para o Proprietário: relatório por filial e Central de Auditoria — o pedido de AGORA já está lá, com quem, quando e por quê.",
      href: "/ncc/central-auditoria/" },
    { titulo: "8. O que está pronto e para onde evoluir", perfil: "Proprietário",
      acao: "Tela Integrações: só o DDA aparece, como integração prevista e ainda não conectada — honestidade total. Reforce que receitas, custos e compras são lançados manualmente e já alimentam a projeção e os limites. Pergunte: qual etapa mais se aproxima do problema de vocês? Depois abra o Encerramento.",
      href: "/ncc/integracoes/" },
  ];
  var CHAVE = "nxGuiaCena", CHAVE_ABERTO = "nxGuiaAberto";
  var URL_ANALISE = "/financeiro/analise/";

  // Cena da Análise Financeira: a DRE do mês corrente compara as compras
  // feitas ATÉ HOJE com a receita do mês inteiro — no começo do mês ela
  // ainda não conta a história. Até o dia 24 o link abre o último mês
  // FECHADO (mesma tela, filtro de mês da própria Análise); do dia 25 em
  // diante, o mês corrente, já quase completo.
  function hrefDaCena(cena) {
    if (cena.href !== URL_ANALISE) { return cena.href; }
    var hoje = new Date();
    if (hoje.getDate() >= 25) { return cena.href; }
    var ano = hoje.getFullYear(), mes = hoje.getMonth();  // getMonth() é 0-11: já é o mês anterior (1-12)
    if (mes === 0) { mes = 12; ano -= 1; }
    return cena.href + "?ano=" + ano + "&mes=" + mes;
  }

  function cenaAtual() {
    var bruto = sessionStorage.getItem(CHAVE);
    var numero = bruto === null ? 0 : parseInt(bruto, 10);
    // Parse defensivo sem o identificador proibido: um valor inválido não
    // satisfaz `>= 0` e volta ao começo do roteiro.
    if (!(numero >= 0)) { numero = 0; }
    return Math.min(numero, CENAS.length - 1);
  }

  function renderizar() {
    var indice = cenaAtual(), cena = CENAS[indice];
    raiz.querySelector("[data-guia-titulo]").textContent = cena.titulo;
    raiz.querySelector("[data-guia-perfil]").textContent = cena.perfil;
    raiz.querySelector("[data-guia-acao]").textContent = cena.acao;
    raiz.querySelector("[data-guia-href]").setAttribute("href", hrefDaCena(cena));
    raiz.querySelector("[data-guia-progresso]").textContent =
      "Cena " + (indice + 1) + " de " + CENAS.length;
    var proxima = raiz.querySelector("[data-guia-proxima]");
    if (indice < CENAS.length - 1) {
      proxima.textContent = "A seguir: " + CENAS[indice + 1].titulo;
    } else {
      proxima.innerHTML =
        'A seguir: <a class="nx-guia-link" href="/demo/encerramento/">abrir a tela de Encerramento &raquo;</a>';
    }
    raiz.querySelector("[data-guia-voltar]").disabled = indice === 0;
    raiz.querySelector("[data-guia-avancar]").disabled = indice === CENAS.length - 1;
  }

  function definir(indice) { sessionStorage.setItem(CHAVE, String(indice)); renderizar(); }

  raiz.querySelector("[data-guia-avancar]").addEventListener("click", function () { definir(cenaAtual() + 1); });
  raiz.querySelector("[data-guia-voltar]").addEventListener("click", function () { definir(cenaAtual() - 1); });
  raiz.querySelector("[data-guia-reiniciar]").addEventListener("click", function () { definir(0); });
  raiz.querySelector("[data-guia-minimizar]").addEventListener("click", function () {
    raiz.classList.add("nx-guia-recolhido");
    sessionStorage.removeItem(CHAVE_ABERTO);
  });
  raiz.querySelector("[data-guia-abrir]").addEventListener("click", function () {
    raiz.classList.remove("nx-guia-recolhido");
    sessionStorage.setItem(CHAVE_ABERTO, "1");
  });

  // Recolhido por padrão (o servidor já renderiza a classe); só reabre se
  // o apresentador expandiu NESTA aba.
  if (sessionStorage.getItem(CHAVE_ABERTO) === "1") {
    raiz.classList.remove("nx-guia-recolhido");
  }
  renderizar();
})();
