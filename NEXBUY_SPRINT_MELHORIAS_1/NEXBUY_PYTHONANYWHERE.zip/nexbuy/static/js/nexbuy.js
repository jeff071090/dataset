document.addEventListener("DOMContentLoaded", function () {
  // V4: há mais de um gatilho da sidebar (topbar + botão "Menu" da barra
  // inferior mobile) — todos compartilham o mesmo estado aria-expanded.
  var toggles = Array.prototype.slice.call(document.querySelectorAll("[data-nx-sidebar-toggle]"));
  var sidebar = document.querySelector(".nx-sidebar");
  var backdrop = document.querySelector("[data-nx-sidebar-backdrop]");
  var sincronizarToggles = function (aberta) {
    toggles.forEach(function (t) { t.setAttribute("aria-expanded", aberta ? "true" : "false"); });
  };
  var fecharSidebarMobile = function () {
    if (sidebar && sidebar.classList.contains("nx-open")) {
      sidebar.classList.remove("nx-open");
      sincronizarToggles(false);
    }
  };
  if (sidebar && toggles.length) {
    sincronizarToggles(false);
    toggles.forEach(function (t) {
      t.addEventListener("click", function () {
        var aberta = sidebar.classList.toggle("nx-open");
        sincronizarToggles(aberta);
      });
    });
  }
  // Fecha a sidebar mobile ao tocar fora dela (Sprint UX 1.0, item 8).
  if (backdrop && sidebar) {
    backdrop.addEventListener("click", fecharSidebarMobile);
  }
  // Fecha a sidebar mobile com Esc, para quem navega só pelo teclado.
  document.addEventListener("keydown", function (evento) {
    if (evento.key === "Escape") { fecharSidebarMobile(); }
  });
  // V4 (Seção 9.3): ao escolher um destino no menu mobile, a sidebar fecha
  // sozinha — o usuário nunca fica com o off-canvas aberto sobre a página.
  if (sidebar) {
    sidebar.addEventListener("click", function (evento) {
      if (evento.target.closest("a.nx-nav-link, a.nx-nav-sublink")) {
        fecharSidebarMobile();
      }
    });
  }

  // V4: grupos recolhíveis da sidebar (partials/_sidebar.html). O grupo da
  // rota atual já chega aberto do servidor; aqui só alternamos os demais.
  // Com a sidebar recolhida (modo ícones), clicar num grupo primeiro
  // reexpande a sidebar — uma sub-lista não tem como aparecer em 72px.
  document.querySelectorAll("[data-nx-grupo-toggle]").forEach(function (botao) {
    botao.addEventListener("click", function () {
      if (document.body.classList.contains("nx-app-collapsed")) {
        document.body.classList.remove("nx-app-collapsed");
        localStorage.setItem("nxSidebarCollapsed", "0");
        var btnRecolher = document.querySelector("[data-nx-sidebar-collapse]");
        if (btnRecolher) { btnRecolher.setAttribute("aria-expanded", "true"); }
      }
      var grupo = botao.closest(".nx-nav-grupo");
      var aberto = grupo.classList.toggle("nx-grupo-aberto");
      botao.setAttribute("aria-expanded", aberto ? "true" : "false");
    });
  });

  var collapseBtn = document.querySelector("[data-nx-sidebar-collapse]");
  if (collapseBtn) {
    var STORAGE_KEY = "nxSidebarCollapsed";
    var jaColapsada = localStorage.getItem(STORAGE_KEY) === "1";
    if (jaColapsada) {
      document.body.classList.add("nx-app-collapsed");
    }
    collapseBtn.setAttribute("aria-expanded", jaColapsada ? "false" : "true");
    collapseBtn.addEventListener("click", function () {
      var colapsada = document.body.classList.toggle("nx-app-collapsed");
      localStorage.setItem(STORAGE_KEY, colapsada ? "1" : "0");
      collapseBtn.setAttribute("aria-expanded", colapsada ? "false" : "true");
    });
  }

  var prazoSelect = document.querySelector("#id_prazo_pagamento");
  var prazoDiasWrapper = document.querySelector("[data-nx-prazo-personalizado]");
  if (prazoSelect && prazoDiasWrapper) {
    var atualizarPrazo = function () {
      prazoDiasWrapper.style.display = prazoSelect.value === "personalizado" ? "block" : "none";
    };
    prazoSelect.addEventListener("change", atualizarPrazo);
    atualizarPrazo();
  }

  // Calendário Inteligente (Gestão de Compras): clique no dia abre o
  // painel lateral com o conteúdo já renderizado pelo servidor — sem AJAX.
  var diasCalendario = document.querySelectorAll(".gc-dia-cell");
  var offcanvasDiaEl = document.getElementById("offcanvasDia");
  if (diasCalendario.length && offcanvasDiaEl && window.bootstrap) {
    var offcanvasBody = document.getElementById("offcanvasDiaBody");
    var offcanvasTitulo = document.getElementById("offcanvasDiaLabel");
    var offcanvasInstancia = bootstrap.Offcanvas.getOrCreateInstance(offcanvasDiaEl);

    var abrirPainelDoDia = function (celula) {
      var painel = document.getElementById("painel-dia-" + celula.dataset.dia);
      if (!painel) {
        return;
      }
      offcanvasBody.innerHTML = painel.innerHTML;
      offcanvasTitulo.textContent = celula.dataset.tituloDia || "Dia";
      offcanvasInstancia.show();
    };

    diasCalendario.forEach(function (celula) {
      celula.addEventListener("click", function () {
        abrirPainelDoDia(celula);
      });
      // Ativação por teclado (Enter/Espaço) — a célula é role="button" e
      // tabindex="0" no template, mas um <div> não dispara clique com
      // essas teclas sozinho (Sprint UX 1.0, item 9 — navegação por teclado).
      celula.addEventListener("keydown", function (evento) {
        if (evento.key === "Enter" || evento.key === " " || evento.key === "Spacebar") {
          evento.preventDefault();
          abrirPainelDoDia(celula);
        }
      });
    });
  }

  // Nova Provisão: adicionar/remover linhas de item sem recarregar a página.
  var itensContainer = document.querySelector("[data-nx-itens-provisao]");
  if (itensContainer) {
    var totalFormsInput = document.querySelector("#id_itens-TOTAL_FORMS");
    var botaoAdicionar = document.querySelector("[data-nx-adicionar-item]");

    if (botaoAdicionar && totalFormsInput) {
      botaoAdicionar.addEventListener("click", function () {
        var linhas = itensContainer.querySelectorAll("[data-nx-item-linha]");
        var ultimaLinha = linhas[linhas.length - 1];
        var novoIndice = linhas.length;
        var novaLinha = ultimaLinha.cloneNode(true);

        novaLinha.querySelectorAll("input").forEach(function (campo) {
          campo.name = campo.name.replace(/itens-(\d+)-/, "itens-" + novoIndice + "-");
          campo.id = campo.id.replace(/itens-(\d+)-/, "itens-" + novoIndice + "-");
          if (campo.type === "checkbox") {
            campo.checked = false;
          } else {
            campo.value = "";
          }
        });

        itensContainer.appendChild(novaLinha);
        totalFormsInput.value = novoIndice + 1;
      });
    }

    itensContainer.addEventListener("click", function (evento) {
      var botaoRemover = evento.target.closest("[data-nx-remover-item]");
      if (!botaoRemover) {
        return;
      }
      var linha = botaoRemover.closest("[data-nx-item-linha]");
      var checkboxDelete = linha.querySelector('input[name$="-DELETE"]');
      if (checkboxDelete) {
        checkboxDelete.checked = true;
        linha.style.display = "none";
      } else {
        linha.remove();
      }
    });
  }

  // Máscara monetária brasileira ("1.234,56") nos campos marcados pelo
  // servidor com data-nx-moeda (Sprint 6, item 1 — MoedaFormMixin). Usa
  // delegação de evento em document.body (em vez de um listener por
  // input) para também funcionar nas linhas de item clonadas
  // dinamicamente pelo bloco "Nova Provisão" acima, sem precisar
  // reatribuir o listener a cada linha nova.
  document.body.addEventListener("input", function (evento) {
    var campo = evento.target.closest("[data-nx-moeda]");
    if (!campo) {
      return;
    }
    var digitos = campo.value.replace(/\D/g, "");
    if (!digitos) {
      campo.value = "";
      return;
    }
    var numero = parseInt(digitos, 10) / 100;
    campo.value = numero.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  });

  // Feedback de "processando" ao enviar um formulário: desabilita o botão e
  // mostra um spinner leve, evitando duplo envio em conexões lentas
  // (Sprint UX 1.0, item 10 — microinterações). Não interfere em nenhuma
  // regra de negócio: só afeta a aparência do botão até a página recarregar.
  // Tour guiado (Demo Experience 1.0, itens 15-16) — carrossel informativo
  // dentro de um modal já existente no template; não navega nem altera
  // nenhum dado, só explica os módulos em sequência.
  // V4: o conteúdo do tour agora é POR PERFIL (data-perfil no <body>) e
  // cada passo aponta para uma função real do próprio perfil, com o link
  // "Abrir esta função" — o tour vira orientação de navegação, não só
  // descrição de conceitos. Nenhum passo mostra função que o perfil não
  // possui; os passos de Agenda/Timeline só entram nos perfis que as têm
  // no menu padrão.
  var TOUR_STEPS_POR_PERFIL = {
    comprador: [
      { titulo: "Início — Posso comprar hoje?", icone: "bi-speedometer2", href: "/", texto: "Seu painel responde a pergunta do dia: quanto ainda dá para comprar, com a Central de Decisão traduzindo o Motor Financeiro em linguagem simples." },
      { titulo: "Nova Compra", icone: "bi-plus-circle-fill", href: "/compras/nova/", texto: "Registra uma compra JÁ realizada ou confirmada — avaliada na hora contra o seu limite do dia." },
      { titulo: "Planejamento de Compras", icone: "bi-calendar3", href: "/gestao-compras/", texto: "A Provisão planeja e reserva valor para uma compra FUTURA — acompanhe tudo no Calendário de Compras, com o semáforo de capacidade por dia." },
      { titulo: "Histórico e Simulador", icone: "bi-clock-history", href: "/compras/lista/", texto: "O Histórico lista as suas compras com cada decisão registrada; o Simulador testa uma compra sem gravar nada." },
      { titulo: "Menu e navegação", icone: "bi-list", href: null, texto: "No computador, o menu lateral agrupa suas tarefas; no celular, a barra inferior leva a Início, Nova Compra e Calendário — e o botão Menu abre o restante." }
    ],
    gerente: [
      { titulo: "Início", icone: "bi-speedometer2", href: "/", texto: "Seu painel destaca o que aguarda a sua decisão agora." },
      { titulo: "Aprovações", icone: "bi-check2-square", href: "/aprovacoes/", texto: "Fila única de compras e provisões acima do limite — Aprovar, Rejeitar ou Solicitar Ajustes, sempre com justificativa registrada." },
      { titulo: "Indicadores", icone: "bi-graph-up-arrow", href: "/indicadores/", texto: "A operação por filial e os fornecedores do mês, para decidir com contexto." },
      { titulo: "Análise Financeira e Relatórios", icone: "bi-graph-up-arrow", href: "/financeiro/analise/", texto: "DRE do mês, créditos × débitos e saúde financeira com curvas e recomendações; a Central de Relatórios reúne impressão e exportação CSV." },
      { titulo: "Menu e navegação", icone: "bi-list", href: null, texto: "No celular, a barra inferior leva a Início, Aprovações e Indicadores — e o botão Menu abre o menu completo." }
    ],
    financeiro: [
      { titulo: "Início — Centro de Controle", icone: "bi-speedometer2", href: "/", texto: "Pagamentos de hoje, próximos vencimentos e compradores — o seu dia num painel só." },
      { titulo: "Agenda e Calendário Financeiro", icone: "bi-calendar2-week", href: "/financeiro/agenda/", texto: "Parcelas a pagar com baixa e estorno justificado, e o Calendário Financeiro com as visões mensal, semanal e diária do caixa." },
      { titulo: "Análise Financeira", icone: "bi-graph-up-arrow", href: "/financeiro/analise/", texto: "DRE gerencial do mês, créditos × débitos (estilo balancete) e saúde financeira com semáforo, curvas e recomendações." },
      { titulo: "Grupo Planejamento", icone: "bi-compass", href: "/financeiro/planejamento/", texto: "Receitas, custos fixos e variáveis, contas a pagar, parcelamentos e o Calendário Operacional — todas as áreas do módulo num grupo só do menu." },
      { titulo: "Compradores e Limites", icone: "bi-people-fill", href: "/financeiro/capacidade-compradores/", texto: "Limites individuais, bloqueio e liberação de compradores — o Motor de Capacidade na prática." }
    ],
    proprietario: [
      { titulo: "Início — Dashboard Executivo", icone: "bi-speedometer2", href: "/", texto: "Receita, compras, fluxo e alertas estratégicos — e a ação mais importante do momento já em destaque." },
      { titulo: "Grupo Compras", icone: "bi-cart-check", href: "/compras/nova/", texto: "Compra registra o que JÁ aconteceu; Provisão planeja e reserva valor para compra futura. O grupo reúne as duas, com Aprovações e o Calendário de Compras." },
      { titulo: "Grupo Financeiro e Análise Financeira", icone: "bi-wallet2", href: "/financeiro/analise/", texto: "Planejamento, Agenda, Capacidade e Compradores num grupo só — e a Análise Financeira: DRE do mês, créditos × débitos e saúde financeira com curvas." },
      { titulo: "Grupo Gestão", icone: "bi-people", href: "/ncc/estrutura/", texto: "Empresas e Filiais, Usuários e Permissões e Perfis de Acesso — a estrutura da sua operação." },
      { titulo: "Relatórios e Configurações", icone: "bi-sliders", href: "/ncc/", texto: "Relatórios com impressão e CSV; em Configurações ficam o Centro de Configurações, o Checklist de Implantação, as Integrações (DDA — ainda não conectado) e a Auditoria." }
    ]
  };
  var TOUR_STEPS = TOUR_STEPS_POR_PERFIL[document.body.dataset.perfil] || TOUR_STEPS_POR_PERFIL.proprietario;
  var tourModalEl = document.getElementById("nxTourModal");
  if (tourModalEl && window.bootstrap) {
    var TOUR_STORAGE_KEY = "nxTourVisto";
    var tourIndice = 0;
    var tourInstancia = bootstrap.Modal.getOrCreateInstance(tourModalEl);
    var tourBody = document.getElementById("nxTourBody");
    var btnAnterior = tourModalEl.querySelector("[data-nx-tour-anterior]");
    var btnProximo = tourModalEl.querySelector("[data-nx-tour-proximo]");

    var renderizarPasso = function () {
      var passo = TOUR_STEPS[tourIndice];
      var linkAbrir = passo.href
        ? '<a class="btn btn-nx-outline btn-sm mt-2" href="' + passo.href + '"><i class="bi bi-box-arrow-up-right me-1" aria-hidden="true"></i>Abrir esta função</a>'
        : "";
      tourBody.innerHTML =
        '<div class="d-flex align-items-start gap-3">' +
        '<i class="bi ' + passo.icone + '" style="font-size:1.8rem;color:var(--nx-primary);" aria-hidden="true"></i>' +
        '<div><h6 class="mb-1">' + passo.titulo + '</h6><p class="nx-text-muted mb-0" style="font-size:.9rem;">' + passo.texto + "</p>" + linkAbrir + "</div>" +
        "</div>" +
        '<div class="nx-text-muted mt-3" style="font-size:.75rem;">Passo ' + (tourIndice + 1) + " de " + TOUR_STEPS.length + "</div>";
      btnAnterior.disabled = tourIndice === 0;
      btnProximo.textContent = tourIndice === TOUR_STEPS.length - 1 ? "Concluir" : "Próximo »";
    };

    var iniciarTour = function () {
      tourIndice = 0;
      renderizarPasso();
      tourInstancia.show();
    };

    var marcarTourVisto = function () {
      localStorage.setItem(TOUR_STORAGE_KEY, "1");
    };

    document.querySelectorAll("[data-nx-iniciar-tour]").forEach(function (botao) {
      botao.addEventListener("click", iniciarTour);
    });

    btnProximo.addEventListener("click", function () {
      if (tourIndice === TOUR_STEPS.length - 1) {
        marcarTourVisto();
        tourInstancia.hide();
        return;
      }
      tourIndice += 1;
      renderizarPasso();
    });

    btnAnterior.addEventListener("click", function () {
      if (tourIndice > 0) {
        tourIndice -= 1;
        renderizarPasso();
      }
    });

    tourModalEl.querySelector("[data-nx-tour-pular]").addEventListener("click", function () {
      marcarTourVisto();
      tourInstancia.hide();
    });

    tourModalEl.addEventListener("hidden.bs.modal", marcarTourVisto);

    // Abre automaticamente na primeira visita (Demo Experience 1.0, item
    // 15) — nunca mais que uma vez por navegador, e nunca sem o usuário
    // já estar autenticado (o modal só existe dentro do bloco logado do
    // template).
    if (!localStorage.getItem(TOUR_STORAGE_KEY)) {
      iniciarTour();
    }
  }

  document.body.addEventListener("submit", function (evento) {
    var formulario = evento.target;
    if (!(formulario instanceof HTMLFormElement)) {
      return;
    }
    // QA funcional Etapa 02 (Seção 16): vários formulários (Bloquear
    // comprador, Rejeitar, excluir Receita/Custo etc.) usam
    // `onsubmit="return confirm(...)"` para pedir confirmação antes de agir.
    // Esse `onsubmit` roda na fase de "target", ANTES deste listener (que
    // está em `document.body`, alcançado só na fase de bubble) — se o
    // usuário cancela o confirm(), `onsubmit` retorna `false`, o que chama
    // `preventDefault()` no evento, mas o evento CONTINUA a subir até aqui.
    // Sem checar `evento.defaultPrevented`, este código travava o botão em
    // estado de carregamento (desabilitado, spinner) mesmo quando o envio
    // foi cancelado — a submissão real nunca acontecia (sem POST, sem
    // reload), então o botão ficava preso, exigindo recarregar a página
    // para tentar de novo. Bug real encontrado no QA em navegador (ver
    // core/tests_qa_navegador.py).
    if (evento.defaultPrevented) {
      return;
    }
    var botao = formulario.querySelector('button[type="submit"]');
    if (botao && !botao.classList.contains("nx-is-loading")) {
      botao.classList.add("nx-is-loading");
      botao.setAttribute("aria-busy", "true");
      // Gate F (Prompt 2, pré-Etapa 02): desabilitar o botão AQUI (síncrono,
      // dentro do próprio handler de "submit") faz o navegador excluir o
      // name/value dele do corpo do POST — por especificação, um elemento
      // desabilitado nunca entra no FormData, mesmo tendo sido ELE quem
      // disparou o submit. Views que decidem a ação pelo nome do botão
      // (`"salvar_permissoes" in request.POST`, em `ncc_usuario_editar` e
      // outras) ficavam recebendo um POST "mudo", sem erro nenhum — a tela
      // parecia salvar (redirect normal) mas nada mudava no banco. Adiar
      // para o próximo tick (`setTimeout`) deixa o navegador terminar de
      // montar o FormData com o botão ainda habilitado, antes de travá-lo.
      setTimeout(function () {
        botao.disabled = true;
      }, 0);
    }
  });

  // Sprint de Consolidação (Gate 2A, Parte 12): painéis de decisão
  // (collapse) dentro de tabelas largas com rolagem horizontal (ex.:
  // Aprovação de Provisões). Em telas estreitas o botão que abre o painel
  // só aparece rolando a tabela para a direita — sem isto, o painel abre
  // preso nessa mesma posição de rolagem, e como o conteúdo dele começa na
  // coluna mais à esquerda, fica fora da área visível. Zera a rolagem da
  // tabela ao clicar, para o painel aparecer inteiro.
  document.body.addEventListener("click", function (evento) {
    var botao = evento.target.closest('[data-bs-toggle="collapse"]');
    if (!botao) {
      return;
    }
    var tabela = botao.closest(".table-responsive");
    if (tabela) {
      tabela.scrollLeft = 0;
    }
  });
});
