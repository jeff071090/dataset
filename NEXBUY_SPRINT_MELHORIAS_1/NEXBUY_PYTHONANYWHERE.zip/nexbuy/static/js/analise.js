// Análise Financeira — melhorias progressivas (a tela funciona sem JS).
// Não lê nem grava dado nenhum.
//
// 1) Filtros: ao trocar mês, ano ou filial, a tela recarrega sozinha (o
//    botão "Aplicar" continua lá para quem navega sem JavaScript ou só pelo
//    teclado).
// 2) Dica de toque/foco nos gráficos (crítico de UX, rodada 1): os valores
//    de cada ponto/barra ficam no <title> do SVG, que o mouse mostra mas o
//    celular não mostra ao tocar. Tocar (ou focar com Tab) num ponto abre
//    uma dica com o mesmo texto; tocar fora, Esc ou sair do foco fecha.
// 3) Créditos × Débitos: botão que mostra/esconde as colunas de detalhe da
//    tabela em telas até 1600px.
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll("form[data-an-filtros]").forEach(function (formulario) {
    formulario.querySelectorAll("select").forEach(function (campo) {
      campo.addEventListener("change", function () {
        formulario.submit();
      });
    });
  });

  var SELETOR = ".an-grafico svg g.an-ponto-grupo, .an-grafico svg g.an-barra-grupo, .an-widget svg g.an-ponto-grupo";
  var grupos = document.querySelectorAll(SELETOR);
  if (grupos.length) {
    var dica = document.createElement("div");
    dica.className = "an-dica";
    dica.setAttribute("role", "status");
    dica.setAttribute("aria-live", "polite");
    dica.hidden = true;
    document.body.appendChild(dica);
    var ativo = null;

    var esconder = function () {
      dica.hidden = true;
      if (ativo) { ativo.classList.remove("an-ativo"); }
      ativo = null;
    };
    var mostrar = function (grupo) {
      var titulo = grupo.querySelector("title");
      if (!titulo) { return; }
      if (ativo) { ativo.classList.remove("an-ativo"); }
      ativo = grupo;
      grupo.classList.add("an-ativo");
      // Rodada final: "R$" nunca fica numa linha e o número na outra (espaço
      // inseparável) e a dica nunca sai pela borda da tela — a largura real
      // (com fração de pixel) é medida depois de preencher o texto.
      dica.textContent = titulo.textContent.replace(/R\$ /g, "R$\u00a0");
      dica.hidden = false;
      var caixa = grupo.getBoundingClientRect();
      var meia = Math.ceil((dica.getBoundingClientRect().width || 200) / 2);
      var x = caixa.left + caixa.width / 2;
      x = Math.max(meia + 8, Math.min(window.innerWidth - meia - 8, x));
      dica.style.left = (x + window.scrollX) + "px";
      dica.style.top = (caixa.top + window.scrollY) + "px";
    };

    grupos.forEach(function (grupo) {
      grupo.setAttribute("tabindex", "0");
      var titulo = grupo.querySelector("title");
      if (titulo) { grupo.setAttribute("aria-label", titulo.textContent); }
      // Tocar/clicar também dá foco ao ponto (tabindex): os dois eventos
      // chegam juntos, então o clique só MOSTRA — fechar é tocar fora,
      // Esc ou sair do foco.
      grupo.addEventListener("click", function (evento) {
        evento.stopPropagation();
        mostrar(grupo);
      });
      grupo.addEventListener("focus", function () { mostrar(grupo); });
      grupo.addEventListener("blur", function () { if (ativo === grupo) { esconder(); } });
    });
    document.addEventListener("click", esconder);
    document.addEventListener("keydown", function (evento) {
      if (evento.key === "Escape") { esconder(); }
    });
    window.addEventListener("resize", esconder);
  }

  document.querySelectorAll("[data-an-alternar-detalhe]").forEach(function (botao) {
    var alvo = document.getElementById(botao.getAttribute("aria-controls"));
    var rotulo = botao.querySelector("[data-an-rotulo-detalhe]");
    if (!alvo) { return; }
    botao.addEventListener("click", function () {
      var resumida = alvo.classList.toggle("an-cd-resumida");
      botao.setAttribute("aria-expanded", resumida ? "false" : "true");
      if (rotulo) {
        rotulo.textContent = resumida ? "Mostrar colunas de detalhe" : "Ocultar colunas de detalhe";
      }
    });
  });
});
