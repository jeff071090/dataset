"""Contrato reservado para a única integração futura do NEXBUY: o DDA.

Decisão de escopo (ida para a nuvem): o NEXBUY é 100% web e NÃO se integra
a ERP. Receita mensal, receitas extras, custos fixos, custos variáveis,
compras e provisões são lançados manualmente pela interface — é assim que o
sistema funciona. Por isso os antigos contratos de ERP/Inovafarma (leitura
de SQL Server local), de conexão bancária (extrato/conciliação) e de
recomendação de compra automatizada foram REMOVIDOS deste módulo: não havia
nenhuma implementação nem nenhum uso deles no código, e mantê-los sugeriria
uma integração que não vai existir.

Fica apenas o DDA (Débito Direto Autorizado), como integração prevista e
ainda NÃO conectada. A classe abaixo é só um contrato (`abc.ABC`), sem
nenhuma implementação: quando o DDA for construído, o restante do sistema
já sabe a forma esperada de entrada/saída, sem alterar o Motor Financeiro.
"""
from abc import ABC, abstractmethod
from datetime import date
from typing import Any


class IntegracaoDDABase(ABC):
    """Contrato futuro para Débito Direto Autorizado."""

    @abstractmethod
    def listar_boletos_dda(self, empresa, data_referencia: date) -> list[Any]:
        """Deve devolver os boletos/títulos DDA pendentes na data informada.

        Fluxo correto que a futura implementação deve seguir (contrato,
        nada disto está implementado aqui):

        1. DDA fornece títulos/boletos apresentados ao CNPJ — isso não é
           pagamento realizado, é só o aviso de que existe um título.
        2. Esta integração nunca cria Custo Fixo/Variável, baixa ou
           pagamento automaticamente e cegamente a partir de um boleto DDA.
        3. Quando houver correspondência exata, inequívoca e idempotente
           entre um título DDA e uma Provisão elegível, a futura
           integração poderá efetivar essa Provisão em Compra chamando o
           service oficial já existente
           (`gestao_compras.services.efetivar_provisao`), conforme a regra
           de negócio aprovada — nunca por escrita direta em tabelas.
        4. Divergência de centavos, mais de um candidato possível, ausência
           de candidato ou dados incompletos geram uma sugestão/pendência
           para revisão humana do Financeiro — nunca uma efetivação
           automática.
        5. Toda decisão humana sobre um título DDA deve ficar registrada:
           quem confirmou, qual vínculo (Provisão) foi escolhido, o estado
           antes/depois e um correlation ID para auditoria.
        6. Reprocessar o mesmo título DDA (ex.: reimportação, reexecução
           de rotina) não pode duplicar Compra, parcela, custo ou evento —
           a implementação real precisa de idempotência por identificador
           externo estável do título.
        7. O contrato de dados devolvido por este método deve prever, no
           mínimo: identificador externo estável do título, CNPJ/nome do
           beneficiário, valor, vencimento, linha digitável (ou
           identificador equivalente do título) e status de processamento
           (e eventuais erros).
        """
        raise NotImplementedError


# "DDA Connector" (nome usado na Sprint 4) é o mesmo contrato de "DDA"
# criado na Sprint 3 — mantido como alias em vez de duplicado.
DDAConnectorBase = IntegracaoDDABase
