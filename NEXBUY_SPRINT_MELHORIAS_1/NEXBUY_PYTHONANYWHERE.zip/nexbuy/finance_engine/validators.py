"""Validações e exceções do Motor Financeiro.

Centraliza aqui as regras de validação usadas pelos serviços do
`finance_engine` — tanto para a Configuração Financeira da empresa quanto
para os dados informados em uma simulação de compra. Views e forms devem
capturar `FinanceEngineError` (ou suas subclasses) e traduzir a mensagem
para o usuário; a validação em si nunca deve ser reimplementada fora daqui.
"""
from datetime import date
from decimal import Decimal
from typing import Optional


class FinanceEngineError(Exception):
    """Erro base de qualquer regra do Motor Financeiro."""


class ConfiguracaoInvalidaError(FinanceEngineError):
    """A Configuração Financeira da empresa contém um valor inválido."""


class SimulacaoInvalidaError(FinanceEngineError):
    """Os dados informados para a simulação de compra são inválidos."""


class FilialSemEmpresaError(FinanceEngineError):
    """A filial informada não está associada a uma empresa válida."""


def validar_percentual(valor: Optional[Decimal], campo: str) -> None:
    """Garante que um percentual esteja no intervalo [0, 100]."""
    if valor is None:
        return
    if valor < 0 or valor > 100:
        raise ConfiguracaoInvalidaError(f"{campo} deve estar entre 0 e 100 (recebido: {valor}).")


def validar_inteiro_positivo(valor: Optional[int], campo: str) -> None:
    if valor is not None and valor <= 0:
        raise ConfiguracaoInvalidaError(f"{campo} deve ser maior que zero.")


def validar_decimal_nao_negativo(valor: Optional[Decimal], campo: str) -> None:
    if valor is not None and valor < 0:
        raise ConfiguracaoInvalidaError(f"{campo} não pode ser negativo.")


def validar_configuracao_financeira(config) -> None:
    """Valida os campos numéricos da Configuração Financeira de uma empresa.

    Recebe a instância de `financeiro.models.ConfiguracaoFinanceira` (ou
    qualquer objeto com os mesmos atributos) — não importamos o model aqui
    para manter os validators livres de dependência direta do Django ORM.
    """
    validar_percentual(config.percentual_compras, "Percentual destinado às compras")
    validar_percentual(config.percentual_seguranca, "Percentual de segurança")
    validar_inteiro_positivo(config.dias_uteis_manual, "Dias úteis considerados")
    validar_decimal_nao_negativo(config.limite_maximo_acumulado, "Limite máximo acumulado")


def validar_valor_positivo(valor: Optional[Decimal], campo: str) -> None:
    if valor is None or valor <= 0:
        raise SimulacaoInvalidaError(f"{campo} deve ser maior que zero.")


def validar_dados_simulacao(
    *, valor: Decimal, data_compra: Optional[date], fornecedor, categoria
) -> None:
    """Valida os dados mínimos exigidos para rodar uma simulação de compra."""
    validar_valor_positivo(valor, "Valor da compra simulada")
    if fornecedor is None:
        raise SimulacaoInvalidaError("Selecione um fornecedor para simular a compra.")
    if categoria is None:
        raise SimulacaoInvalidaError("Selecione uma categoria para simular a compra.")
    if data_compra is None:
        raise SimulacaoInvalidaError("Informe a data da compra simulada.")
