"""Calendário Operacional do Motor Financeiro (Épico 2 — CORE 1.0).

Resolve o TIPO de cada dia (útil / sábado / domingo / feriado / bloqueado /
especial) para uma empresa, combinando a regra padrão (segunda a sexta =
útil) com as exceções cadastradas em `financeiro.models.DiaOperacional`.

Sem nenhuma exceção cadastrada, `dias_uteis_operacionais` devolve
exatamente o mesmo número que `core.utils.dias_uteis_do_mes` sempre
devolveu (segunda a sexta).

Regra ÚNICA para o divisor e para o day-walk (crítico funcional, rodada
1): só os dias que contam capacidade (útil e especial) entram na divisão
da capacidade mensal E recebem limite base no day-walk — antes o divisor
excluía sábado/domingo, mas o day-walk dava limite a eles mesmo assim, e a
soma dos limites do mês passava da capacidade mensal.
"""
from calendar import monthrange
from datetime import date
from typing import Optional

from financeiro.models import DiaOperacional

# Dias que entram na divisão da capacidade mensal (denominador do limite
# diário) e que recebem limite no day-walk. "Especial" existe exatamente
# para promover um dia que por padrão não contaria (ex.: sábado de
# mutirão de compras) a dia com capacidade.
TIPOS_QUE_CONTAM_CAPACIDADE = (DiaOperacional.Tipo.UTIL, DiaOperacional.Tipo.ESPECIAL)


def sabado_e_dia_de_compra(empresa) -> bool:
    """Opção da empresa (Sprint de Melhorias 1): sábado conta como dia útil."""
    return bool(getattr(empresa, "sabado_dia_de_compra", False))


def tipo_padrao_do_dia(data_referencia: date, sabado_util: bool = False) -> str:
    """Regra padrão, sem consultar o banco: seg-sex útil, sáb/dom próprios.
    Com `sabado_util` (opção "Sábado é dia de compra" da empresa), sábado
    também é útil."""
    dia_semana = data_referencia.weekday()  # 0=segunda ... 6=domingo
    if dia_semana < 5:
        return DiaOperacional.Tipo.UTIL
    if dia_semana == 5:
        return DiaOperacional.Tipo.UTIL if sabado_util else DiaOperacional.Tipo.SABADO
    return DiaOperacional.Tipo.DOMINGO


def excecoes_do_mes(empresa, ano: int, mes: int) -> dict:
    """{dia_do_mes: tipo} apenas das exceções cadastradas — 1 consulta."""
    if empresa is None:
        return {}
    registros = DiaOperacional.objects.filter(
        empresa=empresa, data__year=ano, data__month=mes
    ).values_list("data", "tipo")
    return {data_registro.day: tipo for data_registro, tipo in registros}


def tipo_do_dia(empresa, data_referencia: date, excecoes: Optional[dict] = None) -> str:
    """Tipo resolvido de um dia: exceção cadastrada, senão a regra padrão.

    `excecoes` (de `excecoes_do_mes`) evita uma consulta por dia quando o
    chamador já percorre o mês inteiro.
    """
    if excecoes is not None:
        tipo = excecoes.get(data_referencia.day)
        if tipo:
            return tipo
        return tipo_padrao_do_dia(data_referencia, sabado_e_dia_de_compra(empresa))
    registro = (
        DiaOperacional.objects.filter(empresa=empresa, data=data_referencia).values_list("tipo", flat=True).first()
        if empresa is not None
        else None
    )
    return registro or tipo_padrao_do_dia(data_referencia, sabado_e_dia_de_compra(empresa))


def dia_conta_capacidade(tipo: str) -> bool:
    return tipo in TIPOS_QUE_CONTAM_CAPACIDADE


def rotulo_do_tipo(tipo: str) -> str:
    """ "sábado", "domingo", "feriado"... — minúsculo, para compor frases."""
    return str(dict(DiaOperacional.Tipo.choices).get(tipo, tipo)).lower()


def dias_uteis_operacionais(empresa, ano: int, mes: int, excecoes: Optional[dict] = None) -> int:
    """Quantos dias do mês contam capacidade, já considerando exceções.

    Sem exceções cadastradas o resultado é idêntico à contagem simples de
    segunda a sexta (`core.utils.dias_uteis_do_mes`).
    """
    if excecoes is None:
        excecoes = excecoes_do_mes(empresa, ano, mes)
    total_dias = monthrange(ano, mes)[1]
    sabado_util = sabado_e_dia_de_compra(empresa)
    contagem = 0
    for dia_num in range(1, total_dias + 1):
        tipo = excecoes.get(dia_num) or tipo_padrao_do_dia(date(ano, mes, dia_num), sabado_util)
        if dia_conta_capacidade(tipo):
            contagem += 1
    return contagem


def mapa_tipos_do_mes(empresa, ano: int, mes: int) -> dict:
    """{dia_do_mes: tipo_resolvido} para o mês inteiro — 1 consulta."""
    excecoes = excecoes_do_mes(empresa, ano, mes)
    total_dias = monthrange(ano, mes)[1]
    sabado_util = sabado_e_dia_de_compra(empresa)
    return {
        dia_num: (excecoes.get(dia_num) or tipo_padrao_do_dia(date(ano, mes, dia_num), sabado_util))
        for dia_num in range(1, total_dias + 1)
    }
