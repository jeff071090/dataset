"""Alertas do Motor Financeiro (Épico 1 — CORE 1.0).

Gera, a partir dos números que o motor já calcula (nunca recalculando
regra), a lista de alertas operacionais de uma filial: capacidade
excedida, dias críticos próximos, contas vencendo, parcelas vencidas e
solicitações paradas além do prazo da etapa. Reutilizável por qualquer
consumidor — Dashboards, Central de Notificações, futuras integrações.
"""
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Optional

from django.template.defaultfilters import pluralize
from django.utils import timezone

from core.utils import formatar_moeda
from gestao_compras.models import SolicitacaoAprovacao

from .agenda import parcelas_vencidas, proximos_vencimentos
from .calculations import ZERO
from .services import motor_financeiro, receita_configurada

NIVEL_ATENCAO = "atencao"
NIVEL_CRITICO = "critico"


@dataclass(frozen=True)
class Alerta:
    nivel: str  # "atencao" | "critico"
    titulo: str
    mensagem: str
    data: Optional[date] = None


def gerar_alertas(filial, data_referencia: Optional[date] = None, dias_janela: int = 7) -> list[Alerta]:
    """Alertas da filial no dia — cada regra é independente e barata."""
    hoje = data_referencia or date.today()
    alertas: list[Alerta] = []

    # 1) Capacidade do dia (e dias críticos futuros) — reaproveita o
    # day-walk do mês, uma única vez.
    #
    # Sprint de Melhorias 1: sem receita lançada no mês não existe limite —
    # antes TODO dia útil virava "Dia crítico à frente (R$ 0,00
    # comprometidos)" logo no dia 1, antes do lançamento. Agora sai um único
    # alerta dizendo o que falta, e os de capacidade esperam a receita.
    if not receita_configurada(filial, hoje.year, hoje.month):
        alertas.append(
            Alerta(
                NIVEL_ATENCAO, "Receita do mês não lançada",
                f"Lance a receita esperada de {hoje:%m/%Y} da filial {filial.nome} em Financeiro → Receitas: "
                "é ela que libera o limite de compra do dia.",
                hoje,
            )
        )
        posicoes = []
    else:
        posicoes = motor_financeiro.calcular_posicoes_do_mes(filial, hoje.year, hoje.month)
    posicao_hoje = next((p for p in posicoes if p.data == hoje), None)
    if posicao_hoje is not None and posicao_hoje.saldo_do_dia < ZERO:
        alertas.append(
            Alerta(
                NIVEL_CRITICO, "Capacidade de hoje excedida",
                f"O limite de hoje foi ultrapassado em "
                f"{formatar_moeda(abs(posicao_hoje.saldo_do_dia), incluir_prefixo=True)}.",
                hoje,
            )
        )
    dias_criticos = [p for p in posicoes if hoje < p.data <= hoje + timedelta(days=dias_janela) and p.cor == "vermelho"]
    for posicao in dias_criticos[:3]:
        alertas.append(
            Alerta(
                NIVEL_ATENCAO, "Dia crítico à frente",
                f"{posicao.data:%d/%m} já está com o limite comprometido "
                f"({formatar_moeda(posicao.comprado, incluir_prefixo=True)} comprometidos).",
                posicao.data,
            )
        )

    # 2) Parcelas vencidas e não pagas.
    vencidas = parcelas_vencidas(filial, hoje)
    if vencidas:
        total = sum((item.valor for item in vencidas), ZERO)
        qtd = len(vencidas)
        alertas.append(
            Alerta(
                NIVEL_CRITICO, "Parcelas vencidas",
                f"{qtd} parcela{pluralize(qtd)} vencida{pluralize(qtd)} sem baixa, somando "
                f"{formatar_moeda(total, incluir_prefixo=True)}.",
            )
        )

    # 3) Contas/compromissos vencendo em breve (amanhã e depois).
    proximos = proximos_vencimentos(filial, hoje, dias_janela=2, limite=20)
    vencendo = [item for item in proximos if item.pendente]
    if vencendo:
        total = sum((item.valor for item in vencendo), ZERO)
        qtd = len(vencendo)
        alertas.append(
            Alerta(
                NIVEL_ATENCAO, "Compromissos vencendo",
                f"{qtd} compromisso{pluralize(qtd)} nos próximos 2 dias, somando "
                f"{formatar_moeda(total, incluir_prefixo=True)}.",
            )
        )

    # 4) Solicitações de aprovação além do prazo da etapa (Épico 8).
    agora = timezone.now()
    solicitacoes = (
        SolicitacaoAprovacao.objects.filter(
            status=SolicitacaoAprovacao.Status.PENDENTE, provisao__filial=filial, etapa_atual__prazo_dias__isnull=False
        )
        .select_related("etapa_atual", "provisao", "provisao__fornecedor")
    )
    for solicitacao in solicitacoes:
        prazo = solicitacao.etapa_atual.prazo_dias
        if prazo and (agora - solicitacao.atualizado_em).days > prazo:
            alertas.append(
                Alerta(
                    NIVEL_ATENCAO, "Aprovação além do prazo",
                    f"{solicitacao.provisao.fornecedor.nome} aguarda a etapa "
                    f"{solicitacao.etapa_atual.ordem} há mais de {prazo} dia{pluralize(prazo)}.",
                )
            )

    ordem_nivel = {NIVEL_CRITICO: 0, NIVEL_ATENCAO: 1}
    alertas.sort(key=lambda alerta: ordem_nivel.get(alerta.nivel, 9))
    return alertas
