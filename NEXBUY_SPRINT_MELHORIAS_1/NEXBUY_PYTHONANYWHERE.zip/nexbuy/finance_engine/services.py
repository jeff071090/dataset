"""Serviços do Motor Financeiro NEXBUY.

Este módulo é o "motor único" citado na Sprint 3: toda regra de cálculo
financeiro do sistema — capacidade mensal, limite diário, saldo acumulado e
redistribuição de excedente — deve passar por aqui. Views e outros apps
(`financeiro`, `compras`, `dashboard`) consultam estes serviços e nunca
reimplementam a matemática por conta própria.

Serviços expostos:

- `CapacidadeCompraService` — disponibilidade, capacidade mensal e limite
  diário base de uma filial em um mês (item 1 e 2 da Sprint 3). A receita
  do mês é a receita mensal (`Receita.faturamento`) + as receitas extras
  (`ReceitaExtra`) com data naquele mês, ambas lançadas manualmente.
- `SaldoAcumuladoService` — transferência do saldo positivo (sobra) de um
  dia para os seguintes (item 3).
- `RedistribuicaoService` — repasse do excedente de um dia que ultrapassou
  o limite para os dias seguintes (item 4).
- `MotorFinanceiro` — fachada que orquestra os três acima e percorre os
  dias do mês (o "day-walk") produzindo a posição financeira diária usada
  pelo dashboard, pela simulação e pela timeline.

Os três serviços de apoio são propositalmente independentes: cada um recebe
apenas o saldo do dia e a configuração da empresa, sem conhecer o restante
do fluxo — podem ser testados e reaproveitados isoladamente.
"""
import calendar
from datetime import date
from decimal import Decimal
from typing import Optional

from django.db.models import Count, Sum

from compras.models import Compra
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, CustoVariavel, Receita, ReceitaExtra

from .calculations import (
    ZERO,
    PosicaoDiaria,
    ReceitaDoMes,
    ResultadoCapacidade,
    aplicar_margem_seguranca,
    calcular_capacidade_mensal,
    calcular_disponibilidade,
    calcular_limite_diario,
    calcular_percentual_utilizado,
    classificar_consumo,
)
from .calendario_operacional import (
    dia_conta_capacidade,
    dias_uteis_operacionais,
    excecoes_do_mes,
    sabado_e_dia_de_compra,
    tipo_padrao_do_dia,
)

# Status de compra que contam para o total comprado no dia/mês. Definido aqui
# como fonte única — `compras.services` importa esta constante em vez de
# duplicá-la (evita divergência entre os dois módulos).
STATUS_CONSIDERADOS_NO_LIMITE = (Compra.Status.APROVADA, Compra.Status.PENDENTE)


def obter_configuracao(empresa) -> Optional[ConfiguracaoFinanceira]:
    """Configuração financeira da empresa, ou None se ainda não configurada."""
    return getattr(empresa, "configuracao_financeira", None)


def obter_receita_do_mes(filial, ano: int, mes: int) -> ReceitaDoMes:
    """Receita da filial no mês, decomposta (2 consultas): receita mensal
    (faturamento de `Receita`, no máximo 1 por filial/mês) + soma das
    `ReceitaExtra` com data no mês. Fonte ÚNICA da receita do Motor — a
    capacidade, os dashboards e a tela de Receitas leem daqui."""
    receita = Receita.objects.filter(filial=filial, mes__year=ano, mes__month=mes).only("faturamento").first()
    extras = ReceitaExtra.objects.filter(filial=filial, data__year=ano, data__month=mes).aggregate(
        total=Sum("valor"), quantidade=Count("id")
    )
    return ReceitaDoMes(
        receita_mensal=receita.faturamento if receita is not None else ZERO,
        receitas_extras=extras["total"] or ZERO,
        tem_receita_mensal=receita is not None,
        quantidade_extras=extras["quantidade"] or 0,
    )


def receita_configurada(filial, ano: int, mes: int) -> bool:
    """True quando a filial tem QUALQUER receita no mês — receita mensal
    (faturamento) OU pelo menos uma receita extra. É o sinal que as telas
    usam para diferenciar "ainda não há dado" de "capacidade calculada e
    deu zero/negativa"."""
    if Receita.objects.filter(filial=filial, mes__year=ano, mes__month=mes).exists():
        return True
    return ReceitaExtra.objects.filter(filial=filial, data__year=ano, data__month=mes).exists()


class CapacidadeCompraService:
    """Calcula a capacidade financeira mensal e o limite diário base de uma
    filial (Sprint 3, itens 1 e 2)."""

    def calcular(self, filial, ano: int, mes: int) -> ResultadoCapacidade:
        # Receita do mês = receita mensal (faturamento cadastrado em
        # `Receita`) + receitas extras lançadas no mês (`ReceitaExtra`). O
        # campo `faturamento` do resultado continua sendo o TOTAL — é o que
        # todos os consumidores (dashboards, calendário, compras) já leem.
        receita_do_mes = obter_receita_do_mes(filial, ano, mes)
        faturamento = receita_do_mes.total
        custos_fixos = self._custos_fixos_ativos(filial)
        custos_variaveis = self._custos_variaveis_do_mes(filial, ano, mes)

        config = obter_configuracao(filial.empresa)
        percentual_compra = config.percentual_compras if config else Decimal("30")
        percentual_seguranca = config.percentual_seguranca if config else ZERO

        disponibilidade = calcular_disponibilidade(faturamento, custos_fixos, custos_variaveis)
        capacidade_mensal = calcular_capacidade_mensal(disponibilidade, percentual_compra)
        capacidade_ajustada = aplicar_margem_seguranca(capacidade_mensal, percentual_seguranca)

        # Épico 2 (CORE 1.0): o denominador do limite diário passa a vir do
        # Calendário Operacional. Precedência preservada: `dias_uteis_manual`
        # continua mandando quando preenchido; sem exceções cadastradas,
        # `dias_uteis_operacionais` devolve exatamente a contagem seg-sex de
        # sempre (`core.utils.dias_uteis_do_mes`) — zero mudança de número.
        #
        # Revisão adversarial (Fechamento Final, Seção 8): checar por `is
        # not None`, nunca pela truthiness do valor — `dias_uteis_manual=0`
        # é uma configuração explícita válida (zero dias úteis manuais) e
        # tinha, por causa do `or`, o mesmo efeito de "não preenchido",
        # caindo no fallback automático em vez de resultar em limite diário
        # ZERO (o mesmo tratamento de borda que `calcular_limite_diario` já
        # dá quando `dias_uteis` chega 0 por qualquer outro caminho).
        dias_uteis = (
            config.dias_uteis_manual
            if config is not None and config.dias_uteis_manual is not None
            else dias_uteis_operacionais(filial.empresa, ano, mes)
        )
        limite_diario_base = calcular_limite_diario(capacidade_ajustada, dias_uteis)

        return ResultadoCapacidade(
            filial_id=filial.id,
            ano=ano,
            mes=mes,
            faturamento=faturamento,
            custos_fixos=custos_fixos,
            custos_variaveis=custos_variaveis,
            disponibilidade=disponibilidade,
            percentual_compra=percentual_compra,
            percentual_seguranca=percentual_seguranca,
            capacidade_mensal=capacidade_mensal,
            capacidade_mensal_ajustada=capacidade_ajustada,
            dias_uteis=dias_uteis,
            limite_diario_base=limite_diario_base,
            receita_mensal=receita_do_mes.receita_mensal,
            receitas_extras=receita_do_mes.receitas_extras,
            receita_configurada=receita_do_mes.configurada,
        )

    @staticmethod
    def _faturamento_do_mes(filial, ano: int, mes: int) -> Decimal:
        """Receita TOTAL do mês (mensal + extras). Mantido com o nome
        histórico para qualquer chamador antigo."""
        return obter_receita_do_mes(filial, ano, mes).total

    @staticmethod
    def _custos_fixos_ativos(filial) -> Decimal:
        return CustoFixo.objects.filter(filial=filial, ativo=True).aggregate(total=Sum("valor"))["total"] or ZERO

    @staticmethod
    def _custos_variaveis_do_mes(filial, ano: int, mes: int) -> Decimal:
        return (
            CustoVariavel.objects.filter(filial=filial, data_prevista__year=ano, data_prevista__month=mes)
            .aggregate(total=Sum("valor"))["total"]
            or ZERO
        )


class SaldoAcumuladoService:
    """Transfere o saldo positivo (sobra) de um dia sem compras — ou com
    compra abaixo do limite — para os dias seguintes do mês (Sprint 3, item
    3). Só atua quando a empresa tiver 'Permitir saldo acumulativo'
    habilitado; caso contrário, devolve sempre zero (comportamento das
    Sprints anteriores, preservado por padrão)."""

    def transferir(self, saldo_do_dia: Decimal, config: Optional[ConfiguracaoFinanceira]) -> Decimal:
        habilitado = bool(config and config.permitir_saldo_acumulativo)
        if not habilitado or saldo_do_dia <= ZERO:
            return ZERO
        return saldo_do_dia


class RedistribuicaoService:
    """Repassa o excedente de um dia que ultrapassou o limite para os dias
    seguintes, reduzindo automaticamente a capacidade deles (Sprint 3, item
    4). Só atua quando a empresa tiver 'Redistribuição automática'
    habilitada — desligada por padrão, sem impacto nas Sprints anteriores."""

    def redistribuir(self, saldo_do_dia: Decimal, config: Optional[ConfiguracaoFinanceira]) -> Decimal:
        habilitado = bool(config and config.redistribuicao_automatica)
        if not habilitado or saldo_do_dia >= ZERO:
            return ZERO
        return saldo_do_dia


class MotorFinanceiro:
    """Fachada única do Motor Financeiro NEXBUY.

    Toda regra de cálculo financeiro do sistema deve passar por aqui — é o
    único ponto que percorre os dias do mês (o "day-walk") combinando
    capacidade, saldo acumulado e redistribuição.
    """

    def __init__(self):
        self.capacidade_service = CapacidadeCompraService()
        self.saldo_service = SaldoAcumuladoService()
        self.redistribuicao_service = RedistribuicaoService()

    def capacidade_do_mes(self, filial, ano: int, mes: int) -> ResultadoCapacidade:
        return self.capacidade_service.calcular(filial, ano, mes)

    def calcular_posicoes_do_mes(
        self,
        filial,
        ano: int,
        mes: int,
        *,
        ate_dia: Optional[int] = None,
        compras_extras: Optional[dict] = None,
    ) -> list[PosicaoDiaria]:
        """Percorre os dias 1..ate_dia (ou o mês inteiro) somando o carry-in
        de saldo acumulado/redistribuição e devolve a posição financeira de
        cada dia.

        `compras_extras` (dict {dia: Decimal}) permite injetar compras
        hipotéticas sem gravar nada no banco — usado pelo
        `SimuladorCompraService` para responder "e se eu comprasse X no dia
        Y?" sem alterar o histórico real.
        """
        capacidade = self.capacidade_service.calcular(filial, ano, mes)
        config = obter_configuracao(filial.empresa)

        ultimo_dia_mes = calendar.monthrange(ano, mes)[1]
        ate_dia = min(ate_dia or ultimo_dia_mes, ultimo_dia_mes)

        mapa_comprado = self._mapa_comprado_no_mes(filial, ano, mes)
        if compras_extras:
            mapa_comprado = dict(mapa_comprado)
            for dia, valor in compras_extras.items():
                mapa_comprado[dia] = mapa_comprado.get(dia, ZERO) + valor

        limite_maximo_acumulado = config.limite_maximo_acumulado if config else None

        # Épico 2 (CORE 1.0): exceções do Calendário Operacional do mês (1
        # consulta).
        #
        # Crítico funcional (rodada 1): o limite diário base é a capacidade
        # mensal ajustada dividida SÓ pelos dias que contam capacidade (útil
        # e especial — `dias_uteis_operacionais`), mas o day-walk dava o
        # limite base cheio também a sábados e domingos sem exceção
        # cadastrada. A soma dos limites liberados no mês passava da
        # capacidade mensal (30 x 1.284,55 = 38.536,50 contra 28.260, +36%)
        # e o calendário mostrava "Sábado — Capacidade R$ 1.284,55" enquanto
        # o Gerente via "22 dias úteis no mês". Agora o day-walk segue a
        # MESMA regra do divisor: só dia que conta capacidade recebe limite
        # base; sábado/domingo (regra padrão), feriado e bloqueio ficam só
        # com o saldo transferido (se houver saldo acumulativo). Para comprar
        # num sábado, marque-o como "Especial" no Calendário Operacional — o
        # dia passa a receber limite E a entrar no divisor, e a soma do mês
        # continua fechando com a capacidade mensal ajustada.
        excecoes = excecoes_do_mes(filial.empresa, ano, mes)
        sabado_util = sabado_e_dia_de_compra(filial.empresa)

        posicoes: list[PosicaoDiaria] = []
        carry_in = ZERO
        for dia_num in range(1, ate_dia + 1):
            data_dia = date(ano, mes, dia_num)
            tipo_dia = excecoes.get(dia_num) or tipo_padrao_do_dia(data_dia, sabado_util)
            comprado = mapa_comprado.get(dia_num, ZERO)

            # Dia que não conta capacidade (fim de semana pela regra padrão,
            # feriado, bloqueio) não tem limite próprio — o limite do dia é
            # só o saldo transferido (se houver saldo acumulativo ligado).
            limite_base_dia = capacidade.limite_diario_base if dia_conta_capacidade(tipo_dia) else ZERO

            limite_efetivo = limite_base_dia + carry_in
            saldo_do_dia = limite_efetivo - comprado

            carry_out = self.saldo_service.transferir(saldo_do_dia, config) + self.redistribuicao_service.redistribuir(
                saldo_do_dia, config
            )
            if limite_maximo_acumulado is not None and carry_out > limite_maximo_acumulado:
                carry_out = limite_maximo_acumulado

            posicoes.append(
                PosicaoDiaria(
                    data=data_dia,
                    limite_base=limite_base_dia,
                    saldo_transferido=carry_in,
                    limite_efetivo=limite_efetivo,
                    comprado=comprado,
                    saldo_do_dia=saldo_do_dia,
                    carry_out=carry_out,
                    cor=classificar_consumo(comprado, limite_efetivo),
                    tipo_dia=tipo_dia,
                )
            )
            carry_in = carry_out

        return posicoes

    def posicao_do_dia(
        self, filial, data_referencia: date, *, compras_extras: Optional[dict] = None
    ) -> PosicaoDiaria:
        """Posição financeira de um único dia (o mais usado pelas telas)."""
        posicoes = self.calcular_posicoes_do_mes(
            filial,
            data_referencia.year,
            data_referencia.month,
            ate_dia=data_referencia.day,
            compras_extras=compras_extras,
        )
        return posicoes[-1]

    def resumo_dashboard(self, filial, data_referencia: Optional[date] = None) -> dict:
        """Indicadores prontos para o Dashboard do Comprador (Sprint 3, item
        7): capacidade disponível hoje, saldo acumulado, dias comprometidos,
        limite restante e percentual utilizado."""
        data_referencia = data_referencia or date.today()
        posicoes = self.calcular_posicoes_do_mes(
            filial, data_referencia.year, data_referencia.month, ate_dia=data_referencia.day
        )
        posicao_hoje = posicoes[-1]
        dias_comprometidos = sum(1 for posicao in posicoes if posicao.comprado > ZERO)

        return {
            "posicao_hoje": posicao_hoje,
            "capacidade_disponivel_hoje": posicao_hoje.limite_efetivo,
            "saldo_acumulado": posicao_hoje.saldo_transferido,
            "dias_comprometidos": dias_comprometidos,
            "limite_restante": posicao_hoje.saldo_do_dia,
            "percentual_utilizado": calcular_percentual_utilizado(
                posicao_hoje.comprado, posicao_hoje.limite_efetivo
            ),
        }

    @staticmethod
    def _mapa_comprado_no_mes(filial, ano: int, mes: int) -> dict:
        """{dia_do_mes: total_comprado} em uma única consulta agregada."""
        registros = (
            Compra.objects.filter(
                filial=filial,
                data_compra__year=ano,
                data_compra__month=mes,
                status__in=STATUS_CONSIDERADOS_NO_LIMITE,
            )
            .values("data_compra")
            .annotate(total=Sum("valor"))
        )
        return {registro["data_compra"].day: registro["total"] for registro in registros}


# Instância padrão, pronta para uso — evita que cada chamador precise
# instanciar o motor manualmente (ele não guarda estado entre chamadas).
motor_financeiro = MotorFinanceiro()
