"""Simulador de compra do Motor Financeiro (Sprint 3, item 5).

`SimuladorCompraService` responde "o que aconteceria se eu lançasse esta
compra?" sem persistir nada no banco — reaproveita o mesmo day-walk do
`MotorFinanceiro` (`calcular_posicoes_do_mes`), apenas injetando a compra
hipotética como uma "compra extra" naquele dia. Isso garante que a
simulação enxergue exatamente as mesmas regras (capacidade, saldo
acumulado, redistribuição) que uma compra real usaria — sem duplicar
lógica.
"""
from datetime import date
from decimal import Decimal
from typing import Optional

from django.template.defaultfilters import pluralize

from core.utils import formatar_moeda

from .calculations import ZERO, ResultadoSimulacao
from .services import MotorFinanceiro, motor_financeiro
from .validators import validar_dados_simulacao


class SimuladorCompraService:
    """Simula o impacto de uma compra hipotética no saldo financeiro da
    filial, sem gravar nada no banco de dados."""

    def __init__(self, motor: Optional[MotorFinanceiro] = None):
        self.motor = motor or motor_financeiro

    def simular(
        self,
        *,
        filial,
        fornecedor,
        valor: Decimal,
        data_compra: date,
        categoria,
    ) -> ResultadoSimulacao:
        """Executa a simulação. Levanta `SimulacaoInvalidaError` (ver
        `validators.py`) se os dados informados forem inválidos."""
        validar_dados_simulacao(valor=valor, data_compra=data_compra, fornecedor=fornecedor, categoria=categoria)

        compras_extras = {data_compra.day: valor}

        posicao_antes = self.motor.posicao_do_dia(filial, data_compra)
        posicao_depois = self.motor.posicao_do_dia(filial, data_compra, compras_extras=compras_extras)

        excedeu = posicao_depois.saldo_do_dia < ZERO
        dias_afetados = self._dias_afetados(filial, data_compra, compras_extras)

        alerta = None
        if excedeu:
            alerta = (
                f"Esta compra ultrapassaria o limite do dia em "
                f"{formatar_moeda(abs(posicao_depois.saldo_do_dia), incluir_prefixo=True)}."
            )
        elif dias_afetados and len(dias_afetados) > 1:
            qtd = len(dias_afetados) - 1
            alerta = f"Esta compra também altera o saldo de mais {qtd} dia{pluralize(qtd)} seguinte{pluralize(qtd)}."

        return ResultadoSimulacao(
            fornecedor_nome=str(fornecedor),
            categoria_nome=str(categoria),
            valor=valor,
            data_compra=data_compra,
            saldo_antes=posicao_antes.saldo_do_dia,
            saldo_depois=posicao_depois.saldo_do_dia,
            novo_limite=posicao_depois.limite_efetivo,
            excedeu_limite=excedeu,
            dias_afetados=dias_afetados,
            alerta=alerta,
        )

    def _dias_afetados(self, filial, data_compra: date, compras_extras: dict) -> list[date]:
        """Compara a posição diária do restante do mês com e sem a compra
        simulada; devolve os dias cujo saldo ou limite efetivo mudam. Só é
        maior que `[data_compra]` quando saldo acumulado e/ou redistribuição
        automática estão habilitados na Configuração Financeira."""
        ano, mes = data_compra.year, data_compra.month
        posicoes_sem = self.motor.calcular_posicoes_do_mes(filial, ano, mes)
        posicoes_com = self.motor.calcular_posicoes_do_mes(filial, ano, mes, compras_extras=compras_extras)

        afetados = []
        for posicao_sem, posicao_com in zip(posicoes_sem, posicoes_com):
            if posicao_sem.data < data_compra:
                continue
            mudou = (
                posicao_sem.saldo_do_dia != posicao_com.saldo_do_dia
                or posicao_sem.limite_efetivo != posicao_com.limite_efetivo
            )
            if mudou:
                afetados.append(posicao_sem.data)
        return afetados


simulador_compra = SimuladorCompraService()
