"""Motor Financeiro × Receitas Extras (mudança de escopo — lançamento
manual): a receita do mês é receita mensal + receitas extras do mês, em
Decimal exato, e toda a cadeia (capacidade → limite diário → day-walk →
timeline → simulação) enxerga o mesmo total.

Rode com: python manage.py test finance_engine.tests_receitas_extras
"""
from datetime import date
from decimal import Decimal

from django.test import TestCase

from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, Receita, ReceitaExtra

from .calculations import ReceitaDoMes
from .services import CapacidadeCompraService, motor_financeiro, obter_receita_do_mes, receita_configurada
from .timeline import historico_financeiro


class ReceitaDoMesTestCase(TestCase):
    def test_total_e_configurada_do_dataclass(self):
        vazio = ReceitaDoMes()
        self.assertEqual(vazio.total, Decimal("0"))
        self.assertFalse(vazio.configurada)
        so_extras = ReceitaDoMes(receitas_extras=Decimal("10.10"), quantidade_extras=1)
        self.assertTrue(so_extras.configurada)
        self.assertEqual(so_extras.total, Decimal("10.10"))
        mensal_zero = ReceitaDoMes(receita_mensal=Decimal("0"), tem_receita_mensal=True)
        self.assertTrue(mensal_zero.configurada)  # faturamento 0 cadastrado de propósito conta


class MotorReceitasExtrasTestCase(TestCase):
    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Engine Extra", cnpj="86.000.000/0001-86")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz Engine Extra")
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("25"), percentual_seguranca=Decimal("10"),
            dias_uteis_manual=25,
        )
        Receita.objects.create(filial=self.filial, mes=date(2026, 6, 1), faturamento=Decimal("80000.00"))
        CustoFixo.objects.create(filial=self.filial, descricao="Folha", valor=Decimal("30000.00"), dia_vencimento=5)

    def test_decomposicao_exata_em_decimal(self):
        ReceitaExtra.objects.create(filial=self.filial, data=date(2026, 6, 1), descricao="A", valor=Decimal("0.01"))
        ReceitaExtra.objects.create(filial=self.filial, data=date(2026, 6, 30), descricao="B", valor=Decimal("1999.99"))
        receita = obter_receita_do_mes(self.filial, 2026, 6)
        self.assertEqual(receita.receita_mensal, Decimal("80000.00"))
        self.assertEqual(receita.receitas_extras, Decimal("2000.00"))
        self.assertEqual(receita.total, Decimal("82000.00"))
        self.assertEqual(receita.quantidade_extras, 2)
        self.assertIsInstance(receita.receitas_extras, Decimal)

        resultado = CapacidadeCompraService().calcular(self.filial, 2026, 6)
        # (82000 - 30000) = 52000 → × 25% = 13000 → × (1 - 10%) = 11700 → ÷ 25 = 468
        self.assertEqual(resultado.disponibilidade, Decimal("52000.00"))
        self.assertEqual(resultado.capacidade_mensal, Decimal("13000"))
        self.assertEqual(resultado.capacidade_mensal_ajustada, Decimal("11700"))
        self.assertEqual(resultado.limite_diario_base, Decimal("468"))
        self.assertEqual(CapacidadeCompraService._faturamento_do_mes(self.filial, 2026, 6), Decimal("82000.00"))

    def test_timeline_usa_o_limite_com_as_extras(self):
        ReceitaExtra.objects.create(filial=self.filial, data=date(2026, 6, 10), descricao="C", valor=Decimal("2000.00"))
        eventos = historico_financeiro.gerar_timeline(self.filial, 2026, 6)
        self.assertEqual(eventos[0].limite_base, Decimal("468"))
        posicao = motor_financeiro.posicao_do_dia(self.filial, date(2026, 6, 15))
        self.assertEqual(posicao.limite_base, Decimal("468"))

    def test_receita_configurada_so_com_extras(self):
        outra = Filial.objects.create(empresa=self.empresa, nome="Filial sem receita mensal")
        self.assertFalse(receita_configurada(outra, 2026, 6))
        ReceitaExtra.objects.create(filial=outra, data=date(2026, 6, 20), descricao="PBM", valor=Decimal("50.00"))
        self.assertTrue(receita_configurada(outra, 2026, 6))
        self.assertFalse(receita_configurada(outra, 2026, 7))
        self.assertTrue(motor_financeiro.capacidade_do_mes(outra, 2026, 6).receita_configurada)
