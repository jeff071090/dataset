"""Timeline Financeira do Motor Financeiro (Sprint 3, item 6).

`HistoricoFinanceiroService` monta o histórico cronológico dia a dia de uma
filial em um mês — compra(s) do dia, saldo, transferência recebida (Saldo
Acumulado), redistribuição recebida (excedente de dias anteriores) e o novo
saldo gerado para o dia seguinte. Reaproveita o mesmo day-walk do
`MotorFinanceiro`, sem duplicar a lógica de cálculo.

Cada linha do dia-a-dia (`PosicaoDiaria.saldo_transferido`) já é o resultado
combinado de `SaldoAcumuladoService` (sempre ≥ 0) e `RedistribuicaoService`
(sempre ≤ 0) — como os dois nunca atuam no mesmo dia (um só liga quando o
saldo do dia anterior é positivo, o outro só quando é negativo), o sinal do
valor já indica de qual dos dois ele veio; por isso a timeline consegue
separar "Transferência" de "Redistribuição" sem recalcular nada.
"""
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Optional

from compras.models import Compra

from .calculations import ZERO
from .services import STATUS_CONSIDERADOS_NO_LIMITE, MotorFinanceiro, motor_financeiro


@dataclass(frozen=True)
class EventoTimeline:
    """Um dia da timeline financeira, pronto para exibição."""

    data: date
    compras: list
    total_comprado: Decimal
    limite_base: Decimal
    transferencia_recebida: Decimal
    redistribuicao_recebida: Decimal
    limite_efetivo: Decimal
    saldo_do_dia: Decimal
    novo_saldo_acumulado: Decimal
    cor: str

    @property
    def teve_movimento(self) -> bool:
        return bool(
            self.compras or self.transferencia_recebida or self.redistribuicao_recebida
        )


class HistoricoFinanceiroService:
    """Monta a Timeline Financeira (histórico cronológico) de uma filial."""

    def __init__(self, motor: Optional[MotorFinanceiro] = None):
        self.motor = motor or motor_financeiro

    def gerar_timeline(self, filial, ano: int, mes: int, *, ate_dia: Optional[int] = None) -> list[EventoTimeline]:
        posicoes = self.motor.calcular_posicoes_do_mes(filial, ano, mes, ate_dia=ate_dia)
        compras_por_dia = self._compras_por_dia(filial, ano, mes)

        eventos = []
        for posicao in posicoes:
            transferencia = posicao.saldo_transferido if posicao.saldo_transferido > ZERO else ZERO
            redistribuicao = posicao.saldo_transferido if posicao.saldo_transferido < ZERO else ZERO
            eventos.append(
                EventoTimeline(
                    data=posicao.data,
                    compras=compras_por_dia.get(posicao.data.day, []),
                    total_comprado=posicao.comprado,
                    limite_base=posicao.limite_base,
                    transferencia_recebida=transferencia,
                    redistribuicao_recebida=redistribuicao,
                    limite_efetivo=posicao.limite_efetivo,
                    saldo_do_dia=posicao.saldo_do_dia,
                    novo_saldo_acumulado=posicao.carry_out,
                    cor=posicao.cor,
                )
            )
        return eventos

    @staticmethod
    def _compras_por_dia(filial, ano: int, mes: int) -> dict:
        compras = (
            Compra.objects.filter(filial=filial, data_compra__year=ano, data_compra__month=mes)
            .filter(status__in=STATUS_CONSIDERADOS_NO_LIMITE)
            .select_related("fornecedor", "categoria")
            .order_by("data_compra", "criado_em")
        )
        agrupado: dict = {}
        for compra in compras:
            agrupado.setdefault(compra.data_compra.day, []).append(compra)
        return agrupado


historico_financeiro = HistoricoFinanceiroService()
