from django.apps import AppConfig


class FinanceEngineConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "finance_engine"
    verbose_name = "Motor Financeiro"
