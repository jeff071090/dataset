"""Fórmulas puras do Motor Financeiro NEXBUY.

Este módulo não acessa o banco de dados nem conhece models do Django — cada
função recebe valores já resolvidos e devolve o próximo passo da cadeia de
cálculo. Mantê-las puras (sem efeitos colaterais) facilita testar cada regra
isoladamente e garante que toda a matemática do sistema viva em um único
lugar, como exige a Sprint 3.

Cadeia de cálculo mensal → diária:

    Receita do mês = Receita mensal (faturamento) + Receitas extras do mês
    Receita do mês - Custos Fixos - Custos Variáveis = Disponibilidade
    Disponibilidade × Percentual de Compras         = Capacidade Mensal Bruta
    Capacidade Mensal Bruta × (1 - % Segurança)      = Capacidade Mensal Ajustada
    Capacidade Mensal Ajustada ÷ Dias Úteis          = Limite Diário Base

Com os valores padrão (percentual de segurança 0%, dias úteis calculados
automaticamente), o resultado é idêntico ao das Sprints/Etapas anteriores.
"""
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Optional

ZERO = Decimal("0")
CEM = Decimal("100")


def calcular_disponibilidade(
    faturamento: Decimal, custos_fixos: Decimal, custos_variaveis: Decimal
) -> Decimal:
    """Faturamento - Custos Fixos - Custos Variáveis = Disponibilidade Financeira.

    `faturamento` é a RECEITA TOTAL do mês (receita mensal + receitas
    extras) — quem soma as duas partes é o `CapacidadeCompraService`, esta
    fórmula continua recebendo um único valor já resolvido."""
    return faturamento - custos_fixos - custos_variaveis


def calcular_capacidade_mensal(disponibilidade: Decimal, percentual_compra: Decimal) -> Decimal:
    """Disponibilidade × Percentual de Compras = Capacidade Mensal (bruta, sem margem)."""
    return disponibilidade * (percentual_compra / CEM)


def aplicar_margem_seguranca(capacidade_mensal: Decimal, percentual_seguranca: Decimal) -> Decimal:
    """Reduz a capacidade mensal pela margem de segurança configurada pela empresa."""
    margem = Decimal("1") - (percentual_seguranca / CEM)
    return capacidade_mensal * margem


def calcular_limite_diario(capacidade_mensal_ajustada: Decimal, dias_uteis: int) -> Decimal:
    """Capacidade Mensal Ajustada ÷ Dias Úteis = Limite Diário Base.

    Retorna zero (em vez de levantar ZeroDivisionError) quando não há dias
    úteis — cenário de borda tratado explicitamente, não implícito.
    """
    if not dias_uteis:
        return ZERO
    return capacidade_mensal_ajustada / dias_uteis


def calcular_percentual_utilizado(comprado: Decimal, limite: Decimal) -> Decimal:
    """Quanto do limite do dia já foi utilizado, em percentual (0-100+).

    Regra do semáforo (Sprint de Consolidação — Gate 2A, P0-2/P1-3):
    capacidade NEGATIVA (custos > faturamento) é sempre "esgotada", mesmo
    sem nenhuma compra no dia — nunca pode aparecer como saudável. Limite
    exatamente ZERO sem nenhuma compra permanece neutro/verde (dia sem
    capacidade configurada, ex.: mês sem receita cadastrada ainda, não é
    a mesma coisa que capacidade estourada); ZERO com alguma compra é
    tratado como esgotado, unificando o comportamento histórico que
    `compras.services.classificar_dia` já aplicava nesse caso (divergência
    documentada desde a Sprint 4.1 — BASELINE_TECNICO/013_RISCOS.md).
    """
    if limite < ZERO:
        return CEM * 2
    if limite == ZERO:
        return ZERO if comprado <= ZERO else CEM * 2
    if comprado <= ZERO:
        return ZERO
    return (comprado / limite) * CEM


def classificar_por_percentual(percentual: Decimal) -> str:
    """Limiar único de classificação do consumo em 'verde' (disponível) /
    'laranja' (atenção, ≥80%) / 'vermelho' (excedido, >100%) — fonte única
    reaproveitada por `classificar_consumo` (percentual 0-100) e por
    `compras.services.classificar_dia` (proporção 0-1, convertida para
    percentual antes de chamar esta função). Antes da Sprint 4.1, os dois
    módulos repetiam o mesmo limiar (100 / 80) de forma independente."""
    if percentual > CEM:
        return "vermelho"
    if percentual >= Decimal("80"):
        return "laranja"
    return "verde"


def classificar_consumo(comprado: Decimal, limite: Decimal) -> str:
    """Classifica o consumo do dia em 'verde' (disponível) / 'laranja' (atenção,
    ≥80% do limite) / 'vermelho' (limite excedido) — usado no calendário visual
    e nos indicadores do dashboard."""
    return classificar_por_percentual(calcular_percentual_utilizado(comprado, limite))


@dataclass(frozen=True)
class ReceitaDoMes:
    """Receita de uma filial em um mês, decomposta nas duas partes lançadas
    manualmente: a receita mensal (faturamento, `Receita`) e as receitas
    extras (`ReceitaExtra`). É o insumo primário da cadeia de cálculo —
    toda tela que mostra "receita do mês" deve ler daqui (ou do
    `ResultadoCapacidade`, que carrega os mesmos números), para que os
    totais sempre fechem entre telas."""

    receita_mensal: Decimal = ZERO
    receitas_extras: Decimal = ZERO
    tem_receita_mensal: bool = False
    quantidade_extras: int = 0

    @property
    def total(self) -> Decimal:
        return self.receita_mensal + self.receitas_extras

    @property
    def configurada(self) -> bool:
        """True quando existe receita mensal OU pelo menos uma receita extra."""
        return self.tem_receita_mensal or self.quantidade_extras > 0


@dataclass(frozen=True)
class ResultadoCapacidade:
    """Retrato completo da capacidade financeira de uma filial em um mês.

    `faturamento` continua sendo o TOTAL da receita do mês (é o nome que
    todos os consumidores já leem) e agora vem decomposto em
    `receita_mensal` (o faturamento cadastrado em `Receita`) +
    `receitas_extras` (soma das `ReceitaExtra` com data no mês).
    `receita_configurada` é True quando existe qualquer uma das duas —
    sem nenhuma, um limite R$ 0,00 é ausência de dado, não um cálculo."""

    filial_id: int
    ano: int
    mes: int
    faturamento: Decimal
    custos_fixos: Decimal
    custos_variaveis: Decimal
    disponibilidade: Decimal
    percentual_compra: Decimal
    percentual_seguranca: Decimal
    capacidade_mensal: Decimal
    capacidade_mensal_ajustada: Decimal
    dias_uteis: int
    limite_diario_base: Decimal
    receita_mensal: Decimal = ZERO
    receitas_extras: Decimal = ZERO
    receita_configurada: bool = False


@dataclass(frozen=True)
class PosicaoDiaria:
    """Posição financeira de um único dia dentro do mês, já considerando o
    saldo transferido de dias anteriores (saldo acumulado e/ou redistribuição).

    `tipo_dia` (Épico 2 — CORE 1.0) carrega o tipo resolvido pelo
    Calendário Operacional (útil/sábado/domingo/feriado/bloqueado/
    especial); tem default "util" para preservar qualquer construção
    existente do dataclass."""

    data: date
    limite_base: Decimal
    saldo_transferido: Decimal
    limite_efetivo: Decimal
    comprado: Decimal
    saldo_do_dia: Decimal
    carry_out: Decimal
    cor: str
    tipo_dia: str = "util"

    @property
    def excedeu_limite(self) -> bool:
        return self.saldo_do_dia < ZERO

    @property
    def sem_limite_proprio(self) -> bool:
        """True quando o dia não conta capacidade pelo Calendário
        Operacional (fim de semana da regra padrão, feriado, bloqueio) e
        também não herdou saldo de dias anteriores: é um dia SEM compra
        prevista — as telas o mostram neutro ("sem limite de compra"), não
        verde ("compra liberada") nem vermelho ("limite atingido")."""
        return self.tipo_dia not in ("util", "especial") and self.limite_efetivo <= ZERO

    @property
    def dia_sem_capacidade(self) -> bool:
        """True quando o Calendário Operacional zerou o limite base deste
        dia (feriado, bloqueado ou fim de semana — pela regra padrão ou
        cadastrado como exceção)."""
        return self.tipo_dia in ("feriado", "bloqueado", "sabado", "domingo") and self.limite_base == ZERO


@dataclass(frozen=True)
class ResultadoSimulacao:
    """Resultado de uma simulação de compra — nunca é persistido no banco."""

    fornecedor_nome: str
    categoria_nome: str
    valor: Decimal
    data_compra: date
    saldo_antes: Decimal
    saldo_depois: Decimal
    novo_limite: Decimal
    excedeu_limite: bool
    dias_afetados: list[date]
    alerta: Optional[str]
