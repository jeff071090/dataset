"""Testes do Motor Financeiro (Sprint 3, item 11).

Seis cenários exigidos pela especificação, cobrindo os casos de borda mais
importantes do motor: empresa sem faturamento, empresa nova (sem nenhum
histórico), compra abaixo do limite, compra acima do limite (nas três
formas de bloqueio), dias sem compras (saldo acumulado) e o benefício
prático de ter saldo acumulado disponível.

Rode com:  python manage.py test finance_engine
"""
from datetime import date
from decimal import Decimal

from django.test import TestCase

from . import interfaces
from .interfaces import DDAConnectorBase, IntegracaoDDABase

from cadastros.models import Categoria
from compras.models import Compra, Fornecedor
from compras.services import avaliar_e_criar_compra
from empresas.models import Empresa
from filiais.models import Filial
from financeiro.models import ConfiguracaoFinanceira, CustoFixo, Receita
from usuarios.models import Usuario

from .services import motor_financeiro
from .simulations import simulador_compra

ANO, MES = 2026, 6  # mês fixo (30 dias, sem depender da data de execução do teste)
DIAS_UTEIS_FIXO = 20  # fixado via ConfiguracaoFinanceira para números previsíveis


class MotorFinanceiroTestCase(TestCase):
    """Base comum: cria Empresa + Filial. Cada teste monta seu próprio
    cenário financeiro (Receita/Custos/Config/Compras) por cima disso."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Teste", cnpj=self._cnpj_unico())
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz", cidade="Cuiabá")
        self.fornecedor = Fornecedor.objects.create(empresa=self.empresa, nome="Fornecedor Teste")
        self.categoria = Categoria.objects.create(empresa=self.empresa, nome="Categoria Teste")
        self.usuario = Usuario.objects.create_user(
            username=f"user_{self.empresa.pk}", password="x", perfil=Usuario.Perfil.COMPRADOR,
            empresa=self.empresa, filial=self.filial,
        )

    _contador_cnpj = [0]

    @classmethod
    def _cnpj_unico(cls):
        cls._contador_cnpj[0] += 1
        return f"00.000.000/000{cls._contador_cnpj[0]}-00"

    def _configurar(self, **kwargs):
        defaults = {
            "percentual_compras": Decimal("50"),
            "dias_uteis_manual": DIAS_UTEIS_FIXO,
            "regra_excesso": ConfiguracaoFinanceira.RegraExcesso.ALERTA,
        }
        defaults.update(kwargs)
        return ConfiguracaoFinanceira.objects.create(empresa=self.empresa, **defaults)

    def _criar_compra(self, dia, valor):
        return avaliar_e_criar_compra(
            filial=self.filial,
            fornecedor=self.fornecedor,
            valor=Decimal(valor),
            categoria=self.categoria,
            data_compra=date(ANO, MES, dia),
            prazo_pagamento=Compra.PrazoPagamento.AVISTA,
            prazo_personalizado_dias=None,
            usuario=self.usuario,
        )

    # ------------------------------------------------------------------
    # 1) Empresa sem faturamento
    # ------------------------------------------------------------------
    def test_empresa_sem_faturamento(self):
        self._configurar(regra_excesso=ConfiguracaoFinanceira.RegraExcesso.BLOQUEAR)
        CustoFixo.objects.create(filial=self.filial, descricao="Aluguel", valor=Decimal("1000"), dia_vencimento=10)
        # nenhuma Receita cadastrada para o mês

        capacidade = motor_financeiro.capacidade_do_mes(self.filial, ANO, MES)
        self.assertEqual(capacidade.faturamento, Decimal("0"))
        self.assertEqual(capacidade.disponibilidade, Decimal("-1000"))
        self.assertLess(capacidade.limite_diario_base, Decimal("0"))

        avaliacao = self._criar_compra(dia=5, valor="10")
        self.assertTrue(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.compra.status, Compra.Status.BLOQUEADA)

    # ------------------------------------------------------------------
    # 2) Empresa nova (sem nenhum histórico)
    # ------------------------------------------------------------------
    def test_empresa_nova_sem_historico(self):
        self._configurar()  # sem Receita, sem CustoFixo/Variavel, sem Compra

        capacidade = motor_financeiro.capacidade_do_mes(self.filial, ANO, MES)
        self.assertEqual(capacidade.disponibilidade, Decimal("0"))
        self.assertEqual(capacidade.limite_diario_base, Decimal("0"))

        resumo = motor_financeiro.resumo_dashboard(self.filial, date(ANO, MES, 10))
        self.assertEqual(resumo["dias_comprometidos"], 0)

        # Simulação numa empresa nova não deve lançar exceção nem gravar nada.
        resultado = simulador_compra.simular(
            filial=self.filial, fornecedor=self.fornecedor, valor=Decimal("100"),
            data_compra=date(ANO, MES, 10), categoria=self.categoria,
        )
        self.assertTrue(resultado.excedeu_limite)
        self.assertEqual(Compra.objects.filter(filial=self.filial).count(), 0)

    # ------------------------------------------------------------------
    # 3) Empresa que comprou abaixo do limite
    # ------------------------------------------------------------------
    def test_compra_abaixo_do_limite(self):
        self._configurar()
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # disponibilidade=100000, capacidade=50000, limite_diario=50000/20=2500

        avaliacao = self._criar_compra(dia=5, valor="1000")
        self.assertFalse(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.compra.status, Compra.Status.APROVADA)
        self.assertFalse(avaliacao.compra.alerta_excesso)

        posicao = motor_financeiro.posicao_do_dia(self.filial, date(ANO, MES, 5))
        self.assertEqual(posicao.saldo_do_dia, Decimal("1500"))  # 2500 - 1000

    # ------------------------------------------------------------------
    # 4) Empresa que comprou acima do limite (nas 3 formas de bloqueio)
    # ------------------------------------------------------------------
    def test_compra_acima_do_limite_bloquear(self):
        self._configurar(regra_excesso=ConfiguracaoFinanceira.RegraExcesso.BLOQUEAR)
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))

        avaliacao = self._criar_compra(dia=5, valor="3000")  # limite=2500
        self.assertTrue(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.compra.status, Compra.Status.BLOQUEADA)

    def test_compra_acima_do_limite_aprovacao(self):
        self._configurar(regra_excesso=ConfiguracaoFinanceira.RegraExcesso.APROVACAO)
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))

        avaliacao = self._criar_compra(dia=5, valor="3000")
        self.assertTrue(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.compra.status, Compra.Status.PENDENTE)

    def test_compra_acima_do_limite_alerta(self):
        self._configurar(regra_excesso=ConfiguracaoFinanceira.RegraExcesso.ALERTA)
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))

        avaliacao = self._criar_compra(dia=5, valor="3000")
        self.assertTrue(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.compra.status, Compra.Status.APROVADA)
        self.assertTrue(avaliacao.compra.alerta_excesso)

    # ------------------------------------------------------------------
    # 5) Empresa que ficou dias sem comprar (saldo acumulado)
    # ------------------------------------------------------------------
    def test_dias_sem_comprar_acumulam_saldo(self):
        self._configurar(permitir_saldo_acumulativo=True)
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # limite_diario_base = 2500; dias 1-4 sem nenhuma compra

        posicao_dia5 = motor_financeiro.posicao_do_dia(self.filial, date(ANO, MES, 5))
        self.assertEqual(posicao_dia5.saldo_transferido, Decimal("10000"))  # 2500 x 4 dias parados
        self.assertEqual(posicao_dia5.limite_efetivo, Decimal("12500"))  # 2500 base + 10000 acumulado

    # ------------------------------------------------------------------
    # 6) Empresa com saldo acumulado (usa o saldo para uma compra maior)
    # ------------------------------------------------------------------
    def test_saldo_acumulado_permite_compra_maior_sem_exceder(self):
        self._configurar(permitir_saldo_acumulativo=True, regra_excesso=ConfiguracaoFinanceira.RegraExcesso.BLOQUEAR)
        Receita.objects.create(filial=self.filial, mes=date(ANO, MES, 1), faturamento=Decimal("100000"))
        # dias 1-4 ficam sem comprar -> acumula 10000 de saldo; limite base é só 2500

        avaliacao = self._criar_compra(dia=5, valor="5000")  # > limite base, mas < limite base + acumulado
        self.assertFalse(avaliacao.excedeu_limite)
        self.assertEqual(avaliacao.compra.status, Compra.Status.APROVADA)
        self.assertEqual(avaliacao.limite_diario, Decimal("12500"))


class InterfacesIntegracaoTestCase(TestCase):
    """Mudança de escopo (nuvem): o NEXBUY não se integra a ERP — os antigos
    contratos de SQL Server/ERP (Sprint 6, item 10) foram removidos de
    `interfaces.py` e só o DDA continua como integração prevista. Trava em
    teste que o contrato do DDA segue sendo só contrato (nenhuma
    implementação real, nenhum acesso externo) e que os contratos de ERP
    não voltaram."""

    def test_contrato_dda_nao_pode_ser_instanciado_sem_implementacao(self):
        with self.assertRaises(TypeError):
            IntegracaoDDABase()

    def test_alias_de_compatibilidade_aponta_para_o_contrato_dda(self):
        self.assertIs(DDAConnectorBase, IntegracaoDDABase)

    def test_contratos_de_erp_e_sql_server_foram_removidos(self):
        for nome in (
            "IntegracaoInovafarmaBase", "ERPConnectorBase", "SQLServerConectorBase",
            "SQLServerConnectorBase", "SQLServerLeituraBase", "SQLServerMapeamentoBase",
            "SQLServerImportacaoBase",
        ):
            with self.subTest(contrato=nome):
                self.assertFalse(hasattr(interfaces, nome), f"{nome} voltou a existir em interfaces.py")


class SemaforoNegativoTestCase(TestCase):
    """Sprint de Consolidação (Gate 2A, P0-2/P1-3): saldo/capacidade
    negativa nunca pode aparecer "verde". Fonte única testada diretamente
    (calcular_percentual_utilizado / classificar_por_percentual) para os
    três casos de borda pedidos: limite positivo, zero e negativo."""

    def test_limite_positivo_sem_compra_fica_verde(self):
        from .calculations import calcular_percentual_utilizado, classificar_por_percentual

        percentual = calcular_percentual_utilizado(Decimal("0"), Decimal("1000"))
        self.assertEqual(percentual, Decimal("0"))
        self.assertEqual(classificar_por_percentual(percentual), "verde")

    def test_limite_zero_sem_compra_fica_verde_dia_sem_capacidade_configurada(self):
        from .calculations import calcular_percentual_utilizado, classificar_por_percentual

        percentual = calcular_percentual_utilizado(Decimal("0"), Decimal("0"))
        self.assertEqual(classificar_por_percentual(percentual), "verde")

    def test_limite_zero_com_compra_fica_vermelho(self):
        from .calculations import calcular_percentual_utilizado, classificar_por_percentual

        percentual = calcular_percentual_utilizado(Decimal("50"), Decimal("0"))
        self.assertEqual(classificar_por_percentual(percentual), "vermelho")

    def test_limite_negativo_sem_nenhuma_compra_fica_vermelho_nunca_verde(self):
        """O cenário exato do Gate 2A (P1-3): custos > faturamento produz
        limite negativo; mesmo sem nenhuma compra no dia, o semáforo tem
        que acusar capacidade esgotada — nunca "operação saudável"."""
        from .calculations import calcular_percentual_utilizado, classificar_por_percentual

        percentual = calcular_percentual_utilizado(Decimal("0"), Decimal("-1414.50"))
        self.assertEqual(classificar_por_percentual(percentual), "vermelho")

    def test_limite_negativo_com_compra_fica_vermelho(self):
        from .calculations import calcular_percentual_utilizado, classificar_por_percentual

        percentual = calcular_percentual_utilizado(Decimal("200"), Decimal("-500"))
        self.assertEqual(classificar_por_percentual(percentual), "vermelho")

    def test_classificar_dia_unificado_com_classificar_consumo_no_limite_zero_com_compra(self):
        """Antes desta Sprint, `classificar_dia` (compras) e
        `classificar_consumo` (finance_engine) divergiam nesse caso de
        borda (vermelho vs. laranja) — dívida técnica documentada desde a
        Sprint 4.1. Agora ambos delegam à mesma fonte e concordam."""
        from compras.services import classificar_dia

        from .calculations import classificar_consumo

        cor_compras, _ = classificar_dia(Decimal("50"), Decimal("0"))
        cor_motor = classificar_consumo(Decimal("50"), Decimal("0"))
        self.assertEqual(cor_compras, cor_motor)


class DiasUteisManualZeroTestCase(TestCase):
    """Revisão adversarial (Fechamento Final, Prompt 1, Seção 8):
    `dias_uteis_manual=0` é uma configuração EXPLÍCITA válida ("zero dias
    úteis manuais"), mas `(config and config.dias_uteis_manual) or
    dias_uteis_operacionais(...)` tratava `0` como falsy — igual a
    não-preenchido — e caía no cálculo automático, ignorando a
    configuração administrativa explícita e calculando um limite diário
    positivo em vez de ZERO."""

    def setUp(self):
        self.empresa = Empresa.objects.create(nome="Empresa Dias Uteis Zero", cnpj="97.111.111/0001-97")
        self.filial = Filial.objects.create(empresa=self.empresa, nome="Matriz")
        Receita.objects.create(filial=self.filial, mes=date(2026, 6, 1), faturamento=Decimal("100000"))

    def test_dias_uteis_manual_zero_e_honrado_nao_cai_no_calculo_automatico(self):
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=0,
        )
        capacidade = motor_financeiro.capacidade_do_mes(self.filial, 2026, 6)
        self.assertEqual(capacidade.dias_uteis, 0)
        # calcular_limite_diario já trata dias_uteis=0 como caso de borda —
        # o limite diário correto para "zero dias úteis configurados" é
        # ZERO, nunca uma divisão pelo cálculo automático (que dá ~22).
        self.assertEqual(capacidade.limite_diario_base, Decimal("0"))

    def test_dias_uteis_manual_none_ainda_cai_no_calculo_automatico(self):
        """Diferente de `0` (explícito), `None` (nunca preenchido) precisa
        continuar caindo no fallback automático — este teste prova que a
        correção não quebrou o caminho legado."""
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=None,
        )
        capacidade = motor_financeiro.capacidade_do_mes(self.filial, 2026, 6)
        self.assertGreater(capacidade.dias_uteis, 0)

    def test_dias_uteis_manual_positivo_continua_mandando(self):
        ConfiguracaoFinanceira.objects.create(
            empresa=self.empresa, percentual_compras=Decimal("50"), dias_uteis_manual=15,
        )
        capacidade = motor_financeiro.capacidade_do_mes(self.filial, 2026, 6)
        self.assertEqual(capacidade.dias_uteis, 15)
