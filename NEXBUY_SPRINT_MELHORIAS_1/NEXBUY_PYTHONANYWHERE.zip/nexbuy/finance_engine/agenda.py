"""Agenda Financeira única (Épico 3 — CORE 1.0).

Uma visão cronológica ÚNICA de todos os compromissos financeiros de uma
filial: parcelas de compras, contas fixas (recorrentes), contas variáveis
e provisões planejadas. É uma AGREGAÇÃO derivada das fontes reais — nada
é persistido em tabela própria, o que garante que a agenda nunca fique
dessincronizada de uma compra/conta/provisão (a mesma decisão de design
da Timeline Financeira, Sprint 3).

Cada lançamento carrega: empresa, origem, tipo, data, valor, status e
responsável — o contrato pedido pelo Épico 3.
"""
import calendar as calendar_module
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional

from compras.models import ParcelaCompra
from financeiro.models import CustoFixo, CustoVariavel
from gestao_compras.models import Provisao

from .calculations import ZERO

ORIGEM_PARCELA = "parcela"
ORIGEM_CONTA_FIXA = "conta_fixa"
ORIGEM_CONTA_VARIAVEL = "conta_variavel"
ORIGEM_PROVISAO = "provisao"

_STATUS_PROVISAO_NA_AGENDA = (
    Provisao.Status.PROVISIONADA,
    Provisao.Status.AGUARDANDO_APROVACAO,
    Provisao.Status.APROVADA,
    Provisao.Status.AGUARDANDO_DDA,
    # Sprint de Correções Críticas (Seção 13) — EFETIVADA sai da Agenda: a
    # Provisão virou uma Compra real (`Compra.provisao_origem`), e são as
    # PARCELAS dessa Compra (origem `ORIGEM_PARCELA`) que agora representam
    # o compromisso aqui. Mantê-la listada faria a mesma obrigação aparecer
    # duas vezes na Agenda (dupla contagem).
)


@dataclass(frozen=True)
class LancamentoAgenda:
    """Um compromisso na Agenda Financeira — formato único, qualquer origem."""

    empresa_id: int
    origem: str  # parcela | conta_fixa | conta_variavel | provisao
    tipo: str  # rótulo exibível ("Parcela 2/3", "Conta Fixa", ...)
    descricao: str
    data: date
    valor: Decimal
    status: str  # "pendente" | "paga" | "prevista" | "aguardando_aprovacao"
    responsavel: str  # quem lançou/é responsável (quando existe)
    referencia_id: Optional[int] = None  # pk do objeto de origem (ações, ex.: baixar parcela)
    vencida: bool = False

    @property
    def pendente(self) -> bool:
        return self.status in ("pendente", "prevista", "aguardando_aprovacao")


def _ocorrencias_de_custo_fixo(custo: CustoFixo, inicio: date, fim: date) -> list[date]:
    """Datas em que um Custo Fixo (dia fixo do mês) ocorre dentro do
    período — expande mês a mês, ajustando meses mais curtos que o dia."""
    ocorrencias = []
    ano, mes = inicio.year, inicio.month
    while (ano, mes) <= (fim.year, fim.month):
        ultimo_dia = calendar_module.monthrange(ano, mes)[1]
        ocorrencia = date(ano, mes, min(custo.dia_vencimento, ultimo_dia))
        if inicio <= ocorrencia <= fim:
            ocorrencias.append(ocorrencia)
        ano, mes = (ano + 1, 1) if mes == 12 else (ano, mes + 1)
    return ocorrencias


def gerar_agenda(filial, data_inicio: date, data_fim: date, hoje: Optional[date] = None) -> list[LancamentoAgenda]:
    """Todos os compromissos da filial no período, em ordem cronológica."""
    hoje = hoje or date.today()
    lancamentos: list[LancamentoAgenda] = []
    empresa_id = filial.empresa_id

    parcelas = (
        ParcelaCompra.objects.filter(
            compra__filial=filial,
            data_vencimento__gte=data_inicio,
            data_vencimento__lte=data_fim,
        )
        .exclude(status=ParcelaCompra.Status.CANCELADA)
        .select_related("compra", "compra__fornecedor", "compra__usuario")
    )
    for parcela in parcelas:
        total = parcela.compra.parcelas.count()
        responsavel = parcela.compra.usuario
        lancamentos.append(
            LancamentoAgenda(
                empresa_id=empresa_id,
                origem=ORIGEM_PARCELA,
                tipo=f"Parcela {parcela.numero}/{total}" if total > 1 else "Pagamento de compra",
                descricao=parcela.compra.fornecedor.nome,
                data=parcela.data_vencimento,
                valor=parcela.valor,
                status="paga" if parcela.status == ParcelaCompra.Status.PAGA else "pendente",
                responsavel=(responsavel.get_full_name() or responsavel.username) if responsavel else "",
                referencia_id=parcela.pk,
                vencida=parcela.status == ParcelaCompra.Status.PENDENTE and parcela.data_vencimento < hoje,
            )
        )

    for custo in CustoFixo.objects.filter(filial=filial, ativo=True):
        for ocorrencia in _ocorrencias_de_custo_fixo(custo, data_inicio, data_fim):
            lancamentos.append(
                LancamentoAgenda(
                    empresa_id=empresa_id,
                    origem=ORIGEM_CONTA_FIXA,
                    tipo="Conta Fixa",
                    descricao=custo.descricao,
                    data=ocorrencia,
                    valor=custo.valor,
                    status="prevista",
                    responsavel=custo.fornecedor or "",
                    referencia_id=custo.pk,
                    vencida=ocorrencia < hoje,
                )
            )

    variaveis = CustoVariavel.objects.filter(
        filial=filial, data_prevista__gte=data_inicio, data_prevista__lte=data_fim
    )
    for custo in variaveis:
        lancamentos.append(
            LancamentoAgenda(
                empresa_id=empresa_id,
                origem=ORIGEM_CONTA_VARIAVEL,
                tipo="Conta Variável",
                descricao=custo.descricao,
                data=custo.data_prevista,
                valor=custo.valor,
                status="prevista",
                responsavel="",
                referencia_id=custo.pk,
                vencida=custo.data_prevista < hoje,
            )
        )

    provisoes = (
        Provisao.objects.filter(
            filial=filial, data__gte=data_inicio, data__lte=data_fim, status__in=_STATUS_PROVISAO_NA_AGENDA
        )
        .select_related("fornecedor", "comprador")
    )
    for provisao in provisoes:
        aguardando = provisao.status == Provisao.Status.AGUARDANDO_APROVACAO
        lancamentos.append(
            LancamentoAgenda(
                empresa_id=empresa_id,
                origem=ORIGEM_PROVISAO,
                tipo="Provisão de Compra",
                descricao=provisao.fornecedor.nome,
                data=provisao.data,
                valor=provisao.valor_total,
                status="aguardando_aprovacao" if aguardando else "prevista",
                responsavel=provisao.comprador.get_full_name() or provisao.comprador.username,
                referencia_id=provisao.pk,
                vencida=False,
            )
        )

    lancamentos.sort(key=lambda item: (item.data, item.origem, item.descricao))
    return lancamentos


def agenda_do_dia(filial, data_referencia: date) -> list[LancamentoAgenda]:
    return gerar_agenda(filial, data_referencia, data_referencia, hoje=data_referencia)


def pagamentos_do_dia(filial, data_referencia: date) -> dict:
    """Resumo dos pagamentos de um dia (card "Pagamentos de hoje")."""
    itens = agenda_do_dia(filial, data_referencia)
    pendentes = [item for item in itens if item.pendente]
    return {
        "itens": itens,
        "quantidade": len(itens),
        "total": sum((item.valor for item in itens), ZERO),
        "total_pendente": sum((item.valor for item in pendentes), ZERO),
    }


def proximos_vencimentos(filial, data_referencia: date, dias_janela: int = 14, limite: int = 8) -> list[LancamentoAgenda]:
    """Próximos compromissos APÓS o dia de referência, na janela dada."""
    agenda = gerar_agenda(
        filial, data_referencia + timedelta(days=1), data_referencia + timedelta(days=dias_janela), hoje=data_referencia
    )
    return agenda[:limite]


def parcelas_vencidas(filial, data_referencia: date, dias_retroativos: int = 60) -> list[LancamentoAgenda]:
    """Parcelas pendentes com vencimento já passado (para alertas)."""
    agenda = gerar_agenda(
        filial, data_referencia - timedelta(days=dias_retroativos), data_referencia - timedelta(days=1),
        hoje=data_referencia,
    )
    return [item for item in agenda if item.origem == ORIGEM_PARCELA and item.status == "pendente"]
