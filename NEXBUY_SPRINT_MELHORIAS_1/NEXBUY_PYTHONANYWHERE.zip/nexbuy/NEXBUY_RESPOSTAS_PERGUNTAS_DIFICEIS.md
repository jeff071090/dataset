# NEXBUY — Respostas para Perguntas Difíceis

Respostas honestas, prontas para usar. Regra única: **nunca inventar
preço, prazo, certificação, integração ou garantia.** Quando não souber,
diga que vai verificar e volte com a resposta por escrito.

### "Já integra com o Inovafarma?"

> "Não, e não vai integrar: foi uma decisão tomada junto com vocês. O
> NEXBUY é 100% web e funciona sozinho — a receita mensal, as receitas
> extras, os custos fixos e variáveis e as compras são lançados
> manualmente, pela própria tela, e é isso que alimenta a projeção de
> compra e os limites dos compradores. A única integração prevista é o
> DDA, que ainda não está conectado — e a tela de Integrações diz
> exatamente isso."

### "Já busca o DDA?"

> "Ainda não. O DDA é a integração futura prevista: quando for conectado,
> os boletos apresentados ao CNPJ vão aparecer na mesma Agenda Financeira
> que vocês viram, para o Financeiro conferir — ele nunca paga nada
> sozinho nem dá baixa automática. Hoje os compromissos nascem das
> compras, provisões e custos lançados no sistema — o que já elimina a
> surpresa do boleto."

### "O sistema sugere compras sozinho?"

> "Não. O que vocês viram de alertas e mensagens são regras fixas do motor
> financeiro, calculadas a partir do que foi lançado — e a decisão de
> compra é sempre de uma pessoa, dentro do limite e da alçada definidos
> por vocês."

### "Consigo ver a saúde financeira da empresa?"

> "Sim. O módulo de Análise Financeira mostra o DRE, os créditos × débitos
> e um indicador de saúde financeira, com curvas ao longo do tempo — tudo
> calculado a partir dos lançamentos manuais. Ele é visto pelo
> Proprietário, pelo Gerente e pelo Financeiro; o Comprador continua só
> com a visão de compras dele, sem nenhum dado financeiro sensível."

### "Está pronto para produção?"

> "O núcleo que vocês viram — lançamentos de receitas e custos, compras,
> provisões, limites, aprovações, agenda, Análise Financeira e auditoria —
> está funcional e coberto por uma suíte extensa de testes automatizados;
> tudo que demonstrei rodou de verdade, sem tela falsa. O sistema roda
> 100% na web: o primeiro acesso cria o administrador, e ele cadastra os
> demais usuários. Colocar na operação de vocês é cadastrar a estrutura,
> os perfis e os limites e acompanhar o primeiro ciclo — é isso que
> proponho desenharmos juntos como próximo passo."

### "Quanto custa?"

> "Depende do número de empresas, filiais e usuários e do pacote de
> implantação. Não vou chutar um número aqui: prefiro levar a estrutura
> real de vocês e voltar com uma proposta fechada, por escrito."

### "Quanto tempo leva para implantar?"

> "Não vou prometer uma data hoje. A implantação é configuração —
> empresas, filiais, perfis, limites e alçadas — mais o acompanhamento do
> primeiro ciclo. Com a estrutura de vocês em mãos eu volto com um plano
> por etapas e aí sim assumimos prazos."

### "Meus dados ficam seguros?"

> "O desenho de segurança tem camadas que vocês viram funcionando: cada
> empresa e filial isolada, permissões por perfil (o comprador não vê
> folha, aluguel nem faturamento), autenticação com senha, proteção CSRF
> e uma auditoria que registra quem fez o quê e quando. Nesta
> demonstração só usamos dados fictícios. Detalhes de hospedagem e backup
> fazem parte do plano de implantação."

### "Funciona no celular?"

> "Sim — é interface web responsiva, como mostrei na barra inferior: o
> aprovador consegue decidir sem estar no computador. Não é um aplicativo
> de loja (App Store/Play Store); é o sistema abrindo bem em qualquer
> tela."

### "Consigo acompanhar várias empresas?"

> "Sim, e vocês viram ao vivo: o seletor no topo troca o contexto entre
> os CNPJs do grupo, com os dados completamente isolados entre si — e a
> mesma pessoa pode ser autorizada em mais de uma empresa e filial, com
> limites próprios em cada uma."
