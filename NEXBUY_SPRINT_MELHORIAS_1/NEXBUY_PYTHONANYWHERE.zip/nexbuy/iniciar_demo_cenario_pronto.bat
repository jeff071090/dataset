@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo   NEXBUY - Demo Comercial (cenario pronto)
echo ============================================
echo.
echo Este launcher NUNCA toca no banco principal (db.sqlite3) nem na pasta
echo media\ principal. Ele usa SOMENTE db_demo_cliente.sqlite3 e a pasta
echo media_demo_cliente\, isoladas do ambiente real (nexbuy.settings_demo) -
echo o MESMO banco/midia de demo do iniciar_demo_cliente_limpa.bat. Para
echo resetar este cenario, use resetar_demo_cliente_limpa.bat.
echo.
echo ATENCAO: os dados abaixo sao TODOS FICTICIOS ("Farmacia Vida Plena"),
echo criados pelo comando seed_demo para fins de demonstracao comercial.
echo Nenhum dado real de cliente existe neste banco.
echo.

REM --- 0. Isolamento extra so para esta sessao -----------------------------
REM DEBUG=True so para o processo deste terminal (nunca gravado em .env):
REM alem de a demo rodar em http local sem HTTPS/dominio real, o seed_demo
REM cria usuarios com senha publica conhecida e e bloqueado automaticamente
REM quando DEBUG=False (ver core/utils.py::abortar_seed_em_producao) - isto
REM garante que o launcher funciona mesmo que o .env da pasta esteja
REM configurado como producao.
set DEBUG=True
REM Gate Final V2 (Bloqueador P1): o cenario PRONTO usa dados FICTICIOS
REM (seed_demo) - o badge "Modo Demonstracao" deve ficar visivel em todas
REM as telas aplicaveis. DEMO_MODE=True explicito aqui; o cenario limpo
REM (iniciar_demo_cliente_limpa.bat) roda com DEMO_MODE=False.
set DEMO_MODE=True

REM --- 1. Verificar Python 3.12+ no PATH ------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado no PATH.
    echo Instale o Python 3.12 ou mais recente e tente novamente.
    pause
    exit /b 1
)

python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Versao do Python incompativel. E necessario Python 3.12 ou mais recente.
    python --version
    pause
    exit /b 1
)

REM --- 2. Ambiente virtual ---------------------------------------------------
REM Mesma decisao do iniciar_demo_cliente_limpa.bat: reaproveita o venv\ do
REM projeto em vez de um venv de demo separado.
if not exist "venv\Scripts\python.exe" (
    echo Criando ambiente virtual...
    python -m venv venv
    if errorlevel 1 (
        echo [ERRO] Falha ao criar o ambiente virtual.
        pause
        exit /b 1
    )
)

REM --- 3. Dependencias ---------------------------------------------------------
venv\Scripts\python.exe -c "import django" >nul 2>&1
if errorlevel 1 (
    echo Instalando dependencias...
    venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERRO] Falha ao instalar as dependencias.
        pause
        exit /b 1
    )
)

REM --- 4. Banco de demo (isolado, nunca db.sqlite3) + cenario pronto -----------
echo Aplicando migracoes no banco de demo (db_demo_cliente.sqlite3)...
venv\Scripts\python.exe manage.py migrate --noinput --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao aplicar as migracoes no banco de demo.
    pause
    exit /b 1
)

echo.
echo Gerando/atualizando o cenario de demonstracao (seed_demo)...
echo Comando idempotente: pode ser executado de novo a qualquer momento sem
echo duplicar nem quebrar nada - a "historia" do mes e sempre recriada em
echo relacao a data de hoje.
venv\Scripts\python.exe manage.py seed_demo --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao gerar o cenario de demonstracao.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Cenario pronto gerado com sucesso.
echo   Badge "Modo Demonstracao" fica visivel em toda tela (DEMO_MODE=True).
echo   TODOS os dados abaixo sao FICTICIOS - nao sao um cliente real.
echo.
echo   Credenciais de demonstracao (senha igual para todas: nexbuy123):
echo     demo_proprietario  - Roberto Almeida    (Proprietario)
echo     demo_gerente       - Fernanda Costa     (Gerente)
echo     demo_financeiro    - Marcos Vinicius    (Financeiro)
echo     demo_comprador     - Juliana Ramos      (Comprador)
echo     demo_comprador2    - Pedro Henrique     (Comprador)
echo     demo_comprador3    - Carla Menezes      (Comprador, BLOQUEADA)
echo.
echo   Estas credenciais sao DIFERENTES das credenciais de desenvolvimento
echo   (proprietario/gerente/financeiro/comprador) - nunca confunda as duas.
echo ============================================
echo.

echo Abrindo o navegador em /accounts/login/...
start http://127.0.0.1:8000/accounts/login/

echo.
echo ============================================
echo   NAO FECHE ESTA JANELA durante a apresentacao.
echo   Para encerrar, feche esta janela ou pressione Ctrl+C.
echo   Endereco: http://127.0.0.1:8000/
echo   Banco isolado: db_demo_cliente.sqlite3
echo   Midia isolada: media_demo_cliente\
echo ============================================
echo.

venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000 --settings=nexbuy.settings_demo
pause
