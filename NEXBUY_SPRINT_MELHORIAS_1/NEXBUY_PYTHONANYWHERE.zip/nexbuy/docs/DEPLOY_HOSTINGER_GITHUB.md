# NEXBUY na nuvem — passo a passo (GitHub + VPS Hostinger)

Guia para colocar o NEXBUY no ar, do zero, numa VPS da Hostinger, com o código num repositório **privado** do GitHub. Siga na ordem; cada parte termina com uma conferência ("✅ Pronto quando…").

> **Só quer mostrar o NEXBUY para a cliente antes de contratar a VPS?** Há
> uma demonstração **grátis**, só com dados fictícios, no PythonAnywhere:
> [DEPLOY_PYTHONANYWHERE_DEMO.md](DEPLOY_PYTHONANYWHERE_DEMO.md). Ela é
> descartável — este guia continua sendo o da instalação de verdade.

**Arquitetura final**

```
Navegador ──HTTPS──> nginx (certificado Let's Encrypt, porta 443)
                       ├── /static/  e  /media/  → servidos direto do disco
                       └── resto → gunicorn (socket /run/nexbuy/gunicorn.sock) → Django (NEXBUY)
                                                     └── SQLite em /var/lib/nexbuy/db.sqlite3
Backup diário 03:30 → /var/backups/nexbuy (14 dias)
```

| O quê | Onde fica na VPS |
|---|---|
| Código (clone do GitHub) | `/opt/nexbuy/app` |
| Ambiente Python | `/opt/nexbuy/venv` |
| Variáveis de produção (segredos) | `/etc/nexbuy/nexbuy.env` |
| Banco de dados | `/var/lib/nexbuy/db.sqlite3` |
| Uploads (logo/favicon) | `/var/lib/nexbuy/media/` |
| Backups | `/var/backups/nexbuy/` |

Tempo total estimado: **1h30 a 2h**, a maior parte esperando o DNS propagar.

Você vai precisar de: acesso ao e-mail da conta do GitHub, acesso ao hPanel da Hostinger, o domínio já comprado e um e-mail para os avisos do certificado.

---

## Parte A — GitHub: repositório privado e envio do código

### A.1 Criar o repositório

1. Entre em <https://github.com> (crie a conta se ainda não tiver).
2. Canto superior direito **+** → **New repository**.
3. **Repository name:** `nexbuy` · **Private** (obrigatório — o código é da empresa) · **não** marque "Add a README", ".gitignore" nem "license" (o repositório precisa nascer vazio).
4. **Create repository**. Anote o endereço mostrado, no formato `https://github.com/SUA-CONTA/nexbuy.git`.

### A.2 Git no Windows

O Git para Windows **já está instalado** nesta máquina (versão 2.54). Em outra máquina: baixe em <https://git-scm.com/download/win> e instale com as opções padrão.

Abra o **PowerShell** e configure seu nome e e-mail (aparecem no histórico):

```powershell
git config --global user.name "Seu Nome"
git config --global user.email "seu-email@empresa.com.br"
```

### A.3 Primeiro envio (só uma vez)

```powershell
cd C:\NEXBUY\nexbuy_producao      # a pasta do projeto no seu computador
git init
git add .
git status
```

**Confira a lista do `git status` antes de continuar.** Ela **não pode** conter: `.env`, `db.sqlite3`, `db_demo_cliente.sqlite3`, `venv/`, `media/`, `media_demo_cliente/`, `staticfiles/`. O arquivo `.gitignore` do projeto já exclui tudo isso — confirme com:

```powershell
git check-ignore -v .env db.sqlite3 venv media
```

(cada um deve aparecer com a linha do `.gitignore` que o exclui). Estando certo:

```powershell
git add --chmod=+x "deploy/*.sh"
git commit -m "NEXBUY - versao inicial para producao"
git branch -M main
git remote add origin https://github.com/SUA-CONTA/nexbuy.git
git push -u origin main
```

No `git push` o Windows abre uma janela de login do GitHub (Git Credential Manager) — entre com a sua conta e autorize.

> Avisos "LF will be replaced by CRLF" durante o `git add` são normais. O arquivo `.gitattributes` garante que os scripts do servidor (`deploy/*.sh`, `.conf`, `.service`) sempre cheguem ao Linux com fim de linha LF — com CRLF eles quebram com `bad interpreter`.

### A.4 Testes automáticos no GitHub

A cada `git push` na `main`, o GitHub roda a suíte completa de testes (arquivo `.github/workflows/testes.yml`). Acompanhe na aba **Actions** do repositório: leva de 20 a 30 minutos. **Só atualize a VPS com um commit que tenha o ✓ verde.**

> Repositórios privados no plano gratuito têm 2.000 minutos de Actions por mês — dá para ~60 execuções.

### A.5 Como a VPS vai baixar o código (repositório privado)

O servidor precisa de permissão **somente leitura** ao repositório. Escolha **uma** opção (você executa os comandos na Parte E, já dentro da VPS):

**Opção 1 — deploy key (recomendada: só leitura, só este repositório, não expira)**

Na VPS (como root):

```bash
ssh-keygen -t ed25519 -f /root/.ssh/id_ed25519 -N "" -C "vps-nexbuy"
cat /root/.ssh/id_ed25519.pub
```

Copie a linha inteira que começa com `ssh-ed25519`. No GitHub: repositório **nexbuy** → **Settings** → **Deploy keys** → **Add deploy key** → Title `VPS Hostinger` → cole a chave → **deixe "Allow write access" DESMARCADO** → **Add key**. Teste na VPS:

```bash
ssh -T git@github.com
```

Na primeira vez ele pergunta se confia no github.com: confira se a impressão digital mostrada é `SHA256:+DiY3wvvV6TuJJhbpZisF/zLDA0zPMSvHdkr4UvCOqU` (ED25519, oficial do GitHub) e digite `yes`. A resposta esperada é `Hi SUA-CONTA/nexbuy! You've successfully authenticated...`. O endereço para clonar é `git@github.com:SUA-CONTA/nexbuy.git`.

**Opção 2 — token de acesso pessoal (fine-grained, somente leitura)**

GitHub → sua foto → **Settings** → **Developer settings** → **Personal access tokens** → **Fine-grained tokens** → **Generate new token**: nome `vps-nexbuy`; **Expiration** (ex.: 1 ano — anote a data); **Repository access: Only select repositories → nexbuy**; **Permissions → Repository permissions → Contents: Read-only**. Gere e copie o token (`github_pat_...`, aparece uma vez só). Na hora do `git clone https://github.com/SUA-CONTA/nexbuy.git ...`, o Git pede **Username** (seu usuário do GitHub) e **Password** (cole o token). Para as próximas atualizações não pedirem de novo: `git -C /opt/nexbuy/app config credential.helper store`. Quando o token vencer, gere outro e rode um `git pull` (ele pede de novo).

✅ **Pronto quando:** o repositório aparece como **Private** no GitHub, com os arquivos, e a aba Actions mostra o ✓ verde.

---

## Parte B — Hostinger: contratar e preparar a VPS

1. hPanel da Hostinger → **VPS** → contratar um plano **KVM**:
   - **KVM 1** (1 vCPU, 4 GB RAM, 50 GB) — **mínimo**, atende uma farmácia com poucos usuários.
   - **KVM 2** (2 vCPU, 8 GB RAM, 100 GB) — **recomendado**: folga para várias filiais/usuários simultâneos e para crescer.
   (Confira os números no site na hora da compra; o instalador se ajusta sozinho a 1 ou 2 vCPUs.)
2. **Localização do servidor:** a mais próxima dos usuários (Brasil, se disponível).
3. **Sistema operacional:** em "Sistema operacional puro" (*Plain OS*), escolha **Ubuntu 24.04** — **sem** painel de controle e **sem** aplicativo pré-instalado.
4. **Senha root:** crie uma senha forte e guarde no cofre de senhas da empresa. (Se souber usar chave SSH, adicione a sua chave pública também.)
5. Aguarde a VPS ficar "Em execução". Em **VPS → Gerenciar → Visão geral** anote o **endereço IPv4** (ex.: `203.0.113.45`) — ele é usado nas Partes C e D.
6. **Firewall da Hostinger** (VPS → Segurança/Firewall): se houver regras criadas, garanta que as portas **22, 80 e 443** (TCP) estão liberadas. Sem regras, está tudo liberado (o próprio instalador liga o firewall `ufw` dentro do Ubuntu).

✅ **Pronto quando:** a VPS aparece "Em execução" e você tem o IP e a senha root.

---

## Parte C — DNS: apontar o domínio para a VPS

Crie **dois registros do tipo A** apontando para o IP da VPS:

| Tipo | Nome | Aponta para | TTL |
|---|---|---|---|
| A | `@` (o próprio domínio) | IP da VPS | 300 (ou o padrão) |
| A | `www` | IP da VPS | 300 (ou o padrão) |

**Domínio comprado na Hostinger:** hPanel → **Domínios** → escolha o domínio → **DNS / Nameservers** → **Gerenciar registros DNS**. Edite (ou apague e recrie) os registros **A** de `@` e `www` que já existem — normalmente apontam para uma página de "domínio estacionado".

**Domínio `.com.br` no Registro.br:** <https://registro.br> → entre → clique no domínio → **DNS** → (usando os servidores DNS do Registro.br) **Editar zona** → **Nova entrada**: tipo **A**, nome em branco (domínio principal), valor = IP; outra tipo **A**, nome `www`, valor = IP → **Salvar**.

⚠️ **Registro AAAA (IPv6):** se existir um registro **AAAA** para `@` ou `www` apontando para outro lugar (estacionamento), **apague-o**. O Let's Encrypt prefere IPv6 quando existe AAAA — e o certificado falha se esse endereço não for o da sua VPS.

**Conferir a propagação** (de 5 minutos a algumas horas) no PowerShell:

```powershell
nslookup seudominio.com.br 8.8.8.8
nslookup www.seudominio.com.br 8.8.8.8
```

As duas respostas precisam mostrar o IP da VPS. Também dá para ver em <https://dnschecker.org>.

✅ **Pronto quando:** os dois `nslookup` devolvem o IP da VPS.

---

## Parte D — Entrar na VPS pelo PowerShell (SSH)

O Windows 10/11 já traz o cliente SSH. No PowerShell:

```powershell
ssh root@IP-DA-VPS
```

Na primeira conexão ele pergunta se confia no servidor — digite `yes` — e depois pede a senha root (a digitação não aparece na tela; é normal). Alternativa sem PowerShell: hPanel → VPS → **Terminal do navegador**.

Já dentro da VPS, atualize o sistema (recomendado, uma vez):

```bash
apt-get update && apt-get -y full-upgrade
reboot
```

Espere 1 minuto e conecte de novo com `ssh root@IP-DA-VPS`.

✅ **Pronto quando:** o terminal mostra algo como `root@srv123456:~#`.

---

## Parte E — Baixar o código e rodar o instalador

Na VPS, como root:

```bash
apt-get update && apt-get install -y git
```

Faça a **Parte A.5** (deploy key ou token) e clone o repositório para o lugar definitivo:

```bash
# Opção 1 (deploy key):
git clone git@github.com:SUA-CONTA/nexbuy.git /opt/nexbuy/app
# Opção 2 (token):
git clone https://github.com/SUA-CONTA/nexbuy.git /opt/nexbuy/app
```

Rode o instalador (troque pelo seu domínio e e-mail):

```bash
bash /opt/nexbuy/app/deploy/instalar_servidor.sh seudominio.com.br ti@suaempresa.com.br
```

O `instalar_servidor.sh` faz tudo sozinho, em 12 etapas (5 a 10 minutos):

1. instala os pacotes do Ubuntu (Python 3.12, nginx, certbot, git, sqlite3, ufw, cron);
2. cria o usuário de sistema `nexbuy` e as pastas de dados (`/var/lib/nexbuy`) e de backup;
3. usa o código de `/opt/nexbuy/app` (ou clona, se você passar a URL do repositório como 3º argumento);
4. cria o ambiente Python e instala as dependências (`requirements.txt`);
5. cria `/etc/nexbuy/nexbuy.env` (permissão 600) com **SECRET_KEY** e **INITIAL_SETUP_TOKEN** fortes, gerados na hora — **se o arquivo já existir, nunca é alterado**;
6. roda `check --deploy` (verificação de segurança do Django);
7. cria o banco **vazio** (`migrate`) e publica os arquivos estáticos (`collectstatic`) — se o banco já existir, só aplica migrações pendentes;
8. instala e liga o serviço `nexbuy` (gunicorn) e confere o `/healthz/`;
9. configura o nginx para o domínio;
10. liga o firewall (SSH + HTTP + HTTPS);
11. agenda o backup diário (03:30) e já faz o primeiro;
12. confere se o DNS já chega nesta VPS e emite o certificado HTTPS (Let's Encrypt, com renovação automática).

No final ele imprime um quadro com o **endereço**, a **URL do Primeiro Acesso** e o **token**.

**Se o DNS ainda não tiver propagado**, o instalador **não** chama o certbot (para não gastar as tentativas do Let's Encrypt) e avisa. Quando o `nslookup` mostrar o IP certo, **rode o mesmo comando de novo** — é seguro repetir quantas vezes quiser: ele não apaga banco, não troca as chaves e só completa o que faltou.

✅ **Pronto quando:** o quadro final aparece sem "HTTPS ainda NÃO ativo" e <https://seudominio.com.br/healthz/> mostra `{"status": "ok"}` no navegador.

---

## Parte F — Primeiro Acesso: criar a empresa e o administrador

O banco de produção nasce **vazio**: nenhuma empresa, nenhum usuário, nenhuma compra, provisão, receita ou custo. O primeiro usuário (o **administrador da empresa**, perfil Proprietário) é criado por uma tela protegida por token:

1. Abra **https://seudominio.com.br/primeiro-acesso/**
2. Digite o **token** mostrado no fim do instalador. Para vê-lo de novo, na VPS:
   ```bash
   grep INITIAL_SETUP_TOKEN /etc/nexbuy/nexbuy.env
   ```
   (O token é um segredo: não mande por WhatsApp/e-mail; quem o tiver pode criar o administrador enquanto o sistema estiver vazio.)
3. Preencha o cadastro: grupo empresarial, empresa (nome, razão social, **CNPJ válido**, cidade/UF), a primeira filial, e o **administrador** (nome, usuário de login e uma senha forte). Logo e fuso horário são opcionais.
   Depois de digitar o token você tem **15 minutos** para concluir o cadastro; se passar, digite o token de novo.
4. Ao confirmar, o sistema cria tudo e mostra a **tela de login**: entre com o **usuário e a senha do administrador que você acabou de cadastrar** → você cai no **Dashboard** (com a mensagem "Conta criada com sucesso!").

A partir daí a tela `/primeiro-acesso/` **fecha para sempre** (passa a responder "Página não encontrada") e o token deixa de valer. Opcional, por higiene: apague o valor do token e reinicie:

```bash
sed -i 's/^INITIAL_SETUP_TOKEN=.*/INITIAL_SETUP_TOKEN=/' /etc/nexbuy/nexbuy.env && systemctl restart nexbuy
```

(Se um dia o banco precisar ser zerado com `deploy/zerar_banco.sh`, o script gera um token novo quando encontra a linha vazia.)

Próximo passo dentro do sistema: o **Checklist de Implantação** (menu **Configurações › Checklist de Implantação**, endereço `https://seudominio.com.br/ncc/checklist/`), seguindo o roteiro [`PRIMEIROS_PASSOS_ADMINISTRADOR.md`](PRIMEIROS_PASSOS_ADMINISTRADOR.md): dados da empresa, filiais, usuários, configuração financeira, receitas, custos, limites dos compradores e fluxo de aprovação. Cada item pendente do Checklist tem um botão que abre a tela certa.

> ⚠️ **Não use o "Assistente de Implantação"** (`/ncc/implantacao/`) para esta farmácia. O passo 1 dele cria sempre um **grupo e uma empresa (CNPJ) novos**, com filial própria — a empresa e o administrador já nasceram no Primeiro Acesso, então seguir o assistente à risca deixaria o sistema com **duas empresas**. Ele só serve para cadastrar um grupo empresarial totalmente novo (outro cliente no mesmo servidor).

> **Treino com dados fictícios antes do uso real?** Pode — no fim, os lançamentos de teste são apagados pelo servidor, mantendo os cadastros (`deploy/limpar_dados_de_teste.sh`; ver [`OPERACAO_BACKUP_E_ATUALIZACAO.md`](OPERACAO_BACKUP_E_ATUALIZACAO.md), seção 8).

✅ **Pronto quando:** você está no Dashboard do NEXBUY com o seu usuário.

---

## Parte G — Criar os usuários da equipe

Logado como o administrador:

1. Menu **Gestão → Usuários e Permissões** → **Novo Usuário** (endereço `/ncc/usuarios/novo/`).
2. Preencha nome, e-mail, **usuário (login)**, **senha inicial**, **perfil** (Proprietário, Gerente, Financeiro ou Comprador) e a **filial** (obrigatória para Gerente, Financeiro e Comprador).
3. Entregue a cada pessoa o endereço **https://seudominio.com.br/accounts/login/**, o usuário e a senha inicial — e peça para trocar a senha no primeiro acesso em **Meu Perfil** (menu do usuário, canto superior direito).

Permissões finas por pessoa: **Gestão → Perfis de Acesso**. O Comprador continua vendo só a visão sintética dele (nunca valores financeiros da empresa).

✅ **Pronto quando:** cada usuário consegue entrar com o próprio login.

---

## Parte H — Superusuário técnico (opcional, só para o suporte)

O **Django Admin** é uma tela técnica, para suporte — **não** é usada no dia a dia da farmácia (quem cria usuários é o administrador da Parte F/G). Se quiser um acesso técnico:

```bash
bash /opt/nexbuy/app/deploy/criar_suporte_tecnico.sh
```

Ele pergunta usuário, e-mail e senha e roda o `createsuperuser` do Django com o ambiente de produção. Sem perguntas (ex.: automação):

```bash
DJANGO_SUPERUSER_USERNAME=suporte DJANGO_SUPERUSER_EMAIL=suporte@suaempresa.com.br \
DJANGO_SUPERUSER_PASSWORD='SenhaForteAqui' bash /opt/nexbuy/app/deploy/criar_suporte_tecnico.sh --noinput
```

⚠️ **Só depois do Primeiro Acesso.** A tela `/primeiro-acesso/` fecha assim que existe **qualquer** usuário ativo no banco. Se o superusuário for criado antes, não será mais possível criar a empresa e o administrador pela tela — por isso o script se recusa a rodar enquanto o Primeiro Acesso não tiver sido feito.

O endereço do Django Admin **não** é `/admin/`: o instalador sorteia um caminho difícil de adivinhar (reduz ataques automáticos). Para ver:

```bash
grep ADMIN_URL /etc/nexbuy/nexbuy.env
```

Ex.: `ADMIN_URL=suporte-3f9a1c2e/` → **https://seudominio.com.br/suporte-3f9a1c2e/**

---

## Parte I — Backup, restauração e atualização (resumo)

Rotina completa em [`docs/OPERACAO_BACKUP_E_ATUALIZACAO.md`](OPERACAO_BACKUP_E_ATUALIZACAO.md).

| Tarefa | Comando (na VPS, como root) |
|---|---|
| Backup agora | `bash /opt/nexbuy/app/deploy/backup.sh` |
| Ver backups | `ls -lh /var/backups/nexbuy/` |
| Restaurar | `bash /opt/nexbuy/app/deploy/restaurar_backup.sh /var/backups/nexbuy/nexbuy_db_AAAA-MM-DD_HHMMSS.sqlite3.gz` |
| Atualizar para a versão nova do GitHub | `bash /opt/nexbuy/app/deploy/atualizar.sh` |
| Sair da fase de teste (apagar os lançamentos fictícios de uma empresa, mantendo os cadastros) | `bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh` |
| Zerar o banco (caso extremo: o Primeiro Acesso recomeça do zero) | `bash /opt/nexbuy/app/deploy/zerar_banco.sh` |

- O backup roda **sozinho todo dia às 03:30** (banco + uploads) e guarda **14 dias**.
- O `atualizar.sh` **sempre faz backup antes** de mexer no banco.
- Uma vez por semana, copie o backup mais recente para fora da VPS (ver o guia de operação).

**Fluxo para publicar uma mudança:** altere o código no Windows → `git add .` → `git commit -m "descrição"` → `git push` → espere o ✓ verde em **Actions** → na VPS, `bash /opt/nexbuy/app/deploy/atualizar.sh`.

---

## Parte J — Solução de problemas

**Onde olhar primeiro**

```bash
systemctl status nexbuy                      # o serviço está rodando?
journalctl -u nexbuy -n 200 --no-pager       # log da aplicação (erros 500 com o detalhe completo)
journalctl -u nexbuy -f                      # log ao vivo (Ctrl+C para sair)
tail -n 100 /var/log/nginx/nexbuy.error.log  # erros do nginx
tail -n 100 /var/log/nginx/nexbuy.access.log # cada acesso (IP, página, código)
journalctl -t nexbuy-backup -n 50            # resultado dos backups diários
tail -n 100 /var/log/letsencrypt/letsencrypt.log   # certificado
curl -s https://seudominio.com.br/healthz/   # saúde (esperado: {"status": "ok"})
```

| Sintoma | Causa provável | Como resolver |
|---|---|---|
| **502 Bad Gateway** | O gunicorn (serviço `nexbuy`) não está rodando ou não sobe. | `systemctl status nexbuy` e `journalctl -u nexbuy -n 100 --no-pager`. Causas comuns: linha errada em `/etc/nexbuy/nexbuy.env` (ex.: SECRET_KEY apagada — o sistema se recusa a subir), dependência faltando depois de uma atualização (`/opt/nexbuy/venv/bin/pip install -r /opt/nexbuy/app/requirements.txt`). Corrija e `systemctl restart nexbuy`. |
| **Página sem estilo / estáticos 404** | `collectstatic` não rodou ou o nginx não consegue ler a pasta. | `nexbuy-manage collectstatic --noinput`; confira `ls /var/lib/nexbuy/staticfiles/css/`; `id www-data` precisa listar o grupo `nexbuy` (se não: `usermod -aG nexbuy www-data && systemctl restart nginx`). |
| **certbot falha** ("Timeout during connect", "unauthorized", "NXDOMAIN") | DNS ainda não aponta para a VPS; registro **AAAA** apontando para outro lugar; porta 80 bloqueada no firewall da Hostinger; limite de tentativas do Let's Encrypt. | `nslookup seudominio.com.br 8.8.8.8` precisa mostrar o IP da VPS; apague AAAA errado; libere 80/443 no hPanel. Depois **rode o instalador de novo** (ou `certbot --nginx -d seudominio.com.br -d www.seudominio.com.br --redirect`). Muitas falhas seguidas bloqueiam por 1 hora — espere. |
| **"Requisição inválida" (erro 400)** e no log `DisallowedHost` / `Invalid HTTP_HOST header` | O endereço usado não está em `ALLOWED_HOSTS`. | Edite `ALLOWED_HOSTS` em `/etc/nexbuy/nexbuy.env` (domínios separados por vírgula, sem `https://`) e `systemctl restart nexbuy`. Acesso pelo IP puro é recusado de propósito — use o domínio. |
| **"Sua sessão expirou"** em todo formulário (falha de **CSRF**); no log `Forbidden (Origin checking failed ...)` ou `CSRF cookie not set` | Site aberto por um endereço que não está em `ALLOWED_HOSTS`/`CSRF_TRUSTED_ORIGINS`, ou por `http://`, ou `USA_PROXY_HTTPS` diferente de `True`. | Use sempre `https://seudominio.com.br`. Confira `ALLOWED_HOSTS` e `USA_PROXY_HTTPS=True` no `nexbuy.env`. Se o acesso for por outro domínio, inclua-o em `ALLOWED_HOSTS` (o CSRF é liberado automaticamente para os mesmos domínios). Uma vez só (página aberta há muito tempo): basta clicar em **Recarregar a página**. |
| **Redirecionamento infinito** (ERR_TOO_MANY_REDIRECTS) | `USA_PROXY_HTTPS=False` atrás do nginx, ou um proxy da Cloudflare no modo "Flexible". | `USA_PROXY_HTTPS=True` no `nexbuy.env` + `systemctl restart nexbuy`. Na Cloudflare, use "Full (strict)". |
| **Erro 429 no login** | Proteção contra força bruta: mais de 10 tentativas de login por minuto do mesmo IP. | Esperar 1 minuto. |
| **`/primeiro-acesso/` mostra "Página não encontrada"** | O Primeiro Acesso já foi feito, já existe um usuário no banco, ou o token está vazio. | Entre pelo `/accounts/login/`. Se ainda não houve Primeiro Acesso, confira `grep INITIAL_SETUP_TOKEN /etc/nexbuy/nexbuy.env`. |
| **Lançamentos de teste para apagar**, **empresa criada errada no Primeiro Acesso** ou **dados de demonstração gravados por engano** | O Primeiro Acesso só pode ser feito uma vez, e compras/provisões não são apagadas pela tela. | Só lançamentos de teste: `bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh` (mantém os cadastros). CNPJ digitado errado: a tela da empresa não edita o CNPJ, mas o suporte corrige pelo Django Admin (Parte H). Para recomeçar tudo do zero: `bash /opt/nexbuy/app/deploy/zerar_banco.sh` (backup antes; o Primeiro Acesso volta a abrir com o mesmo token). Detalhes na seção 8 do guia de operação. |
| **"Algo deu errado" (erro 500)** | Erro inesperado no código. | O detalhe completo (traceback) fica em `journalctl -u nexbuy -n 200 --no-pager` — copie e envie ao desenvolvimento. |
| **`database is locked`** no log | Uma operação muito longa segurou a escrita no banco. | Raro com o modo WAL. Se repetir, `systemctl restart nexbuy` e reporte ao desenvolvimento. |
| **Disco cheio** | Backups/logs acumulados. | `df -h` e `du -sh /var/backups/nexbuy /var/log`. A retenção de backup é 14 dias; `journalctl --vacuum-time=30d` limpa logs antigos. |

**Depois de reiniciar a VPS**, nginx, NEXBUY, cron e a renovação do certificado sobem sozinhos (serviços habilitados). Confira com `systemctl status nexbuy nginx`.

---

## Referência rápida

```bash
systemctl restart nexbuy           # reiniciar o NEXBUY (depois de editar o nexbuy.env)
systemctl reload nginx             # recarregar o nginx (depois de editar o site)
nano /etc/nexbuy/nexbuy.env        # variáveis de produção (explicadas em deploy/env.producao.exemplo)
nexbuy-manage showmigrations       # qualquer comando do manage.py, com o ambiente de produção
nexbuy-manage changepassword USUARIO   # redefinir a senha de alguém que esqueceu
certbot certificates               # validade do certificado
ufw status                         # firewall
```

Aumentar a proteção HTTPS depois de 1 a 2 semanas estável: em `/etc/nexbuy/nexbuy.env`, troque `SECURE_HSTS_SECONDS=3600` por `SECURE_HSTS_SECONDS=31536000` e `systemctl restart nexbuy`.

**PostgreSQL (opção futura):** a produção usa SQLite (arquivo único, backup simples, o mesmo banco coberto pelos testes). Se um dia o volume exigir, o sistema já aceita PostgreSQL por variável (`DB_ENGINE=postgresql` + `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`) — a migração dos dados é um projeto à parte, e o `backup.sh` precisaria passar a usar `pg_dump`.
