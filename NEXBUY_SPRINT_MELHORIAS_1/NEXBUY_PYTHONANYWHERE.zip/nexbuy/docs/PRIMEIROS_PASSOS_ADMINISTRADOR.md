# NEXBUY — Primeiros passos do administrador

Roteiro para colocar a empresa em funcionamento no NEXBUY, **na ordem certa**, a
partir do sistema recém-instalado e **vazio**. Cada passo depende do anterior: sem
filial não há usuário; sem receita e custos não há limite de compra.

- **Para quem:** o administrador da empresa (perfil **Proprietário**). O Financeiro
  pode fazer os cadastros de apoio e os passos financeiros (5 a 12).
- **Tempo estimado:** 1 a 2 horas, com os números em mãos.
- **O mesmo roteiro, com atalhos clicáveis,** está dentro do sistema: ícone **?** no
  topo › **Manual do sistema** (`/ajuda/`) › "Primeiros passos da implantação".
- **O sistema confere sozinho:** o **Checklist de Implantação** (`/ncc/checklist/`)
  marca cada item assim que o cadastro existe de verdade no banco.

> O banco de produção nasce **sem nenhum dado**: nenhuma compra, provisão, receita
> ou custo. Telas vazias mostram um aviso com o próximo passo — é o esperado.

## Antes de começar: o que ter em mãos

- CNPJ, Inscrição Estadual (ou isenção), endereço completo, telefone e responsável
  de **cada filial**.
- A lista da equipe: nome, e-mail, perfil (Proprietário, Gerente, Financeiro ou
  Comprador) e filial de cada pessoa.
- Os principais **fornecedores** e as **categorias** de compra (ex.: Medicamentos,
  Perfumaria, Higiene).
- A **receita esperada do mês** de cada filial e as receitas extras (serviços
  farmacêuticos, convênios/PBM, rendimentos).
- Os **custos fixos** mensais (valor e dia de vencimento) e os **custos variáveis**
  previstos no mês.
- As decisões de regra: que **percentual** do que sobra vai para compras, o que
  fazer quando uma compra passa do limite do dia e **quem aprova**.

## Sumário

0. O sistema no ar (quem instala)
1. Primeiro Acesso: criar o administrador
2. Dados da empresa e identidade visual
3. Filiais
4. Usuários e perfis de acesso
5. Cadastros de apoio: fornecedores, categorias e centros de custo
6. Configuração financeira
7. Receita mensal
8. Receitas extras
9. Custos fixos
10. Custos variáveis
11. Calendário operacional
12. Limites dos compradores
13. Fluxo de aprovação
14. Conferir o Checklist de Implantação
15. Checklist para imprimir
16. Da fase de teste para o uso real

---

## 0. O sistema no ar (quem instala)

Quem instala segue [DEPLOY_HOSTINGER_GITHUB.md](DEPLOY_HOSTINGER_GITHUB.md). No
fim, o instalador mostra o **token de configuração** (`INITIAL_SETUP_TOKEN`), que
fica guardado no servidor, em `/etc/nexbuy/nexbuy.env`. Para vê-lo de novo, na VPS:

```bash
grep INITIAL_SETUP_TOKEN /etc/nexbuy/nexbuy.env
```

O token é um segredo: entregue pessoalmente ao administrador, nunca por WhatsApp ou
e-mail. Quem tiver o token pode criar o administrador enquanto o sistema estiver
vazio.

## 1. Primeiro Acesso: criar o administrador

1. Abra `https://SEU-DOMINIO/primeiro-acesso/` (sem nada depois da barra — o token
   **nunca** vai na URL).
2. Digite o **token de configuração** e confirme. A partir daí você tem
   **15 minutos** para concluir o cadastro (se passar, digite o token de novo).
3. Preencha:
   - **Você** (o administrador): nome, sobrenome, **usuário (login)** e uma **senha
     forte**;
   - **Sua empresa:** nome do grupo/negócio, nome fantasia, razão social, **CNPJ**,
     cidade e estado;
   - **Primeira filial/Matriz:** o nome da loja principal;
   - **Identidade visual** (opcional) e **fuso horário**.
4. Marque a confirmação e conclua. Entre em `https://SEU-DOMINIO/accounts/login/`
   com o usuário e a senha que acabou de criar.

A tela de Primeiro Acesso **se fecha para sempre** depois disso. O administrador é
quem cria todos os outros usuários. Guarde o login dele no cofre de senhas da
empresa.

> **Recomendado:** cadastre, no passo 4, um **segundo usuário Proprietário** de
> reserva. Se o administrador esquecer a senha, o outro Proprietário gera uma senha
> provisória para ele; sem isso, só o suporte técnico redefine pelo servidor.

## 2. Dados da empresa e identidade visual

- **Dados da empresa** (`/empresas/`): confira nome, razão social, CNPJ e endereço.
  O CNPJ não é editado nessa tela — se estiver errado, fale com o suporte técnico.
  Também abre pelo Checklist (item 1) e por **Configurações › Centro de
  Configurações › Sistema**.
- **Identidade visual** (`/empresas/identidade-visual/`): logo, favicon e **cor
  secundária**. O logo aparece no topo das telas e no cabeçalho dos relatórios
  impressos.
- **Cor principal** (botões, menu e links): fica na **Capacidade Financeira**
  (`/financeiro/configuracao/`, campo "Cor principal da empresa"). O padrão é o
  azul NEXBUY; evite vermelho, que nas telas significa alerta ou prejuízo.

## 3. Filiais

Menu **Gestão › Empresas e Filiais** › botão **Gerenciar** (`/ncc/filiais/`).

1. Abra a **Matriz** e complete o cadastro fiscal: CNPJ, Inscrição Estadual (ou
   marque isenta), endereço completo, razão social, telefone e responsável.
2. Cadastre as demais filiais em **Nova Filial**.

Cada filial tem **a sua própria receita, os seus custos e o seu limite de compra**.

## 4. Usuários e perfis de acesso

Menu **Gestão › Usuários e Permissões** › **Novo Usuário** (`/ncc/usuarios/novo/`).

1. Preencha nome, e-mail, **usuário (login)**, **senha inicial**, **perfil** e
   **filial** (obrigatória para Gerente, Financeiro e Comprador).
2. Depois de salvar, a ficha do usuário abre com as permissões: filiais autorizadas
   (para quem trabalha em mais de uma loja), perfis de acesso e limite individual.
3. Entregue a cada pessoa o endereço `https://SEU-DOMINIO/accounts/login/`, o login e
   a senha inicial, e peça para **trocar a senha em Meu Perfil** no primeiro acesso.

| Perfil | Para quem | O que faz |
|---|---|---|
| Proprietário | Dono(a) e administrador(a) | Vê tudo, cria usuários e filiais, configura, decide aprovações, lança compras e provisões |
| Financeiro | Quem cuida do dinheiro | Receitas, custos, capacidade de compra, limites dos compradores, Agenda e Análise Financeira |
| Gerente | Gerente de loja | Decide compras e provisões acima do limite; indicadores e Análise Financeira |
| Comprador | Quem faz os pedidos | Lança compras, planeja provisões e acompanha o limite do dia; nunca vê os números financeiros da empresa |

**Acesso a mais para alguém?** Em **Gestão › Perfis de Acesso** (`/ncc/perfis/`) ou
nas permissões individuais da ficha do usuário. Permissões extras só **somam**
acessos, nunca tiram.

**Esqueceram a senha?** Na ficha do usuário, **Gerar nova senha provisória**. A senha
aparece uma única vez, na sua tela; passe para a pessoa, que troca em Meu Perfil.
O NEXBUY não envia senha por e-mail.

## 5. Cadastros de apoio: fornecedores, categorias e centros de custo

Toda compra e toda provisão exigem um **fornecedor** e uma **categoria**; o centro de
custo é opcional. Cadastre ao menos os principais antes de liberar os compradores.

Os três ficam no menu — Proprietário: **Compras › Fornecedores**, **Compras ›
Categorias** e **Compras › Centros de Custo**; Financeiro: **Planejamento ›
Fornecedores**, **Planejamento › Categorias** e **Planejamento › Centros de Custo**.

- **Fornecedores:** `/compras/fornecedores/` › **+ Novo Fornecedor**.
- **Categorias:** `/cadastros/categorias/` › **+ Nova Categoria**.
- **Centros de custo:** `/cadastros/centros-custo/` › **+ Novo Centro de Custo**.

## 6. Configuração financeira

Proprietário: **Financeiro › Capacidade Financeira**. Financeiro: **Planejamento ›
Capacidade Financeira** (`/financeiro/configuracao/`).

| Campo | O que faz |
|---|---|
| Percentual destinado às compras (%) | A fatia da disponibilidade financeira (receita menos custos) que pode virar compra no mês |
| Percentual de segurança (%) | Reserva que reduz a capacidade do mês antes de dividir pelos dias úteis |
| Dias úteis considerados (manual) | Em branco = o sistema conta sozinho, respeitando o Calendário Operacional |
| Permitir saldo acumulativo | O que sobrou nos dias anteriores do mês soma ao limite de hoje |
| Limite máximo acumulado | Teto para essa sobra (em branco = sem teto) |
| Redistribuição automática + Permitir ultrapassar o limite diário | O que passou do limite num dia é descontado dos dias seguintes (precisa das duas opções ligadas) |
| Forma de bloqueio ao ultrapassar o limite diário | **Bloquear compra**, **Solicitar Aprovação** ou **Permitir compra com alerta** |

**Salve o formulário ao menos uma vez**, mesmo mantendo os valores sugeridos: é isso
que conclui o item 4 do Checklist.

## 7. Receita mensal

Proprietário: **Financeiro › Planejamento Financeiro › Receitas**. Financeiro:
**Planejamento › Receitas** (`/financeiro/receitas/` › **+ Nova Receita**).

- Uma receita (faturamento) **por filial, por mês**: escolha a filial, o mês de
  referência e o valor.
- Ela **não se repete sozinha**: todo mês começa sem receita, e o limite do dia fica
  "—" até alguém lançar. Dica: lance a receita esperada no começo do mês e corrija
  quando o mês fechar.

## 8. Receitas extras

Na tela de **Receitas**, botão **Gerenciar receitas extras** ou **+ Nova receita extra** (`/financeiro/receitas/extras/`).

Entradas além do faturamento: **serviços farmacêuticos**, **convênios/PBM**,
**rendimentos financeiros** e **outras receitas**. Cada lançamento tem data,
descrição, categoria e valor; pode haver vários no mês. Elas **somam à receita do
mês** e aumentam o limite de compra.

## 9. Custos fixos

Proprietário: **Financeiro › Planejamento Financeiro › Custos Fixos**. Financeiro:
**Planejamento › Custos Fixos** (`/financeiro/custos-fixos/`) — contas que se repetem todo mês: folha de pagamento,
aluguel, energia, internet, contador, impostos fixos. Informe descrição, fornecedor
(opcional), valor mensal e dia do vencimento. **Enquanto ativo, conta em todos os
meses** e aparece na Agenda no vencimento; quando a conta deixar de existir,
desative.

## 10. Custos variáveis

Proprietário: **Financeiro › Planejamento Financeiro › Custos Variáveis**. Financeiro:
**Planejamento › Custos Variáveis** (`/financeiro/custos-variaveis/`) — despesas pontuais com **data prevista** (uma
manutenção, uma campanha, uma taxa avulsa). Contam só no mês daquela data.

## 11. Calendário operacional

Proprietário: **Financeiro › Planejamento Financeiro › Calendário Operacional**.
Financeiro: **Planejamento › Calendário Operacional**
(`/financeiro/calendario-operacional/`) — por padrão, segunda a sexta são dias úteis:
a capacidade do mês é dividida só por eles, e **sábado e domingo não têm limite de
compra próprio**. Cadastre **feriados**, **dias bloqueados** (sem compra) e **dias
especiais** (que contam limite, como um sábado de campanha — o dia ganha limite e
entra na divisão do mês). Se a farmácia compra aos sábados, marque os sábados do mês
como **Especial**. Se a empresa não tiver nenhuma exceção, use o botão **Confirmar
calendário revisado** na própria tela.

## 12. Limites dos compradores

Proprietário: **Financeiro › Compradores e Limites**. Financeiro: **Compradores e
Limites**, direto no menu (`/financeiro/capacidade-compradores/`).

- Cada comprador compra pela filial do cadastro dele (outras filiais: "Filiais
  autorizadas", na ficha do usuário).
- Defina, se quiser, um **limite individual por dia** para cada comprador — sem ele,
  vale o limite da filial. Quem passa do próprio limite gera um pedido de aprovação.
- **Bloquear/Liberar:** um comprador bloqueado tem as compras barradas na hora. Tudo
  fica na auditoria e o comprador é avisado.

## 13. Fluxo de aprovação

1. **Compras:** a regra do passo 6 (**Forma de bloqueio**) decide o que acontece
   quando a compra passa do limite do dia. Com "Solicitar Aprovação", decidem o
   Gerente e o Proprietário.
2. **Provisões:** em **Configurações › Centro de Configurações › Workflow de
   Aprovações** (`/ncc/workflow/`), crie um fluxo com as etapas em ordem: o perfil
   que decide, um aprovador específico e um substituto (opcionais), a **alçada**
   (até que valor a decisão da etapa é final — acima, sobe para a próxima) e o prazo
   em dias. Só um fluxo fica ativo por vez. Sem fluxo, a decisão é em uma etapa, por
   Proprietário, Gerente ou Financeiro. **Marque "Fluxo ativo"** ao salvar: um fluxo
   salvo como inativo é ignorado, e a tela avisa quando isso acontece.
3. **Efetivar a provisão aprovada:** quando o pedido é fechado, a provisão aprovada
   (ou a que coube no saldo do dia) vira Compra. O Proprietário e o Gerente acham as
   que aguardam efetivação em **Aprovações**, no bloco **"Aprovadas aguardando
   efetivação"**; o Financeiro, em **Início › Solicitações**. O botão **Efetivar** pede
   o prazo de pagamento e cria a compra com as parcelas.
4. **Separação de funções:** quem criou a compra ou a provisão não aprova o próprio
   pedido. A exceção ("autoaprovação controlada", com justificativa) só existe se for
   ligada em **Configurações › Centro de Configurações › Sistema**.

## 14. Conferir o Checklist de Implantação

Menu **Configurações › Checklist de Implantação** (`/ncc/checklist/`). São 13 itens;
os pendentes mostram um botão que leva direto à tela.

Os itens 11, 12 e 13 pedem uma primeira compra, uma primeira provisão e uma primeira
visita ao relatório **Compras por Filial**. **Atenção:** compras e provisões
gravadas contam como reais, entram nos relatórios e **não podem ser editadas nem
apagadas pela tela**. Para só experimentar, use o **Simulador**
(`/compras/simulacao/`), que não grava nada. Se a equipe for treinar com lançamentos
fictícios, veja antes a seção 16.

> ⚠️ **Não use o Assistente de Implantação** (`/ncc/implantacao/`) para a empresa
> criada no Primeiro Acesso. O passo 1 dele cria sempre um **grupo e uma empresa
> (CNPJ) novos**, com filial própria — seguido à risca, o sistema ficaria com **duas
> empresas**. O caminho para a sua empresa é este roteiro + o Checklist de
> Implantação. O assistente só serve para cadastrar um grupo empresarial totalmente
> novo.

## 15. Checklist para imprimir

- [ ] 1. Primeiro Acesso feito; login do administrador guardado no cofre de senhas
- [ ] 2. Dados da empresa conferidos; logo e cor na identidade visual
- [ ] 3. Matriz com cadastro fiscal completo; demais filiais cadastradas
- [ ] 4. Equipe cadastrada (cada um com perfil e filial); senhas iniciais entregues; Proprietário reserva criado
- [ ] 5. Fornecedores e categorias principais cadastrados (centros de custo, se usar)
- [ ] 6. Capacidade Financeira salva (percentual de compras e forma de bloqueio decididos)
- [ ] 7. Receita mensal do mês lançada para **cada** filial
- [ ] 8. Receitas extras do mês lançadas
- [ ] 9. Custos fixos cadastrados, com dia de vencimento
- [ ] 10. Custos variáveis previstos do mês lançados
- [ ] 11. Calendário operacional revisado (feriados e bloqueios, ou revisão confirmada)
- [ ] 12. Compradores com filial; limites individuais definidos (se usar)
- [ ] 13. Workflow de aprovação das provisões configurado (ou decisão em etapa única)
- [ ] 14. Checklist de Implantação conferido no sistema
- [ ] 15. Equipe orientada a usar a Central de Ajuda (ícone ? › Manual do sistema)
- [ ] 16. Se houve treino com dados fictícios: limpeza feita pelo servidor antes do primeiro lançamento real

**Rotina mensal (todo começo de mês):** lançar a receita mensal de cada filial,
conferir os custos fixos ativos e lançar os custos variáveis previstos.

## 16. Da fase de teste para o uso real

A equipe pode treinar no próprio sistema com uma "análise fictícia" — compras,
provisões, receitas e custos inventados — antes de começar a usar de verdade. Só
combine o fim do teste com antecedência:

- **Durante o teste:** use valores claramente fictícios e não misture nenhum
  lançamento real. Compras e provisões gravadas não são apagadas pela tela; quem
  apaga é o servidor, e ele apaga **todas** as movimentações da empresa de uma vez.
- **Quando limpar:** uma vez só, no dia em que o uso real começa — depois do último
  treino e **antes** do primeiro lançamento de verdade (o ideal é no começo do mês,
  junto com a receita real do mês).
- **Como:** peça a quem cuida do servidor para rodar
  `sudo bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh` com o CNPJ da empresa
  (passo a passo em [OPERACAO_BACKUP_E_ATUALIZACAO.md](OPERACAO_BACKUP_E_ATUALIZACAO.md),
  seção 8). Ele primeiro mostra quantos registros seriam apagados, pede o CNPJ de
  novo e faz backup antes de apagar. Leva menos de 1 minuto; ninguém lança nada
  nesse intervalo.
- **O que sai:** compras, parcelas, provisões e itens, solicitações de aprovação,
  históricos de compra e de provisão e notificações. Se a receita e os custos do
  treino também eram inventados, peça a opção **com planejamento**: saem também as
  receitas mensais, receitas extras, custos fixos, custos variáveis e os dias do
  calendário operacional.
- **O que fica:** empresa, filiais, usuários (com os limites e bloqueios dos
  compradores), perfis de acesso, fornecedores, categorias, centros de custo,
  configuração financeira, configurações do sistema, fluxo de aprovação, identidade
  visual e a Central de Auditoria — que nunca é apagada e passa a mostrar a limpeza
  (quem, quando e quantos registros).
- **Depois:** abra o **Checklist de Implantação** (`/ncc/checklist/`). A primeira
  compra e a primeira provisão voltam a ficar pendentes (com a opção de
  planejamento, também a receita e, se não houver revisão confirmada, o calendário).
  Lance a receita e os custos reais do mês e avise a equipe de que agora é para
  valer.
- **Caso extremo:** se nada puder ser aproveitado (por exemplo, dados de
  demonstração gravados por engano), o servidor pode ser **zerado**
  (`deploy/zerar_banco.sh`): o sistema volta a ficar vazio e o Primeiro Acesso
  recomeça do zero — aí é preciso recadastrar tudo, inclusive os usuários.

Dúvidas de uso: [MANUAL_DO_USUARIO.md](MANUAL_DO_USUARIO.md). Servidor, backup e
atualização: [OPERACAO_BACKUP_E_ATUALIZACAO.md](OPERACAO_BACKUP_E_ATUALIZACAO.md).
