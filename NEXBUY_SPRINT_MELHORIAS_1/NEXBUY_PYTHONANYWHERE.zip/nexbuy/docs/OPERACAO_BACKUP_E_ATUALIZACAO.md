# NEXBUY — operação do dia a dia (backup, restauração, atualização)

Rotina para quem cuida do servidor depois que o NEXBUY está no ar. Todos os comandos são na VPS, como **root** (`ssh root@IP-DA-VPS`). A instalação inicial está em [`DEPLOY_HOSTINGER_GITHUB.md`](DEPLOY_HOSTINGER_GITHUB.md).

---

## 1. Rotina

| Quando | O quê | Como |
|---|---|---|
| **Todo dia** (automático, 03:30) | Backup do banco + uploads, guarda 14 dias | nada a fazer — o cron chama `deploy/backup.sh` |
| **Toda segunda-feira** (5 min) | Conferir saúde, último backup e espaço em disco | bloco "Conferência semanal" abaixo |
| **Toda semana** | Copiar o backup mais recente para FORA da VPS | seção 3 |
| **A cada versão nova** | Atualizar o sistema | seção 5 (`deploy/atualizar.sh`) |
| **Todo mês** | Atualizações de segurança do Ubuntu | `apt-get update && apt-get -y upgrade` (o Ubuntu já instala as críticas sozinho) |
| **A cada 3 meses** | Ensaiar uma restauração (sem mexer na produção) | seção 4.3 |
| **Uma vez, no início do uso real** | Apagar os lançamentos fictícios da fase de teste | seção 8 (`deploy/limpar_dados_de_teste.sh`) |

**Aviso automático de queda (recomendado, grátis, 5 minutos para configurar)**

O NEXBUY não manda e-mail sozinho quando sai do ar ou quando dá erro. Configure um monitor externo gratuito (por exemplo, o **UptimeRobot**, plano Free) para ser avisado por e-mail — ou pelo app no celular — em poucos minutos:

1. Crie a conta no site do monitor e clique em **Add New Monitor**.
2. Tipo **HTTP(s) — Keyword**, URL `https://seudominio.com.br/healthz/`, palavra-chave `ok`, intervalo de 5 minutos.
3. Em **Alert Contacts**, marque o e-mail de quem cuida do servidor (e, se quiser, o de um sócio).
4. Salve e confira que o monitor fica **Up** (verde).

O `/healthz/` só responde `ok` quando o Django e o banco estão de pé — se o gunicorn cair, o banco travar ou o disco encher, o monitor avisa. Erros 500 isolados (uma tela quebrada) **não** derrubam o `/healthz/`: eles aparecem no `journalctl -u nexbuy` e na conferência semanal abaixo (linhas com `ERROR`). Para saber de backup que falhou, a mesma conferência lê `journalctl -t nexbuy-backup`.

**Conferência semanal**

```bash
curl -s https://seudominio.com.br/healthz/          # esperado: {"status": "ok"}
systemctl is-active nexbuy nginx                     # esperado: active / active
cat /var/backups/nexbuy/ULTIMO_BACKUP_OK             # data/hora do último backup bem-sucedido
ls -lht /var/backups/nexbuy/ | head -n 6             # backups mais recentes
journalctl -t nexbuy-backup --since "7 days ago" | grep -i erro   # nenhuma linha = tudo certo
journalctl -u nexbuy --since "7 days ago" | grep -E " ERROR |Traceback" | tail -n 20   # erros (500) da semana
df -h /                                              # espaço livre em disco (manter acima de 20%)
certbot certificates | grep -i expiry                # validade do certificado (renova sozinho)
```

---

## 2. Backup

O que é copiado:

- **Banco** (`/var/lib/nexbuy/db.sqlite3`) — pela API de backup online do SQLite (`.backup`), segura com o sistema **rodando** e com usuários usando. A cópia é conferida com `PRAGMA integrity_check` antes de ser guardada. **Nunca** copie o arquivo `.sqlite3` com `cp` com o sistema no ar: no modo WAL, parte dos dados ainda pode estar no arquivo `-wal` ao lado.
- **Uploads** (`/var/lib/nexbuy/media/`: logo, favicon, fotos) — em `.tar.gz`.

Onde fica: `/var/backups/nexbuy/` (só o root lê), arquivos `nexbuy_db_AAAA-MM-DD_HHMMSS.sqlite3.gz` e `nexbuy_media_AAAA-MM-DD_HHMMSS.tar.gz`. Arquivos com mais de **14 dias** são apagados automaticamente (só os do NEXBUY).

Backup manual (antes de qualquer intervenção):

```bash
bash /opt/nexbuy/app/deploy/backup.sh
```

Guardar por mais tempo, só nesta execução: `RETENCAO_DIAS=30 bash /opt/nexbuy/app/deploy/backup.sh`.

Log dos backups automáticos: `journalctl -t nexbuy-backup -n 50`.

> O `/etc/nexbuy/nexbuy.env` (segredos) **não** entra no backup diário de propósito. Guarde uma cópia dele no cofre de senhas da empresa: sem a mesma `SECRET_KEY`, uma restauração em outro servidor desloga todo mundo (os dados continuam intactos).

---

## 3. Cópia para fora da VPS (semanal)

Um backup que só existe dentro da VPS se perde junto com ela. No **PowerShell do Windows** (não na VPS):

```powershell
mkdir C:\Backups\NEXBUY -Force
scp "root@IP-DA-VPS:/var/backups/nexbuy/nexbuy_*" C:\Backups\NEXBUY\
```

Guarde essa pasta num lugar com cópia (OneDrive/Google Drive da empresa, HD externo). Os arquivos contêm dados financeiros da empresa: trate como confidenciais.

Camada extra: no hPanel da Hostinger, **VPS → Snapshots/Backups** — crie um snapshot antes de atualizações grandes.

---

## 4. Restauração

### 4.1 Restaurar um backup (volta o sistema inteiro para aquele momento)

```bash
ls -lh /var/backups/nexbuy/
bash /opt/nexbuy/app/deploy/restaurar_backup.sh \
     /var/backups/nexbuy/nexbuy_db_2026-09-26_033000.sqlite3.gz \
     /var/backups/nexbuy/nexbuy_media_2026-09-26_033000.tar.gz
```

(O segundo arquivo, da mídia, é opcional.) O script:

1. confere se o backup está íntegro;
2. faz um **backup de segurança do estado atual** (dá para desfazer a restauração);
3. para o serviço; troca o banco (e a mídia) — os atuais ficam ao lado com o sufixo `.antes-da-restauracao-DATA`;
4. apaga os arquivos `-wal`/`-shm` antigos (se ficassem, seriam reaplicados sobre o banco restaurado);
5. aplica migrações pendentes (se o backup for de uma versão anterior do sistema);
6. sobe o serviço e confere o `/healthz/`.

Ele pede para digitar `RESTAURAR`. **Tudo o que foi lançado depois do horário do backup deixa de aparecer** — avise os usuários antes.

### 4.2 Restauração manual (se o script não puder ser usado)

```bash
systemctl stop nexbuy
mv /var/lib/nexbuy/db.sqlite3 /var/lib/nexbuy/db.sqlite3.antes-da-restauracao
rm -f /var/lib/nexbuy/db.sqlite3-wal /var/lib/nexbuy/db.sqlite3-shm
gzip -dc /var/backups/nexbuy/nexbuy_db_AAAA-MM-DD_HHMMSS.sqlite3.gz > /var/lib/nexbuy/db.sqlite3
sqlite3 /var/lib/nexbuy/db.sqlite3 "PRAGMA integrity_check;"      # precisa responder: ok
chown nexbuy:nexbuy /var/lib/nexbuy/db.sqlite3 && chmod 600 /var/lib/nexbuy/db.sqlite3
nexbuy-manage migrate --noinput
systemctl start nexbuy
curl -s https://seudominio.com.br/healthz/
```

Mídia: `mv /var/lib/nexbuy/media /var/lib/nexbuy/media.antigo && tar -C /var/lib/nexbuy -xzf /var/backups/nexbuy/nexbuy_media_...tar.gz && chown -R nexbuy:nexbuy /var/lib/nexbuy/media`.

### 4.3 Ensaio de restauração (sem tocar na produção)

Confere que os backups realmente abrem:

```bash
gzip -dc "$(ls -t /var/backups/nexbuy/nexbuy_db_*.gz | head -n 1)" > /tmp/ensaio.sqlite3
sqlite3 /tmp/ensaio.sqlite3 "PRAGMA integrity_check;"
sqlite3 /tmp/ensaio.sqlite3 "SELECT COUNT(*) FROM usuarios_usuario;"
rm -f /tmp/ensaio.sqlite3
```

### 4.4 Servidor novo (a VPS foi perdida)

1. Nova VPS Ubuntu 24.04 + DNS para o novo IP (guia de deploy, Partes B a D).
2. Clone o repositório em `/opt/nexbuy/app` (Parte E).
3. **Antes** do instalador, recoloque o `nexbuy.env` guardado no cofre: `mkdir -p /etc/nexbuy && nano /etc/nexbuy/nexbuy.env` (cole o conteúdo).
4. Rode o instalador (ele mantém o `nexbuy.env` existente e cria um banco vazio).
5. Copie os backups do Windows para a VPS: `scp C:\Backups\NEXBUY\nexbuy_db_ULTIMO.sqlite3.gz root@NOVO-IP:/root/` e restaure com o `restaurar_backup.sh` (seção 4.1) apontando para `/root/nexbuy_db_ULTIMO.sqlite3.gz`.

---

## 5. Atualização (versão nova do código)

**No Windows**, depois de alterar o código:

```powershell
cd C:\NEXBUY\nexbuy_producao      # a pasta do projeto no seu computador
git add .
git status          # nunca deve aparecer .env, *.sqlite3, venv/, media/
git commit -m "Descrição curta da mudança"
git push
```

Espere o **✓ verde** na aba **Actions** do GitHub (a suíte de testes). Com ✗ vermelho, **não** atualize a VPS.

**Na VPS:**

```bash
bash /opt/nexbuy/app/deploy/atualizar.sh
```

O `atualizar.sh`, nesta ordem: faz **backup** → baixa o código (`git fetch` + avanço rápido; recusa se alguém editou arquivos à mão no servidor) → instala dependências → aplica **migrações** → `collectstatic` → atualiza o serviço systemd se o modelo mudou → `check --deploy` → reinicia → confere o `/healthz/`. Os usuários ficam 2 a 5 segundos sem resposta durante o reinício — prefira horários de pouco uso.

**Se algo der errado, o script volta sozinho para a versão anterior.** Qualquer falha depois que o código novo chegou ao servidor (dependências, migrações, `collectstatic`, `check --deploy` ou o `/healthz/` depois do reinício) dispara o retorno automático: o código volta ao commit anterior (`git reset --hard`), as dependências e os arquivos estáticos da versão anterior são reinstalados, o modelo do serviço volta e — se o serviço já tinha sido reiniciado — ele é reiniciado de novo na versão anterior e o `/healthz/` é conferido. O script termina com erro e mostra o que fez.

A única coisa que **não** volta sozinha é o banco: se as **migrações** da versão nova chegaram a rodar, o script avisa e mostra o comando para restaurar o backup feito no passo 1 (pede confirmação e reinicia o serviço):

```bash
bash /opt/nexbuy/app/deploy/restaurar_backup.sh "$(ls -t /var/backups/nexbuy/nexbuy_db_*.gz | head -n 1)"
```

Depois de corrigido e enviado ao GitHub (com o ✓ verde): `bash /opt/nexbuy/app/deploy/atualizar.sh`.

**Voltar à mão** (só se o retorno automático também falhar — o script avisa):

```bash
cd /opt/nexbuy/app
git log --oneline -n 5                 # veja o commit anterior
git reset --hard COMMIT_ANTERIOR
/opt/nexbuy/venv/bin/python -m pip install -r requirements.txt
bash deploy/nexbuy-manage.sh collectstatic --noinput
systemctl restart nexbuy
```

---

## 6. Mudar uma configuração

Todas as configurações de produção ficam em `/etc/nexbuy/nexbuy.env` (explicação de cada linha em `/opt/nexbuy/app/deploy/env.producao.exemplo`):

```bash
nano /etc/nexbuy/nexbuy.env
systemctl restart nexbuy
curl -s https://seudominio.com.br/healthz/
```

Exemplos comuns:

- **Novo domínio:** acrescente em `ALLOWED_HOSTS` (separado por vírgula), aponte o DNS e rode o instalador de novo com o domínio novo — ele emite o certificado.
- **HSTS de 1 ano** (após 1–2 semanas estável): `SECURE_HSTS_SECONDS=31536000`.
- **Mais log para investigar um problema:** `LOG_LEVEL=DEBUG` (volte para `INFO` depois).

**Nunca** mude a `SECRET_KEY` sem motivo (todos são deslogados) e **nunca** ligue `DEBUG=True` em produção.

---

## 7. Comandos úteis

```bash
systemctl status nexbuy                  # estado do serviço
systemctl restart nexbuy                 # reiniciar
journalctl -u nexbuy -f                  # log ao vivo
journalctl -u nexbuy --since today       # log de hoje
tail -f /var/log/nginx/nexbuy.access.log # acessos ao vivo
nexbuy-manage showmigrations             # migrações aplicadas
nexbuy-manage changepassword USUARIO     # redefinir senha de um usuário
nexbuy-manage check --deploy             # verificação de segurança
ufw status                               # firewall
certbot renew --dry-run                  # simula a renovação do certificado
```

O `nexbuy-manage` roda qualquer comando do `manage.py` com o ambiente de produção e como o usuário `nexbuy` (dono do banco). Por segurança ele recusa `flush`, `seed_demo` e `seed_dados` — o banco de produção nunca recebe dados fictícios.

---

## 8. Fase de teste → uso real

A equipe pode treinar no próprio sistema de produção com uma "análise fictícia" (compras, provisões, receitas e custos inventados) antes de começar a usar de verdade. Compras e provisões gravadas **não podem ser editadas nem apagadas pela tela** — isso protege o histórico e a auditoria. Por isso a saída da fase de teste é feita aqui, no servidor.

### 8.1 Quando limpar

- **Uma vez só**, no dia em que o uso real começa: depois do último treino e **antes** do primeiro lançamento de verdade (o ideal é no começo do mês, junto com a receita real do mês).
- Combine com a farmácia: durante a limpeza (menos de 1 minuto), ninguém lança nada. O sistema continua no ar.
- Se já houver algum lançamento real misturado com os de teste, **não** limpe: a limpeza apaga **todas** as movimentações da empresa, sem escolher quais.

### 8.2 Como limpar (mantém os cadastros)

```bash
bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh 12.345.678/0001-90
# também apagar receitas, receitas extras, custos fixos, custos variáveis e o calendário:
bash /opt/nexbuy/app/deploy/limpar_dados_de_teste.sh 12.345.678/0001-90 --incluir-planejamento
```

(Troque pelo CNPJ da empresa; sem o CNPJ, o script pergunta.) Nesta ordem, o script:

1. roda uma **simulação** e mostra quantos registros de cada tipo seriam apagados — nada é alterado;
2. pede para **digitar o CNPJ de novo** (se não conferir, cancela) e o seu nome (vai para a auditoria);
3. faz um **backup completo** (`backup.sh` → `/var/backups/nexbuy/`);
4. apaga, numa transação só (qualquer erro desfaz tudo), e antes de apagar o próprio comando ainda grava uma cópia do banco em `/var/lib/nexbuy/nexbuy_antes_da_limpeza_AAAA-MM-DD_HHMMSS.sqlite3`, cujo caminho aparece na tela.

| Apaga (só da empresa do CNPJ informado) | Mantém sempre |
|---|---|
| Compras e parcelas | Empresa e filiais |
| Provisões e itens de provisão | Usuários (com limites e bloqueios dos compradores), perfis de acesso e permissões |
| Solicitações de aprovação | Fornecedores, categorias e centros de custo |
| Históricos de compra e de provisão | Configuração financeira e configuração da plataforma |
| Notificações | Fluxos de aprovação e identidade visual (logo, cor) |
| Com `--incluir-planejamento`: receitas mensais, receitas extras, custos fixos, custos variáveis e dias do calendário operacional | A **Central de Auditoria** (nunca é apagada; a limpeza fica registrada nela, com quem, quando e quantos registros) |

Use `--incluir-planejamento` quando a receita e os custos do teste eram inventados; sem a opção, eles ficam (útil se o treino já usou os números reais).

A mesma coisa sem o script, passo a passo:

```bash
nexbuy-manage limpar_movimentacoes --empresa 12.345.678/0001-90              # simulação
bash /opt/nexbuy/app/deploy/backup.sh
nexbuy-manage limpar_movimentacoes --empresa 12.345.678/0001-90 --confirmar --responsavel "Seu nome"
```

**Depois da limpeza**, no sistema: o **Checklist de Implantação** (`/ncc/checklist/`) volta a mostrar pendentes a primeira compra e a primeira provisão (e, com `--incluir-planejamento`, a receita e o calendário, se não houver revisão confirmada); lance a receita e os custos reais e avise a equipe de que, a partir de agora, tudo é para valer. **Desfazer:** restaure o backup completo feito antes da limpeza (seção 4.1) — o `restaurar_backup.sh` também aceita a cópia `nexbuy_antes_da_limpeza_*.sqlite3`. Essa cópia pode ser apagada depois que o uso real estiver conferido (ela não entra na retenção automática).

### 8.3 Caso extremo: zerar o banco

Quando não dá para aproveitar nada (ex.: dados de demonstração gravados por engano, ou a implantação precisa recomeçar do zero):

```bash
bash /opt/nexbuy/app/deploy/zerar_banco.sh
```

Ele mostra o que existe hoje, pede para digitar `ZERAR`, **para o serviço**, faz o **backup completo**, guarda o banco atual ao lado (`db.sqlite3.antes-de-zerar-DATA`, nunca apagado), cria o banco **vazio** (`migrate`), **religa** e confere o `/healthz/`. Se falhar antes do banco novo ficar pronto, o anterior volta para o lugar e o serviço é religado.

Depois disso o sistema está como no dia da instalação: **todo mundo é desconectado**, não existe empresa nem usuário, e o **Primeiro Acesso** (`https://seudominio.com.br/primeiro-acesso/`) volta a abrir com o **mesmo token** do `/etc/nexbuy/nexbuy.env` (se a linha estiver vazia, o script gera um token novo e mostra na tela). É preciso recadastrar tudo, inclusive os usuários. CNPJ digitado errado no Primeiro Acesso **não** exige zerar: o suporte corrige pelo Django Admin.
