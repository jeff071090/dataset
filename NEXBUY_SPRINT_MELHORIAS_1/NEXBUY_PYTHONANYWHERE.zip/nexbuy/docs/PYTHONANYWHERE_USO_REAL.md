# NEXBUY — passar o site do PythonAnywhere para o USO REAL (passo a passo)

Até aqui, o site `https://<seu-usuario>.pythonanywhere.com` mostrava a
**demonstração**: a farmácia fictícia "Farmácia Vida Plena" e os 6 usuários
`demo_*` (guia `docs/DEPLOY_PYTHONANYWHERE_DEMO.md`). A cliente pediu para
**testar com dados reais**: os compradores vão lançar as compras de verdade e
o financeiro vai lançar as receitas e os custos de verdade.

Este guia faz essa troca **no mesmo site, na mesma conta grátis**. Um comando
só guarda uma cópia da demonstração, deixa o site **vazio** e abre o
**Primeiro Acesso**, em que a **própria proprietária** cadastra a empresa e o
login dela. Daí para a frente quem cadastra lojas, equipe e números é ela.

- Onde aparece `<seu-usuario>`, troque pelo seu usuário do PythonAnywhere,
  sem os sinais `<` `>`. Nos comandos do console use do jeito que está: o
  próprio console troca `$USER` pelo seu usuário.
- Os nomes de botões e abas estão **em inglês, como aparecem no
  PythonAnywhere**.
- Os comandos são colados no **console Bash** (aba **Consoles** → **Bash**),
  **uma linha por vez**, com **Enter** depois de cada uma.

---

## 0. O que muda

| | Antes (demonstração) | Depois (uso real) |
|---|---|---|
| Dados | Farmácia fictícia, com 12 meses de história inventada | Os da farmácia, lançados pela equipe |
| Acessos | 6 usuários `demo_*` com a senha que vocês enviaram | Cada pessoa com o **próprio login**, criado pela proprietária |
| Selo "Modo Demonstração", troca de perfil, tela de apresentação | Existiam | **Não existem mais** |
| Backup | Só quando alguém rodava o script | **Automático, uma vez por dia**, mais o manual |
| DDA | Desligado | **Continua desligado** (`FEATURE_DDA=False`) |
| Endereço do site | `https://<seu-usuario>.pythonanywhere.com` | **O mesmo** |
| Demonstração do computador (Desktop) | Usada nas apresentações | **Continua igual**, com os dados fictícios |

## 1. Antes de começar

- **Avise a cliente:** os **6 acessos de demonstração deixam de existir**
  (`demo_proprietario`, `demo_gerente`, `demo_financeiro`, `demo_comprador`,
  `demo_comprador2`, `demo_comprador3`). O que ela lançou na demonstração
  some do site (fica guardado numa cópia, parte 4). O script mostra um
  número maior de usuários (ex.: 7): é que a farmácia fictícia tem também
  outros usuários fictícios além desses 6 (ex.: `vp_atendente_beatriz`), e
  todos saem.
- **A cliente cadastrou a empresa dela DENTRO da demonstração** (pelo
  **Assistente de Implantação**, por exemplo)? Então o banco mistura a
  farmácia fictícia com essa empresa, e o script **recusa** a troca e
  explica por quê. Se ela só estava testando e vai começar do zero no uso
  real (ela cadastra a empresa de novo no Primeiro Acesso), rode a parte 4
  com a opção que descarta essas empresas junto com a demonstração (tudo
  fica guardado na mesma cópia):
  `bash deploy/pythonanywhere/ativar_uso_real.sh --descartar-empresas-da-demonstracao`.
  **Nunca** coloque o `NEXBUY_USO_REAL=True` no `.env` à mão: os dados
  fictícios ficariam no uso real.
- **Leia com ela a parte 11** (o que fica guardado num servidor grátis nos
  EUA e os limites do plano) e combine que ela está de acordo.
- **Para apresentações** a outras pessoas, use a demonstração do computador
  (Desktop): ela não muda em nada.
- Escolha um horário em que **ninguém esteja usando o site** (a troca leva
  de 2 a 5 minutos).
- Tenha em mãos: o computador com a pasta `nexbuy_producao` e o login da
  conta do PythonAnywhere.

## 2. Gerar o pacote novo no computador

1. Abra a pasta `nexbuy_producao` no **Explorador de Arquivos** do Windows.
2. Clique na **barra de endereço**, apague o que está escrito, digite
   `powershell` e tecle **Enter**.
3. Cole e tecle **Enter**:

```powershell
venv\Scripts\python.exe deploy\pythonanywhere\gerar_pacote.py
```

O zip `NEXBUY_PYTHONANYWHERE.zip` fica na pasta **acima** de
`nexbuy_producao`. O `.env`, os bancos e as pastas de mídia ficam de fora
sozinhos.

## 3. Enviar o pacote e atualizar o código

1. No PythonAnywhere, aba **Files** → botão **Upload a file** → escolha o
   `NEXBUY_PYTHONANYWHERE.zip` (substitua o antigo, se perguntar).
2. Aba **Consoles** → **Bash**. Cole uma linha por vez:

```bash
cd ~
rm -rf ~/nexbuy_antigo
mv nexbuy nexbuy_antigo
unzip -o NEXBUY_PYTHONANYWHERE.zip
cd ~/nexbuy
cp ../nexbuy_antigo/.env .
chmod 600 .env
```

O que cada linha faz: apaga a sobra de uma atualização anterior (se houver;
o site atual está em `~/nexbuy` e não é tocado), guarda o código atual em
`~/nexbuy_antigo`, descompacta o código novo e traz o `.env` (a configuração
com a chave secreta) de volta. O banco, os uploads e o virtualenv ficam fora
da pasta do código e **não são tocados** aqui.

## 4. Ligar o uso real (o comando que apaga a demonstração)

Ainda no console, dentro de `~/nexbuy`:

```bash
bash deploy/pythonanywhere/ativar_uso_real.sh
```

O script mostra 8 etapas numeradas (`[1/8]` ... `[8/8]`) e leva de 2 a 5
minutos:

1. confere a instalação (recusa se o `.env` estiver com `DEBUG` ligado);
2. mostra o que existe hoje no banco (as empresas fictícias e os usuários
   de demonstração);
3. instala as dependências — se isso falhar, **nada foi apagado**;
4. **pede confirmação**: explica o que sai e o que fica guardado e pede
   para você **digitar `APAGAR`** (em maiúsculas) e teclar **Enter**.
   Qualquer outra resposta cancela sem apagar nada;
5. guarda a demonstração em
   `~/nexbuy_backups/demonstracao_final_AAAA-MM-DD_HHMM/` (cópia íntegra do
   banco, o logo e os arquivos enviados, e um `LEIA-ME.txt`) — dá para
   voltar (parte 14);
6. troca o banco por um banco **novo e vazio**, no mesmo lugar, e esvazia a
   pasta de uploads;
7. liga o uso real no `.env`: `DEMO_MODE=False`, `DEMO_EXIBIR_SENHA=False`,
   `NEXBUY_USO_REAL=True`, um **token novo** para o Primeiro Acesso e o
   **backup diário automático** (`BACKUP_DIARIO=True`, 14 cópias em
   `~/nexbuy_backups`). O resto do `.env` (chave secreta, endereço do site,
   Admin técnico) fica igual;
8. atualiza os estilos, **recarrega o site** e testa: a tela de login
   (200), o Primeiro Acesso (200) e a tela de apresentação, que agora tem
   de dar "não encontrada" (404).

No fim aparece um quadro **PRIMEIRO ACESSO** com o **endereço** e o
**token**. **Copie o token na hora** (selecione e Ctrl+C) e guarde num
lugar seguro até entregar à proprietária: ele **não aparece de novo** e não
fica em nenhum log (só no `.env`, que só a sua conta lê). Depois digite
`clear` e **Enter** para limpar a tela.

- **Rodar de novo é seguro.** Com o site já em uso real, o script se recusa
  a apagar qualquer coisa e só mostra a situação ("já está em USO REAL —
  nada foi apagado"). Ele também **nunca apaga** um banco que tenha empresa
  de verdade ou em que o Primeiro Acesso já foi feito.
- **Perdeu o token antes do Primeiro Acesso?** Gere outro (o antigo deixa de
  valer): `bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token`
- Se o script parar com `[ERRO]`, a própria mensagem diz o que fazer. Se ele
  parar depois do `APAGAR`, corrija o que o erro diz e rode o mesmo comando
  de novo: ele termina a troca (estilos e recarga do site) sem apagar nada.
  Se o token já tinha sido gravado, o quadro **PRIMEIRO ACESSO** aparece
  logo abaixo do erro (copie) e continua valendo.
- **O quadro com o token não apareceu** (ou você não chegou a copiar)? O
  caminho é gerar outro: `bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token`

## 5. Conferir

1. Abra `https://<seu-usuario>.pythonanywhere.com/` — a tela de login
   aparece **sem** o aviso de demonstração.
2. Abra `https://<seu-usuario>.pythonanywhere.com/primeiro-acesso/` — a
   tela pede o **token de configuração**. **Não preencha**: isso é com a
   proprietária.
3. `https://<seu-usuario>.pythonanywhere.com/demo/apresentacao/` mostra
   "Página não encontrada" — é o esperado.
4. Os logins `demo_*` não entram mais — também é o esperado.

Deu tudo certo? Apague a pasta antiga (ela tem uma cópia do `.env`):
`rm -rf ~/nexbuy_antigo`

## 6. Mensagem para a proprietária

Mande **o endereço por um canal** e o **token por outro** (de preferência
entregue o token pessoalmente ou por ligação). Modelo:

> Olá, [nome]! O NEXBUY está pronto para o teste com os dados reais da
> farmácia.
>
> **Endereço:** https://<seu-usuario>.pythonanywhere.com/primeiro-acesso/
> (abra no computador, no Chrome, Edge ou Firefox)
>
> Ele pede um **token de configuração**, que vou te passar separado. Com ele
> você cadastra a empresa, a loja principal (Matriz) e o **seu login de
> Proprietária**, com uma senha que só você vai saber. O token vale para um
> único cadastro.
>
> Os acessos de demonstração (`demo_...`) deixaram de existir. Depois do seu
> cadastro, é você quem cria o acesso de cada pessoa da equipe.

## 7. O que a proprietária faz

O roteiro completo, com cada campo, está em
`docs/PRIMEIROS_PASSOS_ADMINISTRADOR.md` (e dentro do sistema: ícone **?** →
**Manual do sistema**). Em resumo, na ordem:

1. **Primeiro Acesso** — abre o endereço, cola o token (a partir daí tem
   15 minutos para concluir) e preenche: **ela** (nome, login e uma senha
   forte), a **empresa** (nome do grupo, nome fantasia, razão social, CNPJ,
   cidade e estado), o nome da **primeira loja (Matriz)** e o **fuso
   horário** (em Mato Grosso: Cuiabá). Depois disso o endereço do Primeiro
   Acesso fecha para sempre.
2. **Login** em `https://<seu-usuario>.pythonanywhere.com/accounts/login/`.
3. **Checklist de Implantação** — menu **Configurações › Checklist de
   Implantação**: mostra o que falta e leva direto a cada tela.
4. **Lojas** — **Gestão › Empresas e Filiais › Gerenciar**: completar o
   cadastro da Matriz e cadastrar as outras lojas.
5. **Equipe e senhas** — **Gestão › Usuários e Permissões › Novo Usuário**:
   nome, e-mail, login, senha inicial, perfil (Gerente, Financeiro,
   Comprador ou outro Proprietário) e loja. Na ficha de cada usuário, o
   botão **Gerar nova senha provisória** cria uma senha forte que aparece uma
   única vez: ela passa para a pessoa, que troca em **Meu Perfil**. Vale
   criar um **segundo Proprietário de reserva** (se ela esquecer a senha, o
   outro gera uma provisória).
6. **Fornecedores e categorias** — **Compras › Fornecedores** e **Compras ›
   Categorias** (toda compra precisa dos dois).
7. **Números do Financeiro** — **Capacidade Financeira** (percentual para
   compras e o que fazer quando passa do limite), **Receitas** do mês de
   cada loja, **Receitas extras**, **Custos fixos**, **Custos variáveis** e
   **Calendário Operacional** (feriados e dias sem compra).
8. **Compradores com limites** — **Financeiro › Compradores e Limites**:
   limite individual por dia de cada comprador, bloquear e liberar.
9. **Aprovações** — **Configurações › Centro de Configurações › Workflow de
   Aprovações**, se quiserem um fluxo com etapas.

Avisos importantes para ela:

- **Não use o Assistente de Implantação** (`/ncc/implantacao/`) para a
  empresa criada no Primeiro Acesso: ele cria **outra** empresa.
- Compras e provisões gravadas contam como **reais** e **não podem ser
  apagadas pela tela**. Para experimentar sem gravar, use o **Simulador**.
- A receita do mês **não se repete sozinha**: todo começo de mês, lance a
  receita de cada loja.

## 8. Rotina (não pule)

| Quando | O quê | Como |
|---|---|---|
| **A cada 3 semanas** | Manter o site no ar | Aba **Web** → botão **Run until 1 month from today**. Com 1 mês sem esse clique o site sai do ar (nada é apagado; o mesmo botão o traz de volta). |
| **Todo dia** (automático) | Backup do banco | Nada a fazer: no **primeiro acesso de cada dia** o próprio site grava `~/nexbuy_backups/diario_AAAA-MM-DD.sqlite3` e guarda os **14** mais recentes. |
| **Toda semana** | Copiar o backup para fora do PythonAnywhere | Aba **Files** → pasta `nexbuy_backups` → ícone de **download** ao lado do `diario_...` mais recente. Guarde numa pasta da empresa com cópia (ex.: OneDrive/Google Drive) — são dados financeiros: trate como confidenciais. |
| **A cada versão nova** | Atualizar o sistema | Parte 9. |
| **Começo de cada mês** (proprietária/financeiro) | Receita do mês | Lançar a receita de cada loja e conferir os custos. |

Se ninguém usar o site num dia, não há backup daquele dia — é normal. Para
fazer um backup na hora (ex.: antes de uma mudança grande):
`cd ~/nexbuy && bash deploy/pythonanywhere/backup.sh`

## 9. Atualizar para uma versão nova

1. No computador, gere o zip de novo (parte 2) e envie pela aba **Files**
   (parte 3, passo 1).
2. No console Bash, uma linha por vez:

```bash
cd ~
rm -rf ~/nexbuy_antigo
mv nexbuy nexbuy_antigo
unzip -o NEXBUY_PYTHONANYWHERE.zip
cd ~/nexbuy
cp ../nexbuy_antigo/.env .
chmod 600 .env
bash deploy/pythonanywhere/atualizar.sh
```

O `atualizar.sh` faz backup do banco, instala dependências novas, aplica as
migrações, atualiza os estilos, **apaga do `.env` o token do Primeiro
Acesso** quando a proprietária já o usou, confere que o backup diário está
ligado e mostra a data do mais recente, recarrega o site e testa as páginas.
Ele **nunca** apaga dado nem mexe em senha. (O nome antigo,
`atualizar_demo.sh`, continua funcionando e faz o mesmo.)

Abra o site e confira. Deu certo? `rm -rf ~/nexbuy_antigo`

As opções da demonstração (`--renovar-cenario`, `--gerar-senha`,
`--trocar-senha`...) são **recusadas** no uso real, sem mudar nada: não
existe mais cenário fictício nem senha de demonstração.

## 10. Backups: onde ficam e como restaurar

Tudo fica em `~/nexbuy_backups/` (só a sua conta lê):

| Arquivo | O que é | Quantos ficam |
|---|---|---|
| `diario_AAAA-MM-DD.sqlite3` | Backup diário automático do site | Os 14 mais recentes |
| `nexbuy_AAAA-MM-DD_HHMM.sqlite3` | Backup feito pelo `backup.sh` (e antes de cada atualização ou restauração) | Os 10 mais recentes |
| `demonstracao_final_AAAA-MM-DD_HHMM/` | A demonstração guardada na troca (parte 4) | Fica até você apagar |

Ver a lista: `ls -l ~/nexbuy_backups/`

**Restaurar** (o sistema volta a ser exatamente o daquele backup):

```bash
cd ~/nexbuy
bash deploy/pythonanywhere/restaurar.sh ~/nexbuy_backups/diario_AAAA-MM-DD.sqlite3
```

Troque o nome pelo do arquivo escolhido (copie da lista). O script:

1. confere se o arquivo é um banco íntegro do NEXBUY e mostra o que tem nele
   e no site agora;
2. pede para **digitar `RESTAURAR`**;
3. faz um **backup de segurança** do banco atual (dá para desfazer,
   restaurando esse backup);
4. copia o backup para dentro do banco do site (com o site no ar) e aplica
   as migrações, se o backup for de uma versão anterior;
5. recarrega o site.

**Tudo o que foi lançado depois do horário do backup deixa de aparecer** —
avise a equipe antes. O logo e os arquivos enviados não fazem parte do
backup do banco e ficam como estão. Por segurança, o script **recusa**
trocar um banco com dados reais por um backup da demonstração (ou vazio).

**Restaurar um backup que está no computador:** aba **Files** → pasta
`nexbuy_backups` → **Upload a file**; depois o comando acima com o nome dele.

## 11. Limites e cuidados do plano grátis (leia com a cliente)

**O que fica guardado no PythonAnywhere:** os dados da empresa (razão
social, CNPJ, endereços das lojas), os **nomes, e-mails e logins da equipe**
(as senhas ficam só embaralhadas, nunca legíveis), fornecedores, e os
**valores financeiros**: receitas, custos, compras, provisões e limites.
**Nenhum dado de cliente ou paciente da farmácia** — o NEXBUY não tem
cadastro de clientes, receitas médicas nem vendas. Não cadastre CPF ou dado
pessoal de ninguém além do necessário (nome e e-mail da equipe).

**Cuidados:**

- O servidor fica nos **EUA** e o plano grátis **não tem contrato** de
  tratamento de dados (LGPD). Para um **teste**, combinado com a cliente, é
  aceitável; **para o uso oficial, recomendamos levar o sistema para o
  servidor definitivo** (VPS Hostinger, parte 13) ou para um plano pago.
- **1 só "web worker":** atende uma pessoa por vez; com várias pessoas ao
  mesmo tempo o site fica lento. O primeiro acesso do dia pode demorar
  alguns segundos a mais.
- **512 MB de disco** (o NEXBUY usa pouco: o `atualizar.sh` mostra o uso) e
  **100 segundos de CPU por dia no console** (passando disso o console só
  fica lento).
- **O site expira** se ninguém clicar em **Run until 1 month from today**
  (parte 8). Nada é apagado, mas ninguém entra até alguém clicar.
- **Conta sem nenhum acesso por 6 meses pode ser apagada** pelo
  PythonAnywhere — com os dados. Por isso o backup semanal no computador
  (parte 8) não é opcional.
- **Não há aviso automático** de queda nem de erro: se a equipe disser que o
  site está fora do ar, veja a parte 12.
- A senha da **conta do PythonAnywhere** é só de quem administra o site —
  nunca a envie à cliente. O `.env` fica com permissão 600 e nunca vai para
  o zip nem para o GitHub.

## 12. Problemas comuns

| Sintoma | O que fazer |
|---|---|
| Perdi o token antes do Primeiro Acesso | `cd ~/nexbuy && bash deploy/pythonanywhere/ativar_uso_real.sh --novo-token` (o antigo deixa de valer; mande o novo à proprietária). |
| `/primeiro-acesso/` mostra "Página não encontrada" | Se a proprietária já fez o Primeiro Acesso, é o normal (ele fecha). **Logo depois do `ativar_uso_real.sh`** (o script avisa "Alguma página respondeu diferente do esperado"): o site ainda lê o banco antigo — aba **Web** → botão verde **Reload**, espere uns 30 segundos e abra de novo (foi o que resolveu na primeira troca, em 06/10/2026). Se a proprietária ainda não fez e o Reload não resolveu: gere um token novo (linha acima). |
| A proprietária esqueceu a senha | Outro Proprietário gera uma senha provisória na ficha dela (**Gestão › Usuários e Permissões**). Sem outro Proprietário, no console: `cd ~/nexbuy && ~/.virtualenvs/nexbuy/bin/python manage.py changepassword LOGIN-DELA` (pede a senha nova duas vezes; nada aparece enquanto digita) e depois ela troca em **Meu Perfil**. |
| Alguém da equipe esqueceu a senha | A proprietária gera uma senha provisória na ficha da pessoa. |
| `ativar_uso_real.sh` diz "já está em USO REAL — nada foi apagado" | É o esperado depois da troca: o script nunca apaga um site em uso real. Para atualizar, use o `atualizar.sh`. |
| `ativar_uso_real.sh` diz "O banco é a DEMONSTRAÇÃO com empresa cadastrada DENTRO dela" | A cliente cadastrou uma empresa na demonstração (parte 1). Se é só teste e ela vai recomeçar no Primeiro Acesso: `bash deploy/pythonanywhere/ativar_uso_real.sh --descartar-empresas-da-demonstracao` (fica tudo guardado na cópia). Não ponha o marcador no `.env` à mão. |
| `ativar_uso_real.sh` diz "O banco já é de USO REAL" | O site já está em uso real, mas o `.env` perdeu o marcador: rode `bash deploy/pythonanywhere/atualizar.sh`, que grava o marcador sem apagar nada. |
| `atualizar.sh` diz "Corrigido no .env: NEXBUY_USO_REAL=True" | Veio um `.env` antigo da demonstração numa atualização. O script recolocou as linhas do uso real (o resto ficou igual); confira o site. |
| Um script diz "A opção ... é da DEMONSTRAÇÃO" | Essas opções não existem no uso real. Rode sem a opção. |
| `Não achei o .../nexbuy/.env: faltou trazer o .env da pasta antiga` ou `Não achei o .../nexbuy/.env, e o banco já tem dados reais` | Faltou trazer o `.env` na atualização: `cp ~/nexbuy_antigo/.env ~/nexbuy/.env` e `chmod 600 ~/nexbuy/.env`, e rode de novo. |
| `BACKUP_DIARIO_DIR=... não é um caminho completo` | Alguém escreveu a pasta do backup diário sem o caminho completo (ex.: `~/nexbuy_backups`); o site recusa esse valor. O script já gravou o caminho completo no `.env` — confira o site depois da recarga. |
| Não aparece backup `diario_...` novo | Ele só é feito quando alguém usa o site naquele dia. Para fazer na hora: `cd ~/nexbuy && ~/.virtualenvs/nexbuy/bin/python manage.py backup_diario`. Confira também a linha `BACKUP_DIARIO=True` no `~/nexbuy/.env`. |
| Site fora do ar / página dizendo que o site foi desativado | Expirou: aba **Web** → **Run until 1 month from today**. |
| "Something went wrong", erro 400 ou "Sua sessão expirou" | Mesmas causas e soluções da parte 11 do `docs/DEPLOY_PYTHONANYWHERE_DEMO.md`. O erro aparece no **Error log** da aba **Web** (ou `tail -n 50 /var/log/$USER.pythonanywhere.com.error.log`). |
| `Disk quota exceeded` | `rm -rf ~/.cache/*`, `rm ~/NEXBUY_PYTHONANYWHERE.zip`, `rm -rf ~/nexbuy_antigo` e, depois de baixar para o computador, apague a pasta `demonstracao_final_...` de `~/nexbuy_backups/`. |
| `$'\r': command not found` | `sed -i 's/\r$//' ~/nexbuy/deploy/pythonanywhere/*.sh` e rode de novo. |

## 13. Levar para o servidor definitivo (VPS Hostinger) depois

Quando a cliente decidir pelo uso oficial, os dados do teste podem ir junto
— não precisa recadastrar nada.

1. Instale a VPS seguindo `docs/DEPLOY_HOSTINGER_GITHUB.md`. **Não** faça o
   Primeiro Acesso lá: os dados vêm do backup.
2. Combine um horário em que ninguém use o PythonAnywhere. No console Bash
   dele, faça um backup e empacote os uploads (logo):

```bash
cd ~/nexbuy
bash deploy/pythonanywhere/backup.sh
tar -czf ~/nexbuy_media.tar.gz -C ~/nexbuy_dados media
```

3. Baixe pela aba **Files** o `nexbuy_...sqlite3` que o backup acabou de
   criar (pasta `nexbuy_backups`) e o `nexbuy_media.tar.gz` (pasta inicial).
4. Envie os dois para a VPS e restaure com o script dela, que aceita o banco
   `.sqlite3` sem compactar — passo a passo em
   `docs/OPERACAO_BACKUP_E_ATUALIZACAO.md`, seção 4.1:
   `bash /opt/nexbuy/app/deploy/restaurar_backup.sh /root/ARQUIVO.sqlite3 /root/nexbuy_media.tar.gz`
5. Logins e senhas continuam os mesmos; todos precisam **entrar de novo**
   (a chave secreta da VPS é outra). Confira, avise a equipe do endereço
   novo e desligue o PythonAnywhere (parte 15).

## 14. Voltar para a demonstração (só antes do Primeiro Acesso)

Só faz sentido se a troca foi feita por engano e **ninguém** fez o Primeiro
Acesso ainda. É **um comando só**, que confere tudo **antes** de mexer em
qualquer coisa:

```bash
cd ~/nexbuy
bash deploy/pythonanywhere/voltar_demonstracao.sh
```

1. Ele confere que o site **não tem dado real** (nenhuma empresa de
   verdade, nenhum usuário fora da demonstração e o Primeiro Acesso **não**
   feito). Se tiver, ele **recusa** e nada é alterado. **Se o script
   recusar, PARE aí:** não apague nem copie nada à mão — os uploads (logo,
   fotos da equipe) **não entram em nenhum backup** e se perderiam.
2. Usa a pasta `demonstracao_final_...` mais recente de `~/nexbuy_backups/`
   (para escolher outra, ponha o caminho dela no fim do comando) e confere
   o banco guardado.
3. Pede para **digitar `VOLTAR`**.
4. Faz um backup do banco atual, restaura o banco da demonstração e
   **move** os uploads atuais para `~/nexbuy_backups/media_antes_da_volta_...`
   (nunca apaga) antes de trazer o logo da demonstração de volta.
5. Deixa o `.env` como demonstração (`NEXBUY_USO_REAL=False`,
   `DEMO_MODE=True`, sem token, backup diário desligado) e roda o
   `atualizar.sh`, que confere as senhas e recarrega o site.

A demonstração volta como estava, com as mesmas senhas de antes. A pasta
`demonstracao_final_...` continua guardada.

## 15. Desligar o site (fim do teste)

- **Pausar:** não clique em "Run until 1 month from today" — o site sai do
  ar sozinho no fim do prazo, sem apagar nada.
- **Apagar de vez:** **antes**, baixe para o computador o backup mais
  recente (parte 8). Depois: aba **Web** → botão para apagar o web app, e no
  console
  `rm -rf ~/nexbuy ~/nexbuy_antigo ~/nexbuy_dados ~/nexbuy_static ~/nexbuy_backups ~/.virtualenvs/nexbuy ~/nexbuy_wsgi_original.py ~/nexbuy_media.tar.gz`
- **Encerrar a conta:** página **Account** do PythonAnywhere.
