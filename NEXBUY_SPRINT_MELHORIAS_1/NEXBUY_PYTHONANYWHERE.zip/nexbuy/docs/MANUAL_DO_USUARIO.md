# NEXBUY — Manual do usuário

Manual completo do NEXBUY, por perfil. O mesmo conteúdo está **dentro do sistema**, na
**Central de Ajuda**: ícone **?** no topo › **Manual do sistema** (`/ajuda/`). Lá ele se
adapta ao perfil de quem está logado, tem atalhos que abrem cada tela e pode ser
impresso ou salvo em PDF.

Para colocar a empresa em funcionamento pela primeira vez, siga antes o roteiro
[PRIMEIROS_PASSOS_ADMINISTRADOR.md](PRIMEIROS_PASSOS_ADMINISTRADOR.md).

## Sumário

1. O NEXBUY em poucas palavras
2. Entrar e navegar
3. Comprador
4. Gerente
5. Financeiro
6. Proprietário (administrador)
7. Compras e provisões
8. Aprovações
9. Agenda financeira e contas a pagar
10. Análise Financeira
11. Relatórios e impressão
12. Perguntas frequentes
13. Mapa de telas por perfil

---

## 1. O NEXBUY em poucas palavras

A empresa lança **manualmente** a receita do mês e os custos. Com esses números, o
NEXBUY calcula **quanto cada filial pode comprar por dia** (o **limite do dia**) e
confere cada compra e cada provisão contra esse limite. A **Análise Financeira**
mostra o resultado do mês e a saúde financeira.

- Não há integração com o sistema de vendas da farmácia (ERP): tudo é lançado pela
  tela.
- Não há controle de estoque.
- O **DDA** (boletos emitidos contra o CNPJ) é uma integração **prevista, ainda não
  conectada**.

### Como o limite do dia é calculado (exemplo)

| Conta | Valor |
|---|---:|
| Receita do mês (receita mensal + receitas extras) | R$ 300.000,00 |
| (−) Custos fixos ativos | R$ 60.000,00 |
| (−) Custos variáveis previstos para o mês | R$ 15.000,00 |
| **(=) Disponibilidade financeira** | **R$ 225.000,00** |
| (×) Percentual destinado às compras: 30% | R$ 67.500,00 |
| (−) Percentual de segurança: 0% | R$ 0,00 |
| (÷) Dias úteis do mês: 22 | ÷ 22 |
| **(=) Limite do dia** | **R$ 3.068,18** |

Com o **saldo acumulativo** ligado, o que não foi usado nos dias anteriores do mês soma
ao limite de hoje. Com a **redistribuição automática** ligada, o que passou do limite
num dia é descontado dos dias seguintes.

### As cores do dia

- **Verde:** uso abaixo de 80% do limite do dia.
- **Laranja:** de 80% a 100% — atenção.
- **Vermelho:** acima de 100% — limite ultrapassado.

## 2. Entrar e navegar

- **Entrar:** `https://SEU-DOMINIO/accounts/login/`, com o usuário e a senha que o
  administrador cadastrou. No primeiro acesso, troque a senha em **Meu Perfil**.
- **Menu lateral:** telas agrupadas por tarefa. No celular, o botão ☰ abre o menu e a
  barra do rodapé leva às telas mais usadas.
- **Trilha** ("Início › …") no alto da página: onde você está.
- **Pesquisa** no topo (atalho **Ctrl + K**): encontra telas pelo nome do menu (com ou
  sem acento — "saude" acha **Saúde Financeira**) e registros (compras, provisões e
  fornecedores pelo nome do fornecedor).
- **Sino:** avisos de aprovações, bloqueios e mudanças de status.
- **Ícone ? (Ajuda):** Manual do sistema, tour guiado e pesquisa.
- **Seu nome (canto superior direito):** Meu Perfil (foto, dados, troca de senha) e
  Sair.

Sistema novo, telas vazias: é normal. Cada tela sem dados mostra um aviso com o
próximo passo.

## 3. Comprador

Você lança as compras da filial, planeja as próximas e acompanha, todo dia, quanto
ainda pode comprar. **O Comprador nunca vê** receita, custos, a Análise Financeira nem
os números financeiros da empresa — só o que precisa para comprar.

**Seu dia a dia:**

1. **Início:** responde "Posso comprar hoje?", mostra quanto ainda cabe no dia, o % já
   usado e, quando existir, a **sua dotação do dia** (limite individual definido pelo
   Financeiro).
2. **Nova Compra:** registre cada pedido fechado ou nota recebida.
3. **Nova Provisão** e **Calendário de Compras:** planeje as compras dos próximos dias.
4. **Simulador:** teste "e se eu comprasse X no dia Y?" sem gravar nada.
5. **Histórico de Compras** e **sino:** acompanhe cada decisão.

Menu do Comprador: Início · Nova Compra · Planejamento de Compras (Nova Provisão,
Calendário de Compras) · Histórico de Compras · Simulador.

**Palavras que você vai ver:**

- **Limite do dia:** quanto a filial pode comprar hoje.
- **Dotação do dia:** o seu limite individual para hoje, quando o Financeiro define.
- **Saldo disponível:** o que ainda cabe no dia, descontando compras e provisões.
- **Provisão:** compra planejada para uma data futura, que reserva o valor no dia.
- **Efetivar:** transformar uma provisão aprovada em compra.

## 4. Gerente

Você acompanha a operação da filial e **decide** as compras e provisões que passam do
limite.

1. **Início:** o que aguarda a sua decisão.
2. **Aprovações:** aprove, rejeite ou peça ajustes (sempre com justificativa). No fim
   da tela, o bloco **"Aprovadas aguardando efetivação"** lista as provisões prontas
   para virar compra, com o botão **Efetivar**.
3. **Indicadores:** operação por filial e fornecedores do mês.
4. **Análise Financeira:** DRE, créditos × débitos e saúde financeira (seção 10).
5. **Relatórios:** impressão e CSV.

O Gerente não lança compras nem provisões e não cadastra receitas e custos. A
**Agenda Financeira** aparece para o Gerente só se o administrador conceder a
permissão; mesmo assim, a baixa de parcelas é feita pelo Financeiro ou pelo
Proprietário.

## 5. Financeiro

Você cuida do planejamento financeiro — é dele que sai o limite de compra.

1. **Início (Centro de Controle):** pagamentos de hoje, próximos vencimentos e
   compradores.
2. **Agenda Financeira:** baixa (marcar como paga) e estorno de parcelas.
3. **Receitas, receitas extras, custos fixos e custos variáveis:** mantenha em dia.
4. **Compradores e Limites:** limites individuais, bloqueio e liberação.
5. **Análise Financeira:** acompanhe o resultado.

Menu do Financeiro: Início · Agenda Financeira · Calendário Financeiro · Compradores e
Limites · Planejamento (Planejamento Financeiro, Capacidade Financeira, Receitas,
Custos Fixos, Custos Variáveis, Contas a Pagar, Parcelamentos, Calendário
Operacional, Fornecedores, Categorias, Centros de Custo) · Análise Financeira ·
Relatórios.

**Provisões para decidir e para efetivar:** no **Início**, botão **Solicitações** —
lá ficam as provisões que aguardam a sua decisão e, no bloco **"Aprovadas aguardando
efetivação"**, as que já podem virar compra (botão **Efetivar**).

### Receitas

- **Receita mensal (faturamento):** uma por filial por mês — filial, mês de referência
  e valor. **Não se repete sozinha:** todo mês começa sem receita, e o limite do dia
  fica "—" até alguém lançar. Lance a receita esperada no início do mês e corrija
  quando o mês fechar.
- **Receitas extras:** serviços farmacêuticos, convênios/PBM, rendimentos financeiros
  e outras receitas. Cada lançamento tem data; pode haver vários no mês; somam à
  receita do mês. A lista filtra por mês, filial e categoria e exporta CSV.
- A tela de Receitas mostra, mês a mês, a receita mensal, as receitas extras e o
  **total da receita do mês** — o mesmo número usado no cálculo e nos painéis.

### Custos

- **Custos fixos:** contas recorrentes (folha de pagamento, aluguel, energia,
  impostos fixos), com valor mensal e dia do vencimento. Enquanto ativo, conta em
  todos os meses; desative quando a conta deixar de existir.
- **Custos variáveis:** despesas pontuais com data prevista; contam só no mês daquela
  data.

### Capacidade Financeira (configuração)

| Campo | O que faz |
|---|---|
| Percentual destinado às compras (%) | Fatia da disponibilidade financeira (receita menos custos) que pode virar compra |
| Percentual de segurança (%) | Reserva que reduz a capacidade antes de dividir pelos dias úteis |
| Dias úteis considerados (manual) | Em branco = o sistema conta sozinho (respeita o Calendário Operacional) |
| Permitir saldo acumulativo / Limite máximo acumulado | A sobra dos dias anteriores soma ao limite de hoje, até o teto |
| Redistribuição automática + Permitir ultrapassar o limite diário | O excedente de um dia é descontado dos dias seguintes |
| Forma de bloqueio ao ultrapassar o limite diário | Bloquear compra · Solicitar Aprovação · Permitir compra com alerta |

### Calendário Operacional e Compradores e Limites

- **Calendário Operacional:** só os dias úteis (segunda a sexta) e os dias
  especiais recebem limite de compra; sábado, domingo, feriados e dias bloqueados
  não têm limite próprio. Para comprar num sábado, marque-o como **Especial** — ele
  ganha limite e entra na divisão da capacidade do mês (a soma dos limites do mês
  continua igual à capacidade mensal).
- **Compradores e Limites:** limite do dia da filial, limite individual por dia de
  cada comprador (opcional), bloqueio e liberação. Comprador bloqueado tem as compras
  barradas na hora; quem passa do próprio limite gera pedido de aprovação.

### Onde acompanhar

**Calendário Financeiro** (visões mensal, semanal e diária), **Timeline Financeira**
(limites, sobras e redistribuições dia a dia) e **Planejamento Financeiro** (o hub com
todas as áreas).

## 6. Proprietário (administrador)

Você vê todas as filiais, cadastra a equipe, define quem pode fazer o quê e decide as
aprovações. Também lança compras e provisões e faz tudo o que o Financeiro faz.

Menu do Proprietário: Início · Compras (Nova Compra, Histórico de Compras,
Aprovações, Calendário de Compras, Nova Provisão, Simulador, Fornecedores, Categorias,
Centros de Custo) · Financeiro (Planejamento Financeiro, Agenda Financeira, Calendário
Financeiro, Capacidade Financeira, Compradores e Limites, Parcelamentos, Análise
Financeira) · Gestão (Empresas e Filiais, Usuários e Permissões, Perfis de Acesso) ·
Relatórios (Central de Relatórios, Indicadores, Timeline Financeira, Compras por
Filial, Compras por Comprador) · Configurações (Centro de Configurações, Checklist de
Implantação, Integrações, Auditoria do Sistema).

Receitas, Custos Fixos, Custos Variáveis, Contas a Pagar e Calendário Operacional
abrem pelo hub **Financeiro › Planejamento Financeiro**. O **Calendário de Compras**
tem um seletor de **filial** quando a empresa tem mais de uma.

- **Usuários:** Gestão › Usuários e Permissões › Novo Usuário. Nome, e-mail, login,
  senha inicial, perfil e filial (obrigatória para Gerente, Financeiro e Comprador).
  Na ficha do usuário: filiais autorizadas, perfis de acesso, permissões individuais,
  limite individual, ativar/desativar e **Gerar nova senha provisória**.
- **Perfis de Acesso:** conjuntos de permissões reutilizáveis que **somam** acessos
  (nunca tiram).
- **Filiais:** Gestão › Empresas e Filiais › Gerenciar.
- **Centro de Configurações:** regras gerais (inclusive a autoaprovação controlada),
  Workflow de Aprovações, parcelamentos e compras, notificações, integrações.
- **Checklist de Implantação:** 13 itens verificados direto no banco.
- **Auditoria do Sistema:** quem fez o quê e quando — não pode ser apagada.
- **Não use o Assistente de Implantação** para a empresa criada no Primeiro Acesso:
  o passo 1 dele cria sempre um **grupo e uma empresa (CNPJ) novos** — seguido à
  risca, o sistema ficaria com duas empresas. Para completar a implantação, use o
  **Checklist de Implantação** e o roteiro
  [PRIMEIROS_PASSOS_ADMINISTRADOR.md](PRIMEIROS_PASSOS_ADMINISTRADOR.md).

## 7. Compras e provisões

| | Compra | Provisão |
|---|---|---|
| O que é | Pedido **já fechado** ou nota recebida | **Planejamento** de uma compra futura |
| Limite | Conta no limite do dia da data da compra | Reserva o valor no dia planejado |
| Passou do limite | Aprovada com alerta, pendente de aprovação ou bloqueada (regra da empresa) | Vai para aprovação |
| Depois | Gera parcelas conforme o prazo | Aprovada, pode ser **efetivada** em compra |

### Lançar uma compra (Comprador e Proprietário)

1. **Nova Compra:** filial, fornecedor, categoria, valor e data da compra (centro de
   custo e observação são opcionais).
2. **Prazo de pagamento:** à vista, 7, 14, 30 ou 60 dias, 30/60 (2x), 30/60/90 (3x) ou
   personalizado. As parcelas são criadas sozinhas.
3. Salve. O resultado sai na hora:
   - **Aprovada:** coube no limite (ou a empresa permite passar com alerta);
   - **Pendente de aprovação:** passou do limite do dia (com a regra "Solicitar
     Aprovação") ou da dotação individual do comprador;
   - **Bloqueada:** a regra da empresa é bloquear, ou o comprador está bloqueado.

### Planejar uma provisão (Comprador e Proprietário)

1. **Nova Provisão:** filial, fornecedor, categoria, **data** prevista e os **itens**
   (produto, quantidade e valor unitário). O total é a soma dos itens.
2. Se couber no saldo do dia, fica reservada; se passar, vai para **Aguardando
   Aprovação**.
3. **Calendário de Compras:** cada dia mostra saldo, valor provisionado e a cor. Cada
   provisão tem uma timeline (quem criou, quem decidiu, quando).
4. **Efetivar:** quando a compra acontece, uma provisão aprovada (ou que coube no
   saldo do dia) vira Compra, com o prazo de pagamento — feito pelo Proprietário,
   Gerente ou Financeiro. Onde: **Aprovações** › bloco **"Aprovadas aguardando
   efetivação"** (Proprietário e Gerente), **Início › Solicitações** (Financeiro) ou a
   timeline da provisão (Calendário de Compras › dia › **Ver timeline**). Quem pode
   efetivar também recebe um aviso no sino quando a provisão é aprovada.

**Simulador:** mostra o que aconteceria com uma compra de X reais no dia Y, sem gravar
nada. **Histórico de Compras:** cada compra com status e decisões; os totais dos
relatórios somam só as compras aprovadas.

## 8. Aprovações

**O que chega para aprovação:**

- **Compras acima do limite** (regra "Solicitar Aprovação") ou acima da dotação
  individual do comprador — decidem o Gerente e o Proprietário.
- **Provisões acima do saldo do dia** — seguem o **Workflow de Aprovações** (etapas por
  perfil, alçada e prazo). Sem fluxo, decidem Proprietário, Gerente ou Financeiro, em
  uma etapa.

**Como decidir:** abra **Aprovações**, confira quem pediu, o fornecedor, o valor,
quanto passou do limite e o histórico; escolha **Aprovar**, **Rejeitar** ou, na
provisão, **Solicitar Ajustes**, e escreva a justificativa. Quem pediu é avisado na
hora.

**Para quem pediu (Comprador):** o pedido aparece no Início em "Aguardando
Aprovação"; o aviso da decisão chega pelo sino. Em **Ajustes Solicitados**, a provisão
original é encerrada: leia a justificativa e lance uma nova provisão corrigida.

**Separação de funções:** quem criou não aprova o próprio pedido (exceto com a
"autoaprovação controlada" ligada pelo administrador, com justificativa).

## 9. Agenda financeira e contas a pagar

(Proprietário e Financeiro; Gerente só com permissão concedida.)

- **Agenda Financeira:** últimos 7 dias e próximos 30 (botões 15, 30, 60 e 90 dias) — parcelas de compras,
  contas fixas e variáveis e provisões, com as vencidas em destaque. **Baixar** marca a
  parcela como paga; **Estornar** desfaz uma baixa por engano, com justificativa. Imprime
  e exporta CSV.
- **Contas a Pagar:** compromissos de um mês fechado, em três grupos: **Obrigações
  constituídas** (parcelas de compras aprovadas), **Previsões** (custos fixos e
  variáveis) e **Provisões** (compras planejadas ainda não efetivadas).
- **Parcelamentos:** todas as parcelas em aberto, com vencidas em destaque.
- **Calendário Financeiro:** caixa comprometido nas visões mensal, semanal e diária.

Hoje os pagamentos são conferidos e baixados manualmente. Quando o DDA for conectado,
os boletos vão aparecer para o Financeiro conferir — o sistema **nunca** vai pagar,
criar custo ou dar baixa sozinho.

## 10. Análise Financeira

(Proprietário, Gerente e Financeiro. O Comprador não tem acesso.)

Três telas: **DRE Gerencial** (deu lucro ou prejuízo?), **Créditos × Débitos** (entrou
mais do que saiu?) e **Saúde Financeira** (o que melhorar?). No alto de cada tela,
escolha o **mês** e a **filial** (ou todas). O botão **Imprimir** está nas três telas; a
DRE e o Créditos × Débitos também exportam **CSV**. Sem receita lançada no mês, a tela
avisa que a receita ainda não foi lançada e mostra o resultado, as margens e o saldo
como "—" (não como prejuízo); os meses anteriores ao primeiro lançamento aparecem como
"Sem dados". As curvas mostram até 12 meses, a partir do primeiro lançamento da
empresa.

### DRE Gerencial (exemplo)

| Linha | Valor | % da receita |
|---|---:|---:|
| Receita total (mensal + extras) | R$ 300.000,00 | 100% |
| (−) Compras de mercadorias (aprovadas no mês) | R$ 210.000,00 | 70% |
| **(=) Margem bruta** | **R$ 90.000,00** | **30%** |
| (−) Custos variáveis | R$ 15.000,00 | 5% |
| **(=) Margem de contribuição** | **R$ 75.000,00** | **25%** |
| (−) Custos fixos | R$ 60.000,00 | 20% |
| **(=) Resultado operacional** | **R$ 15.000,00** | **5%** |

- **Competência:** entra o que pertence ao mês — a receita do mês, as compras
  **aprovadas** com data no mês, os custos variáveis previstos e os custos fixos ativos.
- **Sem estoque:** as compras aprovadas do mês fazem o papel do custo da mercadoria;
  num mês de reposição pesada a margem bruta cai. Olhe a curva, não só um mês.
- Cada linha traz o % da receita e a comparação com o mês anterior e com a média.

### Créditos × Débitos

- **Créditos:** receita mensal + receitas extras do mês.
- **Débitos:** parcelas de compras aprovadas que **vencem** no mês (pagas e a pagar) +
  custos fixos ativos + custos variáveis previstos.
- **Saldo:** créditos − débitos; o saldo acumulado soma os meses desde o primeiro
  lançamento (até 12).
- Diferença para a DRE: aqui vale o **vencimento** — a compra a prazo pesa no mês da
  parcela.

### Saúde Financeira

Cada indicador ganha um semáforo (**Saudável**, **Atenção**, **Crítico** ou **Sem
dados**) comparado com referências do varejo farmacêutico (RD Saúde, resultados de
2024; Sincofarma-SP, 2022; e faixas conservadoras do NEXBUY). São referências
aproximadas, não metas oficiais. A tela também mostra o **ponto de equilíbrio**, a
**tendência** dos últimos 3 meses, o **comprometimento futuro** (parcelas dos próximos
30, 60 e 90 dias sobre a receita média) e recomendações com atalhos. As faixas exatas
de cada indicador aparecem na Central de Ajuda, lidas do próprio cálculo.

### Glossário

- **Margem bruta:** receita − compras de mercadorias. Quanto sobra da venda depois de
  pagar o que foi comprado para revender. Exemplo: R$ 90.000,00 (30%).
- **Margem de contribuição:** margem bruta − custos variáveis. O que sobra para pagar
  os custos fixos e ainda deixar resultado. Exemplo: R$ 75.000,00 (25%).
- **Resultado operacional (margem operacional):** margem de contribuição − custos
  fixos. O lucro ou prejuízo do mês. Exemplo: R$ 15.000,00 (5%).
- **Ponto de equilíbrio:** a receita em que o resultado fica zero: custos fixos ÷
  (margem de contribuição ÷ receita). Exemplo: R$ 60.000,00 ÷ 25% = **R$ 240.000,00**.
  Se a margem de contribuição for zero ou negativa, não existe ponto de equilíbrio.
- **Margem de segurança:** (receita − ponto de equilíbrio) ÷ receita. Exemplo:
  (300.000 − 240.000) ÷ 300.000 = **20%** — a receita pode cair 20% antes de virar
  prejuízo.
- **Competência × vencimento:** competência (DRE) olha quando o fato aconteceu;
  vencimento (Créditos × Débitos) olha quando o dinheiro sai.
- **Comprometimento futuro:** parcelas a vencer nos próximos 30, 60 e 90 dias comparadas
  com a receita média mensal.

## 11. Relatórios e impressão

- **Central de Relatórios:** reúne os relatórios que o seu perfil pode abrir.
- **Imprimir:** o botão monta a folha com o cabeçalho da empresa, o período, os filtros
  e quem gerou. Para PDF, escolha "Salvar como PDF" na janela de impressão.
- **CSV:** abre no Excel ou no Google Planilhas.
- **Totais:** os relatórios de compras somam só as compras **aprovadas**.
- Este manual, na Central de Ajuda, também pode ser impresso.

## 12. Perguntas frequentes

**Esqueci a minha senha. E agora?**
Peça ao administrador (perfil Proprietário). Ele abre **Gestão › Usuários e
Permissões**, clica no seu nome e usa **Gerar nova senha provisória**. A senha aparece
uma única vez, na tela dele; ele passa para você e você troca em Meu Perfil. O NEXBUY
não envia senha por e-mail. Se o próprio administrador esqueceu, outro Proprietário
gera a senha para ele; se não houver, o suporte técnico redefine pelo servidor
(`nexbuy-manage changepassword USUARIO`, ver
[OPERACAO_BACKUP_E_ATUALIZACAO.md](OPERACAO_BACKUP_E_ATUALIZACAO.md)).

**Como troco a minha senha?**
Clique no seu nome (canto superior direito) › **Meu Perfil**.

**Por que a minha compra foi para aprovação?**
Porque passou do que cabia no dia: ultrapassou o limite do dia da filial (com a regra
"Solicitar Aprovação") ou a dotação individual do comprador. Com provisões, é quando o
valor passa do saldo disponível do dia planejado.

**A compra ficou "Bloqueada". O que houve?**
A regra da empresa é "Bloquear compra" quando o limite é ultrapassado, ou o comprador
foi bloqueado pelo Financeiro. Compra bloqueada não vai para aprovação.

**O limite do dia aparece "—" ou zerado.**
"—" = sem dado: não há receita lançada para a filial neste mês. Zero ou negativo = os
custos do mês já consomem a receita, ou hoje é fim de semana, feriado ou dia bloqueado.

**O que é o DDA e quando ele vem?**
DDA (Débito Direto Autorizado) é o serviço dos bancos que mostra os boletos emitidos
contra o CNPJ da empresa. A integração está **prevista, mas ainda não está conectada**
e não tem data definida. Quando vier, os boletos vão aparecer na Agenda para o
Financeiro conferir e ligar à compra ou provisão — nunca vai pagar, criar custo ou dar
baixa sozinho. Até lá, tudo é lançado e baixado manualmente.

**O NEXBUY puxa os dados do sistema da farmácia?**
Não. Não há integração com ERP nem controle de estoque: tudo é lançado pela tela.

**Errei um lançamento. Como corrijo?**
Receitas, receitas extras, custos fixos e custos variáveis têm Editar e Excluir na
lista (custo fixo pode ser desativado). Compras e provisões gravadas não são editadas
nem apagadas — isso protege o histórico e a auditoria; enquanto aguardam decisão,
podem ser rejeitadas (ou, na provisão, receber pedido de ajustes). Parcela baixada por
engano volta com **Estornar**, na Agenda.

**Treinamos com lançamentos fictícios. Como começo o uso real do zero?**
Peça ao administrador: ele combina com quem cuida do servidor a **limpeza dos dados de
teste**, que apaga as compras, provisões, aprovações e notificações da empresa (e, se
pedido, as receitas e os custos) e mantém todos os cadastros — empresa, filiais,
usuários, fornecedores, categorias e configurações. Faça isso antes do primeiro
lançamento real (ver [PRIMEIROS_PASSOS_ADMINISTRADOR.md](PRIMEIROS_PASSOS_ADMINISTRADOR.md),
seção 16).

**Não vejo um menu que o meu colega vê.**
Cada perfil vê só as telas do seu trabalho. O administrador pode somar permissões em
Perfis de Acesso.

**Quem cria os usuários?**
Só o administrador, em Gestão › Usuários e Permissões › Novo Usuário. Não há cadastro
aberto.

**Posso usar no celular?**
Sim, pelo navegador, no mesmo endereço.

## 13. Mapa de telas por perfil

Acesso padrão de cada perfil (o administrador pode somar permissões em Perfis de
Acesso; o Comprador continua sem as telas financeiras).

| Tela | Endereço | Proprietário | Gerente | Financeiro | Comprador |
|---|---|:-:|:-:|:-:|:-:|
| Início (painel do perfil) | `/` | ✔ | ✔ | ✔ | ✔ |
| Central de Ajuda | `/ajuda/` | ✔ | ✔ | ✔ | ✔ |
| Meu Perfil | `/perfil/` | ✔ | ✔ | ✔ | ✔ |
| Nova Compra | `/compras/nova/` | ✔ | — | — | ✔ |
| Histórico de Compras | `/compras/lista/` | ✔ | ✔ | ✔ | ✔ (as suas) |
| Simulador | `/compras/simulacao/` | ✔ | — | ✔ | ✔ |
| Calendário de Compras | `/gestao-compras/` | ✔ | — | — | ✔ |
| Nova Provisão | `/gestao-compras/nova/` | ✔ | — | — | ✔ |
| Aprovações | `/aprovacoes/` | ✔ | ✔ | — | — |
| Compras acima do limite | `/compras/aprovacao/` | ✔ | ✔ | — | — |
| Provisões para decidir | `/gestao-compras/aprovacao/` | ✔ | ✔ | ✔ | — |
| Planejamento Financeiro | `/financeiro/planejamento/` | ✔ | — | ✔ | — |
| Receitas e receitas extras | `/financeiro/receitas/` | ✔ | — | ✔ | — |
| Custos Fixos / Variáveis | `/financeiro/custos-fixos/`, `/financeiro/custos-variaveis/` | ✔ | — | ✔ | — |
| Capacidade Financeira | `/financeiro/configuracao/` | ✔ | — | ✔ | — |
| Compradores e Limites | `/financeiro/capacidade-compradores/` | ✔ | — | ✔ | — |
| Calendário Operacional | `/financeiro/calendario-operacional/` | ✔ | — | ✔ | — |
| Agenda Financeira | `/financeiro/agenda/` | ✔ | se concedido | ✔ | — |
| Contas a Pagar / Parcelamentos | `/financeiro/contas-a-pagar/`, `/financeiro/parcelamentos/` | ✔ | — | ✔ | — |
| Calendário Financeiro | `/financeiro/calendario/` | ✔ | — | ✔ | — |
| Análise Financeira | `/financeiro/analise/` | ✔ | ✔ | ✔ | — |
| Indicadores | `/indicadores/` | ✔ | ✔ | — | — |
| Timeline Financeira | `/timeline/` | ✔ | ✔ | ✔ | — |
| Central de Relatórios | `/relatorios/` | ✔ | ✔ | ✔ | ✔ |
| Compras por Filial / por Comprador | `/compras/relatorios/por-filial/`, `/compras/relatorios/por-comprador/` | ✔ | ✔ | ✔ | — |
| Fornecedores, Categorias, Centros de Custo | `/compras/fornecedores/`, `/cadastros/categorias/`, `/cadastros/centros-custo/` | ✔ | — | ✔ | — |
| Centro de Configurações, Usuários, Perfis, Filiais | `/ncc/` | ✔ | — | — | — |
| Checklist de Implantação | `/ncc/checklist/` | ✔ | — | — | — |
| Workflow de Aprovações | `/ncc/workflow/` | ✔ | — | — | — |
| Integrações (DDA) | `/ncc/integracoes/` | ✔ | — | — | — |
| Auditoria do Sistema | `/ncc/auditoria/` | ✔ | — | — | — |
