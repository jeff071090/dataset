# NEXBUY — Demonstração grátis no PythonAnywhere (passo a passo)

> **O site passou (ou vai passar) para o USO REAL?** A cliente pediu para
> testar com dados reais, no mesmo PythonAnywhere. Para tirar os dados
> fictícios e os 6 usuários de demonstração e abrir o Primeiro Acesso, siga
> **`docs/PYTHONANYWHERE_USO_REAL.md`** — e, depois da troca, use aquele
> guia para a rotina, as atualizações e os backups. Este guia continua
> valendo para montar uma demonstração nova. Os scripts ganharam nomes
> gerais: `atualizar.sh` e `backup.sh` (os nomes `atualizar_demo.sh` e
> `backup_demo.sh` deste guia continuam funcionando e fazem o mesmo).

Este guia coloca o NEXBUY **em modo demonstração** num endereço da internet
(`https://<seu-usuario>.pythonanywhere.com`), **de graça**, para a cliente
(a farmácia) testar do computador dela, entrando com **cada um dos 6
usuários de demonstração, um a um**.

- É só para **amostragem**: dados **fictícios** da "Farmácia Vida Plena".
  Nada de dado real da farmácia aqui (veja a parte 13).
- A instalação de verdade, para uso real, é outra: VPS Hostinger + GitHub
  (`docs/DEPLOY_HOSTINGER_GITHUB.md`). Veja a parte 15.
- Onde aparece `<seu-usuario>`, troque pelo **seu** usuário do
  PythonAnywhere, sem os sinais `<` `>` (ex.: `nexbuydemo`). Nos comandos do
  console Bash o guia usa `$USER`, que o próprio console troca pelo seu
  usuário — cole do jeito que está.

Os nomes de botões e abas estão **em inglês, exatamente como aparecem no
PythonAnywhere** (o site não tem versão em português).

---

## 0. O que você vai precisar (e quanto tempo)

| Item | Detalhe |
|---|---|
| Computador | O PC onde está a pasta do projeto `nexbuy_producao` (com o `venv`) |
| Navegador | **Chrome** ou **Firefox** (no Safari do Mac o copiar/colar do console não funciona) |
| E-mail | Um e-mail para criar a conta (de preferência o da equipe que administra a demonstração) |
| Cartão de crédito | **Não precisa** — o plano Beginner é grátis |
| Tempo | 40 a 60 minutos na primeira vez; depois, 5 minutos por mês |

Limites do plano grátis (Beginner) que importam aqui:

- **1 site**, com 1 "web worker" (atende uma requisição por vez — para uma
  cliente testando, é suficiente).
- **512 MB de disco** (o NEXBUY instalado usa bem menos de 150 MB).
- **O site expira em 1 mês** se ninguém clicar no botão
  **"Run until 1 month from today"** na aba **Web** (parte 8). Expirar não
  apaga nada: só tira o site do ar até alguém clicar no botão.
- Servidor nos **EUA**; sem tarefas agendadas; o console tem uma cota de
  100 segundos de CPU por dia (passando disso ele só fica mais lento).

Palavras que aparecem no caminho:

| Palavra | O que é |
|---|---|
| **Console** (Bash) | A tela preta do PythonAnywhere onde você cola comandos. |
| **WSGI** | O arquivo que liga o endereço do site ao código do NEXBUY. O script grava esse arquivo por você. |
| **SHA-256** | Uma "impressão digital" do zip: se o arquivo mudar um único byte, o código muda. Serve só para conferência. |
| **CSRF** | Proteção dos formulários contra envio forjado por outro site. Quando falha, aparece "Sua sessão expirou". |
| **virtualenv** | A pasta com o Python e as bibliotecas do NEXBUY (`~/.virtualenvs/nexbuy`). |

## 1. O pacote NEXBUY_PYTHONANYWHERE.zip

É um zip com o código do NEXBUY **sem** nada que não pode sair do seu PC:
sem `venv`, sem banco de dados, sem `.env` (senhas e chaves), sem mídia e
sem capturas/logs de testes.

**Onde fica:** na pasta-mãe do projeto — a mesma pasta onde está a pasta
`nexbuy_producao` (ex.: `...\Downloads\files\NEXBUY_PYTHONANYWHERE.zip`).

**Para gerar (ou regerar depois de mudar o código):**

1. Abra a pasta `nexbuy_producao` no **Explorador de Arquivos** do Windows.
2. Clique na **barra de endereço** (lá em cima, onde aparece o caminho da
   pasta), apague o que está escrito, digite `powershell` e tecle **Enter**.
   Abre uma janela azul do PowerShell já dentro da pasta.
3. Cole o comando abaixo e tecle **Enter**:

```powershell
venv\Scripts\python.exe deploy\pythonanywhere\gerar_pacote.py
```

O script mostra quantos arquivos entraram, o tamanho (cerca de 2 MB) e o
código SHA-256 do zip. O `.env`, os bancos (`*.sqlite3`) e as pastas de
mídia ficam de fora **automaticamente**, mesmo que existam na pasta — é
normal e esperado. (Só numa pasta com git, se algum deles tiver entrado no
git por engano, o script **recusa** gerar o pacote e diz qual.) Para salvar
em outra pasta:
`venv\Scripts\python.exe deploy\pythonanywhere\gerar_pacote.py D:\outra\pasta`.

## 2. Criar a conta grátis (Beginner)

1. Abra **https://www.pythonanywhere.com** (conta **US** — a recomendada; a
   EU, em `eu.pythonanywhere.com`, é um sistema separado e só faz sentido se
   você tiver motivo para querer o servidor na Europa).
2. Clique em **Pricing & signup** e, no plano **Beginner** (grátis), no
   botão para criar a conta (hoje: **Create a Beginner account**; o texto
   pode mudar um pouco).
3. Escolha o **usuário** com cuidado: **ele vira o endereço do site**.
   Sugestão: `nexbuydemo` → `https://nexbuydemo.pythonanywhere.com`.
   Se estiver ocupado, tente `nexbuydemo2`, `demonexbuy`... Use só
   letras minúsculas e números.
4. Informe o e-mail e uma **senha forte** (esta é a senha da **conta do
   PythonAnywhere** — nunca a envie à cliente), aceite os termos e confirme
   o e-mail pelo link que chegar na caixa de entrada.

## 3. Criar o web app (ANTES do script)

O script da parte 4 grava o arquivo WSGI do site, e esse arquivo só existe
depois que o web app é criado. Então:

1. No topo do PythonAnywhere, abra a aba **Web**.
2. Clique em **Add a new web app**.
3. Tela do domínio: vai aparecer `<seu-usuario>.pythonanywhere.com` (no
   grátis não dá para trocar). Clique em **Next**.
4. Tela do framework: escolha **Manual configuration**.
   **Não** escolha "Django" — essa opção cria um projeto novo e vazio.
5. Tela da versão: escolha **Python 3.13**. Clique em **Next** até terminar.

Pronto: a aba **Web** agora mostra o seu site (ainda com uma página de
exemplo do PythonAnywhere). Não precisa mexer em mais nada aqui por enquanto.

Escolheu outra versão do Python por engano? Não precisa recriar: na aba
**Web**, seção **Code**, clique na versão ao lado de **Python version** e
escolha **3.13** (ela tem de ser a mesma do virtualenv — o RESUMO do script
mostra qual é).

## 4. Enviar o pacote e rodar o script de preparação

### 4.1 Enviar o zip (aba Files)

1. Abra a aba **Files**. Você já está em `/home/<seu-usuario>/`.
2. Clique no botão laranja **Upload a file** e escolha o
   `NEXBUY_PYTHONANYWHERE.zip` (limite: 100 MB por arquivo — o nosso tem ~2 MB).
3. Confira se o zip apareceu na lista de arquivos.

### 4.2 Abrir o console (aba Consoles)

1. Abra a aba **Consoles** e, em **Other**, clique em **Bash**. Abre uma
   tela preta (o console) no navegador.
2. O plano grátis permite **2 consoles** ao mesmo tempo: se aparecer aviso
   de limite, feche os antigos na própria aba Consoles.
3. Para **colar** um comando no console: **Ctrl+V** (no Mac, Cmd+V). Cole
   **uma linha por vez** e tecle **Enter**.

### 4.3 ANTES dos comandos: escolha como definir a senha

O script troca a senha dos 6 usuários de demonstração (eles nascem com a
senha pública da demonstração local, que qualquer um conhece). Escolha
**um** jeito — ele define a **última linha** que você vai colar na parte 4.4:

| Última linha (escolha UMA) | O que acontece |
|---|---|
| `bash deploy/pythonanywhere/preparar.sh --gerar-senha` | **Recomendado.** **Gera** uma senha forte (16 caracteres, sem letras/números que se confundem como 0/O e 1/l) para os 6 e mostra **uma única vez**. |
| `bash deploy/pythonanywhere/preparar.sh --gerar-senha --senha-individual` | Gera **uma senha para cada usuário** e mostra a tabela usuário → senha **uma única vez**. |
| `bash deploy/pythonanywhere/preparar.sh` | Pede **uma** senha para os 6 usuários, digitada **duas vezes**. |
| `bash deploy/pythonanywhere/preparar.sh --senha-individual` | Pede **uma senha diferente para cada usuário** (pergunta um por um). |

Se for **digitar** a senha:

- `Nova senha (a mesma para os 6 usuários de demonstração):` → digite a
  senha e tecle **Enter**. **Nada aparece enquanto você digita — nem
  asteriscos.** É normal.
- `Digite a mesma senha de novo:` → digite de novo e **Enter**.
- A senha precisa ter **pelo menos 12 caracteres** (dica: três palavras e
  um número, inventados por você na hora), não pode ser só números, nem uma
  senha comum, nem parecida com o nome do usuário, **nem conter "nexbuy"
  ou lembrar a senha da demonstração local** (variações com maiúscula,
  símbolo ou número a mais são recusadas). Se for recusada, o script
  explica o motivo e pergunta de novo (até 3 vezes).

Com `--gerar-senha`: **copie a senha na hora** (selecione e Ctrl+C) e
guarde num lugar seguro (ex.: um gerenciador de senhas). Ela não aparece
de novo e não fica gravada em lugar nenhum. Depois digite `clear` e Enter
para limpar a tela.

### 4.4 Os comandos

Cole uma linha por vez (a última é a que você escolheu na parte 4.3):

```bash
cd ~
unzip -o NEXBUY_PYTHONANYWHERE.zip
cd ~/nexbuy
bash deploy/pythonanywhere/preparar.sh --gerar-senha
```

O script mostra 9 etapas numeradas (`[1/9]` ... `[9/9]`) e leva de 3 a 8
minutos na primeira vez. Ele:

1. confere a pasta e calcula o endereço do site;
2. acha o Python 3.13 (ou 3.12);
3. cria o ambiente Python em `/home/<seu-usuario>/.virtualenvs/nexbuy`;
4. instala as dependências (Django, WhiteNoise, python-dotenv, Pillow);
5. cria o arquivo de configuração `/home/<seu-usuario>/nexbuy/.env` com uma
   chave secreta nova (que **nunca aparece na tela**), `DEBUG=False`, Modo
   Demonstração ligado e a dica de senha da tela de login **desligada**;
6. cria o banco (`migrate`), copia os arquivos de estilo (`collectstatic`) e
   roda a conferência de segurança (`check --deploy` — o aviso
   `security.W008` é **esperado**, veja a parte 5);
7. cria o cenário fictício (Farmácia Vida Plena, 12 meses de histórico) e os
   6 usuários de demonstração;
8. **desativa na hora a senha pública** (ninguém entra com ela nem por um
   instante), **define a senha dos 6 usuários** do jeito que você escolheu e
   confere que nenhum usuário ativo ficou com a senha pública;
9. grava o arquivo WSGI do site (guardando o original em
   `~/nexbuy_wsgi_original.py`), recarrega o site e confere o Force HTTPS
   (na primeira vez ele avisa que está desligado — é a parte 5).

No fim aparece um **RESUMO** com os valores exatos para a parte 5 — deixe o
console aberto. A linha **Admin técnico (suporte)** do RESUMO é um endereço
de manutenção: **ignore** — a demonstração não tem nenhum usuário que entre
nele.

**Rodar de novo é seguro** — e **as senhas não mudam**. Pode repetir o
comando (inclusive com a seta para cima, com `--gerar-senha` e tudo): o que
já está pronto é mantido, o cenário não é recriado e a senha só é pedida
para usuário que ainda **não tem** senha. Senha que já foi definida (e
talvez já mandada à cliente) **só muda** se você pedir de propósito:

| Quero... | Comando |
|---|---|
| Trocar a senha dos 6 (gerando uma nova) | `bash deploy/pythonanywhere/preparar.sh --trocar-senha --gerar-senha` (pede para digitar `SIM`) |
| Trocar só de um usuário | `cd ~/nexbuy && ~/.virtualenvs/nexbuy/bin/python manage.py definir_senha_demo --usuarios demo_gerente --gerar` |

Depois de trocar, **mande a senha nova à cliente** — a antiga deixa de
valer. O comando `definir_senha_demo` também aceita `--individual` (uma
senha por usuário) e, sem `--gerar`, pede a senha digitada.

> Se o script parar com `[ERRO]`, a própria mensagem diz o que fazer. Se ele
> parar **no meio da troca de senha** (3 senhas recusadas, Ctrl+C...), os
> usuários ficam **sem senha** — ninguém entra, nem com a senha pública; o
> site continua seguro. Rode de novo (ex.: com `--gerar-senha`).

## 5. Configurar a aba Web

Volte à aba **Web** (o site `<seu-usuario>.pythonanywhere.com` selecionado à
esquerda) e preencha com os valores do RESUMO do script:

| Seção da aba Web | Campo | Valor |
|---|---|---|
| **Code** | Source code | `/home/<seu-usuario>/nexbuy` (opcional, só organiza) |
| **Code** | Working directory | `/home/<seu-usuario>/nexbuy` (opcional) |
| **Virtualenv** | caminho do virtualenv | `/home/<seu-usuario>/.virtualenvs/nexbuy` |
| **Static files** | URL `/static/` | Directory `/home/<seu-usuario>/nexbuy_static` (recomendado) |
| **Static files** | URL `/media/` | Directory `/home/<seu-usuario>/nexbuy_dados/media` (**obrigatório**) |
| **Security** | Force HTTPS | **ligado** (a chave deslizante) |

Como preencher:

1. **Virtualenv**: clique no texto da seção Virtualenv para editar, cole o
   caminho e confirme (✓ ou Enter). A versão do Python do virtualenv tem de
   ser **a mesma** do web app (3.13) — o RESUMO mostra a do virtualenv (para
   trocar a do web app, veja o fim da parte 3).
2. **Static files**: são **duas linhas**. Em cada uma, clique na coluna
   **URL**, digite `/static/` (e na outra `/media/`), e na coluna
   **Directory** cole o caminho correspondente.
   - `/static/` = estilos, ícones e scripts. O próprio NEXBUY (WhiteNoise)
     já serve esses arquivos; o mapeamento só deixa mais rápido — vale
     fazer, mas a página não fica "sem estilo" por falta dele.
   - `/media/` = o logo da farmácia fictícia. **Sem este mapeamento o logo
     não aparece** (o NEXBUY não serve `/media/` sozinho).
3. **Security > Force HTTPS**: ligue a chave. Quem manda `http://` para
   `https://` é o PythonAnywhere. Por isso o `.env` tem
   `SECURE_SSL_REDIRECT=False` — redirecionar nos dois lugares dá erro de
   "too many redirects". (Esse é o aviso `security.W008` da etapa 6: é
   esperado.) **Não pule**: sem ela, quem digitar o endereço com `http://`
   vê a tela de login sem criptografia.
4. Clique no botão verde **Reload** no topo da aba Web
   (`Reload <seu-usuario>.pythonanywhere.com`) e espere a confirmação.

## 6. Testar

1. Abra `https://<seu-usuario>.pythonanywhere.com/` — deve aparecer a tela
   de login do NEXBUY, com estilo e o aviso "Ambiente de demonstração com
   dados fictícios. Entre com o usuário e a senha que você recebeu."
   (**sem** nenhum usuário nem senha escritos na tela).
2. Abra `https://<seu-usuario>.pythonanywhere.com/demo/apresentacao/` — a
   tela de abertura da apresentação. O botão **Iniciar demonstração** leva ao
   login com `demo_proprietario` já preenchido (a senha continua obrigatória).
3. Entre com **cada um dos 6 usuários, um a um**, com a senha definida na
   parte 4:

| Usuário | Nome | Perfil | O que mostrar / testar |
|---|---|---|---|
| `demo_proprietario` | Roberto Almeida | Proprietário | Visão de toda a operação; seletor de empresa (Farmácia Vida Plena e Drogaria Vida Plena Norte); Análise Financeira (DRE, Créditos × Débitos, Saúde Financeira); Central de Auditoria e Auditoria do Sistema; Centro de Configurações. |
| `demo_gerente` | Fernanda Costa | Gerente | Fila de **Aprovações** (1ª etapa do fluxo, até R$ 2.000); Agenda Financeira (liberada pelo perfil de acesso "Consulta Financeira"); Análise da Loja Centro. |
| `demo_financeiro` | Marcos Vinícius | Financeiro | Receitas, custos, contas a pagar, calendário; **Capacidade dos Compradores**; 2ª etapa das aprovações acima de R$ 2.000; Análise das duas lojas. |
| `demo_comprador` | Juliana Ramos | Comprador | Dashboard "posso comprar hoje?". Limite individual de **R$ 3.500 por DIA, em cada loja** (soma das compras do dia naquela loja, não teto por compra) — o card **Minha dotação do dia** mostra quanto ela já usou hoje (no cenário recém-criado, cerca de R$ 2.500). Teste: uma compra que caiba no que falta (ex.: R$ 500 → aprovada direto) e depois outra que passe do que sobrou (ex.: R$ 1.000 → vai para aprovação). |
| `demo_comprador2` | Pedro Henrique | Comprador | Limite individual de **R$ 2.000 por DIA, em cada loja** (a soma é feita loja por loja); trabalha nas duas lojas (Loja Centro e Loja Bairro). O cenário já lança compras dele HOJE na **Loja Bairro** (cerca de R$ 1.400), então teste na **Loja Centro**: R$ 1.500 é aprovada direto; mais R$ 1.500 no **mesmo dia e na mesma loja** pede aprovação (as duas somam R$ 3.000). Na Loja Bairro, a primeira de R$ 1.500 já vai para aprovação. |
| `demo_comprador3` | Carla Menezes | Comprador (**bloqueada**) | O dashboard abre em **"Bloqueado"**, a Central de Decisão avisa que as compras estão suspensas e qualquer compra dela sai **barrada na origem** — é o bloqueio feito pelo Financeiro. |

   Os valores "já usou hoje" dependem do dia em que o cenário foi gerado e
   da loja escolhida na compra: confira o card **Minha dotação do dia**
   antes de escolher o valor do teste. Em **sábado, domingo e feriado** o
   limite do dia é zero (regra do Calendário Operacional): qualquer compra
   vai para aprovação e o Comprador vê "Hoje não é dia de compra". Para
   testar limites, use um dia útil.

4. **Troca de perfil**: logado com qualquer um, clique no **seu nome** (canto
   superior direito) → **Trocar perfil de demonstração** → escolha um dos 6.
   O sistema sai de verdade e abre o login com o usuário já preenchido —
   digite a senha dele.
5. Com o Comprador, confira que **não aparece** nenhum dado financeiro
   sensível (faturamento, folha, aluguel, Análise Financeira).
6. Conferência opcional pelo console (conta EU: troque
   `pythonanywhere.com` por `eu.pythonanywhere.com`):
   - `curl -s -o /dev/null -w '%{http_code}\n' https://$USER.pythonanywhere.com/accounts/login/`
     → deve mostrar `200`.
   - `curl -s -o /dev/null -w '%{http_code} %{redirect_url}\n' http://$USER.pythonanywhere.com/accounts/login/`
     → deve mostrar `301 https://...` (é o Force HTTPS funcionando).

## 7. Mensagem pronta para a cliente

Mande **o link e os usuários por um canal** (ex.: e-mail) e **a senha por
outro** (ex.: WhatsApp ou ligação). Se você usou `--senha-individual`, mande
a **lista de senhas** (usuário → senha) por esse outro canal. Modelo:

> Olá, [nome]! Segue o acesso à **demonstração do NEXBUY**:
>
> **Endereço:** https://<seu-usuario>.pythonanywhere.com/
> (abra no Chrome, Edge ou Firefox, no computador)
>
> **Usuários** (cada um mostra o sistema do ponto de vista de um cargo):
> - `demo_proprietario` — Proprietário (visão geral, análise financeira, auditoria)
> - `demo_gerente` — Gerente (aprovações da loja)
> - `demo_financeiro` — Financeiro (receitas, custos, limites dos compradores)
> - `demo_comprador` — Compradora Juliana (limite de R$ 3.500 por dia)
> - `demo_comprador2` — Comprador Pedro (limite de R$ 2.000 por dia, somando as compras do dia)
> - `demo_comprador3` — Compradora Carla (está bloqueada — para ver como fica)
>
> A senha (ou as senhas, uma por usuário) vou te mandar por mensagem separada.
>
> **O que você pode testar:** entrar com cada usuário, lançar compras e
> provisões, aprovar e reprovar, ver a agenda, os relatórios e a análise
> financeira. Pelo menu com o seu nome (canto superior direito) dá para
> **trocar de perfil** sem digitar o usuário de novo.
>
> **Importante:** é um ambiente de **demonstração**, com dados **fictícios**
> de uma farmácia inventada. **Não lance nenhum dado real** da farmácia
> (faturamento, fornecedores, CPFs etc.). O que for lançado aqui pode ser
> apagado quando atualizarmos o cenário. O primeiro acesso do dia pode
> demorar alguns segundos a mais.
>
> Qualquer dúvida, é só chamar!

## 8. Rotina mensal (não pule)

**Lembrete a cada 3 semanas** (ponha na agenda): entre no PythonAnywhere,
aba **Web**, e clique em **"Run until 1 month from today"**. Sem isso o site
expira em 1 mês (o PythonAnywhere manda e-mail antes). Se expirar, nada é
apagado — basta clicar no mesmo botão para voltar. Atenção: conta **sem
nenhum acesso por muitos meses** pode ser apagada pelo PythonAnywhere (os
termos falam em 6 meses de inatividade).

**Renovar o cenário (datas de hoje):** o cenário fictício é montado **em
relação à data em que foi gerado** — "hoje", "amanhã", as cores do
calendário, a provisão de amanhã e os 12 meses de histórico. Com o passar dos
dias ele "envelhece", e **na virada do mês** o mês novo pode aparecer sem
compras, sem receita ou marcado como "dados incompletos" na Análise
Financeira. Para renovar:

```bash
cd ~/nexbuy
bash deploy/pythonanywhere/atualizar_demo.sh --renovar-cenario
```

- **Isso APAGA** as compras, provisões, aprovações, lançamentos financeiros e
  a auditoria da empresa de demonstração — **inclusive o que a cliente
  lançou**. Combine com ela antes. O script pede para digitar `SIM`.
- As **senhas são mantidas** (a cliente continua entrando com as mesmas).
- Os 6 usuários voltam **ativos** (se a cliente desativou algum em Usuários
  e Permissões, ele volta a entrar).
- Antes de apagar, uma cópia do banco vai para `~/nexbuy_backups/`.
- Quando: no início de cada mês, ou na véspera de uma apresentação.
- O cenário gasta CPU do console: evite rodar várias vezes no mesmo dia (se
  passar da cota, só fica mais lento).

## 9. Atualizar o código

1. No PC, gere o zip de novo (parte 1).
2. Aba **Files** → **Upload a file** → envie o zip novo para
   `/home/<seu-usuario>/` (substitua o antigo).
3. No console Bash, descompacte numa pasta **limpa** (um `unzip` por cima
   não apaga arquivos que saíram do código numa versão nova, como migrações
   e telas antigas) e traga o `.env` de volta:

```bash
cd ~
mv nexbuy nexbuy_antigo
unzip -o NEXBUY_PYTHONANYWHERE.zip
cp nexbuy_antigo/.env nexbuy/.env
chmod 600 nexbuy/.env
cd ~/nexbuy
bash deploy/pythonanywhere/atualizar_demo.sh
```

4. Abra o site e confira. Deu tudo certo? Apague a pasta antiga (ela tem
   uma cópia do `.env`): `rm -rf ~/nexbuy_antigo`

O `atualizar_demo.sh` faz backup do banco, instala dependências novas (se
houver), aplica as migrações, atualiza os estilos, confere as senhas (sem
trocar nenhuma), recarrega o site e confere o Force HTTPS (sem apagar nada
do cenário; para renovar junto, acrescente `--renovar-cenario`). O banco, os
uploads e o virtualenv ficam fora da pasta do código e **não são tocados**.

Se aparecer `$'\r': command not found`, algum script foi salvo com fim de
linha do Windows. Corrija com:
`sed -i 's/\r$//' ~/nexbuy/deploy/pythonanywhere/*.sh` e rode de novo.

## 10. Backup

```bash
cd ~/nexbuy
bash deploy/pythonanywhere/backup_demo.sh
```

- Faz uma cópia **íntegra** do banco (pela API de backup do SQLite, com o
  site no ar) em `~/nexbuy_backups/nexbuy_AAAA-MM-DD_HHMM.sqlite3`.
- Guarda só as **5** cópias mais recentes (por causa dos 512 MB).
- **Baixar para o PC:** aba **Files** → pasta `nexbuy_backups` → ícone de
  download ao lado do arquivo.
- O `atualizar_demo.sh` já faz um backup antes de mexer no banco.

## 11. Problemas comuns

**Onde ver o erro:** aba **Web** → seção **Log files** → **Error log** (o
erro mais recente fica no **fim** do arquivo). Pelo console:
`tail -n 50 /var/log/$USER.pythonanywhere.com.error.log`
(e `.server.log` para o log do servidor; conta EU:
`/var/log/$USER.eu.pythonanywhere.com.error.log`).

Na tabela, `<seu-host>` é o endereço do site sem `https://`:
`<seu-usuario>.pythonanywhere.com` (conta US) ou
`<seu-usuario>.eu.pythonanywhere.com` (conta EU).

| Sintoma | Causa provável | Solução |
|---|---|---|
| Página sem estilo (tudo branco, sem cores) | O `collectstatic` não rodou, ou o `STATIC_ROOT` do `.env` aponta para outra pasta (o NEXBUY serve os estilos sozinho, mesmo sem o mapeamento de `/static/`) | Rode `bash deploy/pythonanywhere/atualizar_demo.sh`; confira `STATIC_ROOT=/home/<seu-usuario>/nexbuy_static` no `.env` e o mapeamento `/static/` da parte 5; Reload. |
| Logo da farmácia não aparece | Falta o mapeamento de `/media/` | Static files: `/media/` → `/home/<seu-usuario>/nexbuy_dados/media`; Reload. |
| **Bad Request (400)** / `DisallowedHost` no log | Endereço diferente do `ALLOWED_HOSTS` do `.env` | Conta EU: rode `bash deploy/pythonanywhere/preparar.sh --eu` (ele corrige o `.env` sozinho). À mão: em `~/nexbuy/.env`, `ALLOWED_HOSTS=<seu-host>` (sem `https://`) **e** `CSRF_TRUSTED_ORIGINS=https://<seu-host>`; Reload. |
| **"Sua sessão expirou"** (403, CSRF) ao entrar | Página aberta há muito tempo, endereço com `http://`, cookies bloqueados, ou `CSRF_TRUSTED_ORIGINS` errado | Recarregue a página (F5) e entre de novo; use sempre `https://`; confira `CSRF_TRUSTED_ORIGINS=https://<seu-host>` no `.env`; Reload. |
| **"Too many redirects"** (loop de redirecionamento) | HTTPS forçado em dois lugares | No `.env`: `SECURE_SSL_REDIRECT=False`; Force HTTPS ligado na aba Web; Reload; limpe o cache do navegador. |
| **"Something went wrong :-("** (página do PythonAnywhere) | O site não conseguiu carregar | Veja o Error log. Causas comuns: Virtualenv errado ou com Python diferente do web app (parte 3, fim); `.env` ausente (erro de `SECRET_KEY`); WSGI sem o conteúdo do NEXBUY — rode `bash deploy/pythonanywhere/preparar.sh` de novo, **sem** `--trocar-senha` (as senhas não mudam), ou use o modelo `deploy/pythonanywhere/wsgi_pythonanywhere.py`. |
| "There was an error reloading" | O teste automático do Reload falhou (limite de 20 s) | Veja o Error log e o Server log; corrija e clique em Reload de novo. |
| Site fora do ar / página do PythonAnywhere dizendo que o site foi desativado | Expirou (1 mês sem "Run until...") | Aba Web → **Run until 1 month from today**. Nada foi apagado. |
| Site lento | Plano grátis: 1 worker, servidor nos EUA, banco em disco de rede | Normal para amostragem. Evite muitas pessoas ao mesmo tempo. O console muito lento = cota diária de CPU do console acabou (volta no dia seguinte). |
| `Disk quota exceeded` | Disco cheio (512 MB) | `rm -rf ~/.cache/*`, `rm ~/NEXBUY_PYTHONANYWHERE.zip`, apague backups antigos em `~/nexbuy_backups/` e pastas `~/nexbuy_antigo`; `/tmp` também conta (`rm -rf /tmp/*`). |
| Um usuário diz "usuário ou senha inválidos" mesmo com a senha certa | A cliente (como Proprietária) desativou esse usuário em Usuários e Permissões | Rode `cd ~/nexbuy && ~/.virtualenvs/nexbuy/bin/python manage.py definir_senha_demo --verificar` — ele lista os usuários **DESATIVADOS**. Reative logado como `demo_proprietario` (Usuários e Permissões) ou renove o cenário (parte 8), que reativa os 6. |
| A cliente esqueceu a senha | Senha perdida | No console: `cd ~/nexbuy && ~/.virtualenvs/nexbuy/bin/python manage.py definir_senha_demo --usuarios demo_gerente --gerar` (troque o usuário) e mande a senha nova. |
| `Não achei o Python 3.13` | Conta numa imagem de sistema antiga | Página **Account** → troque a imagem de sistema para a mais nova (ajuda: help.pythonanywhere.com/pages/ChangingSystemImage/) e rode o script de novo (as senhas não mudam). |
| O script diz que o arquivo WSGI não existe | O web app não foi criado (ou a conta é da região EU) | Faça a parte 3 e rode o script de novo (as senhas não mudam). Conta EU: `bash deploy/pythonanywhere/preparar.sh --eu`. |

**A conferir (não confirmado oficialmente):**

- Conta **EU**: o nome do arquivo WSGI foi deduzido pela regra oficial
  (`/var/www/<seu-usuario>_eu_pythonanywhere_com_wsgi.py`). Se o script não
  achar, abra o link do arquivo WSGI na seção **Code** da aba Web, apague o
  conteúdo, cole o `deploy/pythonanywhere/wsgi_pythonanywhere.py` (trocando
  `SEU_USUARIO`), salve e clique em Reload.
- Se o PythonAnywhere repassa o cabeçalho `X-Forwarded-Proto`: o
  `atualizar_demo.sh` testa isso no fim e avisa. Em qualquer caso, **deixe
  `SECURE_SSL_REDIRECT=False`** — o Force HTTPS já resolve.
- A auditoria do NEXBUY grava o IP do balanceador do PythonAnywhere (o
  endereço que chega ao site), não o do visitante — aceitável numa
  demonstração.

## 12. Tirar do ar / apagar

- **Pausar:** simplesmente não clique em "Run until 1 month from today" — o
  site sai do ar sozinho no fim do prazo, sem apagar nada.
- **Apagar o site:** aba **Web** → no fim da página, o botão para apagar o
  web app (Delete). Isso não apaga os arquivos.
- **Apagar os arquivos e o banco** (no console Bash):
  `rm -rf ~/nexbuy ~/nexbuy_antigo ~/nexbuy_zip ~/nexbuy_dados ~/nexbuy_static ~/nexbuy_backups ~/.virtualenvs/nexbuy ~/nexbuy_wsgi_original.py`
- **Encerrar a conta:** página **Account** do PythonAnywhere (baixe antes o
  que quiser guardar, pela aba Files).

## 13. Segurança e LGPD

- **Nunca** `DEBUG=True` no servidor (mostraria código e configurações nas
  páginas de erro). O script se recusa a continuar se encontrar isso — em
  qualquer formato que o NEXBUY leia (`DEBUG=True`, `export DEBUG=True`,
  `DEBUG = True`...).
- **Nunca** coloque `ALLOW_SEED_IN_PRODUCTION` no `.env` (valeria para o
  site inteiro). Os scripts passam essa autorização **só** no comando do
  seed.
- **Senha forte** para os usuários de demonstração (de preferência gerada
  com `--gerar-senha`), **diferente** da senha pública da demonstração
  local, enviada por um canal diferente do link. O NEXBUY recusa a senha
  pública e as variações dela em qualquer troca de senha (inclusive em Meu
  Perfil). A senha pública é **desativada** logo depois de criar o cenário:
  o site nunca a aceita, nem se a troca de senha for interrompida. O script
  confere que **nenhum usuário ativo** ficou com a senha pública
  (`definir_senha_demo --verificar` — se aparecer um superusuário ou
  usuário de outra empresa na lista, troque a senha dele à mão, como a
  mensagem explica).
- **Force HTTPS ligado** (parte 5): os scripts conferem e avisam se o
  `http://` não estiver redirecionando para `https://`.
- **Não divulgue o link** além da cliente. A tela de login não mostra
  usuários nem senha; os buscadores são orientados a não indexar
  (`/robots.txt` e `noindex`).
- **Nada de dado real da farmácia no plano grátis**: o servidor fica nos EUA,
  sem contrato de tratamento de dados — é só para amostragem com dados
  fictícios. Dados reais só na instalação de produção (parte 15).
- O **Primeiro Acesso fica fechado** (`INITIAL_SETUP_TOKEN` vazio): ninguém
  cria uma empresa nova pela internet.
- O `.env` (com a chave secreta) fica só no servidor, com permissão 600, e
  **nunca** vai para o zip nem para o GitHub. Cópias dele (como a pasta
  `~/nexbuy_antigo` da parte 9) devem ser apagadas depois de usadas.
- A senha da **conta do PythonAnywhere** é só de quem administra a
  demonstração — nunca a envie à cliente.

## 14. Apêndice: usar o GitHub em vez do zip

Se o código já estiver num **repositório privado** do GitHub (o mesmo da
instalação na Hostinger), dá para buscar direto de lá (o `github.com` está
liberado no plano grátis):

1. No GitHub: **Settings** (da sua conta) → **Developer settings** →
   **Personal access tokens** → **Fine-grained tokens** → **Generate new
   token**. Dê acesso **só ao repositório do NEXBUY**, permissão
   **Contents: Read-only**, e validade curta (ex.: 7 dias).
2. No console Bash do PythonAnywhere (se a pasta `~/nexbuy` já existir por
   causa do zip, renomeie antes: `mv ~/nexbuy ~/nexbuy_zip`):

```bash
cd ~
git clone https://github.com/<conta>/<repositorio>.git nexbuy
```

   Quando pedir **Username**, digite seu usuário do GitHub; em **Password**,
   **cole o token** (não aparece nada enquanto cola — é normal). Não coloque
   o token dentro do endereço (`https://TOKEN@github.com/...`): ele ficaria
   gravado na configuração do git.
3. Se você renomeou a pasta do zip no passo 2, traga o `.env` dela (assim a
   chave secreta e o endereço do Admin técnico continuam os mesmos) e apague
   a pasta antiga:

```bash
cp ~/nexbuy_zip/.env ~/nexbuy/.env
chmod 600 ~/nexbuy/.env
rm -rf ~/nexbuy_zip
```

4. Continue na parte 4.4 a partir de `cd ~/nexbuy`.
5. Depois: confira que o token **não ficou** na configuração
   (`git -C ~/nexbuy remote -v` deve mostrar só `https://github.com/...`) e
   **apague o token** no GitHub. Para atualizar no futuro: gere um token
   novo, `cd ~/nexbuy && git pull`, e rode o `atualizar_demo.sh`.

## 15. E a Hostinger depois?

- A demonstração no PythonAnywhere é **descartável**: serve para a cliente
  experimentar. O banco dela tem só a farmácia fictícia e os usuários de
  demonstração — **nunca** leve esse banco para a produção.
- A instalação de verdade segue `docs/DEPLOY_HOSTINGER_GITHUB.md`: VPS
  Hostinger com nginx, HTTPS próprio, backups diários, `DEMO_MODE=False` e
  banco **vazio**, começando pelo **Primeiro Acesso** com o token de
  implantação.
- O **código é o mesmo** (o zip sai da mesma árvore); mudam só as
  configurações: na VPS o nginx faz o HTTPS e serve os arquivos estáticos, o
  SQLite usa o modo WAL (disco local) e o seed é bloqueado.
- Quando a cliente fechar, desligue a demonstração (parte 12) ou deixe-a
  expirar.
