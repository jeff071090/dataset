> **Documento histórico (15/08/2026).** Registra a microsprint de navegação V4.
> O escopo mudou em 25/09/2026: o NEXBUY é 100% web, **não haverá integração
> com ERP/Inovafarma nem IA**, e a única integração prevista é o DDA (ainda não
> conectada). O que vale hoje está no `README.md` e em `docs/`.

# NEXBUY — Microsprint de Navegação V4 · Manifesto

## 1. O que mudou da V3 para a V4 (lista completa)

**Novos** (6): `core/navegacao.py` · `core/tests_navegacao_v4.py` ·
`templates/partials/_sidebar.html` · `templates/partials/_breadcrumbs.html`
· `templates/partials/_mobile_nav.html` · pasta
`qa_navegacao_v4_screenshots/` (28 PNGs reais).

**Editados** (11): `templates/base.html` · `core/context_processors.py` ·
`nexbuy/settings.py` (registro do context processor) ·
`static/css/nexbuy.css` (bloco só-acréscimo) · `static/js/nexbuy.js` ·
`templates/dashboard/proprietario.html` · `templates/dashboard/financeiro.html`
· `templates/dashboard/comprador.html` · `dashboard/views.py`
(2 variáveis de contexto no dashboard do Proprietário) ·
`NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md` (seção da nova navegação) ·
`core/tests_pacote_demo.py` (1 teste ajustado — não removido — para o
comando novo `test --settings=nexbuy.settings_demo` exigido pela V4;
justificativa formal em `NEXBUY_MICROSPRINT_NAVEGACAO_TESTES_V4.md`).

Justificativa de cada alteração: ver
`NEXBUY_MICROSPRINT_NAVEGACAO_IMPLEMENTACAO_V4.md` (tabela arquivo a
arquivo, com a seção do prompt que a exigiu).

## 2. O que NÃO mudou — prova por hash

Comparação SHA-256 arquivo a arquivo entre a V3 aprovada e a V4:
**91 arquivos do núcleo funcional são byte a byte idênticos**, incluindo:

- TODAS as migrations de todos os apps (as 72 aplicadas são as mesmas —
  nenhuma migração nova foi criada);
- `finance_engine/` completo (motor financeiro e cálculos);
- `core/models.py`, `usuarios/models.py`, `compras/models.py`,
  `financeiro/models.py`, `gestao_compras/models.py` (schema intacto);
- `core/permissions.py` (RBAC/catálogo intactos — nenhuma permissão
  ampliada);
- `financeiro/services.py`, `compras/services.py`,
  `gestao_compras/services.py`, `empresas/services_checklist.py`
  (regras de negócio intactas);
- `core/views_primeiro_acesso.py` e `core/forms_primeiro_acesso.py`
  (Primeiro Acesso Seguro intacto);
- `manage.py`, `requirements.txt` (dependências intactas);
- os 3 launchers `.bat` da demo e `nexbuy/settings_demo.py`
  (isolamento da demo intacto).

A única view alterada (`dashboard/views.py`) apenas soma dois números já
calculados e consulta o serviço de checklist EXISTENTE para decidir o
rótulo do botão primário — nenhuma regra de cálculo, aprovação, limite ou
isolamento foi tocada.

## 3. Contagens finais de testes

- Árvore: **699/699 OK** (settings padrão) e **699/699 OK**
  (`settings_demo`) — 0 falhas, 0 erros, 0 skips.
- Cliente-ready V4 (de dentro do ZIP extraído): **684** ≥ 652 ✔
  (`test_run_CLIENT_V4.txt`).
- Demo V4 (de dentro do ZIP extraído): **696** ≥ 664 ✔
  (`test_run_DEMO_V4.txt`).
- 72 migrações aplicadas; `check` e `makemigrations --check --dry-run`
  limpos nos dois pacotes.

## 4. Demo e cliente-ready

- Demo: launchers, `settings_demo`, bancos/mídia isolados, credenciais
  fictícias, seed idempotente e os dois modos (`DEMO_MODE=False` limpo /
  `True` pronto) preservados byte a byte; roteiro atualizado com a nova
  navegação.
- Cliente-ready: banco limpo (o MESMO `db.sqlite3` da V3, hash-idêntico),
  Primeiro Acesso Seguro, nenhum usuário/dado fictício, nenhum segredo.
- DDA, ERP/Inovafarma e IA continuam **não conectados** (contratos
  abstratos apenas; telas honestas "Não conectado").

## 5. Limitações que permaneceram

- Só o caminho SQLite validado de ponta a ponta (PostgreSQL preparado por
  configuração, não testado).
- Edição de CNPJ/desativação da própria Empresa (nível Grupo) segue via
  `/admin`, por decisão documentada nas etapas anteriores.
- Sem teste de carga multiusuário em escala.
- O estado aberto/fechado dos grupos da sidebar não persiste entre
  páginas além do grupo da rota atual (decisão: o servidor sempre abre o
  grupo correto da página — persistência por usuário exigiria estado
  extra sem ganho claro).
- Páginas transversais (busca, notificações, Meu Perfil, Bem-vindo) têm
  breadcrumb próprio mas nenhum grupo da sidebar ativo — por definição
  (Seção 7.1).
