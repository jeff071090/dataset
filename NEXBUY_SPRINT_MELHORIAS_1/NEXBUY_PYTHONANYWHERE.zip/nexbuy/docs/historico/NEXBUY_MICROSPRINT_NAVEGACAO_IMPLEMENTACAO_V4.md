> **Documento histórico (15/08/2026).** Registra a microsprint de navegação V4.
> O escopo mudou em 25/09/2026: o NEXBUY é 100% web, **não haverá integração
> com ERP/Inovafarma nem IA**, e a única integração prevista é o DDA (ainda não
> conectada). O que vale hoje está no `README.md` e em `docs/`.

# NEXBUY — Microsprint de Navegação V4 · Implementação

Base: Etapa 02 FINAL V3 aprovada (hashes conferidos antes de editar).
Escopo: navegação e UX — **zero** mudança em models, migrations, motor
financeiro, permissões ou regras de negócio (prova por hash no Manifesto).

## Arquivos NOVOS

| Arquivo | O que é |
|---|---|
| `core/navegacao.py` | Fonte única de verdade da navegação: estrutura declarativa por perfil (grupos, itens, ícones), gate de permissão idêntico ao das views (`permissao` RBAC quando a view usa `permissao_required`; `perfis` quando usa `perfil_required` — impossível renderizar link 403), resolutor de estado ativo por `view_name`/prefixo, trilhas de breadcrumb (`TRILHAS`) e a barra mobile (≤3 destinos + Menu, com reservas por perfil). |
| `templates/partials/_sidebar.html` | Sidebar agrupada: links únicos + grupos recolhíveis (`<button data-nx-grupo-toggle aria-expanded aria-controls>`); o grupo da rota atual chega aberto do servidor; item ativo com `aria-current="page"`. |
| `templates/partials/_breadcrumbs.html` | `<nav aria-label="Navegação estrutural">` com `aria-current="page"` no último nível; níveis anteriores viram link só quando o usuário tem a permissão do destino; oculto no Dashboard inicial. |
| `templates/partials/_mobile_nav.html` | Barra inferior fixa (só < lg): até 3 destinos do perfil + botão Menu (mesmo gancho `data-nx-sidebar-toggle` da sidebar off-canvas); estado ativo; safe-area. |
| `core/tests_navegacao_v4.py` | 32 testes novos (Seção 12) — detalhados em `NEXBUY_MICROSPRINT_NAVEGACAO_TESTES_V4.md`. |
| `qa_navegacao_v4_screenshots/` | 28 capturas reais (Playwright/Chromium) nos 4 viewports exigidos. |

## Arquivos EDITADOS

| Arquivo | Mudança | Por quê |
|---|---|---|
| `templates/base.html` | Menu inline por perfil (130+ linhas de `{% if %}`) substituído por `{% include "partials/_sidebar.html" %}`; breadcrumbs incluídos no topo do `<main>`; barra mobile incluída após o layout; item "Perfil" removido da sidebar (acesso segue no menu de conta); `data-perfil` no `<body>` (tour por perfil); cache-bust `?navv4`. | Seções 6, 7, 9 e 11.1 — fim do bloco condicional monolítico. |
| `core/context_processors.py` | Novo processor `navegacao` injetando `nav_grupos`, `nav_mobile` e `breadcrumbs` (só autenticado; custo: as poucas consultas de `permissoes_do_usuario`, zero para perfis legados). | Seção 7.1 — mapeamento centralizado e testável. |
| `nexbuy/settings.py` | Registro do context processor `core.context_processors.navegacao`. | Idem. |
| `static/css/nexbuy.css` | Bloco V4 APENAS ACRESCENTADO ao final: grupos recolhíveis (caret, sub-lista, foco visível), breadcrumbs, barra mobile (+ `env(safe-area-inset-bottom)`, `padding-bottom` do conteúdo < lg), modo sidebar-recolhida para grupos, `prefers-reduced-motion`. Nenhuma regra anterior alterada. | Seções 7.2, 9 e 11.2/11.3. |
| `static/js/nexbuy.js` | (1) TODOS os `[data-nx-sidebar-toggle]` compartilham o estado (topbar + botão Menu mobile); (2) Esc/backdrop/clique em item fecham o off-canvas; (3) toggle dos grupos com `aria-expanded` (com a sidebar recolhida, clicar num grupo primeiro reexpande); (4) `TOUR_STEPS_POR_PERFIL` — passos por perfil, cada um com link "Abrir esta função", sem mostrar funções que o perfil não tem; storage/supressão preservados. | Seções 6.1, 9.3, 10. |
| `templates/dashboard/proprietario.html` | Ação primária contextual: `Revisar Aprovações (N)` → `Continuar Implantação` → `Nova Compra`; "Novo Usuário" virou atalho secundário apontando DIRETO para `ncc:usuario_novo`. | Seções 8.1/8.2 (o botão apontava para a lista). |
| `dashboard/views.py` | `_dashboard_proprietario` passa `aprovacoes_pendentes_total` (soma dos KPIs que a view já calculava) e `implantacao_incompleta` (resumo do serviço de checklist existente). Nenhuma regra nova, nenhuma pendência inventada. | Seção 8.2. |
| `templates/dashboard/financeiro.html` | Rótulo do botão primário corrigido para **Novo Custo Fixo** (o destino sempre foi `financeiro:custofixo_create`). | Seção 8.1 — rótulo amplo para destino específico. |
| `templates/dashboard/comprador.html` | Tooltips + linha auxiliar única explicando **Compra** (registra o que já aconteceu) × **Provisão** (planeja/reserva valor futuro). Comportamentos intactos. | Seção 8.3. |
| `NEXBUY_ROTEIRO_DEMO_CLIENTE_ETAPA_02.md` | Nova seção "A nova navegação (V4)": grupos do Proprietário, alternância de perfil, Compra × Provisão, breadcrumbs, navegação mobile e integrações não conectadas. | Seção 14.1. |

## Nomenclatura padronizada (Seção 8.3)

`Calendário` → **Calendário de Compras** (provisões) e **Calendário
Financeiro** (Financeiro); `Histórico` → **Histórico de Compras**;
`Compradores` → **Compradores e Limites**; `Empresas` → **Empresas e
Filiais**; `Usuários` → **Usuários e Permissões**. Títulos internos das
páginas não mudaram — só a navegação.

## Estrutura final por perfil (1º nível)

- **Proprietário (6)**: Início · Compras · Financeiro · Gestão ·
  Relatórios · Configurações — era 14 links planos.
- **Financeiro (6)**: Início · Agenda Financeira · Calendário Financeiro ·
  Compradores e Limites · Planejamento (grupo com 8 itens) · Relatórios.
- **Gerente (4+1)**: Início · Aprovações · Indicadores · Relatórios
  (+ Agenda Financeira só com a permissão aditiva).
- **Comprador (5+2)**: Início · Nova Compra · Planejamento de Compras
  (Nova Provisão + Calendário de Compras) · Histórico de Compras ·
  Simulador (+ Agenda/Timeline só com permissão aditiva).
