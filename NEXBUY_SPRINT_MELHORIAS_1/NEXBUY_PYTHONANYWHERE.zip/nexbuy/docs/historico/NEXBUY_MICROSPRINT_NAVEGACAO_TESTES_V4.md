> **Documento histórico (15/08/2026).** Registra a microsprint de navegação V4.
> O escopo mudou em 25/09/2026: o NEXBUY é 100% web, **não haverá integração
> com ERP/Inovafarma nem IA**, e a única integração prevista é o DDA (ainda não
> conectada). O que vale hoje está no `README.md` e em `docs/`.

# NEXBUY — Microsprint de Navegação V4 · Testes

## Testes novos: `core/tests_navegacao_v4.py` — 32 testes

Todos rodam contra o HTML REAL renderizado (cenário quase-vazio criado
pelo fluxo verdadeiro de Primeiro Acesso + 1 usuário por perfil), nunca
contra a estrutura em memória isolada.

### 12.1 — Menus por perfil (`MenusPorPerfilTestCase`, 6 testes)
- Proprietário com exatamente 6 destinos de 1º nível (1 link + 5 grupos)
  e TODOS os 22 itens reagrupados presentes (nenhum item autorizado perdido);
- Comprador sem itens de Gestão/Financeiro/aditivos não concedidos, com a
  navegação operacional completa;
- Gerente com menu curto, sem funções administrativas/financeiras;
- Financeiro com grupo Planejamento único e sem destino duplicado
  (cada href aparece 1 vez na sidebar);
- RBAC aditivo: conceder `agenda.ver` a um Comprador faz o item aparecer;
- "Perfil" fora da sidebar, mas `Meu Perfil`/`Sair` no menu de conta.

### 12.2 — Estado ativo (`EstadoAtivoTestCase`, 12 testes)
Rotas verificadas com grupo pai aberto (`aria-expanded="true"`) e item
filho ativo (`aria-current="page"`): `/` · `/ncc/filiais/` ·
`/ncc/filiais/nova/` · `/ncc/integracoes/` · `/ncc/central-auditoria/` ·
`/ncc/usuarios/` + `/ncc/usuarios/novo/` · `/financeiro/planejamento/` ·
`/financeiro/receitas/` · `/financeiro/custos-fixos/` ·
`/financeiro/calendario-operacional/` · `/financeiro/contas-a-pagar/` ·
`/compras/relatorios/por-filial/` (ativa Relatórios e NÃO Compras) ·
`/gestao-compras/` · timeline de uma provisão REAL criada pelo fluxo
completo do formulário · `/aprovacoes/`. Cobre os dois perfis relevantes
(Proprietário e Financeiro) nas rotas de Planejamento.

### 12.3 — Breadcrumbs (`BreadcrumbsTestCase`, 4 testes)
- Ausente no Dashboard; presente nas internas com `aria-label` e
  `aria-current`; textos esperados (Novo Custo Fixo, Nova Filial, Novo
  Usuário, Central de Auditoria, Compras por Filial);
- Nível anterior é link funcional (href real, nunca `history.back()`);
- Trilha começa em Início com link; respeita permissões (nível sem
  permissão vira texto).

### 12.4 — Ações rápidas (`AcoesRapidasTestCase`, 5 testes)
- `Novo Usuário` → `/ncc/usuarios/novo/` (cadastro direto);
- Ação primária contextual: `Continuar Implantação` no cenário vazio e
  `Revisar Aprovações` com uma Compra PENDENTE real criada no teste;
- Rótulo `Novo Custo Fixo` no endpoint de custo fixo (e o rótulo antigo
  ausente da página);
- Explicação Compra × Provisão visível para o Comprador.

### 12.5 — Navegação mobile (`NavegacaoMobileTestCase`, 5 testes)
- ≤ 4 ações por perfil (3 destinos + Menu conectado à sidebar);
- Destinos corretos por perfil; estado ativo; barra ausente em páginas
  não autenticadas; Comprador sem links financeiros na barra.

Nota de processo: o teste do rótulo do Financeiro pegou um bug real na
primeira execução — comentário `{# #}` multi-linha (inválido no Django)
vazando como texto literal no HTML; corrigido para `{% comment %}` antes
de qualquer entrega.

## Ajuste com justificativa técnica formal (Seção 12.6)

**`core/tests_pacote_demo.py::test_database_name_e_arquivo_de_demo_nunca_db_sqlite3`**
— ajustado (não removido, não enfraquecido). Motivo: a V4 passou a exigir
a execução `python manage.py test --settings=nexbuy.settings_demo`
(comando novo desta sprint; V2/V3 validavam a demo com o settings
padrão). Sob esse runner, o Django troca legitimamente o
`DATABASES["default"]["NAME"]` ativo pelo banco DE TESTE (`:memory:`/
`file:memorydb...`), e a asserção original — comparar o atributo do
módulo com `db_demo_cliente.sqlite3` — falhava por design do próprio
test runner, não por qualquer regressão (o `settings_demo.py` é
hash-idêntico à V3). O teste agora: (a) mantém a proibição absoluta de
`db.sqlite3`; (b) GANHOU uma verificação nova no código-fonte do módulo
(`BASE_DIR / "db_demo_cliente.sqlite3"` presente na linha real, imune a
override); (c) aceita em runtime o nome da demo OU um banco de teste
reconhecível do Django — nunca outro arquivo real. Intenção preservada e
reforçada; verificado verde nos dois settings, isolado e na suíte cheia.

## Regressão integral (Seção 12.6) — resultados reais

| Execução | Encontrados | Resultado |
|---|---|---|
| Árvore de trabalho, settings padrão | **699** (667 da V3 + 32 novos) | `Ran 699 tests — OK`, 0 falhas, 0 erros, 0 skips |
| Árvore de trabalho, `--settings=nexbuy.settings_demo` | **699** | `OK`, 0 falhas/erros/skips |
| Pacote cliente-ready V4 extraído do ZIP | **684** (652 + 32) | `test_run_CLIENT_V4.txt` |
| Pacote demo V4 extraído do ZIP | **696** (664 + 32) | `test_run_DEMO_V4.txt` |

`manage.py check`: 0 issues. `makemigrations --check --dry-run`: sem
alterações. **Nenhuma migração nova** — as 72 continuam exatamente as
mesmas (hash-idênticas à V3). Nenhum teste existente foi removido ou
enfraquecido; nenhum skip novo.

As contagens dos pacotes diferem da árvore porque cada ZIP embarca apenas
os testes executáveis com os arquivos presentes nele (regra da V2/V3):
cliente-ready sem `core/tests_pacote_demo.py` (12) e nenhum pacote com
`core/tests_readme_cliente_ready.py` (3, QA da árvore).
