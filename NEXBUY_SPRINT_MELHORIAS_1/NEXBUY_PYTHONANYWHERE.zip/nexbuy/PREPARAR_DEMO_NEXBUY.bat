@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ==================================================
echo   NEXBUY - PREPARAR demonstracao comercial
echo ==================================================
echo.
echo Este preparador NUNCA toca no banco principal (db.sqlite3) nem na
echo pasta media\ principal. Ele usa SOMENTE db_demo_cliente.sqlite3 e
echo media_demo_cliente\ (nexbuy.settings_demo), isolados do ambiente real.
echo Todos os dados criados sao FICTICIOS (Farmacia Vida Plena).
echo.

REM DEBUG=True somente para o processo deste terminal (nunca gravado em
REM .env). O seed_demo e bloqueado automaticamente com DEBUG=False
REM (core/utils.py::abortar_seed_em_producao).
set DEBUG=True
set DEMO_MODE=True

REM --- 1. Validar Python 3.12+ no PATH --------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado no PATH.
    echo Solucao: instale o Python 3.12 ou mais recente em https://www.python.org/
    echo e marque a opcao "Add python.exe to PATH" na instalacao.
    pause
    exit /b 1
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Versao do Python incompativel. E necessario Python 3.12 ou mais recente.
    python --version
    pause
    exit /b 1
)
echo [1/6] Python OK:
python --version

REM --- 2. Ambiente virtual (criar ou reutilizar) ----------------------------
if not exist "venv\Scripts\python.exe" (
    echo [2/6] Criando ambiente virtual...
    python -m venv venv
    if errorlevel 1 (
        echo [ERRO] Falha ao criar o ambiente virtual.
        echo Solucao: confira se ha espaco em disco e permissao de escrita nesta pasta.
        pause
        exit /b 1
    )
) else (
    echo [2/6] Ambiente virtual ja existe - reutilizando.
)

REM --- 3. Dependencias (instalar somente quando necessario) ------------------
venv\Scripts\python.exe -c "import django" >nul 2>&1
if errorlevel 1 (
    echo [3/6] Instalando dependencias...
    venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERRO] Falha ao instalar as dependencias.
        echo Solucao: verifique a conexao de rede desta maquina ou rode
        echo   venv\Scripts\python.exe -m pip install -r requirements.txt
        echo manualmente para ver o erro completo.
        pause
        exit /b 1
    )
) else (
    echo [3/6] Dependencias ja instaladas.
)

REM --- 4. Migracoes SOMENTE no banco de demo --------------------------------
echo [4/6] Aplicando migracoes no banco de demo (db_demo_cliente.sqlite3)...
venv\Scripts\python.exe manage.py migrate --noinput --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao aplicar as migracoes no banco de demo.
    echo O banco principal db.sqlite3 NAO foi tocado.
    pause
    exit /b 1
)

REM --- 5. Cenario ficticio (idempotente: sempre o mesmo cenario) -------------
echo [5/6] Gerando/atualizando o cenario ficticio (seed_demo)...
echo Comando idempotente: pode rodar de novo a qualquer momento sem duplicar
echo nada - a historia e sempre recriada em relacao a data de hoje.
venv\Scripts\python.exe manage.py seed_demo --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] Falha ao gerar o cenario de demonstracao.
    echo Veja o erro acima. O banco principal db.sqlite3 NAO foi tocado.
    pause
    exit /b 1
)

REM --- 6. Verificacao final --------------------------------------------------
echo [6/6] Verificacao final (check do Django)...
venv\Scripts\python.exe manage.py check --settings=nexbuy.settings_demo
if errorlevel 1 (
    echo [ERRO] O check do Django encontrou problemas - veja acima.
    pause
    exit /b 1
)

echo.
echo ==================================================
echo   PREPARACAO CONCLUIDA COM SUCESSO.
echo   Proximo passo: INICIAR_DEMO_NEXBUY.bat
echo ==================================================
echo.
pause
